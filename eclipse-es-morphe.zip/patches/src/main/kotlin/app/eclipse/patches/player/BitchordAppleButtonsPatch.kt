package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"

/**
 * v0.20.305 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Cambia los simbolos de Play, Anterior y
 * Siguiente del diseno Bitchord por los nativos de la plantilla apple-music-v2 (`play.filled`, `previous.plain`,
 * `next.plain`, ya existen en Eclipse 0.6.75). El cambio esta en BitchordTemplate.json(). Mismos ganchos que
 * "Bitchord: Letras estilo Apple Music" (`gx7.c`, `au7.a`, `zt7.q`), ya verificados en el dex 75.
 */
@Suppress("unused")
val bitchordAppleButtonsPatch = bytecodePatch(
    name = "Bitchord: botones estilo Apple Music",
    description = "Los botones Play/Pausa, Anterior y Siguiente de Bitchord pasan a ser los de Apple Music V2 " +
        "(triangulos redondeados). Para una tarjeta que ya tengas, se renueva sola al abrir el reproductor.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordTemplatePatch)

    extendWith("extensions/extension.mpe")

    execute {
        val setStyle = mutableClassDefBy(classDefBy("Lgx7;")).methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lix7;"
        } ?: error("No se encontro gx7.c")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableAppleButtons()V")

        val build = mutableClassDefBy(classDefBy("Lau7;")).methods.firstOrNull {
            it.name == "a" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro au7.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableAppleButtons()V")

        val qm = mutableClassDefBy(classDefBy("Lzt7;")).methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lte7;"
        } ?: error("No se encontro zt7.q")
        qm.addInstructions(0, "invoke-static {}, $EXT->onAppleOpen()V")
    }
}
