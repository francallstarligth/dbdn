package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.util.smali.ExternalLabel
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val WORDS = "Lapp/eclipse/extension/player/LyricsPlusWords;"

/**
 * v0.20.80 (SIN COMPILAR / SIN PROBAR). v75.e(String,String) = consulta a YouLyPlus (POST a los servidores de
 * binimum.org). Verificado en el smali del APK 0.6.47: de la respuesta solo lee "syncedLyrics" y "plainLyrics"
 * (la palabra "syllabus" no aparece en ningun lado). Mochy Music (YouLyPlus.kt) tambien lee "lyrics": lineas con
 * silabas y tiempos en ms. Este parche, justo despues de crear el JSONObject de la respuesta, llama a
 * LyricsPlusWords.convert(respuesta): si NO hay syncedLyrics con texto y SI hay "lyrics", devuelve las lineas en el
 * formato de s65.l (el mismo que Eclipse usa para su API: [{t,e,text,words:[{t,e,text}],voice}], segundos). Entonces
 * se llama a s65.l (lo hace Eclipse mismo), y con eso se arma el resultado igual que en el camino de syncedLyrics
 * (t65 con la fuente LYRICS_PLUS). Si convert devuelve null o la lista queda vacia, salta (etiqueta externa) a la
 * instruccion que seguia y todo sigue como siempre. Registros libres ahi (verificado): v12..v19 (se asignan mas
 * adelante antes de usarse); v7 = JSONObject de la respuesta, no se toca.
 */
@Suppress("unused")
val lyricsPlusWordsPatch = bytecodePatch(
    description = "Eclipse solo lee dos campos de la respuesta de YouLyPlus y a veces la letra llega en otro campo " +
        "(como lo lee Mochy). Con esto, si no llega la letra sincronizada normal, se usa la letra con tiempos por " +
        "palabra (las silabas se juntan en palabras) en el formato que Eclipse ya entiende. Si no hay nada nuevo, " +
        "todo sigue igual. Desmarcalo si las letras de YouLyPlus se ven raras.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val s65 = mutableClassDefBy(classDefBy("Lpo5;"))
        val e = s65.methods.singleOrNull {
            it.name == "e" && it.returnType == "Lqo5;" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/String;", "Ljava/lang/String;")
        } ?: error("No se encontro v75.e (version de Eclipse distinta de 0.6.70?)")
        val list = (e.implementation ?: error("v75.e sin codigo")).instructions.toList()
        // new JSONObject(String): la respuesta del servidor (la otra, JSONObject(), es el pedido)
        val idx = list.indices.filter { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_DIRECT && ref != null && ref.definingClass == "Lorg/json/JSONObject;" &&
                ref.name == "<init>" && ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/String;")
        }
        if (idx.size != 1) error("v75.e: se esperaba 1 JSONObject(String) y hay ${idx.size}")
        // Lo que sigue debe ser la lectura de "syncedLyrics"; si no, no tocar nada.
        val nx = list[idx[0] + 1]
        val nxRef = (nx as? ReferenceInstruction)?.reference as? StringReference
        if (nx.opcode != Opcode.CONST_STRING || nxRef == null || nxRef.string != "syncedLyrics") {
            error("v75.e: despues de JSONObject(String) no esta la lectura de syncedLyrics (version distinta?)")
        }
        val skipTarget = e.getInstruction(idx[0] + 1)
        e.addInstructionsWithLabels(
            idx[0] + 1,
            """
                invoke-static {v7}, $WORDS->convert(Lorg/json/JSONObject;)Lorg/json/JSONArray;
                move-result-object v14
                if-eqz v14, :lyrics_plus_skip
                invoke-static {v14}, Lpo5;->m(Lorg/json/JSONArray;)Ljava/util/ArrayList;
                move-result-object v13
                invoke-virtual {v13}, Ljava/util/ArrayList;->isEmpty()Z
                move-result v12
                if-nez v12, :lyrics_plus_skip
                new-instance v12, Lqo5;
                sget-object v15, Lko5;->LYRICS_PLUS:Lko5;
                const/4 v14, 0x0
                const/16 v16, 0x0
                const/16 v17, 0x0
                const/16 v18, 0x0
                invoke-direct/range {v12 .. v18}, Lqo5;-><init>(Ljava/util/List;Ljava/lang/String;Lko5;Ljava/lang/Float;ZLjava/lang/String;)V
                return-object v12
            """,
            ExternalLabel("lyrics_plus_skip", skipTarget)
        )
    }
}
