package app.eclipse.patches.translation

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val FREE = "Lapp/eclipse/extension/translate/FreeTranslate;"

/**
 * v0.20.192: PORTADO a 0.6.61: `eu3` -> `q44` (DJSegment), `fo4` -> `f05` (tracks); `ru3.g` -> `d54.g(String,JSONObject)`. El comentario (campo `q44.d`) va a `b0.i` (texto en pantalla) y a `b0.d(String)` -> `xx9.a` (audio TTS) y luego `m0.d(texto, bytes)` (reproduce).
 * v0.20.162 (SIN COMPILAR / SIN PROBAR). El DJ habla en espanol: el comentario llega en ingles desde el servidor de Eclipse.
 * Eclipse 0.6.47: `ru3.g(String, JSONObject)` arma el `eu3` (DJSegment) con el JSON (`commentary`, `mood`, `tracks`...); `eu3` solo
 * se construye ahi. Constructor `eu3.<init>(String sessionId, String decisionId, int batch, String commentary, String mood,
 * int songsUntilNext, fo4 tracks, boolean cached)`: sin locales, p0 = this, p4 = commentary. Despues el texto va a `y.d` (genera
 * el audio con la voz elegida) y a `j0.d` (lo reproduce). Gancho al inicio del constructor: p4 = FreeTranslate.dj(p4).
 * Operar sobre un parametro antes de la llamada a super esta permitido (no se toca `this`).
 */
@Suppress("unused")
val djSpanishPatch = bytecodePatch(
    name = "DJ: comentarios en espanol",
    description = "Traduce al espanol lo que dice el DJ antes de leerlo con la voz. Usa DeepL si pusiste tu clave en Apariencia de la " +
        "letra; si no, Google (servicio no oficial). Solo si el telefono esta en espanol. Puede hacer que el DJ tarde un poco mas.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val q44 = mutableClassDefBy(classDefBy("Lla4;"))
        val init = q44.methods.singleOrNull {
            it.name == "<init>" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Ljava/lang/String;", "I", "Ljava/lang/String;", "Ljava/lang/String;", "I", "Lrf5;", "Z")
        } ?: error("No se encontro el constructor de q44 (DJSegment, Eclipse 0.6.70)")
        init.addInstructions(
            0,
            """
                invoke-static {p4}, $FREE->dj(Ljava/lang/String;)Ljava/lang/String;
                move-result-object p4
            """
        )
    }
}
