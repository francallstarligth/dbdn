package app.eclipse.patches.translation

import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.MethodImplementation
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.util.ReferenceUtil

/** Un const-string que se puede traducir sin riesgo: indice de instruccion, registro y texto. */
internal data class Site(val index: Int, val register: Int, val literal: String)

/**
 * Port a Kotlin de analyze.py (v4). Decide por sitio si un const-string es seguro de traducir:
 * se descarta si el registro con el texto se usa enseguida en equals/Map/JSON/Intent/Bundle/etc.,
 * en ramas if-eq/if-ne/switch, como clave de par, o como argumento "name" del constructor de un enum.
 *
 * Diferencias con el script (todas hacia el lado conservador, solo pueden traducir MENOS):
 *  - la ventana se cuenta en instrucciones reales (WINDOW), no en lineas de smali;
 *  - no se corta la ventana en etiquetas (no se conocen aqui);
 *  - un switch sobre el registro tambien descarta el sitio.
 */
internal object SiteAnalyzer {
    private const val WINDOW = 7
    private const val ENUM_WINDOW = 30
    private const val STRING = "Ljava/lang/String;"

    private val UNSAFE = Regex(
        "Ljava/lang/String;->(equals|equalsIgnoreCase|hashCode|contains|startsWith|endsWith|compareTo|valueOf|intern|indexOf|split|matches|regionMatches|replace)" +
            "|Intrinsics;->(areEqual|stringPlus)" +
            "|Ljava/util/(Hash)?Map;->(put|get|containsKey)|Ljava/util/Map;->" +
            "|SharedPreferences|Landroid/os/Bundle;->|Landroid/content/Intent;->(put|get|set|add)" +
            "|Landroid/net/Uri|JSON|Lorg/json|datastore|PreferencesKey|Preferences[\$]" +
            "|Lkotlin/TuplesKt;->to|Lkotlin/Pair;-><init>|Ljava/lang/Enum;|;->valueOf\\(" +
            "|Ljava/net/|Ljava/util/regex|Lokhttp3|Lretrofit2|Ljava/io/(?!Serializable)|Ljava/lang/Class;" +
            "|Lkotlin/text/StringsKt|Ljava/util/Locale|;->parse|Landroidx/navigation" +
            "|Landroidx/compose/ui/platform/ClipboardManager|Landroid/webkit|Landroid/media/MediaMetadata" +
            "|MediaMetadata|Landroid/provider|Ljava/lang/String;->(toLowerCase|toUpperCase|lastIndexOf)"
    )

    private val REDEFINES = listOf("CONST", "MOVE", "NEW_INSTANCE", "SGET", "IGET")

    fun findSites(impl: MethodImplementation, isEnum: Boolean, targets: Set<String>): List<Site> {
        val list = impl.instructions.toList()
        val sites = ArrayList<Site>()
        for (idx in list.indices) {
            val ins = list[idx]
            if (!isConstString(ins)) continue
            val lit = ((ins as ReferenceInstruction).reference as StringReference).string
            if (lit !in targets) continue
            val reg = (ins as OneRegisterInstruction).registerA
            val ok = if (isEnum) enumSiteOk(list, idx, reg) else plainSiteOk(list, idx, reg)
            if (ok) sites += Site(idx, reg, lit)
        }
        return sites
    }

    private fun isConstString(i: Instruction) =
        i.opcode == Opcode.CONST_STRING || i.opcode == Opcode.CONST_STRING_JUMBO

    /** Nombre normalizado (CONST_STRING): dexlib2 expone el nombre smali ("const-string") o el del enum segun el caso. */
    private fun opName(i: Instruction) = i.opcode.name.uppercase().replace('-', '_')

    private fun regs(i: Instruction): List<Int>? = when (i) {
        is RegisterRangeInstruction -> (i.startRegister until i.startRegister + i.registerCount).toList()
        is FiveRegisterInstruction ->
            listOf(i.registerC, i.registerD, i.registerE, i.registerF, i.registerG).take(i.registerCount)
        else -> null
    }

    private fun methodRef(i: Instruction): MethodReference? =
        (i as? ReferenceInstruction)?.reference as? MethodReference

    private fun enumSiteOk(list: List<Instruction>, idx: Int, reg: Int): Boolean {
        for (j in idx + 1 until minOf(list.size, idx + 1 + ENUM_WINDOW)) {
            val ins = list[j]
            val m = methodRef(ins)
            if (m != null && m.name == "<init>" && m.parameterTypes.size >= 2 &&
                m.parameterTypes[0].toString() == STRING && m.parameterTypes[1].toString() == "I"
            ) {
                val rr = regs(ins)
                if (rr != null && reg in rr) {
                    // rr[1] es el argumento "name" del enum: traducirlo rompe valueOf.
                    return !(rr.size > 1 && rr[1] == reg)
                }
            }
            if (isConstString(ins) && (ins as OneRegisterInstruction).registerA == reg) break
        }
        return false // enum-noinit: no se sabe a donde va, se deja en ingles
    }

    private fun plainSiteOk(list: List<Instruction>, idx: Int, reg: Int): Boolean {
        for (j in idx + 1 until minOf(list.size, idx + 1 + WINDOW)) {
            val ins = list[j]
            val name = opName(ins)
            // El registro se redefine: el texto ya no vive aqui.
            if (REDEFINES.any { name.startsWith(it) } && ins is OneRegisterInstruction && ins.registerA == reg) break
            if (name.startsWith("PACKED_SWITCH") || name.startsWith("SPARSE_SWITCH")) {
                if (ins is OneRegisterInstruction && ins.registerA == reg) return false
                break
            }
            if (name.startsWith("RETURN") || name.startsWith("GOTO") || name == "THROW") break
            val m = methodRef(ins)
            if (m != null) {
                val rr = regs(ins)
                if (rr != null && reg in rr) {
                    val desc = ReferenceUtil.getMethodDescriptor(m)
                    if (isPairKey(m, rr, reg)) return false
                    if (UNSAFE.containsMatchIn(desc)) return false
                }
            }
            if ((ins.opcode == Opcode.IF_EQ || ins.opcode == Opcode.IF_NE) && ins is TwoRegisterInstruction &&
                (ins.registerA == reg || ins.registerB == reg)
            ) return false
        }
        return true
    }

    /**
     * Constructor de par ofuscado: metodo estatico (Serializable, Object) cuyo 1.er argumento es la clave.
     * En 0.6.47 es Lp18;->v(Ljava/io/Serializable;Ljava/lang/Object;). Se detecta por forma.
     */
    private fun isPairKey(m: MethodReference, rr: List<Int>, reg: Int): Boolean {
        val p = m.parameterTypes.map { it.toString() }
        return p.size == 2 && p[0] == "Ljava/io/Serializable;" && p[1] == "Ljava/lang/Object;" &&
            rr.isNotEmpty() && rr[0] == reg
    }
}
