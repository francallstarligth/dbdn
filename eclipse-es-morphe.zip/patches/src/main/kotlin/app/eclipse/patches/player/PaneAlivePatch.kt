package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val P = "Lapp/eclipse/extension/player/PaneAlive;"

/**
 * v0.20.70 (SIN COMPILAR / SIN PROBAR). Tres ganchos que solo INSERTAN llamadas:
 * 1) qw0.e(String) (peso de una pestana): al inicio PaneAlive.begin(nombre); antes del unico `return v` PaneAlive.end(peso).
 * 2) hj6.b (arma el panel): justo despues de `Lr15;->g(Lmh5;F)Lmh5;` + move-result-object (alpha de cada pantalla)
 *    se llama PaneAlive.hide(modificador, peso).
 */
@Suppress("unused")
val paneAlivePatch = bytecodePatch(
    name = "Cola: dejarla armada (sin parpadeo al entrar)",
    description = "Cola queda armada pero invisible y sin recibir toques, asi al tocarla ya tiene la lista y las portadas " +
        "(antes se armaba desde cero al tocar). Usa un poco mas de memoria y bateria. Desmarcalo para volver a como era.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- qw0.e ----
        val qw0 = mutableClassDefBy(classDefBy("Lqw0;"))
        val e = qw0.methods.singleOrNull {
            it.name == "e" && it.returnType == "F" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0].toString() == "Ljava/lang/String;"
        } ?: error("No se encontro qw0.e(String)")
        val eIns = (e.implementation ?: error("qw0.e sin codigo")).instructions.toList()
        val rets = eIns.indices.filter { eIns[it].opcode == Opcode.RETURN }
        if (rets.size != 1) error("qw0.e: se esperaba 1 return (hay ${rets.size})")
        val rr = (eIns[rets[0]] as OneRegisterInstruction).registerA
        if (rr > 15) error("qw0.e: registro fuera de rango (v$rr)")
        // primero el final (para no mover indices), luego el inicio
        e.addInstructions(
            rets[0],
            """
                invoke-static {v$rr}, $P->end(F)F
                move-result v$rr
            """
        )
        e.addInstructions(0, "invoke-static {p1}, $P->begin(Ljava/lang/String;)V")

        // ---- hj6.b ----
        val hj6 = mutableClassDefBy(classDefBy("Lhj6;"))
        val b = hj6.methods.singleOrNull {
            it.name == "b" && it.parameterTypes.size == 8 && it.parameterTypes[0].toString() == "Lib6;" &&
                it.parameterTypes[1].toString() == "Lqw0;"
        } ?: error("No se encontro hj6.b")
        val bIns = (b.implementation ?: error("hj6.b sin codigo")).instructions.toList()
        val hits = bIns.indices.filter { i ->
            bIns[i].opcode == Opcode.INVOKE_STATIC &&
                (((bIns[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lr15;" && it.name == "g" && it.returnType == "Lmh5;" &&
                        it.parameterTypes.size == 2 && it.parameterTypes[1].toString() == "F"
                } == true)
        }
        if (hits.size != 1) error("hj6.b: se esperaba 1 r15.g (hay ${hits.size})")
        val h = hits[0]
        if (bIns[h + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("hj6.b: falta move-result-object tras r15.g")
        val modReg = (bIns[h + 1] as OneRegisterInstruction).registerA
        val wReg = (bIns[h] as FiveRegisterInstruction).registerD
        if (modReg > 15 || wReg > 15) error("hj6.b: registros fuera de rango (v$modReg, v$wReg)")
        b.addInstructions(
            h + 2,
            """
                invoke-static {v$modReg, v$wReg}, $P->hide(Ljava/lang/Object;F)Ljava/lang/Object;
                move-result-object v$modReg
                check-cast v$modReg, Lmh5;
            """
        )
    }
}
