package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction

/**
 * v0.20.330 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): titulos de las tarjetas del Inicio ("Mapa de generos",
 * "Mas escuchadas de siempre", "Daily Mix 4"...) con las lineas pegadas y a veces cortadas.
 *
 * Causa (vista en el dex 75): `Lgq6;->d(String, String, F, I, String, Z, dk3, dk3, Leu1, I, I)V` es la tarjeta. Su titulo es
 * `Lysa;->b` (Text) con letra = ancho de la tarjeta * 0.15 sp, maxLines 3, centrado, y SIN lineHeight (usa el del
 * estilo por defecto, mas chico que la letra) => las lineas se pisan; ademas "escuchadas" no cabe y se parte en medio.
 *
 * Arreglo, 3 cambios solo en ese Text:
 * 1) factor de la letra 0.15 -> 0.12 (`const vN, 1041865114` justo antes de `mul-float vX, v46, vN`).
 * 2) lineHeight propio = ancho * 0.135 sp (1,125 veces la letra): se calcula en v24..v26 (aun libres) con `Lqe8;->b0(J,F)J`
 *    y se deja en v22/v23 (lineHeight) justo despues de `const-wide/16 v22, 0` de ESA llamada.
 * 3) mascara de "usar valor por defecto" (`const v33, 240554`): se apaga el bit 9 (lineHeight): 240554 -> 240042.
 */
@Suppress("unused")
val cardTitleSpacingPatch = bytecodePatch(
    name = "Inicio: titulo de tarjetas mas separado",
    description = "En las tarjetas del Inicio (Mapa de generos, Mas escuchadas de siempre, Daily Mix...) separa las " +
        "lineas del titulo y achica un poco la letra para que no se pisen ni se corten. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val gq6 = mutableClassDefBy(classDefBy("Lgq6;"))
        val esperados = listOf(
            "Ljava/lang/String;", "Ljava/lang/String;", "F", "I", "Ljava/lang/String;", "Z",
            "Ldk3;", "Ldk3;", "Leu1;", "I", "I"
        )
        val metodo = gq6.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("No se encontro gq6.d (tarjeta del Inicio; Eclipse 0.6.75)")
        val ins = (metodo.implementation ?: error("gq6.d sin codigo")).instructions.toList()

        // 1) const vN, 1041865114 (0.15f) seguido de mul-float _, v46, vN
        val fuentes = ins.indices.filter { i ->
            val a = ins[i]
            a.opcode == Opcode.CONST && (a as NarrowLiteralInstruction).narrowLiteral == 1041865114 &&
                i + 1 < ins.size && ins[i + 1].opcode == Opcode.MUL_FLOAT
        }
        if (fuentes.size != 1) error("gq6.d: se esperaba 1 \"0.15f * ancho\" (hay ${fuentes.size})")
        val iFuente = fuentes[0]
        val regFuente = (ins[iFuente] as OneRegisterInstruction).registerA

        // 3) const v33, 240554 (mascara de valores por defecto del Text del titulo)
        val mascaras = ins.indices.filter { i ->
            val a = ins[i]
            a.opcode == Opcode.CONST && (a as OneRegisterInstruction).registerA == 33 &&
                (a as NarrowLiteralInstruction).narrowLiteral == 240554
        }
        if (mascaras.size != 1) error("gq6.d: se esperaba 1 \"const v33, 240554\" (hay ${mascaras.size})")
        val iMascara = mascaras[0]
        if (iMascara < iFuente) error("gq6.d: la mascara va antes que la letra (orden inesperado)")

        // 2) const-wide/16 v22, 0 (lineHeight sin valor) de esa misma llamada: el primero tras la mascara
        val lineas = ins.indices.filter { i ->
            val a = ins[i]
            i > iMascara && a.opcode == Opcode.CONST_WIDE_16 && (a as OneRegisterInstruction).registerA == 22 &&
                (a as WideLiteralInstruction).wideLiteral == 0L
        }
        if (lineas.isEmpty()) error("gq6.d: no se encontro const-wide/16 v22, 0 tras la mascara")
        val iLinea = lineas[0]
        // Entre la mascara y ese punto no debe haber otra llamada a Text (la llamada es la siguiente de v24..v29)
        if (ins.subList(iMascara, iLinea).any { it.opcode == Opcode.INVOKE_STATIC_RANGE }) {
            error("gq6.d: hay una llamada entre la mascara y lineHeight (orden inesperado)")
        }

        // De mayor a menor indice (addInstructions desplaza lo de despues; replaceInstruction no).
        metodo.addInstructions(
            iLinea + 1,
            """
                const-wide v24, 0x100000000L
                const v26, 0x3e0a3d71
                mul-float v26, v46, v26
                invoke-static/range {v24 .. v26}, Lqe8;->b0(JF)J
                move-result-wide v22
            """.trimIndent()
        )
        metodo.replaceInstruction(iMascara, "const v33, 240042")
        metodo.replaceInstruction(iFuente, "const v$regFuente, 1039516303")
    }
}
