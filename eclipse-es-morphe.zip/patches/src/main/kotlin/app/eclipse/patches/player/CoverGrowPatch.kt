package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val SCALE = "Lapp/eclipse/extension/player/FluidScale;"

/**
 * v0.20.364 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Caratula: en pausa su tamano normal y al dar play crece un poquito.
 * Hoy el skin ("breatheOnPause", `Lja0.d`; escala `Lja0.e`, 0.86 por defecto) la achica al PAUSAR. `Lxu7.t(Lv51;Lh61;Z J Leu1;I)` calcula el objetivo
 * del resorte "breathe" en v15: bloque `iget-boolean v8, Lja0;->d` / `if-ne` / `if-nez v32` / `if-eqz v1` / `if-nez v19` (v19 = sonando) /
 * (v15 = escala del skin) o `move v15, v9` (= 1.0). Arreglo (2 inserciones; primero la de mas abajo):
 * (1) tras `double-to-float` + `move v15, v0`: v15 = FluidScale.grow(v15) (1.04).
 * (2) antes de `if-nez v19`: `xor-int/lit8 v19, v19, 1` (invierte "sonando": ahora el camino de la escala es sonando y pausado cae en 1.0).
 * v19 se pisa mas abajo (`const/16 v19, 3120`), asi que invertirlo no afecta a nadie.
 * Requiere que el skin tenga "respirar al pausar" encendido (el del usuario ya lo tiene).
 * NO verificado: que se vea bien; que a 1.04 no se corte o choque con otras cosas del skin.
 */
@Suppress("unused")
val coverGrowPatch = bytecodePatch(
    description = "La caratula queda en su tamano normal al pausar y crece un poquito al dar play.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lxu7;"))
        val m = cls.methods.singleOrNull {
            it.name == "t" && it.returnType == "Lev4;" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Lv51;", "Lh61;", "Z", "J", "Leu1;", "I")
        } ?: error("Caratula que crece: no se encontro Lxu7.t (Eclipse 0.6.75)")
        val ins = (m.implementation ?: error("Caratula que crece: Lxu7.t sin codigo")).instructions.toList()

        val starts = ins.indices.filter { i ->
            ins[i].opcode == Opcode.IGET_BOOLEAN &&
                ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let {
                    it.definingClass == "Lja0;" && it.name == "d" && it.type == "Z"
                } == true
        }
        if (starts.size != 1) error("Caratula que crece: se esperaba 1 'iget-boolean Lja0.d' y hay ${starts.size}")
        val s = starts[0]

        // s+1 if-ne, s+2 if-nez v32, s+3 if-eqz v1, s+4 if-nez v19, s+5 if-eqz v0, s+6 iget-wide, s+7 goto, s+8 const-wide, s+9 double-to-float, s+10 move v15
        val pl = ins[s + 4]
        if (pl.opcode != Opcode.IF_NEZ || (pl as OneRegisterInstruction).registerA != 19)
            error("Caratula que crece: s+4 no es 'if-nez v19'")
        if (ins[s + 9].opcode != Opcode.DOUBLE_TO_FLOAT) error("Caratula que crece: s+9 no es double-to-float")
        val mv = ins[s + 10]
        if (mv.opcode != Opcode.MOVE || (mv as OneRegisterInstruction).registerA != 15)
            error("Caratula que crece: s+10 no es 'move v15, v0'")

        // (1) primero la de mas abajo
        m.addInstructions(
            s + 11,
            """
            invoke-static {v15}, $SCALE->grow(F)F
            move-result v15
            """
        )
        // (2)
        m.addInstructions(
            s + 4,
            """
            xor-int/lit8 v19, v19, 0x1
            """
        )
    }
}
