package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.util.smali.ExternalLabel
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val MOCHY = "Lapp/eclipse/extension/player/LyricsPlusMochy;"

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR). Eclipse pide la letra a YouLyPlus (s65.e) con un POST que solo lleva
 * titulo y artista; Mochy Music hace un GET con titulo, artista y DURACION. Prueba del usuario en su navegador
 * (29-oct-2026): "Te Estoy Correteando" (3:14) con artista con coma + duration=194 SI devuelve letra por silabas.
 *
 * VERIFICADO en el smali de 0.6.47: s65.e(String,String) se llama solo desde ha.w (la corrutina de letras), en 2 sitios:
 *  A) proveedor elegido: invoke-virtual {v6 s65, v7 titulo, v8 artista}, s65.e ; v9 = duracion en segundos (Lha;->s,
 *     el mismo entero que Eclipse manda como &durationS= en s65.g) ; return-object.
 *  B) sin proveedor fijo (recorre todos): invoke-virtual {v11 s65, v12 titulo, v13 artista}, s65.e ; move-result v11 ;
 *     goto :goto_c (guarda en cache). La duracion se lee de Lha;->s con v1 (= el propio ha).
 * Antes de cada llamada se inserta: LyricsPlusMochy.fetch(titulo, artista, duracion) -> t65 o null. Si da un t65 se
 * usa ese resultado; si da null sigue el pedido original (s65.e) como siempre. Registros libres verificados:
 * A: v0 ; B: v14 (v4..v8 son constantes del bucle y no se tocan).
 *
 * v0.20.82: causa probable de que v0.20.81 "no funcionara" (VERIFICADO en el smali): en el sitio A, antes de llegar a
 * s65.e, Eclipse pregunta a su propio servidor (s65.g -> api.eclipsemusic.app). Si ese servidor contesta bien pero
 * con found=false, s65.g devuelve llv4.f y ha.w hace `goto :goto_10` = return null ("No se encontro letra") SIN llamar
 * nunca a YouLyPlus. Ahora, justo antes de ese goto, si el proveedor (v1, un n65) es LYRICS_PLUS se salta a :goto_4
 * (el mismo punto al que ya va Eclipse cuando su servidor falla) para pedir directo a YouLyPlus (con el gancho A).
 * Registros: v3 libre (se reasigna en :goto_4), v1 = n65 del proveedor. Los otros proveedores quedan igual.
 */
@Suppress("unused")
val lyricsPlusMochyPatch = bytecodePatch(
    description = "Eclipse le pide la letra a YouLyPlus solo con titulo y artista, y a veces no la encuentra aunque " +
        "Mochy si. Con esto Eclipse pide primero como Mochy (con la duracion de la cancion y el artista con coma); " +
        "si asi no llega nada, sigue con su pedido de siempre. Si la letra viene por palabra, la usa por palabra. " +
        "Ademas, en modo Automatico respeta tu orden de proveedores (ya no deja que el servidor de Eclipse elija la fuente). " +
        "Desmarcalo si las letras de YouLyPlus dejan de salir.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val ha = mutableClassDefBy(classDefBy("Lha;"))

        // Indices de cada invoke-virtual s65.e(String,String), por metodo
        fun isE(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction): Boolean {
            val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference
            return ins.opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Ls65;" &&
                ref.name == "e" && ref.returnType == "Lt65;" &&
                ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/String;", "Ljava/lang/String;")
        }

        var total = 0
        for (m in ha.methods) {
            val impl = m.implementation ?: continue
            total += impl.instructions.count { isE(it) }
        }
        if (total != 2) error("ha: se esperaban 2 llamadas a s65.e y hay $total (version de Eclipse distinta de 0.6.54?)")

        for (m in ha.methods) {
            val impl0 = m.implementation ?: continue
            val found = impl0.instructions.withIndex().filter { isE(it.value) }.map { it.index }
            // De atras hacia adelante, para que los indices del mismo metodo no se muevan
            for (idx in found.sortedDescending()) {
                val list = (m.implementation ?: error("ha sin codigo")).instructions.toList()
                val ins = list[idx] as? FiveRegisterInstruction ?: error("ha: llamada a s65.e con otra forma")
                if (ins.registerCount != 3) error("ha: llamada a s65.e con ${ins.registerCount} registros")
                val regs = listOf(ins.registerC, ins.registerD, ins.registerE)
                val origTarget = m.getInstruction(idx)
                val next = list[idx + 1]
                val after = list[idx + 2]
                when (regs) {
                    // A: ya no se engancha desde v0.20.90 (lo cubre el gancho directo de mas abajo)
                    listOf(6, 7, 8) -> { }
                    // B: {v11, v12, v13}, seguida de move-result-object v11 / goto
                    listOf(11, 12, 13) -> {
                        val isGoto = after.opcode == Opcode.GOTO || after.opcode == Opcode.GOTO_16 ||
                            after.opcode == Opcode.GOTO_32
                        if (next.opcode != Opcode.MOVE_RESULT_OBJECT || !isGoto) {
                            error("ha: despues de s65.e (sitio B) no sigue move-result + goto (version distinta?)")
                        }
                        val gotoTarget = m.getInstruction(idx + 2)
                        m.addInstructionsWithLabels(
                            idx,
                            """
                                iget v14, v1, Lha;->s:I
                                invoke-static {v12, v13, v14}, $MOCHY->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                                move-result-object v14
                                if-eqz v14, :mochy_orig
                                check-cast v14, Lt65;
                                move-object v11, v14
                                goto :mochy_done
                            """,
                            ExternalLabel("mochy_orig", origTarget),
                            ExternalLabel("mochy_done", gotoTarget)
                        )
                    }
                    else -> error("ha: s65.e se llama con registros $regs (se esperaba v6,v7,v8 o v11,v12,v13)")
                }
            }
        }
        // v0.20.90: gancho directo. Justo despues de `sget-object v3, Lo85;->MUSIXMATCH` (donde v1 = n65 del proveedor
        // ya elegido), si es LYRICS_PLUS se pide la letra con LyricsPlusMochy.fetch(titulo=v14, artista=v8, duracion=v9)
        // y, si trae letra, se devuelve ese t65 sin preguntar antes al servidor de Eclipse. Si da null, sigue todo igual.
        // (Se quitaron los ganchos de v0.20.82/84 que saltaban a :goto_4: en el telefono se llegaba a "Letra 2" pero
        // nunca a fetch.)
        val hm = ha.methods.filter { m ->
            val ins = m.implementation?.instructions?.toList() ?: return@filter false
            ins.any { isE(it) }
        }
        if (hm.size != 1) error("ha: s65.e deberia estar en un solo metodo (ha.w) y esta en ${hm.size}")
        val m = hm[0]
        val all = (m.implementation ?: error("ha sin codigo")).instructions.toList()
        val sIdx = all.indexOfFirst { ins ->
            val r = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.SGET_OBJECT && r != null && r.definingClass == "Lo85;" && r.name == "MUSIXMATCH"
        }
        if (sIdx < 0) error("ha.w: no se encontro o85.MUSIXMATCH")
        m.addInstructionsWithLabels(
            sIdx + 1,
            """
                sget-object v3, Ln65;->LYRICS_PLUS:Ln65;
                if-ne v1, v3, :mochy_skip
                invoke-static {v14, v8, v9}, $MOCHY->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                move-result-object v3
                if-eqz v3, :mochy_skip
                check-cast v3, Lt65;
                return-object v3
                :mochy_skip
                sget-object v3, Lo85;->MUSIXMATCH:Lo85;
            """
        )

        // v0.20.148: modo Automatico (sin proveedor fijo). VERIFICADO en el smali de 0.6.47: en ha.w, con v0 (o85) == null,
        // Eclipse llama a s65.g (api.eclipsemusic.app, &provider= vacio): el servidor elige la fuente (kugou/betterlyrics/
        // lyricsplus/lrclib) y ha.w usa esa letra tal cual, sin mirar tu lista de prioridad. Solo si el servidor FALLA
        // (llv4.g) recorre la lista local en orden. Ahora, justo antes de esa llamada a s65.g (la segunda de ha.w), se salta
        // al inicio del recorrido local (el ArrayList.iterator() que sigue a `sget-object v9, Llv4;->g` + equals + if-eqz)
        // fijando antes v10 = 20 (limite de cache que usa el recorrido). v3 (lista de activados en orden), v1 (ha) y v2
        // (null) siguen intactos en ese punto; v4..v8 = 2,3,4,5,1 ya estan puestos antes de la llamada.
        run {
            val l2 = (m.implementation ?: error("ha sin codigo")).instructions.toList()
            fun isG(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction): Boolean {
                val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                return ins.opcode == Opcode.INVOKE_VIRTUAL_RANGE && r != null && r.definingClass == "Ls65;" && r.name == "g"
            }
            val gIdx = l2.withIndex().filter { isG(it.value) }.map { it.index }
            if (gIdx.size != 2) error("ha.w: se esperaban 2 llamadas a s65.g y hay ${gIdx.size} (version distinta de 0.6.54?)")
            val autoIdx = gIdx.last()
            val sg = l2.withIndex().filter { (_, ins) ->
                val r = (ins as? ReferenceInstruction)?.reference as? FieldReference
                ins.opcode == Opcode.SGET_OBJECT && r != null && r.definingClass == "Lp65;" && r.name == "i"
            }.map { it.index }
            if (sg.isEmpty()) error("ha.w: no se encontro p65.i")
            val loopIdx = sg.last() + 4
            val li = l2[loopIdx]
            val lr = (li as? ReferenceInstruction)?.reference as? MethodReference
            if (loopIdx <= autoIdx || li.opcode != Opcode.INVOKE_VIRTUAL || lr == null ||
                lr.definingClass != "Ljava/util/ArrayList;" || lr.name != "iterator") {
                error("ha.w: el inicio del recorrido local no es ArrayList.iterator() (version distinta?)")
            }
            m.addInstructionsWithLabels(
                autoIdx,
                """
                    const/16 v10, 0x14
                    goto/16 :mochy_auto
                """,
                ExternalLabel("mochy_auto", m.getInstruction(loopIdx))
            )
        }
    }
}
