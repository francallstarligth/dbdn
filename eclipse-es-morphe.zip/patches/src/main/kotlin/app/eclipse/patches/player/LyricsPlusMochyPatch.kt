package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.util.smali.ExternalLabel
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val MOCHY = "Lapp/eclipse/extension/player/LyricsPlusMochy;"

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR). Eclipse pide la letra a YouLyPlus (ov4.e) con un POST que solo lleva
 * titulo y artista; Mochy Music hace un GET con titulo, artista y DURACION. Prueba del usuario en su navegador
 * (29-oct-2026): "Te Estoy Correteando" (3:14) con artista con coma + duration=194 SI devuelve letra por silabas.
 *
 * VERIFICADO en el smali de 0.6.47: ov4.e(String,String) se llama solo desde y9.h (la corrutina de letras), en 2 sitios:
 *  A) proveedor elegido: invoke-virtual {v6 ov4, v7 titulo, v8 artista}, ov4.e ; v9 = duracion en segundos (Ly9;->s,
 *     el mismo entero que Eclipse manda como &durationS= en ov4.g) ; return-object.
 *  B) sin proveedor fijo (recorre todos): invoke-virtual {v11 ov4, v12 titulo, v13 artista}, ov4.e ; move-result v11 ;
 *     goto :goto_c (guarda en cache). La duracion se lee de Ly9;->s con v1 (= el propio y9).
 * Antes de cada llamada se inserta: LyricsPlusMochy.fetch(titulo, artista, duracion) -> pv4 o null. Si da un pv4 se
 * usa ese resultado; si da null sigue el pedido original (ov4.e) como siempre. Registros libres verificados:
 * A: v0 ; B: v14 (v4..v8 son constantes del bucle y no se tocan).
 *
 * v0.20.82: causa probable de que v0.20.81 "no funcionara" (VERIFICADO en el smali): en el sitio A, antes de llegar a
 * ov4.e, Eclipse pregunta a su propio servidor (ov4.g -> api.eclipsemusic.app). Si ese servidor contesta bien pero
 * con found=false, ov4.g devuelve llv4.f y y9.h hace `goto :goto_10` = return null ("No se encontro letra") SIN llamar
 * nunca a YouLyPlus. Ahora, justo antes de ese goto, si el proveedor (v1, un jv4) es LYRICS_PLUS se salta a :goto_4
 * (el mismo punto al que ya va Eclipse cuando su servidor falla) para pedir directo a YouLyPlus (con el gancho A).
 * Registros: v3 libre (se reasigna en :goto_4), v1 = jv4 del proveedor. Los otros proveedores quedan igual.
 */
@Suppress("unused")
val lyricsPlusMochyPatch = bytecodePatch(
    name = "Letras: YouLyPlus como Mochy",
    description = "Eclipse le pide la letra a YouLyPlus solo con titulo y artista, y a veces no la encuentra aunque " +
        "Mochy si. Con esto Eclipse pide primero como Mochy (con la duracion de la cancion y el artista con coma); " +
        "si asi no llega nada, sigue con su pedido de siempre. Si la letra viene por palabra, la usa por palabra. " +
        "Desmarcalo si las letras de YouLyPlus dejan de salir.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val y9 = mutableClassDefBy(classDefBy("Ly9;"))

        // Indices de cada invoke-virtual ov4.e(String,String), por metodo
        fun isE(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction): Boolean {
            val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference
            return ins.opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Lov4;" &&
                ref.name == "e" && ref.returnType == "Lpv4;" &&
                ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/String;", "Ljava/lang/String;")
        }

        var total = 0
        for (m in y9.methods) {
            val impl = m.implementation ?: continue
            total += impl.instructions.count { isE(it) }
        }
        if (total != 2) error("y9: se esperaban 2 llamadas a ov4.e y hay $total (version de Eclipse distinta de 0.6.47?)")

        for (m in y9.methods) {
            val impl0 = m.implementation ?: continue
            val found = impl0.instructions.withIndex().filter { isE(it.value) }.map { it.index }
            // De atras hacia adelante, para que los indices del mismo metodo no se muevan
            for (idx in found.sortedDescending()) {
                val list = (m.implementation ?: error("y9 sin codigo")).instructions.toList()
                val ins = list[idx] as? FiveRegisterInstruction ?: error("y9: llamada a ov4.e con otra forma")
                if (ins.registerCount != 3) error("y9: llamada a ov4.e con ${ins.registerCount} registros")
                val regs = listOf(ins.registerC, ins.registerD, ins.registerE)
                val origTarget = m.getInstruction(idx)
                val next = list[idx + 1]
                val after = list[idx + 2]
                when (regs) {
                    // A: {v6, v7, v8}, seguida de move-result-object v0 / return-object v0
                    listOf(6, 7, 8) -> {
                        if (next.opcode != Opcode.MOVE_RESULT_OBJECT || after.opcode != Opcode.RETURN_OBJECT) {
                            error("y9: despues de ov4.e (sitio A) no sigue move-result + return (version distinta?)")
                        }
                        m.addInstructionsWithLabels(
                            idx,
                            """
                                invoke-static {v7, v8, v9}, $MOCHY->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                                move-result-object v0
                                if-eqz v0, :mochy_orig
                                check-cast v0, Lpv4;
                                return-object v0
                            """,
                            ExternalLabel("mochy_orig", origTarget)
                        )
                    }
                    // B: {v11, v12, v13}, seguida de move-result-object v11 / goto
                    listOf(11, 12, 13) -> {
                        val isGoto = after.opcode == Opcode.GOTO || after.opcode == Opcode.GOTO_16 ||
                            after.opcode == Opcode.GOTO_32
                        if (next.opcode != Opcode.MOVE_RESULT_OBJECT || !isGoto) {
                            error("y9: despues de ov4.e (sitio B) no sigue move-result + goto (version distinta?)")
                        }
                        val gotoTarget = m.getInstruction(idx + 2)
                        m.addInstructionsWithLabels(
                            idx,
                            """
                                iget v14, v1, Ly9;->s:I
                                invoke-static {v12, v13, v14}, $MOCHY->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                                move-result-object v14
                                if-eqz v14, :mochy_orig
                                check-cast v14, Lpv4;
                                move-object v11, v14
                                goto :mochy_done
                            """,
                            ExternalLabel("mochy_orig", origTarget),
                            ExternalLabel("mochy_done", gotoTarget)
                        )
                    }
                    else -> error("y9: ov4.e se llama con registros $regs (se esperaba v6,v7,v8 o v11,v12,v13)")
                }
            }
        }
        // v0.20.82: si el servidor de Eclipse dice "no la tengo" (llv4.f) y el proveedor es LyricsPlus, pedir directo
        val hm = y9.methods.filter { m ->
            val ins = m.implementation?.instructions?.toList() ?: return@filter false
            ins.any { isE(it) }
        }
        if (hm.size != 1) error("y9: ov4.e deberia estar en un solo metodo (y9.h) y esta en ${hm.size}")
        val m = hm[0]
        val all = (m.implementation ?: error("y9 sin codigo")).instructions.toList()
        fun fieldOf(i: Int): FieldReference? = (all[i] as? ReferenceInstruction)?.reference as? FieldReference
        val fIdx = all.indices.filter { i ->
            val r = fieldOf(i)
            all[i].opcode == Opcode.SGET_OBJECT && r != null && r.definingClass == "Llv4;" && r.name == "f" &&
                (all[i] as OneRegisterInstruction).registerA == 3
        }
        if (fIdx.isEmpty()) error("y9: no se encontro la comprobacion llv4.f con v3")
        val fi = fIdx[0]
        val chk = listOf(Opcode.INVOKE_VIRTUAL, Opcode.MOVE_RESULT, Opcode.IF_EQZ)
        for (k in 0..2) if (all[fi + 1 + k].opcode != chk[k]) error("y9: la comprobacion llv4.f no tiene la forma esperada")
        val g = all[fi + 4].opcode
        if (g != Opcode.GOTO && g != Opcode.GOTO_16 && g != Opcode.GOTO_32) error("y9: tras llv4.f no sigue un goto")
        val direct = all.indices.filter { i ->
            val r = fieldOf(i)
            all[i].opcode == Opcode.SGET_OBJECT && r != null && r.definingClass == "Lmv4;" && r.name == "b"
        }
        if (direct.size != 1) error("y9: se esperaba 1 lectura de mv4.b y hay ${direct.size}")
        val directTarget = m.getInstruction(direct[0])
        m.addInstructionsWithLabels(
            fi + 4,
            """
                sget-object v3, Ljv4;->LYRICS_PLUS:Ljv4;
                if-eq v1, v3, :mochy_direct
            """,
            ExternalLabel("mochy_direct", directTarget)
        )
    }
}
