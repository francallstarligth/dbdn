package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val ALBUMS = "Lapp/eclipse/extension/umbra/UmbraAlbums;"

/**
 * v0.20.391 (PRUEBA, SIN COMPILAR NI PROBAR, Eclipse 0.6.75): al inicio de `Lcc4;->k(Context, JSONObject, I, Z, String, Lvz1;)`
 * (POST `intent/rules` de la Smart Playlist; instancia: p0 = this, p1 = Context, p2 = JSON de reglas) se llama
 * UmbraAlbums.agregar(reglas), que agrega `"albums": ["Starboy", "Dawn FM"]` si las reglas traen "The Weeknd" como artista.
 * Sirve para ver si el servidor entiende un campo de albumes. Quitar si no funciona.
 */
@Suppress("unused")
val umbraAlbumsTestPatch = bytecodePatch(
    name = "Smart Playlist: prueba de albumes (The Weeknd)",
    description = "PRUEBA. Si en Smart Playlist pones solo el artista The Weeknd, le agrega al pedido los albumes Starboy y Dawn FM " +
        "para ver si el servidor los respeta. No toca otros artistas. Si salen canciones de otros albumes, el servidor no lo entiende.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cc4 = mutableClassDefBy(classDefBy("Lcc4;"))
        val k = cc4.methods.singleOrNull {
            it.name == "k" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.map { p -> p.toString() } == listOf(
                    "Landroid/content/Context;", "Lorg/json/JSONObject;", "I", "Z", "Ljava/lang/String;", "Lvz1;"
                )
        } ?: error("No se encontro cc4.k (Eclipse 0.6.75)")
        // instancia: p0 = this, p1 = Context, p2 = JSONObject de reglas (registro bajo, cabe en 4 bits)
        k.addInstructions(0, "invoke-static {p2}, $ALBUMS->agregar(Ljava/lang/Object;)V")
    }
}
