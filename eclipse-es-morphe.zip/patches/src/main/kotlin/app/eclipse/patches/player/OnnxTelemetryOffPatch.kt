package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * ONNX Runtime (analisis de audio) trae telemetria de Microsoft (1DS): al abrir la app, el ContentProvider
 * `ai.onnxruntime.TelemetryInitializer` crea un `telemetry.HttpClient` (junta clase de dispositivo, ANDROID_ID,
 * zona horaria, bateria y red) y la libreria nativa manda eventos (ProcessInfo, SessionCreation, ModelLoad,
 * RuntimePerf) a https://mobile.events.data.microsoft.com/OneCollector/1.0/.
 *
 * Arreglo: en `TelemetryInitializer.onCreate()`, justo despues de `System.loadLibrary("onnxruntime")`, se devuelve
 * `true` sin crear el cliente HTTP. La libreria nativa lo maneja: "Android telemetry is unavailable because the 1DS
 * Java HttpClient was not initialized". La inferencia no depende de esto.
 */
@Suppress("unused")
val onnxTelemetryOffPatch = bytecodePatch(
    name = "Sin telemetria de ONNX Runtime",
    description = "Evita que la libreria de analisis de audio (ONNX Runtime) envie datos de uso y del " +
        "dispositivo a Microsoft. El analisis no cambia.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lai/onnxruntime/TelemetryInitializer;"))
        val method = cls.methods.firstOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro TelemetryInitializer.onCreate")
        val ins = (method.implementation ?: error("onCreate sin codigo")).instructions.toList()
        val load = ins.indexOfFirst { i ->
            i.opcode == Opcode.INVOKE_STATIC &&
                ((i as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Ljava/lang/System;" && it.name == "loadLibrary"
                } == true
        }
        if (load < 0) error("TelemetryInitializer.onCreate: no se encontro System.loadLibrary")
        // v0 es local (onCreate tiene 4 registros: v0..v2 locales, v3 = this).
        method.addInstructions(
            load + 1,
            """
                const/4 v0, 0x1
                return v0
            """
        )
    }
}
