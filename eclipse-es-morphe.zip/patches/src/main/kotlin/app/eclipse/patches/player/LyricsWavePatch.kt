package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val WAVE = "Lapp/eclipse/extension/player/LyricWave;"

/**
 * v0.20.450 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Letras: desplazamiento en OLA. Ver `LyricWave.java`.
 *
 * Cuatro ganchos (todos verificados en el smali del APK base 0.6.75; nombres ofuscados):
 *  (1) `Lno5;.invokeSuspend` (autoscroll de letras). Antes de `iput 4 -> no5.r` + `Lyd8;->k(La39; F Ls83; Lvz1;)` (animateScrollBy con resorte)
 *      se llama `LyricWave.start(distancia, lineaActiva)`; si devuelve true se salta al scroll instantaneo que ya existe en la misma
 *      corrutina (el `iput 3 -> no5.r` + `Lyd8;->D(La39; F Lvz1;)` de la rama "no5.v"). Si devuelve false sigue el resorte original.
 *  (2) `Lqp5;.k` (item de la LazyColumn): justo despues de `check-cast Len5` -> `LyricWave.line(linea, indice)`.
 *  (3) `Lg22;.B` (la fila): al inicio `LyricWave.cur(p0)` (p0 = Len5) y, entre `Lll.<init>` y su `Lku1.n0` (remember), `LyricWave.bind(lll)`.
 *  (4) `Lll;.invoke` (caso `Ld0b` + 2 `Lhea`: graphicsLayer de la fila: alpha, scaleX, scaleY, origen): antes del `if-eqz Ld0b` se hace
 *      `Loq3.f(LyricWave.dy(this))` (`Loq3.f` = translationY, campo v de `Lmw8`).
 * Todo cae al comportamiento original si algo falla en tiempo de ejecucion (LyricWave.broken).
 */
@Suppress("unused")
val lyricsWavePatch = bytecodePatch(
    description = "Al cambiar de linea, la letra sube con efecto ola: la linea activa sube primero y las demas la siguen, una tras otra, " +
        "con un retraso muy chico. Desmarcalo si prefieres que suba toda junta como en Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        fun mref(i: Instruction): MethodReference? = (i as? ReferenceInstruction)?.reference as? MethodReference
        fun fref(i: Instruction): FieldReference? = (i as? ReferenceInstruction)?.reference as? FieldReference
        fun params(r: MethodReference) = r.parameterTypes.map { it.toString() }

        // true si la instruccion lee o escribe el registro reg (cubre los formatos que usan estos metodos)
        fun usa(x: Instruction, reg: Int): Boolean {
            val a = x is OneRegisterInstruction && (x.registerA == reg || x.registerA + 1 == reg)
            val b = x is TwoRegisterInstruction && (x.registerB == reg || x.registerB + 1 == reg)
            val c = x is ThreeRegisterInstruction && (x.registerC == reg || x.registerC + 1 == reg)
            val f = x is FiveRegisterInstruction &&
                listOf(x.registerC, x.registerD, x.registerE, x.registerF, x.registerG).take(x.registerCount).any { it == reg || it + 1 == reg }
            val g = x is RegisterRangeInstruction && reg >= x.startRegister && reg < x.startRegister + x.registerCount
            return a || b || c || f || g
        }

        // ---------------------------------------------------------------- (1) autoscroll: Lno5;.invokeSuspend
        run {
            val cls = mutableClassDefBy(classDefBy("Lno5;"))
            val m = cls.methods.singleOrNull {
                it.name == "invokeSuspend" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
            } ?: error("Ola: no se encontro Lno5.invokeSuspend")
            val ins = (m.implementation ?: error("Ola: Lno5.invokeSuspend sin codigo")).instructions.toList()

            val kHits = ins.indices.filter { i ->
                val r = mref(ins[i])
                ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lyd8;" && r.name == "k" &&
                    params(r) == listOf("La39;", "F", "Ls83;", "Lvz1;")
            }
            if (kHits.size != 1) error("Ola: se esperaba 1 llamada a Lyd8.k (animateScrollBy) y hay ${kHits.size}")
            val k = kHits[0]
            val dHits = ins.indices.filter { i ->
                val r = mref(ins[i])
                ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lyd8;" && r.name == "D" &&
                    params(r) == listOf("La39;", "F", "Lvz1;")
            }
            if (dHits.size != 1 || dHits[0] >= k) error("Ola: se esperaba 1 llamada a Lyd8.D (scrollBy) antes de Lyd8.k y hay ${dHits.size}")
            val d = dHits[0]

            // el resorte se arma justo antes: const/high16 (rigidez) ... Lpab.F(F F I Object) -> move-result-object -> iput estado=4 -> Lyd8.k
            val putK = ins[k - 1]
            val putKRef = fref(putK)
            if (putK.opcode != Opcode.IPUT || putKRef == null || putKRef.definingClass != "Lno5;" || putKRef.name != "r")
                error("Ola: antes de Lyd8.k no viene iput no5.r")
            val spring = (k - 2 downTo maxOf(0, k - 6)).firstOrNull { i ->
                val r = mref(ins[i]); ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lpab;" && r.name == "F"
            } ?: error("Ola: no se encontro el resorte Lpab.F antes de Lyd8.k")
            if (spring >= k) error("Ola: orden inesperado")

            // rama instantanea existente: iput no5.r (estado 3) justo antes de Lyd8.D
            val putD = ins[d - 1]
            val putDRef = fref(putD)
            if (putD.opcode != Opcode.IPUT || putDRef == null || putDRef.definingClass != "Lno5;" || putDRef.name != "r")
                error("Ola: antes de Lyd8.D no viene iput no5.r")

            val kCall = ins[k] as FiveRegisterInstruction
            val dCall = ins[d] as FiveRegisterInstruction
            val distReg = kCall.registerD
            if (dCall.registerD != distReg) error("Ola: la distancia no esta en el mismo registro en Lyd8.k y Lyd8.D")
            if (distReg > 15) error("Ola: registro alto para la distancia (v$distReg)")

            // indice de la linea activa: iget no5.t (I) al inicio
            val tHits = ins.indices.filter { i ->
                val r = fref(ins[i]); ins[i].opcode == Opcode.IGET && r != null && r.definingClass == "Lno5;" && r.name == "t" && r.type == "I"
            }
            if (tHits.size != 1 || tHits[0] > d) error("Ola: se esperaba 1 iget no5.t (I) al inicio y hay ${tHits.size}")
            val actReg = (ins[tHits[0]] as TwoRegisterInstruction).registerA
            if (actReg > 15) error("Ola: registro alto para la linea activa (v$actReg)")
            // nadie debe escribir sobre ese registro despues del iget (las demas apariciones solo lo leen: sub-int, if, invoke)
            val pisado = ins.indices.any { i ->
                i > tHits[0] && ins[i] is OneRegisterInstruction && (ins[i] as OneRegisterInstruction).registerA == actReg &&
                    ins[i].opcode !in listOf(
                        Opcode.IF_EQ, Opcode.IF_NE, Opcode.IF_LT, Opcode.IF_GE, Opcode.IF_GT, Opcode.IF_LE,
                        Opcode.IF_EQZ, Opcode.IF_NEZ, Opcode.IF_LTZ, Opcode.IF_GEZ, Opcode.IF_GTZ, Opcode.IF_LEZ,
                        Opcode.IPUT, Opcode.IPUT_OBJECT, Opcode.IPUT_BOOLEAN, Opcode.SPUT, Opcode.SPUT_OBJECT,
                        Opcode.RETURN, Opcode.RETURN_OBJECT, Opcode.PACKED_SWITCH, Opcode.SPARSE_SWITCH
                    )
            }
            if (pisado) error("Ola: el registro v$actReg (no5.t) se vuelve a escribir en Lno5.invokeSuspend")

            // registro auxiliar 0..15 que no aparezca ni en la rama del resorte (k-1 .. return) ni en la rama instantanea (d-1 .. return)
            fun tramo(from: Int): IntRange {
                val end = ins.indices.first { it > from && ins[it].opcode == Opcode.RETURN_OBJECT }
                return from..end
            }
            val ra = tramo(k - 1)
            val rb = tramo(d - 1)
            val scratch = (0..15).firstOrNull { r ->
                r != distReg && r != actReg &&
                    ra.none { usa(ins[it], r) } && rb.none { usa(ins[it], r) }
            } ?: error("Ola: no hay registro libre en Lno5.invokeSuspend")

            // Etiqueta externa a la rama instantanea (como LyricsPop): `iput no5.r = 3` + Lyd8.D
            val go = m.getInstruction(d - 1)
            m.addInstructionsWithLabels(
                k - 1,
                """
                    invoke-static {v$distReg, v$actReg}, $WAVE->start(FI)Z
                    move-result v$scratch
                    if-nez v$scratch, :lyric_wave_go
                """,
                ExternalLabel("lyric_wave_go", go)
            )
        }

        // ---------------------------------------------------------------- (2) Lqp5;.k : indice de cada linea
        run {
            val cls = mutableClassDefBy(classDefBy("Lqp5;"))
            val m = cls.methods.singleOrNull {
                it.name == "k" && it.parameterTypes.size == 4 && it.parameterTypes.all { p -> p.toString() == "Ljava/lang/Object;" }
            } ?: error("Ola: no se encontro Lqp5.k")
            val ins = (m.implementation ?: error("Ola: Lqp5.k sin codigo")).instructions.toList()
            // List.get(indice) -> move-result-object -> [move-object] -> check-cast Len5
            val hits = ins.indices.filter { i ->
                val r = mref(ins[i])
                if (ins[i].opcode != Opcode.INVOKE_INTERFACE || r == null || r.definingClass != "Ljava/util/List;" || r.name != "get") return@filter false
                (i + 1..minOf(ins.size - 1, i + 4)).any { j ->
                    val t = (ins[j] as? ReferenceInstruction)?.reference as? TypeReference
                    ins[j].opcode == Opcode.CHECK_CAST && t != null && t.type == "Len5;"
                }
            }
            // hay mas (las lineas vecinas que calcula despues para Ldn5): el que importa es el PRIMERO (la linea del item), en el arranque del metodo
            if (hits.isEmpty() || hits[0] > 80) error("Ola: Lqp5.k: no se encontro List.get + check-cast Len5 al inicio (hits=${hits})")
            val g = hits[0]
            val idxReg = (ins[g] as FiveRegisterInstruction).registerD
            val cc = (g + 1..g + 4).first {
                val t = (ins[it] as? ReferenceInstruction)?.reference as? TypeReference
                ins[it].opcode == Opcode.CHECK_CAST && t != null && t.type == "Len5;"
            }
            val lineReg = (ins[cc] as OneRegisterInstruction).registerA
            if (idxReg > 15 || lineReg > 15) error("Ola: Lqp5.k: registros altos (v$idxReg, v$lineReg)")
            // el registro del indice no se debe escribir entre el get y el check-cast
            if ((g + 1..cc).any { i -> i != cc && ins[i] is OneRegisterInstruction && (ins[i] as OneRegisterInstruction).registerA == idxReg })
                error("Ola: Lqp5.k: el registro del indice (v$idxReg) se pisa antes del check-cast")
            m.addInstructions(cc + 1, "invoke-static {v$lineReg, v$idxReg}, $WAVE->line(Ljava/lang/Object;I)V")
        }

        // ---------------------------------------------------------------- (3) Lg22;.B : fila de letra
        run {
            val cls = mutableClassDefBy(classDefBy("Lg22;"))
            val m = cls.methods.singleOrNull {
                it.name == "B" && it.parameterTypes.size == 23 && it.parameterTypes[0].toString() == "Len5;"
            } ?: error("Ola: no se encontro Lg22.B")
            val ins = (m.implementation ?: error("Ola: Lg22.B sin codigo")).instructions.toList()
            val news = ins.indices.filter { i ->
                val t = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
                ins[i].opcode == Opcode.NEW_INSTANCE && t != null && t.type == "Lll;"
            }
            if (news.size != 1) error("Ola: Lg22.B: se esperaba 1 new-instance Lll y hay ${news.size}")
            val ni = news[0]
            val llReg = (ins[ni] as OneRegisterInstruction).registerA
            if (llReg > 15) error("Ola: Lg22.B: registro alto para Lll (v$llReg)")
            // new-instance -> invoke-direct <init> -> invoke-virtual Lku1.n0 (remember): el bind va entre el <init> y el n0
            val init = (ni + 1..ni + 2).firstOrNull { i ->
                val r = mref(ins[i]); ins[i].opcode == Opcode.INVOKE_DIRECT && r != null && r.definingClass == "Lll;" && r.name == "<init>"
            } ?: error("Ola: Lg22.B: no se encontro Lll.<init> tras el new-instance")
            val n0 = ins[init + 1]
            val n0r = mref(n0)
            if (n0.opcode != Opcode.INVOKE_VIRTUAL || n0r == null || n0r.definingClass != "Lku1;" || n0r.name != "n0")
                error("Ola: Lg22.B: despues de Lll.<init> no viene Lku1.n0")
            // 1o el de mas adelante, para no mover el indice del otro
            m.addInstructions(init + 1, "invoke-static {v$llReg}, $WAVE->bind(Ljava/lang/Object;)V")
            m.addInstructions(0, "invoke-static/range {p0 .. p0}, $WAVE->cur(Ljava/lang/Object;)V")
        }

        // ---------------------------------------------------------------- (4) Lll;.invoke : translationY de la fila
        run {
            val cls = mutableClassDefBy(classDefBy("Lll;"))
            val m = cls.methods.singleOrNull {
                it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
            } ?: error("Ola: no se encontro Lll.invoke")
            val ins = (m.implementation ?: error("Ola: Lll.invoke sin codigo")).instructions.toList()
            val m0 = ins.indices.filter { i ->
                val r = mref(ins[i])
                ins[i].opcode == Opcode.INVOKE_INTERFACE && r != null && r.definingClass == "Loq3;" && r.name == "M0" && params(r) == listOf("J")
            }
            if (m0.size != 1) error("Ola: Lll.invoke: se esperaba 1 Loq3.M0(J) y hay ${m0.size}")
            val i0 = m0[0]
            // iget-wide Ld0b;->a (origen) justo antes, y antes un if-eqz del Ld0b; antes de ese if, Loq3.i(F) (scaleY)
            val ig = ins[i0 - 1]
            val igr = fref(ig)
            if (ig.opcode != Opcode.IGET_WIDE || igr == null || igr.definingClass != "Ld0b;" || igr.name != "a")
                error("Ola: Lll.invoke: antes de Loq3.M0 no viene iget-wide Ld0b.a")
            val ifz = ins[i0 - 2]
            if (ifz.opcode != Opcode.IF_EQZ) error("Ola: Lll.invoke: antes del iget-wide no viene el if-eqz")
            val sy = mref(ins[i0 - 3])
            if (ins[i0 - 3].opcode != Opcode.INVOKE_INTERFACE || sy == null || sy.definingClass != "Loq3;" || sy.name != "i" || params(sy) != listOf("F"))
                error("Ola: Lll.invoke: antes del if-eqz no viene Loq3.i(F) (scaleY)")
            val scope = (ins[i0] as FiveRegisterInstruction).registerC // receptor Loq3
            val scratch = (ig as OneRegisterInstruction).registerA     // se pisa justo despues en la rama normal; en la otra ya no se usa
            if (scope > 15 || scratch > 15 || scope == scratch || scope == scratch + 1)
                error("Ola: Lll.invoke: registros inesperados (Loq3=v$scope, aux=v$scratch)")
            // el receptor no debe cambiar entre aqui y el caso de abajo y no debe estar el aux como Loq3.f ya usado
            val yaTradY = ins.indices.any { i ->
                val r = mref(ins[i]); i in (i0 - 40)..i0 && ins[i].opcode == Opcode.INVOKE_INTERFACE && r != null && r.definingClass == "Loq3;" && r.name == "f"
            }
            if (yaTradY) error("Ola: Lll.invoke: este caso ya usa Loq3.f (translationY)")
            m.addInstructions(
                i0 - 2,
                """
                    move-object/from16 v$scratch, p0
                    invoke-static {v$scratch}, $WAVE->dy(Ljava/lang/Object;)F
                    move-result v$scratch
                    invoke-interface {v$scope, v$scratch}, Loq3;->f(F)V
                """
            )
        }
    }
}
