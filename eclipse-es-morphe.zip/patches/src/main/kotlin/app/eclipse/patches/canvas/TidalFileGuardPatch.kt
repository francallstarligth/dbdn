package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val GUARD = "Lapp/eclipse/extension/canvas/TidalFileGuard;"

/**
 * v0.20.199 (SIN COMPILAR NI PROBAR). Eclipse 0.6.57 baja los videos animados de Tidal a un archivo (AnimatedArtworkCache,
 * clase ks) y los busca con ks.g(String) -> File, que solo mira File.exists(). Un archivo cortado a medias se reutiliza y
 * el video no se reproduce. Verificado en el dex 0.6.57: ks.g(String) la llaman, para Tidal, ww0.o (reproduccion: invoke-virtual
 * v6,v4 + move-result-object v5) y k6a.b (bajada: invoke-virtual v7,v0 + move-result-object v2); ny.c (Apple) tambien, y NO se toca.
 * Despues del move-result-object de esas dos llamadas se pasa el File por TidalFileGuard.check, que lo devuelve igual o,
 * si es un mp4 incompleto, lo borra y devuelve null (Eclipse lo vuelve a bajar).
 */
@Suppress("unused")
val tidalFileGuardPatch = bytecodePatch(
    name = "Canvas: revisar el video guardado de Tidal",
    description = "Eclipse guarda los videos animados de Tidal como archivo y solo comprueba que exista. Si una descarga " +
        "quedo a medias, la portada carga el primer cuadro y no se reproduce hasta borrar el cache. Este parche revisa el " +
        "archivo antes de usarlo y, si esta incompleto, lo borra para que Eclipse lo baje de nuevo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // v0.20.273 (0.6.73, SIN COMPILAR NI PROBAR): rz0.o -> i01.o, tra.b -> fta.b, rt.g -> tt.g (1 llamada en cada uno, verificado).
        var hooked = 0
        for (cls in listOf("Li01;", "Lfta;")) {
            val def = mutableClassDefBy(classDefBy(cls))
            for (method in def.methods.toList()) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val hits = list.indices.filter { i ->
                    val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                    list[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Ltt;" &&
                        ref.name == "g" && ref.returnType == "Ljava/io/File;" &&
                        ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/String;") &&
                        list.getOrNull(i + 1)?.opcode == Opcode.MOVE_RESULT_OBJECT
                }
                // de atras hacia adelante para no mover los indices
                for (i in hits.sortedDescending()) {
                    val reg = (list[i + 1] as OneRegisterInstruction).registerA
                    if (reg > 15) error("$cls.${method.name}: registro del File fuera de v0..v15")
                    method.addInstructions(
                        i + 2,
                        """
                            invoke-static {v$reg}, $GUARD->check(Ljava/io/File;)Ljava/io/File;
                            move-result-object v$reg
                        """
                    )
                    hooked++
                }
            }
        }
        if (hooked != 2) error("Tidal: se esperaban 2 llamadas a rt.g(String) (rz0.o y tra.b) y hay $hooked")
    }
}
