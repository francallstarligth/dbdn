package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"

/**
 * v0.20.45 (SIN COMPILAR / SIN PROBAR). Parche aparte (se puede desmarcar). Mientras arrastras la portada con el dedo,
 * el reflejo (desenfoque de abajo) se mueve igual que la portada y entra al lado la portada de la cancion vecina
 * (siguiente o anterior) con su propio desenfoque, sin hueco. Al soltar, el deslizamiento sigue desde donde quedo.
 *
 * El gancho solo le pasa a PrevCover el estado del arrastre (y46 = MutableFloatState con los pixeles arrastrados, el
 * mismo que Eclipse usa para mover la portada): di6.q(List,Z,ow0,Z,F,F,ib6,t43,f43,u43,kn8,en5,en5,y46,Set,kw0,f43,qi1,I,I)
 * lo recibe como parametro 13 (0 = primero). Todo lo demas esta en PrevCover y BlurredCanvasBackground.
 */
@Suppress("unused")
val dragFollowPatch = bytecodePatch(
    name = "Cambio de cancion: seguir el dedo al arrastrar",
    description = "Al arrastrar la portada con el dedo, el desenfoque se mueve igual y entra la portada de la cancion " +
        "vecina (con su desenfoque), sin hueco. Solo en canciones sin Canvas. Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(slideSkipPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Ly46;"
        } ?: error("No se encontro di6.q con y46 en el parametro 13")
        val impl = q.implementation ?: error("di6.q sin implementacion")
        // metodo estatico: los 20 parametros son los ultimos registros; el parametro 13 queda 7 antes del final
        val reg = impl.registerCount - 20 + 13
        q.addInstructions(
            0,
            "invoke-static/range {v$reg .. v$reg}, $EXT->setDrag(Ljava/lang/Object;)V"
        )
    }
}
