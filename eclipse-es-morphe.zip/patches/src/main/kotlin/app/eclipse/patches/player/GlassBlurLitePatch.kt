package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

/**
 * Blur del liquid glass de Eclipse 0.6.47: `du9.i(zc2, F)V` fija el desenfoque (RenderEffect blur) del vidrio con el
 * radio recibido en p1 (v4; p0 = v3 = zc2). Solo lo llama `tz.invoke` (4 casos); el blur generico de Compose
 * (`llm1.c`) y el de `nm0` no pasan por aqui.
 *
 * Arreglo: al inicio de `du9.i` se multiplica el radio por 0.6 (v0 es libre: se reescribe mas abajo con el SDK_INT).
 * Un radio <= 0 sigue siendo <= 0, asi que el `return-void` original de radio cero se conserva.
 */
@Suppress("unused")
val glassBlurLitePatch = bytecodePatch(
    name = "Blur del liquid glass al 60%",
    description = "Baja el desenfoque (blur) del liquid glass al 60% del valor original para que el telefono " +
        "trabaje menos. No cambia el blur de otras partes de la app.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val du9 = mutableClassDefBy(classDefBy("Ldu9;"))
        val method = du9.methods.firstOrNull {
            it.name == "i" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0].toString() == "Lzc2;" && it.parameterTypes[1].toString() == "F"
        } ?: error("No se encontro du9.i(zc2, F)")

        val impl = method.implementation ?: error("du9.i sin codigo")
        if (impl.registerCount != 5) error("du9.i: se esperaban 5 registros (hay ${impl.registerCount})")
        val ins = impl.instructions.toList()
        if (ins[0].opcode != Opcode.INVOKE_VIRTUAL) error("du9.i: la primera instruccion no es invoke-virtual")
        if (ins.none { it.opcode == Opcode.NEW_INSTANCE }) error("du9.i: no se ve la creacion del efecto de blur (nm0)")

        method.addInstructions(
            0,
            """
                const v0, 0x3f19999a
                mul-float/2addr v4, v0
            """
        )
    }
}
