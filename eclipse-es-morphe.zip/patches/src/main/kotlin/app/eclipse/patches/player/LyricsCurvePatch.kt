package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val CURVE = "Lapp/eclipse/extension/player/CurveText;"

/**
 * v0.20.393 (SIN COMPILAR / SIN PROBAR). Letra curva alrededor del disco (diseno Tocadiscos). Cuatro cambios, todos
 * leidos en el smali del APK Base 0.6.75:
 *  1) Al empezar xz1.I0 (el dibujo de una linea de letra; 27 registros, p0 = v25, p1 = v26 = Lnw4;): se saca el Canvas
 *     (nw4.q -> q51.r -> e46.C() -> an.a, igual que LyricsPopPatch) y se llama CurveText.enter(Canvas); si no es un
 *     Canvas conocido, CurveText.leave(). `iget-object` solo llega a v15, por eso primero `move-object/from16 v1, v26`.
 *     v0 y v1 estan libres al empezar (el metodo los escribe antes de leerlos).
 *  2) Justo antes de `Lnw4;->j()V` (dibujar contenido, al final de I0): CurveText.leave().
 *  3) Justo antes del recorte de cada renglon (`Lpx8;->M(FFFFI)V`, una sola llamada; v17 = izquierda, v18 = arriba,
 *     v19 = derecha, v20 = abajo; v8 esta libre ahi, lo reasigna `add-float v8` mas adelante): si CurveText.clipOff(v5 = tamano de letra en px)
 *     los cambia por -1e6 / 1e6 (el recorte recto dejaria afuera las silabas ya movidas). Se ejecuta DESPUES de
 *     LyricsTailsPatch (que tambien toca v18 / v20 en ese sitio) para que su valor sea el ultimo.
 *  4) Al empezar yd8.q(Lnw4; Lbta; J) (13 locales, p0 = v13 ... p3 = v16; v0 libre): si CurveText.drawColor(...)
 *     dibuja curvo, return-void.
 * La linea que suena (degradado, yd8.p) NO lleva gancho propio: LyricsPop.draw (ya enganchado por lyricsPopPatch) llama
 * a CurveText cuando hay curva. Por eso este parche necesita lyricsPopPatch.
 */
@Suppress("unused")
val lyricsCurvePatch = bytecodePatch(
    description = "Las letras de la vista del disco (tarjeta chica) se curvan alrededor del disco del diseno Tocadiscos. " +
        "Necesita \"Letras grandes junto al relleno\". Experimental.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(lyricsPopPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- xz1.I0 ----
        val xz1 = mutableClassDefBy(classDefBy("Lxz1;"))
        val i0 = xz1.methods.singleOrNull {
            it.name == "I0" && it.parameterTypes.map { p -> p.toString() } == listOf("Lnw4;")
        } ?: error("No se encontro xz1.I0 (version de Eclipse distinta de 0.6.75?)")

        // (3) recorte de renglon: se busca primero (antes de insertar nada arriba) y se inserta antes de esa llamada.
        val list0 = (i0.implementation ?: error("xz1.I0 sin codigo")).instructions.toList()
        val mIdx = list0.indices.filter { i ->
            val ref = (list0[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lpx8;" && ref.name == "M" &&
                ref.parameterTypes.map { it.toString() } == listOf("F", "F", "F", "F", "I")
        }
        if (mIdx.size != 1) error("xz1.I0: se esperaba 1 llamada a px8.M (clipRect) y hay ${mIdx.size}")
        val keepTarget = i0.getInstruction(mIdx[0])
        i0.addInstructionsWithLabels(
            mIdx[0],
            """
                invoke-static/range {v5 .. v5}, $CURVE->clipOff(F)Z
                move-result v8
                if-eqz v8, :curve_keep
                const v17, -0x368bdc00
                const v18, -0x368bdc00
                const v19, 0x49742400
                const v20, 0x49742400
            """,
            ExternalLabel("curve_keep", keepTarget)
        )

        // (2) antes de dibujar el contenido (nw4.j()), al final de I0.
        val list1 = i0.implementation!!.instructions.toList()
        val jIdx = list1.indices.filter { i ->
            val ref = (list1[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lnw4;" && ref.name == "j" && ref.parameterTypes.isEmpty()
        }
        if (jIdx.size != 1) error("xz1.I0: se esperaba 1 llamada a nw4.j() y hay ${jIdx.size}")
        i0.addInstructions(jIdx[0], "invoke-static {}, $CURVE->leave()V")

        // (1) al empezar I0.
        val firstTarget = i0.getInstruction(0)
        i0.addInstructionsWithLabels(
            0,
            """
                move-object/from16 v1, v26
                iget-object v0, v1, Lnw4;->q:Lq51;
                iget-object v0, v0, Lq51;->r:Le46;
                invoke-virtual {v0}, Le46;->C()Lg51;
                move-result-object v0
                instance-of v1, v0, Lan;
                if-eqz v1, :curve_nc
                check-cast v0, Lan;
                iget-object v0, v0, Lan;->a:Landroid/graphics/Canvas;
                invoke-static {v0}, $CURVE->enter(Landroid/graphics/Canvas;)V
                goto :curve_go
                :curve_nc
                invoke-static {}, $CURVE->leave()V
            """,
            ExternalLabel("curve_go", firstTarget)
        )

        // ---- yd8.q ----
        val yd8 = mutableClassDefBy(classDefBy("Lyd8;"))
        val q = yd8.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.map { p -> p.toString() } == listOf("Lnw4;", "Lbta;", "J")
        } ?: error("No se encontro yd8.q (version de Eclipse distinta de 0.6.75?)")
        val qFirst = q.getInstruction(0)
        q.addInstructionsWithLabels(
            0,
            """
                invoke-static/range {v13 .. v16}, $CURVE->drawColor(Ljava/lang/Object;Ljava/lang/Object;J)Z
                move-result v0
                if-eqz v0, :curve_orig
                return-void
            """,
            ExternalLabel("curve_orig", qFirst)
        )
    }
}
