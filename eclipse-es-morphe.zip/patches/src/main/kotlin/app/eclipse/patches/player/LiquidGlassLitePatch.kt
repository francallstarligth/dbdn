package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/**
 * Liquid glass liviano (union de dos arreglos que antes eran parches separados; clases distintas, sin nada compartido).
 *
 * A) Sin dispersion (antes "Liquid glass liviano (sin dispersion)"):
 * `da2.E(zc2, F, F, I)` arma el shader (AGSL) de la lente. Un flag de la lente (bit 8 de el ultimo parametro ->
 * registro v6) elige entre dos shaders: "Refraction" (1 lectura de la imagen por pixel) y "RefractionWithDispersion"
 * (7 lecturas por pixel en el borde, efecto arcoiris). Despues, `if-eqz v6` tambien decide si se fija el uniform
 * `chromaticAberration`. Arreglo: justo antes del `if-nez v6` que elige el shader se fuerza v6 = 0, asi siempre sale
 * "Refraction" y no se fija chromaticAberration (el shader sin dispersion no lo tiene). Un solo gancho, un registro.
 *
 * B) Blur al 60% (antes "Blur del liquid glass al 60%"):
 * `du9.i(zc2, F)V` fija el desenfoque (RenderEffect blur) del vidrio con el radio recibido en p1 (v4; p0 = v3 = zc2).
 * Solo lo llama `tz.invoke` (4 casos); el blur generico de Compose (`llm1.c`) y el de `nm0` no pasan por aqui.
 * Arreglo: al inicio de `du9.i` se multiplica el radio por 0.6 (v0 es libre: se reescribe mas abajo con el SDK_INT).
 * Un radio <= 0 sigue siendo <= 0, asi que el `return-void` original de radio cero se conserva.
 */
@Suppress("unused")
val liquidGlassLitePatch = bytecodePatch(
    name = "Liquid glass liviano",
    description = "Hace que el liquid glass pese menos para el telefono: apaga la dispersion de color (arcoiris) " +
        "en los bordes y baja el desenfoque (blur) del vidrio al 60%. El vidrio sigue curvando el fondo. " +
        "No cambia el blur de otras partes de la app.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // ---------------------------------------------------------------- A) sin dispersion: da2.E
        val da2 = mutableClassDefBy(classDefBy("Lda2;"))
        val shaderMethod = da2.methods.firstOrNull {
            it.name == "E" && it.parameterTypes.size == 4 && it.parameterTypes[0].toString() == "Lzc2;"
        } ?: error("No se encontro da2.E")

        val ins = (shaderMethod.implementation ?: error("da2.E sin codigo")).instructions.toList()

        fun str(i: Int): String? =
            if (ins[i].opcode == Opcode.CONST_STRING)
                (((ins[i] as ReferenceInstruction).reference) as? StringReference)?.string
            else null

        val shaderIdx = ins.indices.filter { str(it) == "Refraction" }
        if (shaderIdx.size != 1) error("da2.E: se esperaba un solo const-string \"Refraction\" (hay ${shaderIdx.size})")
        val ifIdx = shaderIdx[0] - 1
        if (ifIdx < 0 || ins[ifIdx].opcode != Opcode.IF_NEZ) error("da2.E: falta if-nez antes de \"Refraction\"")
        if (ins.indices.count { str(it) == "RefractionWithDispersion" } != 1) error("da2.E: falta \"RefractionWithDispersion\"")

        val flagReg = (ins[ifIdx] as OneRegisterInstruction).registerA
        if (flagReg > 15) error("da2.E: registro del flag fuera de v0..v15 (v$flagReg)")
        // El if-nez no debe ser destino de un salto: la instruccion anterior debe ser secuencial (no goto/return/if).
        val prev = ins[ifIdx - 1].opcode
        if (prev == Opcode.GOTO || prev == Opcode.GOTO_16 || prev == Opcode.GOTO_32 || prev == Opcode.RETURN_VOID)
            error("da2.E: instruccion previa al if-nez no es secuencial ($prev)")

        // ---------------------------------------------------------------- B) blur al 60%: du9.i
        val du9 = mutableClassDefBy(classDefBy("Ldu9;"))
        val blurMethod = du9.methods.firstOrNull {
            it.name == "i" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0].toString() == "Lzc2;" && it.parameterTypes[1].toString() == "F"
        } ?: error("No se encontro du9.i(zc2, F)")

        val blurImpl = blurMethod.implementation ?: error("du9.i sin codigo")
        if (blurImpl.registerCount != 5) error("du9.i: se esperaban 5 registros (hay ${blurImpl.registerCount})")
        val blurIns = blurImpl.instructions.toList()
        if (blurIns[0].opcode != Opcode.INVOKE_VIRTUAL) error("du9.i: la primera instruccion no es invoke-virtual")
        if (blurIns.none { it.opcode == Opcode.NEW_INSTANCE }) error("du9.i: no se ve la creacion del efecto de blur (nm0)")

        // Las dos comprobaciones de arriba se hacen ANTES de tocar nada: si alguna falla, no se modifica ninguna.
        shaderMethod.addInstructions(
            ifIdx,
            """
                const/4 v$flagReg, 0x0
            """
        )
        blurMethod.addInstructions(
            0,
            """
                const v0, 0x3f19999a
                mul-float/2addr v4, v0
            """
        )
    }
}
