package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/**
 * Liquid glass liviano (union de dos arreglos que antes eran parches separados; clases distintas, sin nada compartido).
 *
 * A) Sin dispersion (antes "Liquid glass liviano (sin dispersion)"):
 * `da2.E(zc2, F, F, I)` arma el shader (AGSL) de la lente. Un flag de la lente (bit 8 de el ultimo parametro ->
 * registro v6) elige entre dos shaders: "Refraction" (1 lectura de la imagen por pixel) y "RefractionWithDispersion"
 * (7 lecturas por pixel en el borde, efecto arcoiris). Despues, `if-eqz v6` tambien decide si se fija el uniform
 * `chromaticAberration`. Arreglo: justo antes del `if-nez v6` que elige el shader se fuerza v6 = 0, asi siempre sale
 * "Refraction" y no se fija chromaticAberration (el shader sin dispersion no lo tiene). Un solo gancho, un registro.
 *
 * B) Blur al 60% (antes "Blur del liquid glass al 60%"):
 * `du9.i(zc2, F)V` fija el desenfoque (RenderEffect blur) del vidrio con el radio recibido en p1 (v4; p0 = v3 = zc2).
 * Solo lo llama `tz.invoke` (4 casos); el blur generico de Compose (`llm1.c`) y el de `nm0` no pasan por aqui.
 * Arreglo: al inicio de `du9.i` se multiplica el radio por 0.6 (v0 es libre: se reescribe mas abajo con el SDK_INT).
 * Un radio <= 0 sigue siendo <= 0, asi que el `return-void` original de radio cero se conserva.
 *
 * C) Opcion `frosted` (v1.96.0, apagada): "Frosted: sin refraccion". Cada vez que se actualiza una lente, `ad2.t1`
 * pone `zc2.v = null` y llama a `tz.invoke`, que arma el efecto en 3 pasos: `ka1.b` (filtro de color), `du9.i`
 * (blur) y `da2.E` (refraccion, encadenada encima). Con la opcion, `da2.E` hace `return-void` al inicio: queda
 * filtro de color + blur (un frosted glass) y no se corre el shader. En lugar de A (sin dispersion) que ya no hace falta.
 *
 * D) Opcion `thinRim` (v1.96.2, apagada): "Borde fino parejo (estilo Bitchord)". El borde de luz lo dibujan las
 * estrategias de la interfaz `sd3`: `qd3` (Default) y `od3` (Ambient); `b(ad4, ty7, mh7): lp` arma un shader (AGSL)
 * cuya intensidad depende del angulo (`pow(abs(d), falloff)`), por eso el brillo es direccional. Con la opcion se
 * reemplaza, tras el `const-string` del codigo AGSL, el texto del shader por otro con intensidad constante
 * (`rimStrength`, 35% por defecto): borde parejo. En `od3` ademas `t = 1.0` (blanco en todo el contorno). Se deja
 * `0.0 * falloff + 0.0 * angle` para que los uniforms sigan usados (se fijan despues desde Kotlin/smali).
 *
 * F) Opcion `darkenPercent` (v1.96.3, "0"): `ka1.a(F, F): pa1` arma la matriz de color del vidrio (saturacion con la
 * segunda F y desplazamiento de brillo con la primera F, que se multiplica por 255 en los indices 4, 9 y 14). Con la
 * opcion se resta `pct/100` a la primera F al inicio (p0 = v9, v0 libre): el vidrio queda mas oscuro de forma pareja.
 *
 * G) Opcion `tintPercent` + `tintColor` (v1.96.4, "0"): en `ka1.a(F, F)`, justo antes del primer `new-instance Lpa1;`
 * (la matriz de 20 floats ya esta en v7; v0 y v1 libres; sin saltos en el metodo), se llama a
 * `GlassTint.mix([F F I)V`: escala las filas R, G, B por (1 - alfa) y suma alfa * color (0..255) al desplazamiento.
 * Es una capa lisa translucida (sin dibujar nada nuevo). Cubre tambien el filtro por defecto (`ka1.<clinit>` usa `ka1.a`).
 *
 * E) Opcion `blurPercent` (v1.96.2, "60"): el blur de B ya no es fijo al 60%: se lee el porcentaje (10 a 300).
 */
@Suppress("unused")
val liquidGlassLitePatch = bytecodePatch(
    name = "Liquid glass liviano",
    description = "Hace que el liquid glass pese menos para el telefono: apaga la dispersion de color (arcoiris) " +
        "en los bordes y baja el desenfoque (blur) del vidrio al 60%. El vidrio sigue curvando el fondo. " +
        "No cambia el blur de otras partes de la app. Opcion extra: frosted (sin curvar el fondo).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val frosted by booleanOption(
        key = "frosted",
        default = false,
        title = "Frosted: sin refraccion",
        description = "El vidrio queda como un frosted glass: solo desenfoque (blur) con tinte, sin curvar ni deformar " +
            "el fondo en los bordes. Gasta bastante menos porque no corre el shader de refraccion. Solo se nota " +
            "con el interruptor Liquid Glass de Eclipse encendido."
    )

    val thinRim by booleanOption(
        key = "thinRim",
        default = false,
        title = "Borde fino parejo (estilo Bitchord)",
        description = "Cambia el borde brillante del vidrio (que brilla mas de un lado) por una linea fina y pareja en todo " +
            "el contorno, como el vidrio de Bitchord. Solo se nota con el interruptor Liquid Glass de Eclipse encendido."
    )

    val rimStrength by stringOption(
        key = "rimStrength",
        default = "35",
        title = "Fuerza del borde fino (%)",
        description = "Solo con Borde fino parejo. Numero de 5 a 100: mas alto, borde mas visible. Por defecto 35."
    )

    val blurPercent by stringOption(
        key = "blurPercent",
        default = "60",
        title = "Blur del vidrio (%)",
        description = "Cuanto desenfoque tiene el vidrio, en % del original de Eclipse. Numero de 10 a 300. Por defecto 60 " +
            "(liviano). Sube a 100 o mas para parecerte a Bitchord; gasta mas bateria."
    )

    val darkenPercent by stringOption(
        key = "darkenPercent",
        default = "0",
        title = "Oscurecer el vidrio (%)",
        description = "Pone una trama algo oscura detras del vidrio (minireproductor, barra inferior...). Numero de 0 a 40: " +
            "0 = sin cambio, 8 a 12 = un poco oscuro. Ayuda a leer el texto sobre portadas claras."
    )

    val tintPercent by stringOption(
        key = "tintPercent",
        default = "0",
        title = "Capa de color lisa (%)",
        description = "Pone una capa de color translucida y lisa sobre el vidrio (se mezcla lo de atras con ese color). " +
            "Numero de 0 a 80: 0 = apagada, 25 a 35 = capa media. Mas alto = mas liso pero pasa menos color. " +
            "Mejor con un blur de 100 o mas."
    )

    val tintColor by stringOption(
        key = "tintColor",
        default = "14181F",
        title = "Color de la capa (RRGGBB)",
        description = "Color de la capa en hexadecimal de 6 letras/numeros, sin #. Por defecto 14181F (azul casi negro)."
    )

    execute {
        // ---------------------------------------------------------------- A) sin dispersion: da2.E
        val da2 = mutableClassDefBy(classDefBy("Lda2;"))
        val shaderMethod = da2.methods.firstOrNull {
            it.name == "E" && it.parameterTypes.size == 4 && it.parameterTypes[0].toString() == "Lzc2;"
        } ?: error("No se encontro da2.E")

        val ins = (shaderMethod.implementation ?: error("da2.E sin codigo")).instructions.toList()

        fun str(i: Int): String? =
            if (ins[i].opcode == Opcode.CONST_STRING)
                (((ins[i] as ReferenceInstruction).reference) as? StringReference)?.string
            else null

        val shaderIdx = ins.indices.filter { str(it) == "Refraction" }
        if (shaderIdx.size != 1) error("da2.E: se esperaba un solo const-string \"Refraction\" (hay ${shaderIdx.size})")
        val ifIdx = shaderIdx[0] - 1
        if (ifIdx < 0 || ins[ifIdx].opcode != Opcode.IF_NEZ) error("da2.E: falta if-nez antes de \"Refraction\"")
        if (ins.indices.count { str(it) == "RefractionWithDispersion" } != 1) error("da2.E: falta \"RefractionWithDispersion\"")

        val flagReg = (ins[ifIdx] as OneRegisterInstruction).registerA
        if (flagReg > 15) error("da2.E: registro del flag fuera de v0..v15 (v$flagReg)")
        // El if-nez no debe ser destino de un salto: la instruccion anterior debe ser secuencial (no goto/return/if).
        val prev = ins[ifIdx - 1].opcode
        if (prev == Opcode.GOTO || prev == Opcode.GOTO_16 || prev == Opcode.GOTO_32 || prev == Opcode.RETURN_VOID)
            error("da2.E: instruccion previa al if-nez no es secuencial ($prev)")

        // ---------------------------------------------------------------- B) blur al 60%: du9.i
        val du9 = mutableClassDefBy(classDefBy("Ldu9;"))
        val blurMethod = du9.methods.firstOrNull {
            it.name == "i" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0].toString() == "Lzc2;" && it.parameterTypes[1].toString() == "F"
        } ?: error("No se encontro du9.i(zc2, F)")

        val blurImpl = blurMethod.implementation ?: error("du9.i sin codigo")
        if (blurImpl.registerCount != 5) error("du9.i: se esperaban 5 registros (hay ${blurImpl.registerCount})")
        val blurIns = blurImpl.instructions.toList()
        if (blurIns[0].opcode != Opcode.INVOKE_VIRTUAL) error("du9.i: la primera instruccion no es invoke-virtual")
        if (blurIns.none { it.opcode == Opcode.NEW_INSTANCE }) error("du9.i: no se ve la creacion del efecto de blur (nm0)")

        // Las dos comprobaciones de arriba se hacen ANTES de tocar nada: si alguna falla, no se modifica ninguna.
        if (frosted == true) {
            if (ins[0].opcode != Opcode.MOVE_OBJECT_FROM16) error("da2.E: la primera instruccion no es move-object/from16")
            if (shaderMethod.returnType != "V") error("da2.E: no devuelve void")
            shaderMethod.addInstructions(0, "return-void")
        } else {
            shaderMethod.addInstructions(
                ifIdx,
                """
                    const/4 v$flagReg, 0x0
                """
            )
        }
        val rimPct = (rimStrength ?: "35").trim().toIntOrNull()?.takeIf { it in 5..100 }
            ?: error("Fuerza del borde: pon un numero de 5 a 100")
        val blurPct = (blurPercent ?: "60").trim().toIntOrNull()?.takeIf { it in 10..300 }
            ?: error("Blur: pon un numero de 10 a 300")
        val blurFactor = java.lang.Float.floatToIntBits(blurPct / 100f)

        val darkPct = (darkenPercent ?: "0").trim().toIntOrNull()?.takeIf { it in 0..40 }
            ?: error("Oscurecer: pon un numero de 0 a 40")
        if (darkPct > 0) {
            val ka1 = mutableClassDefBy(classDefBy("Lka1;"))
            val tintMethod = ka1.methods.firstOrNull {
                it.name == "a" && it.returnType == "Lpa1;" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0].toString() == "F" && it.parameterTypes[1].toString() == "F"
            } ?: error("No se encontro ka1.a(F, F)")
            val tintImpl = tintMethod.implementation ?: error("ka1.a sin codigo")
            if (tintImpl.registerCount != 11) error("ka1.a: se esperaban 11 registros (hay ${tintImpl.registerCount})")
            if (tintImpl.instructions.first().opcode != Opcode.CONST_HIGH16) error("ka1.a: la primera instruccion no es const/high16")
            val p0 = tintImpl.registerCount - 2
            val darkBits = java.lang.Float.floatToIntBits(-darkPct / 100f)
            tintMethod.addInstructions(
                0,
                """
                    const v0, 0x${Integer.toHexString(darkBits)}
                    add-float/2addr v$p0, v0
                """
            )
        }

        val tintPct = (tintPercent ?: "0").trim().toIntOrNull()?.takeIf { it in 0..80 }
            ?: error("Capa de color: pon un numero de 0 a 80")
        val tintRgb = (tintColor ?: "14181F").trim().removePrefix("#").takeIf { Regex("[0-9a-fA-F]{6}").matches(it) }
            ?.toInt(16) ?: error("Color de la capa: pon 6 letras/numeros hexadecimales, por ejemplo 14181F")
        if (tintPct > 0) {
            val ka1t = mutableClassDefBy(classDefBy("Lka1;"))
            val mixMethod = ka1t.methods.firstOrNull {
                it.name == "a" && it.returnType == "Lpa1;" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0].toString() == "F" && it.parameterTypes[1].toString() == "F"
            } ?: error("No se encontro ka1.a(F, F)")
            val mixIns = (mixMethod.implementation ?: error("ka1.a sin codigo")).instructions.toList()
            if ((mixMethod.implementation!!).registerCount != 11) error("ka1.a: se esperaban 11 registros")
            if (mixIns.any { it.opcode == Opcode.IF_EQZ || it.opcode == Opcode.IF_NEZ || it.opcode == Opcode.GOTO }) error("ka1.a: ahora tiene saltos")
            val newIdx = mixIns.indexOfFirst {
                it.opcode == Opcode.NEW_INSTANCE &&
                    ((it as ReferenceInstruction).reference.toString() == "Lpa1;")
            }
            if (newIdx < 0) error("ka1.a: no se encontro new-instance Lpa1;")
            val arrIns = mixIns[newIdx + 1]
            if (arrIns.opcode != Opcode.INVOKE_DIRECT) error("ka1.a: se esperaba invoke-direct tras new-instance")
            val alphaBits = java.lang.Float.floatToIntBits(tintPct / 100f)
            mixMethod.addInstructions(
                newIdx,
                """
                    const v0, 0x${Integer.toHexString(alphaBits)}
                    const v1, 0x${Integer.toHexString(tintRgb)}
                    invoke-static {v7, v0, v1}, Lapp/eclipse/extension/player/GlassTint;->mix([FFI)V
                """
            )
        }

        if (thinRim == true) {
            val intensity = String.format(java.util.Locale.US, "%.3f", rimPct / 100f)
            for (cn in listOf("Lqd3;", "Lod3;")) {
                val rim = mutableClassDefBy(classDefBy(cn))
                val rimMethod = rim.methods.firstOrNull {
                    it.name == "b" && it.returnType == "Llp;" && it.parameterTypes.size == 3 &&
                        it.parameterTypes[0].toString() == "Lad4;"
                } ?: error("No se encontro $cn.b(ad4, ty7, mh7)")
                val rimIns = (rimMethod.implementation ?: error("$cn.b sin codigo")).instructions.toList()
                val srcIdx = rimIns.indices.filter { i ->
                    rimIns[i].opcode == Opcode.CONST_STRING &&
                        ((rimIns[i] as ReferenceInstruction).reference as? StringReference)?.string
                            ?.contains("float intensity = pow(abs(d), falloff);") == true
                }
                if (srcIdx.size != 1) error("$cn.b: se esperaba un solo shader con la intensidad (hay ${srcIdx.size})")
                val at = srcIdx[0]
                val reg = (rimIns[at] as OneRegisterInstruction).registerA
                if (reg > 15) error("$cn.b: registro del shader fuera de v0..v15 (v$reg)")
                var src = ((rimIns[at] as ReferenceInstruction).reference as StringReference).string
                src = src.replace(
                    "float intensity = pow(abs(d), falloff);",
                    "float intensity = $intensity + 0.0 * falloff + 0.0 * angle;"
                )
                if (cn == "Lod3;") {
                    if (!src.contains("float t = step(0.0, d);")) error("od3.b: falta la linea de t")
                    src = src.replace("float t = step(0.0, d);", "float t = 1.0;")
                }
                val esc = src.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\t", "\\t")
                // Se agrega justo despues del const-string original: sobreescribe el mismo registro (sin quitar nada).
                rimMethod.addInstructions(at + 1, "const-string v$reg, \"$esc\"")
            }
        }
        blurMethod.addInstructions(
            0,
            """
                const v0, 0x${Integer.toHexString(blurFactor)}
                mul-float/2addr v4, v0
            """
        )
    }
}
