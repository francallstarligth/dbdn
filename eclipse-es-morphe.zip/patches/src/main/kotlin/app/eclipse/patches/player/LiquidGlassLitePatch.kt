package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/**
 * Liquid glass de Eclipse 0.6.47: `da2.E(zc2, F, F, I)` arma el shader (AGSL) de la lente. Un flag de la lente (bit 8 de
 * el ultimo parametro -> registro v6) elige entre dos shaders: "Refraction" (1 lectura de la imagen por pixel) y
 * "RefractionWithDispersion" (7 lecturas por pixel en el borde, efecto arcoiris). Despues, `if-eqz v6` tambien decide si
 * se fija el uniform `chromaticAberration`.
 *
 * Arreglo: justo antes del `if-nez v6` que elige el shader se fuerza v6 = 0, asi siempre sale "Refraction" y no se
 * fija chromaticAberration (el shader sin dispersion no lo tiene). Un solo gancho, un registro.
 */
@Suppress("unused")
val liquidGlassLitePatch = bytecodePatch(
    name = "Liquid glass liviano (sin dispersion)",
    description = "Apaga la dispersion de color (arcoiris) en los bordes del liquid glass. El vidrio sigue " +
        "curvando el fondo, pero el telefono hace mucho menos trabajo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val da2 = mutableClassDefBy(classDefBy("Lda2;"))
        val method = da2.methods.firstOrNull {
            it.name == "E" && it.parameterTypes.size == 4 && it.parameterTypes[0].toString() == "Lzc2;"
        } ?: error("No se encontro da2.E")

        val ins = (method.implementation ?: error("da2.E sin codigo")).instructions.toList()

        fun str(i: Int): String? =
            if (ins[i].opcode == Opcode.CONST_STRING)
                (((ins[i] as ReferenceInstruction).reference) as? StringReference)?.string
            else null

        val shaderIdx = ins.indices.filter { str(it) == "Refraction" }
        if (shaderIdx.size != 1) error("da2.E: se esperaba un solo const-string \"Refraction\" (hay ${shaderIdx.size})")
        val ifIdx = shaderIdx[0] - 1
        if (ifIdx < 0 || ins[ifIdx].opcode != Opcode.IF_NEZ) error("da2.E: falta if-nez antes de \"Refraction\"")
        if (ins.indices.count { str(it) == "RefractionWithDispersion" } != 1) error("da2.E: falta \"RefractionWithDispersion\"")

        val flagReg = (ins[ifIdx] as OneRegisterInstruction).registerA
        if (flagReg > 15) error("da2.E: registro del flag fuera de v0..v15 (v$flagReg)")
        // El if-nez no debe ser destino de un salto: la instruccion anterior debe ser secuencial (no goto/return/if).
        val prev = ins[ifIdx - 1].opcode
        if (prev == Opcode.GOTO || prev == Opcode.GOTO_16 || prev == Opcode.GOTO_32 || prev == Opcode.RETURN_VOID)
            error("da2.E: instruccion previa al if-nez no es secuencial ($prev)")

        method.addInstructions(
            ifIdx,
            """
                const/4 v$flagReg, 0x0
            """
        )
    }
}
