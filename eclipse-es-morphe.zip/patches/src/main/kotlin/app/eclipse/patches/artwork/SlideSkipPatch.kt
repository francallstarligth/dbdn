package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"

/**
 * v0.20.42 (SIN COMPILAR / SIN PROBAR). Parche aparte (se puede desmarcar). Al presionar los botones Siguiente / Anterior
 * del reproductor, la portada nitida y su reflejo se deslizan (la vieja sale hacia un lado y la nueva entra pegada).
 * El trabajo esta en PrevCover (SlideDrawable); este parche solo avisa cuando se pulsa Siguiente/Anterior:
 * kj6.s(lb4, dw0) es el ejecutor de acciones de las capas (lb4.NEXT / lb4.PREVIOUS). El gancho va justo despues de
 * `check-cast p1, Llb4;` y pasa la accion y la capa; PrevCover ignora el caso en que la capa es la portada
 * (arrastre con el dedo: ahi Eclipse ya tiene su propio deslizamiento).
 */
@Suppress("unused")
val slideSkipPatch = bytecodePatch(
    name = "Cambio de cancion: deslizar la portada",
    description = "Al cambiar de cancion (botones o sola), la portada y su reflejo se deslizan hacia un lado y entra la nueva, sin nota ni fundido " +
        "(el fondo de toda la pantalla se queda). Necesita 'Cambio de cancion: mantener la imagen anterior'. Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(previousCoverPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val kj6 = mutableClassDefBy(classDefBy("Lkj6;"))
        val s = kj6.methods.singleOrNull {
            it.name == "s" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0] == "Ljava/lang/Object;" && it.parameterTypes[1] == "Ljava/lang/Object;"
        } ?: error("No se encontro kj6.s(Object, Object)")
        val impl = s.implementation ?: error("kj6.s sin implementacion")
        val ins = impl.instructions.toList()
        val cc = ins.indices.firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
            ins[i].opcode == Opcode.CHECK_CAST && r != null && r.type == "Llb4;"
        } ?: error("kj6.s: no se encontro check-cast Llb4;")
        val regs = impl.registerCount
        val p1 = regs - 2
        val p2 = regs - 1
        if (p1 > 15 || p2 > 15) error("kj6.s: registros altos (v$p1, v$p2)")
        s.addInstructions(
            cc + 1,
            "invoke-static {v$p1, v$p2}, $EXT->onSkip(Ljava/lang/Object;Ljava/lang/Object;)V"
        )
    }
}
