package app.eclipse.patches.spotify

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Texto del log de Eclipse justo cuando NO hay portada animada (rama :cond_19 de qf2.a en 0.6.47). */
private const val MARKER = "pick: no animated artwork found for '"

private fun smaliString(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"")

@Suppress("unused")
val spotifyCanvasPatch = bytecodePatch(
    name = "Spotify Canvas",
    description = "Usa el Canvas (video vertical) de Spotify como portada animada cuando Eclipse no tiene una. " +
        "Uso personal: necesita la cookie sp_dc de tu cuenta y Spotify podria restringirla.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val spdc by stringOption(
        key = "spdc",
        title = "Cookie sp_dc de Spotify",
        description = "Valor de la cookie sp_dc de open.spotify.com (sesion iniciada). Queda guardada dentro del APK.",
        required = true,
        validator = { it != null && it.trim().length >= 20 }
    )

    execute {
        val cookie = (spdc ?: error("Falta la opcion spdc")).trim().removePrefix("sp_dc=")

        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.47?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val strIndex = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (strIndex < 1) continue

            // Instruccion anterior = new-instance StringBuilder (inicio del bloque "sin portada animada").
            val insertIndex = strIndex - 1
            if (method.getInstruction(insertIndex).opcode != Opcode.NEW_INSTANCE) {
                error("Estructura inesperada antes del marcador en ${method.name}")
            }

            method.addInstructionsWithLabels(
                insertIndex,
                """
                    invoke-virtual {v1}, Lcom/eclipse/android/data/models/Song;->getArtist()Ljava/lang/String;
                    move-result-object v2
                    invoke-virtual {v1}, Lcom/eclipse/android/data/models/Song;->getDuration()I
                    move-result v3
                    const-string v4, "${smaliString(cookie)}"
                    invoke-static {v0, v2, v3, v4}, Lapp/eclipse/extension/spotify/SpotifyCanvas;->lookup(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Ljava/lang/String;
                    move-result-object v2
                    if-eqz v2, :orig
                    new-instance v3, Lrf2;
                    sget-object v4, Lmf2;->TidalAnimatedArtwork:Lmf2;
                    const-string v5, "spotify:"
                    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v5
                    invoke-direct {v3, v4, v2, v5}, Lrf2;-><init>(Lmf2;Ljava/lang/String;Ljava/lang/String;)V
                    return-object v3
                """,
                ExternalLabel("orig", method.getInstruction(insertIndex))
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el gancho de Spotify Canvas")
    }
}
