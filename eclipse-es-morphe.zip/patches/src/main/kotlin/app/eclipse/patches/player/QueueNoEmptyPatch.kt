package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val KEEP = "Lapp/eclipse/extension/player/QueueKeep;"

/**
 * v0.20.232 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Arregla el parpadeo "Nada a continuacion" al cambiar Letra<->Cola:
 * el panel de la Cola se recrea y su lista (sd9, `remember` dentro de t50.m) nace vacia hasta que corre t50.y.
 *  - Final de t50.y(pu7, sd9, j16): QueueKeep.guardar(sd9) guarda una copia del contenido.
 *  - Tras `new sd9()` + `<init>` en t50.m: QueueKeep.precargar(sd9) la copia a la lista nueva.
 */
@Suppress("unused")
val queueNoEmptyPatch = bytecodePatch(
    name = "Cola: no arrancar vacia",
    description = "Evita que el cartel \"Nada a continuacion\" parpadee al cambiar entre Letra y Cola: la lista de la Cola " +
        "recreada empieza con el contenido anterior en vez de vacia. Si la cola esta vacia de verdad, el cartel sale igual.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val t50 = mutableClassDefBy(classDefBy("Lt50;"))

        // 1) t50.y: guardar la lista llena justo antes del return-void.
        val y = t50.methods.singleOrNull {
            it.name == "y" && it.returnType == "V" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0] == "Lpu7;" && it.parameterTypes[1] == "Lsd9;"
        } ?: error("Cola: no se encontro t50.y (version de Eclipse distinta de 0.6.61?)")
        val yImpl = y.implementation ?: error("Cola: t50.y sin codigo")
        val retAt = yImpl.instructions.indexOfLast { it.opcode == Opcode.RETURN_VOID }
        if (retAt < 0) error("Cola: t50.y sin return-void")
        y.addInstructions(retAt, "invoke-static {p1}, $KEEP->guardar(Ljava/lang/Object;)V")

        // 2) t50.m: tras el unico `invoke-direct {vX}, Lsd9;-><init>()V`, precargar.
        val m = t50.methods.singleOrNull {
            it.name == "m" && it.returnType == "V" && it.parameterTypes.size == 9 && it.parameterTypes[0] == "J"
        } ?: error("Cola: no se encontro t50.m")
        val mImpl = m.implementation ?: error("Cola: t50.m sin codigo")
        val inits = mImpl.instructions.withIndex().filter { (_, ins) ->
            ins.opcode == Opcode.INVOKE_DIRECT &&
                ((ins as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lsd9;" && it.name == "<init>" && it.parameterTypes.isEmpty()
                } == true
        }
        if (inits.size != 1) error("Cola: se esperaba 1 `new sd9()` en t50.m y hay ${inits.size}")
        val (initAt, initIns) = inits.single()
        val reg = (initIns as FiveRegisterInstruction).registerC
        if (reg > 15) error("Cola: registro $reg fuera de rango para invoke-static")
        m.addInstructions(initAt + 1, "invoke-static {v$reg}, $KEEP->precargar(Ljava/lang/Object;)V")
    }
}
