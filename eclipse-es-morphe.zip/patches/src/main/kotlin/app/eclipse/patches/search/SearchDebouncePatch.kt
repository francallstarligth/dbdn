package app.eclipse.patches.search

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.426 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Busqueda mientras escribes: `Lz59;->u(String)` (SearchViewModel, texto cambiado) cancela el trabajo
 * anterior y lanza una corrutina `Lxz6` (caso 24) que hace `delay(500)` (`Lg22;->Q(J Ltz1;)`) y luego `Lz59;->b(String)` (la busqueda).
 * Este parche cambia ese 500 por 200 ms. Solo toca una constante; no cambia nada mas (el 350 de otro caso de Lxz6 queda igual).
 */
@Suppress("unused")
val searchDebouncePatch = bytecodePatch(
    name = "Busqueda: menos espera al escribir",
    description = "La busqueda espera 500 ms sin que escribas antes de empezar; con este parche espera 200 ms. No cambia la velocidad del servidor, solo quita espera de la app.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lxz6;"))
        var done = 0
        for (m in cls.methods) {
            val impl = m.implementation ?: continue
            val ins = impl.instructions.toList()
            for (i in ins.indices) {
                val x = ins[i]
                if (x.opcode != Opcode.CONST_WIDE_16 || (x as WideLiteralInstruction).wideLiteral != 500L) continue
                val hit = (i + 1..minOf(i + 12, ins.size - 1)).any { j ->
                    ins[j].opcode == Opcode.INVOKE_STATIC &&
                        ((ins[j] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                            r.definingClass == "Lz59;" && r.name == "b"
                        } == true
                }
                if (!hit) continue
                val reg = (x as OneRegisterInstruction).registerA
                m.replaceInstruction(i, "const-wide/16 v$reg, 0xc8")
                done++
            }
        }
        if (done != 1) error("Busqueda: se esperaba 1 'delay(500)' antes de Lz59.b en Lxz6 y hay $done (version distinta de 0.6.75?)")
    }
}
