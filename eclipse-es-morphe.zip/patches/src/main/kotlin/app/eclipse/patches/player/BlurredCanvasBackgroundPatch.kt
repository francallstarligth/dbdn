package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/** Clave de grupo de Compose propia (ASCII "CNVS"), para que el video no choque con los grupos de Eclipse. */
private const val GROUP_KEY = "0x434e5653"

@Suppress("unused")
val blurredCanvasBackgroundPatch = bytecodePatch(
    name = "Custom: Canvas en el fondo borroso",
    description = "En el reproductor Custom, la capa \"Blurred Cover\" solo muestra la portada borrosa. Con este parche, " +
        "si la cancion tiene portada animada (Canvas), esa capa tambien reproduce el video (sin sonido, en bucle) " +
        "y se ve borroso detras, como en el Eclipse oficial.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // xi6.e(dw0, float, float, ow0, boolean, ki1, int): capa "Blurred Cover" del Custom. Dibuja la portada con
        // by9.c dentro de una caja con blur. Justo despues de ese by9.c (y de mover el composer), antes de cerrar su
        // grupo, se agrega el video de ow0.w (animatedArtworkUrl) con xi6.h, igual que hace di6.b con la portada nitida.
        val xi6 = mutableClassDefBy(classDefBy("Lxi6;"))
        val method = xi6.methods.firstOrNull { m ->
            m.name == "e" && m.returnType == "V" && m.parameterTypes.map { it.toString() } ==
                listOf("Ldw0;", "F", "F", "Low0;", "Z", "Lki1;", "I")
        } ?: error("No se encontro xi6.e (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("xi6.e sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference
            ins is RegisterRangeInstruction && ref != null && ref.definingClass == "Lby9;" && ref.name == "c" &&
                ins.registerCount == 11
        } ?: error("xi6.e: no se encontro by9.c(...)")

        // Lo que sigue debe ser: move-object/from16 vC, vX (el composer) y luego qi1.q(Z) que cierra el grupo.
        val mv = list.getOrNull(callIdx + 1) ?: error("xi6.e: fin inesperado")
        if (mv.opcode != Opcode.MOVE_OBJECT_FROM16) error("xi6.e: se esperaba move-object/from16 tras by9.c")
        val nextRef = (list.getOrNull(callIdx + 2) as? ReferenceInstruction)?.reference as? MethodReference
        if (nextRef == null || nextRef.definingClass != "Lqi1;" || nextRef.name != "q") {
            error("xi6.e: se esperaba qi1.q(Z) tras by9.c")
        }
        val composer = (mv as OneRegisterInstruction).registerA
        if (composer > 8) error("xi6.e: el composer esta en v$composer (se esperaba v8 o menos)")

        // v9..v12 estan libres aqui (eran argumentos de by9.c); v0 (true), v4 (false) y el composer no se tocan.
        // p0 = dw0, p3 = ow0.
        method.addInstructionsWithLabels(
            callIdx + 2,
            """
                move-object/from16 v9, p3
                if-eqz v9, :cnvs_skip
                iget-object v9, v9, Low0;->w:Ljava/lang/String;
                if-eqz v9, :cnvs_skip
                move-object/from16 v10, p0
                invoke-static {v10}, Lhj6;->j(Ldw0;)Z
                move-result v10
                if-eqz v10, :cnvs_skip
                const v11, $GROUP_KEY
                invoke-virtual {v$composer, v11}, Lqi1;->c0(I)V
                move-object/from16 v10, p3
                iget-boolean v10, v10, Low0;->b:Z
                sget-object v11, Ljh5;->q:Ljh5;
                const/high16 v12, 0x3f800000    # 1.0f
                invoke-static {v11, v12}, Lg48;->e(Lmh5;F)Lmh5;
                move-result-object v11
                const/16 v12, 0x180
                invoke-static {v9, v10, v11, v$composer, v12}, Lxi6;->h(Ljava/lang/String;ZLmh5;Lki1;I)V
                const/4 v11, 0x0
                invoke-virtual {v$composer, v11}, Lqi1;->q(Z)V
                :cnvs_skip
                nop
            """
        )
    }
}
