package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val POP = "Lapp/eclipse/extension/player/MiniPop;"

/**
 * v0.20.364: ya no es un parche suelto; lo llama "Animaciones fluidas" (opcion miniPop).
 * v0.20.363 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). El mini reproductor ya hace un "pop" (escala 0.9 -> 1.0 con el movimiento del skin)
 * al deslizar para siguiente/anterior (`Lis9.invoke` lanza `Ljs9` modo 1 y llama `Lzr9.b(accion)`), pero al tocar el BOTON cambia de golpe.
 * (1) `Lis9.<init>` (params: v1 Map, v2 Lo12 scope, v3 Lzr9, v4 Lqt Animatable, v5 Lrs9 SkinMotion): tras el ultimo `iput-object v5, v0, Lis9;->C`
 *     -> `MiniPop.register(v2, v4, v5)` (v4/v5 se sobrescriben dos instrucciones despues, por eso va justo ahi).
 * (2) `Les9.a` (lambda de toque de capa del skin; modo 1 = `Lzr9.b(accion)`; v1 = accion): justo DESPUES de esa llamada
 *     -> `MiniPop.onAction(v1)`, que para "next"/"previous" lanza el mismo `Ljs9`. El deslizar no pasa por Les9, asi que no se duplica.
 */
@Suppress("unused")
val miniPopPatch = bytecodePatch(
    description = "Al tocar siguiente o anterior en el mini reproductor, hace el mismo efecto que al deslizar: se achica un poco y vuelve con el resorte del skin.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (2) primero? no: son clases distintas, el orden da igual.
        run {
            val cls = mutableClassDefBy(classDefBy("Les9;"))
            val m = cls.methods.singleOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
                ?: error("Pop del mini: no se encontro Les9.a")
            val ins = (m.implementation ?: error("Pop del mini: Les9.a sin codigo")).instructions.toList()
            val at = ins.indices.filter { i ->
                ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                        it.definingClass == "Lzr9;" && it.name == "b" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/String;")
                    } == true
            }
            if (at.size != 1) error("Pop del mini: se esperaba 1 llamada a Lzr9.b en Les9.a y hay ${at.size}")
            m.addInstructions(
                at[0] + 1,
                """
                invoke-static {v1}, $POP->onAction(Ljava/lang/String;)V
                """
            )
        }

        // (1) registrar scope / Animatable / movimiento
        run {
            val cls = mutableClassDefBy(classDefBy("Lis9;"))
            val m = cls.methods.singleOrNull { it.name == "<init>" }
                ?: error("Pop del mini: no se encontro Lis9.<init>")
            val ins = (m.implementation ?: error("Pop del mini: Lis9.<init> sin codigo")).instructions.toList()
            val at = ins.indices.filter { i ->
                ins[i].opcode == Opcode.IPUT_OBJECT &&
                    ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let {
                        it.definingClass == "Lis9;" && it.name == "C" && it.type == "Lrs9;"
                    } == true
            }
            if (at.size != 1) error("Pop del mini: se esperaba 1 'iput Lis9.C' y hay ${at.size}")
            m.addInstructions(
                at[0] + 1,
                """
                invoke-static {v2, v4, v5}, $POP->register(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
                """
            )
        }
    }
}
