package app.eclipse.patches.tidal

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Identifica la clase qf2 (mismo texto que usan los otros parches). */
private const val MARKER = "pick: no animated artwork found for '"

/** Texto de c19.a (el que busca el video de Tidal): identifica la clase c19. */
private const val TIDAL_LOG = "Animated artwork available for album "

private const val ALBUM_KEY = "tidal_album:"

private const val HELPER = "Lapp/eclipse/extension/tidal/IsrcAlbum;"

private fun ReferenceInstructionString(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction): String? =
    if (ins.opcode == Opcode.CONST_STRING) ((ins as ReferenceInstruction).reference as StringReference).string else null

@Suppress("unused")
val tidalLibraryArtworkPatch = bytecodePatch(
    name = "Tidal: portadas en biblioteca",
    description = "Arregla que las portadas animadas de Tidal no se vean en canciones agregadas a tu biblioteca " +
        "o playlists: Eclipse las descarga pero luego no las encuentra (busca el album con un ID que esas " +
        "canciones no tienen). Se recuerda el album por el ISRC de la cancion.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---------------------------------------------------------------- ESCRITOR: c19.a(Song, Continuation)
        val writerClass = classDefByStrings(TIDAL_LOG).firstOrNull()
            ?: error("No se encontro la clase que descarga la portada de Tidal (c19)")
        val writerMutable = mutableClassDefBy(writerClass)
        val writer = writerMutable.methods.firstOrNull { m ->
            m.returnType == "Ljava/lang/Object;" &&
                (m.implementation?.instructions?.any { ReferenceInstructionString(it) == ALBUM_KEY } == true)
        } ?: error("No se encontro el metodo que descarga la portada de Tidal")

        val wInstr = writer.implementation!!.instructions.toList()
        val wStr = wInstr.indexOfFirst { ReferenceInstructionString(it) == ALBUM_KEY }
        // iget-object v0, v7, Ln57;->q  (ID de album ya resuelto), justo antes de armar "tidal_album:<id>".
        val wGet = (wStr downTo 0).first { i ->
            val ins = wInstr[i]
            ins.opcode == Opcode.IGET_OBJECT &&
                ((ins as ReferenceInstruction).reference as FieldReference).name == "q"
        }
        // v0 = ID de album, v14 = Song; v2 queda libre (se reasigna enseguida).
        writer.addInstructions(
            wGet + 1,
            """
                invoke-virtual {v14}, Lcom/eclipse/android/data/models/Song;->getIsrc()Ljava/lang/String;
                move-result-object v2
                invoke-static {v2, v0}, $HELPER->put(Ljava/lang/String;Ljava/lang/Object;)V
            """
        )

        // ---------------------------------------------------------------- LECTOR: qf2.e(c19, Song, nr)
        val readerClass = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.47?)")
        val readerMutable = mutableClassDefBy(readerClass)
        val reader = readerMutable.methods.firstOrNull { m ->
            m.returnType == "Lrf2;" && m.parameterTypes.size == 3 &&
                (m.implementation?.instructions?.any { ReferenceInstructionString(it) == ALBUM_KEY } == true)
        } ?: error("No se encontro el lector de la portada de Tidal (qf2.e)")

        val rInstr = reader.implementation!!.instructions.toList()
        // Primer if-nez del metodo = "if-nez p0, :cond_2" (ya hay clave de album): punto comun al que se salta.
        val sharedIdx = rInstr.indexOfFirst { it.opcode == Opcode.IF_NEZ }
        if (sharedIdx < 0) error("Estructura inesperada en qf2.e")

        // Solo cuando la cancion NO tiene ID de album ni de pista de Tidal (canciones agregadas) y ya
        // se conoce su album por el ISRC: se arma la clave y se salta al resto del metodo.
        // v2 debe valer null (lo usa el "return null" del final del metodo original).
        reader.addInstructionsWithLabels(
            0,
            """
                invoke-virtual {p1}, Lcom/eclipse/android/data/models/Song;->getTidalAlbumId()Ljava/lang/Integer;
                move-result-object v0
                if-nez v0, :orig
                invoke-virtual {p1}, Lcom/eclipse/android/data/models/Song;->getEffectiveTidalTrackId()Ljava/lang/Integer;
                move-result-object v0
                if-nez v0, :orig
                invoke-virtual {p1}, Lcom/eclipse/android/data/models/Song;->getIsrc()Ljava/lang/String;
                move-result-object v0
                invoke-static {v0}, $HELPER->get(Ljava/lang/String;)Ljava/lang/Integer;
                move-result-object v0
                if-eqz v0, :orig
                invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I
                move-result v0
                const-string v1, "$ALBUM_KEY"
                invoke-static {v0, v1}, Liv5;->i(ILjava/lang/String;)Ljava/lang/String;
                move-result-object p0
                const/4 v2, 0x0
                goto :shared
            """,
            ExternalLabel("orig", reader.getInstruction(0)),
            ExternalLabel("shared", reader.getInstruction(sharedIdx))
        )
    }
}
