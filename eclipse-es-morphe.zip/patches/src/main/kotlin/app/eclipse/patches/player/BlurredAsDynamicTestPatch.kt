package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val STYLE_TEST = "Lapp/eclipse/extension/artwork/StyleTest;"

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun regName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

@Suppress("unused")
val blurredAsDynamicTestPatch = bytecodePatch(
    name = "PRUEBA: Portada desenfocada se dibuja como Dynamic",
    description = "SOLO DIAGNOSTICO, no es un arreglo. Hace que el fondo \"Portada desenfocada\" use el dibujo de " +
        "\"Dynamic\" (mas oscuro) para saber si la raya a la mitad viene de esa rama. Tambien anota el estilo en el " +
        "diagnostico del portapapeles.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // di6.c(sv0, Z, Song, ki1, I): el estilo del fondo se convierte en un numero con
        // `aget vX, yh6.a, ordinal` (SOLID=1, GRADIENT=2, IMAGE=3, BLURRED=4, MESH=5, DYNAMIC=6) y luego va a un
        // packed-switch. Justo despues del aget se pasa ese numero por StyleTest.map (4 -> 6).
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val method = di6.methods.firstOrNull { m ->
            m.name == "c" && m.returnType == "V" && m.parameterTypes.map { it.toString() } ==
                listOf("Lsv0;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lki1;", "I")
        } ?: error("No se encontro di6.c (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("di6.c sin codigo")).instructions.toList()

        val sgetIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? FieldReference
            list[i].opcode == Opcode.SGET_OBJECT && ref != null && ref.definingClass == "Lyh6;" &&
                ref.name == "a" && ref.type == "[I"
        } ?: error("di6.c: no se encontro yh6.a (mapa de estilos)")

        val agetIdx = (sgetIdx + 1 until minOf(list.size, sgetIdx + 8)).firstOrNull { i ->
            list[i].opcode == Opcode.AGET
        } ?: error("di6.c: no se encontro el aget del estilo")
        val reg = (list[agetIdx] as OneRegisterInstruction).registerA
        if (reg > 15) error("di6.c: registro v$reg fuera de rango para invoke-static")

        // Que lo siguiente sea el switch del estilo usando ese mismo registro.
        val switchIdx = (agetIdx + 1 until minOf(list.size, agetIdx + 10)).firstOrNull { i ->
            list[i].opcode == Opcode.PACKED_SWITCH && (list[i] as OneRegisterInstruction).registerA == reg
        } ?: error("di6.c: el packed-switch del estilo no usa v$reg tras el aget")

        val r = regName(reg, method)
        method.addInstructions(
            agetIdx + 1,
            """
                invoke-static {$r}, $STYLE_TEST->map(I)I
                move-result $r
            """
        )
    }
}
