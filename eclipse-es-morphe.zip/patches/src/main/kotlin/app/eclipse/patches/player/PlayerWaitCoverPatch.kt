package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val ENTER = "Lapp/eclipse/extension/player/PlayerEnter;"

/**
 * v0.20.54 (SIN COMPILAR / SIN PROBAR). Al abrir el reproductor grande, la hoja se arma fuera de pantalla (PlayerEnter ya
 * la deja abajo antes de animar) y NO sube hasta que llega la portada nitida (PrevCover.coverTick) o pasan 500 ms.
 * El gancho solo enciende el interruptor PlayerEnter.waitCover (inicio de di6.q, igual que otros ganchos sin registros).
 * Necesita "Animacion: entrada del reproductor (experimento)" (de ahi sale la animacion y el gancho de la hoja).
 */
@Suppress("unused")
val playerWaitCoverPatch = bytecodePatch(
    description = "Al abrir el reproductor grande, espera (maximo medio segundo) a que la portada este lista antes de " +
        "subirlo, para que no se vea el hueco la primera vez que abres una cancion. Desmarcalo para que suba al instante.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(playerEnterAnimationPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Lmq7;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lhd7;"
        } ?: error("No se encontro mq7.q (Eclipse 0.6.70; en 0.6.55 era j87.q)")
        q.addInstructions(0, "invoke-static {}, $ENTER->enableWait()V")
    }
}
