package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val UMBRA = "Lapp/eclipse/extension/umbra/UmbraChatNative;"

/**
 * v0.20.328 (Eclipse 0.6.75, SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL): chat de Umbra tambien en la skin Native.
 *
 * Dos ganchos (verificados en el dex 75; el resto va en UmbraChatNative.java por reflexion):
 * 1) `Lkc.invoke(Object)` = lista (LazyColumn) del Inicio de Native. Justo despues del item "recently-played"
 *    (`Lh15;->y0(Lh15, String, Luk3, I)`, es decir "Playlists recientes") se llama UmbraChatNative.addCard(scope, this),
 *    que agrega un item con la tarjeta ancha de Umbra de Eclipse (`Lfy3;->e`). Al tocarla empuja `Ldn6("Umbra Chat")`
 *    en el navegador de Native (`Lxs6;->j`). Se usan los registros de la clave y de la lambda del propio y0 (ya muertos).
 * 2) `Lxv6;->i(I, Leu1, String)` = pagina de Native por nombre (la llama Lp12.F para `Ldn6`). Al inicio, si el nombre es
 *    "Umbra Chat", se pinta el chat de Eclipse (`Lgcb;->o`) y se sale. Si algo falla devuelve false y todo sigue igual.
 */
@Suppress("unused")
val umbraChatNativePatch = bytecodePatch(
    name = "Umbra: chat en la skin Native",
    description = "Agrega en el Inicio de la skin Native (entre Playlists recientes y Hechas para ti) una tarjeta " +
        "\"Umbra: Chatea o inicia el DJ\" que abre el chat de Umbra. Experimental: no se sabe si el chat funciona " +
        "fuera de la skin Eclipse. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) tarjeta en el Inicio de Native: Lkc.invoke ----
        val kc = mutableClassDefBy(classDefBy("Lkc;"))
        val inv = kc.methods.singleOrNull {
            it.name == "invoke" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro kc.invoke (Eclipse 0.6.75)")
        val ins = (inv.implementation ?: error("kc.invoke sin codigo")).instructions.toList()

        val recientes = ins.indices.filter { i ->
            ins[i].opcode == Opcode.CONST_STRING &&
                ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "recently-played"
        }
        if (recientes.size != 1) error("kc.invoke: se esperaba 1 \"recently-played\" (hay ${recientes.size})")
        var y0 = -1
        for (k in recientes[0] + 1..minOf(recientes[0] + 4, ins.size - 1)) {
            val r = (ins[k] as? ReferenceInstruction)?.reference as? MethodReference
            if (ins[k].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lh15;" && r.name == "y0") {
                y0 = k
                break
            }
        }
        if (y0 < 0) error("kc.invoke: no se encontro h15.y0 tras \"recently-played\"")
        val call = ins[y0] as FiveRegisterInstruction
        if (call.registerCount != 4) error("h15.y0: se esperaban 4 registros (hay ${call.registerCount})")
        val scope = call.registerC
        val clave = call.registerD
        if (scope > 15 || clave > 15 || scope == clave) error("h15.y0: registros inesperados v$scope/v$clave")

        // v$clave (la clave "recently-played") ya no se usa tras el y0: se reasigna antes de leerse. p0 = this (Lkc).
        inv.addInstructions(
            y0 + 1,
            """
                move-object/from16 v$clave, p0
                invoke-static {v$scope, v$clave}, $UMBRA->addCard(Ljava/lang/Object;Ljava/lang/Object;)V
            """.trimIndent()
        )

        // ---- 2) pagina "Umbra Chat": Lxv6.i(I, Leu1, String) ----
        val xv6 = mutableClassDefBy(classDefBy("Lxv6;"))
        val pag = xv6.methods.singleOrNull {
            it.name == "i" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("I", "Leu1;", "Ljava/lang/String;")
        } ?: error("No se encontro xv6.i (Eclipse 0.6.75)")
        // Al entrar todos los v* estan libres (v0 temporal); p1 = composer, p2 = nombre.
        pag.addInstructionsWithLabels(
            0,
            """
                invoke-static {p1, p2}, $UMBRA->page(Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v0
                if-eqz v0, :umbra_sigue
                return-void
                :umbra_sigue
                nop
            """.trimIndent()
        )
    }
}
