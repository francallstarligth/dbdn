package app.eclipse.patches.diag

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.441 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): prueba de tiempos al tocar una cancion (el usuario dice que tarda 6-7 s en sonar las no descargadas).
 * `Ljh0;->W(InstalledAddon, Song, String, Continuation)` es la cadena que resuelve la cancion con el addon (Tido): identidad -> ISRC -> busqueda por nombre
 * (logs "[CHAIN]" con tag AudioPlayer). Es una funcion suspendida (se re-entra al reanudar), asi que se inserta al inicio una llamada sin registros a
 * `PlayTiming.mark()`, que ignora llamadas repetidas en 20 s. No cambia nada del audio.
 */
@Suppress("unused")
val playTimingPatch = bytecodePatch(
    name = "Diagnostico: tiempos al tocar una cancion",
    description = "Prueba. Al tocar una cancion, 12 segundos despues copia al portapapeles el registro de la app con " +
        "las horas de cada paso (buscar la cancion, pedir el audio) y muestra un aviso \"Tiempos copiados\". " +
        "Pegalo en el chat. No cambia nada del audio. Desmarcalo cuando termines.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val jh0 = mutableClassDefBy(classDefBy("Ljh0;"))
        val esperados = listOf(
            "Lcom/eclipse/android/data/models/addon/InstalledAddon;",
            "Lcom/eclipse/android/data/models/Song;",
            "Ljava/lang/String;",
            "Lvz1;"
        )
        val metodo = jh0.methods.singleOrNull {
            it.name == "W" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("No se encontro jh0.W (cadena de resolucion del addon; Eclipse 0.6.75)")
        metodo.addInstructions(0, "invoke-static {}, Lapp/eclipse/extension/diag/PlayTiming;->mark()V")
    }
}
