package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.140 (SIN COMPILAR NI PROBAR). Une los 9 parches de Letras en uno, con una casilla por cada uno. Cada parche
 * original sigue igual (ya sin nombre propio, no sale en la lista) y este los ejecuta con `parche.execute(this)`.
 * Orden: letras grandes -> silabas -> brillo / colas (los que antes eran dependencias se encienden solos).
 */
@Suppress("unused")
val lyricsPatch = bytecodePatch(
    name = "Letras",
    description = "Todos los ajustes de las letras en un solo parche: letras por silaba, brillo, colas completas, " +
        "apagado suave, voz principal a la izquierda, YouLyPlus (como Mochy y por palabra) y reintentar. " +
        "Cada uno tiene su casilla en las opciones.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val pop by booleanOption(
        key = "pop",
        default = true,
        title = "Letras grandes junto al relleno",
        description = "La silaba donde va el relleno se ve mas grande y las ya cantadas bajan de tamano. Se enciende sola si usas silabas, brillo o colas."
    )

    val syllables by booleanOption(
        key = "syllables",
        default = true,
        title = "Letra silaba por silaba",
        description = "Las silabas suben suave una a una cuando les llega el relleno (como Mochy / Apple Music). Se enciende sola si usas brillo o colas."
    )

    val glow by booleanOption(
        key = "glow",
        default = true,
        title = "Brillo suave",
        description = "Las silabas que se sostienen tienen un brillo suave alrededor mientras crecen. Necesita silaba por silaba (se enciende sola)."
    )

    val tails by booleanOption(
        key = "tails",
        default = true,
        title = "Colas de letras completas",
        description = "Cuando una frase ocupa dos renglones, no corta las colas de la g, la y o la p. Necesita silaba por silaba (se enciende sola)."
    )

    val softFade by booleanOption(
        key = "softFade",
        default = true,
        title = "Apagado suave de las lineas",
        description = "La linea ya cantada y las lejanas se apagan y se achican mas despacio."
    )

    val alignLeft by booleanOption(
        key = "alignLeft",
        default = true,
        title = "Voz principal a la izquierda",
        description = "La voz principal va pegada a la izquierda y la otra voz a la derecha."
    )

    val mochy by booleanOption(
        key = "mochy",
        default = true,
        title = "YouLyPlus como Mochy",
        description = "Eclipse le pide la letra a YouLyPlus como lo hace Mochy (con duracion y artista con coma); si no llega nada, sigue como siempre."
    )

    val words by booleanOption(
        key = "words",
        default = true,
        title = "YouLyPlus por palabra",
        description = "Si no llega la letra sincronizada normal, se usa la letra con tiempos por palabra."
    )

    val retry by booleanOption(
        key = "retry",
        default = true,
        title = "Reintentar si no cargan",
        description = "Si la busqueda de letra vuelve vacia, se repite sola hasta 2 veces antes de decir que no hay letra."
    )

    execute {
        // los que antes eran dependencias: glow/tails necesitan silabas; silabas necesita letras grandes
        val runSyllables = syllables == true || glow == true || tails == true
        val runPop = pop == true || runSyllables
        if (runPop) lyricsPopPatch.execute(this)
        if (runSyllables) lyricsSyllablesPatch.execute(this)
        if (glow == true) lyricsGlowPatch.execute(this)
        if (tails == true) lyricsTailsPatch.execute(this)
        if (softFade == true) lyricsSoftFadePatch.execute(this)
        if (alignLeft == true) lyricsAlignLeftPatch.execute(this)
        if (mochy == true) lyricsPlusMochyPatch.execute(this)
        if (words == true) lyricsPlusWordsPatch.execute(this)
        if (retry == true) lyricsRetryPatch.execute(this)
    }
}
