package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val K = "Lapp/eclipse/extension/player/PaneKeep;"

/**
 * v0.20.65 (SIN COMPILAR / SIN PROBAR). Solo INSERTA llamadas (no reemplaza nada):
 * 1) qw0.d(String) (cambio de pestana), al inicio: PaneKeep.changed().
 * 2) hj6.b, panel: justo antes del `cmpg-float` que compara con la constante 0.001f (const 0x3a83126f): r = PaneKeep.w(r).
 * 3) hj6.b, contenido: la llamada `qw0.e(String)F` cuyo resultado se compara enseguida con `cmpg-float`: r = PaneKeep.w(r).
 */
@Suppress("unused")
val paneKeepPatch = bytecodePatch(
    name = "Cola: no destruir al cambiar de pestana",
    description = "Al pasar de pestana (Artwork, Letra, Cola) Eclipse destruye la pantalla de Cola o Letra y la arma otra vez " +
        "vacia (parpadeo de lista vacia y portadas grises). Este parche la mantiene armada durante el cambio, sin verse. " +
        "Desmarcalo para volver a como era.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) qw0.d ----
        val qw0 = mutableClassDefBy(classDefBy("Lqw0;"))
        val d = qw0.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0].toString() == "Ljava/lang/String;"
        } ?: error("No se encontro qw0.d(String)")
        d.addInstructions(0, "invoke-static {}, $K->changed()V")

        // ---- 2) y 3) hj6.b ----
        val hj6 = mutableClassDefBy(classDefBy("Lhj6;"))
        val b = hj6.methods.singleOrNull {
            it.name == "b" && it.returnType == "V" && it.parameterTypes.size == 7 &&
                it.parameterTypes[1].toString() == "Lqw0;"
        } ?: error("No se encontro hj6.b")
        val ins = (b.implementation ?: error("hj6.b sin codigo")).instructions.toList()

        // contenido: qw0.e(String)F + move-result + cmpg-float
        val content = ins.indices.filter { i ->
            ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                (((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lqw0;" && it.name == "e" && it.returnType == "F"
                } == true) &&
                i + 2 < ins.size && ins[i + 1].opcode == Opcode.MOVE_RESULT && ins[i + 2].opcode == Opcode.CMPG_FLOAT
        }
        if (content.size != 1) error("hj6.b: se esperaba 1 qw0.e seguido de cmpg-float (hay ${content.size})")

        // panel: const 0.001f justo antes de cmpg-float
        val panel = ins.indices.filter { i ->
            ins[i].opcode == Opcode.CONST && (ins[i] as NarrowLiteralInstruction).narrowLiteral == 0x3a83126f &&
                i + 1 < ins.size && ins[i + 1].opcode == Opcode.CMPG_FLOAT
        }
        if (panel.size != 1) error("hj6.b: se esperaba 1 const 0.001f + cmpg-float (hay ${panel.size})")

        // Se insertan de atras hacia adelante para no mover los indices.
        val sites = listOf(
            panel[0] + 1 to (ins[panel[0] + 1] as OneRegisterInstruction).registerA,
            content[0] + 2 to (ins[content[0] + 1] as OneRegisterInstruction).registerA
        ).sortedByDescending { it.first }
        for ((idx, r) in sites) {
            if (r > 15) error("hj6.b: registro fuera de rango (v$r)")
            b.addInstructions(
                idx,
                """
                    invoke-static {v$r}, $K->w(F)F
                    move-result v$r
                """
            )
        }
    }
}
