package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val Q = "Lapp/eclipse/extension/player/QueueNoFlash;"

/**
 * v0.20.67 (SIN COMPILAR / SIN PROBAR). e20.m (pantalla Cola) crea la lista t78 vacia y un LaunchedEffect (Lbb caso 0xd)
 * la llena con e20.x(yz6, t78, en5) un cuadro DESPUES. Aqui, justo antes de `Lt78;->isEmpty()Z`, se llama
 * QueueNoFlash.prefill(yz6, lista, upNext, busqueda), que ejecuta esa misma e20.x en el primer cuadro (solo si la lista
 * esta vacia y la cola real tiene canciones). Los 4 registros se leen de los `move-object/from16 v19..v22` que arman
 * `new-instance Lbb;` (args: en5 busqueda, yz6, t78, en5 upNext). Solo INSERTA; si falla se apaga solo.
 */
@Suppress("unused")
val queueFirstFramePatch = bytecodePatch(
    name = "Cola: lista llena desde el primer cuadro",
    description = "Al entrar a Cola la lista ya sale con las canciones en el primer cuadro (antes salia vacia y luego " +
        "con portadas grises). Usa los mismos datos de Eclipse, no guarda copias. Desmarcalo para volver a como era.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val e20 = mutableClassDefBy(classDefBy("Le20;"))
        val m = e20.methods.singleOrNull {
            it.name == "m" && it.returnType == "V" && it.parameterTypes.size == 9 &&
                it.parameterTypes[0].toString() == "J" &&
                it.parameterTypes[5].toString() == "Ljava/util/List;" &&
                it.parameterTypes[6].toString() == "Lki1;"
        } ?: error("No se encontro e20.m")
        val ins = (m.implementation ?: error("e20.m sin codigo")).instructions.toList()

        val bbNew = ins.indices.filter { i ->
            ins[i].opcode == Opcode.NEW_INSTANCE &&
                ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lbb;"
        }
        if (bbNew.size != 1) error("e20.m: se esperaba 1 new-instance Lbb; (hay ${bbNew.size})")
        val ib = bbNew[0]

        // move-object/from16 vDEST, vSRC despues del new-instance (hasta el invoke-direct/range Lbb;-><init>)
        val moves = HashMap<Int, Int>()
        var k = ib + 1
        while (k < ins.size) {
            val x = ins[k]
            if (x.opcode == Opcode.INVOKE_DIRECT_RANGE) break
            if (x.opcode == Opcode.MOVE_OBJECT_FROM16) {
                val t = x as TwoRegisterInstruction
                moves[t.registerA] = t.registerB
            }
            k++
        }
        val search = moves[19] ?: error("e20.m: falta move-object/from16 v19")
        val yz6 = moves[20] ?: error("e20.m: falta move-object/from16 v20")
        val lista = moves[21] ?: error("e20.m: falta move-object/from16 v21")
        val up = moves[22] ?: error("e20.m: falta move-object/from16 v22")

        val hits = ins.indices.filter { i ->
            i > ib && ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                (((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lt78;" && it.name == "isEmpty" && it.parameterTypes.isEmpty() && it.returnType == "Z"
                } == true)
        }
        if (hits.size != 1) error("e20.m: se esperaba 1 Lt78;->isEmpty() tras Lbb (hay ${hits.size})")
        val i = hits[0]
        if ((ins[i] as FiveRegisterInstruction).registerC != lista) error("e20.m: la lista de isEmpty no coincide (v$lista)")
        for (r in listOf(search, yz6, lista, up)) if (r > 15) error("e20.m: registro fuera de rango (v$r)")

        // e20.x(yz6, t78, en5): la 1a vez que el efecto de Eclipse intenta llenar la lista ya llena, se le da una de mentira
        val x = e20.methods.singleOrNull {
            it.name == "x" && it.returnType == "V" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0].toString() == "Lyz6;" && it.parameterTypes[1].toString() == "Lt78;"
        } ?: error("No se encontro e20.x")
        x.addInstructions(
            0,
            """
                invoke-static {p1}, $Q->target(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object p1
                check-cast p1, Lt78;
            """
        )

        m.addInstructions(i, "invoke-static {v$yz6, v$lista, v$up, v$search}, $Q->prefill(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V")
    }
}
