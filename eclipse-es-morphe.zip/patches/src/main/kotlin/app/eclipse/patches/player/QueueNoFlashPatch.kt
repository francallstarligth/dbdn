package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val Q = "Lapp/eclipse/extension/player/QueueNoFlash;"

/**
 * v0.20.62 (SIN COMPILAR / SIN PROBAR). e20.m (pantalla Cola) crea la lista de filas (t78) vacia y la llena despues;
 * mientras esta vacia dibuja "Nothing up next" (e20.j). Aqui, justo despues de `invoke-virtual {lista}, Lt78;->isEmpty()Z`
 * + `move-result r`, se inserta `invoke-static {lista, r}, QueueNoFlash->fix(Ljava/lang/Object;Z)Z` + `move-result r`.
 * Solo inserta (no reemplaza): si la extension falla, devuelve el valor original.
 */
@Suppress("unused")
val queueNoFlashPatch = bytecodePatch(
    name = "Cola: sin parpadeo de \"Nada a continuacion\"",
    description = "Al entrar a Cola no muestra un instante el mensaje \"Nada a continuacion\" mientras la lista se llena. " +
        "Si de verdad no hay canciones, el mensaje sale igual. Desmarcalo para volver a como era.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val e20 = mutableClassDefBy(classDefBy("Le20;"))
        val m = e20.methods.singleOrNull {
            it.name == "m" && it.returnType == "V" && it.parameterTypes.size == 9 &&
                it.parameterTypes[0].toString() == "J" &&
                it.parameterTypes[5].toString() == "Ljava/util/List;" &&
                it.parameterTypes[6].toString() == "Lki1;"
        } ?: error("No se encontro e20.m")
        val ins = (m.implementation ?: error("e20.m sin codigo")).instructions.toList()

        val hits = ins.indices.filter { i ->
            ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                (((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lt78;" && it.name == "isEmpty" && it.parameterTypes.isEmpty() && it.returnType == "Z"
                } == true)
        }
        if (hits.size != 1) error("e20.m: se esperaba 1 Lt78;->isEmpty() (hay ${hits.size})")
        val i = hits[0]
        if (ins[i + 1].opcode != Opcode.MOVE_RESULT) error("e20.m: falta move-result tras isEmpty")

        val lista = (ins[i] as FiveRegisterInstruction).registerC
        val res = (ins[i + 1] as OneRegisterInstruction).registerA
        if (lista > 15 || res > 15) error("e20.m: registros fuera de rango (v$lista, v$res)")

        m.addInstructions(
            i + 2,
            """
                invoke-static {v$lista, v$res}, $Q->fix(Ljava/lang/Object;Z)Z
                move-result v$res
            """
        )
    }
}
