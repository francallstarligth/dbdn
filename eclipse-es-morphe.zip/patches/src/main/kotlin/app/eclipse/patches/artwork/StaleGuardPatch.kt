package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val PREV = "Lapp/eclipse/extension/artwork/PrevCover;"

/**
 * v0.20.145 (SIN COMPILAR / SIN PROBAR). Sin nombre propio (no sale en la lista): lo ejecuta "Portadas: fundido y sin
 * parpadeo" segun su casilla. Solo enciende la guardia de `PrevCover` (`enableStaleGuard`): si la cancion cambio mientras
 * estabas en Letra, el reflejo del Canvas no usa nada de la cancion anterior (usa la portada de la actual). Sin esta
 * llamada, el codigo nuevo no hace nada y todo queda como en la v0.20.140. Gancho: inicio de di6.q (igual que lightCanvasPatch).
 */
@Suppress("unused")
val staleGuardPatch = bytecodePatch(
    description = "Interno: enciende la guardia contra la portada anterior al volver de Letra.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Lj87;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Llv6;"
        } ?: error("No se encontro j87.q (Eclipse 0.6.55)")
        q.addInstructions(0, "invoke-static {}, $PREV->enableStaleGuard()V")
    }
}
