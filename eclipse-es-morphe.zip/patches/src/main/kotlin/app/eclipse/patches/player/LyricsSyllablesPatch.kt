package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val POP = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.79 (SIN COMPILAR / SIN PROBAR). Interruptor del modo por silabas de "Letras: letras grandes junto al relleno".
 * Solo agrega, al empezar fz1.I0 (el dibujo de una fila de letra), la llamada sin registros LyricsPop.enableSyllables()
 * (mismo estilo que PlayerWaitCoverPatch). Sin este parche, LyricsPop agranda letra por letra (v0.20.76); con el, agranda la
 * silaba entera por la que va el relleno (las silabas se cortan con reglas en Syllables.java).
 */
@Suppress("unused")
val lyricsSyllablesPatch = bytecodePatch(
    description = "Las silabas suben suave una a una cuando les llega el relleno (como Mochy / Apple Music) y solo " +
        "crecen las que se sostienen un rato. Las silabas se cortan con reglas (espanol e ingles). Necesita \"Letras: letras " +
        "grandes junto al relleno\". Desmarcalo para volver a letra por letra.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(lyricsPopPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Lwz1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "I0" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljw4;")
        } ?: error("No se encontro fz1.I0 (version de Eclipse distinta de 0.6.70?)")
        e0.addInstructions(0, "invoke-static {}, $POP->enableSyllables()V")
    }
}
