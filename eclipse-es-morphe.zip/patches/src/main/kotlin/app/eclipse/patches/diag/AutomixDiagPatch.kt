package app.eclipse.patches.diag

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val DIAG = "Lapp/eclipse/extension/diag/AutomixDiag;"

private fun callOf(ins: Instruction): MethodReference? =
    (ins as? ReferenceInstruction)?.reference as? MethodReference

private fun isCall(ins: Instruction, cls: String, name: String): Boolean {
    val ref = callOf(ins) ?: return false
    return ref.definingClass == cls && ref.name == name
}

/** Texto del const-string mas cercano ANTES del indice que sea uno de [texts]; null si no hay. */
private fun nearestMarker(list: List<Instruction>, index: Int, texts: Set<String>): String? {
    for (i in index - 1 downTo maxOf(0, index - 80)) {
        val ref = (list[i] as? ReferenceInstruction)?.reference as? StringReference ?: continue
        if (ref.string in texts) return ref.string
    }
    return null
}

/**
 * Diagnostico de Automix 0.6.47 (solo lectura del smali; NO probado en el telefono):
 *  - wf0.invokeSuspend: pedido del plan al servidor (HTTP / fallo / plan listo / respuesta no lista).
 *  - ig0.a: coordinador del analisis (pedido / sin audio local / ya subido / fallo).
 *  - tf0.a: resultado de nativeAnalysisJson (analyzedBpm, beatConfidence, beats, downbeats).
 *  - tf0.b: "models unavailable".
 * Todos los ganchos se insertan ANTES de una llamada existente (no tocan etiquetas ni bloques try).
 */
@Suppress("unused")
val automixDiagPatch = bytecodePatch(
    name = "Diagnostico de Automix (temporal)",
    description = "Muestra avisos con lo que responde el plan de Automix (servidor) y el BPM que calcula el " +
        "analisis nativo. No cambia la reproduccion. Solo para diagnostico: desactivalo despues.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---------- wf0.invokeSuspend: pedido del plan ----------
        run {
            val cls = mutableClassDefBy(classDefBy("Lwf0;"))
            val method = cls.methods.firstOrNull {
                it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
            } ?: error("No se encontro wf0.invokeSuspend")
            val impl = method.implementation ?: error("wf0.invokeSuspend sin codigo")
            val list = impl.instructions.toList()

            val logW = list.indices.filter { isCall(list[it], "Landroid/util/Log;", "w") }
            val logD = list.indices.filter { isCall(list[it], "Landroid/util/Log;", "d") }
            val failed = list.indices.filter { isCall(list[it], "Lq03;", "y") }
            if (logW.size != 1 || logD.size != 2 || failed.size != 1) {
                error("wf0.invokeSuspend no tiene la forma esperada (Log.w=${logW.size}, Log.d=${logD.size}, q03.y=${failed.size})")
            }
            val markers = setOf(" tier=", " status=")
            val ready = logD.filter { nearestMarker(list, it, markers) == " tier=" }
            val notReady = logD.filter { nearestMarker(list, it, markers) == " status=" }
            if (ready.size != 1 || notReady.size != 1) error("No se distinguen los logs de plan listo / no listo")

            val hooks = listOf(
                // "plan HTTP <codigo> - ..." (v4 = codigo HTTP, int).
                logW[0] to "invoke-static {v4}, $DIAG->httpFail(I)V",
                // "plan <out>-><in> tier=.. start=.. fade=.. blocked=.." :
                // v6 = tier, v3 = blocked (Z), v9/v10 = fadeSeconds (D), v0 = sg0 -> v4 libre = rg0.d (reason).
                // 2.o aviso (planDetail): rg0 -> v4 (libre); v11..v17 libres en esta rama (v17/v18 solo se usan en la otra).
                // iget solo admite v0..v15, por eso los Double s/t pasan por v11 y se mueven a v16/v17.
                ready[0] to """
                    iget-object v4, v0, Lsg0;->b:Lrg0;
                    iget-object v4, v4, Lrg0;->d:Ljava/lang/String;
                    invoke-static {v6, v3, v9, v10, v4}, $DIAG->planReady(Ljava/lang/String;ZDLjava/lang/String;)V
                    iget-object v4, v0, Lsg0;->b:Lrg0;
                    iget-object v11, v4, Lrg0;->s:Ljava/lang/Double;
                    move-object/from16 v16, v11
                    iget-object v11, v4, Lrg0;->t:Ljava/lang/Double;
                    move-object/from16 v17, v11
                    iget-object v11, v4, Lrg0;->f:Ljava/lang/String;
                    iget-boolean v12, v4, Lrg0;->o:Z
                    iget-object v13, v4, Lrg0;->q:Ljg0;
                    iget-wide v14, v4, Lrg0;->l:D
                    invoke-static/range {v11 .. v17}, $DIAG->planDetail(Ljava/lang/String;ZLjava/lang/Object;DLjava/lang/Double;Ljava/lang/Double;)V
                """,
                // "plan <out>-><in> status=.. needs=.." : v5 = status, v6 = needs (texto con comas).
                notReady[0] to "invoke-static {v5, v6}, $DIAG->planNotReady(Ljava/lang/String;Ljava/lang/String;)V",
                // "plan failed: <mensaje>" : v0 = mensaje de la excepcion.
                failed[0] to "invoke-static {v0}, $DIAG->planFailed(Ljava/lang/String;)V"
            )
            // De atras hacia adelante: insertar no corre los indices anteriores.
            for ((index, code) in hooks.sortedByDescending { it.first }) method.addInstructions(index, code)
        }

        // ---------- ig0.a: coordinador del analisis (avisos de por que se analiza o se salta) ----------
        run {
            val cls = mutableClassDefBy(classDefBy("Lig0;"))
            val method = cls.methods.firstOrNull {
                it.name == "a" && it.parameterTypes.map { p -> p.toString() } == listOf(
                    "Lcom/eclipse/android/data/models/Song;",
                    "Lcom/eclipse/android/data/models/Song;",
                    "Landroid/net/Uri;",
                    "Lsg0;",
                    "Ld43;",
                    "Lrn1;"
                )
            } ?: error("No se encontro ig0.a")
            val impl = method.implementation ?: error("ig0.a sin codigo")
            val list = impl.instructions.toList()

            val logD = list.indices.filter { isCall(list[it], "Landroid/util/Log;", "d") }
            val logW = list.indices.filter { isCall(list[it], "Landroid/util/Log;", "w") }
            val uploaded = list.indices.filter { isCall(list[it], "Ldg0;", "D") }
            if (logD.size != 2 || logW.size != 1 || uploaded.size != 1) {
                error("ig0.a no tiene la forma esperada (Log.d=${logD.size}, Log.w=${logW.size}, dg0.D=${uploaded.size})")
            }
            val markers = setOf("analysis needed: ", " has no local audio; skipped")
            val needed = logD.filter { nearestMarker(list, it, markers) == "analysis needed: " }
            val noAudio = logD.filter { nearestMarker(list, it, markers) == " has no local audio; skipped" }
            if (needed.size != 1 || noAudio.size != 1) error("ig0.a: no se distinguen los logs de analisis")

            // dg0.D(id)Z es seguido de move-result v7 y de un if-nez: el gancho va ANTES del if-nez.
            val ifIndex = uploaded[0] + 2
            if (list[uploaded[0] + 1].opcode != Opcode.MOVE_RESULT || list[ifIndex].opcode != Opcode.IF_NEZ) {
                error("ig0.a: tras dg0.D no sigue move-result + if-nez")
            }

            val hooks = listOf(
                // v10 = "analysis needed: id1,id2" (String).
                needed[0] to "invoke-static {v10}, $DIAG->analysisNeeded(Ljava/lang/String;)V",
                // v7 = "<id> has no local audio; skipped" (String).
                noAudio[0] to "invoke-static {v7}, $DIAG->noLocalAudio(Ljava/lang/String;)V",
                // v0 = "analyze <id> failed: <mensaje>" (String).
                logW[0] to "invoke-static {v0}, $DIAG->analysisFailed(Ljava/lang/String;)V",
                // v7 = resultado de dg0.D(id) (boolean): true = ya subido, se salta.
                ifIndex to "invoke-static {v7}, $DIAG->alreadyUploaded(Z)V"
            )
            for ((index, code) in hooks.sortedByDescending { it.first }) method.addInstructions(index, code)
        }

        // ---------- tf0: analisis nativo ----------
        run {
            val cls = mutableClassDefBy(classDefBy("Ltf0;"))

            // tf0.a(Ltf0;, String id, Lcg0;, Lkg0;, Z): justo antes de tf0.c(json, id, dur, cg0), v4 = json (no nulo), v7 = id.
            val analyze = cls.methods.firstOrNull {
                it.name == "a" && it.returnType == "Ljava/lang/String;" &&
                    it.parameterTypes.map { p -> p.toString() } ==
                    listOf("Ltf0;", "Ljava/lang/String;", "Lcg0;", "Lkg0;", "Z")
            } ?: error("No se encontro tf0.a")
            val aList = (analyze.implementation ?: error("tf0.a sin codigo")).instructions.toList()
            val cCalls = aList.indices.filter { isCall(aList[it], "Ltf0;", "c") }
            if (cCalls.size != 1) error("tf0.a: se esperaba 1 llamada a tf0.c y hay ${cCalls.size}")
            analyze.addInstructions(
                cCalls[0],
                "invoke-static {v4, v7}, $DIAG->analysis(Ljava/lang/String;Ljava/lang/String;)V"
            )

            // tf0.b(...): "models unavailable: <mensaje>" ; v0 = texto del log.
            val models = cls.methods.firstOrNull {
                it.name == "b" && it.parameterTypes.map { p -> p.toString() } ==
                    listOf("Lcom/eclipse/android/data/models/Song;", "Ljava/lang/String;", "Lcg0;", "Z", "Lrn1;")
            } ?: error("No se encontro tf0.b")
            val bList = (models.implementation ?: error("tf0.b sin codigo")).instructions.toList()
            val bLogW = bList.indices.filter { isCall(bList[it], "Landroid/util/Log;", "w") }
            if (bLogW.size != 1) error("tf0.b: se esperaba 1 Log.w y hay ${bLogW.size}")
            models.addInstructions(
                bLogW[0],
                "invoke-static {v0}, $DIAG->noModels(Ljava/lang/String;)V"
            )
        }
    }
}
