package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val T = "Lapp/eclipse/extension/player/TabSwitch;"

/**
 * v0.20.63 (SIN COMPILAR / SIN PROBAR). Tres ganchos que solo INSERTAN llamadas (no reemplazan nada):
 * 1) qw0.d: justo despues del `invoke-direct Lx;-><init>` (arma la corrutina de la animacion): TabSwitch.pending().
 * 2) x (invokeSuspend, caso 0x14): despues del SEGUNDO `iget-object ..., Lqw0;->d:Ljr;` (ya se puso el avance en 0): TabSwitch.snapped().
 * 3) qw0.e(String): despues de `Number.floatValue()F` + `move-result r` (avance leido): r = TabSwitch.prog(r).
 */
@Suppress("unused")
val tabSwitchPatch = bytecodePatch(
    name = "Cambio de pestana: sin salto al inicio",
    description = "Al pasar de Artwork a Letra o Cola (y de vuelta) la pantalla nueva ya no se ve completa un instante " +
        "antes de empezar el fundido. Desmarcalo para volver a como era.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val qw0 = mutableClassDefBy(classDefBy("Lqw0;"))

        // ---- 1) qw0.d ----
        val d = qw0.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0].toString() == "Ljava/lang/String;"
        } ?: error("No se encontro qw0.d(String)")
        val dIns = (d.implementation ?: error("qw0.d sin codigo")).instructions.toList()
        // OJO: el new-instance Lx; es destino de un salto (:cond_2); se inserta DESPUES de su invoke-direct <init>, que no lo es.
        val inits = dIns.indices.filter { i ->
            dIns[i].opcode == Opcode.INVOKE_DIRECT &&
                (((dIns[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lx;" && it.name == "<init>"
                } == true)
        }
        if (inits.size != 1) error("qw0.d: se esperaba 1 invoke-direct Lx;-><init> (hay ${inits.size})")
        d.addInstructions(inits[0] + 1, "invoke-static {}, $T->pending()V")

        // ---- 3) qw0.e ----
        val e = qw0.methods.singleOrNull {
            it.name == "e" && it.returnType == "F" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0].toString() == "Ljava/lang/String;"
        } ?: error("No se encontro qw0.e(String)")
        val eIns = (e.implementation ?: error("qw0.e sin codigo")).instructions.toList()
        val fl = eIns.indices.filter { i ->
            eIns[i].opcode == Opcode.INVOKE_VIRTUAL &&
                (((eIns[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Ljava/lang/Number;" && it.name == "floatValue" && it.returnType == "F"
                } == true)
        }
        if (fl.size != 1) error("qw0.e: se esperaba 1 floatValue (hay ${fl.size})")
        val fi = fl[0]
        if (eIns[fi + 1].opcode != Opcode.MOVE_RESULT) error("qw0.e: falta move-result tras floatValue")
        val r = (eIns[fi + 1] as OneRegisterInstruction).registerA
        if (r > 15) error("qw0.e: registro fuera de rango (v$r)")
        e.addInstructions(
            fi + 2,
            """
                invoke-static {v$r}, $T->prog(F)F
                move-result v$r
            """
        )

        // ---- 2) x (invokeSuspend) ----
        val x = mutableClassDefBy(classDefBy("Lx;"))
        fun isProgGet(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction): Boolean =
            ins.opcode == Opcode.IGET_OBJECT &&
                (((ins as ReferenceInstruction).reference as? FieldReference)?.let {
                    it.definingClass == "Lqw0;" && it.name == "d" && it.type == "Ljr;"
                } == true)
        val cands = x.methods.filter { m ->
            m.implementation?.instructions?.count { isProgGet(it) } == 2
        }
        if (cands.size != 1) error("x: se esperaba 1 metodo con 2 lecturas de qw0.d (hay ${cands.size})")
        val xm = cands[0]
        val xIns = xm.implementation!!.instructions.toList()
        val gets = xIns.indices.filter { isProgGet(xIns[it]) }
        xm.addInstructions(gets[1] + 1, "invoke-static {}, $T->snapped()V")
    }
}
