package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/** v0.20.140 (SIN COMPILAR NI PROBAR). Une "Sin analitica de Google Cast" y "Sin telemetria de ONNX Runtime". */
@Suppress("unused")
val noTelemetryPatch = bytecodePatch(
    name = "Sin telemetria",
    description = "Corta el envio de datos de uso a terceros: analitica de Google Cast y telemetria de ONNX Runtime " +
        "(analisis de audio). Enviar a Chromecast y el analisis no cambian.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val cast by booleanOption(
        key = "cast",
        default = false,
        title = "Sin analitica de Google Cast",
        description = "Corta el envio de eventos de analitica del SDK de Google Cast a Google. Enviar a Chromecast sigue igual."
    )

    val onnx by booleanOption(
        key = "onnx",
        default = true,
        title = "Sin telemetria de ONNX Runtime",
        description = "Evita que la libreria de analisis de audio envie datos de uso y del dispositivo a Microsoft."
    )

    execute {
        if (cast == true) castAnalyticsOffPatch.execute(this)
        if (onnx == true) onnxTelemetryOffPatch.execute(this)
    }
}
