package app.eclipse.patches.translation

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel

private const val FREE = "Lapp/eclipse/extension/translate/FreeTranslate;"

/**
 * v0.20.161 (SIN COMPILAR / SIN PROBAR). Traduccion de letras gratis (sin clave ni cuenta de Eclipse).
 * Eclipse 0.6.57: `v95.b(Lv95; ArrayList lineas, String idioma, String proveedor): List` (estatico; p0 = jx4, p1 = lineas,
 * p2 = idioma, p3 = proveedor) hace el POST a api.eclipsemusic.app/api/lyrics/translate. El proveedor sale del ajuste
 * "translation_provider": "off" no llama, "deepl" manda "deepl", cualquier otro manda "model" (opcion "Modelo de IA").
 * Gancho al inicio: FreeTranslate.translate(lineas, idioma, proveedor); si devuelve una lista, se devuelve tal cual; si
 * devuelve null (otro proveedor o fallo), jx4.b sigue normal. v0..v5 son locales libres al inicio (el metodo usa v0 primero).
 * En la lista de ajustes, "AI model" (solo se usa en la pantalla de traduccion, rw4.g) se muestra como "Gratis (Google)"
 * por el diccionario en espanol.
 */
@Suppress("unused")
val freeTranslationPatch = bytecodePatch(
    name = "Letras: traduccion gratis (Google)",
    description = "La opcion \"Modelo de IA\" de Traduccion (Apariencia de la letra) pasa a ser \"Gratis (Google)\": traduce las " +
        "letras desde el telefono, sin clave de API ni cuenta de Eclipse. Usa un servicio no oficial de Google que puede " +
        "dejar de funcionar. DeepL no cambia.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val jx4 = mutableClassDefBy(classDefBy("Lv95;"))
        val b = jx4.methods.singleOrNull {
            it.name == "b" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Lv95;", "Ljava/util/ArrayList;", "Ljava/lang/String;", "Ljava/lang/String;") &&
                it.returnType == "Ljava/util/List;"
        } ?: error("No se encontro v95.b(v95, ArrayList, String, String) (version de Eclipse distinta de 0.6.57?)")
        b.addInstructionsWithLabels(
            0,
            """
                invoke-static {p1, p2, p3}, $FREE->translate(Ljava/util/ArrayList;Ljava/lang/String;Ljava/lang/String;)Ljava/util/List;
                move-result-object v0
                if-eqz v0, :orig
                return-object v0
            """,
            ExternalLabel("orig", b.getInstruction(0))
        )
    }
}
