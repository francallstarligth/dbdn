package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val SCALE = "Lapp/eclipse/extension/player/FluidScale;"

/**
 * v0.20.364 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Botones y tarjetas se achican al presionar.
 * `Lwf1` = ClickableSurfaceScale (scale, focusedScale, pressedScale, disabledScale, focusedDisabledScale). Los dos sitios que lo crean
 * (`Lf3c.C(F)` y `Lk3b.m`) mandan pressedScale = 1.0. `Ljf8.k` (la superficie tocable, 9 llamadores) lee `Lwf1.c` cuando esta presionada.
 * Aqui: en `Lwf1.<init>(FFFFF)V`, justo antes de `iput v3, v0, Lwf1;->c`, v3 = FluidScale.pressed(v3) (1.0 -> 0.94).
 * NO verificado: que todos los botones del cel usen esa superficie; que se vea bien con el dedo.
 */
@Suppress("unused")
val pressScalePatch = bytecodePatch(
    description = "Botones y tarjetas se achican un poco al presionarlos.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lwf1;"))
        val m = cls.methods.singleOrNull { it.name == "<init>" && it.parameterTypes.size == 5 }
            ?: error("Achicar al tocar: no se encontro Lwf1.<init>(FFFFF)")
        val ins = (m.implementation ?: error("Achicar al tocar: Lwf1.<init> sin codigo")).instructions.toList()
        val at = ins.indices.filter { i ->
            ins[i].opcode == Opcode.IPUT &&
                ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let {
                    it.definingClass == "Lwf1;" && it.name == "c" && it.type == "F"
                } == true
        }
        if (at.size != 1) error("Achicar al tocar: se esperaba 1 'iput Lwf1.c' y hay ${at.size}")
        m.addInstructions(
            at[0],
            """
            invoke-static {v3}, $SCALE->pressed(F)F
            move-result v3
            """
        )
    }
}
