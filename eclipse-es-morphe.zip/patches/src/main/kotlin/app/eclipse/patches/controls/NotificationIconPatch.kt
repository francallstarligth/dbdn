package app.eclipse.patches.controls

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.resourcePatch
import app.morphe.patcher.patch.stringOption
import java.io.File

/**
 * v0.20.267 (SIN COMPILAR NI PROBAR; luna C en dos variantes: separada o pegada). Eclipse 0.6.70. Apagado por defecto.
 *
 * Cambia el icono chico de la notificacion de reproduccion (la nota musical blanca que sale en la esquina de la
 * portada en la pantalla de bloqueo / centro de control) por una media luna maciza a la izquierda y un disco a la
 * derecha con un surco y un punto central (idea del icono de la app). Es la "luna gruesa (C)" elegida por el usuario
 * en la vista previa. Opcion "luna": "separada" (por defecto) o "pegada" (la luna casi toca el disco).
 * Geometria: arcos SVG exactos medidos de la vista previa (disco r=8,81 en un lienzo 24x24; luna del mismo radio
 * desplazada a la izquierda y recortada por un circulo de r=10,30 centrado en el disco; surco r 2,37-3,06; punto r 0,62).
 * Recursos que reemplaza (leidos en el APK 0.6.70):
 *   - ic_notification: vector 24x24 de la nota; lo usa PlaybackService (Notification.icon).
 *   - media3_notification_small_icon: PNG 192x192 por defecto de Media3 (MediaSessionService y el proveedor de notificacion).
 * Android exige una silueta de un solo color (blanco sobre transparente): el vector es blanco y su sistema lo tine.
 * v0.20.265: ya no da error si un recurso no esta en disco (media3_notification_small_icon no aparecia bajo Morphe): se
 * reemplaza/borra el que haya y siempre se crea el vector en res/drawable-anydpi/<nombre>.xml.
 */

// Luna C separada (hueco de ~23 px de la vista previa) y luna C pegada (hueco de ~13 px). Disco igual en las dos.
private const val PATH_SEPARADA = "M8.937,3.228A8.808,8.808 0 0 0 8.937,20.772A10.303,10.303 0 0 1 8.937,3.228Z M5.532,12.000A8.808,8.808 0 1 0 23.148,12.000A8.808,8.808 0 1 0 5.532,12.000ZM11.285,12.000A3.055,3.055 0 1 0 17.395,12.000A3.055,3.055 0 1 0 11.285,12.000ZM11.967,12.000A2.373,2.373 0 1 0 16.712,12.000A2.373,2.373 0 1 0 11.967,12.000ZM13.723,12.000A0.618,0.618 0 1 0 14.957,12.000A0.618,0.618 0 1 0 13.723,12.000Z"
private const val PATH_PEGADA = "M9.986,3.193A8.808,8.808 0 0 0 9.986,20.807A9.685,9.685 0 0 1 9.986,3.193Z M5.207,12.000A8.808,8.808 0 1 0 22.823,12.000A8.808,8.808 0 1 0 5.207,12.000ZM10.960,12.000A3.055,3.055 0 1 0 17.070,12.000A3.055,3.055 0 1 0 10.960,12.000ZM11.643,12.000A2.373,2.373 0 1 0 16.387,12.000A2.373,2.373 0 1 0 11.643,12.000ZM13.398,12.000A0.618,0.618 0 1 0 14.633,12.000A0.618,0.618 0 1 0 13.398,12.000Z"

private fun vector(pathData: String) = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#FFFFFFFF"
        android:fillType="evenOdd"
        android:pathData="$pathData" />
</vector>
"""

private val ICON_NAMES = listOf("ic_notification", "media3_notification_small_icon")

@Suppress("unused")
val notificationIconPatch = resourcePatch(
    name = "Icono de notificacion: luna + disco",
    description = "Cambia la notita musical blanca que sale sobre la portada en la notificacion y la pantalla de bloqueo " +
        "por una media luna y un disco (como el icono de la app). " +
        "Sin probar: tu pantalla de bloqueo puede ajustar o tenir el icono.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    val luna by stringOption(
        key = "luna",
        default = "separada",
        values = mapOf(
            "Luna separada" to "separada",
            "Luna pegada al disco" to "pegada"
        ),
        title = "Luna",
        description = "Separada = hueco de ~23 px de la vista previa; pegada = hueco de ~13 px."
    )

    execute {
        val xml = vector(if (luna == "pegada") PATH_PEGADA else PATH_SEPARADA)
        val res = get("res")
        // Se busca por nombre en TODA la carpeta res (el recurso puede estar con nombre ofuscado o fuera de drawable*).
        val files: List<File> = res.walkTopDown()
            .filter { it.isFile && it.nameWithoutExtension in ICON_NAMES }
            .toList()

        for (name in ICON_NAMES) {
            // .xml existente: se reemplaza en su sitio; .png existente: se borra.
            for (f in files.filter { it.nameWithoutExtension == name }) {
                if (f.extension == "xml") f.writeText(xml) else f.delete()
            }
            // Siempre se crea el vector en drawable-anydpi (gana a cualquier densidad), exista o no el original en disco.
            val dir = File(res, "drawable-anydpi")
            dir.mkdirs()
            File(dir, "$name.xml").writeText(xml)
        }
    }
}
