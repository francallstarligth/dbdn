package app.eclipse.patches.dj

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val EXT = "Lapp/eclipse/extension/dj/ExplicitFirst;"

/**
 * v0.20.437 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). La 0.20.436 NO funciono (el DJ/chat siguen dando la version limpia). Causa probable: con un addon (Tido),
 * `Ljh0;->W(InstalledAddon, Song, String, Continuation)` prueba primero `getCanResolveIdentity()` y luego `getCanResolveISRC()` del addon y se queda con la pista
 * que el addon elige (puede ser la limpia); solo si ninguna sirve busca por nombre (`Lgv2;->j` + `Lgza;->b`, donde actuaba el parche). Ahora, tras cada uno de esos
 * dos `move-result v0` se inserta: si el addon dijo que si y `ExplicitFirst.skipShortcuts(song)` es true -> v0 = 0 (camino natural de "no puede") y la app va a la
 * busqueda por nombre. Respaldo: si esa busqueda no encuentra nada (`Lgza.b` devuelve null) se llama a `ExplicitFirst.noMatch(song)`; la cancion queda anotada y
 * en el siguiente intento se usan los atajos como antes (el primer intento puede fallar). Lo anterior (reordenar en `Lgza.b/c`) se mantiene.
 *
 * v0.20.436 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). El DJ pone versiones censuradas. Causa probable: las canciones del DJ llegan sin marca de explicita
 * (`Song.isExplicit` = null) y `Lgza;->c` (Tidal) / `Lgza;->b` (addons, ej. Tido) eligen el PRIMER resultado que encaja por titulo/artista/album/duracion
 * (`Lgza;->a`, sale al llegar a 100 puntos) sin mirar si es explicito. Este parche, al inicio de `Lgza.b` y `Lgza.c` (estaticos, 4 registros, params = ultimos 2:
 * Song y List), reordena la lista con `ExplicitFirst.sort(song, lista)` (explicitas primero, orden estable). No cambia nada si la cancion esta marcada como no explicita
 * o su titulo dice "clean".
 */
@Suppress("unused")
val djExplicitPatch = bytecodePatch(
    name = "DJ: preferir versiones explicitas",
    description = "Cuando la app busca en Tidal o en tu addon la cancion que puso el DJ o el chat, prefiere la version explicita en vez de la censurada. Con un addon (ej. Tido) busca primero por nombre en vez de dejar que el addon elija. Afecta a toda cancion sin marca de explicita.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lgza;"))
        for (name in listOf("b", "c")) {
            val m = cls.methods.firstOrNull { it.name == name && it.parameterTypes.size == 2 && it.parameterTypes[1] == "Ljava/util/List;" }
                ?: error("DJ explicitas: no se encontro Lgza.$name(Song, List)")
            val impl = m.implementation ?: error("DJ explicitas: Lgza.$name sin codigo")
            val pList = impl.registerCount - 1
            val pSong = impl.registerCount - 2
            if (pSong > 15 || pList > 15) error("DJ explicitas: registros de Lgza.$name no caben en 4 bits")
            val first = impl.instructions.first()
            if (first.opcode != Opcode.INVOKE_VIRTUAL || (first as FiveRegisterInstruction).registerC != pSong)
                error("DJ explicitas: la 1a instruccion de Lgza.$name no es el getClass() de la cancion")
            m.addInstructions(
                0,
                """
                    invoke-static {v$pSong, v$pList}, $EXT->sort(Ljava/lang/Object;Ljava/util/List;)Ljava/util/List;
                    move-result-object v$pList
                """
            )
        }

        // ---- v0.20.437: Ljh0;->W (addon por defecto): saltar los atajos del addon (identidad / ISRC) para ir a la busqueda por nombre ----
        val jh0 = mutableClassDefBy(classDefBy("Ljh0;"))
        val w = jh0.methods.firstOrNull {
            it.name == "W" && it.parameterTypes.size == 4 && it.parameterTypes[0] == "Lcom/eclipse/android/data/models/addon/InstalledAddon;" &&
                it.parameterTypes[1] == "Lcom/eclipse/android/data/models/Song;" && it.parameterTypes[2] == "Ljava/lang/String;"
        } ?: error("DJ explicitas: no se encontro Ljh0.W(InstalledAddon, Song, String, Continuation)")
        val wImpl = w.implementation ?: error("DJ explicitas: Ljh0.W sin codigo")
        val ins = wImpl.instructions.toList()
        val songReg = wImpl.registerCount - 3 // params: this, addon, song, query, continuation
        fun methodOf(i: Int): MethodReference? = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference

        // la 1a lectura de Song.getIsrc debe ser sobre el registro del parametro Song (invoke-virtual/range)
        val isrcCall = ins.indices.firstOrNull { i ->
            ins[i].opcode == Opcode.INVOKE_VIRTUAL_RANGE &&
                methodOf(i)?.let { it.definingClass == "Lcom/eclipse/android/data/models/Song;" && it.name == "getIsrc" } == true
        } ?: error("DJ explicitas: Ljh0.W no llama a Song.getIsrc")
        if ((ins[isrcCall] as RegisterRangeInstruction).startRegister != songReg)
            error("DJ explicitas: Song.getIsrc no se lee del registro del parametro Song (v$songReg)")

        // index de la instruccion `if-eqz v0` que sigue a `getCanResolveXxx()` + `move-result v0`
        fun ifAfter(name: String): Int {
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                    methodOf(i)?.let { it.definingClass == "Lcom/eclipse/android/data/models/addon/EclipseAddonManifest;" && it.name == name } == true
            }
            if (hits.size != 1) error("DJ explicitas: se esperaba 1 llamada a $name en Ljh0.W y hay ${hits.size}")
            val i = hits[0]
            if (ins[i + 1].opcode != Opcode.MOVE_RESULT) error("DJ explicitas: tras $name no viene move-result")
            val r = (ins[i + 1] as OneRegisterInstruction).registerA
            if (r != 0) error("DJ explicitas: el resultado de $name no va a v0 (va a v$r)")
            if (ins[i + 2].opcode != Opcode.IF_EQZ || (ins[i + 2] as OneRegisterInstruction).registerA != 0)
                error("DJ explicitas: tras el move-result de $name no viene if-eqz v0")
            return i + 2
        }
        val ifIdentity = ifAfter("getCanResolveIdentity")
        val ifIsrc = ifAfter("getCanResolveISRC")

        // final de W: Lgza.b(song, lista) ; move-result-object v0 ; return-object v0
        val last = ins.size - 1
        if (ins[last].opcode != Opcode.RETURN_OBJECT || (ins[last] as OneRegisterInstruction).registerA != 0 ||
            ins[last - 1].opcode != Opcode.MOVE_RESULT_OBJECT || (ins[last - 1] as OneRegisterInstruction).registerA != 0 ||
            ins[last - 2].opcode != Opcode.INVOKE_STATIC ||
            methodOf(last - 2)?.let { it.definingClass == "Lgza;" && it.name == "b" } != true
        ) error("DJ explicitas: el final de Ljh0.W no es Lgza.b + move-result-object v0 + return-object v0")
        val songAtEnd = (ins[last - 2] as FiveRegisterInstruction).registerC
        if (songAtEnd > 15) error("DJ explicitas: registro de la cancion al final de Ljh0.W no cabe en 4 bits")

        // de abajo hacia arriba para no mover los indices
        w.addInstructionsWithLabels(
            last,
            """
                if-nez v0, :ok
                invoke-static {v$songAtEnd}, $EXT->noMatch(Ljava/lang/Object;)V
            """,
            ExternalLabel("ok", w.getInstruction(last))
        )
        for (idx in listOf(ifIsrc, ifIdentity).sortedDescending()) {
            w.addInstructionsWithLabels(
                idx,
                """
                    if-eqz v0, :skip
                    invoke-static/range {v$songReg .. v$songReg}, $EXT->skipShortcuts(Ljava/lang/Object;)Z
                    move-result v0
                    xor-int/lit8 v0, v0, 0x1
                """,
                ExternalLabel("skip", w.getInstruction(idx))
            )
        }
    }
}
