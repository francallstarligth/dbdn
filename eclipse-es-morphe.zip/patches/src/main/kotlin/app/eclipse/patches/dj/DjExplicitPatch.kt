package app.eclipse.patches.dj

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction

private const val EXT = "Lapp/eclipse/extension/dj/ExplicitFirst;"

/**
 * v0.20.436 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). El DJ pone versiones censuradas. Causa probable: las canciones del DJ llegan sin marca de explicita
 * (`Song.isExplicit` = null) y `Lgza;->c` (Tidal) / `Lgza;->b` (addons, ej. Tido) eligen el PRIMER resultado que encaja por titulo/artista/album/duracion
 * (`Lgza;->a`, sale al llegar a 100 puntos) sin mirar si es explicito. Este parche, al inicio de `Lgza.b` y `Lgza.c` (estaticos, 4 registros, params = ultimos 2:
 * Song y List), reordena la lista con `ExplicitFirst.sort(song, lista)` (explicitas primero, orden estable). No cambia nada si la cancion esta marcada como no explicita
 * o su titulo dice "clean".
 */
@Suppress("unused")
val djExplicitPatch = bytecodePatch(
    name = "DJ: preferir versiones explicitas",
    description = "Cuando la app busca en Tidal o en tu addon la cancion que puso el DJ, prefiere la version explicita en vez de la censurada. Afecta a toda cancion sin marca de explicita.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lgza;"))
        for (name in listOf("b", "c")) {
            val m = cls.methods.firstOrNull { it.name == name && it.parameterTypes.size == 2 && it.parameterTypes[1] == "Ljava/util/List;" }
                ?: error("DJ explicitas: no se encontro Lgza.$name(Song, List)")
            val impl = m.implementation ?: error("DJ explicitas: Lgza.$name sin codigo")
            val pList = impl.registerCount - 1
            val pSong = impl.registerCount - 2
            if (pSong > 15 || pList > 15) error("DJ explicitas: registros de Lgza.$name no caben en 4 bits")
            val first = impl.instructions.first()
            if (first.opcode != Opcode.INVOKE_VIRTUAL || (first as FiveRegisterInstruction).registerC != pSong)
                error("DJ explicitas: la 1a instruccion de Lgza.$name no es el getClass() de la cancion")
            m.addInstructions(
                0,
                """
                    invoke-static {v$pSong, v$pList}, $EXT->sort(Ljava/lang/Object;Ljava/util/List;)Ljava/util/List;
                    move-result-object v$pList
                """
            )
        }
    }
}
