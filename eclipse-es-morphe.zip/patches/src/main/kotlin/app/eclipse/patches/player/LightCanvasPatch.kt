package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val BG = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

/**
 * v0.20.56 (SIN COMPILAR / SIN PROBAR). Igual que "Reflejo liviano (portadas sin Canvas)" pero para el reflejo que es
 * el VIDEO del Canvas: la vista del video se crea a 1/3 (radio de blur/3) y la capa se estira 3 veces. El video se
 * decodifica igual; lo que baja es el blur. CoverFade.lightK avisa del factor a CanvasCenter y a CoverFade (que calculan
 * con el tamano de la vista). Solo toca el reflejo de abajo, no el video nitido de arriba. APAGADO por defecto.
 */
@Suppress("unused")
val lightCanvasPatch = bytecodePatch(
    description = "Experimento. El reflejo borroso de abajo, cuando la cancion tiene Canvas, se hace con el video en una caja " +
        "chica y se estira: pesa menos. Si el video se ve corrido, cortado o raro, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Lja7;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lmx6;"
        } ?: error("No se encontro ja7.q (Eclipse 0.6.61; en 0.6.55 era j87.q)")
        q.addInstructions(0, "invoke-static {}, $BG->enableLightCanvas()V")
    }
}
