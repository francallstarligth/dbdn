package app.eclipse.patches.artwork

import app.eclipse.patches.player.transparentEdgeFadePatch
import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.140 (SIN COMPILAR NI PROBAR). Une "Cambio de cancion: fundido", "Portadas animadas sin parpadeo" y
 * "Custom: fundido transparente de la portada". El fundido dependia de "sin parpadeo": aqui el fundido lo enciende solo.
 */
@Suppress("unused")
val coverTransitionsPatch = bytecodePatch(
    name = "Portadas: fundido y sin parpadeo",
    description = "Cambio de cancion con fundido suave, portadas animadas sin destello negro y fundido transparente de " +
        "la portada (Custom). Cada uno tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val fade by booleanOption(
        key = "fade",
        default = true,
        title = "Cambio de cancion: fundido",
        description = "Al cambiar de cancion, la portada, su reflejo y el desenfoque se mezclan con un fundido suave. Enciende tambien el de sin parpadeo."
    )

    val noFlash by booleanOption(
        key = "noFlash",
        default = true,
        title = "Portadas animadas sin parpadeo",
        description = "La portada fija se queda visible hasta que el video del Canvas esta listo y luego se desvanece."
    )

    val edgeFade by booleanOption(
        key = "edgeFade",
        default = false,
        title = "Fundido transparente de la portada (Custom)",
        description = "En el reproductor Custom, la portada inmersiva se borra de a poco (transparente) en vez de pintar un color encima."
    )

    val staleGuard by booleanOption(
        key = "staleGuard",
        default = true,
        title = "Reflejo: no usar la portada anterior al volver de Letra",
        description = "Si cambia la cancion estando en Letra, al volver a Artwork el reflejo del Canvas (y la portada que espera al video) usa la portada de la cancion actual y no la anterior. Desmarcalo para que quede como antes."
    )

    execute {
        if (staleGuard == true) staleGuardPatch.execute(this)
        if (noFlash == true || fade == true) animatedCoverNoFlashPatch.execute(this)
        if (fade == true) previousCoverPatch.execute(this)
        if (edgeFade == true) transparentEdgeFadePatch.execute(this)
    }
}
