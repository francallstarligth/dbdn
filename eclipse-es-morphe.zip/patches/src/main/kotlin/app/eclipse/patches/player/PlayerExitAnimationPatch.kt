package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

/**
 * EXPERIMENTO (v1.97.7, sin compilar ni probar). Salida del reproductor grande mas lenta y que se achique mas.
 * Retroceder y el cierre tras empujar llaman a bl6.b(), que apaga el estado del AnimatedVisibility (hy5.f) de ax1.b
 * cuyo contenido es zg4 caso 8 (dr8.a -> a43.c). Su salida: deslizar (tween 280 ms) + escala a 0.94 (tween 280 ms,
 * dk7) + fundido (tween 200 ms). Antes de `new-instance zg4` se tocan 3 constantes: 280 -> 450 ms (deslizar y escala,
 * comparten el registro), 200 -> 350 ms (fundido) y escala 0.94 -> 0.85. Para no depender de replaceInstruction, se
 * inserta una constante nueva justo despues de la original (pisa el mismo registro antes de usarse).
 */
@Suppress("unused")
val playerExitAnimationPatch = bytecodePatch(
    description = "Experimento. Al retroceder, el reproductor grande baja mas despacio y se achica mas (450 ms, escala 0.85) " +
        "en vez de bajar rapido. No toca la animacion de empujar con el dedo. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val vd2 = mutableClassDefBy(classDefBy("Lax1;"))
        val m = vd2.methods.singleOrNull {
            it.name == "b" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Lei0;", "Lsg6;", "Lfp1;", "I")
        } ?: error("No se encontro ax1.b")
        val ins = (m.implementation ?: error("ax1.b sin codigo")).instructions.toList()

        val zg4 = ins.indices.filter { i ->
            ins[i].opcode == Opcode.NEW_INSTANCE &&
                ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lia5;"
        }
        if (zg4.size != 1) error("ax1.b: se esperaba 1 new-instance zg4 (hay ${zg4.size})")
        val z = zg4[0]

        fun lit(i: Int) = (ins[i] as WideLiteralInstruction).wideLiteral
        fun reg(i: Int) = (ins[i] as OneRegisterInstruction).registerA

        // ultima constante con ese valor ANTES de zg4 (las otras 280/320 de ax1.b son de otras pantallas, mas abajo)
        val i280 = (0 until z).lastOrNull {
            ins[it].opcode == Opcode.CONST_16 && lit(it) == 280L && ins[it + 1].opcode == Opcode.INVOKE_STATIC
        } ?: error("ax1.b: no se encontro const 280")
        val i200 = (0 until z).lastOrNull { ins[it].opcode == Opcode.CONST_16 && lit(it) == 200L }
            ?: error("ax1.b: no se encontro const 200")
        val iScale = (0 until z).lastOrNull { ins[it].opcode == Opcode.CONST && lit(it) == 1064346583L }
            ?: error("ax1.b: no se encontro la escala 0.94")

        // de mayor a menor indice, para que cada insercion no mueva a las que faltan
        val cambios = listOf(
            Triple(i200, "const/16 v${reg(i200)}, 350", "fundido"),
            Triple(iScale, "const v${reg(iScale)}, 0x3f59999a", "escala"),
            Triple(i280, "const/16 v${reg(i280)}, 450", "deslizar"),
        ).sortedByDescending { it.first }
        for ((idx, smali, _) in cambios) m.addInstructions(idx + 1, smali)
    }
}
