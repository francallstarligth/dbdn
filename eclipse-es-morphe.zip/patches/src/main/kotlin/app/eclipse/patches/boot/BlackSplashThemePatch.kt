package app.eclipse.patches.boot

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.resourcePatch

/**
 * v0.20.132 (SIN COMPILAR / SIN PROBAR). Pantalla de inicio del SISTEMA (Android 12 o superior) en negro y con el disco
 * girando como icono animado, para que aparezca en el mismo momento en que antes salia el icono (al tocar la app).
 *
 * VERIFICADO en el APK 0.6.47: Theme.Eclipse (res/values/styles.xml) hereda de Theme.Material.NoActionBar y solo trae
 * windowBackground negro + barras transparentes; no define nada de splash, por eso Android pone el icono de la app.
 * Se agrega res/values-v31/styles.xml con el mismo estilo (mismos items, para no perder nada) mas:
 *   windowSplashScreenBackground = negro y windowSplashScreenAnimatedIcon = un dibujo animado (AnimatedVectorDrawable)
 *   del disco: media luna naranja, disco con surcos y etiqueta que gira (1,8 s por vuelta, en bucle).
 * El dibujo es de 288 dp y todo queda dentro del circulo central de 192 dp (lo unico que el sistema deja ver).
 * Solo afecta a Android 12+ (values-v31); antes de eso ya se veia el fondo negro de windowBackground.
 * HIPOTESIS sin probar en el Redmi (Android 16): HyperOS puede ignorar el icono (paso con el icono vacio de la v0.20.126) y
 * no esta verificado que el sistema repita la animacion en bucle hasta que Eclipse dibuje.
 */
private const val STYLES = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Eclipse" parent="@android:style/Theme.Material.NoActionBar">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:windowDrawsSystemBarBackgrounds">true</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:windowSplashScreenBackground">@android:color/black</item>
        <item name="android:windowSplashScreenAnimatedIcon">@drawable/eclipse_boot_disc</item>
    </style>
</resources>
"""

private const val DISC_VECTOR = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="288dp"
    android:height="288dp"
    android:viewportWidth="288"
    android:viewportHeight="288">
    <path android:fillColor="#E0572F" android:pathData="M52.56,144a77.04,77.04 0 1,0 154.08,0a77.04,77.04 0 1,0 -154.08,0z" />
    <path android:fillColor="#1E1E1E" android:pathData="M80.64,144a74.16,74.16 0 1,0 148.32,0a74.16,74.16 0 1,0 -148.32,0z" />
    <path android:fillColor="#00000000" android:strokeColor="#2A2A2A" android:strokeWidth="2.52" android:pathData="M124.38,144a30.42,30.42 0 1,0 60.84,0a30.42,30.42 0 1,0 -60.84,0zM119.34,144a35.46,35.46 0 1,0 70.92,0a35.46,35.46 0 1,0 -70.92,0zM114.3,144a40.5,40.5 0 1,0 81,0a40.5,40.5 0 1,0 -81,0zM109.26,144a45.54,45.54 0 1,0 91.08,0a45.54,45.54 0 1,0 -91.08,0zM104.22,144a50.58,50.58 0 1,0 101.16,0a50.58,50.58 0 1,0 -101.16,0zM99.18,144a55.62,55.62 0 1,0 111.24,0a55.62,55.62 0 1,0 -111.24,0zM94.14,144a60.66,60.66 0 1,0 121.32,0a60.66,60.66 0 1,0 -121.32,0zM89.1,144a65.7,65.7 0 1,0 131.4,0a65.7,65.7 0 1,0 -131.4,0z" />
    <path android:fillColor="#00000000" android:strokeColor="#404040" android:strokeWidth="4.68" android:pathData="M85.32,144a69.48,69.48 0 1,0 138.96,0a69.48,69.48 0 1,0 -138.96,0z" />
    <group android:name="label" android:pivotX="154.8" android:pivotY="144">
        <path android:fillColor="#474747" android:pathData="M127.08,144a27.72,27.72 0 1,0 55.44,0a27.72,27.72 0 1,0 -55.44,0z" />
        <path android:fillColor="#00000000" android:strokeColor="#FFFFFF" android:strokeWidth="3.6" android:pathData="M139.74,145.32A15.12,15.12 0 0,1 158.71,129.4M169.86,142.68A15.12,15.12 0 0,1 150.89,158.6" />
        <path android:fillColor="#FFFFFF" android:pathData="M164.26,133.69a1.6,1.6 0 1,0 3.2,0a1.6,1.6 0 1,0 -3.2,0zM142.32,154.5a1.6,1.6 0 1,0 3.2,0a1.6,1.6 0 1,0 -3.2,0z" />
    </group>
    <path android:fillColor="#E8503A" android:pathData="M149.76,144a5.04,5.04 0 1,0 10.08,0a5.04,5.04 0 1,0 -10.08,0z" />
</vector>
"""

private const val DISC_ANIMATED = """<?xml version="1.0" encoding="utf-8"?>
<animated-vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:drawable="@drawable/eclipse_boot_disc_vec">
    <target
        android:name="label"
        android:animation="@anim/eclipse_boot_spin" />
</animated-vector>
"""

private const val DISC_SPIN = """<?xml version="1.0" encoding="utf-8"?>
<objectAnimator xmlns:android="http://schemas.android.com/apk/res/android"
    android:propertyName="rotation"
    android:valueFrom="0"
    android:valueTo="360"
    android:valueType="floatType"
    android:duration="1800"
    android:repeatCount="-1"
    android:interpolator="@android:anim/linear_interpolator" />
"""

@Suppress("unused")
val blackSplashThemePatch = resourcePatch(
    name = "Pantalla de carga: disco del sistema",
    description = "En Android 12 o superior pone el disco girando como icono de la pantalla de inicio del sistema " +
        "(la que sale al tocar la app), sobre fondo negro. Si Eclipse no llegara a abrir despues de parchear, " +
        "desmarca este parche.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val dir = get("res/values-v31")
        dir.mkdirs()
        get("res/values-v31/styles.xml").writeText(STYLES)
        val dr = get("res/drawable")
        dr.mkdirs()
        get("res/drawable/eclipse_boot_disc_vec.xml").writeText(DISC_VECTOR)
        get("res/drawable/eclipse_boot_disc.xml").writeText(DISC_ANIMATED)
        // v0.20.133: el APK de Eclipse no trae el tipo "animator" (el parcheador fallo con "Local resource not defined"),
        // pero si trae "anim": el objectAnimator va ahi; Android lo carga igual por su id.
        val an = get("res/anim")
        an.mkdirs()
        get("res/anim/eclipse_boot_spin.xml").writeText(DISC_SPIN)
    }
}
