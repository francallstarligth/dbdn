package app.eclipse.patches.boot

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.resourcePatch

/**
 * v0.20.126 (SIN COMPILAR / SIN PROBAR). Pantalla de inicio del SISTEMA (Android 12 o superior) en negro y sin icono.
 *
 * VERIFICADO en el APK 0.6.47: Theme.Eclipse (res/values/styles.xml) hereda de Theme.Material.NoActionBar y solo trae
 * windowBackground negro + barras transparentes; no define nada de splash, por eso Android pone el icono de la app.
 * Se agrega res/values-v31/styles.xml con el mismo estilo (mismos items, para no perder nada) mas:
 *   windowSplashScreenBackground = negro y windowSplashScreenAnimatedIcon = un dibujo vacio (transparente).
 * Solo afecta a Android 12+ (values-v31); antes de eso ya se veia el fondo negro de windowBackground.
 * HIPOTESIS sin probar en el Redmi (Android 16): algunos fabricantes ponen su propia pantalla con icono y la ignoran.
 */
private const val STYLES = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Eclipse" parent="@android:style/Theme.Material.NoActionBar">
        <item name="android:windowBackground">@android:color/black</item>
        <item name="android:windowDrawsSystemBarBackgrounds">true</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
        <item name="android:windowLightStatusBar">false</item>
        <item name="android:windowSplashScreenBackground">@android:color/black</item>
        <item name="android:windowSplashScreenAnimatedIcon">@drawable/eclipse_boot_blank</item>
    </style>
</resources>
"""

private const val BLANK = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="24"
    android:viewportHeight="24">
    <path
        android:fillColor="#00000000"
        android:pathData="M0,0h1v1h-1z" />
</vector>
"""

@Suppress("unused")
val blackSplashThemePatch = resourcePatch(
    name = "Pantalla de carga: sin icono (negro)",
    description = "En Android 12 o superior quita el icono que el sistema muestra al tocar la app y deja la pantalla " +
        "negra. Si Eclipse no llegara a abrir despues de parchear, desmarca este parche.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val dir = get("res/values-v31")
        dir.mkdirs()
        get("res/values-v31/styles.xml").writeText(STYLES)
        val dr = get("res/drawable")
        dr.mkdirs()
        get("res/drawable/eclipse_boot_blank.xml").writeText(BLANK)
    }
}
