package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val BG = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

/**
 * v0.20.55 (SIN COMPILAR / SIN PROBAR). El reflejo de las portadas normales (sin Canvas) se borronea en una caja
 * grande (mas ancha que la pantalla) con mucho radio: es lo mas pesado al abrir el reproductor. Con este parche se
 * hace en una caja a 1/3 (radio/3) y la capa se estira 3 veces: se ve igual y cuesta mucho menos.
 * El gancho solo enciende el interruptor BlurredCanvasBackground.lightRefl (inicio de di6.q, igual que otros ganchos).
 * Necesita "Custom: Canvas detras del fondo Blurred Cover" (de ahi sale el reflejo). Con Canvas no cambia nada.
 */
@Suppress("unused")
val lightReflectionPatch = bytecodePatch(
    description = "El reflejo de abajo se hace con una copia chica de la portada y se estira: se ve igual y el telefono " +
        "trabaja menos al abrir el reproductor. Con Canvas no cambia nada. Desmarcalo si el reflejo se ve movido o raro.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Lqr7;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lle7;"
        } ?: error("No se encontro mq7.q (Eclipse 0.6.70; en 0.6.55 era j87.q)")
        q.addInstructions(0, "invoke-static {}, $BG->enableLightReflection()V")
    }
}
