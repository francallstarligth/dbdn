package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/** 1.2f: la escala que usa el estilo BLURRED_ARTWORK ("Portada desenfocada"). "Dynamic" usa 1.4f. */
private const val SCALE_BLURRED = 0x3f99999a

/** 0.999f: opacidad casi total; se ve igual, pero obliga a Compose a dibujar la imagen en su propia capa. */
private const val ALMOST_OPAQUE = "0x3f7fbe77"

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun regName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

@Suppress("unused")
val blurredCoverLayerPatch = bytecodePatch(
    name = "Custom: fondo Portada desenfocada en su propia capa",
    description = "Prueba para la raya oscura a la mitad al abrir/cambiar de cancion con el fondo \"Portada desenfocada\". " +
        "Mantiene el blur en vivo (misma escala y mismo radio) pero dibuja la imagen en su propia capa, " +
        "como ya hace el estilo \"Dynamic\" (que no tiene la raya). Hipotesis sin verificar.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // di6.c(sv0, Z, Song, ki1, I): dibuja el fondo segun el estilo. En la rama BLURRED_ARTWORK el modificador de
        // la imagen es: fillMaxSize -> escala 1.2 (yg2.H) -> blur (by9.k). Justo despues del blur se agrega
        // opacidad 0.999 (r15.g, la misma funcion que usa "Dynamic" con 0.8).
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val method = di6.methods.firstOrNull { m ->
            m.name == "c" && m.returnType == "V" && m.parameterTypes.map { it.toString() } ==
                listOf("Lsv0;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lki1;", "I")
        } ?: error("No se encontro di6.c (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("di6.c sin codigo")).instructions.toList()

        // La constante 1.2f identifica la rama (Dynamic usa 1.4f; Image no escala).
        val scaleIdx = list.indices.firstOrNull { i ->
            list[i].opcode == Opcode.CONST && (list[i] as NarrowLiteralInstruction).narrowLiteral == SCALE_BLURRED
        } ?: error("di6.c: no se encontro la escala 1.2f (rama Portada desenfocada)")

        // by9.k(Modifier, float) = Modifier.blur, el primero despues de esa escala.
        val blurIdx = (scaleIdx + 1 until minOf(list.size, scaleIdx + 30)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lby9;" &&
                ref.name == "k" && ref.returnType == "Lmh5;" && ref.parameterTypes.size == 2
        } ?: error("di6.c: no se encontro by9.k despues de la escala 1.2f")

        val call = list[blurIdx] as FiveRegisterInstruction
        val mr = list[blurIdx + 1]
        if (mr.opcode != Opcode.MOVE_RESULT_OBJECT) error("di6.c: by9.k sin move-result-object")
        val resultReg = (mr as OneRegisterInstruction).registerA

        // Registro de paso: el modificador de entrada de by9.k, que despues del blur ya no se usa. Se comprueba que
        // lo siguiente sea una llamada que no lo toca y luego un move-result que lo reescribe.
        val scratchReg = call.registerC
        if (scratchReg == resultReg) error("di6.c: registro de paso igual al del resultado")
        val next = list[blurIdx + 2]
        val after = list[blurIdx + 3]
        if (next !is FiveRegisterInstruction || next.registerCount > 0 &&
            listOf(next.registerC, next.registerD, next.registerE, next.registerF, next.registerG)
                .take(next.registerCount).contains(scratchReg)
        ) error("di6.c: tras by9.k se esperaba una llamada que no use v$scratchReg")
        if (after.opcode != Opcode.MOVE_RESULT || (after as OneRegisterInstruction).registerA != scratchReg) {
            error("di6.c: v$scratchReg no se reescribe justo despues (no es seguro usarlo)")
        }

        for (r in listOf(resultReg, scratchReg)) {
            if (r > 15) error("di6.c: registro v$r fuera de rango para invoke-static")
        }
        val res = regName(resultReg, method)
        val tmp = regName(scratchReg, method)
        method.addInstructions(
            blurIdx + 2,
            """
                const $tmp, $ALMOST_OPAQUE
                invoke-static {$res, $tmp}, Lr15;->g(Lmh5;F)Lmh5;
                move-result-object $res
            """
        )
    }
}
