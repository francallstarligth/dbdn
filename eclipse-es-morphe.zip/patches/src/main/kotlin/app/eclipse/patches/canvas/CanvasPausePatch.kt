package app.eclipse.patches.canvas

import app.eclipse.patches.player.blurredCoverCanvasPatch
import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.157 (SIN COMPILAR / SIN PROBAR). Pausa el Canvas (portada animada y reflejo) en Letra y Cola.
 * xi6.h(String url, boolean reproduciendo, mh5 modifier, ki1 composer, int) es la unica funcion que crea el video del
 * Canvas. Al inicio se pasa "reproduciendo" por CanvasPause.play(Z)Z (false si la pestana no es Artwork). xi6.h ya pausa
 * y reanuda su ExoPlayer cuando ese valor cambia. En el metodo estatico: p0 = url, p1 = reproduciendo.
 */
@Suppress("unused")
val canvasPausePatch = bytecodePatch(
    description = "Pausa el video del Canvas (portada animada y reflejo) mientras estas en Letra o Cola, y lo reanuda al " +
        "volver a Artwork sin recargarlo. El reflejo se conserva pausado en vez de destruirse. Gasta menos y evita la espera.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val xi6 = mutableClassDefBy(classDefBy("Lxi6;"))
        val h = xi6.methods.singleOrNull {
            it.name == "h" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Z", "Lmh5;", "Lki1;", "I")
        } ?: error("No se encontro xi6.h(String, Z, mh5, ki1, I)")
        h.addInstructions(
            0,
            """
                invoke-static {p1}, Lapp/eclipse/extension/canvas/CanvasPause;->play(Z)Z
                move-result p1
            """
        )
    }
}
