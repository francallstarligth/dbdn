package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val ARM = "Lapp/eclipse/extension/player/ArmSeek;"

/**
 * v0.20.395 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Brazo del tocadiscos: la capa llamada "Brazo" gira segun el avance de la cancion
 * (y sigue al dedo cuando se arrastra una barra de progreso). Ver `ArmSeek.java`. Tres ganchos, todos verificados en el dex 0.6.75:
 *  (1) `Lpr7;.invoke` (lambda de graphicsLayer, caso con `iget-object vA, vB, Lv51;->d:Lmv4;` + `iget-wide mv4.e` + `add-float/2addr v3, v2` + `Loq3;->e(F)`):
 *      antes del iget se guarda la capa en v4 (en ese caso v4 no se usa), y despues del add-float se llama ArmSeek.rot(capa, rotacion).
 *  (2) `Lh61.<init>` (unico return-void): ArmSeek.fromState(this).
 *  (3) `Lzt7;.h` (barra de progreso): tras `iget-boolean vX, Lh61;->b` ya estan en registros la posicion efectiva (v12/v13) y la duracion (v1/v2).
 */
@Suppress("unused")
val armSeekPatch = bytecodePatch(
    name = "Tocadiscos: brazo que se mueve con la cancion",
    description = "La capa llamada \"Brazo\" (o \"Brazo 20\" para 20 grados de barrido) gira segun el avance de la cancion y sigue al dedo al " +
        "arrastrar la barra de progreso. Pensado para el diseno Tocadiscos. Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (1) rotacion de cada capa
        run {
            val cls = mutableClassDefBy(classDefBy("Lpr7;"))
            val m = cls.methods.singleOrNull {
                it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes == listOf("Ljava/lang/Object;")
            } ?: error("Brazo: no se encontro Lpr7.invoke")
            val ins = (m.implementation ?: error("Brazo: Lpr7.invoke sin codigo")).instructions.toList()
            val rd = ins.indices.filter { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
                ins[i].opcode == Opcode.IGET_WIDE && r != null && r.definingClass == "Lmv4;" && r.name == "e"
            }
            if (rd.size != 1) error("Brazo: se esperaba 1 lectura de mv4.e en Lpr7.invoke y hay ${rd.size}")
            val iw = rd[0]
            val getL = ins[iw - 1]
            val gr = (getL as? ReferenceInstruction)?.reference as? FieldReference
            if (getL.opcode != Opcode.IGET_OBJECT || gr == null || gr.definingClass != "Lv51;" || gr.name != "d")
                error("Brazo: antes de mv4.e no viene iget-object v51.d")
            val layerReg = (getL as TwoRegisterInstruction).registerB
            val add = ins.indices.firstOrNull { it > iw && it < iw + 14 && ins[it].opcode == Opcode.ADD_FLOAT_2ADDR }
                ?: error("Brazo: no se encontro add-float/2addr despues de mv4.e")
            val sum = (ins[add] as TwoRegisterInstruction).registerA
            if (sum != 3) error("Brazo: se esperaba la suma en v3 (es v$sum)")
            if (layerReg > 15) error("Brazo: registro alto para la capa (v$layerReg)")
            // v4: sin uso en este caso de la lambda (solo se leen v0..v3 hasta el return); se comprueba que nadie lo lee entre el iget y el return.
            val ret = ins.indices.first { it > add && ins[it].opcode == Opcode.RETURN_OBJECT }
            for (i in iw - 1..ret) {
                val x = ins[i]
                val usa = (x is OneRegisterInstruction && x.registerA == 4) ||
                    (x is TwoRegisterInstruction && x.registerB == 4) ||
                    (x is FiveRegisterInstruction && listOf(x.registerC, x.registerD, x.registerE, x.registerF, x.registerG)
                        .take(x.registerCount).contains(4))
                if (usa) error("Brazo: v4 se usa en Lpr7.invoke (indice $i)")
            }
            // 1o el de despues (para no mover los indices), 2o el de antes.
            m.addInstructions(
                add + 1,
                """
                    invoke-static {v4, v3}, $ARM->rot(Ljava/lang/Object;F)F
                    move-result v3
                """
            )
            m.addInstructions(iw - 1, "move-object v4, v$layerReg")
        }

        // (2) foto del estado del reproductor (posicion y duracion)
        run {
            val cls = mutableClassDefBy(classDefBy("Lh61;"))
            val m = cls.methods.singleOrNull { it.name == "<init>" && it.parameterTypes.size == 26 }
                ?: error("Brazo: no se encontro Lh61.<init>")
            val ins = (m.implementation ?: error("Brazo: Lh61.<init> sin codigo")).instructions.toList()
            val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
            if (ret.size != 1) error("Brazo: se esperaba 1 return-void en Lh61.<init> y hay ${ret.size}")
            m.addInstructions(ret[0], "invoke-static {p0}, $ARM->fromState(Ljava/lang/Object;)V")
        }

        // (3) barra de progreso (posicion efectiva: la del dedo si se arrastra)
        run {
            val cls = mutableClassDefBy(classDefBy("Lzt7;"))
            val m = cls.methods.singleOrNull {
                it.name == "h" && it.returnType == "V" && it.parameterTypes.size >= 6 &&
                    it.parameterTypes[0] == "Lv51;" && it.parameterTypes[4] == "Lh61;"
            } ?: error("Brazo: no se encontro Lzt7.h")
            val ins = (m.implementation ?: error("Brazo: Lzt7.h sin codigo")).instructions.toList()
            fun fieldIdx(op: Opcode, n: String) = ins.indices.filter { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
                ins[i].opcode == op && r != null && r.definingClass == "Lh61;" && r.name == n
            }
            val c = fieldIdx(Opcode.IGET_WIDE, "c")
            val d = fieldIdx(Opcode.IGET_WIDE, "d")
            val b = fieldIdx(Opcode.IGET_BOOLEAN, "b")
            if (c.size != 1 || d.size != 1 || b.size != 1) error("Brazo: Lzt7.h: se esperaba 1 lectura de Lh61.c/d/b (${c.size}/${d.size}/${b.size})")
            if (!(c[0] < d[0] && d[0] < b[0] && b[0] - d[0] <= 2)) error("Brazo: Lzt7.h: orden inesperado de lecturas")
            val pos = (ins[c[0]] as OneRegisterInstruction).registerA
            val dur = (ins[d[0]] as OneRegisterInstruction).registerA
            if (pos > 14 || dur > 14) error("Brazo: Lzt7.h: registros altos (v$pos, v$dur)")
            // la posicion no debe pisarse entre su lectura y el gancho
            for (i in c[0] + 1..b[0]) {
                val x = ins[i]
                if (x is OneRegisterInstruction && (x.registerA == pos || x.registerA == pos + 1)) {
                    if (x.opcode != Opcode.IGET_WIDE || i != d[0]) error("Brazo: Lzt7.h: se pisa la posicion (v$pos) antes del gancho")
                }
            }
            m.addInstructions(
                b[0] + 1,
                "invoke-static {v$pos, v${pos + 1}, v$dur, v${dur + 1}}, $ARM->fromBar(DD)V"
            )
        }
    }
}
