package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

/**
 * Bug de Eclipse 0.6.47 (estilo de app Eclipse, pantalla de playlist/favoritos): la lista se MUESTRA con el orden
 * elegido en "Sort By" (ra2.h(lista, go6)), pero la lista que se le pasa a Reproducir / Aleatorio (yl6 -> dm6 -> b40)
 * y al tocar una cancion (im6.y -> o71 -> i40) es la ORIGINAL (orden Custom). Por eso la cola y "siguiente" siguen el
 * orden Custom aunque haya otro activo.
 *
 * Arreglo: en wl6.invoke (el contenido de la lista), justo despues de leer wl6.q (lista original) se reemplaza ese
 * registro por ra2.h(lista, orden actual). Asi todo lo que sale de ese registro (yl6.t y im6.y) ya va ordenado.
 * El resto del metodo vuelve a ordenar/filtrar para mostrar (ordenar dos veces con el mismo criterio no cambia nada).
 */
@Suppress("unused")
val playlistSortPlayPatch = bytecodePatch(
    name = "Reproducir en el orden elegido",
    description = "Arregla que Reproducir, Aleatorio y 'siguiente' usen siempre el orden Custom de la playlist " +
        "aunque tengas otro orden activo (Titulo, Artista, Agregado recientemente).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val wl6 = mutableClassDefBy(classDefBy("Lwl6;"))
        val method = wl6.methods.firstOrNull {
            it.name == "invoke" && it.parameterTypes.size == 1 && it.parameterTypes[0].toString() == "Ljava/lang/Object;"
        } ?: error("No se encontro wl6.invoke")

        val ins = (method.implementation ?: error("wl6.invoke sin codigo")).instructions.toList()
        val listField = ins.indexOfFirst { i ->
            if (i.opcode != Opcode.IGET_OBJECT) return@indexOfFirst false
            val ref = (i as ReferenceInstruction).reference as? FieldReference ?: return@indexOfFirst false
            ref.definingClass == "Lwl6;" && ref.name == "q" && ref.type == "Ljava/util/List;"
        }
        if (listField < 0) error("wl6.invoke: no se encontro el campo q (lista original)")

        // Registro que recibe la lista original. En 0.6.47 es v14; v0 = this (move-object/from16 v0, p0 al inicio)
        // y v15 todavia no se usa (se asigna mas adelante), asi que sirve de registro temporal.
        val listReg = (ins[listField] as OneRegisterInstruction).registerA
        if (listReg != 14) error("wl6.invoke: la lista original no esta en v14 (esta en v$listReg)")

        method.addInstructions(
            listField + 1,
            """
                iget-object v15, v0, Lwl6;->D:Len5;
                invoke-interface {v15}, Lzk8;->getValue()Ljava/lang/Object;
                move-result-object v15
                check-cast v15, Lgo6;
                invoke-static {v14, v15}, Lra2;->h(Ljava/util/List;Lgo6;)Ljava/util/List;
                move-result-object v14
            """
        )
    }
}
