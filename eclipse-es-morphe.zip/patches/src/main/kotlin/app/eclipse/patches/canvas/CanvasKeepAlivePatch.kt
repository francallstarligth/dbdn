package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val KEEP = "Lapp/eclipse/extension/canvas/CanvasKeepAlive;"

/**
 * v0.20.197 (SIN COMPILAR NI PROBAR). Eclipse 0.6.57: la pantalla del video animado (Canvas y portadas animadas de Tidal /
 * Apple; n34.h, que llaman 7 sitios) crea su ExoPlayer con n34.v dentro de un `remember`, y al salir de la pantalla (cerrar
 * el reproductor, ir a Letra o Cola) el efecto de limpieza (f80 caso 0 -> Gn caso 5) quita el oyente i80 y LIBERA el video
 * (gz2.p3). Al volver se crea otro desde cero (reinicia y vuelve a cargar). Este parche lo PAUSA y lo guarda (maximo 2, 2 min)
 * y lo reutiliza si se pide el mismo video. Tres ganchos (verificados en el dex 0.6.57, una sola coincidencia cada uno):
 *
 * 1) n34.h, justo antes de `n34.v(Context, url, cap, flag)` (una sola llamada; el resultado va a v14): se llama a
 *    `CanvasKeepAlive.take(url, cap, flag)`; si devuelve un video guardado se salta n34.v (queda en v14 y sigue con el
 *    `remember`); si devuelve null sigue normal y, despues de n34.v, `register(player, url, cap, flag)` anota su clave.
 * 2) f80.invoke (caso del oyente i80 = n34.h): despues de `gz2.D.a(i80)` (registrar el oyente), `onAttached(player, oyente)`:
 *    si el video venia de la caja y ya esta listo (estado 3), llama a mano a i80.u(3) (el aviso "listo" no se repetiria
 *    solo y el video quedaria escondido, porque el estado de n34.h arranca en falso).
 * 3) Gn.a (caso 5, el que tiene `check-cast i80`): la llamada `gz2.p3()` (release) se cambia por `release(player, oyente)`,
 *    que pausa (gz2.e0(false)) y guarda, o libera si no se puede. Gn caso 15 (j02.o, oyente i86) no se toca.
 *
 * Nombres por reflexion en la extension (el dex esta ofuscado): gz2.m() = estado, gz2.e0(Z) = setPlayWhenReady,
 * gz2.p3() = release, i80.u(I) = onPlaybackStateChanged. Todo falla "a lo de antes" (liberar) si algo no cuadra.
 */
@Suppress("unused")
val canvasKeepAlivePatch = bytecodePatch(
    name = "Canvas: mantener el video vivo (pausar al salir)",
    description = "Al salir del reproductor o ir a Letra/Cola, el video de la portada animada (Canvas, Tidal, Apple) no se " +
        "destruye: se pausa y se guarda unos minutos, y al volver sigue donde estaba sin recargar. Gasta algo mas de memoria " +
        "(guarda hasta 2 videos pausados). Experimental.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) n34.h: take antes de n34.v, register despues ----
        val n34 = mutableClassDefBy(classDefBy("Ln34;"))
        val h = n34.methods.singleOrNull { m ->
            m.parameterTypes.map { it.toString() } == listOf(
                "Ljava/lang/String;", "Lou5;", "Z", "I", "I", "Z", "Lje3;", "Lcq1;", "I", "I"
            ) && m.returnType == "V"
        } ?: error("No se encontro n34.h(String, ou5, Z, I, I, Z, je3, cq1, I, I) (version de Eclipse distinta de 0.6.57?)")
        val hi = (h.implementation ?: error("n34.h sin codigo")).instructions.toList()

        val vHits = hi.indices.filter { i ->
            val ref = (hi[i] as? ReferenceInstruction)?.reference as? MethodReference
            hi[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Ln34;" && ref.name == "v" &&
                ref.parameterTypes.map { it.toString() } == listOf("Landroid/content/Context;", "Ljava/lang/String;", "I", "Z") &&
                ref.returnType == "Lgz2;"
        }
        if (vHits.size != 1) error("n34.h: se esperaba 1 llamada a n34.v (hay ${vHits.size})")
        val callAt = vHits[0]
        val call = hi[callAt] as FiveRegisterInstruction
        val mr = hi.getOrNull(callAt + 1)
        if (mr == null || mr.opcode != Opcode.MOVE_RESULT_OBJECT) error("n34.h: tras n34.v se esperaba move-result-object")
        val outReg = (mr as OneRegisterInstruction).registerA
        val urlReg = call.registerD
        val capReg = call.registerE
        val flagReg = call.registerF
        if (call.registerCount != 4) error("n34.h: n34.v debia tener 4 registros")
        if (outReg > 15 || urlReg > 15 || capReg > 15 || flagReg > 15) error("n34.h: registros fuera de v0..v15")
        if (outReg == urlReg || outReg == capReg || outReg == flagReg) error("n34.h: el registro del resultado choca con un argumento")

        // Primero lo de DESPUES (para no mover el indice de lo de antes): register tras el move-result.
        h.addInstructions(
            callAt + 2,
            "invoke-static {v$outReg, v$urlReg, v$capReg, v$flagReg}, $KEEP->register(Ljava/lang/Object;Ljava/lang/String;IZ)V"
        )
        // La instruccion que sigue es el `n0` del remember (ahora en callAt + 3): a ella salta take si trajo un video.
        val have = h.getInstruction(callAt + 3)
        h.addInstructionsWithLabels(
            callAt,
            """
                invoke-static {v$urlReg, v$capReg, v$flagReg}, $KEEP->take(Ljava/lang/String;IZ)Ljava/lang/Object;
                move-result-object v$outReg
                if-nez v$outReg, :keepalive_have
            """,
            ExternalLabel("keepalive_have", have)
        )

        // ---- 2) f80.invoke: onAttached tras registrar el oyente i80 ----
        val f80 = mutableClassDefBy(classDefBy("Lf80;"))
        val inv = f80.methods.singleOrNull { m ->
            m.name == "invoke" && m.returnType == "Ljava/lang/Object;" &&
                m.parameterTypes.map { it.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro f80.invoke (version de Eclipse distinta de 0.6.57?)")
        val fi = (inv.implementation ?: error("f80.invoke sin codigo")).instructions.toList()

        val newI80 = fi.indices.filter { i ->
            val ref = (fi[i] as? ReferenceInstruction)?.reference as? TypeReference
            fi[i].opcode == Opcode.NEW_INSTANCE && ref != null && ref.type == "Li80;"
        }
        if (newI80.size != 1) error("f80.invoke: se esperaba 1 new-instance i80 (hay ${newI80.size})")
        val listenerReg = (fi[newI80[0]] as OneRegisterInstruction).registerA
        val addAt = fi.indices.firstOrNull { i ->
            val ref = (fi[i] as? ReferenceInstruction)?.reference as? MethodReference
            i > newI80[0] && fi[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Lj15;" &&
                ref.name == "a" && ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("f80.invoke: no se encontro j15.a(Object) tras new-instance i80")
        val addCall = fi[addAt] as FiveRegisterInstruction
        if (addCall.registerCount != 2 || addCall.registerD != listenerReg) error("f80.invoke: j15.a no recibe el oyente i80")
        // El jugador: el `move-object vHolder, vJugador` anterior (holder = registerC de j15.a).
        val holderReg = addCall.registerC
        val moveAt = (addAt - 1 downTo newI80[0]).firstOrNull { i ->
            fi[i].opcode == Opcode.MOVE_OBJECT && (fi[i] as TwoRegisterInstruction).registerA == holderReg
        } ?: error("f80.invoke: no se encontro el move-object del jugador")
        val playerReg = (fi[moveAt] as TwoRegisterInstruction).registerB
        if (playerReg > 15 || listenerReg > 15) error("f80.invoke: registros fuera de v0..v15")
        inv.addInstructions(
            addAt + 1,
            "invoke-static {v$playerReg, v$listenerReg}, $KEEP->onAttached(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        // ---- 3) Gn.a (caso 5): p3() -> release(player, oyente) ----
        val gn = mutableClassDefBy(classDefBy("Lgn;"))
        val a = gn.methods.singleOrNull { it.name == "a" && it.parameterTypes.isEmpty() && it.returnType == "V" }
            ?: error("No se encontro Gn.a() (version de Eclipse distinta de 0.6.57?)")
        val gi = (a.implementation ?: error("Gn.a sin codigo")).instructions.toList()

        val relHits = gi.indices.filter { i ->
            val ref = (gi[i] as? ReferenceInstruction)?.reference as? MethodReference
            if (gi[i].opcode != Opcode.INVOKE_VIRTUAL || ref == null || ref.definingClass != "Lgz2;" ||
                ref.name != "p3" || ref.parameterTypes.isNotEmpty()
            ) return@filter false
            // el caso 5 es el que tiene `check-cast ..., Li80;` pocas instrucciones antes (el caso 15 usa Li86)
            (maxOf(0, i - 12) until i).any { q ->
                val t = (gi[q] as? ReferenceInstruction)?.reference as? TypeReference
                gi[q].opcode == Opcode.CHECK_CAST && t != null && t.type == "Li80;"
            }
        }
        if (relHits.size != 1) error("Gn.a: se esperaba 1 llamada gz2.p3() del caso i80 (hay ${relHits.size})")
        val relAt = relHits[0]
        val relCall = gi[relAt] as FiveRegisterInstruction
        if (relCall.registerCount != 1) error("Gn.a: gz2.p3() debia tener 1 registro")
        val relPlayer = relCall.registerC
        val castAt = (relAt - 1 downTo maxOf(0, relAt - 12)).first { q ->
            val t = (gi[q] as? ReferenceInstruction)?.reference as? TypeReference
            gi[q].opcode == Opcode.CHECK_CAST && t != null && t.type == "Li80;"
        }
        val relListener = (gi[castAt] as OneRegisterInstruction).registerA
        if (relPlayer > 15 || relListener > 15) error("Gn.a: registros fuera de v0..v15")
        a.addInstructions(
            relAt,
            "invoke-static {v$relPlayer, v$relListener}, $KEEP->release(Ljava/lang/Object;Ljava/lang/Object;)V"
        )
        a.removeInstruction(relAt + 1) // la llamada vieja a gz2.p3() quedo una instruccion mas abajo
    }
}
