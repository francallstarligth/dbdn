package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val ENTER = "Lapp/eclipse/extension/player/PlayerEnter;"

/**
 * EXPERIMENTO (v1.97.6, sin compilar ni probar). Animacion de entrada (deslizar de abajo hacia arriba) del reproductor
 * grande. dr8.a lee `jr.d()` (desplazamiento Y de la hoja, arranca en 0) y lo divide por el alto (`div-float/2addr`).
 * Justo despues de esa division se llama a PlayerEnter.hook(jr); la extension detecta una hoja nueva y anima el valor
 * del jr desde el alto de pantalla hasta 0. No toca la salida. Se apaga desmarcando el parche.
 */
@Suppress("unused")
val playerEnterAnimationPatch = bytecodePatch(
    name = "Animacion: entrada del reproductor (experimento)",
    description = "Experimento. El reproductor grande sube desde abajo al abrirse en vez de aparecer de golpe. " +
        "No cambia la salida. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val dr8 = mutableClassDefBy(classDefBy("Ldr8;"))
        val m = dr8.methods.singleOrNull {
            it.name == "a" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ld43;", "F", "Z", "Ld43;", "Lub3;", "Laf1;", "Lki1;", "I", "I")
        } ?: error("No se encontro dr8.a")
        val ins = (m.implementation ?: error("dr8.a sin codigo")).instructions.toList()
        // pares (invoke-virtual/range jr.d(), div-float/2addr que viene despues)
        val pares = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_VIRTUAL_RANGE && r != null && r.definingClass == "Ljr;" &&
                r.name == "d" && r.parameterTypes.isEmpty()
        }.mapNotNull { h ->
            val d = (h + 1..minOf(h + 8, ins.size - 1)).firstOrNull { ins[it].opcode == Opcode.DIV_FLOAT_2ADDR }
            if (d == null) null else h to d
        }
        if (pares.size != 1) error("dr8.a: se esperaba 1 jr.d()+division (hay ${pares.size})")
        val (h, div) = pares[0]
        val jrReg = (ins[h] as RegisterRangeInstruction).startRegister
        m.addInstructions(div + 1, "invoke-static/range {v$jrReg .. v$jrReg}, $ENTER->hook(Ljava/lang/Object;)V")
    }
}
