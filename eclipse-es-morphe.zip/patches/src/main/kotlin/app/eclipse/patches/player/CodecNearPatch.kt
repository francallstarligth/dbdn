package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val NEAR = "Lapp/eclipse/extension/player/CodecNear;"

/**
 * v0.20.402 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Codec (capa Quality Badge) pegado al final del texto real del titulo (Tocadiscos).
 * Ver `CodecNear.java` (convencion de diseno y medida del texto). Dos ganchos, ambos con el mismo patron que `ArmSeekPatch.kt` y compatibles con el:
 *  (1) `Lpr7;.invoke` (lambda de graphicsLayer, caso `iget-object vA, vB, Lv51;->d` + `iget-wide mv4.e` + `Loq3.e/p/i/m`): antes del iget se guarda la capa
 *      en un registro libre vS (5..15, comprobado que nadie lo usa hasta el return); antes del `return-object` se llama `CodecNear.dx(capa)` y se aplica
 *      con `invoke-interface {v1, vS}, Loq3;->r(F)V` (translationX; en `Lmw8` r escribe el 4o campo u de GraphicsLayerScope, despues de scaleX/scaleY/alpha).
 *  (2) `Lh61.<init>` (unico return-void): `CodecNear.fromState(this)` (titulo de la cancion = `Song.title`).
 */
@Suppress("unused")
val codecNearPatch = bytecodePatch(
    name = "Tocadiscos: codec pegado al titulo",
    description = "La capa Quality Badge (FLAC, OPUS...) cuyo nombre empiece con \"Codec\" (ej. \"Codec titulo\") se corre sola hasta el final del texto real de la capa Song Title (se mide con la fuente Inter del " +
        "app). En el diseno hay que poner el codec con su borde izquierdo en el inicio del titulo; el parche lo empuja el ancho del texto + 8 dp, y si el " +
        "titulo es mas largo que su caja lo deja al final de la caja. Pensado para el diseno Tocadiscos. Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (1) traslacion X del codec
        run {
            val cls = mutableClassDefBy(classDefBy("Lpr7;"))
            val m = cls.methods.singleOrNull {
                it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes == listOf("Ljava/lang/Object;")
            } ?: error("Codec: no se encontro Lpr7.invoke")
            val ins = (m.implementation ?: error("Codec: Lpr7.invoke sin codigo")).instructions.toList()
            val rd = ins.indices.filter { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
                ins[i].opcode == Opcode.IGET_WIDE && r != null && r.definingClass == "Lmv4;" && r.name == "e"
            }
            if (rd.size != 1) error("Codec: se esperaba 1 lectura de mv4.e en Lpr7.invoke y hay ${rd.size}")
            val iw = rd[0]
            val getL = ins[iw - 1]
            val gr = (getL as? ReferenceInstruction)?.reference as? FieldReference
            if (getL.opcode != Opcode.IGET_OBJECT || gr == null || gr.definingClass != "Lv51;" || gr.name != "d")
                error("Codec: antes de mv4.e no viene iget-object v51.d")
            val layerReg = (getL as TwoRegisterInstruction).registerB
            if (layerReg > 15) error("Codec: registro alto para la capa (v$layerReg)")
            val ret = ins.indices.firstOrNull { it > iw && ins[it].opcode == Opcode.RETURN_OBJECT }
                ?: error("Codec: no se encontro el return-object del caso")
            // el receptor de Loq3 debe ser v1 (como en `invoke-interface {v1, v3}, Loq3;->e(F)V`)
            val eCall = ins.indices.firstOrNull { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
                i > iw && i < ret && ins[i].opcode == Opcode.INVOKE_INTERFACE && r != null && r.definingClass == "Loq3;" &&
                    r.name == "e" && r.parameterTypes == listOf("F")
            } ?: error("Codec: no se encontro Loq3.e(F) en Lpr7.invoke")
            if ((ins[eCall] as FiveRegisterInstruction).registerC != 1) error("Codec: el receptor de Loq3 no es v1")
            // no debe existir ya una llamada a Loq3.r (translationX) en este caso
            val yaTraslada = ins.indices.any { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
                i in iw..ret && ins[i].opcode == Opcode.INVOKE_INTERFACE && r != null && r.definingClass == "Loq3;" && r.name == "r"
            }
            if (yaTraslada) error("Codec: este caso de Lpr7.invoke ya usa Loq3.r (translationX)")
            // registro libre vS (5..15) en [iw-1..ret]
            fun usa(x: com.android.tools.smali.dexlib2.iface.instruction.Instruction, reg: Int): Boolean {
                val a = (x is OneRegisterInstruction && (x.registerA == reg || x.registerA + 1 == reg))
                val b = (x is TwoRegisterInstruction && (x.registerB == reg || x.registerB + 1 == reg))
                val c = (x is ThreeRegisterInstruction && (x.registerC == reg || x.registerC + 1 == reg))
                val f = (x is FiveRegisterInstruction && listOf(x.registerC, x.registerD, x.registerE, x.registerF, x.registerG)
                    .take(x.registerCount).contains(reg))
                val g = (x is RegisterRangeInstruction && reg >= x.startRegister && reg < x.startRegister + x.registerCount)
                return a || b || c || f || g
            }
            val vS = (5..15).firstOrNull { r -> (iw - 1..ret).none { usa(ins[it], r) } }
                ?: error("Codec: no hay registro libre en Lpr7.invoke")
            // 1o el de despues (para no mover los indices), 2o el de antes.
            m.addInstructions(
                ret,
                """
                    invoke-static {v$vS}, $NEAR->dx(Ljava/lang/Object;)F
                    move-result v$vS
                    invoke-interface {v1, v$vS}, Loq3;->r(F)V
                """
            )
            m.addInstructions(iw - 1, "move-object v$vS, v$layerReg")
        }

        // (2) titulo de la cancion (Song.title) desde el estado del reproductor
        run {
            val cls = mutableClassDefBy(classDefBy("Lh61;"))
            val m = cls.methods.singleOrNull { it.name == "<init>" && it.parameterTypes.size == 26 }
                ?: error("Codec: no se encontro Lh61.<init>")
            val ins = (m.implementation ?: error("Codec: Lh61.<init> sin codigo")).instructions.toList()
            val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
            if (ret.size != 1) error("Codec: se esperaba 1 return-void en Lh61.<init> y hay ${ret.size}")
            m.addInstructions(ret[0], "invoke-static {p0}, $NEAR->fromState(Ljava/lang/Object;)V")
        }
    }
}
