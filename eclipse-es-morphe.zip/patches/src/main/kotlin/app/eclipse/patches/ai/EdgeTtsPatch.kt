package app.eclipse.patches.ai

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EDGE = "Lapp/eclipse/extension/ai/EdgeTts;"

/**
 * v0.20.241 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). El gancho no cambia (misma llamada a
 * `EdgeTts.speak(texto, voz, gradium)`), pero la cadena ahora es: Gradium (con la llave que la persona escribe en la pantalla
 * "Cartesia Sonic" de Eclipse, formato `LLAVE` o `LLAVE@IDVOZ`) -> Cloudflare (voz celeste, via el Worker) -> Edge.
 * `gradium_voice` pasa a ser la voz por defecto de Gradium; vacio o `x` = solo Edge.
 *
 * v0.20.239 (SIN COMPILAR NI PROBAR). Anade la opcion `gradium_voice`: `EdgeTts.speak(texto, voz, gradium)` prueba Gradium
 * primero (si el ID no esta vacio) y cae a Edge. v4 se usa para el ID (libre aqui; se reasigna con `new-instance v4`).
 *
 * v0.20.237 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Apagado por defecto.
 *
 * La voz del DJ se pide en `Lsb.invokeSuspend` (corrutina IO; caso con la cadena "TTSApiClient"): arma el JSON y hace
 * POST a api.eclipsemusic.app/api/tts; devuelve `Lyy9(String proveedor, byte[] audio)` o null. Gancho: justo despues de
 * `check-cast v14, Ljava/util/Map;` (v13 = texto) se llama `EdgeTts.speak(texto, voz)`; si da audio, se devuelve
 * `new Lyy9("", audio)` y listo; si da null, sigue el codigo original. v3, v4, v5 se reasignan mas abajo (libres aqui);
 * v6 NO (guarda "POST"). El audio MP3 lo reproduce `m0.c` con MediaPlayer (detecta el formato por contenido).
 * Requisito: que `dz9.a` llegue a `Lsb` (hay un proveedor de voz "configurado": Groq con llave local, que ya pone FreeAi).
 */
@Suppress("unused")
val edgeTtsPatch = bytecodePatch(
    name = "Voz del DJ: Edge TTS",
    description = "El DJ habla con la voz neuronal de Microsoft Edge (gratis, sin llave), pedida directo desde el telefono. " +
        "Opcional: Gradium primero (la persona pega su propia llave en la pantalla \"Cartesia Sonic\"; formato LLAVE o LLAVE@IDVOZ), " +
        "luego Cloudflare (voz celeste, sin llave) y Edge de respaldo. " +
        "Servicio no oficial: puede dejar de andar. Si falla, la app usa su camino normal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val voice by stringOption(
        key = "voice",
        default = "es-MX-DaliaNeural",
        title = "Voz de Edge",
        description = "Nombre de la voz. Espanol: es-MX-DaliaNeural, es-MX-JorgeNeural, es-PE-CamilaNeural, es-PE-AlexNeural, " +
            "es-ES-ElviraNeural, es-AR-ElenaNeural, es-CO-SalomeNeural."
    )

    val gradiumVoice by stringOption(
        key = "gradium_voice",
        default = "zGR5bDCThKBOm4de",
        title = "Voz de Gradium (ID)",
        description = "Voz de Gradium por defecto (ID). Se usa si la persona pega solo su llave; si pega LLAVE@IDVOZ manda esa voz. " +
            "El DJ prueba Gradium (si hay llave), luego Cloudflare y luego Edge. Pon x o dejalo VACIO para usar solo Edge."
    )

    execute {
        val cls = mutableClassDefBy(classDefBy("Lsb;"))
        val m = cls.methods.singleOrNull {
            it.name == "invokeSuspend" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("Edge TTS: no se encontro Lsb.invokeSuspend (version de Eclipse distinta de 0.6.61?)")
        val ins = (m.implementation ?: error("Edge TTS: Lsb.invokeSuspend sin codigo")).instructions.toList()

        val tagAt = ins.indexOfFirst {
            it.opcode == Opcode.CONST_STRING &&
                ((it as ReferenceInstruction).reference as? StringReference)?.string == "TTSApiClient"
        }
        if (tagAt < 0) error("Edge TTS: no se encontro 'TTSApiClient' en Lsb.invokeSuspend")

        // Primer `check-cast v14, Ljava/util/Map;` despues de la etiqueta
        var at = -1
        for (i in tagAt until ins.size) {
            val x = ins[i]
            if (x.opcode == Opcode.CHECK_CAST &&
                (x as OneRegisterInstruction).registerA == 14 &&
                ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/Map;"
            ) { at = i; break }
            if (i - tagAt > 60) break
        }
        if (at < 0) error("Edge TTS: no se encontro 'check-cast v14, Map' tras TTSApiClient")

        // Esperado justo antes: check-cast v13 String ; check-cast v12 List ; y despues const-string v3 "text"
        val prev2 = ins[at - 2]
        val after = ins[at + 1]
        if (prev2.opcode != Opcode.CHECK_CAST || (prev2 as OneRegisterInstruction).registerA != 13 ||
            after.opcode != Opcode.CONST_STRING ||
            ((after as ReferenceInstruction).reference as? StringReference)?.string != "text"
        ) error("Edge TTS: la secuencia alrededor de TTSApiClient no es la esperada")

        if (m.implementation!!.registerCount < 15) error("Edge TTS: pocos registros en Lsb.invokeSuspend")

        val v = (voice ?: "es-MX-DaliaNeural").trim().ifEmpty { "es-MX-DaliaNeural" }.replace("\"", "")

        val g = (gradiumVoice ?: "").trim().replace("\"", "")

        m.addInstructionsWithLabels(
            at + 1,
            """
            const-string v5, "$v"
            const-string v4, "$g"
            invoke-static {v13, v5, v4}, $EDGE->speak(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
            move-result-object v3
            if-eqz v3, :edge_none
            const-string v5, ""
            new-instance v4, Lyy9;
            invoke-direct {v4, v5, v3}, Lyy9;-><init>(Ljava/lang/String;[B)V
            return-object v4
            :edge_none
            nop
            """
        )
    }
}
