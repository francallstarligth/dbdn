package app.eclipse.patches.ai

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EDGE = "Lapp/eclipse/extension/ai/EdgeTts;"

/**
 * v0.20.297 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). El pedido TTS ahora esta en `Lmd.b(Object)` (antes dentro de invokeSuspend). Gancho nuevo: justo despues de `check-cast v3, String` (texto); v4/v5 libres; se devuelve `new Loma(audio, "")`.
 *
 * v0.20.271 (SIN COMPILAR NI PROBAR; Eclipse 0.6.73). Lld->Lmd, Lxia->Lhka. OJO: en 0.6.73 el constructor de Lhka cambio el orden de parametros:
 * ahora es `<init>([B, String)` (audio, proveedor), asi que se llama con {v13, v5, v4}. Registros y secuencia de Lmd.invokeSuspend iguales a 0.6.70
 * (verificado con cmp.py: solo cambian esas dos llamadas). Mensajes de error actualizados a 0.6.73.
 *
 * v0.20.316 (SIN COMPILAR NI PROBAR). Se quita la opcion `gradium_voice`: el gancho pasa "" como tercer argumento y la cadena
 * Gradium (solo si la llave trae LLAVE@IDVOZ) -> Cloudflare -> Edge corre siempre (`EdgeTts.chainEnabled` = true).
 *
 * v0.20.245 (SIN COMPILAR NI PROBAR; Eclipse 0.6.70). Lsb->Lld, Lyy9->Loma; el Map ahora esta en v12 (antes v14) y v3 es el JSONObject vivo:
 * resultado en v5, respuesta en v13. Chequeos: check-cast v13 String antes del check-cast v12 Map, y despues const-string "text".
 *
 * v0.20.241 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). El gancho no cambia (misma llamada a
 * `EdgeTts.speak(texto, voz, gradium)`), pero la cadena ahora es: Gradium (con la llave que la persona escribe en la pantalla
 * "Cartesia Sonic" de Eclipse, formato `LLAVE` o `LLAVE@IDVOZ`) -> Cloudflare (voz celeste, via el Worker) -> Edge.
 * `gradium_voice` pasa a ser la voz por defecto de Gradium; vacio o `x` = solo Edge.
 *
 * v0.20.239 (SIN COMPILAR NI PROBAR). Anade la opcion `gradium_voice`: `EdgeTts.speak(texto, voz, gradium)` prueba Gradium
 * primero (si el ID no esta vacio) y cae a Edge. v4 se usa para el ID (libre aqui; se reasigna con `new-instance v4`).
 *
 * v0.20.237 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Apagado por defecto.
 *
 * La voz del DJ se pide en `Lsb.invokeSuspend` (corrutina IO; caso con la cadena "TTSApiClient"): arma el JSON y hace
 * POST a api.eclipsemusic.app/api/tts; devuelve `Lyy9(String proveedor, byte[] audio)` o null. Gancho: justo despues de
 * `check-cast v14, Ljava/util/Map;` (v13 = texto) se llama `EdgeTts.speak(texto, voz)`; si da audio, se devuelve
 * `new Lyy9("", audio)` y listo; si da null, sigue el codigo original. v3, v4, v5 se reasignan mas abajo (libres aqui);
 * v6 NO (guarda "POST"). El audio MP3 lo reproduce `m0.c` con MediaPlayer (detecta el formato por contenido).
 * Requisito: que `dz9.a` llegue a `Lsb` (hay un proveedor de voz "configurado": Groq con llave local, que ya pone FreeAi).
 */
@Suppress("unused")
val edgeTtsPatch = bytecodePatch(
    name = "Voz del DJ: Edge TTS",
    description = "El DJ habla con la voz neuronal de Microsoft Edge (gratis, sin llave), pedida directo desde el telefono. " +
        "Opcional: Gradium primero (la persona pega su propia llave en la pantalla \"Cartesia Sonic\"; formato LLAVE o LLAVE@IDVOZ), " +
        "luego Cloudflare (voz celeste, sin llave) y Edge de respaldo. " +
        "Servicio no oficial: puede dejar de andar. Si falla, la app usa su camino normal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val voice by stringOption(
        key = "voice",
        default = "es-MX-DaliaNeural",
        title = "Voz de Edge",
        description = "Nombre de la voz. Espanol: es-MX-DaliaNeural, es-MX-JorgeNeural, es-PE-CamilaNeural, es-PE-AlexNeural, " +
            "es-ES-ElviraNeural, es-AR-ElenaNeural, es-CO-SalomeNeural."
    )

    execute {
        // 0.6.75: el pedido TTS salio de invokeSuspend a su propio metodo `Lmd;->b(Object)Object` (caso 1 de la corrutina).
        // Se busca por la cadena "TTSApiClient" en su primera instruccion (no depende del nombre del metodo).
        val cls = mutableClassDefBy(classDefBy("Lmd;"))
        val m = cls.methods.singleOrNull {
            val first = it.implementation?.instructions?.firstOrNull()
            first != null && first.opcode == Opcode.CONST_STRING &&
                ((first as ReferenceInstruction).reference as? StringReference)?.string == "TTSApiClient" &&
                it.returnType == "Ljava/lang/Object;" && it.parameterTypes.size == 1
        } ?: error("Edge TTS: no se encontro el metodo con 'TTSApiClient' en Lmd (version de Eclipse distinta de 0.6.75?)")
        val ins = m.implementation!!.instructions.toList()
        if (m.implementation!!.registerCount < 8) error("Edge TTS: pocos registros en Lmd.b")

        // Esperado (0.6.75): iget-object v3 <- Lmd.t ; check-cast v3 String ; iget-object v4 <- Lmd.u ; check-cast v4 List
        var at = -1
        for (i in 0 until minOf(ins.size, 40)) {
            val x = ins[i]
            if (x.opcode == Opcode.CHECK_CAST &&
                (x as OneRegisterInstruction).registerA == 3 &&
                ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            ) { at = i; break }
        }
        if (at < 0) error("Edge TTS: no se encontro 'check-cast v3, String' en Lmd.b")
        val nx = ins[at + 1]; val nx2 = ins[at + 2]
        if (nx.opcode != Opcode.IGET_OBJECT || (nx as TwoRegisterInstruction).registerA != 4 ||
            nx2.opcode != Opcode.CHECK_CAST || (nx2 as OneRegisterInstruction).registerA != 4 ||
            ((nx2 as ReferenceInstruction).reference as? TypeReference)?.type != "Ljava/util/List;"
        ) error("Edge TTS: la secuencia tras el texto no es la esperada (0.6.75)")

        val v = (voice ?: "es-MX-DaliaNeural").trim().ifEmpty { "es-MX-DaliaNeural" }.replace("\"", "")

        // 0.6.75: v3 = texto (String), v4 y v5 libres aqui (se reasignan mas abajo), v2 = null, v0/v1/v7 NO se tocan.
        m.addInstructionsWithLabels(
            at + 1,
            """
            const-string v5, "$v"
            const-string v4, ""
            invoke-static {v3, v5, v4}, $EDGE->speak(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
            move-result-object v5
            if-eqz v5, :edge_none
            const-string v4, ""
            new-instance v3, Loma;
            invoke-direct {v3, v5, v4}, Loma;-><init>([BLjava/lang/String;)V
            return-object v3
            :edge_none
            nop
            """
        )
    }
}
