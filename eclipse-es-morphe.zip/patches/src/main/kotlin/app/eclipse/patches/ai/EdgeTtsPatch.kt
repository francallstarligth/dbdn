package app.eclipse.patches.ai

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.SwitchPayload
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EDGE = "Lapp/eclipse/extension/ai/EdgeTts;"
private const val PHONON = "Lapp/eclipse/extension/ai/PhononTts;"

/**
 * v0.20.349 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Phonon tambien con \"Device Voice\" y sin llave: (1) `Ltma;->a(String, Continuation)` (TTSManager) saltaba el pedido
 * remoto cuando no habia ninguna llave (if-nez tras el 2o `ArrayList.isEmpty`, destino `sget-object Lwma;->SYSTEM`); se quita ese salto para que corra `Lmd.b`
 * (donde ya esta el gancho de EdgeTts/Phonon). (2) El boton \"Vista previa\" (`Lv39.invokeSuspend`) llamaba `Lm0;->e(String)` (voz del sistema directo);
 * ahora llama `Lm0;->d(String, null, cont)` (la cadena completa) y el texto es en espanol. (3) \"Device Voice\" -> \"Phonon\" (`Lwma.getDisplayName`/`getProviderNote`)
 * y textos de la tarjeta (`Lj1.b`). (4) Tarjeta \"CHANGE THE VOICE\" (`Lsr1.r`, caso 14 del packed-switch): `return-object v20` (Unit) tras su primera instruccion.
 *
 * v0.20.348 (SIN COMPILAR NI PROBAR). Opcion nueva `phonon_temperature` (texto, por defecto 0.7): antes de `EdgeTts.speak` se llama
 * `PhononTts.configTemp(String)` (v5 libre aqui). Valor invalido o fuera de 0.1-2.0 = 0.7.
 *
 * v0.20.297 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). El pedido TTS ahora esta en `Lmd.b(Object)` (antes dentro de invokeSuspend). Gancho nuevo: justo despues de `check-cast v3, String` (texto); v4/v5 libres; se devuelve `new Loma(audio, "")`.
 *
 * v0.20.271 (SIN COMPILAR NI PROBAR; Eclipse 0.6.73). Lld->Lmd, Lxia->Lhka. OJO: en 0.6.73 el constructor de Lhka cambio el orden de parametros:
 * ahora es `<init>([B, String)` (audio, proveedor), asi que se llama con {v13, v5, v4}. Registros y secuencia de Lmd.invokeSuspend iguales a 0.6.70
 * (verificado con cmp.py: solo cambian esas dos llamadas). Mensajes de error actualizados a 0.6.73.
 *
 * v0.20.316 (SIN COMPILAR NI PROBAR). Se quita la opcion `gradium_voice`: el gancho pasa "" como tercer argumento y la cadena
 * Gradium (solo si la llave trae LLAVE@IDVOZ) -> Cloudflare -> Edge corre siempre (`EdgeTts.chainEnabled` = true).
 *
 * v0.20.245 (SIN COMPILAR NI PROBAR; Eclipse 0.6.70). Lsb->Lld, Lyy9->Loma; el Map ahora esta en v12 (antes v14) y v3 es el JSONObject vivo:
 * resultado en v5, respuesta en v13. Chequeos: check-cast v13 String antes del check-cast v12 Map, y despues const-string "text".
 *
 * v0.20.241 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). El gancho no cambia (misma llamada a
 * `EdgeTts.speak(texto, voz, gradium)`), pero la cadena ahora es: Gradium (con la llave que la persona escribe en la pantalla
 * "Cartesia Sonic" de Eclipse, formato `LLAVE` o `LLAVE@IDVOZ`) -> Cloudflare (voz celeste, via el Worker) -> Edge.
 * `gradium_voice` pasa a ser la voz por defecto de Gradium; vacio o `x` = solo Edge.
 *
 * v0.20.239 (SIN COMPILAR NI PROBAR). Anade la opcion `gradium_voice`: `EdgeTts.speak(texto, voz, gradium)` prueba Gradium
 * primero (si el ID no esta vacio) y cae a Edge. v4 se usa para el ID (libre aqui; se reasigna con `new-instance v4`).
 *
 * v0.20.237 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Apagado por defecto.
 *
 * La voz del DJ se pide en `Lsb.invokeSuspend` (corrutina IO; caso con la cadena "TTSApiClient"): arma el JSON y hace
 * POST a api.eclipsemusic.app/api/tts; devuelve `Lyy9(String proveedor, byte[] audio)` o null. Gancho: justo despues de
 * `check-cast v14, Ljava/util/Map;` (v13 = texto) se llama `EdgeTts.speak(texto, voz)`; si da audio, se devuelve
 * `new Lyy9("", audio)` y listo; si da null, sigue el codigo original. v3, v4, v5 se reasignan mas abajo (libres aqui);
 * v6 NO (guarda "POST"). El audio MP3 lo reproduce `m0.c` con MediaPlayer (detecta el formato por contenido).
 * Requisito: que `dz9.a` llegue a `Lsb` (hay un proveedor de voz "configurado": Groq con llave local, que ya pone FreeAi).
 */
@Suppress("unused")
val edgeTtsPatch = bytecodePatch(
    name = "Voz del DJ: Edge TTS",
    description = "El DJ habla con la voz neuronal de Microsoft Edge (gratis, sin llave), pedida directo desde el telefono. " +
        "Opcional: Gradium primero (la persona pega su propia llave en la pantalla \"Cartesia Sonic\"; formato LLAVE o LLAVE@IDVOZ), " +
        "luego Cloudflare (voz celeste, sin llave) y Edge de respaldo. " +
        "Servicio no oficial: puede dejar de andar. Si falla, la app usa su camino normal. " +
        "Tambien: \"Device Voice\" pasa a llamarse Phonon y suena con Phonon aunque no haya ninguna llave; se quita la tarjeta \"Change the voice\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val voice by stringOption(
        key = "voice",
        default = "es-MX-DaliaNeural",
        title = "Voz de Edge",
        description = "Nombre de la voz. Espanol: es-MX-DaliaNeural, es-MX-JorgeNeural, es-PE-CamilaNeural, es-PE-AlexNeural, " +
            "es-ES-ElviraNeural, es-AR-ElenaNeural, es-CO-SalomeNeural."
    )

    val phononTemp by stringOption(
        key = "phonon_temperature",
        default = "0.7",
        title = "Temperatura de Phonon",
        description = "Voz local Phonon. Mas baja (0.6) = mas estable y plana; mas alta (1.0) = mas expresiva pero con mas errores. Entre 0.1 y 2.0; si no es un numero queda 0.7."
    )

    val phononPausas by booleanOption(
        key = "phonon_pausas",
        default = true,
        title = "Pausas en las comas de Phonon",
        description = "Antes de dar el texto a Phonon pone \"..\" despues de cada coma y de cada raya (\u2014) para empujarlo a hacer pausa. Es un truco: si no suena bien, desmarcalo y vuelve a parchear."
    )

    execute {
        // 0.6.75: el pedido TTS salio de invokeSuspend a su propio metodo `Lmd;->b(Object)Object` (caso 1 de la corrutina).
        // Se busca por la cadena "TTSApiClient" en su primera instruccion (no depende del nombre del metodo).
        val cls = mutableClassDefBy(classDefBy("Lmd;"))
        val m = cls.methods.singleOrNull {
            val first = it.implementation?.instructions?.firstOrNull()
            first != null && first.opcode == Opcode.CONST_STRING &&
                ((first as ReferenceInstruction).reference as? StringReference)?.string == "TTSApiClient" &&
                it.returnType == "Ljava/lang/Object;" && it.parameterTypes.size == 1
        } ?: error("Edge TTS: no se encontro el metodo con 'TTSApiClient' en Lmd (version de Eclipse distinta de 0.6.75?)")
        val ins = m.implementation!!.instructions.toList()
        if (m.implementation!!.registerCount < 8) error("Edge TTS: pocos registros en Lmd.b")

        // Esperado (0.6.75): iget-object v3 <- Lmd.t ; check-cast v3 String ; iget-object v4 <- Lmd.u ; check-cast v4 List
        var at = -1
        for (i in 0 until minOf(ins.size, 40)) {
            val x = ins[i]
            if (x.opcode == Opcode.CHECK_CAST &&
                (x as OneRegisterInstruction).registerA == 3 &&
                ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            ) { at = i; break }
        }
        if (at < 0) error("Edge TTS: no se encontro 'check-cast v3, String' en Lmd.b")
        val nx = ins[at + 1]; val nx2 = ins[at + 2]
        if (nx.opcode != Opcode.IGET_OBJECT || (nx as TwoRegisterInstruction).registerA != 4 ||
            nx2.opcode != Opcode.CHECK_CAST || (nx2 as OneRegisterInstruction).registerA != 4 ||
            ((nx2 as ReferenceInstruction).reference as? TypeReference)?.type != "Ljava/util/List;"
        ) error("Edge TTS: la secuencia tras el texto no es la esperada (0.6.75)")

        val v = (voice ?: "es-MX-DaliaNeural").trim().ifEmpty { "es-MX-DaliaNeural" }.replace("\"", "")

        val pz = if (phononPausas == true) "0x1" else "0x0"

        val t = (phononTemp ?: "0.7").trim().filter { it.isDigit() || it == '.' || it == ',' }.ifEmpty { "0.7" }

        // 0.6.75: v3 = texto (String), v4 y v5 libres aqui (se reasignan mas abajo), v2 = null, v0/v1/v7 NO se tocan.
        m.addInstructionsWithLabels(
            at + 1,
            """
            const-string v5, "$t"
            invoke-static {v5}, $PHONON->configTemp(Ljava/lang/String;)V
            const/4 v5, $pz
            invoke-static {v5}, $PHONON->configPausas(Z)V
            const-string v5, "$v"
            const-string v4, ""
            invoke-static {v3, v5, v4}, $EDGE->speak(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)[B
            move-result-object v5
            if-eqz v5, :edge_none
            const-string v4, "apple"
            new-instance v3, Loma;
            invoke-direct {v3, v5, v4}, Loma;-><init>([BLjava/lang/String;)V
            return-object v3
            :edge_none
            nop
            """
        )
        // ---------------------------------------------------------------------------------------------
        // v0.20.349: Phonon tambien por "Device Voice" (sin llave), nombre y tarjetas de esa pantalla.
        // ---------------------------------------------------------------------------------------------

        // (1) Ltma.a: con 0 llaves (solo Device Voice) saltaba el pedido remoto (donde esta el gancho). Se quita ese salto.
        run {
            val tm = mutableClassDefBy(classDefBy("Ltma;"))
            val a = tm.methods.singleOrNull {
                it.name == "a" && it.parameterTypes.size == 2 && it.parameterTypes[0] == "Ljava/lang/String;"
            } ?: error("Phonon/Device Voice: no se encontro Ltma.a(String, cont) (version de Eclipse distinta de 0.6.75?)")
            val ins = (a.implementation ?: error("Phonon/Device Voice: Ltma.a sin codigo")).instructions.toList()
            val addr = IntArray(ins.size)
            var pos = 0
            for (i in ins.indices) { addr[i] = pos; pos += ins[i].codeUnits }
            val cand = ins.indices.filter { k ->
                k >= 2 && ins[k].opcode == Opcode.IF_NEZ && ins[k - 1].opcode == Opcode.MOVE_RESULT &&
                    ins[k - 2].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((ins[k - 2] as ReferenceInstruction).reference as? MethodReference)?.let {
                        it.definingClass == "Ljava/util/ArrayList;" && it.name == "isEmpty"
                    } == true
            }
            if (cand.size != 1) error("Phonon/Device Voice: se esperaba 1 if-nez tras ArrayList.isEmpty en Ltma.a y hay ${cand.size}")
            val k = cand[0]
            val tgt = addr.indexOf(addr[k] + (ins[k] as OffsetInstruction).codeOffset)
            if (tgt < 0) error("Phonon/Device Voice: no se resolvio el destino del if-nez en Ltma.a")
            val tIns = ins[tgt]
            val okTarget = tIns.opcode == Opcode.SGET_OBJECT &&
                ((tIns as ReferenceInstruction).reference as? FieldReference)?.let { it.definingClass == "Lwma;" && it.name == "SYSTEM" } == true
            if (!okTarget) error("Phonon/Device Voice: el destino del if-nez no es 'sget-object Lwma;->SYSTEM' (0.6.75)")
            a.removeInstruction(k)
        }

        // (2) Vista previa (Lv39.invokeSuspend): de Lm0.e(texto) (voz del sistema directo) a Lm0.d(texto, null) (cadena completa).
        run {
            val pv = mutableClassDefBy(classDefBy("Lv39;"))
            val inv = pv.methods.singleOrNull { it.name == "invokeSuspend" && it.parameterTypes.size == 1 }
                ?: error("Phonon/Device Voice: no se encontro Lv39.invokeSuspend")
            val ins = (inv.implementation ?: error("Phonon/Device Voice: Lv39.invokeSuspend sin codigo")).instructions.toList()
            val nullOk = ins.take(14).any {
                it.opcode == Opcode.CONST_4 && (it as OneRegisterInstruction).registerA == 6 && (it as NarrowLiteralInstruction).narrowLiteral == 0
            }
            if (!nullOk) error("Phonon/Device Voice: Lv39 no empieza con 'const/4 v6, 0' (0.6.75)")
            val calls = ins.indices.filter { i ->
                ins[i].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                        it.definingClass == "Lm0;" && it.name == "e" && it.returnType == "Ljava/lang/Object;" &&
                            it.parameterTypes.size == 2 && it.parameterTypes[0].toString() == "Ljava/lang/String;"
                    } == true
            }
            if (calls.size != 1) error("Phonon/Device Voice: se esperaba 1 llamada a Lm0.e en Lv39 y hay ${calls.size}")
            val c = calls[0]
            val five = ins[c] as? FiveRegisterInstruction ?: error("Phonon/Device Voice: la llamada a Lm0.e no tiene 3 registros")
            if (five.registerCount != 3) error("Phonon/Device Voice: la llamada a Lm0.e no tiene 3 registros")
            val rThis = five.registerC; val rText = five.registerD; val rCont = five.registerE
            if (rThis > 15 || rText > 15 || rCont > 15) error("Phonon/Device Voice: registros fuera de v0..v15 en Lv39")
            inv.addInstructions(
                c,
                """
                const/4 v6, 0x0
                invoke-virtual {v$rThis, v$rText, v6, v$rCont}, Lm0;->d(Ljava/lang/String;[BLvz1;)Ljava/lang/Object;
                """
            )
            inv.removeInstruction(c + 2) // la llamada vieja a Lm0.e quedo dos instrucciones mas abajo
        }

        // (3) Nombre, nota y textos de la tarjeta (todo cambia solo si se encuentra el texto original, una vez).
        val swaps = listOf(
            Triple("Lwma;", "getDisplayName", mapOf("Device Voice" to "Phonon")),
            Triple("Lwma;", "getProviderNote", mapOf("Free, offline, system voices" to "Voz local, gratis y sin internet")),
            Triple(
                "Lj1;", "b", mapOf(
                    "ALWAYS AVAILABLE" to "VOZ LOCAL",
                    "Your device's built-in voice synth. Free, offline, no key required. The DJ uses it whenever no cloud voice is available." to
                        "Phonon (de Gradium) es una voz de IA que corre en tu celular. Gratis, sin internet y sin llave. El DJ la usa primero; si todav\u00eda no est\u00e1 lista, usa otra voz mientras tanto.",
                    "Always ready \u00b7 works offline" to "Funciona sin internet"
                )
            ),
            Triple("Lv39;", "invokeSuspend", mapOf("Hey, I'm Umbra. Let's play some music." to "Hola, soy Umbra. Pongamos algo de m\u00fasica."))
        )
        for ((cn, mn, map) in swaps) {
            val cl = mutableClassDefBy(classDefBy(cn))
            val found = HashSet<String>()
            for (m in cl.methods.filter { it.name == mn && it.implementation != null }) {
                val ins = m.implementation!!.instructions.toList()
                val hits = ins.indices.filter { i ->
                    ins[i].opcode == Opcode.CONST_STRING &&
                        (((ins[i] as ReferenceInstruction).reference as? StringReference)?.string?.let { map.containsKey(it) } == true)
                }
                for (i in hits.sortedDescending()) {
                    val reg = (ins[i] as OneRegisterInstruction).registerA
                    val old = ((ins[i] as ReferenceInstruction).reference as StringReference).string
                    found.add(old)
                    m.addInstructions(i, "const-string v$reg, \"${smaliStr(map.getValue(old))}\"")
                    m.removeInstruction(i + 1)
                }
            }
            for (key in map.keys) if (key !in found) error("Phonon/Device Voice: no se encontro el texto \"$key\" en $cn.$mn (0.6.75)")
        }

        // (4) Tarjeta "CHANGE THE VOICE": caso 14 del packed-switch de Lsr1.r (lambda de composable). Se vuelve a Unit sin dibujar nada.
        run {
            val lam = mutableClassDefBy(classDefBy("Lsr1;"))
            val r = lam.methods.singleOrNull { it.name == "r" && it.parameterTypes.size == 2 }
                ?: error("Phonon/Device Voice: no se encontro Lsr1.r")
            val ins = (r.implementation ?: error("Phonon/Device Voice: Lsr1.r sin codigo")).instructions.toList()
            val addr = IntArray(ins.size)
            var pos = 0
            for (i in ins.indices) { addr[i] = pos; pos += ins[i].codeUnits }
            val sw = ins.indexOfFirst { it.opcode == Opcode.PACKED_SWITCH }
            if (sw < 0) error("Phonon/Device Voice: Lsr1.r no tiene packed-switch")
            val payload = ins.getOrNull(addr.indexOf(addr[sw] + (ins[sw] as OffsetInstruction).codeOffset)) as? SwitchPayload
                ?: error("Phonon/Device Voice: no se encontro la tabla del packed-switch en Lsr1.r")
            val el = payload.switchElements.firstOrNull { it.key == 14 } ?: error("Phonon/Device Voice: el switch de Lsr1.r no tiene el caso 14")
            val caseIdx = addr.indexOf(addr[sw] + el.offset)
            if (caseIdx < 0) error("Phonon/Device Voice: no se resolvio el caso 14 de Lsr1.r")
            val hasText = (caseIdx until minOf(ins.size, caseIdx + 160)).any {
                ins[it].opcode == Opcode.CONST_STRING &&
                    ((ins[it] as ReferenceInstruction).reference as? StringReference)?.string == "CHANGE THE VOICE"
            }
            if (!hasText) error("Phonon/Device Voice: el caso 14 de Lsr1.r no trae 'CHANGE THE VOICE' (0.6.75)")
            val unitOk = (0 until sw).any {
                ins[it].opcode == Opcode.SGET_OBJECT && (ins[it] as OneRegisterInstruction).registerA == 20 &&
                    ((ins[it] as ReferenceInstruction).reference as? FieldReference)?.let { f -> f.definingClass == "Lscb;" && f.name == "a" } == true
            }
            if (!unitOk) error("Phonon/Device Voice: v20 no es Lscb.a (Unit) antes del switch de Lsr1.r (0.6.75)")
            // Despues de la 1a instruccion del caso (no depende de a donde apunten las etiquetas del switch).
            r.addInstructions(caseIdx + 1, "return-object v20")
        }

        // (5) v0.20.350: prender Phonon al abrir Eclipse. Se inserta al INICIO de MainActivity.onCreate(Bundle) (no antes del ultimo
        // return-void, porque BootSplashPatch revisa esa zona). v0 esta libre al inicio (.locals >= 1); se comprueba.
        run {
            val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))
            val oc = main.methods.singleOrNull {
                it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
            } ?: error("Phonon: no se encontro MainActivity.onCreate")
            val impl = oc.implementation ?: error("Phonon: MainActivity.onCreate sin codigo")
            if (impl.registerCount - oc.parameterTypes.size - 1 < 1) error("Phonon: MainActivity.onCreate no tiene registros libres")
            oc.addInstructions(
                0,
                """
                const-string v0, "$t"
                invoke-static {v0}, $PHONON->warmup(Ljava/lang/String;)V
                """
            )
        }
    }
}

/** v0.20.349: texto para `const-string` de smali (comillas, barra y lo que no es ASCII como \uXXXX). */
private fun smaliStr(s: String): String {
    val sb = StringBuilder()
    for (ch in s) {
        when {
            ch == '"' -> sb.append("\\\"")
            ch == '\\' -> sb.append("\\\\")
            ch.code < 32 || ch.code > 126 -> sb.append("\\u").append(ch.code.toString(16).padStart(4, '0'))
            else -> sb.append(ch)
        }
    }
    return sb.toString()
}
