package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val FLUID = "Lapp/eclipse/extension/player/LayerMorph;"
private const val OBJ2 = "Ljava/lang/Object;Ljava/lang/Object;"

private fun methodIdx(ins: List<Instruction>, op: Opcode, cls: String, name: String, params: List<String>?): List<Int> =
    ins.indices.filter { i ->
        val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
        ins[i].opcode == op && r != null && r.definingClass == cls && r.name == name &&
            (params == null || r.parameterTypes.map { it.toString() } == params)
    }

/**
 * v0.20.290 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Complemento de
 * "Bitchord: la portada chica crece (Letra)": en vez de cambiar el TAMANO de la portada en cada cuadro (Compose vuelve a
 * medir y dibujar todo, y con la letra en movimiento se nota el tiron), la portada se mide siempre en tamano Artwork y
 * se achica con un graphicsLayer (je7.E, el mismo de PlayerBack). La posicion sigue mezclandose en la lambda de colocacion
 * (xp7.invoke) y alli mismo se suma el desplazamiento vertical. Si algo falla en tiempo de ejecucion, LayerMorph vuelve a
 * mezclar el tamano como antes. Las esquinas redondeadas se achican junto con la imagen (sin compensar).
 */
@Suppress("unused")
val bitchordCoverFluidPatch = bytecodePatch(
    name = "Bitchord: portada chica crece fluida",
    description = "Hace mas fluida la animacion de la portada que crece/se achica (la escala con la GPU en vez de volver a medirla " +
        "en cada cuadro). Necesita 'Bitchord: la portada chica crece (Letra)'. Las esquinas de la portada chica se ven algo mas " +
        "cuadradas. Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordCoverMorphPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- qr7.d: dibuja UNA capa. De mayor a menor indice para no mover los demas. ----
        val qr = mutableClassDefBy(classDefBy("Lqr7;"))
        val d = qr.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size >= 2 &&
                it.parameterTypes[0] == "Lu51;" && it.parameterTypes[1] == "Lu51;"
        } ?: error("No se encontro qr7.d(u51, u51, ...)")

        // 1) graphicsLayer tras el modificador de tamano `yj9.q(mb6, F, F)` (moveresult = modificador).
        var ins = d.implementation!!.instructions.toList()
        val qList = methodIdx(ins, Opcode.INVOKE_STATIC, "Lyj9;", "q", listOf("Lmb6;", "F", "F"))
        if (qList.size != 1) error("qr7.d: se esperaba 1 llamado a yj9.q(mb6, F, F) (hay ${qList.size})")
        val qIdx = qList[0]
        val mres = ins[qIdx + 1]
        if (mres.opcode != Opcode.MOVE_RESULT_OBJECT) error("qr7.d: despues de yj9.q no viene move-result-object")
        val vR = (mres as OneRegisterInstruction).registerA
        // La capa (u51): primer argumento de xp7.<init> (registro start+1); se copia con un move-object justo despues.
        val xInit = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_DIRECT_RANGE && r != null && r.definingClass == "Lxp7;" && r.name == "<init>"
        }
        if (xInit.size != 1) error("qr7.d: se esperaba 1 llamado a xp7.<init> (hay ${xInit.size})")
        val layerSrc = (ins[xInit[0]] as RegisterRangeInstruction).startRegister + 1
        val mvIdx = (xInit[0] + 1 until qIdx).firstOrNull { i ->
            (ins[i].opcode == Opcode.MOVE_OBJECT || ins[i].opcode == Opcode.MOVE_OBJECT_FROM16) &&
                (ins[i] as TwoRegisterInstruction).registerB == layerSrc
        } ?: error("qr7.d: no se encontro la copia de la capa tras xp7.<init>")
        val vL = (ins[mvIdx] as TwoRegisterInstruction).registerA
        if (vL > 15 || vR > 15 || vL == vR) error("qr7.d: registros inesperados (capa v$vL, modificador v$vR)")
        for (i in (mvIdx + 1) until qIdx) {
            val n = ins[i].opcode.name
            val w = (ins[i] as? OneRegisterInstruction)?.registerA
            if (w == vL && (n.startsWith("MOVE") || n.startsWith("CONST") || n.startsWith("IGET") || n == "NEW_INSTANCE"))
                error("qr7.d: la capa (v$vL) se pisa antes del modificador de tamano")
        }
        d.addInstructions(
            qIdx + 2,
            """
                invoke-static {v$vR, v$vL}, $FLUID->gl($OBJ2)Ljava/lang/Object;
                move-result-object v$vR
                check-cast v$vR, Lmb6;
            """
        )

        // 2) ancho y alto (px) antes de qr7.M(iv4, F, F).
        ins = d.implementation!!.instructions.toList()
        val mList = methodIdx(ins, Opcode.INVOKE_STATIC, "Lqr7;", "M", listOf("Liv4;", "F", "F"))
        if (mList.size != 1) error("qr7.d: se esperaba 1 llamado a qr7.M (hay ${mList.size})")
        val mi = ins[mList[0]] as FiveRegisterInstruction
        if (mi.registerD > 15 || mi.registerE > 15) error("qr7.d: registros altos en qr7.M")
        d.addInstructions(mList[0], "invoke-static {v${mi.registerD}, v${mi.registerE}}, $FLUID->setWH(FF)V")

        // 3) la composicion usa tfComp (la portada conserva el tamano de Artwork) en vez de tf.
        ins = d.implementation!!.instructions.toList()
        val tList = methodIdx(ins, Opcode.INVOKE_STATIC, FLUID, "tf", null)
        if (tList.size != 1) error("qr7.d: se esperaba 1 llamado a LayerMorph.tf (hay ${tList.size});")
        val ti = ins[tList[0]] as FiveRegisterInstruction
        d.addInstructions(tList[0], "invoke-static {v${ti.registerC}, v${ti.registerD}}, $FLUID->tfComp($OBJ2)Ljava/lang/Object;")
        d.removeInstruction(tList[0] + 1)

        // ---- xp7.invoke: lambda de colocacion. ----
        val xp = mutableClassDefBy(classDefBy("Lxp7;"))
        val inv = xp.methods.singleOrNull {
            it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro xp7.invoke")
        var xi = inv.implementation!!.instructions.toList()
        val zList = methodIdx(xi, Opcode.INVOKE_STATIC, "Lmv5;", "z", listOf("F"))
        if (zList.size != 1) error("xp7.invoke: se esperaba 1 llamado a mv5.z(F) (hay ${zList.size})")
        val zr = (xi[zList[0]] as FiveRegisterInstruction).registerC
        if (zr > 15) error("xp7.invoke: registro alto en mv5.z")
        inv.addInstructions(
            zList[0],
            """
                invoke-static {v$zr}, $FLUID->addDy(F)F
                move-result v$zr
            """
        )
        xi = inv.implementation!!.instructions.toList()
        val xtList = methodIdx(xi, Opcode.INVOKE_STATIC, FLUID, "tf", null)
        if (xtList.size != 1) error("xp7.invoke: se esperaba 1 llamado a LayerMorph.tf (hay ${xtList.size})")
        val xt = xi[xtList[0]] as FiveRegisterInstruction
        inv.addInstructions(xtList[0], "invoke-static {v${xt.registerC}, v${xt.registerD}}, $FLUID->place($OBJ2)Ljava/lang/Object;")
        inv.removeInstruction(xtList[0] + 1)

        // ---- qr7.q: enciende el modo fluido (igual que el parche de la portada que crece enciende morphMode). ----
        val qm = qr.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lle7;"
        } ?: error("No se encontro qr7.q")
        qm.addInstructions(0, "invoke-static {}, $FLUID->enableFluid()V")
    }
}
