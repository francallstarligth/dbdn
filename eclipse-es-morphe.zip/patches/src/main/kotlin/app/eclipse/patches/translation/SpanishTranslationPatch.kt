package app.eclipse.patches.translation

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val HELPER = "Lapp/eclipse/extension/es/Translator;"

private fun resourceLines(path: String): List<String> {
    val stream = object {}.javaClass.getResourceAsStream(path)
        ?: error("Recurso no encontrado en el parche: $path")
    return stream.bufferedReader(Charsets.UTF_8).use { it.readLines() }
}

/** Solo clases de la app: raiz sin paquete (R8) o com/eclipse. Se excluyen librerias. */
private fun isAppClass(type: String) = !type.contains('/') || type.startsWith("Lcom/eclipse/")

@Suppress("unused")
val spanishTranslationPatch = bytecodePatch(
    name = "Spanish translation",
    description = "Traduce la interfaz de Eclipse al espanol (si el idioma del telefono es espanol).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val risky = resourceLines("/eclipse/risky.txt").filter { it.isNotEmpty() }.toSet()
        val targets = resourceLines("/eclipse/dictionary_en_es.tsv")
            .mapNotNull { line -> line.substringBefore('\t', "").takeIf { it.isNotEmpty() && line.contains('\t') } }
            .filter { it !in risky }
            .toSet()

        // 1) Clases de la app que contienen algun texto del diccionario (busqueda directa por indice).
        val candidates = LinkedHashSet<String>()
        targets.forEach { literal ->
            classDefByStrings(literal).forEach { classDef ->
                if (isAppClass(classDef.type)) candidates += classDef.type
            }
        }

        // 2) Solo se hace mutable una clase si tiene al menos un sitio seguro (evita gastar memoria).
        var siteCount = 0
        var classCount = 0
        for (type in candidates) {
            val immutable = classDefBy(type)
            val isEnum = immutable.superclass == "Ljava/lang/Enum;"
            val hasSites = immutable.methods.any { m ->
                m.implementation?.let { SiteAnalyzer.findSites(it, isEnum, targets).isNotEmpty() } == true
            }
            if (!hasSites) continue

            val mutable = mutableClassDefBy(immutable)
            classCount++
            for (method in mutable.methods) {
                val impl = method.implementation ?: continue
                val sites = SiteAnalyzer.findSites(impl, isEnum, targets)
                // De atras hacia adelante para que los indices no se muevan.
                for (site in sites.sortedByDescending { it.index }) {
                    val v = "v${site.register}"
                    method.addInstructions(
                        site.index + 1,
                        """
                            invoke-static/range {$v .. $v}, $HELPER->t(Ljava/lang/String;)Ljava/lang/String;
                            move-result-object $v
                        """
                    )
                    siteCount++
                }
            }
        }
        println("Eclipse ES: $siteCount sitios traducidos en $classCount clases (diccionario: ${targets.size}).")
    }
}
