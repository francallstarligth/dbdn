package app.eclipse.patches.translation

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val HELPER = "Lapp/eclipse/extension/es/Translator;"

private fun resourceLines(path: String): List<String> {
    val stream = object {}.javaClass.getResourceAsStream(path)
        ?: error("Recurso no encontrado en el parche: $path")
    return stream.bufferedReader(Charsets.UTF_8).use { it.readLines() }
}

/** Llama a Translator.back sobre el registro (traduccion inversa de los textos de Configuracion). */
private fun backCall(reg: Int) = """
    invoke-static/range {v$reg .. v$reg}, $HELPER->back(Ljava/lang/String;)Ljava/lang/String;
    move-result-object v$reg
"""

/** Solo clases de la app: raiz sin paquete (R8) o com/eclipse. Se excluyen librerias. */
private fun isAppClass(type: String) = !type.contains('/') || type.startsWith("Lcom/eclipse/")

@Suppress("unused")
val spanishTranslationPatch = bytecodePatch(
    name = "Spanish translation",
    description = "Traduce la interfaz de Eclipse al espanol (si el idioma del telefono es espanol).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val risky = resourceLines("/eclipse/risky.txt").filter { it.isNotEmpty() }.toSet()
        val targets = resourceLines("/eclipse/dictionary_en_es.tsv")
            .mapNotNull { line -> line.substringBefore('\t', "").takeIf { it.isNotEmpty() && line.contains('\t') } }
            .filter { it !in risky }
            .toSet()

        // 1) Clases de la app que contienen algun texto del diccionario (busqueda directa por indice).
        val candidates = LinkedHashSet<String>()
        targets.forEach { literal ->
            classDefByStrings(literal).forEach { classDef ->
                if (isAppClass(classDef.type)) candidates += classDef.type
            }
        }

        // 2) Solo se hace mutable una clase si tiene al menos un sitio seguro (evita gastar memoria).
        var siteCount = 0
        var classCount = 0
        for (type in candidates) {
            val immutable = classDefBy(type)
            val isEnum = immutable.superclass == "Ljava/lang/Enum;"
            val hasSites = immutable.methods.any { m ->
                m.implementation?.let { SiteAnalyzer.findSites(it, isEnum, targets).isNotEmpty() } == true
            }
            if (!hasSites) continue

            val mutable = mutableClassDefBy(immutable)
            classCount++
            for (method in mutable.methods) {
                val impl = method.implementation ?: continue
                val sites = SiteAnalyzer.findSites(impl, isEnum, targets)
                // De atras hacia adelante para que los indices no se muevan.
                for (site in sites.sortedByDescending { it.index }) {
                    val v = "v${site.register}"
                    method.addInstructions(
                        site.index + 1,
                        """
                            invoke-static/range {$v .. $v}, $HELPER->t(Ljava/lang/String;)Ljava/lang/String;
                            move-result-object $v
                        """
                    )
                    siteCount++
                }
            }
        }
        // 3) Eclipse 0.6.57: el buscador de Configuracion compara el nombre (ya traducido) con constantes
        //    en ingles via String.equals; sin esto la pantalla sale vacia/negra. Se devuelve a ingles
        //    SOLO al llegar a los 3 despachadores (el menu sigue en espanol). Nombres de 0.6.57 (antes 0.6.55):
        //    de6.e (antes zc6.e; indice de Configuracion; OJO: ahora el String es el 3er parametro, (I, composer, String)),
        //    ud6.g (antes qc6.g; lambda de la lista) y sv1.j (antes y02.q; ordenar).
        fun entryHook(cls: String, name: String, params: List<String>, paramIndex: Int) {
            val m = mutableClassDefBy(classDefBy(cls)).methods.firstOrNull { mm ->
                mm.name == name && mm.parameterTypes.map { it.toString() } == params
            } ?: error("Spanish translation: no se encontro $cls->$name (version de Eclipse distinta de 0.6.61?)")
            val impl = m.implementation ?: error("Spanish translation: $cls->$name sin codigo")
            // Los tres metodos son static: el primer parametro es el registro registerCount - params.size.
            val reg = impl.registerCount - params.size + paramIndex
            m.addInstructions(0, backCall(reg))
        }
        entryHook("Lve6;", "e", listOf("I", "Lzq1;", "Ljava/lang/String;"), 2)
        entryHook("Lqw1;", "j", listOf("Lya6;", "Ljava/lang/String;", "Z", "Lzq1;", "I"), 1)

        val lambda = mutableClassDefBy(classDefBy("Lle6;")).methods.firstOrNull { mm ->
            mm.name == "g" && mm.parameterTypes.size == 3
        } ?: error("Spanish translation: no se encontro Lle6;->g (version de Eclipse distinta de 0.6.61?)")
        val lambdaImpl = lambda.implementation ?: error("Spanish translation: Lle6;->g sin codigo")
        val castAt = lambdaImpl.instructions.indexOfFirst { ins ->
            ins.opcode == Opcode.CHECK_CAST &&
                (ins as OneRegisterInstruction).registerA == 11 &&
                ((ins as ReferenceInstruction).reference as TypeReference).type == "Ljava/lang/String;"
        }
        if (castAt !in 20..120) error("Spanish translation: estructura inesperada en Lle6;->g (check-cast en $castAt)")
        lambda.addInstructions(castAt + 1, backCall(11))

        println("Eclipse ES: $siteCount sitios traducidos en $classCount clases (diccionario: ${targets.size}).")
    }
}
