package app.eclipse.patches.audio

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val FS = "Lapp/eclipse/extension/audio/FirstSong;"

/**
 * v0.20.453 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): primera cancion mas rapida.
 * Gancho A: inicio de EclipseApplication.onCreate -> FirstSong.warm() (calienta DNS/HTTPS hacia api.eclipsemusic.app en otro hilo).
 * (v0.20.457: `FirstSong.warm` ahora calienta los addons activos (token + primer pedido con el cliente de Eclipse), no solo api.eclipsemusic.app. El gancho no cambia.)
 * (v0.20.454: los puntos se buscan por patron de instrucciones, no por indice; el indice 293 de androguard no coincidio en el parcheador.)
 * (v0.20.455: el Gancho B (cache en jh0.W) se QUITO: con la 0.20.454 la app no abria. Queda solo el Gancho A.)
 * [Descripcion historica del Gancho B, ya NO aplicado:] `Ljh0;->W(InstalledAddon, Song, String, Continuation)` (cadena que resuelve la cancion con el addon; la llaman jh0.j, s57.V,
 * bh0 via zg0 y y.invokeSuspend):
 *   - indice 57 (justo despues de `kd8.Q` del estado 0, no es destino de salto): `FirstSong.get(v32, v33, v34)`; si hay guardado, devuelve eso.
 *   - antes de cada `return-object` de un EclipseAddonTrack (indices 169, 240, 293) guarda con `FirstSong.put(addon, cancion, texto, track)`.
 * Los indices y registros se comprueban antes de tocar nada; si no cuadran, el parche falla con un mensaje claro (no parchea a medias).
 */
@Suppress("unused")
val firstSongPatch = bytecodePatch(
    name = "Primera cancion mas rapida",
    description = "Al abrir la app, en segundo plano, calienta los addons activos (Tido): pide su token de acceso y hace un primer " +
        "pedido a su direccion con el mismo cliente de red de Eclipse, para que la primera cancion no pague esa primera conexion. " +
        "No cambia el audio ni el orden de fuentes.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // Gancho A: calentar al abrir la app
        val app = mutableClassDefBy(classDefBy("Lcom/eclipse/android/EclipseApplication;"))
        val onCreate = app.methods.singleOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("Primera cancion: no se encontro EclipseApplication.onCreate")
        onCreate.addInstructions(0, "invoke-static/range {p0 .. p0}, $FS->warm(Landroid/content/Context;)V")

    }
}
