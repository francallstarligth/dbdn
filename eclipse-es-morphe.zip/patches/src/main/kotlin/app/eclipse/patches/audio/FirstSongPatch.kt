package app.eclipse.patches.audio

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val FS = "Lapp/eclipse/extension/audio/FirstSong;"
private const val OBJ3 = "Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;"

/**
 * v0.20.453 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): primera cancion mas rapida.
 * Gancho A: inicio de EclipseApplication.onCreate -> FirstSong.warm() (calienta DNS/HTTPS hacia api.eclipsemusic.app en otro hilo).
 * (v0.20.454: los puntos se buscan por patron de instrucciones, no por indice; el indice 293 de androguard no coincidio en el parcheador.)
 * Gancho B: `Ljh0;->W(InstalledAddon, Song, String, Continuation)` (cadena que resuelve la cancion con el addon; la llaman jh0.j, s57.V,
 * bh0 via zg0 y y.invokeSuspend):
 *   - indice 57 (justo despues de `kd8.Q` del estado 0, no es destino de salto): `FirstSong.get(v32, v33, v34)`; si hay guardado, devuelve eso.
 *   - antes de cada `return-object` de un EclipseAddonTrack (indices 169, 240, 293) guarda con `FirstSong.put(addon, cancion, texto, track)`.
 * Los indices y registros se comprueban antes de tocar nada; si no cuadran, el parche falla con un mensaje claro (no parchea a medias).
 */
@Suppress("unused")
val firstSongPatch = bytecodePatch(
    name = "Primera cancion mas rapida",
    description = "Al abrir la app calienta la conexion con el servidor de Eclipse y guarda en memoria las canciones ya buscadas " +
        "en el addon, para que la primera cancion y las repetidas empiecen antes. No cambia el audio ni el orden de fuentes.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // Gancho A: calentar al abrir la app
        val app = mutableClassDefBy(classDefBy("Lcom/eclipse/android/EclipseApplication;"))
        val onCreate = app.methods.singleOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("Primera cancion: no se encontro EclipseApplication.onCreate")
        onCreate.addInstructions(0, "invoke-static {}, $FS->warm()V")

        // Gancho B: cache en jh0.W
        val jh0 = mutableClassDefBy(classDefBy("Ljh0;"))
        val esperados = listOf(
            "Lcom/eclipse/android/data/models/addon/InstalledAddon;",
            "Lcom/eclipse/android/data/models/Song;",
            "Ljava/lang/String;",
            "Lvz1;"
        )
        val w = jh0.methods.singleOrNull {
            it.name == "W" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("Primera cancion: no se encontro jh0.W (Eclipse 0.6.75)")

        // Los puntos se buscan por lo que hace cada instruccion (no por numero de linea).
        val lista = w.implementation!!.instructions.toList()
        fun metodoDe(i: Int): MethodReference? =
            (lista[i] as? ReferenceInstruction)?.reference as? MethodReference

        // (a) el unico invoke-interface Ltz1;->getContext() (primer paso del estado 0)
        val idxGet = lista.indices.filter { i ->
            val m = metodoDe(i)
            lista[i].opcode == Opcode.INVOKE_INTERFACE && m != null && m.name == "getContext" && m.definingClass == "Ltz1;"
        }.singleOrNull() ?: error("Primera cancion: jh0.W cambio (no se hallo getContext unico)")

        // (b) los dos `new EclipseAddonTrack(...)` seguidos de return-object (ISRC/identidad) y (c) el return de Lgza;->b
        val track = "Lcom/eclipse/android/data/models/addon/EclipseAddonTrack;"
        val ctor = lista.indices.filter { i ->
            val m = metodoDe(i)
            lista[i].opcode == Opcode.INVOKE_DIRECT_RANGE && m != null && m.name == "<init>" && m.definingClass == track &&
                i + 1 < lista.size && lista[i + 1].opcode == Opcode.RETURN_OBJECT
        }
        if (ctor.size != 2) error("Primera cancion: jh0.W cambio (return de EclipseAddonTrack: ${ctor.size}, se esperaban 2)")
        val idxB = lista.indices.filter { i ->
            val m = metodoDe(i)
            lista[i].opcode == Opcode.INVOKE_STATIC && m != null && m.name == "b" && m.definingClass == "Lgza;" &&
                i + 2 < lista.size && lista[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT && lista[i + 2].opcode == Opcode.RETURN_OBJECT
        }.singleOrNull() ?: error("Primera cancion: jh0.W cambio (no se hallo return de Lgza.b)")

        // (indice del return-object, registro del track, addon, cancion, texto) segun el smali de 0.6.75
        data class Ret(val idx: Int, val track: Int, val addon: Int, val song: Int, val text: Int)
        val rets = listOf(
            Ret(idxB + 2, 0, 11, 1, 7),
            Ret(ctor[1] + 1, 10, 3, 8, 7),
            Ret(ctor[0] + 1, 15, 11, 3, 8)
        )
        for (r in rets) {
            val ins = lista[r.idx]
            if (ins.opcode != Opcode.RETURN_OBJECT || (ins as OneRegisterInstruction).registerA != r.track) {
                error("Primera cancion: jh0.W cambio (el return en ${r.idx} no es return-object v${r.track})")
            }
        }
        if (!(idxGet < rets.minOf { it.idx })) error("Primera cancion: jh0.W cambio (orden de puntos)")

        // de mayor a menor indice para no mover los demas
        for (r in rets.sortedByDescending { it.idx }) {
            w.addInstructions(
                r.idx,
                "invoke-static {v${r.addon}, v${r.song}, v${r.text}, v${r.track}}, $FS->put($OBJ3" + "Ljava/lang/Object;)V"
            )
        }
        w.addInstructionsWithLabels(
            idxGet,
            """
            invoke-static/range {v32 .. v34}, $FS->get($OBJ3)Ljava/lang/Object;
            move-result-object v0
            if-eqz v0, :fs_go
            return-object v0
            :fs_go
            nop
            """.trimIndent()
        )
    }
}
