package app.eclipse.patches.audio

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

private const val FS = "Lapp/eclipse/extension/audio/FirstSong;"
private const val OBJ3 = "Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;"

/**
 * v0.20.453 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): primera cancion mas rapida.
 * Gancho A: inicio de EclipseApplication.onCreate -> FirstSong.warm() (calienta DNS/HTTPS hacia api.eclipsemusic.app en otro hilo).
 * Gancho B: `Ljh0;->W(InstalledAddon, Song, String, Continuation)` (cadena que resuelve la cancion con el addon; la llaman jh0.j, s57.V,
 * bh0 via zg0 y y.invokeSuspend):
 *   - indice 57 (justo despues de `kd8.Q` del estado 0, no es destino de salto): `FirstSong.get(v32, v33, v34)`; si hay guardado, devuelve eso.
 *   - antes de cada `return-object` de un EclipseAddonTrack (indices 169, 240, 293) guarda con `FirstSong.put(addon, cancion, texto, track)`.
 * Los indices y registros se comprueban antes de tocar nada; si no cuadran, el parche falla con un mensaje claro (no parchea a medias).
 */
@Suppress("unused")
val firstSongPatch = bytecodePatch(
    name = "Primera cancion mas rapida",
    description = "Al abrir la app calienta la conexion con el servidor de Eclipse y guarda en memoria las canciones ya buscadas " +
        "en el addon, para que la primera cancion y las repetidas empiecen antes. No cambia el audio ni el orden de fuentes.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // Gancho A: calentar al abrir la app
        val app = mutableClassDefBy(classDefBy("Lcom/eclipse/android/EclipseApplication;"))
        val onCreate = app.methods.singleOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("Primera cancion: no se encontro EclipseApplication.onCreate")
        onCreate.addInstructions(0, "invoke-static {}, $FS->warm()V")

        // Gancho B: cache en jh0.W
        val jh0 = mutableClassDefBy(classDefBy("Ljh0;"))
        val esperados = listOf(
            "Lcom/eclipse/android/data/models/addon/InstalledAddon;",
            "Lcom/eclipse/android/data/models/Song;",
            "Ljava/lang/String;",
            "Lvz1;"
        )
        val w = jh0.methods.singleOrNull {
            it.name == "W" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("Primera cancion: no se encontro jh0.W (Eclipse 0.6.75)")

        // (indice, registro del track, addon, cancion, texto) segun el smali de 0.6.75
        data class Ret(val idx: Int, val track: Int, val addon: Int, val song: Int, val text: Int)
        val rets = listOf(Ret(293, 0, 11, 1, 7), Ret(240, 10, 3, 8, 7), Ret(169, 15, 11, 3, 8))

        for (r in rets) {
            val ins = w.getInstruction(r.idx)
            if (ins.opcode != Opcode.RETURN_OBJECT || (ins as OneRegisterInstruction).registerA != r.track) {
                error("Primera cancion: jh0.W cambio (indice ${r.idx} no es return-object v${r.track})")
            }
        }
        val kdQ = w.getInstruction(56)
        if (kdQ.opcode != Opcode.INVOKE_STATIC) error("Primera cancion: jh0.W cambio (indice 56)")

        // de mayor a menor indice para no mover los demas
        for (r in rets) {
            w.addInstructions(
                r.idx,
                "invoke-static {v${r.addon}, v${r.song}, v${r.text}, v${r.track}}, $FS->put($OBJ3" + "Ljava/lang/Object;)V"
            )
        }
        w.addInstructionsWithLabels(
            57,
            """
            invoke-static/range {v32 .. v34}, $FS->get($OBJ3)Ljava/lang/Object;
            move-result-object v0
            if-eqz v0, :fs_go
            return-object v0
            :fs_go
            nop
            """.trimIndent()
        )
    }
}
