package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.140 (SIN COMPILAR NI PROBAR). Une los parches de animaciones del reproductor. "Esperar la portada" dependia de
 * "entrada" (por eso la entrada ya estaba encendida de hecho): aqui sigue igual, esperar la portada enciende la entrada.
 */
@Suppress("unused")
val playerAnimationsPatch = bytecodePatch(
    name = "Reproductor: animaciones",
    description = "Animaciones del reproductor grande: entrada (sube desde abajo), esperar la portada, salida mas lenta, " +
        "gesto de retroceder y velocidad fija. Cada una tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val enter by booleanOption(
        key = "enter",
        default = true,
        title = "Entrada del reproductor",
        description = "El reproductor grande sube desde abajo al abrirse en vez de aparecer de golpe."
    )

    val waitCover by booleanOption(
        key = "waitCover",
        default = true,
        title = "Esperar la portada al abrir",
        description = "Espera (maximo medio segundo) a que la portada este lista antes de subir el reproductor. Se enciende junto con la entrada."
    )

    val exit by booleanOption(
        key = "exit",
        default = false,
        title = "Salida mas lenta (experimento)",
        description = "Al retroceder, el reproductor baja mas despacio y se achica mas (450 ms, escala 0.85)."
    )

    val backGesture by booleanOption(
        key = "backGesture",
        default = false,
        title = "Gesto de retroceder (experimento)",
        description = "Mientras mantienes el gesto de retroceder, el reproductor grande se achica segun cuanto arrastras."
    )

    val fixedSpeed by booleanOption(
        key = "fixedSpeed",
        default = true,
        title = "Velocidad fija",
        description = "Las animaciones de Eclipse duran siempre lo mismo, sin importar la velocidad de animaciones del telefono."
    )

    execute {
        if (enter == true || waitCover == true) playerEnterAnimationPatch.execute(this)
        if (waitCover == true) playerWaitCoverPatch.execute(this)
        if (exit == true) playerExitAnimationPatch.execute(this)
        if (backGesture == true) playerBackGesturePatch.execute(this)
        if (fixedSpeed == true) fixedAnimationSpeedPatch.execute(this)
    }
}
