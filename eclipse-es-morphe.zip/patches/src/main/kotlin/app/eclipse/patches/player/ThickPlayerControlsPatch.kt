package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val BUTTON_STYLES = "Lapp/eclipse/extension/player/ButtonStyles;"

/** Fraccion del alto de la capa que ocupa el track (1/3): con alto de capa 3 queda ~8.7 dp, el grosor de v1.66.0 con alto 1. */
private const val TRACK_FRACTION = "0x3eaaaaab"

/** 1.0f: el contenedor llena todo el alto de la capa. */
private const val FULL = "0x3f800000"

/** Bits de const/high16 de 4.0f, 5.0f y 40.0f (altos fijos originales, en dp). */
private const val H_4 = 0x40800000
private const val H_5 = 0x40a00000
private const val H_40 = 0x42200000

private class Target(
    val cls: String,
    val name: String,
    val params: List<String>,
    /** Alto fijo (const/high16 seguido de Modifier.height) que pasa a fillMaxHeight. */
    val heightBits: Int,
    /** Quitar las 2 llamadas a Icon (im3.a) propias de Eclipse. */
    val removeIcons: Boolean = false,
    /** Tambien cambiar `height(ha2.q)` (grosor animado 4 -> 8 dp del estilo Classic) por fillMaxHeight. */
    val animatedHeight: Boolean = false,
    /** Fraccion (hex de float) del alto disponible: FULL para contenedores, TRACK_FRACTION para el track. */
    val fraction: String = TRACK_FRACTION,
)

private val TARGETS = listOf(
    // Volumen: di6.C — track 4 dp + 2 iconos propios (im3.a).
    Target("Lq97;", "C", listOf("I", "Li21;", "Lu21;", "Lcq1;", "Z"), H_4, removeIcons = true),
    // Progreso, vista del editor (estilo simple): track 5 dp.
    Target("Lq97;", "h", listOf("Li21;", "F", "J", "Z", "Lu21;", "D", "Z", "Lxe3;", "Lcq1;", "I"), H_5),
    Target("Lka7;", "i", listOf("Li21;", "F", "J", "Z", "D", "Lxe3;", "Lje3;", "Lcq1;", "I"), H_5),
    // Progreso en el reproductor real: vd2.V (contenedor de 40 dp) y el estilo CLASSIC vd2.h
    // (contenedor de 40 dp + track animado 4 -> 8 dp).
    Target(
        "Lpr7;", "E",
        listOf("F", "D", "D", "J", "Z", "Z", "Lhe3;", "Lje3;", "Lhe3;", "Lou5;", "Ltj8;", "Lcq1;", "I", "I", "I"),
        H_40, fraction = FULL
    ),
    Target("Lpr7;", "d", listOf("F", "I", "J", "Lcq1;", "Z"), H_40, animatedHeight = true, fraction = FULL),
)

/** Modifier.height(float) de Compose: g48.i(Modifier, F). */
private fun isHeightCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lkz8;" && ref.name == "i" && ref.parameterTypes.size == 2
}

private fun isIconCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC_RANGE && ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lqw3;" && ref.name == "a" && ref.parameterTypes.size == 7
}

/** iget ... Loj2;->q:F (grosor animado). */
private fun isAnimatedHeightGet(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.IGET) return false
    val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return false
    return ref.definingClass == "Lok2;" && ref.name == "q" && ref.type == "F"
}

private enum class Kind { REMOVE, CONST_AND_CALL, CALL_ONLY }

/**
 * Botones y barras gruesas (union de dos parches que antes eran separados: "Botones del reproductor: estilo grueso" y
 * "Barras gruesas: volumen y progreso (alto = capa)"). Cada mitad es una opcion y se puede apagar sola; la mitad
 * apagada no corre ni sus comprobaciones. Las dos mitades tocan metodos distintos (bw0.<clinit> y di6.A los botones;
 * di6.C, di6.h, xi6.i, vd2.V y vd2.h las barras), asi que no se pisan.
 */
@Suppress("unused")
val thickPlayerControlsPatch = bytecodePatch(
    name = "Reproductor: botones y barras gruesas",
    description = "Estilos nuevos para los botones del reproductor (grueso y tipo Apple Music, mas el icono Connect " +
        "dinamico) y barras de volumen y progreso con grosor ajustable. Cada parte se puede apagar en las opciones.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val buttons by booleanOption(
        key = "buttons",
        default = true,
        title = "Botones: estilo grueso y Apple Music",
        description = "Agrega un estilo nuevo (grueso, esquinas apenas redondeadas) para Play/Pause, Previous y Next al principio de la lista de estilos del editor del reproductor de Eclipse. Tambien agrega estilos tipo Apple Music: doble triangulo (Previous y Next), letra, cola, conectar (AirPods), persona (Jam) y menu. Incluye el icono Connect dinamico."
    )

    val bars by booleanOption(
        key = "bars",
        default = true,
        title = "Barras gruesas: volumen y progreso",
        description = "La barra de volumen y la de progreso (estilo Classic y la vista del editor) ya no tienen alto fijo: su grosor pasa a ser el alto de la capa en el editor (extremos redondeados). Tambien quita los dos altavoces chicos que Eclipse dibuja dentro de la barra de volumen. Los otros estilos de progreso no cambian."
    )

    execute {
        if (buttons == true) {
            // bw0 guarda los estilos: e = Map(ob4 -> lista de nombres), f = Map(nombre -> icono),
            // g = Map(nombre de Play -> icono de Pause). El gancho va al final de bw0.<clinit>, justo antes del
            // return-void: pasa cada mapa por ButtonStyles.apply(which, mapa) y lo vuelve a guardar.
            val bw0 = mutableClassDefBy(classDefBy("Lg21;"))

            for (name in listOf("e", "f", "g")) {
                if (bw0.fields.none { it.name == name && it.type == "Ljava/util/Map;" }) {
                    error("bw0.$name (Map) no encontrado")
                }
            }

            val clinit = bw0.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro bw0.<clinit>")
            val list = (clinit.implementation ?: error("bw0.<clinit> sin codigo")).instructions.toList()
            val last = list.indexOfLast { it.opcode == Opcode.RETURN_VOID }
            if (last < 0 || last != list.lastIndex) error("bw0.<clinit>: no termina en return-void")

            fun hookFor(field: String, which: Int) = """
                sget-object v0, Lg21;->$field:Ljava/util/Map;
                const/4 v1, $which
                invoke-static {v1, v0}, $BUTTON_STYLES->apply(ILjava/util/Map;)Ljava/util/Map;
                move-result-object v0
                sput-object v0, Lg21;->$field:Ljava/util/Map;
            """

            clinit.addInstructions(last, hookFor("e", 0) + hookFor("f", 1) + hookFor("g", 2))

            // v1.91.0: Connect dinamico. di6.A(I, dw0, ow0, ki1, t43, Z) dibuja cada capa del reproductor Custom; justo
            // despues de `iget-object v8, v1, dw0.r` (nombre del icono de la capa) y antes de `iget-object v10, v1, dw0.b`
            // se pasa el nombre por ButtonStyles.autoSymbol(nombre, estado). v1 = dw0 y v3 = ow0 (estado), segun los
            // `move` del inicio del metodo (se comprueban abajo). Si no coincide, solo se omite este gancho.
            try {
                val di6 = mutableClassDefBy(classDefBy("Lq97;"))
                val a = di6.methods.singleOrNull {
                    it.name == "A" && it.parameterTypes.size == 6 &&
                        it.parameterTypes[0].toString() == "I" &&
                        it.parameterTypes[1].toString() == "Li21;" &&
                        it.parameterTypes[2].toString() == "Lu21;"
                } ?: error("di6.A no encontrado")
                val ins = (a.implementation ?: error("di6.A sin codigo")).instructions.toList()

                fun fieldOf(i: Int): FieldReference? =
                    (ins[i] as? ReferenceInstruction)?.reference as? FieldReference

                val hits = (0 until ins.size - 1).filter { i ->
                    ins[i].opcode == Opcode.IGET_OBJECT && ins[i + 1].opcode == Opcode.IGET_OBJECT &&
                        fieldOf(i)?.let { it.definingClass == "Li21;" && it.name == "r" && it.type == "Ljava/lang/String;" } == true &&
                        fieldOf(i + 1)?.let { it.definingClass == "Li21;" && it.name == "b" && it.type == "Lzm4;" } == true
                }
                if (hits.size != 1) error("di6.A: se esperaba 1 sitio (hay ${hits.size})")
                val at = hits[0]
                val dest = (ins[at] as OneRegisterInstruction).registerA
                val obj = (ins[at] as TwoRegisterInstruction).registerB
                if (dest != 8 || obj != 1) error("di6.A: registros inesperados (v$dest, v$obj)")
                // v3 debe ser el ow0 recibido: `move-object/from16 v3, <param>` al inicio y nunca reescrito antes
                val writesV3 = (0 until at).filter { i ->
                    val x = ins[i]
                    x is OneRegisterInstruction && x.registerA == 3
                }
                if (writesV3.size != 1 || ins[writesV3[0]].opcode != Opcode.MOVE_OBJECT_FROM16) {
                    error("di6.A: v3 no es solo el parametro ow0")
                }
                a.addInstructions(
                    at + 1,
                    """
                        invoke-static {v8, v3}, $BUTTON_STYLES->autoSymbol(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
                        move-result-object v8
                    """
                )
            } catch (e: Exception) {
                println("Connect dinamico omitido: ${e.message}")
            }
        }

        if (bars == true) {
            for (t in TARGETS) {
                val label = "${t.cls}.${t.name}"
                val cls = mutableClassDefBy(classDefBy(t.cls))
                val method = cls.methods.firstOrNull { m ->
                    m.name == t.name && m.parameterTypes.map { it.toString() } == t.params
                } ?: error("No se encontro $label")

                val list = (method.implementation ?: error("$label sin codigo")).instructions.toList()

                val heightIdx = list.indices.filter { i ->
                    val ins = list[i]
                    ins.opcode == Opcode.CONST_HIGH16 &&
                        (ins as NarrowLiteralInstruction).narrowLiteral == t.heightBits &&
                        i + 1 < list.size && isHeightCall(list[i + 1])
                }
                if (heightIdx.size != 1) error("$label: se esperaba 1 alto fijo y hay ${heightIdx.size}")

                val iconIdx = if (t.removeIcons) list.indices.filter { isIconCall(list[it]) } else emptyList()
                if (t.removeIcons && iconIdx.size != 2) {
                    error("$label: se esperaban 2 iconos (im3.a) y hay ${iconIdx.size}")
                }

                val animIdx = if (t.animatedHeight) list.indices.filter { i ->
                    isAnimatedHeightGet(list[i]) && i + 1 < list.size && isHeightCall(list[i + 1])
                } else emptyList()
                if (t.animatedHeight && animIdx.size != 1) {
                    error("$label: se esperaba 1 grosor animado (ha2.q) y hay ${animIdx.size}")
                }

                // Cada edicion: (indice, tipo). De atras hacia adelante para que los indices no se muevan.
                val edits = buildList {
                    iconIdx.forEach { add(it to Kind.REMOVE) }
                    add(heightIdx[0] to Kind.CONST_AND_CALL)
                    animIdx.forEach { add((it + 1) to Kind.CALL_ONLY) }
                }.sortedByDescending { it.first }

                for ((idx, kind) in edits) {
                    when (kind) {
                        Kind.REMOVE -> method.removeInstruction(idx)
                        Kind.CONST_AND_CALL -> {
                            val constReg = (list[idx] as OneRegisterInstruction).registerA
                            val call = list[idx + 1] as FiveRegisterInstruction
                            if (call.registerCount != 2 || call.registerD != constReg) {
                                error("$label: registros inesperados en height()")
                            }
                            val modReg = call.registerC
                            // height(X dp) -> fillMaxHeight(1f): g48.c = Modifier.fillMaxHeight(fraction).
                            method.removeInstruction(idx + 1)
                            method.removeInstruction(idx)
                            method.addInstructions(
                                idx,
                                """
                                    const v$constReg, ${t.fraction}
                                    invoke-static {v$modReg, v$constReg}, Lkz8;->c(Lou5;F)Lou5;
                                """
                            )
                        }
                        Kind.CALL_ONLY -> {
                            // Solo la llamada height(v) con v = grosor animado: se reemplaza por 1.0f + fillMaxHeight.
                            val call = list[idx] as FiveRegisterInstruction
                            if (call.registerCount != 2) error("$label: registros inesperados en height(animado)")
                            val modReg = call.registerC
                            val floatReg = call.registerD
                            method.removeInstruction(idx)
                            method.addInstructions(
                                idx,
                                """
                                    const v$floatReg, $TRACK_FRACTION
                                    invoke-static {v$modReg, v$floatReg}, Lkz8;->c(Lou5;F)Lou5;
                                """
                            )
                        }
                    }
                }
            }
        }
    }
}
