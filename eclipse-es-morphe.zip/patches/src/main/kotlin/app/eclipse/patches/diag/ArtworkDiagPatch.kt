package app.eclipse.patches.diag

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Mismo texto del log que usa el parche Canvas: identifica qf2.a(Context, Song, Continuation) en 0.6.47. */
private const val MARKER = "pick: no animated artwork found for '"

@Suppress("unused")
val artworkDiagPatch = bytecodePatch(
    name = "Diagnostico de portadas (temporal)",
    description = "Muestra un aviso con los datos de la cancion (ID de album de Apple y de Tidal, ISRC, album) " +
        "cada vez que Eclipse busca su portada animada. Solo para diagnostico: desactivalo despues.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.47?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val hasMarker = impl.instructions.any { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (!hasMarker) continue

            // En qf2.a(Context, Song, Continuation) la cancion es el 2.o parametro: p2.
            method.addInstructions(
                0,
                "invoke-static/range {p2 .. p2}, Lapp/eclipse/extension/diag/ArtworkDiag;->show(Ljava/lang/Object;)V"
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el diagnostico")
    }
}
