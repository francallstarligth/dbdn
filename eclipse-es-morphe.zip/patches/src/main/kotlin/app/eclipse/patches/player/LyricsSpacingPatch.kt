package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.451 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Letras: mas espacio entre lineas.
 *
 * `Lg22;.B` (fila de letra) arma `padding(horizontal = x, vertical = v)` con `Lsq4;->H(Lrb6; F F)` (justo antes: `if-eqz v7 -> 3.0 dp`,
 * si no `9.0 dp` (con config Ljr9) o `9.6 dp` (por defecto)). Por eso entre dos lineas quedan 2 x 9,6 = 19,2 dp.
 * Medido en las capturas (app de referencia vs Eclipse, 900 px de ancho): hueco extra entre bloques 64 px vs 41 px (~1,5 veces).
 * Aqui, justo despues de cada uno de esos dos `const` (9.0 y 9.6) se vuelve a escribir en el mismo registro 13 dp y 14 dp.
 * El caso de 3 dp no se toca. Si no encuentra exactamente cada constante pegada al `Lsq4.H` -> error (version distinta).
 */
@Suppress("unused")
val lyricsSpacingPatch = bytecodePatch(
    description = "Mas espacio entre una linea de letra y la siguiente (como la app de referencia). " +
        "Desmarcalo si prefieres el espacio original de Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lg22;"))
        val b = cls.methods.singleOrNull {
            it.name == "B" && it.parameterTypes.size == 23 && it.parameterTypes[0].toString() == "Len5;"
        } ?: error("Espaciado: no se encontro Lg22.B")
        val ins = (b.implementation ?: error("Espaciado: Lg22.B sin codigo")).instructions.toList()

        val padCalls = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lsq4;" && r.name == "H" &&
                r.parameterTypes.map { it.toString() } == listOf("Lrb6;", "F", "F")
        }
        if (padCalls.size != 1) error("Espaciado: Lg22.B: se esperaba 1 llamada a Lsq4.H y hay ${padCalls.size}")
        val call = padCalls[0]

        fun find(op: Opcode, bits: Int, altBits: Int?): Int {
            val hits = (maxOf(0, call - 8) until call).filter { i ->
                ins[i].opcode == op && (ins[i] as NarrowLiteralInstruction).narrowLiteral.let { it == bits || it == altBits }
            }
            if (hits.size != 1) error("Espaciado: se esperaba 1 const (0x${bits.toString(16)}) pegado a Lsq4.H y hay ${hits.size}")
            return hits[0]
        }
        // 9.0f = 0x41100000 (const/high16)   9.6f = 0x4119999A (const)
        val nine = find(Opcode.CONST_HIGH16, 0x41100000, 0x4110)
        val nineSix = find(Opcode.CONST, 0x4119999A, null)
        val rNine = (ins[nine] as OneRegisterInstruction).registerA
        val rSix = (ins[nineSix] as OneRegisterInstruction).registerA
        // 1o el indice mas alto, para que el otro no se mueva
        val (hi, lo) = if (nineSix > nine) (nineSix to rSix) to (nine to rNine) else (nine to rNine) to (nineSix to rSix)
        val v = { r: Int, at: Int -> if (at == nine) "const/high16 v$r, 0x41500000" else "const/high16 v$r, 0x41600000" } // 13 dp / 14 dp
        b.addInstructions(hi.first + 1, v(hi.second, hi.first))
        b.addInstructions(lo.first + 1, v(lo.second, lo.first))
    }
}
