package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.451/452 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Letras: mas espacio entre lineas.
 *
 * `Lg22;.B` (fila de letra) arma `padding(horizontal = x, vertical = v)` con `Lsq4;->H(Lrb6; F F)` (justo antes: `if-eqz v7 -> 3.0 dp`,
 * si no `9.0 dp` (con config Ljr9) o `9.6 dp` (por defecto)). Por eso entre dos lineas quedan 2 x 9,6 = 19,2 dp.
 * Medido en las capturas (app de referencia vs Eclipse, 900 px de ancho): hueco extra entre bloques 64 px vs 41 px (~1,5 veces).
 * Aqui, justo despues de cada uno de esos dos `const` (9.0 y 9.6) se vuelve a escribir en el mismo registro 13 dp y 14 dp.
 * El caso de 3 dp no se toca.
 * v0.20.452: tambien el alto de linea (renglones de una misma frase). En el mismo metodo se arma el TextStyle (`Luta.<init>`) con
 * lineHeight = tamano * 1.2 (`const v12, 0x3F99999A` -> `mul-float/2addr v12, v10` -> `Lqe8;->b0(J F)J`). Medido en las capturas: 100 px (referencia)
 * vs 91-95 px (Eclipse) entre renglones, ~8 % -> 1.3 (0x3FA66666).
 * Si no encuentra exactamente cada constante pegada al `Lsq4.H` -> error (version distinta).
 */
@Suppress("unused")
val lyricsSpacingPatch = bytecodePatch(
    description = "Mas espacio entre una linea de letra y la siguiente, y un poco mas entre renglones (como la app de referencia). " +
        "Desmarcalo si prefieres el espacio original de Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lg22;"))
        val b = cls.methods.singleOrNull {
            it.name == "B" && it.parameterTypes.size == 23 && it.parameterTypes[0].toString() == "Len5;"
        } ?: error("Espaciado: no se encontro Lg22.B")
        val ins = (b.implementation ?: error("Espaciado: Lg22.B sin codigo")).instructions.toList()

        val padCalls = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lsq4;" && r.name == "H" &&
                r.parameterTypes.map { it.toString() } == listOf("Lrb6;", "F", "F")
        }
        if (padCalls.size != 1) error("Espaciado: Lg22.B: se esperaba 1 llamada a Lsq4.H y hay ${padCalls.size}")
        val call = padCalls[0]

        fun find(op: Opcode, bits: Int, altBits: Int?): Int {
            val hits = (maxOf(0, call - 8) until call).filter { i ->
                ins[i].opcode == op && (ins[i] as NarrowLiteralInstruction).narrowLiteral.let { it == bits || it == altBits }
            }
            if (hits.size != 1) error("Espaciado: se esperaba 1 const (0x${bits.toString(16)}) pegado a Lsq4.H y hay ${hits.size}")
            return hits[0]
        }
        // 9.0f = 0x41100000 (const/high16)   9.6f = 0x4119999A (const)
        val nine = find(Opcode.CONST_HIGH16, 0x41100000, 0x4110)
        val nineSix = find(Opcode.CONST, 0x4119999A, null)
        val rNine = (ins[nine] as OneRegisterInstruction).registerA
        val rSix = (ins[nineSix] as OneRegisterInstruction).registerA
        // 1o el indice mas alto, para que el otro no se mueva
        val (hi, lo) = if (nineSix > nine) (nineSix to rSix) to (nine to rNine) else (nine to rNine) to (nineSix to rSix)
        val v = { r: Int, at: Int -> if (at == nine) "const/high16 v$r, 0x41500000" else "const/high16 v$r, 0x41600000" } // 13 dp / 14 dp
        // alto de linea: const 1.2f seguido de mul-float/2addr (mismo registro)
        val lh = ins.indices.filter { i ->
            ins[i].opcode == Opcode.CONST && (ins[i] as NarrowLiteralInstruction).narrowLiteral == 0x3F99999A &&
                i + 1 < ins.size && ins[i + 1].opcode == Opcode.MUL_FLOAT_2ADDR
        }
        if (lh.size != 1) error("Espaciado: se esperaba 1 'const 1.2f' + mul-float/2addr (alto de linea) y hay ${lh.size}")
        val rLh = (ins[lh[0]] as OneRegisterInstruction).registerA
        if ((ins[lh[0] + 1] as OneRegisterInstruction).registerA != rLh) error("Espaciado: el mul-float/2addr no usa el registro de la constante 1.2")
        // de mas adelante a mas atras, para no mover los indices
        val todos = listOf(
            hi.first to v(hi.second, hi.first),
            lo.first to v(lo.second, lo.first),
            lh[0] to "const v$rLh, 0x3fa66666"
        ).sortedByDescending { it.first }
        for ((i, code) in todos) b.addInstructions(i + 1, code)
    }
}
