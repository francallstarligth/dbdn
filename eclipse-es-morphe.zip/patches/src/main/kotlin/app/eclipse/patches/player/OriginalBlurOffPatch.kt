package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"
private const val SONG = "Lcom/eclipse/android/data/models/Song;"

/**
 * v0.20.17 (SIN PROBAR). Apaga el fondo borroso ORIGINAL de Eclipse (ja7.c, rama BLURRED_ARTWORK) cuando el diseno
 * es como Bitchord (portada arriba + reflejo nuestro debajo). Antes de llamar a ja7.c se cambia la cancion por null:
 * ja7.c ya tiene su camino "sin portada" (no dibuja el borroso), asi no se toca la estructura de Compose.
 */
@Suppress("unused")
val originalBlurOffPatch = bytecodePatch(
    name = "Bitchord: quitar fondo borroso original",
    description = "Con un diseno tipo Bitchord (portada nitida arriba y reflejo debajo) quita el fondo borroso original " +
        "de Eclipse, que queda casi todo tapado y consume de mas. Si se ve raro (bordes oscuros), desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    val fill by booleanOption(
        key = "fill",
        default = true,
        title = "Rellenar el hueco con un fondo liviano",
        description = "Al quitar el fondo original pueden verse huecos oscuros (por ejemplo al arrastrar la portada con el dedo). " +
            "Con esto se dibuja detras la portada borrosa en tamano chiquito (1/8) estirada a toda la pantalla: se ve parecida al " +
            "fondo original pero gasta muy poco. Desmarcalo si no la quieres."
    )

    execute {
        val k97 = mutableClassDefBy(classDefBy("Lk97;"))
        val method = k97.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro k97.g (version de Eclipse distinta de 0.6.61?)")

        val list = (method.implementation ?: error("k97.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lja7;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } == listOf("Lu21;", "Z", SONG, "Lzq1;", "I")
        } ?: error("k97.g: no se encontro ja7.c(y11, Z, Song, cq1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val songReg = call.registerE   // Song (3er argumento)

        // d37 (el layout): iget-object vX, vThis, Lk97;->q:Lx37;
        val layoutGet = (callIdx - 1 downTo maxOf(0, callIdx - 40)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lk97;" && ref.name == "q" &&
                ref.type == "Lx37;"
        } ?: error("k97.g: no se encontro k97.q (d37) antes de ja7.c")
        val layoutReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Que nadie reescriba el registro del layout entre su lectura y la llamada.
        for (i in layoutGet + 1 until callIdx) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == layoutReg) ||
                (ins.opcode.setsWideRegister() && (a == layoutReg || a + 1 == layoutReg))
            if (hit) error("k97.g: v$layoutReg se reescribe antes de ja7.c")
        }
        if (songReg > 15 || layoutReg > 15) error("k97.g: registros fuera de rango para invoke-static")
        if (songReg == layoutReg) error("k97.g: registros repetidos")

        val fn = if (fill == true) "songForBlurFill" else "songForBlur"
        method.addInstructions(
            callIdx,
            """
                invoke-static {v$songReg, v$layoutReg}, $HELPER->$fn(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$songReg
                check-cast v$songReg, $SONG
            """
        )
    }
}
