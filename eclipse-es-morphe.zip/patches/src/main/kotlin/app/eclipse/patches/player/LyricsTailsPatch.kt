package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val POP_TAILS = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.111 (SIN COMPILAR / SIN PROBAR). Eclipse (pu1.G0, leido en el smali del APK Base) recorta CADA renglon de la
 * letra activa a su caja con Ls25;->I(FFFFI)V (clipRect): izquierda -v5, arriba = -v5 (primer renglon) o xt4.a,
 * derecha ancho+v5, abajo = alto+v5 (ultimo renglon) o xt4.b. Por eso las colas (g, y, p) del renglon de arriba salen
 * cortadas. Este parche, justo antes de esa llamada (v18 = arriba, v20 = abajo, v5 = tamano de letra en px, v7 = indice
 * del renglon, v3 = ArrayList de renglones), alarga el recorte de abajo de los renglones que tienen otro debajo y baja el
 * de arriba de los que tienen otro encima (para no dibujar dos veces la cola). Tambien activa los margenes del recorte
 * propio de LyricsPop (enableTails).
 */
@Suppress("unused")
val lyricsTailsPatch = bytecodePatch(
    description = "Cuando una frase ocupa dos renglones, no corta las colas de letras como la g, la y o la p del " +
        "renglon de arriba. Necesita \"Letras: silaba por silaba\". Desmarcalo si ves algo raro.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(lyricsSyllablesPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Lqu1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "G0" && it.parameterTypes.map { p -> p.toString() } == listOf("Lmn4;")
        } ?: error("No se encontro pu1.G0 (version de Eclipse distinta de 0.6.55?)")
        e0.addInstructions(0, "invoke-static {}, $POP_TAILS->enableTails()V")

        // Se busca DESPUES de insertar arriba, con la lista fresca.
        val list = (e0.implementation ?: error("pu1.G0 sin codigo")).instructions.toList()
        val idx = list.indices.filter { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lc98;" && ref.name == "M" &&
                ref.parameterTypes.map { it.toString() } == listOf("F", "F", "F", "F", "I")
        }
        if (idx.size != 1) error("pu1.G0: se esperaba 1 llamada a z88.M (clipRect) y hay ${idx.size}")
        e0.addInstructions(
            idx[0],
            """
                invoke-static {v7, v5, v3}, $POP_TAILS->clipCtx(IFLjava/util/ArrayList;)V
                invoke-static/range {v18 .. v18}, $POP_TAILS->clipTop(F)F
                move-result v18
                invoke-static/range {v20 .. v20}, $POP_TAILS->clipBottom(F)F
                move-result v20
            """
        )
    }
}
