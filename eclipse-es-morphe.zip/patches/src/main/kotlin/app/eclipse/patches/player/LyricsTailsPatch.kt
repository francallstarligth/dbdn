package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val POP_TAILS = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.110 (SIN COMPILAR / SIN PROBAR). Interruptor de "Letras: colas de letras completas" (mismo estilo que
 * LyricsGlowPatch): al empezar tn1.E0 llama LyricsPop.enableTails(). Sin este parche el recorte de cada renglon
 * queda como antes.
 */
@Suppress("unused")
val lyricsTailsPatch = bytecodePatch(
    name = "Letras: colas de letras completas",
    description = "Cuando una frase ocupa dos renglones, no corta las colas de letras como la g, la y o la p del " +
        "renglon de arriba. Necesita \"Letras: silaba por silaba\". Desmarcalo si ves algo raro.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(lyricsSyllablesPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Ltn1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "E0" && it.parameterTypes.map { p -> p.toString() } == listOf("Lad4;")
        } ?: error("No se encontro tn1.E0 (version de Eclipse distinta de 0.6.47?)")
        e0.addInstructions(0, "invoke-static {}, $POP_TAILS->enableTails()V")
    }
}
