package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val FADE_MASK = "Lapp/eclipse/extension/player/FadeMask;"

/** BlendMode.DstOut = 8. Mascara de "valores por defecto" de DrawScope.drawRect: 0x78 sin el bit del blendMode (0x40). */
private const val DST_OUT = 8
private const val MASK_WITHOUT_BLEND = 0x38

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun regName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

@Suppress("unused")
val transparentEdgeFadePatch = bytecodePatch(
    name = "Custom: fundido transparente de la portada",
    description = "En el reproductor Custom, el fundido de la portada inmersiva (edgeFade) pinta un color encima. " +
        "Con este parche borra la portada de a poco (transparente), como el Eclipse oficial, y se ve el fondo " +
        "que hay debajo (p. ej. \"Blurred Cover\").",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // 1) di6.a(int, dw0, ow0, ki1, t43, boolean): la caja del fondo inmersivo. Su primer modificador es
        //    g48.e(Modifier.Companion, 1.0f) (fillMaxSize); justo despues se le agrega la capa fuera de pantalla.
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val boxMethod = di6.methods.firstOrNull { m ->
            m.name == "a" && m.returnType == "V" && m.parameterTypes.map { it.toString() } ==
                listOf("I", "Ldw0;", "Low0;", "Lki1;", "Lt43;", "Z")
        } ?: error("No se encontro di6.a (version de Eclipse distinta de 0.6.47?)")
        run {
            val list = (boxMethod.implementation ?: error("di6.a sin codigo")).instructions.toList()
            val idx = list.indices.firstOrNull { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null && ref.definingClass == "Lg48;" && ref.name == "e" && ref.returnType == "Lmh5;" &&
                    i + 1 < list.size && list[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT
            } ?: error("di6.a: no se encontro g48.e(...)")
            val reg = regName((list[idx + 1] as OneRegisterInstruction).registerA, boxMethod)
            boxMethod.addInstructions(
                idx + 2,
                """
                    invoke-static {$reg}, $FADE_MASK->wrap(Ljava/lang/Object;)Ljava/lang/Object;
                    move-result-object $reg
                    check-cast $reg, Lmh5;
                """
            )
        }

        // 2) bd6.invoke (caso del edgeFade): el degradado se dibuja con drawRect(..., blendMode). Se cambia a DstOut.
        val bd6 = mutableClassDefBy(classDefBy("Lbd6;"))
        var patched = 0
        for (method in bd6.methods) {
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val castIdx = list.indexOfFirst { ins ->
                ins.opcode == Opcode.CHECK_CAST &&
                    ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Ljh2;"
            }
            if (castIdx < 0) continue
            val callIdx = (castIdx until list.size).firstOrNull { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null && ref.definingClass == "Lhd2;" && ref.name == "S0"
            } ?: continue
            val call = list[callIdx]
            if (call !is RegisterRangeInstruction) error("bd6: hd2.S0 no es invoke/range")
            if (call.registerCount != 11) error("bd6: hd2.S0 con ${call.registerCount} registros (se esperaban 11)")
            val blendReg = regName(call.startRegister + 9, method)
            val maskReg = regName(call.startRegister + 10, method)
            method.addInstructions(
                callIdx,
                """
                    const/16 $blendReg, $DST_OUT
                    const/16 $maskReg, $MASK_WITHOUT_BLEND
                """
            )
            patched++
            break
        }
        if (patched == 0) error("No se encontro el dibujo del edgeFade en bd6")
    }
}
