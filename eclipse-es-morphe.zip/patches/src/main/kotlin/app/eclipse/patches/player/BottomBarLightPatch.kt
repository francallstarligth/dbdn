package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.438 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): vidrio de la barra de abajo mas liviano al hacer scroll.
 *
 * Visto en el dex 75: `Lmo;->U(...)` (= drawBackdrop) recibe una escala del fondo (float, entre 0.05 y 1.0) que
 * reduce el tamano al que se dibuja y difumina el fondo. Los demas vidrios (`Lfg5.f`, `Lpg5.c`, `Lpr9.e`, ...) la
 * calculan con `La82.Q(radio)` = 0.3 si el blur es >= 7 dp. `Lcp9.e` (strings "lens", "pill", "tabBar" = la barra de
 * abajo, que se achica con la animacion "onScrollDown") la deja en el valor por defecto = 1.0 (tamano completo):
 * la mascara de la llamada es 31712 (bit 4096 puesto = usar 1.0 por defecto) y el float va en el registro v22.
 * Arreglo: en esa llamada se quita el bit 4096 de la mascara y el float pasa a 0.3.
 */
private const val ESCALA_030 = "0x3e99999a" // 0.3f
private const val BIT_ESCALA = 4096

@Suppress("unused")
val bottomBarLightPatch = bytecodePatch(
    name = "Barra de abajo: vidrio liviano",
    description = "Al hacer scroll la barra de abajo se achica y se anima; su vidrio se dibuja a tamano completo. " +
        "Con este parche se dibuja mas chico (30 %, como el resto de los vidrios) y cuesta menos. La animacion " +
        "queda igual; los bordes del efecto de lente pueden verse un poco mas suaves. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cp9 = mutableClassDefBy(classDefBy("Lcp9;"))
        val esperados = listOf(
            "Lrx0;", "Ldv8;", "Ljava/lang/String;", "J", "D", "F", "Ldk3;", "Ldk3;", "Lcq0;", "Ldk3;", "Leu1;", "I", "I"
        )
        val metodo = cp9.methods.singleOrNull {
            it.name == "e" && it.returnType == "V" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("No se encontro cp9.e (vidrio de la barra de abajo; Eclipse 0.6.75)")
        val ins = (metodo.implementation ?: error("cp9.e sin codigo")).instructions.toList()

        val llamadas = ins.indices.filter { i ->
            val a = ins[i]
            val ref = (a as? ReferenceInstruction)?.reference as? MethodReference
            a.opcode == Opcode.INVOKE_STATIC_RANGE && ref != null && ref.definingClass == "Lmo;" &&
                ref.name == "U" && ref.parameterTypes.size == 14
        }
        if (llamadas.size != 1) error("cp9.e: se esperaba 1 llamada a mo.U (hay ${llamadas.size})")
        val idx = llamadas[0]
        val call = ins[idx] as RegisterRangeInstruction
        if (call.registerCount != 14) error("cp9.e: mo.U con ${call.registerCount} registros (se esperaban 14)")
        val regEscala = call.startRegister + 11
        val regMascara = call.startRegister + 13

        // Ultimas asignaciones antes de la llamada (hacia atras): mascara (const/16) y escala (const/16 0).
        var idxMascara = -1
        var idxEscala = -1
        for (j in idx - 1 downTo maxOf(0, idx - 60)) {
            val a = ins[j]
            if (a.opcode != Opcode.CONST_16) continue
            val reg = (a as OneRegisterInstruction).registerA
            if (reg == regMascara && idxMascara < 0) idxMascara = j
            if (reg == regEscala && idxEscala < 0) idxEscala = j
        }
        if (idxMascara < 0 || idxEscala < 0) error("cp9.e: no se hallaron las constantes de mascara/escala")
        val mascara = (ins[idxMascara] as NarrowLiteralInstruction).narrowLiteral
        if (mascara and BIT_ESCALA == 0) error("cp9.e: la mascara $mascara ya trae escala propia (inesperado)")

        metodo.replaceInstruction(idxMascara, "const/16 v$regMascara, ${mascara and BIT_ESCALA.inv()}")
        metodo.replaceInstruction(idxEscala, "const v$regEscala, $ESCALA_030")
    }
}
