package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.234 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Arregla el parpadeo de Letra<->Cola en el canvas
 * (Apple Music V2 editable, Bitchord).
 *
 * Causa (medida con TabDiag): la Cola se compone DOS veces por cambio: al empezar (alfa ~0, no se nota) y otra vez
 * ~265 ms despues, justo cuando Letra llega a peso <= 0.001 y deja de componerse (alfa 1: se ve vacia 3-4 cuadros).
 * En rb7.b cada panel de la caja es una iteracion de un `for`; una pestana con peso <= 0.001 no emite NINGUN grupo
 * de Compose (salta al inicio del `for`). Los grupos de rama son `startReplaceGroup` (d0/q), que se alinean por
 * POSICION: al desaparecer el grupo de Letra, el de Cola cae en la posicion del de Letra, la clave no coincide y
 * Compose lo reemplaza (lo recrea: lista `sd9` nueva y vacia, portadas recargando). En Cola->Letra pasa al reves al empezar.
 *
 * Arreglo: en la rama "peso <= 0.001" de ese `for`, emitir un grupo vacio (d0 + q(false)), asi cada iteracion deja
 * siempre exactamente un grupo y las posiciones no se corren.
 */
@Suppress("unused")
val tabKeepPatch = bytecodePatch(
    name = "Pestanas: no recrear la Cola al cambiar Letra/Cola",
    description = "Arregla el parpadeo de la Cola (cartel \"Nada a continuacion\" y portadas vacias) al cambiar entre Letra y " +
        "Cola en los reproductores Custom (Apple Music V2 editable, Bitchord): al ocultarse una pestana, la otra ya no se " +
        "destruye y se vuelve a crear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val rb7 = mutableClassDefBy(classDefBy("Ltr7;"))
        val b = rb7.methods.singleOrNull {
            it.name == "b" && it.returnType == "V" && it.parameterTypes.size == 8 &&
                it.parameterTypes[0] == "Lwj7;" && it.parameterTypes[1] == "Lr51;"
        } ?: error("Pestanas: no se encontro rb7.b (version de Eclipse distinta de 0.6.70?)")
        val ins = (b.implementation ?: error("Pestanas: rb7.b sin codigo")).instructions.toList()

        // Direcciones (en unidades de codigo) de cada instruccion, para resolver el destino del if.
        val addr = IntArray(ins.size)
        var a = 0
        for (i in ins.indices) { addr[i] = a; a += ins[i].codeUnits }

        // Llamadas a s31.e(String): la ULTIMA es la del peso de cada panel (las 2 anteriores son el max del contenedor).
        val weightCalls = ins.withIndex().filter { (_, x) ->
            x.opcode == Opcode.INVOKE_VIRTUAL &&
                ((x as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lr51;" && it.name == "e" && it.returnType == "F"
                } == true
        }.map { it.index }
        if (weightCalls.size != 3) error("Pestanas: se esperaban 3 llamadas a s31.e en rb7.b y hay ${weightCalls.size}")
        val last = weightCalls.last()

        // Tras ella: move-result, cmpg-float, if-lez (peso <= 0.001 -> saltar).
        val cmpAt = (last + 1..last + 3).firstOrNull { ins[it].opcode == Opcode.CMPG_FLOAT }
            ?: error("Pestanas: no hay cmpg-float tras la ultima s31.e")
        val ifAt = cmpAt + 1
        if (ins[ifAt].opcode != Opcode.IF_LEZ) error("Pestanas: tras cmpg-float no hay if-lez")
        val targetAddr = addr[ifAt] + (ins[ifAt] as OffsetInstruction).codeOffset
        val target = addr.indexOf(targetAddr)
        if (target < 0) error("Pestanas: no se resolvio el destino del if-lez")

        // El destino empieza con un `move-object/from16 v25, v5`; el codigo nuevo va DESPUES de esa primera instruccion
        // (no depende de a donde apunten las etiquetas) y antes de volver al inicio del `for`.
        // v8 = composer (Lfr1) en todo el `for`; v0 se reasigna al volver al inicio del `for`, asi que es libre.
        b.addInstructions(
            target + 1,
            """
            const v0, 0x4e4f5041
            invoke-virtual {v8, v0}, Ltt1;->d0(I)V
            const/4 v0, 0x0
            invoke-virtual {v8, v0}, Ltt1;->q(Z)V
            """
        )
    }
}
