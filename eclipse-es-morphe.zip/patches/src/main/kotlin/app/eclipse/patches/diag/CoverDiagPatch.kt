package app.eclipse.patches.diag

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val DIAG = "Lapp/eclipse/extension/diag/CoverDiag;"

@Suppress("unused")
val coverDiagPatch = bytecodePatch(
    name = "Diagnostico del reproductor (temporal)",
    description = "Al abrir el reproductor copia al portapapeles quien dibuja las imagenes (portada) para ubicar " +
        "donde poner el fundido. No cambia nada visible. Solo para diagnostico: desactivalo despues.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        fun hook(className: String, name: String, params: List<String>, call: String) {
            val cls = mutableClassDefBy(classDefBy(className))
            val method = cls.methods.firstOrNull { m ->
                m.name == name && m.returnType == "V" &&
                    m.parameterTypes.map { it.toString() } == params && m.implementation != null
            } ?: error("No se encontro $className->$name (version de Eclipse distinta de 0.6.47?)")
            // Metodo estatico sin llamada previa: el gancho no usa registros.
            method.addInstructions(0, "invoke-static {}, $DIAG->$call()V")
        }

        // by9.c(d43, mh5, t43, un3, sn3, f43, v43, ki1, int, int, int): carga de imagen por URL.
        hook(
            "Lby9;", "c",
            listOf("Ld43;", "Lmh5;", "Lt43;", "Lun3;", "Lsn3;", "Lf43;", "Lv43;", "Lki1;", "I", "I", "I"),
            "hitC"
        )
        // bc2.f(un, String, mh5, bn1, ki1, int, int): dibujo de un bitmap.
        hook(
            "Lbc2;", "f",
            listOf("Lun;", "Ljava/lang/String;", "Lmh5;", "Lbn1;", "Lki1;", "I", "I"),
            "hitF"
        )
    }
}
