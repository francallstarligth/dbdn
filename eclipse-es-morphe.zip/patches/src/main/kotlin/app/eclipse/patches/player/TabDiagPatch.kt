package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val DIAG = "Lapp/eclipse/extension/player/TabDiag;"

/**
 * v0.20.231 (SIN COMPILAR NI PROBAR). DIAGNOSTICO TEMPORAL, apagado por defecto. Solo anota; no cambia nada del reproductor.
 * Eclipse 0.6.61. Ganchos al INICIO de:
 *  - s31.d(String): cambio de pestana (con quien lo llamo y el valor de d).
 *  - s31.c(): reinicio (f=false, g++).
 *  - a0.b(Object): pasos de la corrutina del fundido (snapTo / animateTo).
 *  - t50.y(pu7, sd9, j16): llena la lista de la Cola.
 *  - t50.j(zq1, I): dibuja el cartel "Nada a continuacion".
 * TabDiag copia el registro al portapapeles 1,2 s despues del ultimo evento.
 */
@Suppress("unused")
val tabDiagPatch = bytecodePatch(
    name = "Diagnostico: registro de pestanas (portapapeles)",
    description = "TEMPORAL. Anota con hora cada cambio de pestana (Artwork/Letra/Cola), los pasos del fundido y el cartel " +
        "\"Nada a continuacion\", y copia el registro al portapapeles unos segundos despues del ultimo toque. " +
        "Para buscar por que la lista de la Cola parpadea. No cambia nada del reproductor.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val s31 = mutableClassDefBy(classDefBy("Ls31;"))
        val d = s31.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/String;"
        } ?: error("No se encontro s31.d(String)")
        d.addInstructions(0, "invoke-static {p0, p1}, $DIAG->d(Ljava/lang/Object;Ljava/lang/String;)V")

        val c = s31.methods.singleOrNull {
            it.name == "c" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro s31.c()")
        c.addInstructions(0, "invoke-static {p0}, $DIAG->c(Ljava/lang/Object;)V")

        val a0 = mutableClassDefBy(classDefBy("La0;"))
        val b = a0.methods.singleOrNull {
            it.name == "b" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("No se encontro a0.b(Object)")
        b.addInstructions(0, "invoke-static {p0}, $DIAG->a0(Ljava/lang/Object;)V")

        val t50 = mutableClassDefBy(classDefBy("Lt50;"))
        val y = t50.methods.singleOrNull {
            it.name == "y" && it.returnType == "V" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0] == "Lpu7;" && it.parameterTypes[1] == "Lsd9;"
        } ?: error("No se encontro t50.y")
        y.addInstructions(0, "invoke-static {}, $DIAG->llenar()V")

        val j = t50.methods.singleOrNull {
            it.name == "j" && it.returnType == "V" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0] == "Lzq1;" && it.parameterTypes[1] == "I"
        } ?: error("No se encontro t50.j")
        j.addInstructions(0, "invoke-static {}, $DIAG->nada()V")
    }
}
