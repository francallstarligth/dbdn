package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val POP = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.73 (SIN COMPILAR / SIN PROBAR). tn1.E0 es el dibujo de la linea de letra (nodo de dibujo). Para la linea activa
 * (rama del degradado: el borde del relleno cae dentro de la linea) hace cy7.C(ad4, vy8, degradado). Justo antes de
 * esa llamada se dibujan 2 copias blancas del texto, mas grandes, recortadas a una ventana que termina en el borde del
 * relleno (LyricsPop). Registros libres ahi (verificado en el smali): v3, v13, v14. Entradas: v15 = x del borde,
 * v18 = arriba y v20 = abajo de la linea, v5 = tamano de letra en px, v9 = lienzo (ba5), v1 = ad4, v4 = vy8,
 * v0 = nodo (campo N = color de lo cantado). Si el lienzo no es el esperado (uk) no hace nada.
 */
@Suppress("unused")
val lyricsPopPatch = bytecodePatch(
    name = "Letras: letras grandes junto al relleno",
    description = "En la linea de letra que suena, las letras cercanas al borde del relleno se ven un poco mas grandes " +
        "(la que se canta, la mas grande), como en la referencia. No cambia el texto ni el acomodo. " +
        "Desmarcalo si las letras se ven raras o cortadas.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Ltn1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "E0" && it.parameterTypes.map { p -> p.toString() } == listOf("Lad4;")
        } ?: error("No se encontro tn1.E0 (version de Eclipse distinta de 0.6.47?)")
        val list = (e0.implementation ?: error("tn1.E0 sin codigo")).instructions.toList()
        val idx = list.indices.filter { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lcy7;" &&
                ref.name == "C" && ref.parameterTypes.map { it.toString() } == listOf("Lad4;", "Lvy8;", "Lkm4;")
        }
        if (idx.size != 1) error("tn1.E0: se esperaba 1 llamada a cy7.C y hay ${idx.size}")
        e0.addInstructions(
            idx[0],
            """
                invoke-virtual {v9}, Lba5;->C()Lnv0;
                move-result-object v3
                instance-of v13, v3, Luk;
                if-eqz v13, :lyrics_pop_skip
                check-cast v3, Luk;
                iget-object v3, v3, Luk;->a:Landroid/graphics/Canvas;
                move/from16 v13, v18
                move/from16 v14, v20
                invoke-static {v3, v15, v13, v14, v5}, $POP->begin1(Landroid/graphics/Canvas;FFFF)V
                iget-wide v13, v0, Ltn1;->N:J
                invoke-static {v1, v4, v13, v14}, Lcy7;->D(Lad4;Lvy8;J)V
                invoke-static {v3}, $POP->end(Landroid/graphics/Canvas;)V
                move/from16 v13, v18
                move/from16 v14, v20
                invoke-static {v3, v15, v13, v14, v5}, $POP->begin2(Landroid/graphics/Canvas;FFFF)V
                iget-wide v13, v0, Ltn1;->N:J
                invoke-static {v1, v4, v13, v14}, Lcy7;->D(Lad4;Lvy8;J)V
                invoke-static {v3}, $POP->end(Landroid/graphics/Canvas;)V
                :lyrics_pop_skip
            """
        )
    }
}
