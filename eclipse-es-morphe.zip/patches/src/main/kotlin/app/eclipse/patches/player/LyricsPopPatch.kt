package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.util.smali.ExternalLabel
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val POP = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.77 (SIN COMPILAR / SIN PROBAR). nv1.G0 es el dibujo de la linea de letra (nodo de dibujo). Para la linea activa
 * (rama del degradado: el borde del relleno cae dentro de la fila) hace cy7.C(ad4, vy8, degradado). Justo antes de
 * esa llamada, LyricsPop.begin guarda (vy8, fila, borde, tamano de letra) y LyricsPop.draw hace el efecto SILABA POR
 * SILABA (la silaba del borde mas grande y las ya cantadas bajando de tamano; las silabas se cortan con reglas en Syllables.java) llamando a cy7.C por reflexion; si dibujo
 * devuelve true se salta la llamada original, si no, sigue la original sin cambios. Registros libres ahi (verificado
 * en el smali): v3, v8, v13, v14. Entradas: v15 = x del borde, v5 = tamano de letra en px, v7 = indice de la fila
 * (= linea del texto), v4 = vy8, v1 = ad4, v2 = degradado (km4), v9 = lienzo (ba5). v10/v11 (guardados del lienzo)
 * NO se tocan. Si el lienzo no es el esperado (uk) no hace nada.
 */
@Suppress("unused")
val lyricsPopPatch = bytecodePatch(
    description = "En la linea de letra que suena, la silaba donde va el relleno se ve mas grande y las ya cantadas " +
        "van bajando de tamano (silaba por silaba, como Apple Music). No cambia el texto ni el acomodo. " +
        "Desmarcalo si las letras se ven raras o cortadas.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Lwz1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "I0" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljw4;")
        } ?: error("No se encontro nv1.G0 (version de Eclipse distinta de 0.6.57?)")
        val list = (e0.implementation ?: error("nv1.G0 sin codigo")).instructions.toList()
        val idx = list.indices.filter { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Llb8;" &&
                ref.name == "p" && ref.parameterTypes.map { it.toString() } == listOf("Ljw4;", "Ltqa;", "Ll65;")
        }
        if (idx.size != 1) error("nv1.G0: se esperaba 1 llamada a do7.G y hay ${idx.size}")
        // La instruccion que sigue a cy7.C debe ser la que restaura el lienzo de la fila (Lhx5;->A); si no, no tocar nada.
        val nx = list[idx[0] + 1]
        val nxRef = (nx as? ReferenceInstruction)?.reference as? MethodReference
        if (nx.opcode != Opcode.INVOKE_STATIC || nxRef == null || nxRef.definingClass != "Ln97;" || nxRef.name != "x") {
            error("nv1.G0: despues de do7.G no esta Lcv6;->x (version de Eclipse distinta?)")
        }
        // Etiquetas externas (como PreviousCoverPatch): "skip" = la llamada cy7.C original (sigue igual);
        // "done" = la instruccion que va despues de esa llamada (restaurar el lienzo de la fila).
        val skipTarget = e0.getInstruction(idx[0])
        val doneTarget = e0.getInstruction(idx[0] + 1)
        e0.addInstructionsWithLabels(
            idx[0],
            """
                invoke-virtual {v9}, Lz36;->C()Lf51;
                move-result-object v3
                instance-of v13, v3, Lzm;
                if-eqz v13, :lyrics_pop_skip
                check-cast v3, Lzm;
                invoke-static {v3}, $POP->setCanvasOwner(Ljava/lang/Object;)V
                iget-object v3, v3, Lzm;->a:Landroid/graphics/Canvas;
                invoke-static {v4, v7, v15, v5}, $POP->begin(Ljava/lang/Object;IFF)V
                invoke-static {v3, v1, v2}, $POP->draw(Landroid/graphics/Canvas;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v8
                if-eqz v8, :lyrics_pop_skip
                goto :lyrics_pop_done
            """,
            ExternalLabel("lyrics_pop_skip", skipTarget),
            ExternalLabel("lyrics_pop_done", doneTarget)
        )
    }
}
