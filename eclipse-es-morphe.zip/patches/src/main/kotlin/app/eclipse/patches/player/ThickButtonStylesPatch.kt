package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val BUTTON_STYLES = "Lapp/eclipse/extension/player/ButtonStyles;"

@Suppress("unused")
val thickButtonStylesPatch = bytecodePatch(
    name = "Botones del reproductor: estilo grueso",
    description = "Agrega un estilo nuevo (grueso, esquinas apenas redondeadas) para Play/Pause, Previous y Next, " +
        "al principio de la lista de estilos del editor del reproductor de Eclipse. Tambien agrega estilos tipo Apple Music: doble triangulo (Previous y Next), letra, cola, conectar (AirPods), persona (Jam) y menu, trazados de las capturas de Apple Music.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // bw0 guarda los estilos: e = Map(ob4 -> lista de nombres), f = Map(nombre -> icono),
        // g = Map(nombre de Play -> icono de Pause). El gancho va al final de bw0.<clinit>, justo antes del
        // return-void: pasa cada mapa por ButtonStyles.apply(which, mapa) y lo vuelve a guardar.
        val bw0 = mutableClassDefBy(classDefBy("Lbw0;"))

        for (name in listOf("e", "f", "g")) {
            if (bw0.fields.none { it.name == name && it.type == "Ljava/util/Map;" }) {
                error("bw0.$name (Map) no encontrado")
            }
        }

        val clinit = bw0.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro bw0.<clinit>")
        val list = (clinit.implementation ?: error("bw0.<clinit> sin codigo")).instructions.toList()
        val last = list.indexOfLast { it.opcode == Opcode.RETURN_VOID }
        if (last < 0 || last != list.lastIndex) error("bw0.<clinit>: no termina en return-void")

        fun hookFor(field: String, which: Int) = """
            sget-object v0, Lbw0;->$field:Ljava/util/Map;
            const/4 v1, $which
            invoke-static {v1, v0}, $BUTTON_STYLES->apply(ILjava/util/Map;)Ljava/util/Map;
            move-result-object v0
            sput-object v0, Lbw0;->$field:Ljava/util/Map;
        """

        clinit.addInstructions(last, hookFor("e", 0) + hookFor("f", 1) + hookFor("g", 2))

        // v1.91.0: Connect dinamico. di6.A(I, dw0, ow0, ki1, t43, Z) dibuja cada capa del reproductor Custom; justo
        // despues de `iget-object v8, v1, dw0.r` (nombre del icono de la capa) y antes de `iget-object v10, v1, dw0.b`
        // se pasa el nombre por ButtonStyles.autoSymbol(nombre, estado). v1 = dw0 y v3 = ow0 (estado), segun los
        // `move` del inicio del metodo (se comprueban abajo). Si no coincide, solo se omite este gancho.
        try {
            val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
            val a = di6.methods.singleOrNull {
                it.name == "A" && it.parameterTypes.size == 6 &&
                    it.parameterTypes[0].toString() == "I" &&
                    it.parameterTypes[1].toString() == "Ldw0;" &&
                    it.parameterTypes[2].toString() == "Low0;"
            } ?: error("di6.A no encontrado")
            val ins = (a.implementation ?: error("di6.A sin codigo")).instructions.toList()

            fun fieldOf(i: Int): FieldReference? =
                (ins[i] as? ReferenceInstruction)?.reference as? FieldReference

            val hits = (0 until ins.size - 1).filter { i ->
                ins[i].opcode == Opcode.IGET_OBJECT && ins[i + 1].opcode == Opcode.IGET_OBJECT &&
                    fieldOf(i)?.let { it.definingClass == "Ldw0;" && it.name == "r" && it.type == "Ljava/lang/String;" } == true &&
                    fieldOf(i + 1)?.let { it.definingClass == "Ldw0;" && it.name == "b" && it.type == "Lob4;" } == true
            }
            if (hits.size != 1) error("di6.A: se esperaba 1 sitio (hay ${hits.size})")
            val at = hits[0]
            val dest = (ins[at] as OneRegisterInstruction).registerA
            val obj = (ins[at] as TwoRegisterInstruction).registerB
            if (dest != 8 || obj != 1) error("di6.A: registros inesperados (v$dest, v$obj)")
            // v3 debe ser el ow0 recibido: `move-object/from16 v3, <param>` al inicio y nunca reescrito antes
            val writesV3 = (0 until at).filter { i ->
                val x = ins[i]
                x is OneRegisterInstruction && x.registerA == 3
            }
            if (writesV3.size != 1 || ins[writesV3[0]].opcode != Opcode.MOVE_OBJECT_FROM16) {
                error("di6.A: v3 no es solo el parametro ow0")
            }
            a.addInstructions(
                at + 1,
                """
                    invoke-static {v8, v3}, $BUTTON_STYLES->autoSymbol(Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/String;
                    move-result-object v8
                """
            )
        } catch (e: Exception) {
            println("Connect dinamico omitido: ${e.message}")
        }
    }
}
