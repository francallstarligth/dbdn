package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val BUTTON_STYLES = "Lapp/eclipse/extension/player/ButtonStyles;"

@Suppress("unused")
val thickButtonStylesPatch = bytecodePatch(
    name = "Botones del reproductor: estilo grueso",
    description = "Agrega un estilo nuevo (grueso, esquinas apenas redondeadas) para Play/Pause, Previous y Next, " +
        "al principio de la lista de estilos del editor del reproductor de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // bw0 guarda los estilos: e = Map(ob4 -> lista de nombres), f = Map(nombre -> icono),
        // g = Map(nombre de Play -> icono de Pause). El gancho va al final de bw0.<clinit>, justo antes del
        // return-void: pasa cada mapa por ButtonStyles.apply(which, mapa) y lo vuelve a guardar.
        val bw0 = mutableClassDefBy(classDefBy("Lbw0;"))

        for (name in listOf("e", "f", "g")) {
            if (bw0.fields.none { it.name == name && it.type == "Ljava/util/Map;" }) {
                error("bw0.$name (Map) no encontrado")
            }
        }

        val clinit = bw0.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro bw0.<clinit>")
        val list = (clinit.implementation ?: error("bw0.<clinit> sin codigo")).instructions.toList()
        val last = list.indexOfLast { it.opcode == Opcode.RETURN_VOID }
        if (last < 0 || last != list.lastIndex) error("bw0.<clinit>: no termina en return-void")

        fun hookFor(field: String, which: Int) = """
            sget-object v0, Lbw0;->$field:Ljava/util/Map;
            const/4 v1, $which
            invoke-static {v1, v0}, $BUTTON_STYLES->apply(ILjava/util/Map;)Ljava/util/Map;
            move-result-object v0
            sput-object v0, Lbw0;->$field:Ljava/util/Map;
        """

        clinit.addInstructions(last, hookFor("e", 0) + hookFor("f", 1) + hookFor("g", 2))
    }
}
