package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch

private const val INTER = "Lapp/eclipse/extension/font/InterFont;"
private val INTER_WEIGHTS = listOf("regular", "medium", "semibold", "bold")

/**
 * v0.20.120 (SIN COMPILAR / SIN PROBAR). Copia los 4 pesos de Inter (la fuente de Mochy, licencia OFL) a assets/ del APK.
 * Los archivos viven en patches/src/main/resources/eclipse/inter_*.ttf.
 */
@Suppress("unused")
val interFontFilesPatch = resourcePatch(
    name = "Fuente Inter: archivos",
    description = "Agrega los archivos de la fuente Inter. Los usa \"Fuente Inter en toda la app\".",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        for (w in INTER_WEIGHTS) {
            val bytes = object {}.javaClass.getResourceAsStream("/eclipse/inter_$w.ttf")?.use { it.readBytes() }
                ?: error("Recurso no encontrado en el parche: /eclipse/inter_$w.ttf")
            val out = get("assets/eclipse_inter_$w.ttf")
            out.parentFile?.mkdirs()
            out.writeBytes(bytes)
        }
    }
}

/**
 * v0.20.120 (SIN COMPILAR / SIN PROBAR). Al inicio de EclipseApplication.onCreate (clase com.eclipse.android.EclipseApplication,
 * leida en el smali del APK Base; p0 = this) llama InterFont.install(this), que cambia la fuente por defecto de Android
 * dentro de la app por Inter (ver InterFont.java). Si falla, queda la fuente del sistema.
 */
@Suppress("unused")
val interFontPatch = bytecodePatch(
    name = "Fuente Inter en toda la app",
    description = "Usa la fuente Inter (la de Mochy) en toda la app, letras incluidas. Android 10 o superior. " +
        "Desmarcalo para volver a la fuente del sistema.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(interFontFilesPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val app = mutableClassDefBy(classDefBy("Lcom/eclipse/android/EclipseApplication;"))
        val onCreate = app.methods.singleOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro EclipseApplication.onCreate (version de Eclipse distinta de 0.6.47?)")
        onCreate.addInstructions(0, "invoke-static {p0}, $INTER->install(Landroid/content/Context;)V")
    }
}
