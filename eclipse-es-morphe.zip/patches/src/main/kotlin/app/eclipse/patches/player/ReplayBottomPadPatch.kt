package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val REPLAY_PAD = "Lapp/eclipse/extension/player/ReplayBottomPad;"

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun replayRegName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

/**
 * v0.20.343 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): en Replay, con las skins Native/Apple Music/Spotify, el boton
 * "Compartir mi Replay" queda tapado por la barra flotante (orbes + miniplayer), incluso al bajar hasta el final.
 *
 * Visto en el dex 75: `Lct8;->o(I Integer dk3 fk3 fk3 Z eu1 I I)V` es la pantalla de Replay. Su lista usa
 * `Lsq4;->h(F F F I)Lzb7;` (PaddingValues) con el 3er valor = `Lnp2;->q` (alto medido de la barra, `Lvs5;->a`) + 32 dp.
 * Con la barra flotante esa medida no llega y solo quedan 32 dp. Arreglo: justo antes de esa llamada, el 3er valor
 * pasa por `ReplayBottomPad.fix(F)F` (minimo 115 dp). Sin cambios si ya era mayor.
 */
@Suppress("unused")
val replayBottomPadPatch = bytecodePatch(
    name = "Replay: espacio extra abajo",
    description = "En Replay, con las skins Native, Apple Music y Spotify, el boton \"Compartir mi Replay\" queda " +
        "tapado por la barra de abajo. Con este parche la lista deja mas espacio al final para poder tocarlo. " +
        "Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val ct8 = mutableClassDefBy(classDefBy("Lct8;"))
        val esperados = listOf(
            "I", "Ljava/lang/Integer;", "Ldk3;", "Lfk3;", "Lfk3;", "Z", "Leu1;", "I", "I"
        )
        val metodo = ct8.methods.singleOrNull {
            it.name == "o" && it.returnType == "V" && it.parameterTypes.map { p -> p.toString() } == esperados
        } ?: error("No se encontro ct8.o (pantalla de Replay; Eclipse 0.6.75)")
        val ins = (metodo.implementation ?: error("ct8.o sin codigo")).instructions.toList()

        // sq4.h(F, F, F, I) : PaddingValues(start, top, bottom, mascara)
        val llamadas = ins.indices.filter { i ->
            val a = ins[i]
            val ref = (a as? ReferenceInstruction)?.reference as? MethodReference
            a.opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lsq4;" && ref.name == "h" &&
                ref.returnType == "Lzb7;" && ref.parameterTypes.map { p -> p.toString() } == listOf("F", "F", "F", "I")
        }
        if (llamadas.size != 1) error("ct8.o: se esperaba 1 llamada a sq4.h(FFFI) (hay ${llamadas.size})")
        val idx = llamadas[0]
        val call = ins[idx] as? FiveRegisterInstruction ?: error("ct8.o: sq4.h no es invoke-static normal")
        if (call.registerCount != 4) error("ct8.o: sq4.h con ${call.registerCount} registros (se esperaban 4)")
        // El 3er argumento (registerE) es el espacio de abajo en dp (float).
        val reg = replayRegName(call.registerE, metodo)
        if (reg.startsWith("p")) error("ct8.o: el espacio de abajo esta en un parametro ($reg), orden inesperado")

        metodo.addInstructions(
            idx,
            """
                invoke-static {$reg}, $REPLAY_PAD->fix(F)F
                move-result $reg
            """.trimIndent()
        )
    }
}
