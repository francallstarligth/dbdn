package app.eclipse.patches.automix

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val EXT = "Lapp/eclipse/extension/automix/AutomixBackup;"

/**
 * Automix con respaldo local (Eclipse 0.6.47). Verificado solo contra el smali; NO probado en el telefono.
 *
 * Eclipse pide el plan al servidor en wf0.invokeSuspend (r = ISRC que sale, s = ISRC que entra, t = fundido).
 * Ganchos:
 *  - 1 (inicio de wf0.invokeSuspend): pasa las opciones a la extension y, si alguna cancion tiene ISRC inventado (ZZ...)
 *    o una de las opciones "Plan local primero" / "Solo Automix local" esta activa, plan local directo (antes pide el analisis de Eclipse si falta).
 *  - 2 (los 3 `return null` de wf0.invokeSuspend: sin cliente HTTP, error HTTP, excepcion): plan local.
 *  - 3 (los Song.getIsrc() de ig0.a y ig0.d): ISRC real o, si no hay, uno inventado; guarda artista y titulo.
 *  - 4 (tf0.a, tras armar la ficha): guarda BPM, beats y downbeats de la ficha de Eclipse (la ficha se sube igual).
 *  - 5 (dg0.D, "ya analizada"): fuerza el analisis de las canciones sin ficha local (solo con plan local primero o ISRC inventado).
 *  - 6 (xf0, subida de la ficha): no sube fichas con ISRC inventado.
 */
@Suppress("unused")
val automixBackupPatch = bytecodePatch(
    name = "Automix con respaldo local",
    description = "Eclipse sigue usando el plan de Automix del servidor. Si el servidor no responde, o la cancion " +
        "no tiene ISRC, el plan se calcula en el telefono con el analisis de Eclipse (BPM, compases) o el BPM de Deezer. " +
        "Con Beatmatch la entrante iguala el tempo de la que sale. No activar junto con el diagnostico de Automix.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val beatmatch by booleanOption(
        key = "beatmatch",
        default = true,
        title = "Beatmatch",
        description = "En el plan local, la entrante cambia de velocidad (sin cambiar el tono) hasta el tempo de la que sale, " +
            "y su primer compas cae donde empieza el fundido. Necesita el analisis de Eclipse de las dos canciones " +
            "(compases); sin eso hace el fundido normal. Con el modo de rendimiento de Eclipse encendido no hay compases."
    )

    val localFirst by booleanOption(
        key = "localFirst",
        default = false,
        title = "Plan local primero",
        description = "Usa el plan local en todas las canciones (el servidor de Eclipse solo si el local no puede). " +
            "Sin esto, el plan local solo entra cuando el servidor falla o la cancion no tiene ISRC. " +
            "El beatmatch solo se nota en canciones con plan local."
    )

    val localOnly by booleanOption(
        key = "localOnly",
        default = false,
        title = "Solo Automix local",
        description = "Nunca usa el servidor de Eclipse: el plan siempre se calcula en el telefono " +
            "(analisis de Eclipse, Deezer o valores fijos), asi el Automix no depende de la red ni del servidor. " +
            "Tiene prioridad sobre Plan local primero."
    )

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Avisos de depuracion",
        description = "Muestra avisos cortos en pantalla: si el plan lo dio el servidor o el local, BPM (F = analisis de Eclipse, " +
            "D = Deezer), inicio, velocidad del beatmatch y por que no hubo beatmatch. Dejalo apagado para uso normal."
    )

    execute {
        val debugFlag = if (debug == true) "0x1" else "0x0"
        val localOnlyFlag = if (localOnly == true) "0x1" else "0x0"
        val beatmatchFlag = if (beatmatch == true) "0x1" else "0x0"
        val localFirstFlag = if (localFirst == true) "0x1" else "0x0"

        // ---- wf0.invokeSuspend ---------------------------------------------------------------------------------
        val cls = mutableClassDefBy(classDefBy("Lwf0;"))
        val method = cls.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro wf0.invokeSuspend")
        val impl = method.implementation ?: error("wf0.invokeSuspend sin codigo")
        val list = impl.instructions.toList()
        // Parametros: p0 = this, p1 = Object (en ese orden, al final de los registros).
        val p1Reg = impl.registerCount - 1

        // Primer `iget-object ..., wf0->u:String` (lectura del modo, justo despues de calcular el fundido).
        val idx = list.indices.firstOrNull { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.IGET_OBJECT) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@firstOrNull false
            ref.definingClass == "Lwf0;" && ref.name == "u" && ref.type == "Ljava/lang/String;"
        } ?: error("wf0.invokeSuspend: no se encontro la lectura de wf0.u")
        if (list[idx - 1].opcode != Opcode.MOVE_RESULT) error("wf0.invokeSuspend: antes de wf0.u no hay move-result")
        val prev = ((list[idx - 2] as? ReferenceInstruction)?.reference as? MethodReference)
        if (prev == null || prev.definingClass != "Li92;" || prev.name != "x") {
            error("wf0.invokeSuspend: antes del move-result no esta la llamada a i92.x")
        }

        // Los retornos con null: `return-object p1` (x2: error HTTP y excepcion) y `return-object v12` (x1: sin cliente HTTP).
        val retP1 = list.indices.filter { i ->
            val x = list[i]
            x.opcode == Opcode.RETURN_OBJECT && (x as OneRegisterInstruction).registerA == p1Reg
        }
        val retV12 = list.indices.filter { i ->
            val x = list[i]
            x.opcode == Opcode.RETURN_OBJECT && (x as OneRegisterInstruction).registerA == 12
        }
        if (retP1.size != 2) error("wf0.invokeSuspend: se esperaban 2 return-object p1 y hay ${retP1.size}")
        if (retV12.size != 1) error("wf0.invokeSuspend: se esperaba 1 return-object v12 y hay ${retV12.size}")
        // El v12 debe ser null ahi: `const/4 v12, 0x0` en algun punto antes.
        val zeroV12 = list.indices.any { i ->
            val x = list[i]
            x.opcode == Opcode.CONST_4 && (x as OneRegisterInstruction).registerA == 12
        }
        if (!zeroV12) error("wf0.invokeSuspend: no se encontro const/4 v12")

        // Se inserta de atras hacia delante para que los indices anteriores no se muevan.
        val sites = (retP1.map { "p1" to it } + retV12.map { "v12" to it }).sortedByDescending { it.second }
        var n = 0
        for ((reg, at) in sites) {
            val label = ":automix_k$n"
            n++
            val callG = if (reg == "p1") "invoke-static/range {p1 .. p1}" else "invoke-static {v12}"
            method.addInstructionsWithLabels(
                at,
                """
                    invoke-static/range {p0 .. p0}, $EXT->fallback(Ljava/lang/Object;)Ljava/lang/String;
                    move-result-object $reg
                    if-eqz $reg, $label
                    $callG, Lwx6;->G(Ljava/lang/String;)Lsg0;
                    move-result-object $reg
                    $label
                    nop
                """
            )
        }

        method.addInstructionsWithLabels(
            idx,
            """
                const/4 v7, $beatmatchFlag
                invoke-static {v7}, $EXT->setBeatmatch(Z)V
                const/4 v7, $localFirstFlag
                invoke-static {v7}, $EXT->setLocalFirst(Z)V
                const/4 v7, $localOnlyFlag
                invoke-static {v7}, $EXT->setLocalOnly(Z)V
                const/4 v7, $debugFlag
                invoke-static {v7}, $EXT->setDebug(Z)V
                invoke-static {v4, v5, v6}, $EXT->localFirst(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                move-result-object v7
                if-eqz v7, :automix_server
                invoke-static {v7}, Lwx6;->G(Ljava/lang/String;)Lsg0;
                move-result-object v7
                return-object v7
                :automix_server
                nop
            """
        )

        // ---- Gancho 3: Song.getIsrc() de ig0.a (x1) e ig0.d (x2) ---------------------------------------------------
        // Patron: invoke-virtual{/range} {Song}, getIsrc ; move-result-object vR ; if-eqz vR, :sin_automix.
        // Entre el move-result-object y el if-eqz se sustituye vR por AutomixBackup.isrcFor(Song).
        fun hookGetIsrc(className: String, methodName: String, expected: Int) {
            val c = mutableClassDefBy(classDefBy(className))
            val m = c.methods.firstOrNull { it.name == methodName && it.returnType == "Ljava/lang/Object;" }
                ?: error("No se encontro $className.$methodName")
            val ins = (m.implementation ?: error("$className.$methodName sin codigo")).instructions.toList()
            val sites = ins.indices.filter { i ->
                val x = ins[i]
                if (x.opcode != Opcode.INVOKE_VIRTUAL && x.opcode != Opcode.INVOKE_VIRTUAL_RANGE) return@filter false
                val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@filter false
                ref.definingClass == "Lcom/eclipse/android/data/models/Song;" && ref.name == "getIsrc"
            }
            if (sites.size != expected) error("$className.$methodName: se esperaban $expected getIsrc y hay ${sites.size}")
            // De atras hacia delante para que los indices anteriores no se muevan.
            for (i in sites.reversed()) {
                val call = ins[i]
                if (ins[i + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("$className.$methodName: tras getIsrc no hay move-result-object")
                if (ins[i + 2].opcode != Opcode.IF_EQZ) error("$className.$methodName: tras el ISRC no hay if-eqz")
                val resultReg = (ins[i + 1] as OneRegisterInstruction).registerA
                val songReg = if (call.opcode == Opcode.INVOKE_VIRTUAL_RANGE) {
                    (call as RegisterRangeInstruction).startRegister
                } else {
                    (call as FiveRegisterInstruction).registerC
                }
                m.addInstructions(
                    i + 2,
                    """
                        invoke-static/range {v$songReg .. v$songReg}, $EXT->isrcFor(Ljava/lang/Object;)Ljava/lang/String;
                        move-result-object v$resultReg
                    """
                )
            }
        }
        hookGetIsrc("Lig0;", "a", 1)
        hookGetIsrc("Lig0;", "d", 2)

        // ---- Gancho 4: ficha del analizador de Eclipse (tf0.a) -------------------------------------------------------
        // tf0.a(Ltf0;, String isrc, Lcg0;, Lkg0;, Z) -> String analiza la cancion en el telefono y arma la ficha con
        // tf0.c(jsonNativo, isrc, duracion, fuente). Justo despues de ese `move-result-object` (antes del `if-nez` que
        // comprueba null) pasamos ISRC y ficha a AutomixBackup.onCard. Eclipse sigue con su flujo (la ficha se sube igual).
        val analyzer = mutableClassDefBy(classDefBy("Ltf0;"))
        val analyze = analyzer.methods.firstOrNull {
            it.name == "a" && it.returnType == "Ljava/lang/String;" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ltf0;", "Ljava/lang/String;", "Lcg0;", "Lkg0;", "Z")
        } ?: error("No se encontro tf0.a")
        val body = (analyze.implementation ?: error("tf0.a sin codigo")).instructions.toList()

        val cardCall = body.indices.firstOrNull { i ->
            val x = body[i]
            if (x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Ltf0;" && ref.name == "c" && ref.returnType == "Ljava/lang/String;" &&
                ref.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Ljava/lang/String;", "D", "Lcg0;")
        } ?: error("tf0.a: no se encontro la llamada a tf0.c")

        if (body[cardCall + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("tf0.a: tras tf0.c no hay move-result-object")
        if (body[cardCall + 2].opcode != Opcode.IF_NEZ) error("tf0.a: tras la ficha no hay if-nez")

        // tf0.c(json, isrc, D, cg0) = invoke-static {json, isrc, dLo, dHi, cg0}: el ISRC es el 2.o registro (D).
        val isrcReg = (body[cardCall] as FiveRegisterInstruction).registerD
        val cardReg = (body[cardCall + 1] as OneRegisterInstruction).registerA
        if (isrcReg > 15 || cardReg > 15) error("tf0.a: registros >15 (isrc=v$isrcReg, ficha=v$cardReg)")

        analyze.addInstructions(
            cardCall + 2,
            "invoke-static {v$isrcReg, v$cardReg}, $EXT->onCard(Ljava/lang/String;Ljava/lang/String;)V"
        )

        // ---- Gancho 5: dg0.D(String) -> boolean = "ya analizada/subida" ---------------------------------------------
        // Lo consultan ig0.a y tf0.b (x2) para saltarse canciones ya analizadas. Tras normalizar el ISRC con yf0.e
        // (move-result-object) y antes de tocar las listas, preguntamos a AutomixBackup.forceAnalyze(isrc): si es true
        // (cancion sin ficha local y se quiere plan local) devolvemos false = "no analizada" y Eclipse la analiza; si es
        // false, sigue el codigo original. v0 esta libre (el iget-object siguiente lo sobrescribe).
        val registry = mutableClassDefBy(classDefBy("Ldg0;"))
        val done = registry.methods.firstOrNull {
            it.name == "D" && it.returnType == "Z" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/String;")
        } ?: error("No se encontro dg0.D")
        val dBody = (done.implementation ?: error("dg0.D sin codigo")).instructions.toList()

        val normCall = dBody.indices.firstOrNull { i ->
            val x = dBody[i]
            if (x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lyf0;" && ref.name == "e" && ref.returnType == "Ljava/lang/String;"
        } ?: error("dg0.D: no se encontro la llamada a yf0.e")

        val normMove = dBody[normCall + 1]
        if (normMove.opcode != Opcode.MOVE_RESULT_OBJECT) error("dg0.D: tras yf0.e no hay move-result-object")
        if (dBody[normCall + 2].opcode != Opcode.IGET_OBJECT) error("dg0.D: tras el ISRC no viene iget-object")
        val isrcDReg = (normMove as OneRegisterInstruction).registerA
        if (isrcDReg > 15) error("dg0.D: registro del ISRC >15 (v$isrcDReg)")

        done.addInstructionsWithLabels(
            normCall + 2,
            """
                invoke-static {v$isrcDReg}, $EXT->forceAnalyze(Ljava/lang/String;)Z
                move-result v0
                if-eqz v0, :automix_orig
                const/4 v0, 0x0
                return v0
                :automix_orig
                nop
            """
        )

        // ---- Gancho 6: no subir fichas con ISRC inventado -------------------------------------------------------------
        // xf0.invokeSuspend (caso 0 del switch) = POST api/automix/analysis con la ficha en xf0.s. Va tras
        // `invoke-static/range {p1 .. p1}, Lyg2;->K` y antes de armar la peticion. Si la ficha lleva un ISRC inventado
        // devolvemos Boolean.TRUE (como si ya estuviera subida) y no sale nada a la red. v0 = this, v7 libre.
        val uploader = mutableClassDefBy(classDefBy("Lxf0;"))
        val upload = uploader.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro xf0.invokeSuspend")
        val up = (upload.implementation ?: error("xf0.invokeSuspend sin codigo")).instructions.toList()

        val tagIdx = up.indices.firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.CONST_STRING) return@firstOrNull false
            ((x as ReferenceInstruction).reference as? StringReference)?.string == "analysis upload HTTP "
        } ?: error("xf0: no se encontro \"analysis upload HTTP \"")

        val kIdx = (tagIdx + 1 until minOf(tagIdx + 12, up.size)).firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.INVOKE_STATIC_RANGE && x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lyg2;" && ref.name == "K"
        } ?: error("xf0: tras la marca de subida no se encontro yg2.K")
        if (up[kIdx + 1].opcode != Opcode.SGET_OBJECT) error("xf0: tras yg2.K no viene sget-object")

        upload.addInstructionsWithLabels(
            kIdx + 1,
            """
                iget-object v7, v0, Lxf0;->s:Ljava/lang/String;
                invoke-static {v7}, $EXT->blockUpload(Ljava/lang/String;)Z
                move-result v7
                if-eqz v7, :automix_upload
                sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
                return-object v0
                :automix_upload
                nop
            """
        )
    }
}
