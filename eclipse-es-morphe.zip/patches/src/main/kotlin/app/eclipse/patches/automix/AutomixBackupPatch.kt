package app.eclipse.patches.automix

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val EXT = "Lapp/eclipse/extension/automix/AutomixBackup;"

/**
 * v0.20.219 (Eclipse 0.6.61, SIN COMPILAR NI PROBAR): al0->xl0, ml0->jm0, xk0->ul0, gl0->dm0, ol0->lm0, hl0->em0, cl0->zl0, bl0->yl0,
 * wl0->tm0, l42.H->l74.z, xr7.r->at7.s, qs7.Z->ut7.X. Comparadas por firma y cuerpo en el dex (solo cambian nombres de llamadas).
 * Automix con respaldo local (Eclipse 0.6.47). Verificado solo contra el smali; NO probado en el telefono.
 *
 * Eclipse pide el plan al servidor en kk0.invokeSuspend (r = ISRC que sale, s = ISRC que entra, t = fundido).
 * Ganchos:
 *  - 1 (inicio de kk0.invokeSuspend): pasa las opciones a la extension y, si alguna cancion tiene ISRC inventado (ZZ...)
 *    o una de las opciones "Plan local primero" / "Solo Automix local" esta activa, plan local directo (antes pide el analisis de Eclipse si falta).
 *  - 2 (los 3 `return null` de kk0.invokeSuspend: sin cliente HTTP, error HTTP, excepcion): plan local.
 *  - 3 (los Song.getIsrc() de wk0.a y wk0.d): ISRC real o, si no hay, uno inventado; guarda artista y titulo.
 *  - 4 (hk0.a, tras armar la ficha): guarda BPM, beats y downbeats de la ficha de Eclipse (la ficha se sube igual).
 *  - 5 (rk0.D, "ya analizada"): fuerza el analisis de las canciones sin ficha local (solo con plan local primero o ISRC inventado).
 *  - 6 (lk0, subida de la ficha): no sube fichas con ISRC inventado.
 */
@Suppress("unused")
val automixBackupPatch = bytecodePatch(
    name = "Automix con respaldo local",
    description = "Eclipse sigue usando el plan de Automix del servidor. Si el servidor no responde, o la cancion " +
        "no tiene ISRC, el plan se calcula en el telefono con el analisis de Eclipse (BPM, compases) o el BPM de Deezer, SongBPM o Tunebat. " +
        "Con Beatmatch la entrante iguala el tempo de la que sale.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val beatmatch by booleanOption(
        key = "beatmatch",
        default = true,
        title = "Beatmatch",
        description = "En el plan local, la entrante cambia de velocidad (sin cambiar el tono) hasta el tempo de la que sale, " +
            "y su primer compas cae donde empieza el fundido. Necesita el analisis de Eclipse de las dos canciones " +
            "(compases); sin eso hace el fundido normal. Con el modo de rendimiento de Eclipse encendido no hay compases."
    )

    val localFirst by booleanOption(
        key = "localFirst",
        default = false,
        title = "Plan local primero",
        description = "Usa el plan local en todas las canciones (el servidor de Eclipse solo si el local no puede). " +
            "Sin esto, el plan local solo entra cuando el servidor falla o la cancion no tiene ISRC. " +
            "El beatmatch solo se nota en canciones con plan local."
    )

    val localOnly by booleanOption(
        key = "localOnly",
        default = false,
        title = "Solo Automix local",
        description = "Nunca usa el servidor de Eclipse: el plan siempre se calcula en el telefono " +
            "(analisis de Eclipse, Deezer, SongBPM, Tunebat o valores fijos), asi el Automix no depende de la red ni del servidor. " +
            "Tiene prioridad sobre Plan local primero."
    )

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Avisos de depuracion",
        description = "Muestra avisos cortos en pantalla: si el plan lo dio el servidor o el local, BPM (F = analisis de Eclipse, " +
            "D = Deezer, S = SongBPM, T = Tunebat), inicio, velocidad del beatmatch y por que no hubo beatmatch. Dejalo apagado para uso normal."
    )

    execute {
        val debugFlag = if (debug == true) "0x1" else "0x0"
        val localOnlyFlag = if (localOnly == true) "0x1" else "0x0"
        val beatmatchFlag = if (beatmatch == true) "0x1" else "0x0"
        val localFirstFlag = if (localFirst == true) "0x1" else "0x0"

        // ---- kk0.invokeSuspend ---------------------------------------------------------------------------------
        val cls = mutableClassDefBy(classDefBy("Lxl0;"))
        val method = cls.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro kk0.invokeSuspend")
        val impl = method.implementation ?: error("kk0.invokeSuspend sin codigo")
        val list = impl.instructions.toList()
        // Parametros: p0 = this, p1 = Object (en ese orden, al final de los registros).
        val p1Reg = impl.registerCount - 1

        // Primer `iget-object ..., kk0->u:String` (lectura del modo, justo despues de calcular el fundido).
        val idx = list.indices.firstOrNull { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.IGET_OBJECT) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@firstOrNull false
            ref.definingClass == "Lxl0;" && ref.name == "u" && ref.type == "Ljava/lang/String;"
        } ?: error("kk0.invokeSuspend: no se encontro la lectura de kk0.u")
        if (list[idx - 1].opcode != Opcode.MOVE_RESULT) error("kk0.invokeSuspend: antes de kk0.u no hay move-result")
        val prev = ((list[idx - 2] as? ReferenceInstruction)?.reference as? MethodReference)
        if (prev == null || prev.definingClass != "Lat7;" || prev.name != "s") {
            error("kk0.invokeSuspend: antes del move-result no esta la llamada a lp7.t (version de Eclipse distinta de 0.6.55?)")
        }

        // Los retornos con null: `return-object p1` (x2: error HTTP y excepcion) y `return-object v12` (x1: sin cliente HTTP).
        val retP1 = list.indices.filter { i ->
            val x = list[i]
            x.opcode == Opcode.RETURN_OBJECT && (x as OneRegisterInstruction).registerA == p1Reg
        }
        val retV12 = list.indices.filter { i ->
            val x = list[i]
            x.opcode == Opcode.RETURN_OBJECT && (x as OneRegisterInstruction).registerA == 12
        }
        if (retP1.size != 2) error("kk0.invokeSuspend: se esperaban 2 return-object p1 y hay ${retP1.size}")
        if (retV12.size != 1) error("kk0.invokeSuspend: se esperaba 1 return-object v12 y hay ${retV12.size}")
        // El v12 debe ser null ahi: `const/4 v12, 0x0` en algun punto antes.
        val zeroV12 = list.indices.any { i ->
            val x = list[i]
            x.opcode == Opcode.CONST_4 && (x as OneRegisterInstruction).registerA == 12
        }
        if (!zeroV12) error("kk0.invokeSuspend: no se encontro const/4 v12")

        // Se inserta de atras hacia delante para que los indices anteriores no se muevan.
        val sites = (retP1.map { "p1" to it } + retV12.map { "v12" to it }).sortedByDescending { it.second }
        var n = 0
        for ((reg, at) in sites) {
            val label = ":automix_k$n"
            n++
            val callG = if (reg == "p1") "invoke-static/range {p1 .. p1}" else "invoke-static {v12}"
            method.addInstructionsWithLabels(
                at,
                """
                    invoke-static/range {p0 .. p0}, $EXT->fallback(Ljava/lang/Object;)Ljava/lang/String;
                    move-result-object $reg
                    if-eqz $reg, $label
                    $callG, Ll74;->z(Ljava/lang/String;)Ltm0;
                    move-result-object $reg
                    $label
                    nop
                """
            )
        }

        method.addInstructionsWithLabels(
            idx,
            """
                const/4 v7, $beatmatchFlag
                invoke-static {v7}, $EXT->setBeatmatch(Z)V
                const/4 v7, $localFirstFlag
                invoke-static {v7}, $EXT->setLocalFirst(Z)V
                const/4 v7, $localOnlyFlag
                invoke-static {v7}, $EXT->setLocalOnly(Z)V
                const/4 v7, $debugFlag
                invoke-static {v7}, $EXT->setDebug(Z)V
                invoke-static {v4, v5, v6}, $EXT->localFirst(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                move-result-object v7
                if-eqz v7, :automix_server
                invoke-static {v7}, Ll74;->z(Ljava/lang/String;)Ltm0;
                move-result-object v7
                return-object v7
                :automix_server
                nop
            """
        )

        // ---- Gancho 3: Song.getIsrc() de wk0.a (x1) e wk0.d (x2) ---------------------------------------------------
        // Patron: invoke-virtual{/range} {Song}, getIsrc ; move-result-object vR ; if-eqz vR, :sin_automix.
        // Entre el move-result-object y el if-eqz se sustituye vR por AutomixBackup.isrcFor(Song).
        fun hookGetIsrc(className: String, methodName: String, expected: Int) {
            val c = mutableClassDefBy(classDefBy(className))
            // 0.6.55: wk0 puede tener otros metodos a/d que devuelven Object: se escoge el que tiene EXACTAMENTE
            // `expected` llamadas a Song.getIsrc.
            fun isGetIsrc(x: com.android.tools.smali.dexlib2.iface.instruction.Instruction): Boolean {
                if (x.opcode != Opcode.INVOKE_VIRTUAL && x.opcode != Opcode.INVOKE_VIRTUAL_RANGE) return false
                val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return false
                return ref.definingClass == "Lcom/eclipse/android/data/models/Song;" && ref.name == "getIsrc"
            }
            val m = c.methods.singleOrNull {
                it.name == methodName && it.returnType == "Ljava/lang/Object;" &&
                    (it.implementation?.instructions?.count { x -> isGetIsrc(x) } ?: 0) == expected
            } ?: error("No se encontro $className.$methodName con $expected getIsrc (version de Eclipse distinta de 0.6.55?)")
            val ins = (m.implementation ?: error("$className.$methodName sin codigo")).instructions.toList()
            val sites = ins.indices.filter { i ->
                val x = ins[i]
                if (x.opcode != Opcode.INVOKE_VIRTUAL && x.opcode != Opcode.INVOKE_VIRTUAL_RANGE) return@filter false
                val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@filter false
                ref.definingClass == "Lcom/eclipse/android/data/models/Song;" && ref.name == "getIsrc"
            }
            if (sites.size != expected) error("$className.$methodName: se esperaban $expected getIsrc y hay ${sites.size}")
            // De atras hacia delante para que los indices anteriores no se muevan.
            for (i in sites.reversed()) {
                val call = ins[i]
                if (ins[i + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("$className.$methodName: tras getIsrc no hay move-result-object")
                if (ins[i + 2].opcode != Opcode.IF_EQZ) error("$className.$methodName: tras el ISRC no hay if-eqz")
                val resultReg = (ins[i + 1] as OneRegisterInstruction).registerA
                val songReg = if (call.opcode == Opcode.INVOKE_VIRTUAL_RANGE) {
                    (call as RegisterRangeInstruction).startRegister
                } else {
                    (call as FiveRegisterInstruction).registerC
                }
                m.addInstructions(
                    i + 2,
                    """
                        invoke-static/range {v$songReg .. v$songReg}, $EXT->isrcFor(Ljava/lang/Object;)Ljava/lang/String;
                        move-result-object v$resultReg
                    """
                )
            }
        }
        hookGetIsrc("Ljm0;", "a", 1)
        hookGetIsrc("Ljm0;", "d", 2)

        // ---- Gancho 4: ficha del analizador de Eclipse (hk0.a) -------------------------------------------------------
        // hk0.a(Lxk0;, String isrc, Lgl0;, Lol0;, Z) -> String analiza la cancion en el telefono y arma la ficha con
        // hk0.c(jsonNativo, isrc, duracion, fuente). Justo despues de ese `move-result-object` (antes del `if-nez` que
        // comprueba null) pasamos ISRC y ficha a AutomixBackup.onCard. Eclipse sigue con su flujo (la ficha se sube igual).
        val analyzer = mutableClassDefBy(classDefBy("Lul0;"))
        val analyze = analyzer.methods.firstOrNull {
            it.name == "a" && it.returnType == "Ljava/lang/String;" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Lul0;", "Ljava/lang/String;", "Ldm0;", "Llm0;", "Z")
        } ?: error("No se encontro hk0.a")
        val body = (analyze.implementation ?: error("hk0.a sin codigo")).instructions.toList()

        val cardCall = body.indices.firstOrNull { i ->
            val x = body[i]
            if (x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lul0;" && ref.name == "c" && ref.returnType == "Ljava/lang/String;" &&
                ref.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Ljava/lang/String;", "D", "Ldm0;")
        } ?: error("hk0.a: no se encontro la llamada a hk0.c")

        if (body[cardCall + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("hk0.a: tras hk0.c no hay move-result-object")
        if (body[cardCall + 2].opcode != Opcode.IF_NEZ) error("hk0.a: tras la ficha no hay if-nez")

        // hk0.c(json, isrc, D, qk0) = invoke-static {json, isrc, dLo, dHi, qk0}: el ISRC es el 2.o registro (D).
        val isrcReg = (body[cardCall] as FiveRegisterInstruction).registerD
        val cardReg = (body[cardCall + 1] as OneRegisterInstruction).registerA
        if (isrcReg > 15 || cardReg > 15) error("hk0.a: registros >15 (isrc=v$isrcReg, ficha=v$cardReg)")

        analyze.addInstructions(
            cardCall + 2,
            "invoke-static {v$isrcReg, v$cardReg}, $EXT->onCard(Ljava/lang/String;Ljava/lang/String;)V"
        )

        // ---- Gancho 5: rk0.D(String) -> boolean = "ya analizada/subida" ---------------------------------------------
        // Lo consultan wk0.a y hk0.b (x2) para saltarse canciones ya analizadas. Tras normalizar el ISRC con mk0.e
        // (move-result-object) y antes de tocar las listas, preguntamos a AutomixBackup.forceAnalyze(isrc): si es true
        // (cancion sin ficha local y se quiere plan local) devolvemos false = "no analizada" y Eclipse la analiza; si es
        // false, sigue el codigo original. v0 esta libre (el iget-object siguiente lo sobrescribe).
        val registry = mutableClassDefBy(classDefBy("Lem0;"))
        val done = registry.methods.firstOrNull {
            it.name == "D" && it.returnType == "Z" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/String;")
        } ?: error("No se encontro rk0.D")
        val dBody = (done.implementation ?: error("rk0.D sin codigo")).instructions.toList()

        val normCall = dBody.indices.firstOrNull { i ->
            val x = dBody[i]
            if (x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lzl0;" && ref.name == "e" && ref.returnType == "Ljava/lang/String;"
        } ?: error("rk0.D: no se encontro la llamada a mk0.e")

        val normMove = dBody[normCall + 1]
        if (normMove.opcode != Opcode.MOVE_RESULT_OBJECT) error("rk0.D: tras mk0.e no hay move-result-object")
        if (dBody[normCall + 2].opcode != Opcode.IGET_OBJECT) error("rk0.D: tras el ISRC no viene iget-object")
        val isrcDReg = (normMove as OneRegisterInstruction).registerA
        if (isrcDReg > 15) error("rk0.D: registro del ISRC >15 (v$isrcDReg)")

        done.addInstructionsWithLabels(
            normCall + 2,
            """
                invoke-static {v$isrcDReg}, $EXT->forceAnalyze(Ljava/lang/String;)Z
                move-result v0
                if-eqz v0, :automix_orig
                const/4 v0, 0x0
                return v0
                :automix_orig
                nop
            """
        )

        // ---- Gancho 6: no subir fichas con ISRC inventado -------------------------------------------------------------
        // lk0.invokeSuspend (caso 0 del switch) = POST api/automix/analysis con la ficha en lk0.s. Va tras
        // `invoke-static/range {p1 .. p1}, Lut7;->X` y antes de armar la peticion. Si la ficha lleva un ISRC inventado
        // devolvemos Boolean.TRUE (como si ya estuviera subida) y no sale nada a la red. v0 = this, v7 libre.
        val uploader = mutableClassDefBy(classDefBy("Lyl0;"))
        val upload = uploader.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro lk0.invokeSuspend")
        val up = (upload.implementation ?: error("lk0.invokeSuspend sin codigo")).instructions.toList()

        val tagIdx = up.indices.firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.CONST_STRING) return@firstOrNull false
            ((x as ReferenceInstruction).reference as? StringReference)?.string == "analysis upload HTTP "
        } ?: error("lk0: no se encontro \"analysis upload HTTP \"")

        val kIdx = (tagIdx + 1 until minOf(tagIdx + 12, up.size)).firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.INVOKE_STATIC_RANGE && x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lut7;" && ref.name == "X"
        } ?: error("lk0: tras la marca de subida no se encontro wp7.c0")
        if (up[kIdx + 1].opcode != Opcode.SGET_OBJECT) error("lk0: tras wp7.c0 no viene sget-object")

        upload.addInstructionsWithLabels(
            kIdx + 1,
            """
                iget-object v7, v0, Lyl0;->s:Ljava/lang/String;
                invoke-static {v7}, $EXT->blockUpload(Ljava/lang/String;)Z
                move-result v7
                if-eqz v7, :automix_upload
                sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
                return-object v0
                :automix_upload
                nop
            """
        )
    }
}
