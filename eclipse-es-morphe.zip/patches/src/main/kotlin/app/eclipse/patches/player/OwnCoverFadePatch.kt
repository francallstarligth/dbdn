package app.eclipse.patches.player

import app.eclipse.patches.artwork.previousCoverPatch
import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val OWN_FADE = "Lapp/eclipse/extension/artwork/OwnFade;"

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun regName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

/**
 * v1.100.12 (SIN COMPILAR NI PROBAR). Opcion B contra la raya a la mitad: hj6.a(dw0, ow0, ki1, I) lee la configuracion del
 * edge fade (`iget-object vX, vX, Lx40;->i:Ljh2;`) y, si no es null, dibuja una caja aparte con el degradado encima de la
 * portada. Justo despues de ese iget se pasa el jh2 a OwnFade.capture (que lo guarda y devuelve null): asi hj6.a cree que
 * no hay edge fade y NO dibuja la caja (lo mismo que probo el usuario quitando el edge fade en el editor: la raya se va).
 * El mismo degradado se hornea dentro del dibujo de la portada (PrevCover.FadeDrawable, con DstOut en una capa propia).
 */
@Suppress("unused")
val ownCoverFadePatch = bytecodePatch(
    name = "Custom: portada con fundido propio (sin raya)",
    description = "Arregla la raya a la mitad al cambiar de cancion. En vez de la caja del edge fade de Eclipse, " +
        "el fundido del borde de la portada se dibuja dentro de la portada misma (transparente, con el mismo degradado). " +
        "Usa el mismo edge fade que ya tienes configurado en el editor Custom. Activa tambien \"mantener la imagen anterior\".",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(previousCoverPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val hj6 = mutableClassDefBy(classDefBy("Lhj6;"))
        val method = hj6.methods.firstOrNull { m ->
            m.name == "a" && m.returnType == "V" &&
                m.parameterTypes.map { it.toString() } == listOf("Ldw0;", "Low0;", "Lki1;", "I")
        } ?: error("No se encontro hj6.a (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("hj6.a sin codigo")).instructions.toList()
        val hits = list.indices.filter { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? FieldReference
            list[i].opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lx40;" &&
                ref.name == "i" && ref.type == "Ljh2;"
        }
        if (hits.size != 1) error("hj6.a: se esperaba 1 lectura de x40.i (hay ${hits.size})")
        val idx = hits[0]
        val reg = regName((list[idx] as OneRegisterInstruction).registerA, method)
        // El registro pasa a Object y vuelve a jh2 (null) para que el verificador de ART quede conforme.
        method.addInstructions(
            idx + 1,
            """
                invoke-static {$reg}, $OWN_FADE->capture(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object $reg
                check-cast $reg, Ljh2;
            """
        )
    }
}
