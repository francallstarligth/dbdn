package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch

private const val LRCRED = "Lapp/eclipse/extension/player/LrcRed;"

/**
 * v0.20.285 (SIN COMPILAR / SIN PROBAR). Eclipse 0.6.73: el pedido a Musixmatch es `po5.f(I duracion, String titulo,
 * String artista)Lqo5;` (VERIFICADO en el dex 73: lo llaman 3 sitios de fq.D, que es la corrutina de letras, y dentro
 * usa apic-desktop.musixmatch.com con "q_track=", "&q_artist=" y "&q_duration="). Registros: this=p0, duracion=p1,
 * titulo=p2, artista=p3 (37 registros en total; los primeros bytes mueven p0/p1/p3 a v1/v2/v3).
 *
 * Gancho al inicio de po5.f: LrcRed.fetch(titulo, artista, duracion) -> qo5 o null. Con un qo5 se devuelve ese
 * resultado; con null sigue el pedido original a Musixmatch (respaldo). Solo se usa cuando Musixmatch esta activado en
 * tu lista de proveedores de letras de Eclipse.
 */
@Suppress("unused")
val lrcRedPatch = bytecodePatch(
    description = "En lugar de pedir la letra a Musixmatch, Eclipse la pide primero a lrc.red (con tiempos por palabra " +
        "si los tiene). Si lrc.red no la tiene, sigue con Musixmatch como siempre. Necesita tener Musixmatch activado " +
        "en tus proveedores de letras.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val po5 = mutableClassDefBy(classDefBy("Lpo5;"))
        val matches = po5.methods.filter {
            it.name == "f" && it.returnType == "Lqo5;" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0].toString() == "I" &&
                it.parameterTypes[1].toString() == "Ljava/lang/String;" &&
                it.parameterTypes[2].toString() == "Ljava/lang/String;"
        }
        if (matches.size != 1) error("po5.f(I, String, String) no se encontro o esta repetido (${matches.size}); version de Eclipse distinta de 0.6.73?")
        val m = matches[0]
        val impl = m.implementation ?: error("po5.f sin codigo")
        // comprobacion: es el de Musixmatch (tiene la URL de apic-desktop.musixmatch.com)
        val isMxm = impl.instructions.any {
            (it as? com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction)?.reference
                ?.toString()?.contains("apic-desktop.musixmatch.com") == true
        }
        if (!isMxm) error("po5.f no parece el pedido de Musixmatch (version distinta?)")
        // v0..v2 estan libres al inicio (el metodo todavia no escribio nada; usa 37 registros)
        m.addInstructionsWithLabels(
            0,
            """
                move-object/from16 v0, p2
                move-object/from16 v1, p3
                move/from16 v2, p1
                invoke-static {v0, v1, v2}, $LRCRED->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                move-result-object v0
                if-eqz v0, :lrcred_orig
                check-cast v0, Lqo5;
                return-object v0
                :lrcred_orig
                nop
            """
        )
    }
}
