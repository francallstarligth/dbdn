package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val LRCRED = "Lapp/eclipse/extension/player/LrcRed;"

/**
 * v0.20.285 (SIN COMPILAR / SIN PROBAR). Eclipse 0.6.73: el pedido a Musixmatch es `po5.f(I duracion, String titulo,
 * String artista)Lvo5;` (VERIFICADO en el dex 73: lo llaman 3 sitios de fq.D, que es la corrutina de letras, y dentro
 * usa apic-desktop.musixmatch.com con "q_track=", "&q_artist=" y "&q_duration="). Registros: this=p0, duracion=p1,
 * titulo=p2, artista=p3 (37 registros en total; los primeros bytes mueven p0/p1/p3 a v1/v2/v3).
 *
 * Gancho al inicio de po5.f: LrcRed.fetch(titulo, artista, duracion) -> qo5 o null. Con un qo5 se devuelve ese
 * resultado; v0.20.289: se devuelve siempre lo que da fetch (qo5 o null = sin letra, Eclipse pasa a la siguiente fuente); el pedido original a Musixmatch queda como codigo muerto (como en CastAnalyticsOff). Solo se usa cuando Musixmatch esta activado en
 * tu lista de proveedores de letras de Eclipse.
 */
@Suppress("unused")
val lrcRedPatch = bytecodePatch(
    description = "En lugar de pedir la letra a Musixmatch, Eclipse la pide primero a lrc.red (con tiempos por palabra " +
        "si los tiene). Si lrc.red no la tiene, Eclipse pasa a la siguiente fuente (ya no se pide a Musixmatch). Necesita tener Musixmatch activado " +
        "en tus proveedores de letras.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val po5 = mutableClassDefBy(classDefBy("Luo5;"))
        val matches = po5.methods.filter {
            it.name == "f" && it.returnType == "Lvo5;" && it.parameterTypes.size == 3 &&
                it.parameterTypes[0].toString() == "I" &&
                it.parameterTypes[1].toString() == "Ljava/lang/String;" &&
                it.parameterTypes[2].toString() == "Ljava/lang/String;"
        }
        if (matches.size != 1) error("po5.f(I, String, String) no se encontro o esta repetido (${matches.size}); version de Eclipse distinta de 0.6.73?")
        val m = matches[0]
        val impl = m.implementation ?: error("po5.f sin codigo")
        // comprobacion: es el de Musixmatch (tiene la URL de apic-desktop.musixmatch.com)
        val isMxm = impl.instructions.any {
            (it as? com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction)?.reference
                ?.toString()?.contains("apic-desktop.musixmatch.com") == true
        }
        if (!isMxm) error("po5.f no parece el pedido de Musixmatch (version distinta?)")
        // v0..v2 estan libres al inicio (el metodo todavia no escribio nada; usa 37 registros)
        m.addInstructionsWithLabels(
            0,
            """
                move-object/from16 v0, p2
                move-object/from16 v1, p3
                move/from16 v2, p1
                invoke-static {v0, v1, v2}, $LRCRED->fetch(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/Object;
                move-result-object v0
                check-cast v0, Lvo5;
                return-object v0
                :lrcred_orig
                nop
            """
        )

        // v0.20.288: el nombre que se ve en la lista de fuentes y abajo a la izquierda pasa de "Musixmatch" a "lrc.red".
        // VERIFICADO en el dex 73: el texto "Musixmatch" esta en el <clinit> de dos enums: lq5 (campo label, el menu de
        // fuentes; const-string v2 en el indice 29) y ko5 (campo displayName, la fuente de la letra; indice 2).
        // Justo despues de ese const-string se pone otro con "lrc.red" en el mismo registro. El id interno
        // ("musixmatch") y el nombre MUSIXMATCH del enum no cambian.
        for (cls in listOf("Lqq5;", "Lpo5;")) {
            val c = mutableClassDefBy(classDefBy(cls))
            val ci = c.methods.firstOrNull { it.name == "<clinit>" } ?: error("$cls sin <clinit>")
            val list = (ci.implementation ?: error("$cls <clinit> sin codigo")).instructions.toList()
            val idx = list.indexOfFirst {
                ((it as? ReferenceInstruction)?.reference as? StringReference)?.string == "Musixmatch"
            }
            if (idx < 0) error("$cls: no se encontro el texto Musixmatch (version distinta de 0.6.73?)")
            val reg = (list[idx] as OneRegisterInstruction).registerA
            ci.addInstructions(idx + 1, "const-string v$reg, \"lrc.red\"")
        }
    }
}
