package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val BG = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

/**
 * v0.20.61 (SIN COMPILAR / SIN PROBAR). En Letras y Cola el fondo es la portada borrosa a pantalla completa (1.2x) y se
 * borronea a tamano real: es lo mas pesado de esa pantalla. Con este parche se borronea en una caja a 1/6 (radio/6) y la
 * capa se estira 6 veces: se ve casi igual y cuesta mucho menos. El gancho solo enciende el interruptor
 * BlurredCanvasBackground.lightPane (inicio de di6.q, igual que otros ganchos). No toca el Canvas ni el reflejo.
 */
@Suppress("unused")
val lightPanePatch = bytecodePatch(
    description = "El fondo borroso de Letras y Cola se hace con una copia chica de la portada y se estira: se ve casi igual " +
        "y el telefono trabaja menos al pasar de Artwork a Letras. Desmarcalo si el fondo se ve movido o raro.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Ly46;"
        } ?: error("No se encontro di6.q")
        q.addInstructions(0, "invoke-static {}, $BG->enableLightPane()V")
    }
}
