package app.eclipse.patches.automix

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val LOCAL = "Lapp/eclipse/extension/automix/LocalAutomix;"

/**
 * Automix local (Eclipse 0.6.47). Verificado solo contra el smali; NO probado en el telefono.
 *
 * wf0.invokeSuspend es el pedido del plan al servidor (GET api.eclipsemusic.app/api/automix/plan). Su comienzo:
 *   v4 = ISRC que sale (normalizado por yf0.e), v5 = ISRC que entra, v6 = fundido en segundos (int),
 *   y luego `iget-object v7, p0, wf0->u` (modo) y la cache/HTTP.
 * El gancho va justo ANTES de ese iget-object (v7 se sobrescribe ahi, asi que esta libre):
 *   LocalAutomix.planJson(out, in, fade) devuelve el JSON del plan -> wx6.G(json) lo convierte en sg0 (igual que
 *   con la respuesta del servidor) -> return sg0. Nunca se llega al HTTP.
 */
@Suppress("unused")
val localAutomixPatch = bytecodePatch(
    name = "Automix local",
    description = "Reemplaza el plan de Automix del servidor de Eclipse por uno calculado en el telefono " +
        "(BPM del analizador de Eclipse o de Deezer por ISRC, filtro y bass swap). Sin BPM usa valores fijos.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lwf0;"))
        val method = cls.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro wf0.invokeSuspend")
        val list = (method.implementation ?: error("wf0.invokeSuspend sin codigo")).instructions.toList()

        // Primer `iget-object ..., wf0->u:String` : es la lectura del modo, justo despues de calcular el fundido.
        val idx = list.indices.firstOrNull { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.IGET_OBJECT) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@firstOrNull false
            ref.definingClass == "Lwf0;" && ref.name == "u" && ref.type == "Ljava/lang/String;"
        } ?: error("wf0.invokeSuspend: no se encontro la lectura de wf0.u")

        // Comprobaciones de forma: antes debe venir `move-result` del fundido (v6) y antes la llamada a i92.x(III).
        if (list[idx - 1].opcode != Opcode.MOVE_RESULT) error("wf0.invokeSuspend: antes de wf0.u no hay move-result")
        val prev = ((list[idx - 2] as? ReferenceInstruction)?.reference as? MethodReference)
        if (prev == null || prev.definingClass != "Li92;" || prev.name != "x") {
            error("wf0.invokeSuspend: antes del move-result no esta la llamada a i92.x")
        }

        method.addInstructionsWithLabels(
            idx,
            """
                invoke-static {v4, v5, v6}, $LOCAL->planJson(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                move-result-object v7
                if-eqz v7, :automix_server
                invoke-static {v7}, Lwx6;->G(Ljava/lang/String;)Lsg0;
                move-result-object v7
                return-object v7
                :automix_server
                nop
            """
        )

        // ---- Gancho 2: ficha del analizador de Eclipse (tf0.a) -------------------------------------------------
        // tf0.a(Ltf0;, String isrc, Lcg0;, Lkg0;, Z) -> String analiza la cancion en el telefono (decodifica, libreria
        // nativa + modelos ONNX) y arma la ficha con tf0.c(jsonNativo, isrc, duracion, fuente). Justo despues de ese
        // `move-result-object` (antes del `if-nez` que comprueba null) pasamos ISRC y ficha a LocalAutomix.onCard,
        // que guarda el BPM en la cache. Eclipse sigue con su flujo normal (la ficha se sube igual que antes).
        val analyzer = mutableClassDefBy(classDefBy("Ltf0;"))
        val analyze = analyzer.methods.firstOrNull {
            it.name == "a" && it.returnType == "Ljava/lang/String;" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ltf0;", "Ljava/lang/String;", "Lcg0;", "Lkg0;", "Z")
        } ?: error("No se encontro tf0.a")
        val body = (analyze.implementation ?: error("tf0.a sin codigo")).instructions.toList()

        val cardCall = body.indices.firstOrNull { i ->
            val ins = body[i]
            if (ins.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Ltf0;" && ref.name == "c" && ref.returnType == "Ljava/lang/String;" &&
                ref.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Ljava/lang/String;", "D", "Lcg0;")
        } ?: error("tf0.a: no se encontro la llamada a tf0.c")

        if (body[cardCall + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("tf0.a: tras tf0.c no hay move-result-object")
        if (body[cardCall + 2].opcode != Opcode.IF_NEZ) error("tf0.a: tras la ficha no hay if-nez")

        // tf0.c(json, isrc, D, cg0) = invoke-static {json, isrc, dLo, dHi, cg0}: el ISRC es el 2.o registro (D).
        val isrcReg = (body[cardCall] as FiveRegisterInstruction).registerD
        val cardReg = (body[cardCall + 1] as OneRegisterInstruction).registerA
        if (isrcReg > 15 || cardReg > 15) error("tf0.a: registros >15 (isrc=v$isrcReg, ficha=v$cardReg)")

        analyze.addInstructions(
            cardCall + 2,
            "invoke-static {v$isrcReg, v$cardReg}, $LOCAL->onCard(Ljava/lang/String;Ljava/lang/String;)V"
        )
    }
}
