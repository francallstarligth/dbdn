package app.eclipse.patches.automix

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val LOCAL = "Lapp/eclipse/extension/automix/LocalAutomix;"

/**
 * Automix local (Eclipse 0.6.47). Verificado solo contra el smali; NO probado en el telefono.
 *
 * wf0.invokeSuspend es el pedido del plan al servidor (GET api.eclipsemusic.app/api/automix/plan). Su comienzo:
 *   v4 = ISRC que sale (normalizado por yf0.e), v5 = ISRC que entra, v6 = fundido en segundos (int),
 *   y luego `iget-object v7, p0, wf0->u` (modo) y la cache/HTTP.
 * El gancho va justo ANTES de ese iget-object (v7 se sobrescribe ahi, asi que esta libre):
 *   LocalAutomix.planJson(out, in, fade) devuelve el JSON del plan -> wx6.G(json) lo convierte en sg0 (igual que
 *   con la respuesta del servidor) -> return sg0. Nunca se llega al HTTP.
 */
@Suppress("unused")
val localAutomixPatch = bytecodePatch(
    name = "Automix local",
    description = "Reemplaza el plan de Automix del servidor de Eclipse por uno calculado en el telefono " +
        "(BPM del analizador de Eclipse o de Deezer por ISRC, filtro y bass swap). Sin BPM usa valores fijos.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lwf0;"))
        val method = cls.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro wf0.invokeSuspend")
        val list = (method.implementation ?: error("wf0.invokeSuspend sin codigo")).instructions.toList()

        // Primer `iget-object ..., wf0->u:String` : es la lectura del modo, justo despues de calcular el fundido.
        val idx = list.indices.firstOrNull { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.IGET_OBJECT) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@firstOrNull false
            ref.definingClass == "Lwf0;" && ref.name == "u" && ref.type == "Ljava/lang/String;"
        } ?: error("wf0.invokeSuspend: no se encontro la lectura de wf0.u")

        // Comprobaciones de forma: antes debe venir `move-result` del fundido (v6) y antes la llamada a i92.x(III).
        if (list[idx - 1].opcode != Opcode.MOVE_RESULT) error("wf0.invokeSuspend: antes de wf0.u no hay move-result")
        val prev = ((list[idx - 2] as? ReferenceInstruction)?.reference as? MethodReference)
        if (prev == null || prev.definingClass != "Li92;" || prev.name != "x") {
            error("wf0.invokeSuspend: antes del move-result no esta la llamada a i92.x")
        }

        method.addInstructionsWithLabels(
            idx,
            """
                invoke-static {v4, v5, v6}, $LOCAL->planJson(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                move-result-object v7
                if-eqz v7, :automix_server
                invoke-static {v7}, Lwx6;->G(Ljava/lang/String;)Lsg0;
                move-result-object v7
                return-object v7
                :automix_server
                nop
            """
        )

        // ---- Gancho 2: ficha del analizador de Eclipse (tf0.a) -------------------------------------------------
        // tf0.a(Ltf0;, String isrc, Lcg0;, Lkg0;, Z) -> String analiza la cancion en el telefono (decodifica, libreria
        // nativa + modelos ONNX) y arma la ficha con tf0.c(jsonNativo, isrc, duracion, fuente). Justo despues de ese
        // `move-result-object` (antes del `if-nez` que comprueba null) pasamos ISRC y ficha a LocalAutomix.onCard,
        // que guarda el BPM en la cache. Eclipse sigue con su flujo normal (la ficha se sube igual que antes).
        val analyzer = mutableClassDefBy(classDefBy("Ltf0;"))
        val analyze = analyzer.methods.firstOrNull {
            it.name == "a" && it.returnType == "Ljava/lang/String;" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ltf0;", "Ljava/lang/String;", "Lcg0;", "Lkg0;", "Z")
        } ?: error("No se encontro tf0.a")
        val body = (analyze.implementation ?: error("tf0.a sin codigo")).instructions.toList()

        val cardCall = body.indices.firstOrNull { i ->
            val ins = body[i]
            if (ins.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Ltf0;" && ref.name == "c" && ref.returnType == "Ljava/lang/String;" &&
                ref.parameterTypes.map { p -> p.toString() } ==
                listOf("Ljava/lang/String;", "Ljava/lang/String;", "D", "Lcg0;")
        } ?: error("tf0.a: no se encontro la llamada a tf0.c")

        if (body[cardCall + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("tf0.a: tras tf0.c no hay move-result-object")
        if (body[cardCall + 2].opcode != Opcode.IF_NEZ) error("tf0.a: tras la ficha no hay if-nez")

        // tf0.c(json, isrc, D, cg0) = invoke-static {json, isrc, dLo, dHi, cg0}: el ISRC es el 2.o registro (D).
        val isrcReg = (body[cardCall] as FiveRegisterInstruction).registerD
        val cardReg = (body[cardCall + 1] as OneRegisterInstruction).registerA
        if (isrcReg > 15 || cardReg > 15) error("tf0.a: registros >15 (isrc=v$isrcReg, ficha=v$cardReg)")

        analyze.addInstructions(
            cardCall + 2,
            "invoke-static {v$isrcReg, v$cardReg}, $LOCAL->onCard(Ljava/lang/String;Ljava/lang/String;)V"
        )

        // ---- Gancho 3 (paso 2): dg0.D(String) -> boolean = "ya analizada/subida" ----------------------------------
        // Lo consultan ig0.a y tf0.b (x2) para saltarse canciones ya analizadas. Justo tras normalizar el ISRC con
        // yf0.e (move-result-object p1) y antes de tocar las listas, devolvemos LocalAutomix.analyzed(isrc): solo es
        // true si la ficha de ESA cancion ya paso por onCard. Asi las ya analizadas por Eclipse se re-analizan una vez.
        val registry = mutableClassDefBy(classDefBy("Ldg0;"))
        val done = registry.methods.firstOrNull {
            it.name == "D" && it.returnType == "Z" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/String;")
        } ?: error("No se encontro dg0.D")
        val dBody = (done.implementation ?: error("dg0.D sin codigo")).instructions.toList()

        val normCall = dBody.indices.firstOrNull { i ->
            val ins = dBody[i]
            if (ins.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lyf0;" && ref.name == "e" && ref.returnType == "Ljava/lang/String;"
        } ?: error("dg0.D: no se encontro la llamada a yf0.e")

        val normMove = dBody[normCall + 1]
        if (normMove.opcode != Opcode.MOVE_RESULT_OBJECT) error("dg0.D: tras yf0.e no hay move-result-object")
        if (dBody[normCall + 2].opcode != Opcode.IGET_OBJECT) error("dg0.D: tras el ISRC no viene iget-object")
        val isrcDReg = (normMove as OneRegisterInstruction).registerA
        if (isrcDReg > 15) error("dg0.D: registro del ISRC >15 (v$isrcDReg)")

        // v0 esta libre (se sobrescribe en el iget-object siguiente); el codigo que queda detras es inalcanzable.
        done.addInstructions(
            normCall + 2,
            """
                invoke-static {v$isrcDReg}, $LOCAL->analyzed(Ljava/lang/String;)Z
                move-result v0
                return v0
            """
        )

        // ---- Paso 3, gancho 4: canciones sin ISRC -----------------------------------------------------------------
        // Las 3 lecturas de Song.getIsrc() del flujo de Automix (ig0.a x1, ig0.d x2) siguen el patron
        //   invoke-virtual{/range} {Song}, Song->getIsrc() ; move-result-object vR ; if-eqz vR, :sin_automix
        // Entre el move-result-object y el if-eqz sustituimos vR por LocalAutomix.isrcFor(Song): el ISRC real si lo hay y, si
        // es null o vacio, uno inventado (ZZ + hash del id) para que Eclipse trate la cancion como cualquier otra.
        fun hookGetIsrc(className: String, methodName: String, expected: Int) {
            val c = mutableClassDefBy(classDefBy(className))
            val m = c.methods.firstOrNull { it.name == methodName && it.returnType == "Ljava/lang/Object;" }
                ?: error("No se encontro $className.$methodName")
            val ins = (m.implementation ?: error("$className.$methodName sin codigo")).instructions.toList()
            val sites = ins.indices.filter { i ->
                val x = ins[i]
                if (x.opcode != Opcode.INVOKE_VIRTUAL && x.opcode != Opcode.INVOKE_VIRTUAL_RANGE) return@filter false
                val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@filter false
                ref.definingClass == "Lcom/eclipse/android/data/models/Song;" && ref.name == "getIsrc"
            }
            if (sites.size != expected) error("$className.$methodName: se esperaban $expected getIsrc y hay ${sites.size}")
            // De atras hacia delante para que los indices anteriores no se muevan.
            for (i in sites.reversed()) {
                val call = ins[i]
                if (ins[i + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("$className.$methodName: tras getIsrc no hay move-result-object")
                if (ins[i + 2].opcode != Opcode.IF_EQZ) error("$className.$methodName: tras el ISRC no hay if-eqz")
                val resultReg = (ins[i + 1] as OneRegisterInstruction).registerA
                val songReg = if (call.opcode == Opcode.INVOKE_VIRTUAL_RANGE) {
                    (call as RegisterRangeInstruction).startRegister
                } else {
                    (call as FiveRegisterInstruction).registerC
                }
                m.addInstructions(
                    i + 2,
                    """
                        invoke-static/range {v$songReg .. v$songReg}, $LOCAL->isrcFor(Ljava/lang/Object;)Ljava/lang/String;
                        move-result-object v$resultReg
                    """
                )
            }
        }
        hookGetIsrc("Lig0;", "a", 1)
        hookGetIsrc("Lig0;", "d", 2)

        // ---- Paso 3, gancho 5: no subir fichas con ISRC inventado ---------------------------------------------------
        // xf0.invokeSuspend (caso 0 del switch) = POST api/automix/analysis con la ficha en xf0.s. Va tras
        // `invoke-static/range {p1 .. p1}, Lyg2;->K` y antes de armar la peticion. Si la ficha lleva un ISRC inventado devolvemos
        // Boolean.TRUE (como si ya estuviera subida) y no sale nada a la red. v0 = this, v7 libre (se reasigna justo despues).
        val uploader = mutableClassDefBy(classDefBy("Lxf0;"))
        val upload = uploader.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro xf0.invokeSuspend")
        val up = (upload.implementation ?: error("xf0.invokeSuspend sin codigo")).instructions.toList()

        val tagIdx = up.indices.firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.CONST_STRING) return@firstOrNull false
            ((x as ReferenceInstruction).reference as? StringReference)?.string == "analysis upload HTTP "
        } ?: error("xf0: no se encontro \"analysis upload HTTP \"")

        val kIdx = (tagIdx + 1 until minOf(tagIdx + 12, up.size)).firstOrNull { i ->
            val x = up[i]
            if (x.opcode != Opcode.INVOKE_STATIC_RANGE && x.opcode != Opcode.INVOKE_STATIC) return@firstOrNull false
            val ref = (x as ReferenceInstruction).reference as? MethodReference ?: return@firstOrNull false
            ref.definingClass == "Lyg2;" && ref.name == "K"
        } ?: error("xf0: tras la marca de subida no se encontro yg2.K")
        if (up[kIdx + 1].opcode != Opcode.SGET_OBJECT) error("xf0: tras yg2.K no viene sget-object")

        upload.addInstructionsWithLabels(
            kIdx + 1,
            """
                iget-object v7, v0, Lxf0;->s:Ljava/lang/String;
                invoke-static {v7}, $LOCAL->blockUpload(Ljava/lang/String;)Z
                move-result v7
                if-eqz v7, :automix_upload
                sget-object v0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;
                return-object v0
                :automix_upload
                nop
            """
        )
    }
}
