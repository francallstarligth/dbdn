package app.eclipse.patches.automix

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val LOCAL = "Lapp/eclipse/extension/automix/LocalAutomix;"

/**
 * Automix local (Eclipse 0.6.47). Verificado solo contra el smali; NO probado en el telefono.
 *
 * wf0.invokeSuspend es el pedido del plan al servidor (GET api.eclipsemusic.app/api/automix/plan). Su comienzo:
 *   v4 = ISRC que sale (normalizado por yf0.e), v5 = ISRC que entra, v6 = fundido en segundos (int),
 *   y luego `iget-object v7, p0, wf0->u` (modo) y la cache/HTTP.
 * El gancho va justo ANTES de ese iget-object (v7 se sobrescribe ahi, asi que esta libre):
 *   LocalAutomix.planJson(out, in, fade) devuelve el JSON del plan -> wx6.G(json) lo convierte en sg0 (igual que
 *   con la respuesta del servidor) -> return sg0. Nunca se llega al HTTP.
 */
@Suppress("unused")
val localAutomixPatch = bytecodePatch(
    name = "Automix local",
    description = "Reemplaza el plan de Automix del servidor de Eclipse por uno calculado en el telefono " +
        "(BPM de Deezer por ISRC, filtro y bass swap). Sin BPM usa valores fijos.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lwf0;"))
        val method = cls.methods.firstOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro wf0.invokeSuspend")
        val list = (method.implementation ?: error("wf0.invokeSuspend sin codigo")).instructions.toList()

        // Primer `iget-object ..., wf0->u:String` : es la lectura del modo, justo despues de calcular el fundido.
        val idx = list.indices.firstOrNull { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.IGET_OBJECT) return@firstOrNull false
            val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@firstOrNull false
            ref.definingClass == "Lwf0;" && ref.name == "u" && ref.type == "Ljava/lang/String;"
        } ?: error("wf0.invokeSuspend: no se encontro la lectura de wf0.u")

        // Comprobaciones de forma: antes debe venir `move-result` del fundido (v6) y antes la llamada a i92.x(III).
        if (list[idx - 1].opcode != Opcode.MOVE_RESULT) error("wf0.invokeSuspend: antes de wf0.u no hay move-result")
        val prev = ((list[idx - 2] as? ReferenceInstruction)?.reference as? MethodReference)
        if (prev == null || prev.definingClass != "Li92;" || prev.name != "x") {
            error("wf0.invokeSuspend: antes del move-result no esta la llamada a i92.x")
        }

        method.addInstructionsWithLabels(
            idx,
            """
                invoke-static {v4, v5, v6}, $LOCAL->planJson(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                move-result-object v7
                if-eqz v7, :automix_server
                invoke-static {v7}, Lwx6;->G(Ljava/lang/String;)Lsg0;
                move-result-object v7
                return-object v7
                :automix_server
                nop
            """
        )
    }
}
