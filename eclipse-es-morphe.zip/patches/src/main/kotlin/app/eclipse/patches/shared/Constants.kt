package app.eclipse.patches.shared

import app.morphe.patcher.patch.ApkFileType
import app.morphe.patcher.patch.AppTarget
import app.morphe.patcher.patch.Compatibility

object Constants {
    val COMPATIBILITY_ECLIPSE = Compatibility(
        name = "Eclipse",
        packageName = "com.eclipse.android",
        apkFileType = ApkFileType.APK,
        appIconColor = 0x6C5CE7,
        targets = listOf(
            // Version objetivo (0.6.55). Los grupos 1, 2 y 5 ya estan portados a 0.6.55; los parches de los grupos 3, 4 y 6 siguen con nombres de 0.6.47 hasta que se porten (fallan en 0.6.55).
            AppTarget(version = "0.6.55"),
            // Otras versiones: experimental. Los textos se buscan por contenido,
            // pero las reglas de seguridad por sitio conviene revisarlas.
            AppTarget(version = null, isExperimental = true)
        )
    )
}
