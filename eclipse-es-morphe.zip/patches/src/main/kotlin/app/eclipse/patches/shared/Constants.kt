package app.eclipse.patches.shared

import app.morphe.patcher.patch.ApkFileType
import app.morphe.patcher.patch.AppTarget
import app.morphe.patcher.patch.Compatibility

object Constants {
    val COMPATIBILITY_ECLIPSE = Compatibility(
        name = "Eclipse",
        packageName = "com.eclipse.android",
        apkFileType = ApkFileType.APK,
        appIconColor = 0x6C5CE7,
        targets = listOf(
            // Version objetivo (0.6.57). Portados a 0.6.57: Letras grandes (LyricsPop) y Brillo (LyricsGlow). Todo lo demas sigue con nombres de 0.6.55 (o 0.6.47) y falla en 0.6.57 hasta portarlo.
            AppTarget(version = "0.6.57"),
            // Otras versiones: experimental. Los textos se buscan por contenido,
            // pero las reglas de seguridad por sitio conviene revisarlas.
            AppTarget(version = null, isExperimental = true)
        )
    )
}
