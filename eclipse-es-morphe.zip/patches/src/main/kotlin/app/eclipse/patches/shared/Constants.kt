package app.eclipse.patches.shared

import app.morphe.patcher.patch.ApkFileType
import app.morphe.patcher.patch.AppTarget
import app.morphe.patcher.patch.Compatibility

object Constants {
    val COMPATIBILITY_ECLIPSE = Compatibility(
        name = "Eclipse",
        packageName = "com.eclipse.android",
        apkFileType = ApkFileType.APK,
        appIconColor = 0x6C5CE7,
        targets = listOf(
            // Version objetivo (0.6.57). Portados a 0.6.57: Letras grandes, Brillo, Silabas, Colas, SoftFade, PlusWords, Mochy, Retry, AlignLeft, FixedAnimationSpeed, CastAnalyticsOff, FreeTranslation, DjSpanish, AppleToken, AutomixBackup, PausePrevious, StaleGuard, PlayerWaitCover, LightPane, LightCanvas y LightReflection. Todo lo demas sigue con nombres de 0.6.55 (o 0.6.47) y falla en 0.6.57 hasta portarlo.
            AppTarget(version = "0.6.57"),
            AppTarget(version = "0.6.70"), // v0.20.242: portando a 0.6.70 grupo por grupo; grupos 1 y 2 y parte del 3 listos (PlayerEnter, WaitCover, PausePrevious; Cast, FixedAnimationSpeed, KeepScreenOn, DjSpanish, PlusWords, TabKeep, Glow, Silabas; Cast, AlignLeft, FreeTranslation, Onnx, Inter, Apple token, iconos). El resto sigue con nombres de 0.6.61 y falla en 0.6.70 hasta portarlo.
            AppTarget(version = "0.6.61"), // TEMPORAL para probar: solo estan portados a 0.6.61: Canvas comunidad y los 12 parches de la tanda 1 (README v0.20.210)
            // Otras versiones: experimental. Los textos se buscan por contenido,
            // pero las reglas de seguridad por sitio conviene revisarlas.
            AppTarget(version = null, isExperimental = true)
        )
    )
}
