package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val POP = "Lapp/eclipse/extension/player/StarPop;"

/**
 * v0.20.409 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Animacion de estrella al marcar una cancion como favorita (como el corazon de Mochy).
 * Un solo gancho: `Lh61.<init>` (unico return-void) -> `StarPop.fromState(this)`. Mismo punto que usa `CodecNearPatch.kt` (se pueden usar juntos:
 * cada uno inserta antes del unico `return-void`). Ver `StarPop.java`.
 */
@Suppress("unused")
val starPopPatch = bytecodePatch(
    name = "Favorito: estrella animada",
    description = "Al marcar una cancion como favorita sale una estrella grande en el centro (blanca a dorada con brillo) que se desvanece, y un aviso de texto sobre " +
        "el titulo, como el corazon de Mochy. Es una vista de Android encima del reproductor. Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lh61;"))
        val m = cls.methods.singleOrNull { it.name == "<init>" && it.parameterTypes.size == 26 }
            ?: error("Estrella: no se encontro Lh61.<init>")
        val ins = (m.implementation ?: error("Estrella: Lh61.<init> sin codigo")).instructions.toList()
        val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
        if (ret.size != 1) error("Estrella: se esperaba 1 return-void en Lh61.<init> y hay ${ret.size}")
        m.addInstructions(ret[0], "invoke-static {p0}, $POP->fromState(Ljava/lang/Object;)V")
    }
}
