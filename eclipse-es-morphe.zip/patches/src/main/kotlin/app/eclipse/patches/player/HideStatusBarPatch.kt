package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

private const val AWAKE_BAR = "Lapp/eclipse/extension/player/KeepAwake;"

/**
 * v0.20.417 (SIN COMPILAR NI PROBAR). Casilla nueva `navButtons` (activa): tambien se esconden los botones de navegacion de Android
 * (cuadrado, circulo, triangulo) con el mismo desvanecido; deslizando desde abajo aparecen un momento. El gancho llama a
 * `KeepAwake.startHideBarNav()` (que pone navTambien y llama a startHideBar()) en vez de `startHideBar()`; sin registros nuevos.
 * El desvanecido retiene el espacio de las barras, asi el contenido no sube ni baja.
 *
 * v0.20.383 (SIN COMPILAR NI PROBAR; sin kotlinc aqui). Oculta la barra de estado (hora, senal, wifi, bateria) SOLO mientras
 * el reproductor grande esta abierto. Usa el mismo reloj que "Reproductor: pantalla siempre encendida" (`KeepAwake`, que lee
 * `Lex7;->a` cada 700 ms) y el mismo gancho: inicio de `Lex7;->e()` (abrir el reproductor). Al abrir se hace una revision
 * inmediata; al cerrar la barra vuelve en la siguiente revision (hasta 700 ms). Deslizando desde arriba aparece un momento.
 * Si no se encuentra `Lex7;->e()`, el parche falla.
 */
@Suppress("unused")
val hideStatusBarPatch = bytecodePatch(
    name = "Reproductor: ocultar la barra de estado",
    description = "Mientras el reproductor grande esta abierto se esconde la barra de arriba (hora, senal, wifi y bateria). " +
        "Al cerrarlo vuelve. Deslizando desde arriba aparece un momento. " +
        "Opcional: tambien los botones de navegacion (cuadrado, circulo, triangulo); deslizando desde abajo aparecen un momento.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val navButtons by booleanOption(
        key = "navButtons",
        default = true,
        title = "Esconder tambien los botones de navegacion",
        description = "Los botones de abajo (cuadrado, circulo, triangulo) se esconden con desvanecido mientras el reproductor grande esta abierto. " +
            "Deslizando desde abajo aparecen un momento, translucidos sobre el contenido."
    )

    execute {
        val ex7 = mutableClassDefBy(classDefBy("Lex7;"))
        val f = ex7.methods.singleOrNull {
            it.name == "e" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro ex7.e (Eclipse 0.6.75)")
        val hook = if (navButtons == true) "startHideBarNav" else "startHideBar"
        f.addInstructions(0, "invoke-static {}, $AWAKE_BAR->$hook()V")
    }
}
