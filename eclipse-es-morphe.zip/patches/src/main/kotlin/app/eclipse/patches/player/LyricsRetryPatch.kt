package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val RETRY = "Lapp/eclipse/extension/player/LyricsRetry;"

/**
 * v0.20.122 (SIN COMPILAR / SIN PROBAR). Reintento automatico cuando la busqueda de letra vuelve vacia.
 *
 * VERIFICADO en el smali de 0.6.47: la letra se pide en nd2.h0 (composable) con un LaunchedEffect cuyo bloque es j1
 * (selector pswitch_b de j1.invokeSuspend). Ese bloque llama Lj74;->V(py1.s, new y9(ov4, id, titulo, artista, duracion,
 * isrc, null), this); al volver (directo o por reanudacion de estado 2) las dos rutas confluyen en :goto_10:
 *   check-cast v1, Lpv4; iget-object v2, v2, Lvu4;->a:Lc56; (guarda la letra) ... (vu4.b = false: ya no "buscando").
 * Registros en ese punto (verificados): v0 = Lng9 (Unit, valor de retorno), v1 = resultado pv4 o null, v2 = vu4, v3 = Song,
 * v4 = vu4 (j1.z), v5 = COROUTINE_SUSPENDED, p0 = this (j1; v1 se pisa con el resultado). j1.t = titulo, j1.x = artista,
 * j1.w = ov4; la duracion se guardo en vu4.c (z46) con h(I) y se lee con g()I.
 *
 * Justo despues del check-cast se inserta: si v1 es null y LyricsRetry.shouldRetry(song.id) -> se vuelve a armar y9
 * con los mismos datos, se escribe s = 2 e y = vu4 (igual que el original) y se llama j74.V otra vez; si suspende se
 * devuelve COROUTINE_SUSPENDED (al reanudar vuelve a entrar por :goto_10 y se repite la comprobacion); si no suspende
 * se repite aqui mismo. Al final se restaura v2 = vu4 para el codigo original. Ademas, al inicio de y9.h (hilo de IO) se
 * llama LyricsRetry.maybeDelay() que espera 1.5 s si hay un reintento pendiente.
 */
@Suppress("unused")
val lyricsRetryPatch = bytecodePatch(
    name = "Letras: reintentar si no cargan",
    description = "Si la busqueda de letra vuelve vacia, Eclipse la repite sola hasta 2 veces (con una pausa de 1.5 s) " +
        "antes de decir que no hay letra. Las canciones sin letra tardan unos 4 s mas en avisarlo. " +
        "Desmarcalo si prefieres el comportamiento original.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // 1) y9.h: pausa antes de pedir si hay un reintento pendiente.
        val y9 = mutableClassDefBy(classDefBy("Ly9;"))
        val h = y9.methods.singleOrNull {
            it.name == "h" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;") &&
                it.returnType == "Ljava/lang/Object;"
        } ?: error("No se encontro y9.h (version de Eclipse distinta de 0.6.47?)")
        h.addInstructions(0, "invoke-static {}, $RETRY->maybeDelay()V")

        // 2) j1.invokeSuspend: el reintento, justo despues de `check-cast v1, Lpv4;` seguido de `iget-object v2, v2, Lvu4;->a`.
        val j1 = mutableClassDefBy(classDefBy("Lj1;"))
        val inv = j1.methods.singleOrNull {
            it.name == "invokeSuspend" && it.parameterTypes.map { p -> p.toString() } == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro j1.invokeSuspend")
        val list = (inv.implementation ?: error("j1.invokeSuspend sin codigo")).instructions.toList()
        val hits = list.indices.filter { i ->
            if (i + 1 >= list.size) return@filter false
            val a = list[i]
            val b = list[i + 1]
            val aRef = (a as? ReferenceInstruction)?.reference as? TypeReference
            val bRef = (b as? ReferenceInstruction)?.reference as? FieldReference
            a.opcode == Opcode.CHECK_CAST && aRef?.type == "Lpv4;" &&
                b.opcode == Opcode.IGET_OBJECT && bRef != null &&
                bRef.definingClass == "Lvu4;" && bRef.name == "a" && bRef.type == "Lc56;"
        }
        if (hits.size != 1) error("j1.invokeSuspend: se esperaba 1 'check-cast Lpv4;' + 'iget-object Lvu4;->a' y hay ${hits.size}")

        inv.addInstructionsWithLabels(
            hits[0] + 1,
            """
                :lr_again
                if-nez v1, :lr_ok
                invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getId()Ljava/lang/String;
                move-result-object v9
                invoke-static {v9}, $RETRY->shouldRetry(Ljava/lang/String;)Z
                move-result v6
                if-eqz v6, :lr_ok
                move-object/from16 v6, p0
                iget-object v8, v6, Lj1;->w:Ljava/lang/Object;
                check-cast v8, Lov4;
                iget-object v10, v6, Lj1;->t:Ljava/lang/Object;
                check-cast v10, Ljava/lang/String;
                iget-object v11, v6, Lj1;->x:Ljava/lang/Object;
                check-cast v11, Ljava/lang/String;
                iget-object v12, v4, Lvu4;->c:Lz46;
                invoke-virtual {v12}, Lz46;->g()I
                move-result v12
                invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getIsrc()Ljava/lang/String;
                move-result-object v13
                iput-object v4, v6, Lj1;->y:Ljava/lang/Object;
                const/4 v7, 0x2
                iput v7, v6, Lj1;->s:I
                sget-object v2, Lpy1;->s:Lpy1;
                new-instance v7, Ly9;
                const/4 v14, 0x0
                invoke-direct/range {v7 .. v14}, Ly9;-><init>(Lov4;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Lqn1;)V
                invoke-static {v2, v7, v6}, Lj74;->V(Lxo1;Lt43;Lqn1;)Ljava/lang/Object;
                move-result-object v1
                if-eq v1, v5, :lr_susp
                check-cast v1, Lpv4;
                goto :lr_again
                :lr_susp
                return-object v5
                :lr_ok
                move-object v2, v4
            """
        )
    }
}
