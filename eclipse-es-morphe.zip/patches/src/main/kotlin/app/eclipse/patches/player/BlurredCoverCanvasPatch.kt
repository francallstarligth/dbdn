package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Si el layout tiene la portada nitida pegada arriba con fundido (edgeFade), el video se dibuja como reflejo " +
        "(volteado) justo debajo de la portada; en los demas layouts queda a pantalla completa, sin voltear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val syncStart by booleanOption(
        key = "syncStart",
        default = false,
        title = "Sincronizar inicio",
        description = "La portada con Canvas y el fondo borroso con Canvas son dos videos distintos y a veces uno aparece " +
            "antes que el otro. Con esto, cada uno espera a que el otro tenga su primer cuadro y los dos aparecen juntos " +
            "(mientras tanto se ve la portada quieta). Si el video de uno falla, el otro se queda en la portada quieta."
    )

    execute {
        // eg6.g(Object, Object, Object): lambda de contenido del reproductor Custom. Llama a
        // di6.c(sv0, Z, Song, ki1, I) (dibuja el fondo). Justo despues se agrega el video, porque aqui si
        // se tiene ow0 (di6.c solo recibe la cancion).
        val eg6 = mutableClassDefBy(classDefBy("Leg6;"))
        val method = eg6.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro eg6.g (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("eg6.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Ldi6;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } ==
                listOf("Lsv0;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lki1;", "I")
        } ?: error("eg6.g: no se encontro di6.c(sv0, Z, Song, ki1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val bgReg = call.registerC          // sv0
        val composerReg = call.registerF    // ki1 (el composer)

        // ow0: el objeto del que se saca la cancion justo antes de la llamada (iget-object vX, vOw0, Low0;->a).
        val songGet = (callIdx - 1 downTo maxOf(0, callIdx - 12)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Low0;" && ref.name == "a"
        } ?: error("eg6.g: no se encontro ow0.a antes de di6.c")
        val stateReg = (list[songGet] as TwoRegisterInstruction).registerB

        // ib6 (el layout): el objeto de donde se saca el fondo (iget-object vX, vThis, Leg6;->q:Lib6;).
        val layoutGet = (callIdx - 1 downTo maxOf(0, callIdx - 40)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Leg6;" && ref.name == "q" &&
                ref.type == "Lib6;"
        } ?: error("eg6.g: no se encontro eg6.q (ib6) antes de di6.c")
        val layoutReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Alto disponible en dp: el ultimo ko0.b() antes de la llamada y su move-result.
        val heightCall = (callIdx - 1 downTo maxOf(0, callIdx - 80)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lko0;" && ref.name == "b" && ref.returnType == "F" &&
                list[i + 1].opcode == Opcode.MOVE_RESULT
        } ?: error("eg6.g: no se encontro ko0.b() antes de di6.c")
        val heightReg = (list[heightCall + 1] as OneRegisterInstruction).registerA
        // Que nadie reescriba ese registro entre su move-result y la llamada.
        for (i in heightCall + 2 until callIdx) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == heightReg) ||
                (ins.opcode.setsWideRegister() && (a == heightReg || a + 1 == heightReg))
            if (hit) error("eg6.g: v$heightReg se reescribe antes de di6.c")
        }

        // Registro de pasaje: el de Song (3er argumento de di6.c), que se pisa justo despues de la llamada.
        val scratchReg = call.registerE
        val after = list.getOrNull(callIdx + 1)
        val afterRef = (after as? ReferenceInstruction)?.reference as? FieldReference
        if (after == null || after.opcode != Opcode.SGET_OBJECT || (after as OneRegisterInstruction).registerA != scratchReg ||
            afterRef == null || afterRef.definingClass != "Ljh5;"
        ) error("eg6.g: tras di6.c se esperaba sget-object v$scratchReg, Ljh5;->q")

        for (r in listOf(bgReg, stateReg, composerReg, layoutReg, scratchReg)) {
            if (r > 15) error("eg6.g: registro v$r fuera de rango para invoke-static")
        }
        if (setOf(bgReg, stateReg, composerReg, layoutReg, scratchReg).size != 5) error("eg6.g: registros repetidos")

        method.addInstructions(
            callIdx + 1,
            """
                move/from16 v$scratchReg, v$heightReg
                invoke-static {v$bgReg, v$stateReg, v$composerReg, v$layoutReg, v$scratchReg}, $HELPER->draw(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
            """
        )

        // v1.93.0 (opcion Sincronizar inicio): xi6.h(url, playing, modifier, composer, int) crea su propio ExoPlayer y
        // elige entre dibujar el video o la portada quieta segun un estado "primer cuadro listo" (en5 = v9). Justo
        // despues de leerlo (`Boolean.booleanValue()` -> move-result vX -> if-eqz vX) se pasa por
        // CanvasSync.gate(player = v5, estado = v9, url = p0, listo = vX) y se usa su resultado.
        if (syncStart == true) {
            val xi6 = mutableClassDefBy(classDefBy("Lxi6;"))
            val h = xi6.methods.singleOrNull { m ->
                m.name == "h" && m.parameterTypes.map { it.toString() } ==
                    listOf("Ljava/lang/String;", "Z", "Lmh5;", "Lki1;", "I")
            } ?: error("No se encontro xi6.h(String, boolean, Modifier, Composer, int)")
            val impl = h.implementation ?: error("xi6.h sin codigo")
            if (impl.registerCount != 16) error("xi6.h: se esperaban 16 registros (hay ${impl.registerCount})")
            val ins = impl.instructions.toList()

            val hits = ins.indices.filter { i ->
                val ref = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
                ins[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null &&
                    ref.definingClass == "Ljava/lang/Boolean;" && ref.name == "booleanValue" &&
                    i + 2 < ins.size && ins[i + 1].opcode == Opcode.MOVE_RESULT && ins[i + 2].opcode == Opcode.IF_EQZ &&
                    (ins[i + 1] as OneRegisterInstruction).registerA == (ins[i + 2] as OneRegisterInstruction).registerA
            }
            if (hits.size != 1) error("xi6.h: se esperaba 1 lectura del indicador (hay ${hits.size})")
            val at = hits[0]
            val readyReg = (ins[at + 1] as OneRegisterInstruction).registerA
            if (readyReg > 15) error("xi6.h: registro del indicador fuera de v0..v15 (v$readyReg)")

            // v5 debe ser el ExoPlayer (check-cast) y v9 el en5, y nadie los reescribe antes del gancho.
            fun castIdx(reg: Int, type: String) = ins.indices.filter { i ->
                val ref = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
                ins[i].opcode == Opcode.CHECK_CAST && ref != null && ref.type == type &&
                    (ins[i] as OneRegisterInstruction).registerA == reg && i < at
            }
            val c5 = castIdx(5, "Landroidx/media3/exoplayer/ExoPlayer;")
            val c9 = castIdx(9, "Len5;")
            if (c5.isEmpty() || c9.isEmpty()) error("xi6.h: v5 no es ExoPlayer o v9 no es en5")
            fun rewritten(reg: Int, from: Int): Boolean = (from + 1 until at).any { i ->
                val x = ins[i] as? OneRegisterInstruction ?: return@any false
                (x.opcode.setsRegister() && x.registerA == reg) ||
                    (x.opcode.setsWideRegister() && (x.registerA == reg || x.registerA + 1 == reg))
            }
            if (rewritten(5, c5.last())) error("xi6.h: v5 se reescribe antes del gancho")
            if (rewritten(9, c9.last())) error("xi6.h: v9 se reescribe antes del gancho")

            h.addInstructions(
                at + 2,
                """
                    invoke-static {v5, v9, p0, v$readyReg}, Lapp/eclipse/extension/canvas/CanvasSync;->gate(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/String;Z)Z
                    move-result v$readyReg
                """
            )
        }
    }
}
