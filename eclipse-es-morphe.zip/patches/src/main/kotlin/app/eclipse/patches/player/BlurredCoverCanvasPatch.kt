package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Reemplaza al parche \"Custom: Canvas en el fondo borroso\" (ese solo funciona con la opcion blurCopy).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // eg6.g(Object, Object, Object): lambda de contenido del reproductor Custom. Llama a
        // di6.c(sv0, Z, Song, ki1, I) (dibuja el fondo). Justo despues se agrega el video, porque aqui si
        // se tiene ow0 (di6.c solo recibe la cancion).
        val eg6 = mutableClassDefBy(classDefBy("Leg6;"))
        val method = eg6.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro eg6.g (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("eg6.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Ldi6;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } ==
                listOf("Lsv0;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lki1;", "I")
        } ?: error("eg6.g: no se encontro di6.c(sv0, Z, Song, ki1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val bgReg = call.registerC          // sv0
        val composerReg = call.registerF    // ki1 (el composer)

        // ow0: el objeto del que se saca la cancion justo antes de la llamada (iget-object vX, vOw0, Low0;->a).
        val songGet = (callIdx - 1 downTo maxOf(0, callIdx - 12)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Low0;" && ref.name == "a"
        } ?: error("eg6.g: no se encontro ow0.a antes de di6.c")
        val stateReg = (list[songGet] as TwoRegisterInstruction).registerB

        for (r in listOf(bgReg, stateReg, composerReg)) {
            if (r > 15) error("eg6.g: registro v$r fuera de rango para invoke-static")
        }
        if (bgReg == stateReg || bgReg == composerReg || stateReg == composerReg) error("eg6.g: registros repetidos")

        method.addInstructions(
            callIdx + 1,
            "invoke-static {v$bgReg, v$stateReg, v$composerReg}, " +
                "$HELPER->draw(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V"
        )
    }
}
