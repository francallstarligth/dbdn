package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Si el layout tiene la portada nitida pegada arriba con fundido (edgeFade), el video se dibuja como reflejo " +
        "(volteado) justo debajo de la portada; en los demas layouts queda a pantalla completa, sin voltear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val dimOption by stringOption(
        key = "dim",
        default = "25",
        title = "Oscurecimiento (0 a 100)",
        description = "Cuanto se oscurece el fondo detras de los textos y botones. 0 = nada, 100 = negro total. " +
            "Por defecto 25. Escribe solo el numero."
    )

    execute {
        // Solo digitos, entre 0 y 100 (se pasa a smali como numero).
        val dimPercent = (dimOption ?: "25").filter { it in '0'..'9' }.take(3).toIntOrNull()?.coerceIn(0, 100) ?: 25
        // eg6.g(Object, Object, Object): lambda de contenido del reproductor Custom. Llama a
        // di6.c(sv0, Z, Song, ki1, I) (dibuja el fondo). Justo despues se agrega el video, porque aqui si
        // se tiene ow0 (di6.c solo recibe la cancion).
        val eg6 = mutableClassDefBy(classDefBy("Leg6;"))
        val method = eg6.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro eg6.g (version de Eclipse distinta de 0.6.47?)")

        val list = (method.implementation ?: error("eg6.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Ldi6;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } ==
                listOf("Lsv0;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lki1;", "I")
        } ?: error("eg6.g: no se encontro di6.c(sv0, Z, Song, ki1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val bgReg = call.registerC          // sv0
        val composerReg = call.registerF    // ki1 (el composer)

        // ow0: el objeto del que se saca la cancion justo antes de la llamada (iget-object vX, vOw0, Low0;->a).
        val songGet = (callIdx - 1 downTo maxOf(0, callIdx - 12)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Low0;" && ref.name == "a"
        } ?: error("eg6.g: no se encontro ow0.a antes de di6.c")
        val stateReg = (list[songGet] as TwoRegisterInstruction).registerB

        // ib6 (el layout): el objeto de donde se saca el fondo (iget-object vX, vThis, Leg6;->q:Lib6;).
        val layoutGet = (callIdx - 1 downTo maxOf(0, callIdx - 40)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Leg6;" && ref.name == "q" &&
                ref.type == "Lib6;"
        } ?: error("eg6.g: no se encontro eg6.q (ib6) antes de di6.c")
        val layoutReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Alto disponible en dp: el ultimo ko0.b() antes de la llamada y su move-result.
        val heightCall = (callIdx - 1 downTo maxOf(0, callIdx - 80)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lko0;" && ref.name == "b" && ref.returnType == "F" &&
                list[i + 1].opcode == Opcode.MOVE_RESULT
        } ?: error("eg6.g: no se encontro ko0.b() antes de di6.c")
        val heightReg = (list[heightCall + 1] as OneRegisterInstruction).registerA
        // Que nadie reescriba ese registro entre su move-result y la llamada.
        for (i in heightCall + 2 until callIdx) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == heightReg) ||
                (ins.opcode.setsWideRegister() && (a == heightReg || a + 1 == heightReg))
            if (hit) error("eg6.g: v$heightReg se reescribe antes de di6.c")
        }

        // Registro de pasaje: el de Song (3er argumento de di6.c), que se pisa justo despues de la llamada.
        val scratchReg = call.registerE
        val after = list.getOrNull(callIdx + 1)
        val afterRef = (after as? ReferenceInstruction)?.reference as? FieldReference
        if (after == null || after.opcode != Opcode.SGET_OBJECT || (after as OneRegisterInstruction).registerA != scratchReg ||
            afterRef == null || afterRef.definingClass != "Ljh5;"
        ) error("eg6.g: tras di6.c se esperaba sget-object v$scratchReg, Ljh5;->q")

        for (r in listOf(bgReg, stateReg, composerReg, layoutReg, scratchReg)) {
            if (r > 15) error("eg6.g: registro v$r fuera de rango para invoke-static")
        }
        if (setOf(bgReg, stateReg, composerReg, layoutReg, scratchReg).size != 5) error("eg6.g: registros repetidos")

        method.addInstructions(
            callIdx + 1,
            """
                const/16 v$scratchReg, $dimPercent
                invoke-static {v$scratchReg}, $HELPER->setDim(I)V
                move/from16 v$scratchReg, v$heightReg
                invoke-static {v$bgReg, v$stateReg, v$composerReg, v$layoutReg, v$scratchReg}, $HELPER->draw(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
            """
        )
    }
}
