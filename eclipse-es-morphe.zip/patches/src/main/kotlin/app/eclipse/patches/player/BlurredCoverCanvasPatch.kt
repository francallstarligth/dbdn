package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Si el layout tiene la portada nitida pegada arriba con fundido (edgeFade), el video se dibuja como reflejo " +
        "(volteado) justo debajo de la portada; en los demas layouts queda a pantalla completa, sin voltear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val dimOption by stringOption(
        key = "dim",
        default = "25",
        title = "Oscurecimiento (0 a 100)",
        description = "Cuanto se oscurece el fondo detras de los textos y botones. 0 = nada, 100 = negro total. " +
            "Por defecto 25. Escribe solo el numero."
    )

    execute {
        // Solo digitos, entre 0 y 100 (se pasa a smali como numero).
        val dimPercent = (dimOption ?: "25").filter { it in '0'..'9' }.take(3).toIntOrNull()?.coerceIn(0, 100) ?: 25
        // k97.g(Object, Object, Object): lambda de contenido del reproductor Custom. Llama a
        // ja7.c(y11, Z, Song, cq1, I) (dibuja el fondo). Justo despues se agrega el video, porque aqui si
        // se tiene u21 (ja7.c solo recibe la cancion).
        val k97 = mutableClassDefBy(classDefBy("Lk97;"))
        val method = k97.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro k97.g (version de Eclipse distinta de 0.6.61?)")

        val list = (method.implementation ?: error("k97.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lja7;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } ==
                listOf("Lu21;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lzq1;", "I")
        } ?: error("k97.g: no se encontro ja7.c(y11, Z, Song, cq1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val bgReg = call.registerC          // y11
        val composerReg = call.registerF    // cq1 (el composer)

        // u21: el objeto del que se saca la cancion justo antes de la llamada (iget-object vX, vOw0, Lq31;->a).
        val songGet = (callIdx - 1 downTo maxOf(0, callIdx - 12)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lq31;" && ref.name == "a"
        } ?: error("k97.g: no se encontro u21.a antes de ja7.c")
        val stateReg = (list[songGet] as TwoRegisterInstruction).registerB

        // d37 (el layout): el objeto de donde se saca el fondo (iget-object vX, vThis, Lk97;->q:Lx37;).
        val layoutGet = (callIdx - 1 downTo maxOf(0, callIdx - 40)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lk97;" && ref.name == "q" &&
                ref.type == "Lx37;"
        } ?: error("k97.g: no se encontro k97.q (d37) antes de ja7.c")
        val layoutReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Alto disponible en dp: el ultimo ju0.b() antes de la llamada y su move-result.
        val heightCall = (callIdx - 1 downTo maxOf(0, callIdx - 80)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Liv0;" && ref.name == "b" && ref.returnType == "F" &&
                list[i + 1].opcode == Opcode.MOVE_RESULT
        } ?: error("k97.g: no se encontro ju0.b() antes de ja7.c")
        val heightReg = (list[heightCall + 1] as OneRegisterInstruction).registerA
        // Que nadie reescriba ese registro entre su move-result y la llamada.
        for (i in heightCall + 2 until callIdx) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == heightReg) ||
                (ins.opcode.setsWideRegister() && (a == heightReg || a + 1 == heightReg))
            if (hit) error("k97.g: v$heightReg se reescribe antes de ja7.c")
        }

        // Registro de pasaje: el de Song (3er argumento de ja7.c), que se pisa justo despues de la llamada.
        val scratchReg = call.registerE
        val after = list.getOrNull(callIdx + 1)
        val afterRef = (after as? ReferenceInstruction)?.reference as? FieldReference
        if (after == null || after.opcode != Opcode.SGET_OBJECT || (after as OneRegisterInstruction).registerA != scratchReg ||
            afterRef == null || afterRef.definingClass != "Lev5;"
        ) error("k97.g: tras ja7.c se esperaba sget-object v$scratchReg, Lev5;->q")

        for (r in listOf(bgReg, stateReg, composerReg, layoutReg, scratchReg)) {
            if (r > 15) error("k97.g: registro v$r fuera de rango para invoke-static")
        }
        if (setOf(bgReg, stateReg, composerReg, layoutReg, scratchReg).size != 5) error("k97.g: registros repetidos")

        method.addInstructions(
            callIdx + 1,
            """
                const/16 v$scratchReg, $dimPercent
                invoke-static {v$scratchReg}, $HELPER->setDim(I)V
                move/from16 v$scratchReg, v$heightReg
                invoke-static {v$bgReg, v$stateReg, v$composerReg, v$layoutReg, v$scratchReg}, $HELPER->draw(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
            """
        )
    }
}
