package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Si el layout tiene la portada nitida pegada arriba con fundido (edgeFade), el video se dibuja como reflejo " +
        "(volteado) justo debajo de la portada; en los demas layouts queda a pantalla completa, sin voltear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val dimOption by stringOption(
        key = "dim",
        default = "25",
        title = "Oscurecimiento (0 a 100)",
        description = "Cuanto se oscurece el fondo detras de los textos y botones. 0 = nada, 100 = negro total. " +
            "Por defecto 25. Escribe solo el numero."
    )

    execute {
        // Solo digitos, entre 0 y 100 (se pasa a smali como numero).
        val dimPercent = (dimOption ?: "25").filter { it in '0'..'9' }.take(3).toIntOrNull()?.coerceIn(0, 100) ?: 25
        // Eclipse 0.6.70 (v0.20.247): ya no hay una sola lambda con la llamada de dibujo y el alto. La llamada
        // mq7.c(t41, Z, Song, nt1, I) esta ahora en fp7.r (dentro de un Box), y justo despues se abre un
        // BoxWithConstraints cuyo contenido es mp7.g(Object, Object, Object) (antes k97.g): ahi se calcula el alto
        // disponible (ex0.b()). El gancho va al inicio de ese contenido, despues de ex0.b(), y pasa el propio objeto
        // lambda (v0), el composer y el alto; la extension saca de el el layout (wj7) y el estado (p51) por tipo.
        val mp7 = mutableClassDefBy(classDefBy("Lmp7;"))
        val method = mp7.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro mp7.g (version de Eclipse distinta de 0.6.70?)")

        val list = (method.implementation ?: error("mp7.g sin codigo")).instructions.toList()

        // El layout: iget-object vT, vThis, Lmp7;->q:Lwj7;  (vT se sobrescribe en esa misma instruccion: es libre antes)
        val layoutGet = list.indices.firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lmp7;" && ref.name == "q" &&
                ref.type == "Lwj7;"
        } ?: error("mp7.g: no se encontro mp7.q (wj7)")
        val selfReg = (list[layoutGet] as TwoRegisterInstruction).registerB
        val tmpReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Alto disponible en dp: el ultimo ex0.b() antes del layout y su move-result.
        val heightCall = (layoutGet - 1 downTo maxOf(0, layoutGet - 30)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Lex0;" && ref.name == "b" && ref.returnType == "F" &&
                list[i + 1].opcode == Opcode.MOVE_RESULT
        } ?: error("mp7.g: no se encontro ex0.b() antes de mp7.q")
        val heightReg = (list[heightCall + 1] as OneRegisterInstruction).registerA
        if (heightCall + 1 >= layoutGet) error("mp7.g: el move-result del alto no esta antes del layout")
        // Que nadie reescriba ese registro entre su move-result y el punto de insercion.
        for (i in heightCall + 2 until layoutGet) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == heightReg) ||
                (ins.opcode.setsWideRegister() && (a == heightReg || a + 1 == heightReg))
            if (hit) error("mp7.g: v$heightReg se reescribe antes de mp7.q")
        }

        // El composer (nt1): el receptor del primer Ltt1;->d0(I)V despues del layout. Debe ser el registro del
        // parametro (se asigna una sola vez al inicio): no se puede haber escrito entre el inicio y el layout, salvo
        // las primeras instrucciones.
        val d0 = (layoutGet until list.size).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Ltt1;" &&
                ref.name == "d0" && ref.parameterTypes.map { it.toString() } == listOf("I")
        } ?: error("mp7.g: no se encontro tt1.d0(I) despues de mp7.q")
        val composerReg = (list[d0] as FiveRegisterInstruction).registerC
        for (i in 12 until layoutGet) {
            val ins = list[i]
            if (ins.opcode == Opcode.CHECK_CAST) continue // solo cambia el tipo del mismo objeto
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == composerReg) ||
                (ins.opcode.setsWideRegister() && (a == composerReg || a + 1 == composerReg))
            if (hit) error("mp7.g: v$composerReg (composer) se reescribe antes de mp7.q")
        }
        // Y el registro de pasaje no puede leerse en la instruccion del layout ni valer algo vivo: se sobrescribe ahi.
        if ((list[layoutGet] as TwoRegisterInstruction).registerB == tmpReg) error("mp7.g: v$tmpReg es tambien el this")

        for (r in listOf(selfReg, tmpReg, composerReg)) {
            if (r > 15) error("mp7.g: registro v$r fuera de rango para invoke-static")
        }
        if (setOf(selfReg, tmpReg, composerReg).size != 3) error("mp7.g: registros repetidos")

        method.addInstructions(
            layoutGet,
            """
                const/16 v$tmpReg, $dimPercent
                invoke-static {v$tmpReg}, $HELPER->setDim(I)V
                move/from16 v$tmpReg, v$heightReg
                invoke-static {v$selfReg, v$composerReg, v$tmpReg}, $HELPER->drawPlayer(Ljava/lang/Object;Ljava/lang/Object;F)V
            """
        )
    }
}
