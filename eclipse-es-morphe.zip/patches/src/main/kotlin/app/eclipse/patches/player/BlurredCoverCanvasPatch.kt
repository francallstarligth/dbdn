package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

@Suppress("unused")
val blurredCoverCanvasPatch = bytecodePatch(
    name = "Custom: Canvas detras del fondo Blurred Cover",
    description = "En el reproductor Custom con fondo \"Blurred Cover\" (tipo de fondo, no capa), si la cancion tiene " +
        "portada animada (Canvas), la reproduce (sin sonido, en bucle) borrosa detras, como en el Eclipse oficial. " +
        "Si el layout tiene la portada nitida pegada arriba con fundido (edgeFade), el video se dibuja como reflejo " +
        "(volteado) justo debajo de la portada; en los demas layouts queda a pantalla completa, sin voltear.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val dimOption by stringOption(
        key = "dim",
        default = "25",
        title = "Oscurecimiento (0 a 100)",
        description = "Cuanto se oscurece el fondo detras de los textos y botones. 0 = nada, 100 = negro total. " +
            "Por defecto 25. Escribe solo el numero."
    )

    execute {
        // Solo digitos, entre 0 y 100 (se pasa a smali como numero).
        val dimPercent = (dimOption ?: "25").filter { it in '0'..'9' }.take(3).toIntOrNull()?.coerceIn(0, 100) ?: 25
        // n77.g(Object, Object, Object): lambda de contenido del reproductor Custom. Llama a
        // j87.c(i11, Z, Song, fp1, I) (dibuja el fondo). Justo despues se agrega el video, porque aqui si
        // se tiene e21 (j87.c solo recibe la cancion).
        val n77 = mutableClassDefBy(classDefBy("Ln77;"))
        val method = n77.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro n77.g (version de Eclipse distinta de 0.6.55?)")

        val list = (method.implementation ?: error("n77.g sin codigo")).instructions.toList()
        val callIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            list[i].opcode == Opcode.INVOKE_STATIC && ref != null && ref.definingClass == "Lj87;" && ref.name == "c" &&
                ref.parameterTypes.map { it.toString() } ==
                listOf("Li11;", "Z", "Lcom/eclipse/android/data/models/Song;", "Lfp1;", "I")
        } ?: error("n77.g: no se encontro j87.c(i11, Z, Song, fp1, I)")
        val call = list[callIdx] as FiveRegisterInstruction
        val bgReg = call.registerC          // i11
        val composerReg = call.registerF    // fp1 (el composer)

        // e21: el objeto del que se saca la cancion justo antes de la llamada (iget-object vX, vOw0, Le21;->a).
        val songGet = (callIdx - 1 downTo maxOf(0, callIdx - 12)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Le21;" && ref.name == "a"
        } ?: error("n77.g: no se encontro e21.a antes de j87.c")
        val stateReg = (list[songGet] as TwoRegisterInstruction).registerB

        // w17 (el layout): el objeto de donde se saca el fondo (iget-object vX, vThis, Ln77;->q:Lw17;).
        val layoutGet = (callIdx - 1 downTo maxOf(0, callIdx - 40)).firstOrNull { i ->
            val ins = list[i]
            val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Ln77;" && ref.name == "q" &&
                ref.type == "Lw17;"
        } ?: error("n77.g: no se encontro n77.q (w17) antes de j87.c")
        val layoutReg = (list[layoutGet] as TwoRegisterInstruction).registerA

        // Alto disponible en dp: el ultimo tt0.b() antes de la llamada y su move-result.
        val heightCall = (callIdx - 1 downTo maxOf(0, callIdx - 80)).firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
            ref != null && ref.definingClass == "Ltt0;" && ref.name == "b" && ref.returnType == "F" &&
                list[i + 1].opcode == Opcode.MOVE_RESULT
        } ?: error("n77.g: no se encontro tt0.b() antes de j87.c")
        val heightReg = (list[heightCall + 1] as OneRegisterInstruction).registerA
        // Que nadie reescriba ese registro entre su move-result y la llamada.
        for (i in heightCall + 2 until callIdx) {
            val ins = list[i]
            val a = (ins as? OneRegisterInstruction)?.registerA ?: continue
            val hit = (ins.opcode.setsRegister() && a == heightReg) ||
                (ins.opcode.setsWideRegister() && (a == heightReg || a + 1 == heightReg))
            if (hit) error("n77.g: v$heightReg se reescribe antes de j87.c")
        }

        // Registro de pasaje: el de Song (3er argumento de j87.c), que se pisa justo despues de la llamada.
        val scratchReg = call.registerE
        val after = list.getOrNull(callIdx + 1)
        val afterRef = (after as? ReferenceInstruction)?.reference as? FieldReference
        if (after == null || after.opcode != Opcode.SGET_OBJECT || (after as OneRegisterInstruction).registerA != scratchReg ||
            afterRef == null || afterRef.definingClass != "Lht5;"
        ) error("n77.g: tras j87.c se esperaba sget-object v$scratchReg, Lht5;->q")

        for (r in listOf(bgReg, stateReg, composerReg, layoutReg, scratchReg)) {
            if (r > 15) error("n77.g: registro v$r fuera de rango para invoke-static")
        }
        if (setOf(bgReg, stateReg, composerReg, layoutReg, scratchReg).size != 5) error("n77.g: registros repetidos")

        method.addInstructions(
            callIdx + 1,
            """
                const/16 v$scratchReg, $dimPercent
                invoke-static {v$scratchReg}, $HELPER->setDim(I)V
                move/from16 v$scratchReg, v$heightReg
                invoke-static {v$bgReg, v$stateReg, v$composerReg, v$layoutReg, v$scratchReg}, $HELPER->draw(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;F)V
            """
        )
    }
}
