package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val DIAG = "Lapp/eclipse/extension/umbra/UmbraDiag;"

/**
 * v0.20.390 (DIAGNOSTICO, SIN COMPILAR NI PROBAR, Eclipse 0.6.75): al inicio de `Lcc4;->f(JSONObject)Ltb4;` (parser estatico
 * de la playlist que devuelve el servidor; lo llaman el chat `intent/chat`, `intent/playlist` y `playlists/{id}/regenerate`)
 * se llama UmbraDiag.copiar(json), que copia el JSON crudo (personal, provider, model, plan, tracks con "strategy") al portapapeles.
 */
@Suppress("unused")
val umbraDiagPatch = bytecodePatch(
    name = "Umbra: copiar datos de la playlist (diagnostico)",
    description = "Cuando Umbra o \"AI Playlist\" arman una playlist, copia al portapapeles lo que respondio el servidor " +
        "(si es personalizada, modelo, plan y como eligio cada cancion). No muestra nada. Pegalo en una nota o chat para verlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cc4 = mutableClassDefBy(classDefBy("Lcc4;"))
        val f = cc4.methods.singleOrNull {
            it.name == "f" && it.returnType == "Ltb4;" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Lorg/json/JSONObject;")
        } ?: error("No se encontro cc4.f(JSONObject) (Eclipse 0.6.75)")
        // static: p0 = JSONObject (puede ser > v15, por eso /range)
        f.addInstructions(0, "invoke-static/range {p0 .. p0}, $DIAG->copiar(Ljava/lang/Object;)V")
    }
}
