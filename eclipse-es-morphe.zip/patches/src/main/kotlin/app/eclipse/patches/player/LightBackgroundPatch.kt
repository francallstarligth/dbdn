package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.140 (SIN COMPILAR NI PROBAR). Une los 3 parches "liviano" (reflejo con Canvas, reflejo sin Canvas, fondo de Letras y
 * Cola). Los tres dependian de blurredCoverCanvasPatch; ahora esa dependencia la tiene este parche.
 */
@Suppress("unused")
val lightBackgroundPatch = bytecodePatch(
    name = "Fondo liviano",
    description = "El fondo borroso y el reflejo se hacen con una copia chica y se estiran: se ve casi igual y el telefono " +
        "trabaja menos. Tres casillas: reflejo con Canvas, reflejo sin Canvas y fondo de Letras y Cola.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(blurredCoverCanvasPatch)

    extendWith("extensions/extension.mpe")

    val canvas by booleanOption(
        key = "canvas",
        default = true,
        title = "Reflejo liviano con Canvas",
        description = "El reflejo borroso del video del Canvas se hace en una caja chica y se estira. Si el video se ve corrido o cortado, apagalo."
    )

    val reflection by booleanOption(
        key = "reflection",
        default = true,
        title = "Reflejo liviano sin Canvas",
        description = "El reflejo de las portadas sin Canvas se hace con una copia chica de la portada."
    )

    val pane by booleanOption(
        key = "pane",
        default = true,
        title = "Fondo liviano de Letras y Cola",
        description = "El fondo borroso de Letras y Cola se hace con una copia chica de la portada."
    )

    execute {
        if (canvas == true) lightCanvasPatch.execute(this)
        if (reflection == true) lightReflectionPatch.execute(this)
        if (pane == true) lightPanePatch.execute(this)
    }
}
