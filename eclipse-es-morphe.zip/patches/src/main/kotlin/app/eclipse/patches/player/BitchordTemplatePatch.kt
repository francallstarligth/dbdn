package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"

private const val PREVIEW_NAME = "player_preview_bitchord"

/**
 * Agrega la foto de vista previa de la tarjeta Bitchord como recurso nuevo (drawable-nodpi, igual que las
 * demas player_preview_*). Se busca por nombre en tiempo de ejecucion (BitchordTemplate.previewId).
 * La imagen vive en patches/src/main/resources/eclipse/bitchord_preview.jpg (720 px de ancho).
 */
@Suppress("unused")
val bitchordPreviewResourcePatch = resourcePatch(
    name = "Bitchord: imagen de vista previa",
    description = "Recurso con la vista previa de la tarjeta Bitchord. Lo usa \"Reproductor integrado: Bitchord\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val bytes = object {}.javaClass.getResourceAsStream("/eclipse/bitchord_preview.jpg")?.use { it.readBytes() }
            ?: error("Recurso no encontrado en el parche: /eclipse/bitchord_preview.jpg")
        val out = get("res/drawable-nodpi/$PREVIEW_NAME.jpg")
        out.parentFile?.mkdirs()
        out.writeBytes(bytes)
    }
}

@Suppress("unused")
val bitchordTemplatePatch = bytecodePatch(
    name = "Reproductor integrado: Bitchord",
    description = "Agrega la tarjeta \"Bitchord\" (portada a pantalla completa, estilo Apple Music) a la lista " +
        "de Reproductores integrados. Se puede elegir y queda guardada como Bitchord; se dibuja con el motor de Custom.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordPreviewResourcePatch)

    extendWith("extensions/extension.mpe")

    execute {
        // Indice (en la lista de instrucciones) del SPUT_OBJECT de un campo estatico de la clase dada.
        fun sputIndex(method: com.android.tools.smali.dexlib2.iface.Method, cls: String, field: String): Int {
            val list = (method.implementation ?: error("$cls sin codigo")).instructions.toList()
            val i = list.indexOfFirst { ins ->
                if (ins.opcode != Opcode.SPUT_OBJECT) return@indexOfFirst false
                val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@indexOfFirst false
                ref.definingClass == cls && ref.name == field
            }
            if (i < 0) error("No se encontro el sput de $cls.$field")
            return i
        }

        // 1) fl6 = enum de los Reproductores integrados (ECLIPSE..CUSTOM, ordinal 0..6).
        //    En <clinit>, justo antes de guardar $VALUES (v0 = array de 7), se copia a un array de 8 y se agrega
        //    BITCHORD (ordinal 7). $ENTRIES se arma despues a partir de $VALUES, asi que la lista lo incluye.
        //    Constructor: (nombre, ordinal, displayName, description, iconName).
        val fl6 = mutableClassDefBy(classDefBy("Lsc7;"))
        val flClinit = fl6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro fl6.<clinit>")
        flClinit.addInstructions(
            sputIndex(flClinit, "Lsc7;", "\$VALUES"),
            """
                array-length v1, v0
                add-int/lit8 v2, v1, 1
                new-array v2, v2, [Lsc7;
                const/4 v3, 0
                invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
                new-instance v3, Lsc7;
                const-string v4, "BITCHORD"
                move v5, v1
                const-string v6, "Bitchord"
                const-string v7, "Portada a pantalla completa, estilo Apple Music"
                const-string v8, "Expand"
                invoke-direct/range {v3 .. v8}, Lsc7;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
                aput-object v3, v2, v1
                move-object v0, v2
            """
        )

        // 2) fl6.getServerKey(): sin esto, BITCHORD cae en la rama por defecto del `when` y falla.
        //    (p0 = v1, v0 libre.)
        val serverKey = fl6.methods.firstOrNull { it.name == "getServerKey" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro fl6.getServerKey")
        serverKey.addInstructionsWithLabels(
            0,
            """
                invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I
                move-result v0
                add-int/lit8 v0, v0, -7
                if-nez v0, :otro
                const-string v0, "bitchord"
                return-object v0
                :otro
                nop
            """
        )

        // 3) hl6.a (ordinal -> numero de caso) decide que imagen de vista previa dibuja cada tarjeta (i92.o).
        //    BITCHORD (ordinal 7) usa el caso 3 = la vista previa de "Apple Music v2" (prestada).
        val hl6 = mutableClassDefBy(classDefBy("Lrc7;"))
        val hlClinit = hl6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro hl6.<clinit>")
        hlClinit.addInstructions(
            sputIndex(hlClinit, "Lrc7;", "a"),
            """
                const/4 v1, 7
                const/4 v2, 3
                aput v2, v0, v1
            """
        )

        // 3b) uc7.a es el mismo mapa (ordinal -> caso) pero lo lee qw1.k, la funcion que dibuja cada tarjeta de
        //     Player layout (en 57 hay dos mapas iguales: rc7 lo leen getIcon/getServerKey y uc7 lo lee qw1.k).
        //     Sin esto BITCHORD cae en la rama por defecto de qw1.k (gx0.b -> excepcion tl1) y la pantalla crashea.
        //     Igual que arriba: BITCHORD (ordinal 7) usa el caso 3 = "Apple Music v2" (prestado).
        val uc7 = mutableClassDefBy(classDefBy("Luc7;"))
        val ucClinit = uc7.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro uc7.<clinit>")
        ucClinit.addInstructions(
            sputIndex(ucClinit, "Luc7;", "a"),
            """
                const/4 v1, 7
                const/4 v2, 3
                aput v2, v0, v1
            """
        )

        // 4) dl6.b(fl6, Context, Z) es donde termina el clic de una tarjeta (a7.a -> dl6.b) y tambien donde se guarda
        //    la seleccion (player_style = nombre del enum). Si es BITCHORD: se busca un diseno del usuario llamado
        //    "Bitchord" (o se crea con sj6.c, igual que al elegir una plantilla de Custom) y se activa con sj6.p;
        //    luego sigue el codigo original con BITCHORD, que lo guarda y lo marca como seleccionado.
        //    Si ya hay sj6.g() disenos y ninguno es Bitchord, no se cambia nada (return).
        //    Registros: p0=v5, p1=v6, p2=v7 (Context), p3=v8; libres v0..v4.
        val dl6 = mutableClassDefBy(classDefBy("Lqc7;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lsc7;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructionsWithLabels(
            0,
            """
                invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I
                move-result v0
                add-int/lit8 v0, v0, -7
                if-nez v0, :done
                sget-object v0, Leb7;->t:Lxn6;
                invoke-virtual {v0, p2}, Lxn6;->j(Landroid/content/Context;)Leb7;
                move-result-object v0
                iget-object v1, v0, Leb7;->d:Lcq9;
                invoke-virtual {v1}, Lcq9;->getValue()Ljava/lang/Object;
                move-result-object v1
                invoke-static {v1}, $EXT->existingId(Ljava/lang/Object;)Ljava/lang/String;
                move-result-object v2
                if-nez v2, :activate
                check-cast v1, Ljava/util/List;
                invoke-interface {v1}, Ljava/util/List;->size()I
                move-result v1
                invoke-virtual {v0}, Leb7;->g()I
                move-result v3
                if-ge v1, v3, :abort
                invoke-static {}, $EXT->jsonCard()Lorg/json/JSONObject;
                move-result-object v1
                invoke-static {v1}, Ls77;->a(Lorg/json/JSONObject;)Ld37;
                move-result-object v1
                const/4 v3, 0
                invoke-virtual {v0, v1, v3}, Leb7;->c(Ld37;Ljava/lang/String;)Ld37;
                move-result-object v1
                iget-object v2, v1, Ld37;->a:Ljava/lang/String;
                :activate
                invoke-virtual {v0, v2}, Leb7;->p(Ljava/lang/String;)V
                goto :done
                :abort
                return-void
                :done
                nop
            """
        )

        // 5) Los lectores de la seleccion que deciden como dibujar el reproductor comparan contra CUSTOM:
        //    a43.u (lo usa a43.c, el layout del reproductor) y n.c (2 lecturas). Justo despues de leer el valor
        //    se pasa por BitchordTemplate.norm: BITCHORD -> CUSTOM (el diseno activo ya es Bitchord). El resto
        //    de lectores (lista de tarjetas i92.j, nombres en ajustes) siguen viendo BITCHORD real.
        fun normalizeReads(classDesc: String, methodName: String) {
            val cls = mutableClassDefBy(classDefBy(classDesc))
            val m = cls.methods.firstOrNull { it.name == methodName }
                ?: error("No se encontro $classDesc.$methodName")
            val ins = (m.implementation ?: error("$classDesc.$methodName sin codigo")).instructions.toList()
            val sites = mutableListOf<Pair<Int, Int>>()
            for (i in 2 until ins.size) {
                val cc = ins[i]
                if (cc.opcode != Opcode.CHECK_CAST) continue
                val type = ((cc as ReferenceInstruction).reference as? TypeReference)?.type
                if (type != "Lsc7;") continue
                val mv = ins[i - 1]
                if (mv.opcode != Opcode.MOVE_RESULT_OBJECT) continue
                val inv = ins[i - 2]
                val ref = (inv as? ReferenceInstruction)?.reference as? MethodReference ?: continue
                if (ref.name != "getValue") continue
                val reg = (cc as OneRegisterInstruction).registerA
                if ((mv as OneRegisterInstruction).registerA != reg) continue
                sites += i to reg
            }
            if (sites.isEmpty()) error("$classDesc.$methodName: no se encontro la lectura de la seleccion")
            // De atras hacia adelante para que los indices no se muevan.
            for ((i, reg) in sites.asReversed()) {
                m.addInstructions(
                    i,
                    """
                        invoke-static/range {v$reg .. v$reg}, $EXT->norm(Ljava/lang/Object;)Ljava/lang/Object;
                        move-result-object v$reg
                    """
                )
            }
        }
        // 5b) uq2.g (antes n.c): en 0.6.55 la seleccion ya no se lee con getValue + check-cast sino con
        //     jb7.a(Context) -> lb7 (move-result-object). Se normaliza justo DESPUES de cada move-result-object
        //     (2 sitios en uq2.g), de atras hacia adelante. norm(null) devuelve null.
        fun normalizeCtxReads(classDesc: String, methodName: String) {
            val cls = mutableClassDefBy(classDefBy(classDesc))
            val m = cls.methods.firstOrNull { it.name == methodName && it.parameterTypes.size == 3 }
                ?: error("No se encontro $classDesc.$methodName")
            val ins = (m.implementation ?: error("$classDesc.$methodName sin codigo")).instructions.toList()
            val sites = mutableListOf<Pair<Int, Int>>()
            for (i in 0 until ins.size - 1) {
                val inv = ins[i]
                if (inv.opcode != Opcode.INVOKE_VIRTUAL && inv.opcode != Opcode.INVOKE_VIRTUAL_RANGE) continue
                val ref = (inv as ReferenceInstruction).reference as? MethodReference ?: continue
                if (ref.definingClass != "Lqc7;" || ref.name != "a" || ref.returnType != "Lsc7;") continue
                if (ref.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
                val mv = ins[i + 1]
                if (mv.opcode != Opcode.MOVE_RESULT_OBJECT) continue
                sites += (i + 2) to (mv as OneRegisterInstruction).registerA
            }
            if (sites.size != 2) error("$classDesc.$methodName: se esperaban 2 lecturas de la seleccion y hay ${sites.size}")
            for ((i, reg) in sites.asReversed()) {
                m.addInstructions(
                    i,
                    """
                        invoke-static/range {v$reg .. v$reg}, $EXT->norm(Ljava/lang/Object;)Ljava/lang/Object;
                        move-result-object v$reg
                    """
                )
            }
        }
        normalizeReads("Ldv1;", "F")
        normalizeCtxReads("Lur2;", "g")

        // 6) Vista previa propia. i92.o(fl6, Z, J, d43, ki1, I) dibuja cada tarjeta; la imagen sale de
        //    `u92.L(ki1, id)` (painterResource). Al entrar a i92.o se anota que tarjeta es (p0) y justo antes de
        //    painterResource el id pasa por BitchordTemplate.previewId: si la tarjeta es BITCHORD devuelve el id del
        //    recurso player_preview_bitchord (si no existe, deja el id original = vista previa de Apple Music v2).
        val i92 = mutableClassDefBy(classDefBy("Lqw1;"))
        val card = i92.methods.firstOrNull {
            it.name == "k" && it.parameterTypes.firstOrNull()?.toString() == "Lsc7;"
        } ?: error("No se encontro i92.o(fl6, ...)")
        val cardIns = (card.implementation ?: error("i92.o sin codigo")).instructions.toList()
        val paint = cardIns.indexOfFirst { ins ->
            if (ins.opcode != Opcode.INVOKE_STATIC) return@indexOfFirst false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@indexOfFirst false
            ref.definingClass == "Lax1;" && ref.name == "L" &&
                ref.parameterTypes.map { it.toString() } == listOf("Lcq1;", "I")
        }
        if (paint < 0) error("i92.o: no se encontro u92.L (painterResource)")
        val idReg = (cardIns[paint] as FiveRegisterInstruction).registerD
        // Primero el indice mas alto para no mover el otro.
        card.addInstructions(
            paint,
            """
                invoke-static {v$idReg}, $EXT->previewId(I)I
                move-result v$idReg
            """
        )
        card.addInstructions(0, "invoke-static/range {p0 .. p0}, $EXT->card(Ljava/lang/Object;)V")

        // 7) Orden de las tarjetas. kd.invoke arma la lista (ArrayList sin CUSTOM) a partir de fl6.getEntries();
        //    antes de crear el u91 que la usa (new-instance u91) se llama BitchordTemplate.reorder(lista), que
        //    mueve BITCHORD a la posicion elegida (BitchordTemplate.CARD_POSITION). Es la misma lista para el
        //    dibujo y el clic, asi que todo queda consistente.
        val kd = mutableClassDefBy(classDefBy("Lie;"))
        val kdInvoke = kd.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.size == 1 }
            ?: error("No se encontro kd.invoke")
        val kdIns = (kdInvoke.implementation ?: error("kd.invoke sin codigo")).instructions.toList()
        val entries = kdIns.indexOfFirst { ins ->
            if (ins.opcode != Opcode.INVOKE_STATIC) return@indexOfFirst false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@indexOfFirst false
            ref.definingClass == "Lsc7;" && ref.name == "getEntries"
        }
        if (entries < 0) error("kd.invoke: no se encontro fl6.getEntries")
        val listInit = (entries until kdIns.size).first { i ->
            val ins = kdIns[i]
            if (ins.opcode != Opcode.INVOKE_DIRECT) return@first false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@first false
            ref.definingClass == "Ljava/util/ArrayList;" && ref.name == "<init>" && ref.parameterTypes.isEmpty()
        }
        val listReg = (kdIns[listInit] as FiveRegisterInstruction).registerC
        val u91New = (listInit until kdIns.size).first { i ->
            val ins = kdIns[i]
            if (ins.opcode != Opcode.NEW_INSTANCE) return@first false
            ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Lfb;"
        }
        kdInvoke.addInstructions(
            u91New,
            "invoke-static/range {v$listReg .. v$listReg}, $EXT->reorder(Ljava/util/List;)V"
        )

        // 8) Menu "New Player" (plantillas de Custom). vj6.b es la lista de plantillas (uj6 = id, nombre,
        //    descripcion, constructor d43); al elegir una, c1.a llama uj6.d.a() -> ib6, la copia con sj6.c, la activa
        //    y pone el estilo CUSTOM. Se agrega "Bitchord" en la 2.a posicion (despues de Blank Canvas) con un
        //    constructor jh6(99); jh6.a() atiende el caso 99 antes de su switch devolviendo bg6.a(BitchordTemplate.json()).
        val vj6 = mutableClassDefBy(classDefBy("Lhb7;"))
        val vjClinit = vj6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro vj6.<clinit>")
        vjClinit.addInstructions(
            sputIndex(vjClinit, "Lhb7;", "b"),
            """
                new-instance v1, Ljava/util/ArrayList;
                invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
                new-instance v2, Lgb7;
                new-instance v3, Lvh6;
                const/16 v4, 99
                invoke-direct {v3, v4}, Lvh6;-><init>(I)V
                const-string v4, "bitchord"
                const-string v5, "Bitchord"
                const-string v6, "Full-bleed cover, Apple Music style"
                invoke-direct {v2, v4, v5, v6, v3}, Lgb7;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lhe3;)V
                const/4 v3, 1
                invoke-virtual {v1, v3, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
                move-object v0, v1
            """
        )
        val jh6 = mutableClassDefBy(classDefBy("Lvh6;"))
        val jhBuild = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        // OJO: jh6.a tiene 72 registros (p0 = v71) y `iget` solo acepta v0..v15; por eso se inserta en el indice 1,
        // justo despues de su primera instruccion (move-object/from16 v0, p0), y se usa v0 como `this`.
        jhBuild.addInstructionsWithLabels(
            1,
            """
                iget v1, v0, Lvh6;->q:I
                const/16 v2, 99
                if-ne v1, v2, :orig
                invoke-static {}, $EXT->json()Lorg/json/JSONObject;
                move-result-object v1
                invoke-static {v1}, Ls77;->a(Lorg/json/JSONObject;)Ld37;
                move-result-object v1
                return-object v1
                :orig
                nop
            """
        )

        // 9) Ocultar el diseno interno de la tarjeta ("Bitchord (integrado)") de "Your Custom Players". La lista se lee
        //    en kd.invoke: despues de `new-instance yx4` hay `getValue` + `check-cast List` (registro = lista de ib6) y
        //    de ahi salen size/items. Se reemplaza por BitchordTemplate.visible(lista) (copia sin el diseno interno).
        // Se vuelve a leer la lista de instrucciones (el paso 7 ya inserto codigo en este mismo metodo).
        val kdIns2 = (kdInvoke.implementation ?: error("kd.invoke sin codigo")).instructions.toList()
        val yx4New = kdIns2.indexOfFirst { ins ->
            ins.opcode == Opcode.NEW_INSTANCE && ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Lka5;"
        }
        if (yx4New < 0) error("kd.invoke: no se encontro new-instance yx4")
        val listCast = (yx4New until kdIns2.size).first { i ->
            val ins = kdIns2[i]
            ins.opcode == Opcode.CHECK_CAST && ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
        }
        val designsReg = (kdIns2[listCast] as OneRegisterInstruction).registerA
        kdInvoke.addInstructions(
            listCast + 1,
            """
                invoke-static/range {v$designsReg .. v$designsReg}, $EXT->visible(Ljava/util/List;)Ljava/util/List;
                move-result-object v$designsReg
            """
        )

        // 10) Pantalla "Custom Players" (Manage Custom Players): lo mismo en dos lugares.
        //     (a) un5.invoke: `zk8.getValue` + `check-cast List` = la lista de tarjetas (size/items salen de ahi).
        //     (b) e1.g (caso del titulo): `getValue` + `check-cast List` justo antes del texto "PLAYERS (" (el contador).
        fun filterNextListCast(classDesc: String, methodName: String, anchor: (List<com.android.tools.smali.dexlib2.iface.instruction.Instruction>) -> Int) {
            val cls = mutableClassDefBy(classDefBy(classDesc))
            val m = cls.methods.firstOrNull { it.name == methodName && it.parameterTypes.size <= 3 }
                ?: error("No se encontro $classDesc.$methodName")
            val ins = (m.implementation ?: error("$classDesc.$methodName sin codigo")).instructions.toList()
            val from = anchor(ins)
            val castIdx = (from until ins.size).first { i ->
                val x = ins[i]
                x.opcode == Opcode.CHECK_CAST && ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
            }
            val reg = (ins[castIdx] as OneRegisterInstruction).registerA
            m.addInstructions(
                castIdx + 1,
                """
                    invoke-static/range {v$reg .. v$reg}, $EXT->visible(Ljava/util/List;)Ljava/util/List;
                    move-result-object v$reg
                """
            )
        }
        filterNextListCast("Lh16;", "invoke") { 0 }
        filterNextListCast("Ln1;", "g") { ins ->
            val str = ins.indexOfFirst { x ->
                x.opcode == Opcode.CONST_STRING &&
                    ((x as ReferenceInstruction).reference as? com.android.tools.smali.dexlib2.iface.reference.StringReference)?.string == "PLAYERS ("
            }
            if (str < 0) error("e1.g: no se encontro el texto PLAYERS (")
            // el check-cast de la lista esta unas instrucciones ANTES del const-string: se busca hacia atras
            (str downTo 0).first { i ->
                val x = ins[i]
                x.opcode == Opcode.CHECK_CAST && ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
            }
        }

        // 11) sr8.b(Map) (antes zx7.b): recibe los ajustes de la cuenta; si trae "playerStyle" distinto llama
        //     jb7.c(estilo, ctx, false) y cambia el estilo local. Si el servidor devuelve otro valor que "bitchord",
        //     la seleccion se pierde. En 0.6.54/0.6.55 la forma es: const-string "playerStyle"; invoke-static sr8.d(String,Map);
        //     move-result-object vS (valor del servidor); ...; iget-object vC, this, Lyt8;->a (Context); if-eqz vS.
        //     Gancho: justo DESPUES de ese iget-object del Context: vS = BitchordTemplate.serverStyle(vC, vS)
        //     (si el estilo local es BITCHORD devuelve null y el codigo original lo trata como "no vino").
        val sr8 = mutableClassDefBy(classDefBy("Lyt8;"))
        val pull = sr8.methods.firstOrNull {
            it.name == "b" && it.parameterTypes.size == 1 && it.parameterTypes[0].toString() == "Ljava/util/Map;"
        } ?: error("No se encontro sr8.b(Map)")
        val pIns = (pull.implementation ?: error("sr8.b sin codigo")).instructions.toList()
        val psIdx = pIns.indexOfFirst { x ->
            x.opcode == Opcode.CONST_STRING &&
                ((x as ReferenceInstruction).reference as? com.android.tools.smali.dexlib2.iface.reference.StringReference)?.string == "playerStyle"
        }
        if (psIdx < 0) error("sr8.b: no se encontro \"playerStyle\"")
        if (pIns[psIdx + 1].opcode != Opcode.INVOKE_STATIC || pIns[psIdx + 2].opcode != Opcode.MOVE_RESULT_OBJECT) {
            error("sr8.b: estructura inesperada despues de \"playerStyle\"")
        }
        val styleReg = (pIns[psIdx + 2] as OneRegisterInstruction).registerA
        val ctxGet = (psIdx + 3 until pIns.size).first { i ->
            val x = pIns[i]
            if (x.opcode != Opcode.IGET_OBJECT) return@first false
            val ref = (x as ReferenceInstruction).reference as? FieldReference ?: return@first false
            ref.definingClass == "Lyt8;" && ref.name == "a" && ref.type == "Landroid/content/Context;"
        }
        val ctxReg = (pIns[ctxGet] as TwoRegisterInstruction).registerA
        if (styleReg > 15 || ctxReg > 15 || ctxReg == styleReg) {
            error("sr8.b: registros fuera de rango (estilo v$styleReg, contexto v$ctxReg)")
        }
        pull.addInstructions(
            ctxGet + 1,
            """
                invoke-static {v$ctxReg, v$styleReg}, $EXT->serverStyle(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
                move-result-object v$styleReg
            """
        )
    }
}
