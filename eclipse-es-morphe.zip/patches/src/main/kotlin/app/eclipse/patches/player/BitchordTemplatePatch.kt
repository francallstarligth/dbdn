package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"

private const val PREVIEW_NAME = "player_preview_bitchord"

/**
 * Agrega la foto de vista previa de la tarjeta Bitchord como recurso nuevo (drawable-nodpi, igual que las
 * demas player_preview_*). Se busca por nombre en tiempo de ejecucion (BitchordTemplate.previewId).
 * La imagen vive en patches/src/main/resources/eclipse/bitchord_preview.jpg (720 px de ancho).
 */
@Suppress("unused")
val bitchordPreviewResourcePatch = resourcePatch(
    name = "Bitchord: imagen de vista previa",
    description = "Recurso con la vista previa de la tarjeta Bitchord. Lo usa \"Reproductor integrado: Bitchord\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val bytes = object {}.javaClass.getResourceAsStream("/eclipse/bitchord_preview.jpg")?.use { it.readBytes() }
            ?: error("Recurso no encontrado en el parche: /eclipse/bitchord_preview.jpg")
        val out = get("res/drawable-nodpi/$PREVIEW_NAME.jpg")
        out.parentFile?.mkdirs()
        out.writeBytes(bytes)
    }
}

@Suppress("unused")
val bitchordTemplatePatch = bytecodePatch(
    name = "Reproductor integrado: Bitchord",
    description = "Agrega la tarjeta \"Bitchord\" (portada a pantalla completa, estilo Apple Music) a la lista " +
        "de Reproductores integrados. Se puede elegir y queda guardada como Bitchord; se dibuja con el motor de Custom.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordPreviewResourcePatch)

    extendWith("extensions/extension.mpe")

    execute {
        // Indice (en la lista de instrucciones) del SPUT_OBJECT de un campo estatico de la clase dada.
        fun sputIndex(method: com.android.tools.smali.dexlib2.iface.Method, cls: String, field: String): Int {
            val list = (method.implementation ?: error("$cls sin codigo")).instructions.toList()
            val i = list.indexOfFirst { ins ->
                if (ins.opcode != Opcode.SPUT_OBJECT) return@indexOfFirst false
                val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return@indexOfFirst false
                ref.definingClass == cls && ref.name == field
            }
            if (i < 0) error("No se encontro el sput de $cls.$field")
            return i
        }

        // 1) fl6 = enum de los Reproductores integrados (ECLIPSE..CUSTOM, ordinal 0..6).
        //    En <clinit>, justo antes de guardar $VALUES (v0 = array de 7), se copia a un array de 8 y se agrega
        //    BITCHORD (ordinal 7). $ENTRIES se arma despues a partir de $VALUES, asi que la lista lo incluye.
        //    Constructor: (nombre, ordinal, displayName, description, iconName).
        val fl6 = mutableClassDefBy(classDefBy("Lfl6;"))
        val flClinit = fl6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro fl6.<clinit>")
        flClinit.addInstructions(
            sputIndex(flClinit, "Lfl6;", "\$VALUES"),
            """
                array-length v1, v0
                add-int/lit8 v2, v1, 1
                new-array v2, v2, [Lfl6;
                const/4 v3, 0
                invoke-static {v0, v3, v2, v3, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V
                new-instance v3, Lfl6;
                const-string v4, "BITCHORD"
                move v5, v1
                const-string v6, "Bitchord"
                const-string v7, "Portada a pantalla completa, estilo Apple Music"
                const-string v8, "Expand"
                invoke-direct/range {v3 .. v8}, Lfl6;-><init>(Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
                aput-object v3, v2, v1
                move-object v0, v2
            """
        )

        // 2) fl6.getServerKey(): sin esto, BITCHORD cae en la rama por defecto del `when` y falla.
        //    (p0 = v1, v0 libre.)
        val serverKey = fl6.methods.firstOrNull { it.name == "getServerKey" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro fl6.getServerKey")
        serverKey.addInstructionsWithLabels(
            0,
            """
                invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I
                move-result v0
                add-int/lit8 v0, v0, -7
                if-nez v0, :otro
                const-string v0, "bitchord"
                return-object v0
                :otro
                nop
            """
        )

        // 3) hl6.a (ordinal -> numero de caso) decide que imagen de vista previa dibuja cada tarjeta (i92.o).
        //    BITCHORD (ordinal 7) usa el caso 3 = la vista previa de "Apple Music v2" (prestada).
        val hl6 = mutableClassDefBy(classDefBy("Lhl6;"))
        val hlClinit = hl6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro hl6.<clinit>")
        hlClinit.addInstructions(
            sputIndex(hlClinit, "Lhl6;", "a"),
            """
                const/4 v1, 7
                const/4 v2, 3
                aput v2, v0, v1
            """
        )

        // 4) dl6.b(fl6, Context, Z) es donde termina el clic de una tarjeta (a7.a -> dl6.b) y tambien donde se guarda
        //    la seleccion (player_style = nombre del enum). Si es BITCHORD: se busca un diseno del usuario llamado
        //    "Bitchord" (o se crea con sj6.c, igual que al elegir una plantilla de Custom) y se activa con sj6.p;
        //    luego sigue el codigo original con BITCHORD, que lo guarda y lo marca como seleccionado.
        //    Si ya hay sj6.g() disenos y ninguno es Bitchord, no se cambia nada (return).
        //    Registros: p0=v5, p1=v6, p2=v7 (Context), p3=v8; libres v0..v4.
        val dl6 = mutableClassDefBy(classDefBy("Ldl6;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "b" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lfl6;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructionsWithLabels(
            0,
            """
                invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I
                move-result v0
                add-int/lit8 v0, v0, -7
                if-nez v0, :done
                sget-object v0, Lsj6;->t:Lg96;
                invoke-virtual {v0, p2}, Lg96;->i(Landroid/content/Context;)Lsj6;
                move-result-object v0
                iget-object v1, v0, Lsj6;->d:Ldl8;
                invoke-virtual {v1}, Ldl8;->getValue()Ljava/lang/Object;
                move-result-object v1
                invoke-static {v1}, $EXT->existingId(Ljava/lang/Object;)Ljava/lang/String;
                move-result-object v2
                if-nez v2, :activate
                check-cast v1, Ljava/util/List;
                invoke-interface {v1}, Ljava/util/List;->size()I
                move-result v1
                invoke-virtual {v0}, Lsj6;->g()I
                move-result v3
                if-ge v1, v3, :abort
                invoke-static {}, $EXT->jsonCard()Lorg/json/JSONObject;
                move-result-object v1
                invoke-static {v1}, Lbg6;->a(Lorg/json/JSONObject;)Lib6;
                move-result-object v1
                const/4 v3, 0
                invoke-virtual {v0, v1, v3}, Lsj6;->c(Lib6;Ljava/lang/String;)Lib6;
                move-result-object v1
                iget-object v2, v1, Lib6;->a:Ljava/lang/String;
                :activate
                invoke-virtual {v0, v2}, Lsj6;->p(Ljava/lang/String;)V
                goto :done
                :abort
                return-void
                :done
                nop
            """
        )

        // 5) Los lectores de la seleccion que deciden como dibujar el reproductor comparan contra CUSTOM:
        //    a43.u (lo usa a43.c, el layout del reproductor) y n.c (2 lecturas). Justo despues de leer el valor
        //    se pasa por BitchordTemplate.norm: BITCHORD -> CUSTOM (el diseno activo ya es Bitchord). El resto
        //    de lectores (lista de tarjetas i92.j, nombres en ajustes) siguen viendo BITCHORD real.
        fun normalizeReads(classDesc: String, methodName: String) {
            val cls = mutableClassDefBy(classDefBy(classDesc))
            val m = cls.methods.firstOrNull { it.name == methodName }
                ?: error("No se encontro $classDesc.$methodName")
            val ins = (m.implementation ?: error("$classDesc.$methodName sin codigo")).instructions.toList()
            val sites = mutableListOf<Pair<Int, Int>>()
            for (i in 2 until ins.size) {
                val cc = ins[i]
                if (cc.opcode != Opcode.CHECK_CAST) continue
                val type = ((cc as ReferenceInstruction).reference as? TypeReference)?.type
                if (type != "Lfl6;") continue
                val mv = ins[i - 1]
                if (mv.opcode != Opcode.MOVE_RESULT_OBJECT) continue
                val inv = ins[i - 2]
                val ref = (inv as? ReferenceInstruction)?.reference as? MethodReference ?: continue
                if (ref.name != "getValue") continue
                val reg = (cc as OneRegisterInstruction).registerA
                if ((mv as OneRegisterInstruction).registerA != reg) continue
                sites += i to reg
            }
            if (sites.isEmpty()) error("$classDesc.$methodName: no se encontro la lectura de la seleccion")
            // De atras hacia adelante para que los indices no se muevan.
            for ((i, reg) in sites.asReversed()) {
                m.addInstructions(
                    i,
                    """
                        invoke-static/range {v$reg .. v$reg}, $EXT->norm(Ljava/lang/Object;)Ljava/lang/Object;
                        move-result-object v$reg
                    """
                )
            }
        }
        normalizeReads("La43;", "u")
        normalizeReads("Ln;", "c")

        // 6) Vista previa propia. i92.o(fl6, Z, J, d43, ki1, I) dibuja cada tarjeta; la imagen sale de
        //    `u92.L(ki1, id)` (painterResource). Al entrar a i92.o se anota que tarjeta es (p0) y justo antes de
        //    painterResource el id pasa por BitchordTemplate.previewId: si la tarjeta es BITCHORD devuelve el id del
        //    recurso player_preview_bitchord (si no existe, deja el id original = vista previa de Apple Music v2).
        val i92 = mutableClassDefBy(classDefBy("Li92;"))
        val card = i92.methods.firstOrNull {
            it.name == "o" && it.parameterTypes.firstOrNull()?.toString() == "Lfl6;"
        } ?: error("No se encontro i92.o(fl6, ...)")
        val cardIns = (card.implementation ?: error("i92.o sin codigo")).instructions.toList()
        val paint = cardIns.indexOfFirst { ins ->
            if (ins.opcode != Opcode.INVOKE_STATIC) return@indexOfFirst false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@indexOfFirst false
            ref.definingClass == "Lu92;" && ref.name == "L" &&
                ref.parameterTypes.map { it.toString() } == listOf("Lki1;", "I")
        }
        if (paint < 0) error("i92.o: no se encontro u92.L (painterResource)")
        val idReg = (cardIns[paint] as FiveRegisterInstruction).registerD
        // Primero el indice mas alto para no mover el otro.
        card.addInstructions(
            paint,
            """
                invoke-static {v$idReg}, $EXT->previewId(I)I
                move-result v$idReg
            """
        )
        card.addInstructions(0, "invoke-static/range {p0 .. p0}, $EXT->card(Ljava/lang/Object;)V")

        // 7) Orden de las tarjetas. kd.invoke arma la lista (ArrayList sin CUSTOM) a partir de fl6.getEntries();
        //    antes de crear el u91 que la usa (new-instance u91) se llama BitchordTemplate.reorder(lista), que
        //    mueve BITCHORD a la posicion elegida (BitchordTemplate.CARD_POSITION). Es la misma lista para el
        //    dibujo y el clic, asi que todo queda consistente.
        val kd = mutableClassDefBy(classDefBy("Lkd;"))
        val kdInvoke = kd.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.size == 1 }
            ?: error("No se encontro kd.invoke")
        val kdIns = (kdInvoke.implementation ?: error("kd.invoke sin codigo")).instructions.toList()
        val entries = kdIns.indexOfFirst { ins ->
            if (ins.opcode != Opcode.INVOKE_STATIC) return@indexOfFirst false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@indexOfFirst false
            ref.definingClass == "Lfl6;" && ref.name == "getEntries"
        }
        if (entries < 0) error("kd.invoke: no se encontro fl6.getEntries")
        val listInit = (entries until kdIns.size).first { i ->
            val ins = kdIns[i]
            if (ins.opcode != Opcode.INVOKE_DIRECT) return@first false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@first false
            ref.definingClass == "Ljava/util/ArrayList;" && ref.name == "<init>" && ref.parameterTypes.isEmpty()
        }
        val listReg = (kdIns[listInit] as FiveRegisterInstruction).registerC
        val u91New = (listInit until kdIns.size).first { i ->
            val ins = kdIns[i]
            if (ins.opcode != Opcode.NEW_INSTANCE) return@first false
            ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Lu91;"
        }
        kdInvoke.addInstructions(
            u91New,
            "invoke-static/range {v$listReg .. v$listReg}, $EXT->reorder(Ljava/util/List;)V"
        )

        // 8) Menu "New Player" (plantillas de Custom). vj6.b es la lista de plantillas (uj6 = id, nombre,
        //    descripcion, constructor d43); al elegir una, c1.a llama uj6.d.a() -> ib6, la copia con sj6.c, la activa
        //    y pone el estilo CUSTOM. Se agrega "Bitchord" en la 2.a posicion (despues de Blank Canvas) con un
        //    constructor jh6(99); jh6.a() atiende el caso 99 antes de su switch devolviendo bg6.a(BitchordTemplate.json()).
        val vj6 = mutableClassDefBy(classDefBy("Lvj6;"))
        val vjClinit = vj6.methods.firstOrNull { it.name == "<clinit>" } ?: error("No se encontro vj6.<clinit>")
        vjClinit.addInstructions(
            sputIndex(vjClinit, "Lvj6;", "b"),
            """
                new-instance v1, Ljava/util/ArrayList;
                invoke-direct {v1, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
                new-instance v2, Luj6;
                new-instance v3, Ljh6;
                const/16 v4, 99
                invoke-direct {v3, v4}, Ljh6;-><init>(I)V
                const-string v4, "bitchord"
                const-string v5, "Bitchord"
                const-string v6, "Full-bleed cover, Apple Music style"
                invoke-direct {v2, v4, v5, v6, v3}, Luj6;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ld43;)V
                const/4 v3, 1
                invoke-virtual {v1, v3, v2}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V
                move-object v0, v1
            """
        )
        val jh6 = mutableClassDefBy(classDefBy("Ljh6;"))
        val jhBuild = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        jhBuild.addInstructionsWithLabels(
            0,
            """
                iget v1, p0, Ljh6;->q:I
                const/16 v2, 99
                if-ne v1, v2, :orig
                invoke-static {}, $EXT->json()Lorg/json/JSONObject;
                move-result-object v1
                invoke-static {v1}, Lbg6;->a(Lorg/json/JSONObject;)Lib6;
                move-result-object v1
                return-object v1
                :orig
                nop
            """
        )

        // 9) Ocultar el diseno interno de la tarjeta ("Bitchord (integrado)") de "Your Custom Players". La lista se lee
        //    en kd.invoke: despues de `new-instance yx4` hay `getValue` + `check-cast List` (registro = lista de ib6) y
        //    de ahi salen size/items. Se reemplaza por BitchordTemplate.visible(lista) (copia sin el diseno interno).
        // Se vuelve a leer la lista de instrucciones (el paso 7 ya inserto codigo en este mismo metodo).
        val kdIns2 = (kdInvoke.implementation ?: error("kd.invoke sin codigo")).instructions.toList()
        val yx4New = kdIns2.indexOfFirst { ins ->
            ins.opcode == Opcode.NEW_INSTANCE && ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Lyx4;"
        }
        if (yx4New < 0) error("kd.invoke: no se encontro new-instance yx4")
        val listCast = (yx4New until kdIns2.size).first { i ->
            val ins = kdIns2[i]
            ins.opcode == Opcode.CHECK_CAST && ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
        }
        val designsReg = (kdIns2[listCast] as OneRegisterInstruction).registerA
        kdInvoke.addInstructions(
            listCast + 1,
            """
                invoke-static/range {v$designsReg .. v$designsReg}, $EXT->visible(Ljava/util/List;)Ljava/util/List;
                move-result-object v$designsReg
            """
        )
    }
}
