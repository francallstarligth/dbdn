package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val NAV_INSET = "Lapp/eclipse/extension/player/NavInset;"

/**
 * v0.20.421 (SIN COMPILAR EN GITHUB NI PROBAR; sin kotlinc aqui). Que el margen de abajo del reproductor grande no dependa de
 * los botones de navegacion. En Eclipse 0.6.75, `Lzs7;->f` (3 Object) arma el area segura con `zpb.l` (clase `Lpcb;`, union de
 * dos insets): `Lpcb;->c(Lrg2;)I` = margen de abajo en px; luego `Lrg2;->k0(I)F` lo pasa a dp. Aqui, justo despues de ese
 * move-result, se llama a `NavInset.fix(F)F` (>= 40 dp -> 0 dp, v0.20.422; antes 24). Si no hay exactamente 1 llamada a `Lpcb;->c`, falla.
 */
@Suppress("unused")
val bottomInsetPatch = bytecodePatch(
    name = "Reproductor: margen de abajo sin botones",
    description = "Con navegacion por botones el reproductor sube sus controles y pisan el titulo. Este parche hace que el " +
        "margen de abajo sea 0 (igual que con los botones escondidos) aunque se vean los botones. Va aparte del que esconde los botones.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lzs7;"))
        val f = cls.methods.singleOrNull {
            it.name == "f" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes.size == 3 &&
                it.implementation?.instructions?.any { ins ->
                    (ins as? ReferenceInstruction)?.reference.let { r ->
                        r is MethodReference && r.definingClass == "Lpcb;" && r.name == "c"
                    }
                } == true
        } ?: error("Margen de abajo: no se encontro zs7.f (Eclipse 0.6.75)")

        val ins = f.implementation!!.instructions.toList()
        val calls = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            r != null && r.definingClass == "Lpcb;" && r.name == "c" && r.parameterTypes.size == 1
        }
        if (calls.size != 1) error("Margen de abajo: se esperaba 1 llamada a Lpcb.c en zs7.f y hay ${calls.size}")

        // despues de Lpcb;->c: move-result (px), invoke-interface Lrg2;->k0(I)F, move-result (dp)
        val k0 = (calls[0] + 1 until minOf(calls[0] + 6, ins.size)).filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_INTERFACE && r != null && r.definingClass == "Lrg2;" && r.name == "k0"
        }
        if (k0.size != 1) error("Margen de abajo: no se encontro Lrg2.k0 despues de Lpcb.c")
        val mr = k0[0] + 1
        if (ins[mr].opcode != Opcode.MOVE_RESULT) error("Margen de abajo: falta move-result tras Lrg2.k0")
        val reg = (ins[mr] as OneRegisterInstruction).registerA
        if (reg > 15) error("Margen de abajo: registro $reg no cabe en 4 bits")

        f.addInstructions(
            mr + 1,
            """
            invoke-static {v$reg}, $NAV_INSET->fix(F)F
            move-result v$reg
            """
        )
    }
}
