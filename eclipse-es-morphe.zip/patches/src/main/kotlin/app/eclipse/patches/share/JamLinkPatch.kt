package app.eclipse.patches.share

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val JAML = "Lapp/eclipse/extension/share/JamLink;"

/**
 * v0.20.358 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Enlace propio para jams. Dos ganchos (v356/357 enganchaban `Lu08`, que no es el camino que usa el boton de compartir):
 * (1) `Lti1.invokeSuspend`: justo despues de `const-string v2, "debridmusic://jam?id="` (v15 = codigo del jam, ya con check-cast String antes):
 *     `JamLink.jam(v15)`. (2) `Lr1.b` (el que contiene "Jam with "): tras `iget-object v0, v0, Lgd7;->q` + `check-cast v0, String` (el enlace que
 *     devolvio Lti1) se hace `v0 = JamLink.fix(v0)`, que devuelve BASE?id=JAMID&s=XXXX&n=NOMBRE&a=URLFOTO. Si algo falla devuelve el enlace original.
 */
@Suppress("unused")
val jamLinkPatch = bytecodePatch(
    name = "Enlace propio para jams",
    description = "Al compartir un jam, la app manda un enlace de tu pagina (con tu nombre y tu foto en la vista previa) " +
        "en vez de la imagen \"Join My Jam\". Necesita la pagina jamlink publicada.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- (2) consumidor: Lr1.b ----
        run {
            val cls = mutableClassDefBy(classDefBy("Lr1;"))
            val m = cls.methods.singleOrNull { mm ->
                mm.implementation?.instructions?.any {
                    it.opcode == Opcode.CONST_STRING &&
                        ((it as ReferenceInstruction).reference as? StringReference)?.string == "Jam with "
                } == true
            } ?: error("Enlace de jam: no se encontro en Lr1 el metodo con 'Jam with ' (version distinta de 0.6.75?)")
            val ins = m.implementation!!.instructions.toList()
            val cand = ins.indices.filter { i ->
                i + 1 < ins.size &&
                    ins[i].opcode == Opcode.IGET_OBJECT &&
                    ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let { it.definingClass == "Lgd7;" && it.name == "q" } == true &&
                    ins[i + 1].opcode == Opcode.CHECK_CAST &&
                    ((ins[i + 1] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            }
            if (cand.size != 1) error("Enlace de jam: se esperaba 1 'iget Lgd7.q + check-cast String' en Lr1 y hay ${cand.size}")
            val reg = (ins[cand[0] + 1] as OneRegisterInstruction).registerA
            if (reg > 15) error("Enlace de jam: registro $reg no cabe en 4 bits")
            m.addInstructions(
                cand[0] + 2,
                """
                invoke-static {v$reg}, $JAML->fix(Ljava/lang/String;)Ljava/lang/String;
                move-result-object v$reg
                """
            )
        }

        // ---- (1) origen del codigo del jam: Lti1.invokeSuspend ----
        run {
            val cls = mutableClassDefBy(classDefBy("Lti1;"))
            val m = cls.methods.singleOrNull { it.name == "invokeSuspend" && it.parameterTypes.size == 1 }
                ?: error("Enlace de jam: no se encontro Lti1.invokeSuspend")
            val ins = (m.implementation ?: error("Enlace de jam: Lti1.invokeSuspend sin codigo")).instructions.toList()
            val at = ins.indices.filter {
                ins[it].opcode == Opcode.CONST_STRING &&
                    ((ins[it] as ReferenceInstruction).reference as? StringReference)?.string == "debridmusic://jam?id="
            }
            if (at.size != 1) error("Enlace de jam: se esperaba 1 'debridmusic://jam?id=' en Lti1 y hay ${at.size}")
            val k = at[0]
            val castOk = (maxOf(0, k - 15) until k).any {
                ins[it].opcode == Opcode.CHECK_CAST && (ins[it] as OneRegisterInstruction).registerA == 15 &&
                    ((ins[it] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            }
            if (!castOk) error("Enlace de jam: no hay 'check-cast v15, String' antes de 'debridmusic://jam?id=' en Lti1 (0.6.75)")
            m.addInstructions(
                k + 1,
                """
                invoke-static {v15}, $JAML->jam(Ljava/lang/String;)V
                """
            )
        }
    }
}
