package app.eclipse.patches.share

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.stringOption
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val JAML = "Lapp/eclipse/extension/share/JamLink;"

/**
 * v0.20.356 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Enlace propio para jams.
 * `Lu08.invokeSuspend` (caso "rich share": POST /api/share/create) devuelve el enlace corto https://eclipsemusic.app/s/XXXX.
 * (1) Tras `check-cast v3, String` que sigue a `const-string "deepLink"` (v3 = deepLink, v7 = Map metadata, v6 = Lhi9 con contexto;
 *     v14 y v15 libres aqui): `JamLink.note(deepLink, meta, base)` + `JamLink.user(Lfl0)` (foto de la cuenta, por reflexion).
 * (2) En la rama de exito (`Log.d` "Rich share created" -> `move-object v5, v0` -> `goto`): `v5 = JamLink.fix(v5)`.
 * Solo cambia el enlace si el deepLink empieza con debridmusic://jam?id= ; si no, devuelve el original.
 */
@Suppress("unused")
val jamLinkPatch = bytecodePatch(
    name = "Enlace propio para jams",
    description = "Al compartir un jam, la app manda un enlace de tu pagina (con tu nombre y tu foto en la vista previa) " +
        "en vez de la imagen \"Join My Jam\". Necesita la pagina jamlink publicada.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val baseUrl by stringOption(
        key = "base_url",
        default = "https://jamlink.pages.dev/",
        title = "Direccion de la pagina",
        description = "Pagina que abre el jam. Debe terminar en /."
    )

    execute {
        val cls = mutableClassDefBy(classDefBy("Lu08;"))
        val m = cls.methods.singleOrNull { it.name == "invokeSuspend" && it.parameterTypes.size == 1 }
            ?: error("Enlace de jam: no se encontro Lu08.invokeSuspend (version de Eclipse distinta de 0.6.75?)")
        val impl = m.implementation ?: error("Enlace de jam: Lu08.invokeSuspend sin codigo")
        if (impl.registerCount < 20) error("Enlace de jam: pocos registros en Lu08.invokeSuspend")
        val ins = impl.instructions.toList()

        fun str(i: Int) = ((ins[i] as? ReferenceInstruction)?.reference as? StringReference)?.string

        // (2) rama de exito: Log.d tras "Rich share created: " seguido de `move-object v5, v0`
        val created = ins.indices.firstOrNull { str(it) == "Rich share created: " }
            ?: error("Enlace de jam: no se encontro 'Rich share created: '")
        var okAt = -1
        for (i in created until minOf(ins.size - 1, created + 80)) {
            val x = ins[i]
            if (x.opcode == Opcode.INVOKE_STATIC &&
                ((x as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Landroid/util/Log;" && it.name == "d"
                } == true
            ) {
                val n = ins[i + 1]
                if (n.opcode == Opcode.MOVE_OBJECT && (n as TwoRegisterInstruction).registerA == 5 && n.registerB == 0) {
                    okAt = i + 1; break
                }
            }
        }
        if (okAt < 0) error("Enlace de jam: no se encontro 'Log.d; move-object v5, v0' tras 'Rich share created'")
        if (ins[okAt + 1].opcode != Opcode.GOTO && ins[okAt + 1].opcode != Opcode.GOTO_16 && ins[okAt + 1].opcode != Opcode.GOTO_32)
            error("Enlace de jam: tras 'move-object v5, v0' no hay goto")

        // (1) deepLink
        val dl = ins.indices.firstOrNull { str(it) == "deepLink" }
            ?: error("Enlace de jam: no se encontro la cadena 'deepLink'")
        val cc = ins[dl + 1]
        if (cc.opcode != Opcode.CHECK_CAST || (cc as OneRegisterInstruction).registerA != 3 ||
            ((cc as ReferenceInstruction).reference as? TypeReference)?.type != "Ljava/lang/String;"
        ) error("Enlace de jam: tras 'deepLink' no viene 'check-cast v3, String' (0.6.75)")
        if (dl + 1 >= okAt) error("Enlace de jam: orden de instrucciones inesperado")

        val base = (baseUrl ?: "https://jamlink.pages.dev/").trim().replace("\"", "").ifEmpty { "https://jamlink.pages.dev/" }

        // primero el indice mas alto, para no mover el otro
        m.addInstructions(
            okAt + 1,
            """
            invoke-static {v5}, $JAML->fix(Ljava/lang/String;)Ljava/lang/String;
            move-result-object v5
            """
        )
        m.addInstructions(
            dl + 2,
            """
            const-string v14, "$base"
            invoke-static {v3, v7, v14}, $JAML->note(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V
            sget-object v14, Lfl0;->m:La1c;
            iget-object v15, v6, Lhi9;->a:Landroid/content/Context;
            invoke-virtual {v14, v15}, La1c;->o(Landroid/content/Context;)Lfl0;
            move-result-object v14
            invoke-static {v14}, $JAML->user(Ljava/lang/Object;)V
            """
        )
    }
}
