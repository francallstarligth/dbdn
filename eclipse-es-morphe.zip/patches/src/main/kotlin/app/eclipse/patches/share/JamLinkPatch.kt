package app.eclipse.patches.share

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val JAML = "Lapp/eclipse/extension/share/JamLink;"

/**
 * v0.20.360 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Parte 1 (manifiesto): MainActivity reclama https://jamlink.pages.dev (autoVerify,
 * necesita https://jamlink.pages.dev/.well-known/assetlinks.json con la huella de la firma de Morphe). Se edita el AndroidManifest.xml como texto
 * (igual que `get("res")` en otros parches): se inserta el intent-filter justo antes del `</activity>` de MainActivity.
 */
@Suppress("unused")
val jamOpenManifestPatch = resourcePatch(
    name = "Jam: manifiesto (abrir directo)",
    description = "Anade al manifiesto el enlace jamlink.pages.dev para que Android abra Eclipse directo. Lo usa el parche \"Jam: enlace propio, abrir directo y mensaje\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val mf = get("AndroidManifest.xml")
        val txt = mf.readText()
        if (txt.contains("jamlink.pages.dev")) return@execute
        val start = txt.indexOf("com.eclipse.android.MainActivity\"")
        if (start < 0) error("Abrir jam directo: no se encontro MainActivity en el manifiesto")
        val end = txt.indexOf("</activity>", start)
        if (end < 0) error("Abrir jam directo: MainActivity sin </activity>")
        val filter = "<intent-filter android:autoVerify=\"true\">" +
            "<action android:name=\"android.intent.action.VIEW\"/>" +
            "<category android:name=\"android.intent.category.DEFAULT\"/>" +
            "<category android:name=\"android.intent.category.BROWSABLE\"/>" +
            "<data android:scheme=\"https\" android:host=\"jamlink.pages.dev\"/>" +
            "</intent-filter>"
        mf.writeText(txt.substring(0, end) + filter + txt.substring(end))
    }
}

/**
 * v0.20.358 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Enlace propio para jams. Dos ganchos (v356/357 enganchaban `Lu08`, que no es el camino que usa el boton de compartir):
 * (1) `Lti1.invokeSuspend`: justo despues de `const-string v2, "debridmusic://jam?id="` (v15 = codigo del jam, ya con check-cast String antes):
 *     `JamLink.jam(v15)`. (2) `Lr1.b` (el que contiene "Jam with "): tras `iget-object v0, v0, Lgd7;->q` + `check-cast v0, String` (el enlace que
 *     devolvio Lti1) se hace `v0 = JamLink.fix(v0)`, que devuelve BASE?id=JAMID&s=XXXX&n=NOMBRE&a=URLFOTO. Si algo falla devuelve el enlace original.
 */
@Suppress("unused")
val jamLinkPatch = bytecodePatch(
    name = "Jam: enlace propio, abrir directo y mensaje",
    description = "Todo lo del jam en un solo parche, con casillas: (1) enlace propio con tu nombre y foto en la vista previa, " +
        "(2) abrir el enlace directo en Eclipse sin pasar por el navegador, (3) mensaje en espanol. " +
        "Necesita la pagina jamlink publicada (y assetlinks.json para abrir directo).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(jamOpenManifestPatch)
    extendWith("extensions/extension.mpe")

    val enlace by booleanOption(
        key = "jam_enlace",
        default = true,
        title = "Enlace propio",
        description = "Al compartir un jam (boton compartir, y en la pantalla \"Tu Jam\": Copiar enlace, Invitar amigos y el QR) manda el enlace de tu pagina (jamlink.pages.dev) en vez del de Eclipse."
    )
    val abrir by booleanOption(
        key = "jam_abrir",
        default = true,
        title = "Abrir directo en la app",
        description = "Al tocar un enlace de jamlink.pages.dev, Android abre Eclipse directo. Si lo desmarcas, el manifiesto igual queda con el enlace pero la app no lo entiende."
    )
    val mensaje by booleanOption(
        key = "jam_mensaje",
        default = true,
        title = "Mensaje en espanol",
        description = "El texto que se comparte dice \"Jam de NOMBRE · Sonando: CANCION\" y el enlace abajo, en vez del texto en ingles."
    )

    execute {
        // ---- (2) consumidor: Lr1.b ----
        if (enlace == true || mensaje == true) run {
            val cls = mutableClassDefBy(classDefBy("Lr1;"))
            val m = cls.methods.singleOrNull { mm ->
                mm.implementation?.instructions?.any {
                    it.opcode == Opcode.CONST_STRING &&
                        ((it as ReferenceInstruction).reference as? StringReference)?.string == "Jam with "
                } == true
            } ?: error("Enlace de jam: no se encontro en Lr1 el metodo con 'Jam with ' (version distinta de 0.6.75?)")
            val ins = m.implementation!!.instructions.toList()
            val cand = ins.indices.filter { i ->
                i + 1 < ins.size &&
                    ins[i].opcode == Opcode.IGET_OBJECT &&
                    ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let { it.definingClass == "Lgd7;" && it.name == "q" } == true &&
                    ins[i + 1].opcode == Opcode.CHECK_CAST &&
                    ((ins[i + 1] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            }
            if (cand.size != 1) error("Enlace de jam: se esperaba 1 'iget Lgd7.q + check-cast String' en Lr1 y hay ${cand.size}")
            val reg = (ins[cand[0] + 1] as OneRegisterInstruction).registerA
            if (reg > 15) error("Enlace de jam: registro $reg no cabe en 4 bits")
            // v0.20.361: mensaje en espanol: la llamada a Lhi9.g(url, asunto, texto) pasa a JamLink.intent(url, asunto, texto).
            // Se hace primero (replaceInstruction no desplaza indices); el gancho de enlace se inserta antes, mas arriba.
            if (mensaje == true) {
                val gs = ins.indices.filter { i ->
                    ins[i].opcode == Opcode.INVOKE_STATIC &&
                        ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                            it.definingClass == "Lhi9;" && it.name == "g" && it.parameterTypes.size == 3
                        } == true
                }
                if (gs.size != 1) error("Enlace de jam: se esperaba 1 llamada a Lhi9.g en Lr1 y hay ${gs.size}")
                val fi = ins[gs[0]] as FiveRegisterInstruction
                m.replaceInstruction(
                    gs[0],
                    "invoke-static {v${fi.registerC}, v${fi.registerD}, v${fi.registerE}}, $JAML->intent(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;"
                )
            }
            if (enlace == true) m.addInstructions(
                cand[0] + 2,
                """
                invoke-static {v$reg}, $JAML->fix(Ljava/lang/String;)Ljava/lang/String;
                move-result-object v$reg
                """
            )
        }

        // ---- (1) origen del codigo del jam: Lti1.invokeSuspend ----
        if (enlace == true) run {
            val cls = mutableClassDefBy(classDefBy("Lti1;"))
            val m = cls.methods.singleOrNull { it.name == "invokeSuspend" && it.parameterTypes.size == 1 }
                ?: error("Enlace de jam: no se encontro Lti1.invokeSuspend")
            val ins = (m.implementation ?: error("Enlace de jam: Lti1.invokeSuspend sin codigo")).instructions.toList()
            val at = ins.indices.filter {
                ins[it].opcode == Opcode.CONST_STRING &&
                    ((ins[it] as ReferenceInstruction).reference as? StringReference)?.string == "debridmusic://jam?id="
            }
            if (at.size != 1) error("Enlace de jam: se esperaba 1 'debridmusic://jam?id=' en Lti1 y hay ${at.size}")
            val k = at[0]
            val castOk = (maxOf(0, k - 15) until k).any {
                ins[it].opcode == Opcode.CHECK_CAST && (ins[it] as OneRegisterInstruction).registerA == 15 &&
                    ((ins[it] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
            }
            if (!castOk) error("Enlace de jam: no hay 'check-cast v15, String' antes de 'debridmusic://jam?id=' en Lti1 (0.6.75)")
            m.addInstructions(
                k + 1,
                """
                invoke-static {v15}, $JAML->jam(Ljava/lang/String;)V
                """
            )
        }
        // ---- (4) v0.20.425: pantalla "Tu Jam" (Iniciar un Jam del menu de la cancion): "Copiar enlace", "Invitar amigos" y el QR ----
        if (enlace == true) {
            // (4a) Ls71.invokeSuspend: tras `iget-object vA, vB, Lh22;->c` seguido de `invoke-virtual ..., Llea;->j` (guarda el enlace
            // corto en Lsf4.v): vA = JamLink.link(vA, codigoDelJam), con el codigo = `Lh22;->b` leido antes.
            run {
                val m = mutableClassDefBy(classDefBy("Ls71;")).methods.singleOrNull {
                    it.name == "invokeSuspend" && it.parameterTypes.size == 1 &&
                        it.implementation?.instructions?.any { ii ->
                            ii.opcode == Opcode.CONST_STRING &&
                                ((ii as ReferenceInstruction).reference as? StringReference)?.string == "Creating jam session..."
                        } == true
                } ?: error("Tu Jam: no se encontro Ls71.invokeSuspend con 'Creating jam session...' (version distinta de 0.6.75?)")
                val ins = m.implementation!!.instructions.toList()
                val at = ins.indices.filter { i ->
                    i + 1 < ins.size &&
                        ins[i].opcode == Opcode.IGET_OBJECT &&
                        ((ins[i] as ReferenceInstruction).reference as? FieldReference)?.let { it.definingClass == "Lh22;" && it.name == "c" } == true &&
                        ins[i + 1].opcode == Opcode.INVOKE_VIRTUAL &&
                        ((ins[i + 1] as ReferenceInstruction).reference as? MethodReference)?.let { it.definingClass == "Llea;" && it.name == "j" } == true
                }
                if (at.size != 1) error("Tu Jam: se esperaba 1 'Lh22.c + Llea.j' en Ls71 y hay ${at.size}")
                val k = at[0]
                val regUrl = (ins[k] as OneRegisterInstruction).registerA
                val idIdx = (k - 1 downTo maxOf(0, k - 40)).firstOrNull { j ->
                    ins[j].opcode == Opcode.IGET_OBJECT &&
                        ((ins[j] as ReferenceInstruction).reference as? FieldReference)?.let { it.definingClass == "Lh22;" && it.name == "b" } == true
                } ?: error("Tu Jam: no se encontro 'iget Lh22.b' (codigo del jam) antes del enlace en Ls71")
                val regId = (ins[idIdx] as OneRegisterInstruction).registerA
                if (regUrl > 15 || regId > 15 || regUrl == regId) error("Tu Jam: registros $regUrl/$regId no sirven")
                m.addInstructions(
                    k + 1,
                    """
                    invoke-static {v$regUrl, v$regId}, $JAML->link(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v$regUrl
                    """
                )
            }
            // (4b) Lpd.invokeSuspend (QR): tras `check-cast vD, String` antes de "Join my Jam" (ya es el enlace propio por 4a) -> JamLink.noteDeep(vD);
            // tras `iget-object vE, vF, Lvh9;->d` (enlace corto) -> vE = JamLink.qr(vE).
            run {
                val m = mutableClassDefBy(classDefBy("Lpd;")).methods.singleOrNull {
                    it.name == "invokeSuspend" && it.parameterTypes.size == 1 &&
                        it.implementation?.instructions?.any { ii ->
                            ii.opcode == Opcode.CONST_STRING &&
                                ((ii as ReferenceInstruction).reference as? StringReference)?.string == "Join my Jam"
                        } == true
                } ?: error("Tu Jam QR: no se encontro Lpd.invokeSuspend con 'Join my Jam'")
                val ins = m.implementation!!.instructions.toList()
                val js = ins.indices.filter {
                    ins[it].opcode == Opcode.CONST_STRING &&
                        ((ins[it] as ReferenceInstruction).reference as? StringReference)?.string == "Join my Jam"
                }
                if (js.size != 1) error("Tu Jam QR: se esperaba 1 'Join my Jam' y hay ${js.size}")
                val kj = js[0]
                val cc = (kj - 1 downTo maxOf(0, kj - 6)).firstOrNull {
                    ins[it].opcode == Opcode.CHECK_CAST &&
                        ((ins[it] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
                } ?: error("Tu Jam QR: no hay 'check-cast String' justo antes de 'Join my Jam'")
                val regDeep = (ins[cc] as OneRegisterInstruction).registerA
                val ds = ins.indices.filter {
                    it > kj && ins[it].opcode == Opcode.IGET_OBJECT &&
                        ((ins[it] as ReferenceInstruction).reference as? FieldReference)?.let { f -> f.definingClass == "Lvh9;" && f.name == "d" } == true
                }
                if (ds.size != 1) error("Tu Jam QR: se esperaba 1 'iget Lvh9.d' despues de 'Join my Jam' y hay ${ds.size}")
                val regD = (ins[ds[0]] as OneRegisterInstruction).registerA
                if (regDeep > 15 || regD > 15) error("Tu Jam QR: registros $regDeep/$regD no caben en 4 bits")
                // plan B del QR (si falla el enlace corto): `iget-object vF, vP, Lpd;->v` + `check-cast vF, String` despues del de arriba
                val fs = ins.indices.filter {
                    it > ds[0] && it + 1 < ins.size && ins[it].opcode == Opcode.IGET_OBJECT &&
                        ((ins[it] as ReferenceInstruction).reference as? FieldReference)?.let { f -> f.definingClass == "Lpd;" && f.name == "v" } == true &&
                        ins[it + 1].opcode == Opcode.CHECK_CAST &&
                        ((ins[it + 1] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/lang/String;"
                }
                if (fs.isEmpty()) error("Tu Jam QR: no se encontro el plan B (iget Lpd.v + check-cast String) despues de Lvh9.d")
                val regF = (ins[fs[0] + 1] as OneRegisterInstruction).registerA
                if (regF > 15) error("Tu Jam QR: registro $regF no cabe en 4 bits")
                // de abajo hacia arriba, para no mover los indices de los de arriba
                m.addInstructions(
                    fs[0] + 2,
                    """
                    invoke-static {v$regF}, $JAML->qrFallback(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v$regF
                    """
                )
                m.addInstructions(
                    ds[0] + 1,
                    """
                    invoke-static {v$regD}, $JAML->qr(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v$regD
                    """
                )
                m.addInstructions(
                    cc + 1,
                    """
                    invoke-static {v$regDeep}, $JAML->noteDeep(Ljava/lang/String;)V
                    """
                )
            }
        }
        // ---- (3) abrir directo: MainActivity.onCreate / onNewIntent cambian https://jamlink.pages.dev/?i=CODIGO -> debridmusic://jam?id=CODIGO ----
        if (abrir == true) run {
            val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))
            val oc = main.methods.singleOrNull {
                it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
            } ?: error("Abrir jam directo: no se encontro MainActivity.onCreate")
            oc.addInstructions(0, "invoke-static {p0}, $JAML->rewriteActivity(Landroid/app/Activity;)V")
            val ni = main.methods.singleOrNull {
                it.name == "onNewIntent" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/content/Intent;")
            } ?: error("Abrir jam directo: no se encontro MainActivity.onNewIntent")
            ni.addInstructions(0, "invoke-static {p1}, $JAML->rewrite(Landroid/content/Intent;)V")
        }
    }
}
