package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/** 4.0f (alto original de la barra, en dp) como bits de const/high16. */
private const val OLD_HEIGHT_BITS = 0x40800000

/** 10.0f en dp. */
private const val NEW_HEIGHT_HEX = "0x41200000"

@Suppress("unused")
val thickVolumeBarPatch = bytecodePatch(
    name = "Barra de volumen gruesa",
    description = "Engrosa la barra de volumen del reproductor (de 4 dp a 10 dp, extremos redondeados, estilo Apple Music) " +
        "y quita los dos altavoces chicos que Eclipse dibuja dentro de la barra, para que solo queden los iconos " +
        "que pongas como capas en el editor.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // di6.C(int, dw0, ow0, ki1, boolean): composable de la barra de volumen (caso 6 de la capa VOLUME_SLIDER).
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val method = di6.methods.firstOrNull { m ->
            m.name == "C" && m.parameterTypes.map { it.toString() } ==
                listOf("I", "Ldw0;", "Low0;", "Lki1;", "Z")
        } ?: error("No se encontro di6.C (barra de volumen)")

        val list = (method.implementation ?: error("di6.C sin codigo")).instructions.toList()

        val heightIdx = list.indices.filter { i ->
            val ins = list[i]
            ins.opcode == Opcode.CONST_HIGH16 && (ins as NarrowLiteralInstruction).narrowLiteral == OLD_HEIGHT_BITS
        }
        if (heightIdx.size != 1) error("di6.C: se esperaba 1 constante 4.0f y hay ${heightIdx.size}")

        val iconIdx = list.indices.filter { i ->
            val ins = list[i]
            if (ins.opcode != Opcode.INVOKE_STATIC_RANGE && ins.opcode != Opcode.INVOKE_STATIC) return@filter false
            val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return@filter false
            ref.definingClass == "Lim3;" && ref.name == "a" && ref.parameterTypes.size == 7
        }
        if (iconIdx.size != 2) error("di6.C: se esperaban 2 iconos (im3.a) y hay ${iconIdx.size}")

        val heightReg = (list[heightIdx[0]] as OneRegisterInstruction).registerA

        // De atras hacia adelante para que los indices no se muevan.
        val edits = (iconIdx.map { it to false } + (heightIdx[0] to true)).sortedByDescending { it.first }
        for ((idx, isHeight) in edits) {
            method.removeInstruction(idx)
            if (isHeight) {
                method.addInstructions(idx, "const/high16 v$heightReg, $NEW_HEIGHT_HEX")
            }
        }
    }
}
