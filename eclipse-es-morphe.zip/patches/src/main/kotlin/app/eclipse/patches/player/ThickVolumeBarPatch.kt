package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/** Bits de const/high16 de 4.0f y 5.0f (alto fijo original del track, en dp). */
private const val H_4 = 0x40800000
private const val H_5 = 0x40a00000

private class Target(
    val cls: String,
    val name: String,
    val params: List<String>,
    val heightBits: Int,
    val removeIcons: Boolean,
)

private val TARGETS = listOf(
    // Volumen: di6.C(I, dw0, ow0, ki1, Z) — track 4 dp + 2 iconos propios (im3.a).
    Target("Ldi6;", "C", listOf("I", "Ldw0;", "Low0;", "Lki1;", "Z"), H_4, true),
    // Progreso estilo simple: track 5 dp.
    Target("Ldi6;", "h", listOf("Ldw0;", "F", "J", "Z", "Low0;", "D", "Z", "Lt43;", "Lki1;", "I"), H_5, false),
    Target("Lxi6;", "i", listOf("Ldw0;", "F", "J", "Z", "D", "Lt43;", "Lf43;", "Lki1;", "I"), H_5, false),
)

/** Modifier.height(float) de Compose: g48.i(Modifier, F). */
private fun isHeightCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lg48;" && ref.name == "i" && ref.parameterTypes.size == 2
}

private fun isIconCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC_RANGE && ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lim3;" && ref.name == "a" && ref.parameterTypes.size == 7
}

@Suppress("unused")
val thickVolumeBarPatch = bytecodePatch(
    name = "Barras gruesas: volumen y progreso (alto = capa)",
    description = "La barra de volumen y la barra de progreso (estilo simple) ya no tienen alto fijo de 4-5 dp: " +
        "su grosor pasa a ser el alto de la capa en el editor (extremos redondeados), asi se ajusta a gusto. " +
        "Tambien quita los dos altavoces chicos que Eclipse dibuja dentro de la barra de volumen, para que solo " +
        "queden los iconos que pongas como capas. Los otros estilos de progreso no cambian.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        for (t in TARGETS) {
            val cls = mutableClassDefBy(classDefBy(t.cls))
            val method = cls.methods.firstOrNull { m ->
                m.name == t.name && m.parameterTypes.map { it.toString() } == t.params
            } ?: error("No se encontro ${t.cls}.${t.name}")

            val list = (method.implementation ?: error("${t.cls}.${t.name} sin codigo")).instructions.toList()

            val heightIdx = list.indices.filter { i ->
                val ins = list[i]
                ins.opcode == Opcode.CONST_HIGH16 &&
                    (ins as NarrowLiteralInstruction).narrowLiteral == t.heightBits &&
                    i + 1 < list.size && isHeightCall(list[i + 1])
            }
            if (heightIdx.size != 1) error("${t.cls}.${t.name}: se esperaba 1 alto fijo y hay ${heightIdx.size}")
            val ci = heightIdx[0]
            val constReg = (list[ci] as OneRegisterInstruction).registerA
            val call = list[ci + 1] as FiveRegisterInstruction
            if (call.registerCount != 2 || call.registerD != constReg) {
                error("${t.cls}.${t.name}: registros inesperados en height()")
            }
            val modReg = call.registerC

            val iconIdx = if (t.removeIcons) list.indices.filter { isIconCall(list[it]) } else emptyList()
            if (t.removeIcons && iconIdx.size != 2) {
                error("${t.cls}.${t.name}: se esperaban 2 iconos (im3.a) y hay ${iconIdx.size}")
            }

            // De atras hacia adelante para que los indices no se muevan.
            val edits = (iconIdx.map { it to false } + (ci to true)).sortedByDescending { it.first }
            for ((idx, isHeight) in edits) {
                if (!isHeight) {
                    method.removeInstruction(idx)
                } else {
                    // height(X) -> fillMaxHeight(1f): g48.c = Modifier.fillMaxHeight(fraction).
                    method.removeInstruction(idx + 1)
                    method.removeInstruction(idx)
                    method.addInstructions(
                        idx,
                        """
                            const/high16 v$constReg, 0x3f800000
                            invoke-static {v$modReg, v$constReg}, Lg48;->c(Lmh5;F)Lmh5;
                        """
                    )
                }
            }
        }
    }
}
