package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/** Fraccion del alto de la capa que ocupa el track (0.45f): con el alto minimo del editor (1) queda ~4 dp, como el original. */
private const val TRACK_FRACTION = "0x3ee66666"

/** 1.0f: el contenedor llena todo el alto de la capa. */
private const val FULL = "0x3f800000"

/** Bits de const/high16 de 4.0f, 5.0f y 40.0f (altos fijos originales, en dp). */
private const val H_4 = 0x40800000
private const val H_5 = 0x40a00000
private const val H_40 = 0x42200000

private class Target(
    val cls: String,
    val name: String,
    val params: List<String>,
    /** Alto fijo (const/high16 seguido de Modifier.height) que pasa a fillMaxHeight. */
    val heightBits: Int,
    /** Quitar las 2 llamadas a Icon (im3.a) propias de Eclipse. */
    val removeIcons: Boolean = false,
    /** Tambien cambiar `height(ha2.q)` (grosor animado 4 -> 8 dp del estilo Classic) por fillMaxHeight. */
    val animatedHeight: Boolean = false,
    /** Fraccion (hex de float) del alto disponible: FULL para contenedores, TRACK_FRACTION para el track. */
    val fraction: String = TRACK_FRACTION,
)

private val TARGETS = listOf(
    // Volumen: di6.C — track 4 dp + 2 iconos propios (im3.a).
    Target("Ldi6;", "C", listOf("I", "Ldw0;", "Low0;", "Lki1;", "Z"), H_4, removeIcons = true),
    // Progreso, vista del editor (estilo simple): track 5 dp.
    Target("Ldi6;", "h", listOf("Ldw0;", "F", "J", "Z", "Low0;", "D", "Z", "Lt43;", "Lki1;", "I"), H_5),
    Target("Lxi6;", "i", listOf("Ldw0;", "F", "J", "Z", "D", "Lt43;", "Lf43;", "Lki1;", "I"), H_5),
    // Progreso en el reproductor real: vd2.V (contenedor de 40 dp) y el estilo CLASSIC vd2.h
    // (contenedor de 40 dp + track animado 4 -> 8 dp).
    Target(
        "Lvd2;", "V",
        listOf("F", "D", "D", "J", "Z", "Z", "Ld43;", "Lf43;", "Ld43;", "Lmh5;", "Ldp7;", "Lki1;", "I", "I"),
        H_40, fraction = FULL
    ),
    Target("Lvd2;", "h", listOf("F", "I", "J", "Lki1;", "Z"), H_40, animatedHeight = true, fraction = FULL),
)

/** Modifier.height(float) de Compose: g48.i(Modifier, F). */
private fun isHeightCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lg48;" && ref.name == "i" && ref.parameterTypes.size == 2
}

private fun isIconCall(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC_RANGE && ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lim3;" && ref.name == "a" && ref.parameterTypes.size == 7
}

/** iget ... Lha2;->q:F (grosor animado). */
private fun isAnimatedHeightGet(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.IGET) return false
    val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return false
    return ref.definingClass == "Lha2;" && ref.name == "q" && ref.type == "F"
}

private enum class Kind { REMOVE, CONST_AND_CALL, CALL_ONLY }

@Suppress("unused")
val thickVolumeBarPatch = bytecodePatch(
    name = "Barras gruesas: volumen y progreso (alto = capa)",
    description = "La barra de volumen y la de progreso (estilo Classic y la vista del editor) ya no tienen alto fijo: " +
        "su grosor pasa a ser el alto de la capa en el editor (extremos redondeados), asi se ajusta a gusto. " +
        "Tambien quita los dos altavoces chicos que Eclipse dibuja dentro de la barra de volumen, para que solo " +
        "queden los iconos que pongas como capas. Los otros estilos de progreso no cambian.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        for (t in TARGETS) {
            val label = "${t.cls}.${t.name}"
            val cls = mutableClassDefBy(classDefBy(t.cls))
            val method = cls.methods.firstOrNull { m ->
                m.name == t.name && m.parameterTypes.map { it.toString() } == t.params
            } ?: error("No se encontro $label")

            val list = (method.implementation ?: error("$label sin codigo")).instructions.toList()

            val heightIdx = list.indices.filter { i ->
                val ins = list[i]
                ins.opcode == Opcode.CONST_HIGH16 &&
                    (ins as NarrowLiteralInstruction).narrowLiteral == t.heightBits &&
                    i + 1 < list.size && isHeightCall(list[i + 1])
            }
            if (heightIdx.size != 1) error("$label: se esperaba 1 alto fijo y hay ${heightIdx.size}")

            val iconIdx = if (t.removeIcons) list.indices.filter { isIconCall(list[it]) } else emptyList()
            if (t.removeIcons && iconIdx.size != 2) {
                error("$label: se esperaban 2 iconos (im3.a) y hay ${iconIdx.size}")
            }

            val animIdx = if (t.animatedHeight) list.indices.filter { i ->
                isAnimatedHeightGet(list[i]) && i + 1 < list.size && isHeightCall(list[i + 1])
            } else emptyList()
            if (t.animatedHeight && animIdx.size != 1) {
                error("$label: se esperaba 1 grosor animado (ha2.q) y hay ${animIdx.size}")
            }

            // Cada edicion: (indice, tipo). De atras hacia adelante para que los indices no se muevan.
            val edits = buildList {
                iconIdx.forEach { add(it to Kind.REMOVE) }
                add(heightIdx[0] to Kind.CONST_AND_CALL)
                animIdx.forEach { add((it + 1) to Kind.CALL_ONLY) }
            }.sortedByDescending { it.first }

            for ((idx, kind) in edits) {
                when (kind) {
                    Kind.REMOVE -> method.removeInstruction(idx)
                    Kind.CONST_AND_CALL -> {
                        val constReg = (list[idx] as OneRegisterInstruction).registerA
                        val call = list[idx + 1] as FiveRegisterInstruction
                        if (call.registerCount != 2 || call.registerD != constReg) {
                            error("$label: registros inesperados en height()")
                        }
                        val modReg = call.registerC
                        // height(X dp) -> fillMaxHeight(1f): g48.c = Modifier.fillMaxHeight(fraction).
                        method.removeInstruction(idx + 1)
                        method.removeInstruction(idx)
                        method.addInstructions(
                            idx,
                            """
                                const v$constReg, ${t.fraction}
                                invoke-static {v$modReg, v$constReg}, Lg48;->c(Lmh5;F)Lmh5;
                            """
                        )
                    }
                    Kind.CALL_ONLY -> {
                        // Solo la llamada height(v) con v = grosor animado: se reemplaza por 1.0f + fillMaxHeight.
                        val call = list[idx] as FiveRegisterInstruction
                        if (call.registerCount != 2) error("$label: registros inesperados en height(animado)")
                        val modReg = call.registerC
                        val floatReg = call.registerD
                        method.removeInstruction(idx)
                        method.addInstructions(
                            idx,
                            """
                                const v$floatReg, $TRACK_FRACTION
                                invoke-static {v$modReg, v$floatReg}, Lg48;->c(Lmh5;F)Lmh5;
                            """
                        )
                    }
                }
            }
        }
    }
}
