package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val AWAKE = "Lapp/eclipse/extension/player/KeepAwake;"

/** v0.20.272 (0.6.73, SIN COMPILAR NI PROBAR): qt7 -> wu7 (e() identico, pone el flujo `a` en true).
 *
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.61: `qt7.e()` (estatico, sin parametros) es "abrir el reproductor" (pone `md7.a` en true); `md7.a()` y
 * `md7.b()` ponen todas las banderas en false. Gancho unico: al inicio de `qt7.e()` se llama KeepAwake.start(), que
 * arranca un reloj que lee `md7.a` y pone/quita FLAG_KEEP_SCREEN_ON. Si no se encuentra qt7.e, el parche falla.
 */
@Suppress("unused")
val keepScreenOnPatch = bytecodePatch(
    name = "Reproductor: pantalla siempre encendida",
    description = "Mientras el reproductor grande (con las letras) esta abierto, la pantalla no se apaga sola. " +
        "Al cerrarlo, vuelve a apagarse como siempre.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val md7 = mutableClassDefBy(classDefBy("Lwu7;"))
        val f = md7.methods.singleOrNull {
            it.name == "e" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro wu7.e (Eclipse 0.6.73)")
        f.addInstructions(0, "invoke-static {}, $AWAKE->start()V")
    }
}
