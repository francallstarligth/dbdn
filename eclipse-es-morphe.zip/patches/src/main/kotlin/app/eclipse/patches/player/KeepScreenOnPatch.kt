package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val AWAKE = "Lapp/eclipse/extension/player/KeepAwake;"

/**
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.57: `oc7.f()` (estatico, sin parametros) es "abrir el reproductor" (pone `oc7.a` en true); `oc7.a()` y
 * `oc7.b()` ponen todas las banderas en false. Gancho unico: al inicio de `oc7.f()` se llama KeepAwake.start(), que
 * arranca un reloj que lee `oc7.a` y pone/quita FLAG_KEEP_SCREEN_ON. Si no se encuentra oc7.f, el parche falla.
 */
@Suppress("unused")
val keepScreenOnPatch = bytecodePatch(
    name = "Reproductor: pantalla siempre encendida",
    description = "Mientras el reproductor grande (con las letras) esta abierto, la pantalla no se apaga sola. " +
        "Al cerrarlo, vuelve a apagarse como siempre.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val oc7 = mutableClassDefBy(classDefBy("Loc7;"))
        val f = oc7.methods.singleOrNull {
            it.name == "f" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro oc7.f (Eclipse 0.6.57)")
        f.addInstructions(0, "invoke-static {}, $AWAKE->start()V")
    }
}
