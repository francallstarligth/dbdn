package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val POP_GLOW = "Lapp/eclipse/extension/player/LyricsPop;"

/**
 * v0.20.99 (SIN COMPILAR / SIN PROBAR). Interruptor del brillo suave de "Letras: silaba por silaba" (mismo estilo que
 * LyricsSyllablesPatch): al empezar lw1.H0 llama LyricsPop.enableGlow(). Sin este parche no se dibuja el brillo.
 */
@Suppress("unused")
val lyricsGlowPatch = bytecodePatch(
    description = "Las silabas que se sostienen tienen un brillo suave alrededor mientras crecen. Necesita \"Letras: silaba " +
        "por silaba\". Desmarcalo si no te gusta el brillo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(lyricsSyllablesPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val tn1 = mutableClassDefBy(classDefBy("Llw1;"))
        val e0 = tn1.methods.singleOrNull {
            it.name == "H0" && it.parameterTypes.map { p -> p.toString() } == listOf("Lip4;")
        } ?: error("No se encontro lw1.H0 (version de Eclipse distinta de 0.6.61?)")
        e0.addInstructions(0, "invoke-static {}, $POP_GLOW->enableGlow()V")
    }
}
