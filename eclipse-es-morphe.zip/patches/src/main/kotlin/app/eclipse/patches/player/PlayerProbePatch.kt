package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

private const val PROBE = "Lapp/eclipse/extension/player/PlayerProbe;"

/**
 * DIAGNOSTICO. v1.97.2/3: cadena de clases que dibujan el reproductor (resultado: a43.c es la pantalla, lf2.r el Bitchord,
 * no hay AnimatedVisibility alrededor). v1.97.4: vigila los 3 interruptores Boolean de a43.c (a43.m, a43.r, a43.s) para ver
 * cual cambia al abrir/cerrar el reproductor grande. No cambia nada del reproductor.
 */
@Suppress("unused")
val playerProbePatch = bytecodePatch(
    name = "Diagnostico: quien abre el reproductor",
    description = "Solo para pruebas. Anota en el portapapeles cuando cambian los interruptores internos del reproductor " +
        "(al abrirlo y cerrarlo). No cambia nada mas. Apagalo despues de la prueba.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // v1.97.4: se quitan los ganchos de pila (ya dieron su resultado) y se vigilan los 3 interruptores de a43.c:
        // a43.m / a43.r / a43.s (Len5;)Z, cada uno lee un estado Boolean y lo devuelve. Antes del `return` se llama a
        // PlayerProbe.boolX(valor), que anota cuando CAMBIA y copia la lista al portapapeles.
        val a43 = mutableClassDefBy(classDefBy("La43;"))
        for ((name, hit) in listOf("m" to "boolM", "r" to "boolR", "s" to "boolS")) {
            val m = a43.methods.singleOrNull {
                it.name == name && it.returnType == "Z" && it.parameterTypes.map { p -> p.toString() } == listOf("Len5;")
            } ?: error("No se encontro a43.$name(en5)Z")
            val ins = (m.implementation ?: error("a43.$name sin codigo")).instructions.toList()
            val rets = ins.indices.filter { ins[it].opcode == Opcode.RETURN }
            if (rets.size != 1) error("a43.$name: se esperaba 1 return (hay ${rets.size})")
            val reg = (ins[rets[0]] as OneRegisterInstruction).registerA
            if (reg > 15) error("a43.$name: registro del return fuera de v0..v15")
            m.addInstructions(rets[0], "invoke-static {v$reg}, $PROBE->$hit(Z)V")
        }
    }
}
