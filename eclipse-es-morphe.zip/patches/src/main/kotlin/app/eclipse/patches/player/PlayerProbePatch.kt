package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val PROBE = "Lapp/eclipse/extension/player/PlayerProbe;"

/**
 * DIAGNOSTICO. v1.97.2/3: a43.c es la pantalla del reproductor. v1.97.4: los interruptores a43.m/r/s no cambian al
 * abrir/cerrar. v1.97.5: el reproductor vive dentro de dr8.a (hoja arrastrable con su propio Float de posicion);
 * se anota ese valor (desplazamiento / alto, 0..1) para ver si abrir/cerrar es suave o salta. No cambia nada del reproductor.
 */
@Suppress("unused")
val playerProbePatch = bytecodePatch(
    name = "Diagnostico: quien abre el reproductor",
    description = "Solo para pruebas. Anota en el portapapeles la posicion de la hoja del reproductor grande " +
        "(al abrirlo y cerrarlo) para ver si el movimiento es suave o salta. No cambia nada mas. Apagalo despues de la prueba.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // dr8.a(d43, F, Z, d43, ub3, af1, ki1, I, I)V: lee `jr.d()` (desplazamiento), lo pasa a float y lo divide por el
        // alto (`div-float/2addr vX, vY`). Justo despues de esa division se llama a PlayerProbe.pos(vX).
        val dr8 = mutableClassDefBy(classDefBy("Ldr8;"))
        val m = dr8.methods.singleOrNull {
            it.name == "a" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ld43;", "F", "Z", "Ld43;", "Lub3;", "Laf1;", "Lki1;", "I", "I")
        } ?: error("No se encontro dr8.a")
        val ins = (m.implementation ?: error("dr8.a sin codigo")).instructions.toList()
        val divs = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_VIRTUAL_RANGE && r != null && r.definingClass == "Ljr;" &&
                r.name == "d" && r.parameterTypes.isEmpty()
        }.mapNotNull { h ->
            (h + 1..minOf(h + 8, ins.size - 1)).firstOrNull { ins[it].opcode == Opcode.DIV_FLOAT_2ADDR }
        }
        if (divs.size != 1) error("dr8.a: se esperaba 1 division tras jr.d() (hay ${divs.size})")
        val div = divs[0]
        val reg = (ins[div] as TwoRegisterInstruction).registerA
        if (reg > 15) error("dr8.a: registro de la division fuera de v0..v15")
        m.addInstructions(div + 1, "invoke-static {v$reg}, $PROBE->pos(F)V")
    }
}
