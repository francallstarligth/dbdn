package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val PROBE = "Lapp/eclipse/extension/player/PlayerProbe;"

/**
 * DIAGNOSTICO (v1.97.2). Al abrir el reproductor grande copia al portapapeles la cadena de clases que lo
 * dibujan, para encontrar la hoja que sube y baja y poder animarla. No cambia nada del reproductor.
 *
 * Gancho: `invoke-static {}` (sin registros) al inicio de r18.x, gm.i y oi9.f (las 3 funciones que dibujan
 * "PLAYING FROM"; verificado con androguard: 88, 115 y 129 registros; la primera instruccion es move-object/from16 y
 * nadie salta al inicio). v1.97.3: ademas a43.c (host de TODOS los estilos; 7 parametros, 145 registros), lf2.r (Custom/Bitchord; 90 registros) y q18.e (22 parametros, 72 registros).
 */
@Suppress("unused")
val playerProbePatch = bytecodePatch(
    name = "Diagnostico: quien abre el reproductor",
    description = "Solo para pruebas. Al abrir el reproductor grande copia al portapapeles las clases que lo " +
        "dibujan. No cambia nada mas. Apagalo despues de la prueba.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        fun hook(cls: String, name: String, params: Int, hit: String) {
            val c = mutableClassDefBy(classDefBy(cls))
            val m = c.methods.singleOrNull { it.name == name && it.returnType == "V" && it.parameterTypes.size == params }
                ?: error("No se encontro $cls.$name con $params parametros (version de Eclipse distinta de 0.6.47?)")
            m.addInstructions(0, "invoke-static {}, $PROBE->$hit()V")
        }
        hook("Lr18;", "x", 18, "hitA")
        hook("Lgm;", "i", 18, "hitB")
        hook("Loi9;", "f", 24, "hitC")
        hook("La43;", "c", 7, "hitD")
        hook("Lq18;", "e", 22, "hitF")

        // lf2.r (Custom/Bitchord): unico metodo "r" de lf2 con primer parametro ib6.
        val lf2 = mutableClassDefBy(classDefBy("Llf2;"))
        val r = lf2.methods.singleOrNull {
            it.name == "r" && it.returnType == "V" && it.parameterTypes.firstOrNull()?.toString() == "Lib6;"
        } ?: error("No se encontro lf2.r(ib6, Song, ...)")
        r.addInstructions(0, "invoke-static {}, $PROBE->hitE()V")
    }
}
