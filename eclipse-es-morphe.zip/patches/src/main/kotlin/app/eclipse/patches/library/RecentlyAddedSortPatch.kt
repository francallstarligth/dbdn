package app.eclipse.patches.library

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val HELPER = "Lapp/eclipse/extension/es/RecentSort;"

// Nombres ofuscados de Eclipse 0.6.47 (verificados en el APK original):
//  - Lr18;  : pantalla que aplica el orden elegido en "Ordenar por".
//  - Ltg8;  : tabla ($WhenMappings) del enum de orden; campo "a" = int[].
//  - Lz91;->N0(Iterable) : reversed(). Es lo unico que hacia "Agregado recientemente".
private const val SORT_CLASS = "Lr18;"
private const val WHEN_MAPPINGS = "Ltg8;"
private const val REVERSED_CLASS = "Lz91;"
private const val REVERSED_NAME = "N0"
private const val SEARCH_WINDOW = 260

// Cola de reproduccion (verificado en el APK original):
//  - Lyz6;->L(List, int, Lqa2;) : QueueManager; todos los clics en una lista llegan aqui.
private const val QUEUE_CLASS = "Lyz6;"
private const val QUEUE_METHOD = "L"

@Suppress("unused")
val recentlyAddedSortPatch = bytecodePatch(
    name = "Fix recently added sort",
    description = "Arregla 'Agregado recientemente': ordena por la fecha real de agregado (mas nuevo arriba) y hace que Siguiente/Anterior sigan el orden de la pantalla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        var patched = false

        val immutable = runCatching { classDefBy(SORT_CLASS) }.getOrNull()
        if (immutable != null) {
            val mutable = mutableClassDefBy(immutable)
            for (method in mutable.methods) {
                if (patched) break
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()

                // 1) El sget-object de Ltg8;->a (la tabla del "when" sobre el orden elegido).
                val anchor = list.indexOfFirst { ins ->
                    ins.opcode == Opcode.SGET_OBJECT &&
                        ((ins as? ReferenceInstruction)?.reference as? FieldReference)?.let {
                            it.definingClass == WHEN_MAPPINGS && it.name == "a"
                        } == true
                }
                if (anchor < 0) continue

                // 2) Primer reversed() despues de ese punto = rama RECENTLY_ADDED.
                val callIdx = (anchor + 1 until minOf(list.size, anchor + 1 + SEARCH_WINDOW)).firstOrNull { i ->
                    val ins = list[i]
                    ins.opcode == Opcode.INVOKE_STATIC &&
                        ((ins as? ReferenceInstruction)?.reference as? MethodReference)?.let {
                            it.definingClass == REVERSED_CLASS && it.name == REVERSED_NAME
                        } == true
                } ?: continue

                // 3) Debe venir un move-result-object con el resultado (lista dada vuelta).
                val moveResult = list.getOrNull(callIdx + 1) ?: continue
                if (moveResult.opcode != Opcode.MOVE_RESULT_OBJECT) continue
                val reg = (moveResult as OneRegisterInstruction).registerA
                val v = "v$reg"

                // 4) Despues del move-result: reordenar esa lista por fecha (estable).
                method.addInstructions(
                    callIdx + 2,
                    """
                        invoke-static/range {$v .. $v}, $HELPER->resort(Ljava/util/List;)Ljava/util/List;
                        move-result-object $v
                    """
                )
                // 5) Avisar al ayudante cada vez que se recalcula el orden (si no es
                //    "Agregado recientemente", se olvida la lista). Se inserta DESPUES del
                //    sget (anchor + 1), mas abajo que el bloque anterior, asi no cambia sus indices.
                method.addInstructions(
                    anchor + 1,
                    "invoke-static {}, $HELPER->reset()V"
                )
                patched = true
            }
        }

        // Cola: si la cola llega justo al reves de la lista mostrada, se alinea con la pantalla.
        var queuePatched = false
        val queueClass = runCatching { classDefBy(QUEUE_CLASS) }.getOrNull()
        if (queueClass != null) {
            val mutableQueue = mutableClassDefBy(queueClass)
            val target = mutableQueue.methods.firstOrNull { m ->
                m.name == QUEUE_METHOD &&
                    m.parameterTypes.map { it.toString() } ==
                    listOf("Ljava/util/List;", "I", "Lqa2;")
            }
            if (target != null) {
                target.addInstructions(
                    0,
                    """
                        invoke-static {p1, p2}, $HELPER->alignIndex(Ljava/util/List;I)I
                        move-result v0
                        invoke-static {p1}, $HELPER->alignList(Ljava/util/List;)Ljava/util/List;
                        move-result-object p1
                        move p2, v0
                    """
                )
                queuePatched = true
            }
        }
        println(
            if (queuePatched) "Eclipse ES: cola alineada con el orden de pantalla."
            else "Eclipse ES: no se encontro la cola (version distinta); sin cambios en Siguiente/Anterior."
        )
        println(
            if (patched) "Eclipse ES: orden 'Agregado recientemente' corregido."
            else "Eclipse ES: no se encontro el sitio del orden 'Agregado recientemente' (version distinta); sin cambios."
        )
    }
}
