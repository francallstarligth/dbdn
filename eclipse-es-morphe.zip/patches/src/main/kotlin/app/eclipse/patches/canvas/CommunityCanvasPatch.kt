package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Texto del log de Eclipse justo cuando NO hay portada animada (rama final de ww0.m en 0.6.57). */
private const val MARKER = "pick: no animated artwork found for '"

@Suppress("unused")
val communityCanvasPatch = bytecodePatch(
    name = "Canvas (comunidad)",
    description = "Pone un video en bucle como portada animada cuando Eclipse no tiene una, " +
        "usando una lista publica de la comunidad (sin cuenta ni cookie) y, si pegas tu cookie sp_dc en las opciones, Spotify. Uso personal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Mostrar avisos de depuracion",
        description = "Muestra avisos en pantalla con el paso en que se queda la busqueda de portadas animadas. Dejalo apagado para uso normal."
    )

    val spCookie by stringOption(
        key = "spDc",
        default = "",
        title = "Cookie sp_dc de Spotify (opcional)",
        description = "Si la pegas, cuando la lista de la comunidad no tiene la cancion se busca el Canvas en Spotify con TU cuenta. " +
            "Dejala vacia para no usar Spotify. Saca el valor de la cookie sp_dc en open.spotify.com (sesion iniciada). " +
            "Queda dentro de tu APK parcheado: no lo compartas. Usar la cuenta asi va contra las normas de Spotify (riesgo para tu cuenta)."
    )

    execute {
        // Solo caracteres que puede tener la cookie (la pasa a smali como texto: nada de comillas ni barras).
        val cookieValue = (spCookie ?: "").trim().removePrefix("sp_dc=").substringBefore(';')
            .filter { it.isLetterOrDigit() && it.code < 128 || it in "_-%.=~+/" }
        val debugFlag = if (debug == true) "0x1" else "0x0"

        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.57?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val strIndex = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (strIndex < 1) continue

            // Instruccion anterior = new-instance StringBuilder (inicio del bloque "sin portada animada").
            val insertIndex = strIndex - 1
            if (method.getInstruction(insertIndex).opcode != Opcode.NEW_INSTANCE) {
                error("Estructura inesperada antes del marcador en ${method.name}")
            }

            method.addInstructionsWithLabels(
                insertIndex,
                """
                    const/4 v2, $debugFlag
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setDebug(Z)V
                    const-string v2, "$cookieValue"
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setCookie(Ljava/lang/String;)V
                    invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getArtist()Ljava/lang/String;
                    move-result-object v2
                    invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getDuration()I
                    move-result v6
                    invoke-static {v7, v2, v6, v3}, Lapp/eclipse/extension/canvas/CanvasLookup;->lookup(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;
                    move-result-object v2
                    if-eqz v2, :orig
                    new-instance v6, Lpp2;
                    sget-object v8, Lmp2;->TidalAnimatedArtwork:Lmp2;
                    const-string v9, "canvas:"
                    invoke-virtual {v9, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v9
                    invoke-direct {v6, v8, v2, v9}, Lpp2;-><init>(Lmp2;Ljava/lang/String;Ljava/lang/String;)V
                    return-object v6
                """,
                ExternalLabel("orig", method.getInstruction(insertIndex))
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el gancho de Canvas")

        // v1.90.0 - gancho 2: en vk0.invokeSuspend (efecto de la pantalla del reproductor) justo antes de
        // `ww0.F(ctx, song, cont)` se avisa a la extension de la cancion (v1) y de la variable de estado q06 (v14) que
        // recibira la URL. Asi el gancho 1 puede responder "sin Canvas" al instante y entregar el video despues.
        val vk0 = mutableClassDefBy(classDefBy("Lvk0;"))
        var bound = false
        for (method in vk0.methods) {
            if (method.name != "invokeSuspend") continue
            val impl = method.implementation ?: continue
            val ins = impl.instructions.toList()
            val calls = ins.indices.filter { i ->
                val x = ins[i]
                x.opcode == Opcode.INVOKE_VIRTUAL && (x as ReferenceInstruction).reference.let { r ->
                    r is MethodReference && r.definingClass == "Lww0;" && r.name == "F" && r.parameterTypes.size == 3
                }
            }
            if (calls.isEmpty()) continue
            if (calls.size != 1) error("vk0.invokeSuspend: se esperaba un solo llamado a ww0.F (hay ${calls.size})")
            val ci = calls[0]
            val call = ins[ci] as FiveRegisterInstruction
            val songReg = call.registerE
            val put = ins[ci - 1]
            if (put.opcode != Opcode.IPUT || ci < 3) error("vk0.invokeSuspend: estructura inesperada antes de ww0.F")
            val putObj = ins[ci - 2]
            if (putObj.opcode != Opcode.IPUT_OBJECT) error("vk0.invokeSuspend: falta el iput-object del estado")
            val stateReg = (putObj as TwoRegisterInstruction).registerA
            if (songReg > 15 || stateReg > 15) error("vk0.invokeSuspend: registro fuera de v0..v15")
            method.addInstructions(
                ci,
                """
                    invoke-static {v$songReg, v$stateReg}, Lapp/eclipse/extension/canvas/CanvasLookup;->bindState(Ljava/lang/Object;Ljava/lang/Object;)V
                """
            )
            bound = true
            break
        }
        if (!bound) error("No se encontro vk0.invokeSuspend con el llamado a ww0.F")
    }
}
