package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Texto del log de Eclipse justo cuando NO hay portada animada (rama :cond_19 de qf2.a en 0.6.47). */
private const val MARKER = "pick: no animated artwork found for '"

@Suppress("unused")
val communityCanvasPatch = bytecodePatch(
    name = "Canvas (comunidad)",
    description = "Pone un video en bucle como portada animada cuando Eclipse no tiene una, " +
        "usando una lista publica de la comunidad (sin cuenta ni cookie) y, si pegas tu cookie sp_dc en las opciones, Spotify. Uso personal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Mostrar avisos de depuracion",
        description = "Muestra avisos en pantalla con el paso en que se queda la busqueda de portadas animadas. Dejalo apagado para uso normal."
    )

    val spCookie by stringOption(
        key = "spDc",
        default = "",
        title = "Cookie sp_dc de Spotify (opcional)",
        description = "Si la pegas, cuando la lista de la comunidad no tiene la cancion se busca el Canvas en Spotify con TU cuenta. " +
            "Dejala vacia para no usar Spotify. Saca el valor de la cookie sp_dc en open.spotify.com (sesion iniciada). " +
            "Queda dentro de tu APK parcheado: no lo compartas. Usar la cuenta asi va contra las normas de Spotify (riesgo para tu cuenta)."
    )

    execute {
        // Solo caracteres que puede tener la cookie (la pasa a smali como texto: nada de comillas ni barras).
        val cookieValue = (spCookie ?: "").trim().removePrefix("sp_dc=").substringBefore(';')
            .filter { it.isLetterOrDigit() && it.code < 128 || it in "_-%.=~+/" }
        val debugFlag = if (debug == true) "0x1" else "0x0"

        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.47?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val strIndex = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (strIndex < 1) continue

            // Instruccion anterior = new-instance StringBuilder (inicio del bloque "sin portada animada").
            val insertIndex = strIndex - 1
            if (method.getInstruction(insertIndex).opcode != Opcode.NEW_INSTANCE) {
                error("Estructura inesperada antes del marcador en ${method.name}")
            }

            method.addInstructionsWithLabels(
                insertIndex,
                """
                    const/4 v2, $debugFlag
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setDebug(Z)V
                    const-string v2, "$cookieValue"
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setCookie(Ljava/lang/String;)V
                    invoke-virtual {v1}, Lcom/eclipse/android/data/models/Song;->getArtist()Ljava/lang/String;
                    move-result-object v2
                    invoke-virtual {v1}, Lcom/eclipse/android/data/models/Song;->getDuration()I
                    move-result v3
                    invoke-static {v0, v2, v3}, Lapp/eclipse/extension/canvas/CanvasLookup;->lookup(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;
                    move-result-object v2
                    if-eqz v2, :orig
                    new-instance v3, Lrf2;
                    sget-object v4, Lmf2;->TidalAnimatedArtwork:Lmf2;
                    const-string v5, "canvas:"
                    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v5
                    invoke-direct {v3, v4, v2, v5}, Lrf2;-><init>(Lmf2;Ljava/lang/String;Ljava/lang/String;)V
                    return-object v3
                """,
                ExternalLabel("orig", method.getInstruction(insertIndex))
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el gancho de Canvas")
    }
}
