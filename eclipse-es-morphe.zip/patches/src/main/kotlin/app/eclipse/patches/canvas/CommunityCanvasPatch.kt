package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.TypeReference
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Texto del log de Eclipse justo cuando NO hay portada animada (rama final de rz0.m en 0.6.70; antes ux0.m). */
private const val MARKER = "pick: no animated artwork found for '"

@Suppress("unused")
val communityCanvasPatch = bytecodePatch(
    name = "Canvas (comunidad)",
    description = "Pone un video en bucle como portada animada cuando Eclipse no tiene una, " +
        "usando una lista publica de la comunidad (sin cuenta ni cookie) y, si pegas tu cookie sp_dc en las opciones, Spotify. Uso personal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Mostrar avisos de depuracion",
        description = "Muestra avisos en pantalla con el paso en que se queda la busqueda de portadas animadas. Dejalo apagado para uso normal."
    )

    val spCookie by stringOption(
        key = "spDc",
        default = "",
        title = "Cookie sp_dc de Spotify (opcional)",
        description = "Si la pegas, cuando la lista de la comunidad no tiene la cancion se busca el Canvas en Spotify con TU cuenta. " +
            "Dejala vacia para no usar Spotify. Saca el valor de la cookie sp_dc en open.spotify.com (sesion iniciada). " +
            "Queda dentro de tu APK parcheado: no lo compartas. Usar la cuenta asi va contra las normas de Spotify (riesgo para tu cuenta)."
    )

    val useEclipse by booleanOption(
        key = "useEclipseSession",
        default = true,
        title = "Usar la sesion de Spotify de Eclipse",
        description = "Si no pegaste cookie, se lee la sesion que Eclipse guarda al iniciar sesion en Spotify (dentro de Eclipse) y se busca el Canvas con esa cuenta. " +
            "Sin sesion iniciada no pasa nada. Desmarcalo para no usar Spotify. Usar la cuenta asi va contra las normas de Spotify (riesgo para tu cuenta)."
    )

    execute {
        // Solo caracteres que puede tener la cookie (la pasa a smali como texto: nada de comillas ni barras).
        val cookieValue = (spCookie ?: "").trim().removePrefix("sp_dc=").substringBefore(';')
            .filter { it.isLetterOrDigit() && it.code < 128 || it in "_-%.=~+/" }
        val finalCookie = if (cookieValue.isEmpty() && useEclipse == true) "@eclipse" else cookieValue
        val debugFlag = if (debug == true) "0x1" else "0x0"

        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.70?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val strIndex = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (strIndex < 1) continue

            // Instruccion anterior = new-instance StringBuilder (inicio del bloque "sin portada animada").
            val insertIndex = strIndex - 1
            if (method.getInstruction(insertIndex).opcode != Opcode.NEW_INSTANCE) {
                error("Estructura inesperada antes del marcador en ${method.name}")
            }

            method.addInstructionsWithLabels(
                insertIndex,
                """
                    const/4 v2, $debugFlag
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setDebug(Z)V
                    const-string v2, "$finalCookie"
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setCookie(Ljava/lang/String;)V
                    invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getArtist()Ljava/lang/String;
                    move-result-object v2
                    invoke-virtual {v3}, Lcom/eclipse/android/data/models/Song;->getDuration()I
                    move-result v6
                    invoke-static {v7, v2, v6, v3}, Lapp/eclipse/extension/canvas/CanvasLookup;->lookup(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;
                    move-result-object v2
                    if-eqz v2, :orig
                    new-instance v6, Lst2;
                    sget-object v8, Lpt2;->TidalAnimatedArtwork:Lpt2;
                    const-string v9, "canvas:"
                    invoke-virtual {v9, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v9
                    invoke-direct {v6, v8, v2, v9}, Lst2;-><init>(Lpt2;Ljava/lang/String;Ljava/lang/String;)V
                    return-object v6
                """,
                ExternalLabel("orig", method.getInstruction(insertIndex))
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el gancho de Canvas")

        // v1.90.0 - gancho 2 (v0.20.249, SIN COMPILAR NI PROBAR: portado a 0.6.70; sl0 -> h10, ux0.F -> rz0.I): en
        // h10.invokeSuspend (efecto de la pantalla del reproductor) justo antes de `rz0.I(ctx, song, cont)` se avisa a la
        // extension de la cancion (v3) y de la variable de estado jg6 (v2) que recibira la URL. Asi el gancho 1 puede
        // responder "sin Canvas" al instante y entregar el video despues. En 0.6.70 esa clase junta 6 variantes con el
        // mismo codigo (6 llamados a rz0.I en un solo invokeSuspend): se engancha cada uno.
        // v0.20.256: tambien `j10.a(Lbz1;)` (12 variantes). Es el colector que k10/m10 lanzan sobre el flujo de Tidal (tra.l):
        // al emitir llama a rz0.I y escribe en el MISMO estado jg6 (iput-object del estado + iput + rz0.I + jg6.setValue),
        // asi que podia pisar la entrega. En j10.a el estado es v2 y la cancion v3 en todas las variantes (se leen al inicio).
        val targets = listOf(
            Triple("Lh10;", "invokeSuspend", listOf("Ljava/lang/Object;")),
            Triple("Lj10;", "a", listOf("Lbz1;"))
        )
        var bound = 0
        for ((clsName, mName, mParams) in targets) {
            val cls = mutableClassDefBy(classDefBy(clsName))
            var boundHere = 0
            for (method in cls.methods) {
                if (method.name != mName || method.parameterTypes.map { it.toString() } != mParams) continue
                val impl = method.implementation ?: continue
                val ins = impl.instructions.toList()
                val calls = ins.indices.filter { i ->
                    val x = ins[i]
                    x.opcode == Opcode.INVOKE_VIRTUAL && (x as ReferenceInstruction).reference.let { r ->
                        r is MethodReference && r.definingClass == "Lrz0;" && r.name == "I" && r.parameterTypes.size == 3
                    }
                }
                if (calls.isEmpty()) continue
                val hooks = calls.map { ci ->
                    val call = ins[ci] as FiveRegisterInstruction
                    val songReg = call.registerE
                    val put = ins[ci - 1]
                    if (put.opcode != Opcode.IPUT || ci < 3) error("$clsName.$mName: estructura inesperada antes de rz0.I")
                    val putObj = ins[ci - 2]
                    if (putObj.opcode != Opcode.IPUT_OBJECT) error("$clsName.$mName: falta el iput-object del estado")
                    val stateReg = (putObj as TwoRegisterInstruction).registerA
                    if (songReg > 15 || stateReg > 15) error("$clsName.$mName: registro fuera de v0..v15")
                    Triple(ci, songReg, stateReg)
                }
                // De abajo hacia arriba para no correr los indices.
                for ((ci, songReg, stateReg) in hooks.sortedByDescending { it.first }) {
                    // v0.20.255: justo despues de que Eclipse escribe su resultado en el estado (jg6.setValue tras rz0.I) se
                    // vuelve a poner el Canvas si ya esta en cache: en 0.6.70 ese setValue puede llegar DESPUES de mi entrega
                    // y borrarla. Se inserta primero (indice mayor) para no mover el indice del bindState.
                    val setIdx = (ci + 1 until minOf(ci + 12, ins.size)).firstOrNull { i ->
                        val x = ins[i]
                        x.opcode == Opcode.INVOKE_INTERFACE && (x as ReferenceInstruction).reference.let { r ->
                            r is MethodReference && r.definingClass == "Ljg6;" && r.name == "setValue"
                        }
                    } ?: error("$clsName.$mName: no se encontro jg6.setValue tras rz0.I")
                    method.addInstructions(
                        setIdx + 1,
                        """
                            invoke-static {v$songReg, v$stateReg}, Lapp/eclipse/extension/canvas/CanvasLookup;->reapply(Ljava/lang/Object;Ljava/lang/Object;)V
                        """
                    )
                    method.addInstructions(
                        ci,
                        """
                            invoke-static {v$songReg, v$stateReg}, Lapp/eclipse/extension/canvas/CanvasLookup;->bindState(Ljava/lang/Object;Ljava/lang/Object;)V
                        """
                    )
                    boundHere++
                }
                break
            }
            if (boundHere == 0) error("No se encontro $clsName.$mName con el llamado a rz0.I")
            bound += boundHere
        }

        // v0.20.257 - gancho 3 (SIN COMPILAR NI PROBAR): el aviso Canvas[2] nunca salia, o sea que h10/j10 no pasaron por la ruta
        // de esa cancion. El estado jg6 del Canvas lo CREA w32.Z(Song, nt1)jg6 (unico `check-cast Ljg6;` del metodo, que luego
        // devuelve ese mismo registro): se anota ahi la cancion (p0 = ultimo-1 registros de parametros) y el estado.
        run {
            val z = mutableClassDefBy(classDefBy("Lw32;")).methods.firstOrNull { m ->
                m.name == "Z" && m.returnType == "Ljg6;" &&
                    m.parameterTypes.map { it.toString() } == listOf("Lcom/eclipse/android/data/models/Song;", "Lnt1;")
            } ?: error("No se encontro w32.Z(Song, nt1)jg6 (version de Eclipse distinta de 0.6.70?)")
            val zi = (z.implementation ?: error("w32.Z sin codigo")).let { it.instructions.toList() to it.registerCount }
            val zIns = zi.first
            val casts = zIns.indices.filter { i ->
                val x = zIns[i]
                x.opcode == Opcode.CHECK_CAST && ((x as ReferenceInstruction).reference as? TypeReference)?.type == "Ljg6;"
            }
            if (casts.size != 1) error("w32.Z: se esperaba 1 check-cast Ljg6; (hay ${casts.size})")
            val ci = casts[0]
            val stateReg = (zIns[ci] as OneRegisterInstruction).registerA
            val songReg = zi.second - 2 // p0 (metodo estatico con 2 parametros de 1 registro)
            if (stateReg > 15 || songReg > 15 || songReg < 0) error("w32.Z: registro fuera de v0..v15")
            z.addInstructions(
                ci + 1,
                """
                    invoke-static {v$songReg, v$stateReg}, Lapp/eclipse/extension/canvas/CanvasLookup;->bindState(Ljava/lang/Object;Ljava/lang/Object;)V
                """
            )
        }
    }
}
