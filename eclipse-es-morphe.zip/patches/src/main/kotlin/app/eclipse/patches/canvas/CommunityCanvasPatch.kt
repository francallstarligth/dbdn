package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.stringOption
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Texto del log de Eclipse justo cuando NO hay portada animada (rama final de oo2.a en 0.6.55). */
private const val MARKER = "pick: no animated artwork found for '"

@Suppress("unused")
val communityCanvasPatch = bytecodePatch(
    name = "Canvas (comunidad)",
    description = "Pone un video en bucle como portada animada cuando Eclipse no tiene una, " +
        "usando una lista publica de la comunidad (sin cuenta ni cookie) y, si pegas tu cookie sp_dc en las opciones, Spotify. Uso personal.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Mostrar avisos de depuracion",
        description = "Muestra avisos en pantalla con el paso en que se queda la busqueda de portadas animadas. Dejalo apagado para uso normal."
    )

    val spCookie by stringOption(
        key = "spDc",
        default = "",
        title = "Cookie sp_dc de Spotify (opcional)",
        description = "Si la pegas, cuando la lista de la comunidad no tiene la cancion se busca el Canvas en Spotify con TU cuenta. " +
            "Dejala vacia para no usar Spotify. Saca el valor de la cookie sp_dc en open.spotify.com (sesion iniciada). " +
            "Queda dentro de tu APK parcheado: no lo compartas. Usar la cuenta asi va contra las normas de Spotify (riesgo para tu cuenta)."
    )

    execute {
        // Solo caracteres que puede tener la cookie (la pasa a smali como texto: nada de comillas ni barras).
        val cookieValue = (spCookie ?: "").trim().removePrefix("sp_dc=").substringBefore(';')
            .filter { it.isLetterOrDigit() && it.code < 128 || it in "_-%.=~+/" }
        val debugFlag = if (debug == true) "0x1" else "0x0"

        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.55?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val strIndex = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (strIndex < 1) continue

            // Instruccion anterior = new-instance StringBuilder (inicio del bloque "sin portada animada").
            val insertIndex = strIndex - 1
            if (method.getInstruction(insertIndex).opcode != Opcode.NEW_INSTANCE) {
                error("Estructura inesperada antes del marcador en ${method.name}")
            }

            method.addInstructionsWithLabels(
                insertIndex,
                """
                    const/4 v2, $debugFlag
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setDebug(Z)V
                    const-string v2, "$cookieValue"
                    invoke-static {v2}, Lapp/eclipse/extension/canvas/CanvasLookup;->setCookie(Ljava/lang/String;)V
                    invoke-virtual {v11}, Lcom/eclipse/android/data/models/Song;->getArtist()Ljava/lang/String;
                    move-result-object v2
                    invoke-virtual {v11}, Lcom/eclipse/android/data/models/Song;->getDuration()I
                    move-result v3
                    invoke-static {v0, v2, v3, v11}, Lapp/eclipse/extension/canvas/CanvasLookup;->lookup(Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Ljava/lang/String;
                    move-result-object v2
                    if-eqz v2, :orig
                    new-instance v3, Lpo2;
                    sget-object v4, Lmo2;->TidalAnimatedArtwork:Lmo2;
                    const-string v5, "canvas:"
                    invoke-virtual {v5, v2}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v5
                    invoke-direct {v3, v4, v2, v5}, Lpo2;-><init>(Lmo2;Ljava/lang/String;Ljava/lang/String;)V
                    return-object v3
                """,
                ExternalLabel("orig", method.getInstruction(insertIndex))
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro el metodo donde insertar el gancho de Canvas")

        // v1.90.0 - gancho 2: en gk0.invokeSuspend (efecto de la pantalla del reproductor) justo antes de
        // `oo2.a(ctx, song, cont)` se avisa a la extension de la cancion (v1) y de la variable de estado nz5 (v14) que
        // recibira la URL. Asi el gancho 1 puede responder "sin Canvas" al instante y entregar el video despues.
        val gk0 = mutableClassDefBy(classDefBy("Lgk0;"))
        var bound = false
        for (method in gk0.methods) {
            if (method.name != "invokeSuspend") continue
            val impl = method.implementation ?: continue
            val ins = impl.instructions.toList()
            val calls = ins.indices.filter { i ->
                val x = ins[i]
                x.opcode == Opcode.INVOKE_VIRTUAL && (x as ReferenceInstruction).reference.let { r ->
                    r is MethodReference && r.definingClass == "Loo2;" && r.name == "a" && r.parameterTypes.size == 3
                }
            }
            if (calls.isEmpty()) continue
            if (calls.size != 1) error("gk0.invokeSuspend: se esperaba un solo llamado a oo2.a (hay ${calls.size})")
            val ci = calls[0]
            val call = ins[ci] as FiveRegisterInstruction
            val songReg = call.registerE
            val put = ins[ci - 1]
            if (put.opcode != Opcode.IPUT || ci < 3) error("gk0.invokeSuspend: estructura inesperada antes de oo2.a")
            val putObj = ins[ci - 2]
            if (putObj.opcode != Opcode.IPUT_OBJECT) error("gk0.invokeSuspend: falta el iput-object del estado")
            val stateReg = (putObj as TwoRegisterInstruction).registerA
            if (songReg > 15 || stateReg > 15) error("gk0.invokeSuspend: registro fuera de v0..v15")
            method.addInstructions(
                ci,
                """
                    invoke-static {v$songReg, v$stateReg}, Lapp/eclipse/extension/canvas/CanvasLookup;->bindState(Ljava/lang/Object;Ljava/lang/Object;)V
                """
            )
            bound = true
            break
        }
        if (!bound) error("No se encontro gk0.invokeSuspend con el llamado a oo2.a")
    }
}
