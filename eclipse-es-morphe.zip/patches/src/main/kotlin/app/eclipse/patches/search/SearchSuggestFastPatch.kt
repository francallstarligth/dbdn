package app.eclipse.patches.search

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val FAST = "Lapp/eclipse/extension/search/SuggestFast;"

/**
 * v0.20.443 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Parche APARTE que depende de "Busqueda: sugerencias al escribir".
 * Unico gancho: en `Lju6;->invoke`, justo antes del `Suggest.add(texto, scope, this)` que pone el otro parche, llama
 * `SuggestFast.onText(texto)` (mismo registro que usa `Suggest.add` para el texto). Todo lo demas vive en Java:
 * `Suggest.add` pregunta a `SuggestFast.pick` y lee `SuggestFast.touch` (estado propio para redibujar). Sin este parche
 * activo nadie llama `onText`, asi que `pick` devuelve siempre las sugerencias de los resultados (comportamiento de la 0.20.442).
 */
@Suppress("unused")
val searchSuggestFastPatch = bytecodePatch(
    name = "Busqueda: sugerencias rapidas",
    description = "Las sugerencias salen de inmediato (piden aparte al autocompletar publico de Deezer) en vez de esperar los resultados de la busqueda. Necesita \"Busqueda: sugerencias al escribir\". Lo que escribes se envia a Deezer.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    dependsOn(searchSuggestPatch)
    extendWith("extensions/extension.mpe")

    execute {
        val j = mutableClassDefBy(classDefBy("Lju6;"))
        val inv = j.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.size == 1 }
            ?: error("Sugerencias rapidas: no se encontro Lju6.invoke")
        val ins = inv.implementation!!.instructions.toList()
        val hits = ins.indices.filter { i ->
            ins[i].opcode == Opcode.INVOKE_STATIC &&
                ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                    r.definingClass == "Lapp/eclipse/extension/search/Suggest;" && r.name == "add"
                } == true
        }
        if (hits.size != 1) error("Sugerencias rapidas: se esperaba 1 'Suggest.add' en Lju6.invoke y hay ${hits.size} (activa tambien \"Busqueda: sugerencias al escribir\")")
        val reg = (ins[hits[0]] as FiveRegisterInstruction).registerC
        if (reg > 15) error("Sugerencias rapidas: registro v$reg del texto no cabe en 4 bits")
        inv.addInstructions(hits[0], "invoke-static {v$reg}, $FAST->onText(Ljava/lang/String;)V")
    }
}
