package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val TAB_SLIDE = "Lapp/eclipse/extension/player/TabSlide;"

/**
 * v0.20.461 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Skin NATIVE: la vieja pantalla se desvanece y se desplaza al cambiar de
 * pestana. Native no tiene transicion (las pestanas son `Lcy6;`: HOME, LIBRARY, NEW, RADIO, SEARCH, y las dibuja su propio
 * navegador `Lxs6;`, no el NavHost de la skin Eclipse). Gancho: inicio de `Lxs6;->l(Lcy6;)V` (se tocó una pestana) llama a
 * `TabSlide.before(Lxs6, Lcy6)`, que toma una captura (PixelCopy) y la desvanece/desplaza encima. Si algo falla no hace nada.
 * Pantalla nueva: en `Lfm6;->r`, el Modifier del Box de la pagina (el que recibe `Lkq0;->K` despues de `Lnd4;->D`) pasa
 * por `TabSlide.page`, que le agrega un graphicsLayer (entra deslizando 5 % con fundido).
 */
@Suppress("unused")
val tabSlidePatch = bytecodePatch(
    name = "Native: pestanas con desvanecido y desplazamiento",
    description = "En la skin Native, al cambiar de pestana la pantalla vieja se desvanece y se desliza un poco hacia el " +
        "lado, y la nueva entra deslizandose con fundido. El mini reproductor y la barra de abajo no se mueven. Desmarcalo para volver al " +
        "cambio seco.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val xs6 = mutableClassDefBy(classDefBy("Lxs6;"))
        val l = xs6.methods.singleOrNull {
            it.name == "l" && it.returnType == "V" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0] == "Lcy6;"
        } ?: error("Native pestanas: no se encontro Lxs6;->l(Lcy6;) (version de Eclipse distinta de 0.6.75?)")
        l.addInstructions(
            0,
            "invoke-static {p0, p1}, $TAB_SLIDE->before(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        val fm6 = mutableClassDefBy(classDefBy("Lfm6;"))
        val r = fm6.methods.singleOrNull { it.name == "r" && it.parameterTypes.size == 2 }
            ?: error("Native pestanas: no se encontro Lfm6;->r")
        val ins = (r.implementation ?: error("Native pestanas: Lfm6;->r sin codigo")).instructions.toList()
        fun ref(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
        val source = ins.indices.filter {
            val m = ref(it)
            m != null && m.definingClass == "Lnd4;" && m.name == "D" &&
                m.parameterTypes.map(CharSequence::toString) == listOf("Lrb6;", "Lsu4;", "Ldk3;")
        }
        if (source.size != 1) error("Native pestanas: se esperaba 1 Lnd4;->D en Lfm6;->r y hay ${source.size}")
        val k = (source[0] + 1 until ins.size).firstOrNull {
            val m = ref(it)
            m != null && m.definingClass == "Lkq0;" && m.name == "K"
        } ?: error("Native pestanas: no se encontro Lkq0;->K despues de Lnd4;->D")
        val reg = (ins[k] as FiveRegisterInstruction).registerD // segundo argumento: el Modifier
        r.addInstructions(
            k,
            """
                invoke-static { v$reg }, $TAB_SLIDE->page(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$reg
                check-cast v$reg, Lrb6;
            """
        )
    }
}
