package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val TAB_SLIDE = "Lapp/eclipse/extension/player/TabSlide;"

/**
 * v0.20.460 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Skin NATIVE: la vieja pantalla se desvanece y se desplaza al cambiar de
 * pestana. Native no tiene transicion (las pestanas son `Lcy6;`: HOME, LIBRARY, NEW, RADIO, SEARCH, y las dibuja su propio
 * navegador `Lxs6;`, no el NavHost de la skin Eclipse). Gancho: inicio de `Lxs6;->l(Lcy6;)V` (se tocó una pestana) llama a
 * `TabSlide.before(Lxs6, Lcy6)`, que toma una captura (PixelCopy) y la desvanece/desplaza encima. Si algo falla no hace nada.
 */
@Suppress("unused")
val tabSlidePatch = bytecodePatch(
    name = "Native: pestanas con desvanecido y desplazamiento",
    description = "En la skin Native, al cambiar de pestana la pantalla vieja se desvanece y se desliza un poco hacia el " +
        "lado, y la nueva queda debajo. El mini reproductor y la barra de abajo no se mueven. Desmarcalo para volver al " +
        "cambio seco.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val xs6 = mutableClassDefBy(classDefBy("Lxs6;"))
        val l = xs6.methods.singleOrNull {
            it.name == "l" && it.returnType == "V" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0] == "Lcy6;"
        } ?: error("Native pestanas: no se encontro Lxs6;->l(Lcy6;) (version de Eclipse distinta de 0.6.75?)")
        l.addInstructions(
            0,
            "invoke-static {p0, p1}, $TAB_SLIDE->before(Ljava/lang/Object;Ljava/lang/Object;)V"
        )
    }
}
