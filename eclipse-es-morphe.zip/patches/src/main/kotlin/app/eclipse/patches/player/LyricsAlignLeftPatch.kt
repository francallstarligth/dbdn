package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

/**
 * v0.20.119 (SIN COMPILAR / SIN PROBAR). iw4.k (la lista de letras de Eclipse, leido en el smali del APK Base) calcula la
 * alineacion del texto de cada linea (TextAlign de Compose: 3 = centro, 5 = inicio/izquierda, 6 = final/derecha):
 * si la voz es "Other(index)" -> 6 si el indice es impar, 5 si es par; si la voz es Lead o Background -> 3 (centro).
 * Por eso la voz principal sale centrada. Aqui, justo despues de `const/4 v1, 0x3` (que va seguido de un goto) se vuelve a
 * escribir `const/4 v1, 0x5` en el mismo registro: la voz principal queda pegada a la izquierda y la otra voz sigue a la
 * derecha. Falla con error claro si no encuentra exactamente 1 sitio (version distinta de Eclipse).
 */
@Suppress("unused")
val lyricsAlignLeftPatch = bytecodePatch(
    description = "La voz principal de la letra va pegada a la izquierda (antes salia centrada) y la otra voz sigue a la " +
        "derecha. Desmarcalo si prefieres el centrado original de Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val iw4 = mutableClassDefBy(classDefBy("Ldo5;"))
        val k = iw4.methods.singleOrNull {
            it.name == "k" && it.parameterTypes.size == 4 && it.parameterTypes.all { p -> p.toString() == "Ljava/lang/Object;" }
        } ?: error("No se encontro do5.k (version de Eclipse distinta de 0.6.70?)")
        val list = (k.implementation ?: error("do5.k sin codigo")).instructions.toList()

        val hits = list.indices.filter { i ->
            val ins = list[i]
            ins.opcode == Opcode.CONST_4 &&
                (ins as NarrowLiteralInstruction).narrowLiteral == 3 &&
                i + 1 < list.size &&
                (list[i + 1].opcode == Opcode.GOTO || list[i + 1].opcode == Opcode.GOTO_16 || list[i + 1].opcode == Opcode.GOTO_32)
        }
        if (hits.size != 1) error("do5.k: se esperaba 1 'const/4 vX, 0x3' seguido de goto y hay ${hits.size}")
        // 0.6.55: el registro ya no es v1 (ahora v6): se toma el del hit (const/4 admite v0..v15).
        val r = (list[hits[0]] as OneRegisterInstruction).registerA
        if (r > 15) error("do5.k: registro v$r fuera de rango para const/4")
        k.addInstructions(hits[0] + 1, "const/4 v$r, 0x5")
    }
}
