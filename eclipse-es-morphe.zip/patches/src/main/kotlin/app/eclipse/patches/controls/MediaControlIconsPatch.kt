package app.eclipse.patches.controls

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.resourcePatch

/**
 * Iconos de adelantar/retroceder de la notificacion, la pantalla de bloqueo y el centro de control.
 * Eclipse usa los iconos estandar de Media3 (media3_icon_previous / media3_icon_next): una barra fina y un
 * triangulo que ocupan solo la mitad del cuadro, por eso se ven pequenos y delgados. Aqui se cambian por
 * un doble triangulo grueso y redondeado (estilo YouTube). Solo se usan en esas superficies del sistema:
 * el reproductor dentro de la app dibuja sus propios iconos (la unica clase que referencia estos
 * recursos es la que arma la notificacion).
 */
private fun vector(pathData: String) = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    <path
        android:fillColor="@android:color/white"
        android:strokeColor="@android:color/white"
        android:strokeWidth="60"
        android:strokeLineJoin="round"
        android:pathData="$pathData" />
</vector>
"""

// Doble triangulo hacia la derecha (siguiente) y su espejo (anterior), alrededor de x = 480.
// v1.11.1: mas grande (ocupa ~90% del cuadro; en v1.11.0 ocupaba ~70% de ancho y ~55% de alto).
private const val NEXT_PATH = "M80,130L80,830L490,480Z M470,130L470,830L880,480Z"
private const val PREVIOUS_PATH = "M880,130L880,830L470,480Z M490,130L490,830L80,480Z"

@Suppress("unused")
val mediaControlIconsPatch = resourcePatch(
    name = "Controles de notificacion estilo YouTube",
    description = "Cambia los iconos de anterior/siguiente de la notificacion, la pantalla de bloqueo y el " +
        "centro de control por un doble triangulo mas grande y grueso (como YouTube). No cambia el " +
        "reproductor dentro de la app.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        get("res/drawable-anydpi/media3_icon_next.xml").writeText(vector(NEXT_PATH))
        get("res/drawable-anydpi/media3_icon_previous.xml").writeText(vector(PREVIOUS_PATH))
    }
}
