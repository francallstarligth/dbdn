package app.eclipse.patches.controls

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.resourcePatch

/**
 * Iconos de adelantar/retroceder de la notificacion, la pantalla de bloqueo y el centro de control.
 * Eclipse usa los iconos estandar de Media3 (media3_icon_previous / media3_icon_next): una barra fina y un
 * triangulo que ocupan solo la mitad del cuadro, por eso se ven pequenos y delgados. Aqui se cambian por
 * un doble triangulo grueso y redondeado (estilo YouTube). Solo se usan en esas superficies del sistema:
 * el reproductor dentro de la app dibuja sus propios iconos (la unica clase que referencia estos
 * recursos es la que arma la notificacion).
 */
private fun vector(pathData: String) = """<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="24dp"
    android:height="24dp"
    android:viewportWidth="960"
    android:viewportHeight="960">
    <path
        android:fillColor="@android:color/white"
        android:strokeColor="@android:color/white"
        android:strokeWidth="60"
        android:strokeLineJoin="round"
        android:pathData="$pathData" />
</vector>
"""

// Doble triangulo hacia la derecha (siguiente) y su espejo (anterior), alrededor de x = 480.
private const val NEXT_PATH = "M170,220L170,740L500,480Z M480,220L480,740L810,480Z"
private const val PREVIOUS_PATH = "M790,220L790,740L460,480Z M480,220L480,740L150,480Z"

@Suppress("unused")
val mediaControlIconsPatch = resourcePatch(
    name = "Controles de notificacion estilo YouTube",
    description = "Cambia los iconos de anterior/siguiente de la notificacion, la pantalla de bloqueo y el " +
        "centro de control por un doble triangulo mas grande y grueso (como YouTube). No cambia el " +
        "reproductor dentro de la app.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        get("res/drawable-anydpi/media3_icon_next.xml").writeText(vector(NEXT_PATH))
        get("res/drawable-anydpi/media3_icon_previous.xml").writeText(vector(PREVIOUS_PATH))
    }
}
