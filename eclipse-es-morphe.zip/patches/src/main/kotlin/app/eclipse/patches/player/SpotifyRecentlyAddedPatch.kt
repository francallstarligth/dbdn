package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * Modo Spotify de Eclipse 0.6.47: la pantalla de playlist (r18.d) ordena con su PROPIO codigo (enum bh8, preferencia
 * "spotifySkin.playlistSort_"). Para RECENTLY_ADDED solo hace z91.N0(lista) = dar vuelta la lista (asume que la ultima
 * cancion del orden de la playlist es la mas nueva). El modo Eclipse, en cambio, usa ra2.h(lista, go6.RecentlyAdded):
 * ordena por la fecha real (Song.addedAt) y solo da vuelta la lista si ninguna cancion tiene fecha.
 *
 * Arreglo: en r18.d se cambia ese z91.N0(lista) por ra2.h(lista, go6.RecentlyAdded), asi los dos modos dan el mismo orden.
 * Es la unica llamada a z91.N0 en r18.d (las otras ramas usan z91.T0 con comparadores).
 */
@Suppress("unused")
val spotifyRecentlyAddedPatch = bytecodePatch(
    name = "Modo Spotify: 'Agregado recientemente' por fecha",
    description = "En el modo Spotify, 'Recently added' solo daba vuelta la playlist. Ahora ordena por la fecha " +
        "en que agregaste cada cancion, igual que el modo Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val r18 = mutableClassDefBy(classDefBy("Lr18;"))
        val method = r18.methods.firstOrNull {
            it.name == "d" && it.parameterTypes.size == 3 && it.parameterTypes[0].toString() == "Lx18;"
        } ?: error("No se encontro r18.d")

        val ins = (method.implementation ?: error("r18.d sin codigo")).instructions.toList()
        val n0 = ins.indexOfFirst { i ->
            if (i.opcode != Opcode.INVOKE_STATIC) return@indexOfFirst false
            val ref = (i as ReferenceInstruction).reference as? MethodReference ?: return@indexOfFirst false
            ref.definingClass == "Lz91;" && ref.name == "N0" &&
                ref.parameterTypes.map { it.toString() } == listOf("Ljava/lang/Iterable;")
        }
        if (n0 < 0) error("r18.d: no se encontro z91.N0 (orden RECENTLY_ADDED)")
        if (ins.count { i ->
                i.opcode == Opcode.INVOKE_STATIC &&
                    ((i as ReferenceInstruction).reference as? MethodReference)?.let { it.definingClass == "Lz91;" && it.name == "N0" } == true
            } != 1
        ) error("r18.d: hay mas de una llamada a z91.N0")

        val listReg = (ins[n0] as FiveRegisterInstruction).registerC
        val destIns = ins[n0 + 1]
        if (destIns.opcode != Opcode.MOVE_RESULT_OBJECT) error("r18.d: falta move-result-object despues de z91.N0")
        val destReg = (destIns as OneRegisterInstruction).registerA
        // Instrucciones no-range: solo v0..v15. El destino se usa de registro temporal para el enum.
        if (listReg > 15 || destReg > 15) error("r18.d: registros fuera de v0..v15 (lista v$listReg, destino v$destReg)")
        if (listReg == destReg) error("r18.d: lista y destino son el mismo registro")

        method.addInstructions(
            n0,
            """
                sget-object v$destReg, Lgo6;->RecentlyAdded:Lgo6;
                invoke-static {v$listReg, v$destReg}, Lra2;->h(Ljava/util/List;Lgo6;)Ljava/util/List;
            """
        )
        // La llamada vieja a z91.N0 quedo 2 instrucciones mas abajo; se quita (su move-result-object recibe ahora ra2.h).
        method.removeInstruction(n0 + 2)
    }
}
