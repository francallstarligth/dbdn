package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val DIAG = "Lapp/eclipse/extension/player/BadgeDiag;"

private fun isString(ins: Instruction, value: String): Boolean {
    if (ins.opcode != Opcode.CONST_STRING && ins.opcode != Opcode.CONST_STRING_JUMBO) return false
    val ref = (ins as ReferenceInstruction).reference as? StringReference ?: return false
    return ref.string == value
}

private fun isEmptyModifier(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.SGET_OBJECT) return false
    val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return false
    return ref.definingClass == "Ljh5;" && ref.name == "q"
}

@Suppress("unused")
val badgeDiagPatch = bytecodePatch(
    name = "Diagnostico: icono de calidad",
    description = "TEMPORAL. Agrega al final del texto del Quality Badge [calidad|modo del icono|icon o NOICON] " +
        "para ver por que no sale el icono con una cancion real.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Ldi6;"))
        val method = cls.methods.firstOrNull { m ->
            m.name == "t" && m.parameterTypes.map { it.toString() } ==
                listOf("I", "Ldw0;", "Low0;", "Lki1;", "Lt43;", "Z")
        } ?: error("No se encontro di6.t")

        val list = (method.implementation ?: error("di6.t sin codigo")).instructions.toList()

        val strIdx = list.indices.filter { isString(list[it], "badge.lossless") }
        if (strIdx.size != 1) error("di6.t: se esperaba 1 \"badge.lossless\" y hay ${strIdx.size}")

        val hookIdx = (strIdx[0] + 1 until minOf(strIdx[0] + 12, list.size)).filter { isEmptyModifier(list[it]) }
        if (hookIdx.isEmpty()) error("di6.t: no se encontro el Modifier vacio tras el icono")

        // v6 = calidad (lz6), v7 = nombre/modo del icono, v2 = icono (do3 o null), v41 = texto del badge
        method.addInstructions(
            hookIdx[0],
            """
                invoke-static {v6, v7, v2}, $DIAG->set(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
                invoke-static/range {v41 .. v41}, $DIAG->text(Ljava/lang/String;)Ljava/lang/String;
                move-result-object v41
            """
        )
    }
}
