package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val COVER_FADE = "Lapp/eclipse/extension/artwork/CoverFade;"

/**
 * v0.20.15. Interruptor del comportamiento "con Canvas, el fondo borroso (reflejo) se comporta como en las canciones sin
 * Canvas". Todo el codigo vive en la extension (CoverFade/BlurredCanvasBackground) y solo actua si este parche esta
 * activo: este parche solo agrega UNA llamada al inicio de xi6.h que enciende el interruptor. Si falla, se desmarca y
 * queda el comportamiento de la v0.20.11 (portada nueva encima durante el retraso).
 */
@Suppress("unused")
val keepBackgroundCanvasPatch = bytecodePatch(
    name = "Canvas: mantener el fondo anterior (reflejo)",
    description = "En canciones con portada animada (Canvas), mientras el video espera, no se pone la portada nueva " +
        "encima del fondo borroso/reflejo: se ve el mismo fondo que en las canciones sin Canvas (que se queda con la " +
        "imagen anterior hasta cargar la nueva). Necesita \"Portadas animadas sin parpadeo\" y \"Custom: Canvas detras " +
        "del fondo Blurred Cover\". Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // xi6.h(String, boolean, Modifier, Composer, int): crea el video del Canvas. Al inicio se enciende el interruptor.
        val xi6 = mutableClassDefBy(classDefBy("Lxi6;"))
        var hooked = 0
        for (method in xi6.methods) {
            if (method.name != "h") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Z", "Lmh5;", "Lki1;", "I")) continue
            if (method.implementation == null) continue
            method.addInstructions(0, "invoke-static {}, $COVER_FADE->enableKeepBg()V")
            hooked++
        }
        if (hooked != 1) error("No se encontro xi6.h(String, boolean, Modifier, Composer, int)")
    }
}
