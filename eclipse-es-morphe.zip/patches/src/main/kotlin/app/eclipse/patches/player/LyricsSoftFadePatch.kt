package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/**
 * v0.20.94 (SIN COMPILAR / SIN PROBAR). lf2.H (la fila de letra de Eclipse) anima dos cosas con un tween:
 *  - "lyricAlpha": la transparencia de la linea segun su distancia a la activa (1.0 / 0.75 / 0.5 / 0.3 / 0.2). Dura 250 ms
 *    (`const/16 v15, 0xfa` -> w46.G(duracion, retraso, easing) -> kr.b(..., "lyricAlpha")). Por eso la linea que acaba de
 *    cantarse se apaga rapido.
 *  - "lyricEmphasis": el agrandado (1.05) de la linea activa. Dura 220 ms (`const/16 v6, 0xdc`, nombre "lyricEmphasis").
 * Aqui se alargan: alpha a 450 ms y emphasis a 380 ms. Se busca cada constante (const/16 con ese valor) que tenga la
 * cadena con el nombre dentro de las 40 instrucciones siguientes, y justo despues se vuelve a escribir en el mismo
 * registro el valor nuevo (antes de que se use). Si no encuentra algo, error (version distinta de Eclipse).
 */
@Suppress("unused")
val lyricsSoftFadePatch = bytecodePatch(
    description = "La linea que ya se canto (y las lejanas) se apagan y se achican mas despacio, en vez de cortarse rapido. " +
        "Desmarcalo si prefieres el cambio rapido original de Eclipse.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val lf2 = mutableClassDefBy(classDefBy("Loy1;"))
        val h = lf2.methods.singleOrNull {
            it.name == "D" && it.parameterTypes.size == 23 && it.parameterTypes[0].toString() == "Lg55;"
        } ?: error("No se encontro ny1.D (version de Eclipse distinta de 0.6.55?)")
        val list = (h.implementation ?: error("ny1.D sin codigo")).instructions.toList()

        fun findConst(value: Int, tag: String): Pair<Int, Int> {
            val hits = list.indices.filter { i ->
                val ins = list[i]
                if (ins.opcode != Opcode.CONST_16 || (ins as NarrowLiteralInstruction).narrowLiteral != value) return@filter false
                (i + 1 until minOf(list.size, i + 41)).any { j ->
                    val r = (list[j] as? ReferenceInstruction)?.reference as? StringReference
                    list[j].opcode == Opcode.CONST_STRING && r != null && r.string == tag
                }
            }
            if (hits.size != 1) error("ny1.D: se esperaba 1 const/16 $value junto a \"$tag\" y hay ${hits.size}")
            return hits[0] to (list[hits[0]] as OneRegisterInstruction).registerA
        }

        val alpha = findConst(0xfa, "lyricAlpha")
        val emph = findConst(0xdc, "lyricEmphasis")
        // Primero el indice mas alto, para que el otro no se mueva. v0..v15 se pueden usar en const/16.
        fun reg(r: Int) = if (r <= 15) "v$r" else error("registro v$r fuera de rango para const/16")
        val first = if (alpha.first > emph.first) alpha to 450 else emph to 380
        val second = if (alpha.first > emph.first) emph to 380 else alpha to 450
        for ((p, ms) in listOf(first, second)) {
            h.addInstructions(p.first + 1, "const/16 ${reg(p.second)}, $ms")
        }
    }
}
