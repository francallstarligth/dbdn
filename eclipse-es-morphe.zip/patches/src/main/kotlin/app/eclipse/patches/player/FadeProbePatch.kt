package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.Method
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val FADE_PROBE = "Lapp/eclipse/extension/artwork/FadeProbe;"

/** Nombre del registro para el smali: vN si es local, pN si es parametro. */
private fun regName(reg: Int, method: Method): String {
    val impl = method.implementation ?: error("sin codigo")
    var paramWords = if (method.accessFlags and 0x8 != 0) 0 else 1
    for (t in method.parameterTypes) paramWords += if (t.toString() == "J" || t.toString() == "D") 2 else 1
    val firstParam = impl.registerCount - paramWords
    return if (reg < firstParam) "v$reg" else "p${reg - firstParam}"
}

@Suppress("unused")
val fadeProbePatch = bytecodePatch(
    name = "Diagnostico: degradado del edge fade",
    description = "Solo para pruebas. Anota en el portapapeles los colores y la posicion del degradado del edge fade " +
        "cuando cambia la portada (para entender la raya a la mitad). No cambia nada visible. Apagalo despues de la prueba.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // bd6.invoke (caso del edgeFade): justo antes de hd2.S0 (drawRect, 11 registros en invoke/range) se llama a
        // FadeProbe.probe(pincel, topLeft, size) con los registros +1 (pincel), +2/+3 (topLeft J), +4/+5 (size J).
        val bd6 = mutableClassDefBy(classDefBy("Lbd6;"))
        var patched = 0
        for (method in bd6.methods) {
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val castIdx = list.indexOfFirst { ins ->
                ins.opcode == Opcode.CHECK_CAST &&
                    ((ins as ReferenceInstruction).reference as? TypeReference)?.type == "Ljh2;"
            }
            if (castIdx < 0) continue
            val callIdx = (castIdx until list.size).firstOrNull { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null && ref.definingClass == "Lhd2;" && ref.name == "S0"
            } ?: continue
            val call = list[callIdx]
            if (call !is RegisterRangeInstruction) error("bd6: hd2.S0 no es invoke/range")
            if (call.registerCount != 11) error("bd6: hd2.S0 con ${call.registerCount} registros (se esperaban 11)")
            val first = regName(call.startRegister + 1, method)
            val last = regName(call.startRegister + 5, method)
            if (first[0] != last[0]) error("bd6: los registros del drawRect mezclan locales y parametros")
            method.addInstructions(
                callIdx,
                "invoke-static/range {$first .. $last}, $FADE_PROBE->probe(Ljava/lang/Object;JJ)V"
            )
            patched++
            break
        }
        if (patched == 0) error("No se encontro el dibujo del edgeFade en bd6")
    }
}
