package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

/** Layout "view_animated_artwork_texture" (un PlayerView con TextureView) en 0.6.55. */
private const val ANIMATED_LAYOUT_ID = 0x7f0d005c

@Suppress("unused")
val animatedCoverNoFlashPatch = bytecodePatch(
    description = "Evita el destello negro al pasar de la portada fija a la animada mientras el video aun no " +
        "tiene su primer cuadro: la portada fija se queda visible hasta que el video esta listo y luego se " +
        "desvanece (cruce suave).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // np7.H(Context): infla el layout de la portada animada y devuelve el PlayerView.
        // PlayerView trae una "cortina" (shutter) negra que tapa la portada fija hasta el primer cuadro: se hace transparente.
        val mutable = mutableClassDefBy(classDefBy("Lnp7;"))

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Landroidx/media3/ui/PlayerView;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()

            val inflatesAnimatedLayout = list.any { ins ->
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == ANIMATED_LAYOUT_ID
            }
            if (!inflatesAnimatedLayout) continue

            val returnIndex = list.indexOfLast { it.opcode == Opcode.RETURN_OBJECT }
            if (returnIndex < 0) continue

            // np7.H tiene .locals 3: v0 esta libre al final; p0 es el PlayerView ya convertido (check-cast).
            method.addInstructions(
                returnIndex,
                """
                    const/4 v0, 0x0
                    invoke-virtual {p0, v0}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro np7.H(Context) con el layout de la portada animada")

        // 2) Fundido: la vista queda casi invisible hasta el primer cuadro del video (ver CoverFade).
        //    En 0.6.55 el PlayerView lo crean 3 fabricas (y70, fx5, v37; invoke(Object)) llamando a np7.H(Context): tras el
        //    move-result-object se busca el primer `return-object` de ESE registro y justo antes se llama CoverFade.prepare.
        //    La clase `n` (otro caso de np7.H, el que fija su propia transparencia) queda sin tocar, como en 0.6.47.
        var faded = 0
        for (cls in listOf("Ly70;", "Lfx5;", "Lv37;")) {
            val vf = mutableClassDefBy(classDefBy(cls))
            for (method in vf.methods) {
                if (method.name != "invoke" || method.returnType != "Ljava/lang/Object;") continue
                if (method.parameterTypes.map { it.toString() } != listOf("Ljava/lang/Object;")) continue
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()

                val calls = list.indices.filter { i ->
                    val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                    ref != null && ref.definingClass == "Lnp7;" && ref.name == "H" &&
                        i + 1 < list.size && list[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT
                }
                val inserts = ArrayList<Pair<Int, Int>>() // (indice del return, registro de la vista)
                for (c in calls) {
                    val reg = (list[c + 1] as OneRegisterInstruction).registerA
                    var ret = -1
                    for (j in c + 2 until list.size) {
                        val ins = list[j]
                        if (ins.opcode == Opcode.RETURN_OBJECT && (ins as OneRegisterInstruction).registerA == reg) { ret = j; break }
                        // si algo reescribe el registro antes del return, no es el mismo PlayerView
                        if (ins.opcode.setsRegister() && (ins as? OneRegisterInstruction)?.registerA == reg) break
                    }
                    if (ret >= 0) inserts.add(ret to reg)
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for ((ret, reg) in inserts.sortedByDescending { it.first }) {
                    method.addInstructions(
                        ret,
                        "invoke-static/range {v$reg .. v$reg}, Lapp/eclipse/extension/artwork/CoverFade;->prepare(Landroid/view/View;)V"
                    )
                    faded++
                }
            }
        }
        if (faded != 3) error("Se esperaban 3 fabricas del PlayerView de la portada animada (y70, fx5, v37) y hay $faded")

        // 3) v1.56.0: Eclipse dibuja el video EN LUGAR de la portada fija. Para poder dejar la portada debajo del video
        //    hasta su primer cuadro, se recuerda la portada de la cancion actual: tras cada lectura de e21.w (URL del
        //    Canvas; solo la lee quien va a dibujar el Canvas, en todos los estilos) se llama a CoverUnderlay.seen(e21).
        var seenHooks = 0
        for (cls in listOf("Ld97;", "Lj87;", "Ln97;")) {
            val mutableCls = mutableClassDefBy(classDefBy(cls))
            for (method in mutableCls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val reads = list.indices.filter { i ->
                    val ins = list[i]
                    if (ins.opcode != Opcode.IGET_OBJECT) return@filter false
                    val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
                    ref != null && ref.definingClass == "Le21;" && ref.name == "w"
                }
                for (i in reads.reversed()) {
                    val ins = list[i] as TwoRegisterInstruction
                    val srcReg = ins.registerB
                    // si el destino pisa a la fuente, el estado ya no esta tras la lectura
                    if (ins.registerA == srcReg) error("${cls}.${method.name}: iget-object e21.w pisa su propio origen (v$srcReg)")
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$srcReg .. v$srcReg}, " +
                            "Lapp/eclipse/extension/artwork/CoverUnderlay;->seen(Ljava/lang/Object;)V"
                    )
                    seenHooks++
                }
            }
        }
        if (seenHooks != 5) error("Se esperaban 5 lecturas de e21.w (URL del Canvas) en d97/j87/n97 y hay $seenHooks")

        // 4) v1.57.0: el video (d97.h -> kw0.f) NO dibuja nada hasta que reporta el primer cuadro (recien ahi compone el
        //    PlayerView). Ese hueco es el parpadeo. En 0.6.55 d97.h(String, Z, kt5, fp1, I) SOLO delega en
        //    kw0.f(String, kt5, Z, I, I, Z, kd3, fp1, I, I), que llaman 7 sitios: se enciende una bandera alrededor del
        //    llamado de d97.h y, en la rama "aun sin primer cuadro" de kw0.f (la que abre el grupo con la constante
        //    -0x2150 ... -559566239, seguida de lp1.d0(I)V y un goto), se dibuja la portada. kw0.f es estatico: p1 = modifier
        //    (kt5) y p7 = composer (fp1) NO se escriben nunca en el metodo (verificado), asi que se leen directo.
        val kw0 = mutableClassDefBy(classDefBy("Lkw0;"))
        var holeHooks = 0
        for (method in kw0.methods) {
            if (method.name != "f") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Lkt5;", "Z", "I", "I", "Z", "Lkd3;", "Lfp1;", "I", "I")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val idx = list.indices.filter { i ->
                val ins = list[i]
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == -559566239 &&
                    i + 2 < list.size && list[i + 1].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((list[i + 1] as ReferenceInstruction).reference as? MethodReference)?.name == "d0" &&
                    (list[i + 2].opcode == Opcode.GOTO || list[i + 2].opcode == Opcode.GOTO_16 || list[i + 2].opcode == Opcode.GOTO_32)
            }
            if (idx.size != 1) error("kw0.f: se esperaba 1 rama de espera, hay ${idx.size}")
            val first = impl.registerCount - 10      // p0
            val modReg = first + 1                   // p1 = modifier (kt5)
            val compReg = first + 7                  // p7 = composer (fp1)
            if (modReg != 21 || compReg != 27) error("kw0.f: registros inesperados (modifier=v$modReg, composer=v$compReg)")
            // Despues del d0 (abre el grupo) y antes del goto que lo cierra.
            method.addInstructions(
                idx[0] + 2,
                """
                    invoke-static/range {v$modReg .. v$modReg}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeMod(Ljava/lang/Object;)V
                    invoke-static/range {v$compReg .. v$compReg}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeDraw(Ljava/lang/Object;)V
                """
            )
            holeHooks++
        }
        if (holeHooks != 1) error("No se encontro kw0.f(String, Modifier, Z, I, I, Z, kd3, Composer, I, I)")

        // 4b) bandera: solo el llamado desde d97.h (portada del Canvas) puede dibujar el hueco.
        val d97 = mutableClassDefBy(classDefBy("Ld97;"))
        var flagged = 0
        for (method in d97.methods) {
            if (method.name != "h") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Z", "Lkt5;", "Lfp1;", "I")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val calls = list.indices.filter { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null && ref.definingClass == "Lkw0;" && ref.name == "f" && list[i].opcode == Opcode.INVOKE_STATIC_RANGE
            }
            if (calls.size != 1) error("d97.h: se esperaba 1 llamado a kw0.f (hay ${calls.size})")
            val c = calls[0]
            // Primero el de despues (no corre el indice anterior).
            method.addInstructions(c + 1, "invoke-static {}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeExit()V")
            method.addInstructions(c, "invoke-static {}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeEnter()V")
            flagged++
        }
        if (flagged != 1) error("No se encontro d97.h(String, boolean, Modifier, Composer, int)")
    }
}
