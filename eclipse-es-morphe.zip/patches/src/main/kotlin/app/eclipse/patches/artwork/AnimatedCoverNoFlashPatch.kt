package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction

/** Layout "view_animated_artwork_texture" (un PlayerView con TextureView) en 0.6.47. */
private const val ANIMATED_LAYOUT_ID = 0x7f0d005c

@Suppress("unused")
val animatedCoverNoFlashPatch = bytecodePatch(
    name = "Portadas animadas sin parpadeo",
    description = "Evita el destello negro al pasar de la portada fija a la animada mientras el video aun no " +
        "tiene su primer cuadro: la portada fija se queda visible hasta que el video esta listo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // hz7.m(Context): infla el layout de la portada animada y devuelve el PlayerView.
        // PlayerView trae una "cortina" (shutter) negra que tapa la portada fija hasta el primer cuadro: se hace transparente.
        val mutable = mutableClassDefBy(classDefBy("Lhz7;"))

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Landroidx/media3/ui/PlayerView;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()

            val inflatesAnimatedLayout = list.any { ins ->
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == ANIMATED_LAYOUT_ID
            }
            if (!inflatesAnimatedLayout) continue

            val returnIndex = list.indexOfLast { it.opcode == Opcode.RETURN_OBJECT }
            if (returnIndex < 0) continue

            // hz7.m tiene .locals 3: v0 esta libre al final; p0 es el PlayerView ya convertido (check-cast).
            method.addInstructions(
                returnIndex,
                """
                    const/4 v0, 0x0
                    invoke-virtual {p0, v0}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro hz7.m(Context) con el layout de la portada animada")

        // 2) Fundido: la vista queda casi invisible hasta el primer cuadro del video (ver CoverFade).
        //    La fabrica de vistas vw.invoke(Object) crea ese PlayerView en varios casos; se toca cada caso que termina en
        //    "setResizeMode(I) ; return-object p1". El caso que fija su propia transparencia (setAlpha 0.6) no cumple
        //    ese patron (hay un setAlpha entre medias) y queda sin tocar.
        val vw = mutableClassDefBy(classDefBy("Lvw;"))
        var faded = 0
        for (method in vw.methods) {
            if (method.name != "invoke" || method.returnType != "Ljava/lang/Object;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Ljava/lang/Object;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            // p1 (el parametro Object, o sea el Context/Scope de entrada) es el ultimo registro del metodo.
            val p1Register = impl.registerCount - 1

            val targets = list.indices.filter { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null &&
                    ref.definingClass == "Landroidx/media3/ui/PlayerView;" &&
                    ref.name == "setResizeMode" &&
                    i + 1 < list.size &&
                    list[i + 1].opcode == Opcode.RETURN_OBJECT &&
                    (list[i + 1] as OneRegisterInstruction).registerA == p1Register
            }
            // De atras hacia adelante: insertar no corre los indices anteriores.
            for (i in targets.reversed()) {
                method.addInstructions(
                    i + 1,
                    "invoke-static {p1}, Lapp/eclipse/extension/artwork/CoverFade;->prepare(Landroid/view/View;)V"
                )
                faded++
            }
        }
        if (faded == 0) error("No se encontro el lugar donde vw crea el PlayerView de la portada animada")
    }
}
