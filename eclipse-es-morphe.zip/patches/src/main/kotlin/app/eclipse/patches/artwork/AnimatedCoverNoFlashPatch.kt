package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

/** Layout "view_animated_artwork_texture" (un PlayerView con TextureView) en 0.6.47. */
private const val ANIMATED_LAYOUT_ID = 0x7f0d005c

@Suppress("unused")
val animatedCoverNoFlashPatch = bytecodePatch(
    description = "Evita el destello negro al pasar de la portada fija a la animada mientras el video aun no " +
        "tiene su primer cuadro: la portada fija se queda visible hasta que el video esta listo y luego se " +
        "desvanece (cruce suave).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // hz7.m(Context): infla el layout de la portada animada y devuelve el PlayerView.
        // PlayerView trae una "cortina" (shutter) negra que tapa la portada fija hasta el primer cuadro: se hace transparente.
        val mutable = mutableClassDefBy(classDefBy("Lhz7;"))

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Landroidx/media3/ui/PlayerView;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()

            val inflatesAnimatedLayout = list.any { ins ->
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == ANIMATED_LAYOUT_ID
            }
            if (!inflatesAnimatedLayout) continue

            val returnIndex = list.indexOfLast { it.opcode == Opcode.RETURN_OBJECT }
            if (returnIndex < 0) continue

            // hz7.m tiene .locals 3: v0 esta libre al final; p0 es el PlayerView ya convertido (check-cast).
            method.addInstructions(
                returnIndex,
                """
                    const/4 v0, 0x0
                    invoke-virtual {p0, v0}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro hz7.m(Context) con el layout de la portada animada")

        // 2) Fundido: la vista queda casi invisible hasta el primer cuadro del video (ver CoverFade).
        //    La fabrica de vistas vw.invoke(Object) crea ese PlayerView en varios casos; se toca cada caso que termina en
        //    "setResizeMode(I) ; return-object p1". El caso que fija su propia transparencia (setAlpha 0.6) no cumple
        //    ese patron (hay un setAlpha entre medias) y queda sin tocar.
        val vw = mutableClassDefBy(classDefBy("Lvw;"))
        var faded = 0
        for (method in vw.methods) {
            if (method.name != "invoke" || method.returnType != "Ljava/lang/Object;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Ljava/lang/Object;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            // p1 (el parametro Object, o sea el Context/Scope de entrada) es el ultimo registro del metodo.
            val p1Register = impl.registerCount - 1

            val targets = list.indices.filter { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null &&
                    ref.definingClass == "Landroidx/media3/ui/PlayerView;" &&
                    ref.name == "setResizeMode" &&
                    i + 1 < list.size &&
                    list[i + 1].opcode == Opcode.RETURN_OBJECT &&
                    (list[i + 1] as OneRegisterInstruction).registerA == p1Register
            }
            // De atras hacia adelante: insertar no corre los indices anteriores.
            for (i in targets.reversed()) {
                method.addInstructions(
                    i + 1,
                    "invoke-static {p1}, Lapp/eclipse/extension/artwork/CoverFade;->prepare(Landroid/view/View;)V"
                )
                faded++
            }
        }
        if (faded == 0) error("No se encontro el lugar donde vw crea el PlayerView de la portada animada")

        // 3) v1.56.0: Eclipse dibuja el video EN LUGAR de la portada fija. Para poder dejar la portada debajo del video
        //    hasta su primer cuadro, se recuerda la portada de la cancion actual: tras cada lectura de ow0.w (URL del
        //    Canvas; solo la lee quien va a dibujar el Canvas, en todos los estilos) se llama a CoverUnderlay.seen(ow0).
        var seenHooks = 0
        for (cls in listOf("Lxi6;", "Ldi6;", "Lhj6;")) {
            val mutableCls = mutableClassDefBy(classDefBy(cls))
            for (method in mutableCls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val reads = list.indices.filter { i ->
                    val ins = list[i]
                    if (ins.opcode != Opcode.IGET_OBJECT) return@filter false
                    val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
                    ref != null && ref.definingClass == "Low0;" && ref.name == "w"
                }
                for (i in reads.reversed()) {
                    val srcReg = (list[i] as TwoRegisterInstruction).registerB
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$srcReg .. v$srcReg}, " +
                            "Lapp/eclipse/extension/artwork/CoverUnderlay;->seen(Ljava/lang/Object;)V"
                    )
                    seenHooks++
                }
            }
        }
        if (seenHooks == 0) error("No se encontro ninguna lectura de ow0.w (URL del Canvas)")

        // 4) v1.57.0: xi6.h(url, playing, modifier, composer, int) crea su propio ExoPlayer y NO dibuja nada hasta que
        //    reporta el primer cuadro (recien ahi compone el PlayerView). Ese hueco es el parpadeo. En la rama "aun sin
        //    primer cuadro" (la que abre el grupo con la constante -0x494994d7) se dibuja la portada.
        val xi6 = mutableClassDefBy(classDefBy("Lxi6;"))
        var holeHooks = 0
        for (method in xi6.methods) {
            if (method.name != "h") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Z", "Lmh5;", "Lki1;", "I")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val idx = list.indices.filter { i ->
                val ins = list[i]
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == -0x494994d7 &&
                    i + 1 < list.size && list[i + 1].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((list[i + 1] as ReferenceInstruction).reference as? MethodReference)?.name == "c0"
            }
            if (idx.size != 1) error("xi6.h: se esperaba 1 rama de espera, hay ${idx.size}")
            // Despues del c0 (abre el grupo) y antes del goto que lo cierra. p2 = modifier, p3 = composer.
            method.addInstructions(
                idx[0] + 2,
                "invoke-static {p2, p3}, Lapp/eclipse/extension/artwork/CoverUnderlay;->drawHole(Ljava/lang/Object;Ljava/lang/Object;)V"
            )
            holeHooks++
        }
        if (holeHooks != 1) error("No se encontro xi6.h(String, boolean, Modifier, Composer, int)")
    }
}
