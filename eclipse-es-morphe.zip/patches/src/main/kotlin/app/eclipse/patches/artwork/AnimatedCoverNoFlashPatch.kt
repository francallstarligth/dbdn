package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

/** Layout "view_animated_artwork_texture" (un PlayerView con TextureView). Mismo id en 0.6.57 y 0.6.61 (2131558492). */
private const val ANIMATED_LAYOUT_ID = 0x7f0d005c

@Suppress("unused")
val animatedCoverNoFlashPatch = bytecodePatch(
    description = "Evita el destello negro al pasar de la portada fija a la animada mientras el video aun no " +
        "tiene su primer cuadro: la portada fija se queda visible hasta que el video esta listo y luego se " +
        "desvanece (cruce suave).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ua8.P(Context) (0.6.61: at7.H; 0.6.57: xr7.F): infla el layout de la portada animada y devuelve el PlayerView.
        // PlayerView trae una "cortina" (shutter) negra que tapa la portada fija hasta el primer cuadro: se hace transparente.
        val mutable = mutableClassDefBy(classDefBy("Lua8;"))

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Landroidx/media3/ui/PlayerView;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()

            val inflatesAnimatedLayout = list.any { ins ->
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == ANIMATED_LAYOUT_ID
            }
            if (!inflatesAnimatedLayout) continue

            val returnIndex = list.indexOfLast { it.opcode == Opcode.RETURN_OBJECT }
            if (returnIndex < 0) continue

            // ua8.P (0.6.70) tiene .locals 3 (4 registros, p0 = v3): v0 esta libre al final; p0 es el PlayerView ya convertido (check-cast).
            method.addInstructions(
                returnIndex,
                """
                    const/4 v0, 0x0
                    invoke-virtual {p0, v0}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro ua8.P(Context) con el layout de la portada animada (0.6.70)")

        // 2) Fundido: la vista queda casi invisible hasta el primer cuadro del video (ver CoverFade).
        //    En 0.6.70 el PlayerView lo crean 3 fabricas (aa0, y96, yy7; invoke(Object); 0.6.61: e90, t47, pu5) llamando a ua8.P(Context): tras el
        //    move-result-object se busca el primer `return-object` de ESE registro y justo antes se llama CoverFade.prepare.
        //    La clase `n` (otro caso de at7.H, el que fija su propia transparencia) queda sin tocar, como en 0.6.47.
        var faded = 0
        for (cls in listOf("Laa0;", "Ly96;", "Lyy7;")) {
            val vf = mutableClassDefBy(classDefBy(cls))
            for (method in vf.methods) {
                if (method.name != "invoke" || method.returnType != "Ljava/lang/Object;") continue
                if (method.parameterTypes.map { it.toString() } != listOf("Ljava/lang/Object;")) continue
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()

                val calls = list.indices.filter { i ->
                    val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                    ref != null && ref.definingClass == "Lua8;" && ref.name == "P" &&
                        i + 1 < list.size && list[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT
                }
                val inserts = ArrayList<Pair<Int, Int>>() // (indice del return, registro de la vista)
                for (c in calls) {
                    val reg = (list[c + 1] as OneRegisterInstruction).registerA
                    var ret = -1
                    for (j in c + 2 until list.size) {
                        val ins = list[j]
                        if (ins.opcode == Opcode.RETURN_OBJECT && (ins as OneRegisterInstruction).registerA == reg) { ret = j; break }
                        // si algo reescribe el registro antes del return, no es el mismo PlayerView
                        if (ins.opcode.setsRegister() && (ins as? OneRegisterInstruction)?.registerA == reg) break
                    }
                    if (ret >= 0) inserts.add(ret to reg)
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for ((ret, reg) in inserts.sortedByDescending { it.first }) {
                    method.addInstructions(
                        ret,
                        "invoke-static/range {v$reg .. v$reg}, Lapp/eclipse/extension/artwork/CoverFade;->prepare(Landroid/view/View;)V"
                    )
                    faded++
                }
            }
        }
        if (faded != 3) error("Se esperaban 3 fabricas del PlayerView de la portada animada (aa0, y96, yy7) y hay $faded")

        // 3) v1.56.0: Eclipse dibuja el video EN LUGAR de la portada fija. Para poder dejar la portada debajo del video
        //    hasta su primer cuadro, se recuerda la portada de la cancion actual: tras cada lectura de q31.w (URL del
        //    Canvas; solo la lee quien va a dibujar el Canvas, en todos los estilos) se llama a CoverUnderlay.seen(q31).
        var seenHooks = 0
        for (cls in listOf("Ljr7;", "Lmq7;", "Ltr7;")) {
            val mutableCls = mutableClassDefBy(classDefBy(cls))
            for (method in mutableCls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val reads = list.indices.filter { i ->
                    val ins = list[i]
                    if (ins.opcode != Opcode.IGET_OBJECT) return@filter false
                    val ref = (ins as? ReferenceInstruction)?.reference as? FieldReference
                    ref != null && ref.definingClass == "Lp51;" && ref.name == "w"
                }
                for (i in reads.reversed()) {
                    val ins = list[i] as TwoRegisterInstruction
                    val srcReg = ins.registerB
                    // si el destino pisa a la fuente, el estado ya no esta tras la lectura
                    if (ins.registerA == srcReg) error("${cls}.${method.name}: iget-object p51.w pisa su propio origen (v$srcReg)")
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$srcReg .. v$srcReg}, " +
                            "Lapp/eclipse/extension/artwork/CoverUnderlay;->seen(Ljava/lang/Object;)V"
                    )
                    seenHooks++
                }
            }
        }
        if (seenHooks != 5) error("Se esperaban 5 lecturas de p51.w (URL del Canvas) en jr7/mq7/tr7 y hay $seenHooks")

        // 0.6.70: qj4.f -> vz0.e (mismos 11 parametros: hv5->ga6, ef3->zi3, zq1->nt1), hb7.h -> jr7.h. // 0.6.61: n34.h -> qj4.f (ahora con 11 parametros: se agrego un Lef3;), ka7.h -> hb7.h, ou5/je3/cq1 -> hv5/ef3/zq1.
        // 4) v1.57.0: el video (ka7.h -> n34.f) NO dibuja nada hasta que reporta el primer cuadro (recien ahi compone el
        //    PlayerView). Ese hueco es el parpadeo. En 0.6.57 ka7.h(String, Z, ou5, cq1, I) SOLO delega en
        //    n34.f(String, ou5, Z, I, I, Z, je3, cq1, I, I), que llaman 7 sitios: se enciende una bandera alrededor del
        //    llamado de ka7.h y, en la rama "aun sin primer cuadro" de n34.f (la que abre el grupo con la constante
        //    -0x2150 ... -559566239, seguida de lp1.d0(I)V y un goto), se dibuja la portada. n34.f es estatico: p1 = modifier
        //    (ou5) y p7 = composer (cq1) NO se escriben nunca en el metodo (verificado), asi que se leen directo.
        val n34 = mutableClassDefBy(classDefBy("Lvz0;"))
        var holeHooks = 0
        for (method in n34.methods) {
            if (method.name != "e") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Lga6;", "Z", "I", "I", "Z", "Lzi3;", "Lzi3;", "Lnt1;", "I", "I")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val idx = list.indices.filter { i ->
                val ins = list[i]
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == 810987700 &&
                    i + 2 < list.size && list[i + 1].opcode == Opcode.INVOKE_VIRTUAL &&
                    ((list[i + 1] as ReferenceInstruction).reference as? MethodReference)?.name == "d0" &&
                    (list[i + 2].opcode == Opcode.GOTO || list[i + 2].opcode == Opcode.GOTO_16 || list[i + 2].opcode == Opcode.GOTO_32)
            }
            if (idx.size != 1) error("vz0.e: se esperaba 1 rama de espera, hay ${idx.size}")
            val first = impl.registerCount - 11      // p0 (0.6.70: vz0.e, 34 registros, 11 parametros -> p0 = v23)
            val modReg = first + 1                   // p1 = modifier (ga6)
            val compReg = first + 8                  // p8 = composer (nt1)
            if (modReg != 24 || compReg != 31) error("vz0.e: registros inesperados (modifier=v$modReg, composer=v$compReg)")
            // Despues del d0 (abre el grupo) y antes del goto que lo cierra.
            method.addInstructions(
                idx[0] + 2,
                """
                    invoke-static/range {v$modReg .. v$modReg}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeMod(Ljava/lang/Object;)V
                    invoke-static/range {v$compReg .. v$compReg}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeDraw(Ljava/lang/Object;)V
                """
            )
            holeHooks++
        }
        if (holeHooks != 1) error("No se encontro vz0.e(String, Modifier, Z, I, I, Z, zi3, zi3, Composer, I, I)")

        // 4b) bandera: solo el llamado desde ka7.h (portada del Canvas) puede dibujar el hueco.
        val ka7 = mutableClassDefBy(classDefBy("Ljr7;"))
        var flagged = 0
        for (method in ka7.methods) {
            if (method.name != "h") continue
            if (method.parameterTypes.map { it.toString() } !=
                listOf("Ljava/lang/String;", "Z", "Lga6;", "Lnt1;", "I")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()
            val calls = list.indices.filter { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? MethodReference
                ref != null && ref.definingClass == "Lvz0;" && ref.name == "e" && list[i].opcode == Opcode.INVOKE_STATIC_RANGE
            }
            if (calls.size != 1) error("jr7.h: se esperaba 1 llamado a vz0.e (hay ${calls.size})")
            val c = calls[0]
            // Primero el de despues (no corre el indice anterior).
            method.addInstructions(c + 1, "invoke-static {}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeExit()V")
            method.addInstructions(c, "invoke-static {}, Lapp/eclipse/extension/artwork/CoverUnderlay;->holeEnter()V")
            flagged++
        }
        if (flagged != 1) error("No se encontro jr7.h(String, boolean, Modifier, Composer, int)")
    }
}
