package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction

/** Layout "view_animated_artwork_texture" (un PlayerView con TextureView) en 0.6.47. */
private const val ANIMATED_LAYOUT_ID = 0x7f0d005c

@Suppress("unused")
val animatedCoverNoFlashPatch = bytecodePatch(
    name = "Portadas animadas sin parpadeo",
    description = "Evita el destello negro al pasar de la portada fija a la animada mientras el video aun no " +
        "tiene su primer cuadro: la portada fija se queda visible hasta que el video esta listo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // hz7.m(Context): infla el layout de la portada animada y devuelve el PlayerView.
        // PlayerView trae una "cortina" (shutter) negra que tapa la portada fija hasta el primer cuadro: se hace transparente.
        val mutable = mutableClassDefBy(classDefBy("Lhz7;"))

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Landroidx/media3/ui/PlayerView;") continue
            if (method.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")) continue
            val impl = method.implementation ?: continue
            val list = impl.instructions.toList()

            val inflatesAnimatedLayout = list.any { ins ->
                ins.opcode == Opcode.CONST && (ins as NarrowLiteralInstruction).narrowLiteral == ANIMATED_LAYOUT_ID
            }
            if (!inflatesAnimatedLayout) continue

            val returnIndex = list.indexOfLast { it.opcode == Opcode.RETURN_OBJECT }
            if (returnIndex < 0) continue

            // hz7.m tiene .locals 3: v0 esta libre al final; p0 es el PlayerView ya convertido (check-cast).
            method.addInstructions(
                returnIndex,
                """
                    const/4 v0, 0x0
                    invoke-virtual {p0, v0}, Landroidx/media3/ui/PlayerView;->setShutterBackgroundColor(I)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro hz7.m(Context) con el layout de la portada animada")
    }
}
