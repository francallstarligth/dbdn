package app.eclipse.patches.audio

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import app.morphe.patcher.util.smali.ExternalLabel

private const val EAC3 = "Lapp/eclipse/extension/audio/Eac3Soft;"
private val FFMPEG_LIBS = listOf("avutil", "swresample", "avcodec", "ffmpegJNI")

/**
 * v0.20.423 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui). Copia al APK las 4 librerias de ffmpeg (arm64) que
 * decodifican E-AC-3: son las de https://github.com/Lekuno/media3-ffmpeg-audio-android (release media3-1.8.0-ffmpeg-release-6.0-202609152256,
 * FFmpeg LGPL 2.1+, solo decodificadores de audio; fuente y licencias en esa release). Viven en patches/src/main/resources/eclipse/ffmpeg/.
 * NO verificado: que el APK final las deje cargables (extractNativeLibs / alineacion).
 */
@Suppress("unused")
val eac3SoftFilesPatch = resourcePatch(
    name = "Dolby Atmos por software: librerias",
    description = "Agrega las librerias de ffmpeg (arm64) que usa \"Dolby Atmos por software\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        for (n in FFMPEG_LIBS) {
            val bytes = object {}.javaClass.getResourceAsStream("/eclipse/ffmpeg/lib$n.so")?.use { it.readBytes() }
                ?: error("Recurso no encontrado en el parche: /eclipse/ffmpeg/lib$n.so")
            val out = get("lib/arm64-v8a/lib$n.so")
            out.parentFile?.mkdirs()
            out.writeBytes(bytes)
        }
    }
}

/**
 * v0.20.423 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui). Dolby Atmos (E-AC-3) por software.
 * Si el cel NO trae decodificador Dolby (ej. Red Magic 10 Pro), la cancion "suena" pero en silencio. `Lr7;` (Eclipse 0.6.75) es el
 * envoltorio del AudioSink que ya decodifica AC-4 por software; aqui se le agrega E-AC-3 con `Eac3Soft` (ffmpeg). Ganchos al inicio
 * de 6 metodos de `Lr7;`: B3(format)Z, M1(format,int[])V, r1(I,J,ByteBuffer)Z, flush, reset y a. Si el cel SI trae decodificador Dolby,
 * o la libreria no carga, `Eac3Soft` devuelve "no es mio" y todo sigue como antes. Apagado por defecto.
 */
@Suppress("unused")
val eac3SoftPatch = bytecodePatch(
    name = "Dolby Atmos por software (cels sin Dolby)",
    description = "En cels sin decodificador Dolby (ej. Red Magic) el Dolby Atmos (E-AC-3) sale en silencio. Este parche lo " +
        "decodifica dentro de Eclipse (sale 5.1, sin los efectos 3D). En cels con Dolby no cambia nada.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(eac3SoftFilesPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lr7;"))
        fun m(name: String, params: List<String>, ret: String) = cls.methods.singleOrNull {
            it.name == name && it.returnType == ret && it.parameterTypes.map { p -> p.toString() } == params
        } ?: error("Dolby por software: no se encontro Lr7;->$name (Eclipse 0.6.75?)")

        val b3 = m("B3", listOf("Ltg3;"), "Z")
        val m1 = m("M1", listOf("Ltg3;", "[I"), "V")
        val r1 = m("r1", listOf("I", "J", "Ljava/nio/ByteBuffer;"), "Z")
        val flush = m("flush", emptyList(), "V")
        val reset = m("reset", emptyList(), "V")
        val a = m("a", emptyList(), "V")

        b3.addInstructionsWithLabels(
            0,
            """
                invoke-static {p1}, $EAC3->supports(Ljava/lang/Object;)Z
                move-result v0
                if-eqz v0, :orig
                return v0
            """,
            ExternalLabel("orig", b3.getInstruction(0))
        )
        m1.addInstructionsWithLabels(
            0,
            """
                invoke-static {p0, p1}, $EAC3->configure(Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v0
                if-eqz v0, :orig
                return-void
            """,
            ExternalLabel("orig", m1.getInstruction(0))
        )
        r1.addInstructionsWithLabels(
            0,
            """
                invoke-static/range {p0 .. p4}, $EAC3->handle(Ljava/lang/Object;IJLjava/nio/ByteBuffer;)Z
                move-result v0
                if-eqz v0, :orig
                invoke-static {}, $EAC3->result()Z
                move-result v0
                return v0
            """,
            ExternalLabel("orig", r1.getInstruction(0))
        )
        flush.addInstructions(0, "invoke-static {}, $EAC3->flush()V")
        reset.addInstructions(0, "invoke-static {}, $EAC3->release()V")
        a.addInstructions(0, "invoke-static {}, $EAC3->release()V")
    }
}
