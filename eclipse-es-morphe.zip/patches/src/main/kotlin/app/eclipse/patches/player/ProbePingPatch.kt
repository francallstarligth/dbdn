package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.90 (SIN COMPILAR / SIN PROBAR). Parche de PRUEBA: al abrir Eclipse muestra el aviso "Parches Eclipse ES
 * 0.20.90 activos". Sirve para saber si los parches de esta version llegan a la app instalada (el aviso de letras
 * de LyricsPlus nunca salio). Gancho: ai.onnxruntime.TelemetryInitializer.onCreate() (ContentProvider declarado en
 * el manifest, Android lo crea al arrancar), al principio; p0 = this (un ContentProvider). Independiente del parche
 * "Sin telemetria de ONNX Runtime" (ese busca su propio sitio despues de System.loadLibrary).
 */
@Suppress("unused")
val probePingPatch = bytecodePatch(
    name = "Prueba: aviso al abrir",
    description = "Muestra un aviso corto al abrir Eclipse para confirmar que los parches estan instalados. " +
        "Es solo una prueba: desmarcalo cuando ya no haga falta.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lai/onnxruntime/TelemetryInitializer;"))
        val method = cls.methods.firstOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro TelemetryInitializer.onCreate")
        method.addInstructions(
            0,
            """
                invoke-static {p0}, Lapp/eclipse/extension/player/ProbePing;->hi(Landroid/content/ContentProvider;)V
            """
        )

        // v0.20.90: marcas en y9.h (letras) para ver hasta donde llega el pedido de letra
        val y9 = mutableClassDefBy(classDefBy("Ly9;"))
        val h = y9.methods.firstOrNull { m ->
            m.implementation?.instructions?.any { ins ->
                val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                ins.opcode == Opcode.INVOKE_VIRTUAL_RANGE && r != null && r.definingClass == "Lov4;" && r.name == "g"
            } == true
        } ?: error("y9.h no encontrado")
        val list = (h.implementation ?: error("y9.h sin codigo")).instructions.toList()
        val sIdx = list.indexOfFirst { ins ->
            val r = (ins as? ReferenceInstruction)?.reference as? FieldReference
            ins.opcode == Opcode.SGET_OBJECT && r != null && r.definingClass == "Lgx4;" && r.name == "MUSIXMATCH"
        }
        if (sIdx < 0) error("y9.h: no se encontro gx4.MUSIXMATCH")
        // Primero el indice mas alto para que el otro no se mueva. v1 = jv4 (proveedor) tras :goto_3.
        h.addInstructions(
            sIdx + 1,
            """
                invoke-static {v1}, Lapp/eclipse/extension/player/ProbePing;->mark(Ljava/lang/Object;)V
            """
        )
        h.addInstructions(
            0,
            """
                invoke-static {}, Lapp/eclipse/extension/player/ProbePing;->m1()V
            """
        )
    }
}
