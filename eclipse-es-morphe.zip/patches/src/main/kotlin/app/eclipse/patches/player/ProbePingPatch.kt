package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.87 (SIN COMPILAR / SIN PROBAR). Parche de PRUEBA: al abrir Eclipse muestra el aviso "Parches Eclipse ES
 * 0.20.87 activos". Sirve para saber si los parches de esta version llegan a la app instalada (el aviso de letras
 * de LyricsPlus nunca salio). Gancho: ai.onnxruntime.TelemetryInitializer.onCreate() (ContentProvider declarado en
 * el manifest, Android lo crea al arrancar), al principio; p0 = this (un ContentProvider). Independiente del parche
 * "Sin telemetria de ONNX Runtime" (ese busca su propio sitio despues de System.loadLibrary).
 */
@Suppress("unused")
val probePingPatch = bytecodePatch(
    name = "Prueba: aviso al abrir",
    description = "Muestra un aviso corto al abrir Eclipse para confirmar que los parches estan instalados. " +
        "Es solo una prueba: desmarcalo cuando ya no haga falta.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val cls = mutableClassDefBy(classDefBy("Lai/onnxruntime/TelemetryInitializer;"))
        val method = cls.methods.firstOrNull { it.name == "onCreate" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro TelemetryInitializer.onCreate")
        method.addInstructions(
            0,
            """
                invoke-static {p0}, Lapp/eclipse/extension/player/ProbePing;->hi(Landroid/content/ContentProvider;)V
            """
        )
    }
}
