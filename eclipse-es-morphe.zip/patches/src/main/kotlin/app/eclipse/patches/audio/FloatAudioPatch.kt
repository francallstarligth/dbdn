package app.eclipse.patches.audio

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val FLOAT_AUDIO = "Lapp/eclipse/extension/audio/FloatAudio;"

private fun isHighResCheck(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference ?: return false
    return ref.definingClass == "Lpi9;" && ref.name == "M" &&
        ref.returnType == "Z" && ref.parameterTypes.map { it.toString() } == listOf("I")
}

@Suppress("unused")
val floatAudioPatch = bytecodePatch(
    name = "Audio: todo a float",
    description = "Hace que tambien el audio de 16 bit pase a float antes del procesador de audio de Eclipse " +
        "(EQ, normalizacion, Automix), en vez de calcularse y truncarse a 16 bit. Mas CPU; la mejora " +
        "audible puede ser pequena (mas si apagas normalizacion y EQ).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val kd3 = mutableClassDefBy(classDefBy("Lkd3;"))

        // u(Lo03;)I = consulta de formato; y(Lo03;[I)V = configurar (rama "audio/raw"). En cada uno hay una
        // llamada a pi9.M(encoding) seguida de move-result: el gancho va justo despues de ese move-result.
        fun hook(name: String, params: List<String>, returnType: String) {
            val method = kd3.methods.firstOrNull {
                it.name == name && it.returnType == returnType &&
                    it.parameterTypes.map { p -> p.toString() } == params
            } ?: error("No se encontro kd3.$name")
            val list = (method.implementation ?: error("kd3.$name sin codigo")).instructions.toList()
            val calls = list.indices.filter { isHighResCheck(list[it]) }
            if (calls.size != 1) error("kd3.$name: se esperaba 1 llamada a pi9.M y hay ${calls.size}")
            val c = calls[0]
            val moveResult = list.getOrNull(c + 1)
            if (moveResult == null || moveResult.opcode != Opcode.MOVE_RESULT) {
                error("kd3.$name: tras pi9.M no sigue move-result")
            }
            val enc = (list[c] as FiveRegisterInstruction).registerC
            val res = (moveResult as OneRegisterInstruction).registerA
            if (enc > 15 || res > 15) error("kd3.$name: registros fuera de rango (v$enc, v$res)")

            method.addInstructions(
                c + 2,
                """
                    invoke-static {v$res, v$enc}, $FLOAT_AUDIO->floatAll(ZI)Z
                    move-result v$res
                """
            )
        }

        hook("u", listOf("Lo03;"), "I")
        hook("y", listOf("Lo03;", "[I"), "V")
    }
}
