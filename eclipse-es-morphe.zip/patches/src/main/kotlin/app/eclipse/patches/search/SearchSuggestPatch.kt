package app.eclipse.patches.search

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.util.smali.ExternalLabel
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val SUG = "Lapp/eclipse/extension/search/Suggest;"

/**
 * v0.20.432 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias mientras escribes, SIN peticiones nuevas: salen de los resultados que ya trae la busqueda.
 * La pantalla real (Ls6b.d -> Lj7a.invoke, un LazyColumn; q=1 -> bloque tras el packed-switch) agrega items "field", "sources" y luego: texto vacio -> "recent"
 * (Lgw6 caso 26 -> Ls6b.c) o "hint"; con texto -> "results" (Lu40). (Lmd8.t NO es esta pantalla.)
 * (1) `Lz59;->b`: antes de cada `check-cast vX, Lm49` -> `Suggest.note(vX)`.
 * (2) `Lj7a;->invoke`: justo despues del item "sources" (nadie salta ahi): si `Suggest.show(query)` -> agrega el item "suggest" = `new Lgw6(Lz59, recientes, 26)` en un `Lfq1`.
 * (3) `Lgw6;->q`: tras `check-cast v4, List` (lectura de recientes) -> `v4 = Suggest.list(v4)`.
 * (4) `Ls6b;->c`: tras `const-string v3, "Recent Searches"` -> `v3 = Suggest.title(v3)`.
 * Aborta con error claro si no encuentra exactamente lo esperado. DIAGNOSTICO: Suggest.java avisa (Toast) y copia el registro al portapapeles.
 */
@Suppress("unused")
val searchSuggestPatch = bytecodePatch(
    name = "Busqueda: sugerencias al escribir",
    description = "Mientras escribes, sale una lista de sugerencias (artistas y canciones de lo que la busqueda ya encontro) encima de los resultados. No hace peticiones extra. (En PRUEBA: muestra avisos y los copia al portapapeles.)",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    extendWith("extensions/extension.mpe")

    execute {
        // (1) Lz59.b: guardar sugerencias con los resultados, VENGAN DE DONDE VENGAN
        val vm = mutableClassDefBy(classDefBy("Lz59;"))
        val b = vm.methods.firstOrNull { it.name == "b" && it.parameterTypes.size == 3 }
            ?: error("Sugerencias: no se encontro Lz59.b(Lz59, String, Continuation)")
        run {
            val ins = b.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CHECK_CAST &&
                    ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lm49;"
            }
            if (hits.isEmpty()) error("Sugerencias: no se encontro ningun 'check-cast Lm49' en Lz59.b")
            for (i in hits.sortedDescending()) {
                val reg = (ins[i] as OneRegisterInstruction).registerA
                if (reg > 15) error("Sugerencias: registro v$reg de Lm49 no cabe en 4 bits")
                b.addInstructions(i, "invoke-static {v$reg}, $SUG->note(Ljava/lang/Object;)V")
            }
        }

        // (2) Lj7a.invoke: item "suggest" despues del item "sources"
        run {
            val j = mutableClassDefBy(classDefBy("Lj7a;"))
            val inv = j.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.size == 1 }
                ?: error("Sugerencias: no se encontro Lj7a.invoke")
            val ins = inv.implementation!!.instructions.toList()
            val src = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CONST_STRING &&
                    ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "sources"
            }
            if (src.size != 1) error("Sugerencias: se esperaba 1 item \"sources\" en Lj7a.invoke y hay ${src.size}")
            val at = src[0] + 2
            val nx = ins[at]
            val ok = nx.opcode == Opcode.INVOKE_INTERFACE_RANGE && (nx as RegisterRangeInstruction).startRegister == 16 &&
                ((nx as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                    r.definingClass == "Lhea;" && r.name == "getValue"
                } == true
            if (!ok) error("Sugerencias: tras el item \"sources\" no esta la lectura del texto (v16.getValue) en Lj7a.invoke")
            inv.addInstructionsWithLabels(
                at,
                """
                    invoke-interface/range {v16 .. v16}, Lhea;->getValue()Ljava/lang/Object;
                    move-result-object v12
                    check-cast v12, Ljava/lang/String;
                    invoke-static {v12}, $SUG->show(Ljava/lang/String;)Z
                    move-result v12
                    if-eqz v12, :orig
                    new-instance v12, Lgw6;
                    const/16 v13, 26
                    invoke-direct {v12, v15, v5, v13}, Lgw6;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V
                    new-instance v13, Lfq1;
                    const v14, -2055723432
                    invoke-direct {v13, v12, v11, v14}, Lfq1;-><init>(Ljava/lang/Object;ZI)V
                    const-string v12, "suggest"
                    invoke-static {v1, v12, v13, v10}, Lh15;->y0(Lh15;Ljava/lang/String;Luk3;I)V
                """,
                ExternalLabel("orig", inv.getInstruction(at))
            )
        }

        // (3) Lgw6.q: la lista de recientes -> sugerencias si estan activas
        run {
            val g = mutableClassDefBy(classDefBy("Lgw6;"))
            val q = g.methods.firstOrNull { it.name == "q" && it.parameterTypes.size == 3 }
                ?: error("Sugerencias: no se encontro Lgw6.q")
            val ins = q.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                i + 2 < ins.size && ins[i].opcode == Opcode.INVOKE_INTERFACE &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Lhea;" && r.name == "getValue"
                    } == true &&
                    ins[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT && (ins[i + 1] as OneRegisterInstruction).registerA == 4 &&
                    ins[i + 2].opcode == Opcode.CHECK_CAST && (ins[i + 2] as OneRegisterInstruction).registerA == 4 &&
                    ((ins[i + 2] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
            }
            if (hits.size != 1) error("Sugerencias: se esperaba 1 lectura de la lista de recientes en Lgw6.q y hay ${hits.size}")
            q.addInstructions(
                hits[0] + 3,
                """
                    invoke-static {v4}, $SUG->list(Ljava/util/List;)Ljava/util/List;
                    move-result-object v4
                """
            )
        }

        // (4) Ls6b.c: titulo
        run {
            val s6 = mutableClassDefBy(classDefBy("Ls6b;"))
            val c = s6.methods.firstOrNull { it.name == "c" && it.parameterTypes.size == 4 }
                ?: error("Sugerencias: no se encontro Ls6b.c(List, Lfk3, Composer, int)")
            val ins = c.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CONST_STRING && (ins[i] as OneRegisterInstruction).registerA == 3 &&
                    ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "Recent Searches"
            }
            if (hits.size != 1) error("Sugerencias: se esperaba 1 'Recent Searches' en v3 en Ls6b.c y hay ${hits.size}")
            c.addInstructions(
                hits[0] + 1,
                """
                    invoke-static {v3}, $SUG->title(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v3
                """
            )
        }
    }
}
