package app.eclipse.patches.search

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val SUG = "Lapp/eclipse/extension/search/Suggest;"

/**
 * v0.20.435 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sobre la 0.20.434: (6) `Lz59;->t(String)` (tocar un reciente/sugerencia: pone el texto y busca) -> al inicio `Suggest.tapped(texto)`; `Suggest.add` no muestra las sugerencias mientras la caja tenga ese mismo texto.
 * v0.20.434 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sobre la 0.20.433 (el usuario confirmo que las sugerencias SALEN): se quitan los avisos de prueba; (4) `Lpb;->x`: con el header de sugerencias se salta el boton "Clear" (`Lww0;->E`) para no borrar los recientes; (5) `Llu6;->k`: tras `Li22;->S()` (icono del reloj) -> `Suggest.icon(fila, icono)` devuelve null en las filas de sugerencias (Li12.y acepta icono nulo).
 * v0.20.433 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias mientras escribes, SIN peticiones nuevas: salen de los resultados que ya trae la busqueda.
 * La pantalla REAL es la del "modo nativo": `Ly12;->r` crea `Lju6` (LazyColumn: `Lju6;->invoke(Lh15)`). (Lmd8.t, Lj7a/Lgw6/Ls6b.c NO eran esa pantalla: con la 0.20.432 los
 * avisos mostraron "note" pero nunca "show/list/title".) Items de Lju6: `Lig4` (barra); texto vacio -> header `Lpb`(25) "Recently Searched" + filas `Llu6` (JSONObject title/subtitle);
 * texto -> resultados.
 * (1) `Lz59;->b`: antes de cada `check-cast vX, Lm49` -> `Suggest.note(vX)`.
 * (2) `Lju6;->invoke`: justo despues del `Lh15;->y0` que sigue a `new Lig4`: `Suggest.add(texto, scope, this)` (agrega header + filas por reflexion).
 * (3) `Lpb;->x`: tras la 1a instruccion `Suggest.seen(this)`; tras `const-string v8, "Recently Searched"` -> `v8 = Suggest.title(v8)`.
 * Aborta con error claro si no encuentra exactamente lo esperado. DIAGNOSTICO: Suggest.java avisa (Toast) y copia el registro al portapapeles.
 */
@Suppress("unused")
val searchSuggestPatch = bytecodePatch(
    name = "Busqueda: sugerencias al escribir",
    description = "Mientras escribes, sale una lista de sugerencias (artistas y canciones de lo que la busqueda ya encontro) encima de los resultados. No hace peticiones extra.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    extendWith("extensions/extension.mpe")

    execute {
        // (1) Lz59.b: guardar sugerencias con los resultados, VENGAN DE DONDE VENGAN
        val vm = mutableClassDefBy(classDefBy("Lz59;"))
        val b = vm.methods.firstOrNull { it.name == "b" && it.parameterTypes.size == 3 }
            ?: error("Sugerencias: no se encontro Lz59.b(Lz59, String, Continuation)")
        run {
            val ins = b.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CHECK_CAST &&
                    ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lm49;"
            }
            if (hits.isEmpty()) error("Sugerencias: no se encontro ningun 'check-cast Lm49' en Lz59.b")
            for (i in hits.sortedDescending()) {
                val reg = (ins[i] as OneRegisterInstruction).registerA
                if (reg > 15) error("Sugerencias: registro v$reg de Lm49 no cabe en 4 bits")
                b.addInstructions(i, "invoke-static {v$reg}, $SUG->note(Ljava/lang/Object;)V")
            }
        }

        // (6) Lz59.t(String): al tocar una sugerencia/reciente, recordar el texto para esconder las sugerencias
        run {
            val t = vm.methods.firstOrNull { it.name == "t" && it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/String;" }
                ?: error("Sugerencias: no se encontro Lz59.t(String)")
            val ins = t.implementation!!.instructions.toList()
            val first = ins[0]
            if (first.opcode != Opcode.INVOKE_VIRTUAL || (first as FiveRegisterInstruction).registerC != 5)
                error("Sugerencias: la 1a instruccion de Lz59.t no es 'invoke-virtual v5, getClass'")
            t.addInstructions(0, "invoke-static {v5}, $SUG->tapped(Ljava/lang/String;)V")
        }

        // (2) Lju6.invoke: despues del item Lig4, llamar a Suggest.add(texto, scope, this)
        run {
            val j = mutableClassDefBy(classDefBy("Lju6;"))
            val inv = j.methods.firstOrNull { it.name == "invoke" && it.parameterTypes.size == 1 }
                ?: error("Sugerencias: no se encontro Lju6.invoke")
            val ins = inv.implementation!!.instructions.toList()
            val news = ins.indices.filter { i ->
                ins[i].opcode == Opcode.NEW_INSTANCE &&
                    ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lig4;"
            }
            // Lig4 es una clase-lambda con 3 usos en Lju6.invoke; el PRIMERO (el de la barra) es el que sigue a los dos caminos
            if (news.isEmpty()) error("Sugerencias: no se encontro 'new Lig4' en Lju6.invoke")
            val y0 = (news[0] until ins.size).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Lh15;" && r.name == "y0"
                    } == true
            } ?: error("Sugerencias: no se encontro Lh15.y0 tras 'new Lig4' en Lju6.invoke")
            val at = y0 + 1
            val nx = ins[at]
            val ok = nx.opcode == Opcode.INVOKE_INTERFACE &&
                ((nx as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                    r.definingClass == "Lhea;" && r.name == "getValue"
                } == true
            if (!ok) error("Sugerencias: tras el item Lig4 no esta la lectura del texto (getValue) en Lju6.invoke")
            inv.addInstructions(
                at,
                """
                    invoke-interface {v6}, Lhea;->getValue()Ljava/lang/Object;
                    move-result-object v2
                    check-cast v2, Ljava/lang/String;
                    invoke-static {v2, v1, v0}, $SUG->add(Ljava/lang/String;Ljava/lang/Object;Ljava/lang/Object;)V
                """
            )
        }

        // (5) Llu6.k: sin icono de reloj en las filas de sugerencias
        run {
            val lu = mutableClassDefBy(classDefBy("Llu6;"))
            val k = lu.methods.firstOrNull { it.name == "k" && it.parameterTypes.size == 4 }
                ?: error("Sugerencias: no se encontro Llu6.k")
            val ins = k.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Li22;" && r.name == "S" && r.parameterTypes.isEmpty()
                    } == true
            }
            if (hits.size != 1) error("Sugerencias: se esperaba 1 'Li22.S()' en Llu6.k y hay ${hits.size}")
            val mr = ins[hits[0] + 1]
            if (mr.opcode != Opcode.MOVE_RESULT_OBJECT || (mr as OneRegisterInstruction).registerA != 14)
                error("Sugerencias: tras Li22.S() en Llu6.k no esta 'move-result-object v14'")
            k.addInstructions(
                hits[0] + 2,
                """
                    invoke-static {v1, v14}, $SUG->icon(Lorg/json/JSONObject;Ljava/lang/Object;)Ljava/lang/Object;
                    move-result-object v14
                    check-cast v14, Lf54;
                """
            )
        }

        // (3) Lpb.x: titulo del header ("Recently Searched")
        run {
            val pb = mutableClassDefBy(classDefBy("Lpb;"))
            val x = pb.methods.firstOrNull { it.name == "x" && it.parameterTypes.size == 3 }
                ?: error("Sugerencias: no se encontro Lpb.x")
            val ins = x.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CONST_STRING && (ins[i] as OneRegisterInstruction).registerA == 8 &&
                    ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "Recently Searched"
            }
            if (hits.size != 1) error("Sugerencias: se esperaba 1 'Recently Searched' en v8 en Lpb.x y hay ${hits.size}")
            if (ins[0].opcode != Opcode.MOVE_OBJECT_FROM16 || (ins[0] as OneRegisterInstruction).registerA != 0)
                error("Sugerencias: la 1a instruccion de Lpb.x no es 'move-object/from16 v0, v32'")
            // (4) saltar el boton "Clear" cuando es el header de sugerencias
            val ysa = ins.indices.firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Lysa;" && r.name == "b"
                    } == true
            } ?: error("Sugerencias: no se encontro Lysa.b (titulo) en Lpb.x")
            val mv = ins[ysa + 1]
            if (mv.opcode != Opcode.MOVE_OBJECT_FROM16 || (mv as OneRegisterInstruction).registerA != 15)
                error("Sugerencias: tras Lysa.b en Lpb.x no esta 'move-object/from16 v15, v28'")
            val ww = (ysa + 1 until ins.size).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE &&
                    ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Lww0;" && r.name == "E"
                    } == true
            } ?: error("Sugerencias: no se encontro el boton Clear (Lww0.E) en Lpb.x")
            val end = ins[ww + 1]
            if (end.opcode != Opcode.INVOKE_VIRTUAL) error("Sugerencias: tras Lww0.E en Lpb.x no esta el cierre de grupo")
            x.addInstructionsWithLabels(
                ysa + 1,
                """
                    move-object/from16 v15, v28
                    invoke-static {}, $SUG->hideClear()Z
                    move-result v3
                    if-nez v3, :skip_clear
                """,
                ExternalLabel("skip_clear", x.getInstruction(ww + 1))
            )
            // de abajo hacia arriba
            x.addInstructions(
                hits[0] + 1,
                """
                    invoke-static {v8}, $SUG->title(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object v8
                """
            )
            x.addInstructions(1, "invoke-static {v0}, $SUG->seen(Ljava/lang/Object;)V")
        }
    }
}
