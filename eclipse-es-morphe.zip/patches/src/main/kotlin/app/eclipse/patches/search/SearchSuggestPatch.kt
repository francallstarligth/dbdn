package app.eclipse.patches.search

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val SUG = "Lapp/eclipse/extension/search/Suggest;"

/**
 * v0.20.427 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias mientras escribes, SIN peticiones nuevas: salen de los resultados que ya trae la busqueda.
 * (1) `Lz59;->q` (busqueda con addon de metadatos: Spotify o Apple): justo antes del `return-object` que sigue a `new Lm49(4 listas)` -> `Suggest.note(Lm49)`.
 * (2) `Lmd8;->t` (pantalla de busqueda, Compose). La lista "Recent searches" (`Lz59.v`, leida 2 veces con `invoke-interface/range v28, Lhea;->getValue`
 *     + `check-cast v3, List`) solo se pintaba con el texto vacio (`move/from16 v37, v5` con v5 = largo, seguido de `const v5, 1937736510` e `if-nez v37`):
 *     - antes del `move/from16 v37, v5`: `v5 = Suggest.len(v5)` (0 si hay sugerencias -> pinta la lista),
 *     - tras cada `check-cast v3, List` de esas 2 lecturas: `v3 = Suggest.list(v3)` (las sugerencias en vez de los recientes),
 *     - tras `const-string v3, "Recent searches"`: `v3 = Suggest.title(v3)`.
 * Aborta con error claro si no encuentra exactamente lo esperado.
 */
@Suppress("unused")
val searchSuggestPatch = bytecodePatch(
    name = "Busqueda: sugerencias al escribir",
    description = "Mientras escribes, sale una lista de sugerencias (artistas y canciones de lo que la busqueda ya encontro) en el lugar de las busquedas recientes. No hace peticiones extra.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)
    extendWith("extensions/extension.mpe")

    execute {
        // (1) Lz59.q: guardar sugerencias con los resultados
        val vm = mutableClassDefBy(classDefBy("Lz59;"))
        val q = vm.methods.firstOrNull { it.name == "q" && it.parameterTypes.size == 3 }
            ?: error("Sugerencias: no se encontro Lz59.q(String, String, Continuation)")
        run {
            val ins = q.implementation!!.instructions.toList()
            val hits = ins.indices.filter { i ->
                i >= 1 && ins[i].opcode == Opcode.RETURN_OBJECT &&
                    ins[i - 1].opcode == Opcode.INVOKE_DIRECT &&
                    ((ins[i - 1] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                        r.definingClass == "Lm49;" && r.name == "<init>" && r.parameterTypes.size == 4
                    } == true
            }
            if (hits.size != 1) error("Sugerencias: se esperaba 1 'new Lm49' + return en Lz59.q y hay ${hits.size}")
            val reg = (ins[hits[0] - 1] as FiveRegisterInstruction).registerC
            if (reg > 15) error("Sugerencias: registro v$reg de Lm49 no cabe en 4 bits")
            q.addInstructions(hits[0], "invoke-static {v$reg}, $SUG->note(Ljava/lang/Object;)V")
        }

        // (2) Lmd8.t: pintar la lista mientras hay texto
        val ui = mutableClassDefBy(classDefBy("Lmd8;"))
        val t = ui.methods.firstOrNull { it.name == "t" } ?: error("Sugerencias: no se encontro Lmd8.t")
        val ins = t.implementation!!.instructions.toList()

        // lecturas de Lz59.v: invoke-interface/range v28 Lhea;->getValue + move-result-object v3 + check-cast v3, List
        val reads = ins.indices.filter { i ->
            i + 2 < ins.size && ins[i].opcode == Opcode.INVOKE_INTERFACE_RANGE &&
                (ins[i] as RegisterRangeInstruction).startRegister == 28 &&
                ((ins[i] as ReferenceInstruction).reference as? MethodReference)?.let { r ->
                    r.definingClass == "Lhea;" && r.name == "getValue"
                } == true &&
                ins[i + 1].opcode == Opcode.MOVE_RESULT_OBJECT && (ins[i + 1] as OneRegisterInstruction).registerA == 3 &&
                ins[i + 2].opcode == Opcode.CHECK_CAST && (ins[i + 2] as OneRegisterInstruction).registerA == 3 &&
                ((ins[i + 2] as ReferenceInstruction).reference as? TypeReference)?.type == "Ljava/util/List;"
        }
        if (reads.size != 2) error("Sugerencias: se esperaban 2 lecturas de la lista de recientes en Lmd8.t y hay ${reads.size}")

        // largo del texto: move/from16 v37, v5 seguido de const v5, 1937736510
        val lens = ins.indices.filter { i ->
            i + 1 < ins.size && ins[i].opcode == Opcode.MOVE_FROM16 &&
                (ins[i] as OneRegisterInstruction).registerA == 37 &&
                ins[i + 1].opcode == Opcode.CONST &&
                (ins[i + 1] as WideLiteralInstruction).wideLiteral == 1937736510L
        }
        if (lens.size != 1) error("Sugerencias: se esperaba 1 'move/from16 v37, v5' (largo) en Lmd8.t y hay ${lens.size}")

        // titulo
        val titles = ins.indices.filter { i ->
            ins[i].opcode == Opcode.CONST_STRING && (ins[i] as OneRegisterInstruction).registerA == 3 &&
                ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "Recent searches"
        }
        if (titles.size != 1) error("Sugerencias: se esperaba 1 'Recent searches' en v3 en Lmd8.t y hay ${titles.size}")

        // de abajo hacia arriba, para no mover los indices de los de arriba
        val ops = listOf(
            titles[0] + 1 to "invoke-static {v3}, $SUG->title(Ljava/lang/String;)Ljava/lang/String;\nmove-result-object v3",
            reads[1] + 3 to "invoke-static {v3}, $SUG->list(Ljava/util/List;)Ljava/util/List;\nmove-result-object v3",
            reads[0] + 3 to "invoke-static {v3}, $SUG->list(Ljava/util/List;)Ljava/util/List;\nmove-result-object v3",
            lens[0] to "invoke-static {v5}, $SUG->len(I)I\nmove-result v5"
        ).sortedByDescending { it.first }
        for ((idx, code) in ops) t.addInstructions(idx, code)
    }
}
