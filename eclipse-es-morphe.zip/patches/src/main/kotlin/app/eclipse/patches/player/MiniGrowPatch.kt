package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val MORPH = "Lapp/eclipse/extension/player/LayerMorph;"

/**
 * v0.20.374 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * REEMPLAZA a la version "B" anterior (escala 0.15 + fundido, que no era lo que el usuario queria). Ahora: al abrir el
 * reproductor grande, la PORTADA sale del lugar de la portada del mini (abajo a la izquierda) y viaja hasta su sitio
 * agrandandose, siguiendo el avance de la hoja (el mismo que anima "Entrada del reproductor").
 *
 * Como funciona: este parche NO engancha nada nuevo en el dibujo; solo enciende un interruptor (LayerMorph.enableOpen)
 * al inicio de `Lex7.e()` (abrir el reproductor, el mismo metodo que ya usa PlayerEnter). El movimiento lo hace
 * LayerMorph.tf, que ya esta enganchado por "Bitchord: la portada chica crece (Letra)" en Lzt7.d y Lgs7.invoke, y lee el
 * avance con PlayerEnter.progreso().
 *
 * REQUIERE (si no, no hace nada): "Bitchord: la portada chica crece (Letra)" encendido (con su diseno Bitchord/Capsule
 * creado de nuevo, las capas marcadas) y "Entrada del reproductor" encendida en "Reproductor: animaciones".
 * NO hace: cerrar (la salida sigue como antes), titulo/artista/botones, el rebote del mini, esconder la barra de abajo.
 * NO verificado: que compile; que Morphe aplique el gancho; que la portada se vea (puede quedar recortada por la hoja
 * mientras esta fuera de su rectangulo); que el mini medido en 1080x2400 coincida en otras pantallas.
 */
@Suppress("unused")
val miniGrowPatch = bytecodePatch(
    description = "Experimento. Al abrir el reproductor grande, la portada sale de la portada del mini y viaja hasta su lugar.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val ex7 = mutableClassDefBy(classDefBy("Lex7;"))
        val e = ex7.methods.singleOrNull {
            it.name == "e" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("Crece desde el mini: no se encontro Lex7.e() (abrir el reproductor, Eclipse 0.6.75)")
        // Misma comprobacion que PlayerEnter: Lex7.e() debe poner Boolean.TRUE (= abrir).
        val setsTrue = e.implementation?.instructions?.any { i ->
            val r = (i as? ReferenceInstruction)?.reference
            i.opcode == Opcode.SGET_OBJECT && r is FieldReference && r.definingClass == "Ljava/lang/Boolean;" && r.name == "TRUE"
        } == true
        if (!setsTrue) error("Crece desde el mini: Lex7.e() no pone Boolean.TRUE")
        e.addInstructions(0, "invoke-static {}, $MORPH->enableOpen()V")
    }
}
