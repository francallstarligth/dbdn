package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

/**
 * v0.20.365 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Entrada y salida "B" del reproductor grande: crece desde el mini
 * (abajo al centro) y al cerrar se mete de nuevo en el.
 *
 * Todo en `Lh12.d` (ax1.b), el AnimatedVisibility del reproductor grande (`Lb9b.d`, visible = `Lex7.b`; `Lex7.e()` = abrir).
 * Origen de la escala ya es abajo-centro (`Lne8.i(0.5, 1.0)`). Antes de `new-instance Lls5`:
 *  ENTRADA = slide `Li03.n` (320 ms) + escala `Li03.g` (0.92) + fundido `Li03.e` (180 ms).
 *  SALIDA  = slide `Li03.r` (280 ms) + escala `Ld19` (0.94, 280 ms) + fundido (200 ms).
 * Cambios (se insertan constantes nuevas justo despues de las originales, y de mayor a menor indice):
 *  entrada: escala 0.92 -> 0.15, duracion 320 -> 450 ms, sin slide (tras `Lo03.a` slide+escala: `move-object` deja solo la
 *  escala), fundido 180 -> 250 ms.
 *  salida: escala 0.94 -> 0.15, duracion 280 -> 350 ms, sin slide (tras `Lp33.a` idem), fundido 200 -> 300 ms.
 * Si "Reproductor: animaciones" tiene encendida "Entrada del reproductor", su `PlayerEnter` tambien sube la hoja desde
 * abajo y se suma: apagarla. No usar junto con "Salida mas lenta (experimento)".
 * NO verificado: que compile, que Morphe aplique, el aspecto (la hoja grande y el mini se ven a la vez mientras crece).
 */
@Suppress("unused")
val miniGrowPatch = bytecodePatch(
    description = "Experimento. El reproductor grande crece desde el mini al abrir y se mete en el al cerrar.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lh12;"))
        val m = cls.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } == listOf("Lfl0;", "Ltz6;", "Leu1;", "I")
        } ?: error("Crece desde el mini: no se encontro ax1.b (Eclipse 0.6.75)")
        val ins = (m.implementation ?: error("Crece desde el mini: ax1.b sin codigo")).instructions.toList()

        fun lit(i: Int) = (ins[i] as WideLiteralInstruction).wideLiteral
        fun reg(i: Int) = (ins[i] as OneRegisterInstruction).registerA
        fun mref(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
        fun params(r: MethodReference) = r.parameterTypes.map { p -> p.toString() }

        val zs = ins.indices.filter { i ->
            ins[i].opcode == Opcode.NEW_INSTANCE &&
                ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lls5;"
        }
        if (zs.size != 1) error("Crece desde el mini: se esperaba 1 new-instance Lls5 (hay ${zs.size})")
        val z = zs[0]

        // ---------- ENTRADA ----------
        val enterScale = (0 until z).lastOrNull { i ->
            ins[i].opcode == Opcode.INVOKE_STATIC && mref(i)?.let {
                it.definingClass == "Li03;" && it.name == "g" && params(it) == listOf("F", "J", "Ls83;")
            } == true
        } ?: error("Crece desde el mini: no se encontro Li03.g (escala de entrada)")
        val enterMerge = (enterScale + 1 until z).firstOrNull { i ->
            ins[i].opcode == Opcode.INVOKE_VIRTUAL && mref(i)?.let {
                it.definingClass == "Lo03;" && it.name == "a"
            } == true
        } ?: error("Crece desde el mini: no se encontro Lo03.a tras la escala de entrada")
        if (ins[enterMerge + 1].opcode != Opcode.MOVE_RESULT_OBJECT)
            error("Crece desde el mini: tras Lo03.a no hay move-result-object")
        val enterMergeIns = ins[enterMerge] as? FiveRegisterInstruction
        if (enterMergeIns == null || enterMergeIns.registerCount != 2)
            error("Crece desde el mini: Lo03.a no tiene 2 registros")
        val i092 = (0 until enterScale).lastOrNull { ins[it].opcode == Opcode.CONST && lit(it) == 1064011039L }
            ?: error("Crece desde el mini: no se encontro la escala de entrada 0.92")
        val i320 = (0 until enterScale).lastOrNull { ins[it].opcode == Opcode.CONST_16 && lit(it) == 320L }
            ?: error("Crece desde el mini: no se encontro const 320")
        val i180 = (enterMerge until z).firstOrNull { ins[it].opcode == Opcode.CONST_16 && lit(it) == 180L }
            ?: error("Crece desde el mini: no se encontro const 180")

        // ---------- SALIDA ----------
        val d19 = (0 until z).lastOrNull { i ->
            ins[i].opcode == Opcode.NEW_INSTANCE &&
                ((ins[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Ld19;"
        } ?: error("Crece desde el mini: no se encontro new-instance Ld19")
        val exitMerge = (d19 + 1 until z).firstOrNull { i ->
            ins[i].opcode == Opcode.INVOKE_VIRTUAL && mref(i)?.let {
                it.definingClass == "Lp33;" && it.name == "a"
            } == true
        } ?: error("Crece desde el mini: no se encontro Lp33.a tras Ld19")
        if (ins[exitMerge + 1].opcode != Opcode.MOVE_RESULT_OBJECT)
            error("Crece desde el mini: tras Lp33.a no hay move-result-object")
        val exitMergeIns = ins[exitMerge] as? FiveRegisterInstruction
        if (exitMergeIns == null || exitMergeIns.registerCount != 2)
            error("Crece desde el mini: Lp33.a no tiene 2 registros")
        val i094 = (0 until z).lastOrNull { ins[it].opcode == Opcode.CONST && lit(it) == 1064346583L }
            ?: error("Crece desde el mini: no se encontro la escala de salida 0.94")
        val i280 = (0 until d19).lastOrNull {
            ins[it].opcode == Opcode.CONST_16 && lit(it) == 280L && ins[it + 1].opcode == Opcode.INVOKE_STATIC
        } ?: error("Crece desde el mini: no se encontro const 280")
        val i200 = (exitMerge until z).firstOrNull { ins[it].opcode == Opcode.CONST_16 && lit(it) == 200L }
            ?: error("Crece desde el mini: no se encontro const 200")

        val enterRes = reg(enterMerge + 1)
        val enterArg = enterMergeIns.registerD
        val exitRes = reg(exitMerge + 1)
        val exitArg = exitMergeIns.registerD
        if (enterRes > 15 || enterArg > 15 || exitRes > 15 || exitArg > 15)
            error("Crece desde el mini: registros fuera de rango para move-object")

        // (indice donde se inserta, smali). Se aplican de mayor a menor indice para no mover a los que faltan.
        val cambios = listOf(
            i092 + 1 to "const v${reg(i092)}, 0x3e19999a",
            i320 + 1 to "const/16 v${reg(i320)}, 450",
            enterMerge + 2 to "move-object v$enterRes, v$enterArg",
            i180 + 1 to "const/16 v${reg(i180)}, 250",
            i280 + 1 to "const/16 v${reg(i280)}, 350",
            i094 + 1 to "const v${reg(i094)}, 0x3e19999a",
            exitMerge + 2 to "move-object v$exitRes, v$exitArg",
            i200 + 1 to "const/16 v${reg(i200)}, 300",
        ).sortedByDescending { it.first }
        for ((idx, smali) in cambios) m.addInstructions(idx, smali)
    }
}
