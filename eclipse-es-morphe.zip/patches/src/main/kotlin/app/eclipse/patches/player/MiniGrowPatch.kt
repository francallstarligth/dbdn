package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.WideLiteralInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val FB = "Lapp/eclipse/extension/player/FluidB;"

/**
 * v0.20.377 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin javac/kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * REEMPLAZA la B de la 374 (solo la portada). Ahora es la B de la demo: TODA la hoja del reproductor grande sale chiquita de donde
 * esta el mini (abajo al centro) y crece hasta llenar la pantalla. NO hace (todavia): fundido de transparencia, esquinas redondeadas,
 * esconder la barra de abajo ni la forma de capsula (la escala es pareja: arranca como un cuadrito al 15%).
 *
 * `Lwka.a` (la hoja): Animatable v27 (`Lqt`) = valor Y (0 = abierta, alto = cerrada; PlayerEnter lo anima). Escala = 1 - 0.6 * valor/alto
 * (const 0.6 en el indice 162, v17) y `Lm10(v27, 11)` = offset { IntOffset(0, max(0, valor)) } (`Lm10.invoke` caso 11: `Lh9.G(F)I` + `if-gez`).
 * Cadena: offset (afuera) -> scale (adentro, pivote al centro). Cambios (solo mientras corre la apertura de PlayerEnter):
 *  (1) `Lwka.a`: tras `check-cast v27, Lqt;` -> FluidB.setSheet(v27).
 *  (2) `Lwka.a`: tras `const v17, 0.6f` -> v17 = FluidB.factor() (0.85).
 *  (3) `Lm10.invoke` caso 11: antes de `Lqt.d()` -> FluidB.mark(Lqt); antes de `Lh9.G` -> v5 = FluidB.offset(v5) (x0.37 si es la hoja).
 *  (4) `Lex7.e()` (abrir): FluidB.enable() (misma comprobacion Boolean.TRUE que PlayerEnter). PlayerEnter alarga la apertura a 420 ms.
 * REQUIERE "Entrada del reproductor" encendida (si no, no hay animacion y no hace nada).
 * NO verificado: que compile; que Morphe aplique (da error claro si algo no coincide); que el valor del Animatable siga a PlayerEnter sin
 * retraso; el aspecto. Al esperar la portada la hoja sigue fuera de pantalla y aparece de golpe chiquita en el mini (sin fundido).
 */
@Suppress("unused")
val miniGrowPatch = bytecodePatch(
    description = "Experimento. Al abrir, el reproductor grande sale chiquito de donde esta el mini y crece hasta llenar la pantalla.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (4) abrir
        val ex7 = mutableClassDefBy(classDefBy("Lex7;"))
        val e = ex7.methods.singleOrNull { it.name == "e" && it.returnType == "V" && it.parameterTypes.isEmpty() }
            ?: error("Crece desde el mini: no se encontro Lex7.e() (abrir el reproductor, Eclipse 0.6.75)")
        val setsTrue = e.implementation?.instructions?.any { i ->
            val r = (i as? ReferenceInstruction)?.reference
            i.opcode == Opcode.SGET_OBJECT && r is FieldReference && r.definingClass == "Ljava/lang/Boolean;" && r.name == "TRUE"
        } == true
        if (!setsTrue) error("Crece desde el mini: Lex7.e() no pone Boolean.TRUE")
        e.addInstructions(0, "invoke-static {}, $FB->enable()V")

        // (1) y (2) en Lwka.a
        val wk = mutableClassDefBy(classDefBy("Lwka;"))
        val a = wk.methods.singleOrNull { it.name == "a" && it.returnType == "V" && it.parameterTypes.size == 9 }
            ?: error("Crece desde el mini: no se encontro Lwka.a (la hoja del reproductor)")
        val ai = (a.implementation ?: error("Crece desde el mini: Lwka.a sin codigo")).instructions.toList()
        val cc = ai.indices.firstOrNull { i ->
            ai[i].opcode == Opcode.CHECK_CAST && (ai[i] as OneRegisterInstruction).registerA == 27 &&
                ((ai[i] as ReferenceInstruction).reference as? TypeReference)?.type == "Lqt;"
        } ?: error("Crece desde el mini: no se encontro 'check-cast v27, Lqt;' en Lwka.a")
        val k = ai.indices.filter { i ->
            ai[i].opcode == Opcode.CONST && (ai[i] as OneRegisterInstruction).registerA == 17 &&
                (ai[i] as WideLiteralInstruction).wideLiteral == 1058642330L
        }
        if (k.size != 1) error("Crece desde el mini: se esperaba 1 'const v17, 0.6f' en Lwka.a y hay ${k.size}")
        // primero la de mas abajo
        a.addInstructions(
            k[0] + 1,
            """
            invoke-static {}, $FB->factor()F
            move-result v17
            """
        )
        a.addInstructions(cc + 1, "invoke-static {v27}, $FB->setSheet(Ljava/lang/Object;)V")

        // (3) en Lm10.invoke (caso 11)
        val lm = mutableClassDefBy(classDefBy("Lm10;"))
        val inv = lm.methods.singleOrNull {
            it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes.size == 1 &&
                it.parameterTypes[0].toString() == "Ljava/lang/Object;"
        } ?: error("Crece desde el mini: no se encontro Lm10.invoke(Object)")
        val li = (inv.implementation ?: error("Crece desde el mini: Lm10.invoke sin codigo")).instructions.toList()
        val g = li.indices.filter { i ->
            li[i].opcode == Opcode.INVOKE_STATIC && i + 2 < li.size && li[i + 2].opcode == Opcode.IF_GEZ &&
                ((li[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lh9;" && it.name == "G"
                } == true
        }
        if (g.size != 1) error("Crece desde el mini: se esperaba 1 'Lh9.G + if-gez' en Lm10.invoke y hay ${g.size}")
        val gi = g[0]
        if ((li[gi] as FiveRegisterInstruction).registerC != 5) error("Crece desde el mini: Lh9.G no usa v5")
        val q = (gi - 1 downTo 0).firstOrNull { i ->
            li[i].opcode == Opcode.INVOKE_VIRTUAL &&
                ((li[i] as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lqt;" && it.name == "d"
                } == true
        } ?: error("Crece desde el mini: no se encontro 'Lqt.d()' antes de Lh9.G")
        if ((li[q] as FiveRegisterInstruction).registerC != 5) error("Crece desde el mini: Lqt.d() no usa v5")
        inv.addInstructions(
            gi,
            """
            invoke-static {v5}, $FB->offset(F)F
            move-result v5
            """
        )
        inv.addInstructions(q, "invoke-static {v5}, $FB->mark(Ljava/lang/Object;)V")
    }
}
