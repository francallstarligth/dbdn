package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val CACHE_HELPER = "Lapp/eclipse/extension/canvas/CanvasCache;"
private const val PRELOAD_HELPER = "Lapp/eclipse/extension/canvas/CanvasPreload;"

/**
 * Eclipse 0.6.70 (porte desde 0.6.61): los ExoPlayer de los Canvas (vz0.r -> w23.a()) leen el video directo de la red.
 * Eclipse ya trae una cache de media3 (su8.x.e(Context) -> ih9) y una fabrica de fuente con cache (w11, usada para las
 * canciones en sg0.o).
 *
 * 1) vz0.r(Context, String, int, boolean): `CanvasCache.begin()` justo antes de `w23.a()` y `CanvasCache.end()` justo
 *    despues (marca que ESE ExoPlayer es de un Canvas; w23 lo usan otros sitios que no se tocan). Al inicio se anota la URL
 *    (p1) con `CanvasCache.setUrl`.
 * 2) xc2.<init>(Context, jb2) (la fabrica de fuentes por defecto: od0.get -> `xc2(ctx, jb2())`): la fuente de red
 *    `r26(ctx, 12)` pasa por `CanvasCache.wrap(ctx, r26)`, que la envuelve con w11 solo mientras begin/end esta activo.
 * 3) Opcion `preload` (v1.95.0): al inicio de rz0.I(Context, Song, dz1) se llama a `CanvasPreload.onSongWifi/onSongAny
 *    (ctx, song)` con `invoke-static/range {p1 .. p2}`; si la cancion es la actual de la cola, tras unos segundos se
 *    resuelve y baja a la cache el Canvas de la SIGUIENTE (ver CanvasPreload.java).
 *
 * Mapa 61 -> 70: q92=xc2, b82=jb2, m42=m72, h34=r26 (ahora `<init>(Context, I)` con I=12), qj4.u=vz0.r, kz2=w23, c03=o33,
 * ux0.F=rz0.I, jw1=dz1. Verificado en el dex 70 (ver traspaso v351).
 */
@Suppress("unused")
val canvasCachePatch = bytecodePatch(
    name = "Canvas: cache compartida",
    description = "(Solo Canvas de Spotify y de la lista de la comunidad; Tidal y Apple no se tocan.) Los videos de los Canvas pasan por la misma cache de disco que usa Eclipse para las canciones. " +
        "Los Canvas ya vistos cargan casi al instante y los dos videos de una cancion (portada y fondo) comparten " +
        "lo ya bajado. La primera descarga demora igual salvo que uses la precarga (opcion). Ocupa algo de espacio extra " +
        "en la cache de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val preload by booleanOption(
        key = "preload",
        default = true,
        title = "Precargar el Canvas de la siguiente cancion",
        description = "Mientras suena la cancion actual, baja el Canvas de la siguiente (el de la cola, con shuffle y " +
            "\"a continuacion\") a la cache para que cargue al instante. Solo videos normales (no HLS/m3u8). Usa algo de datos."
    )

    val wifiOnly by booleanOption(
        key = "wifiOnly",
        default = true,
        title = "Precargar solo con Wi-Fi",
        description = "No precarga si la red esta marcada como de uso limitado (datos moviles). Solo aplica a la precarga."
    )

    execute {
        // ---- 2) xc2.<init>(Context, jb2): envolver la fuente de red r26 ----
        val u82 = mutableClassDefBy(classDefBy("Lxc2;"))
        val init = u82.methods.singleOrNull { m ->
            m.name == "<init>" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Ljb2;")
        } ?: error("No se encontro xc2.<init>(Context, jb2) (version de Eclipse distinta de 0.6.70?)")
        val gi = (init.implementation ?: error("xc2.<init> sin codigo")).instructions.toList()

        val u82Hits = gi.indices.filter { i ->
            val ref = (gi[i] as? ReferenceInstruction)?.reference as? MethodReference
            gi[i].opcode == Opcode.INVOKE_DIRECT && ref != null && ref.definingClass == "Lxc2;" &&
                ref.name == "<init>" && ref.parameterTypes.map { it.toString() } == listOf("Lm72;", "Ljb2;")
        }
        if (u82Hits.size != 1) error("xc2.<init>: se esperaba 1 llamada a xc2.<init>(m72, jb2) (hay ${u82Hits.size})")
        val callAt = u82Hits[0]
        val call = gi[callAt] as FiveRegisterInstruction
        val factoryReg = call.registerD

        // La instruccion anterior debe ser r26.<init>(Context, I) (I = 12, fuente de red por defecto) sobre ese mismo registro.
        val prev = gi.getOrNull(callAt - 1)
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev == null || prev.opcode != Opcode.INVOKE_DIRECT || prevRef == null ||
            prevRef.definingClass != "Lr26;" || prevRef.name != "<init>" ||
            prevRef.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;", "I")
        ) error("xc2.<init>: antes de la llamada se esperaba r26.<init>(Context, I)")
        val mCall = prev as FiveRegisterInstruction
        if (mCall.registerC != factoryReg) error("xc2.<init>: r26 y la fabrica no son el mismo registro")
        val ctxReg = mCall.registerD
        if (factoryReg > 15 || ctxReg > 15) error("xc2.<init>: registros fuera de v0..v15")

        init.addInstructions(
            callAt,
            """
                invoke-static {v$ctxReg, v$factoryReg}, $CACHE_HELPER->wrap(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$factoryReg
                check-cast v$factoryReg, Lm72;
            """
        )

        // ---- 1) vz0.r: begin/end alrededor de w23.a() ----
        val n34 = mutableClassDefBy(classDefBy("Lvz0;"))
        val h = n34.methods.singleOrNull { m ->
            m.name == "r" && m.returnType == "Lo33;" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Ljava/lang/String;", "I", "Z")
        } ?: error("No se encontro vz0.r(Context, String, int, boolean)")
        val hi = (h.implementation ?: error("vz0.r sin codigo")).instructions.toList()

        val aHits = hi.indices.filter { i ->
            val ref = (hi[i] as? ReferenceInstruction)?.reference as? MethodReference
            hi[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Lw23;" &&
                ref.name == "a" && ref.returnType == "Lo33;" && ref.parameterTypes.isEmpty()
        }
        if (aHits.size != 1) error("vz0.r: se esperaba 1 llamada a w23.a() (hay ${aHits.size})")
        val aAt = aHits[0]
        if (hi.getOrNull(aAt + 1)?.opcode != Opcode.MOVE_RESULT_OBJECT) error("vz0.r: tras w23.a() se esperaba move-result-object")

        // v0.20.201: al inicio de vz0.r se anota la URL (p1) para que la cache solo se use con Canvas de Spotify/comunidad.
        run {
            val first = hi.firstOrNull() ?: error("vz0.r sin instrucciones")
            var pos = 0
            for (ins in hi) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("vz0.r: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            if (first.opcode == Opcode.MOVE_RESULT_OBJECT) error("vz0.r: la primera instruccion es un move-result")
        }

        // Primero la de despues (para no mover el indice de la de antes).
        h.addInstructions(aAt + 2, "invoke-static {}, $CACHE_HELPER->end()V")
        h.addInstructions(aAt, "invoke-static {}, $CACHE_HELPER->begin()V")
        h.addInstructions(0, "invoke-static/range {p1 .. p1}, $CACHE_HELPER->setUrl(Ljava/lang/String;)V")

        // ---- 3) precarga: gancho al inicio de rz0.I ----
        if (preload == true) {
            val ww0 = mutableClassDefBy(classDefBy("Lrz0;"))
            val a = ww0.methods.singleOrNull { m ->
                m.name == "I" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.map { it.toString() } ==
                    listOf("Landroid/content/Context;", "Lcom/eclipse/android/data/models/Song;", "Ldz1;")
            } ?: error("No se encontro rz0.I(Context, Song, Continuation)")
            val impl = a.implementation ?: error("rz0.I sin codigo")
            // Verificado en 0.6.70: 20 registros -> p0=v16, p1=v17 (Context), p2=v18 (Song), p3=v19.
            if (impl.registerCount != 20) error("rz0.I: se esperaban 20 registros (hay ${impl.registerCount})")
            val ai = impl.instructions.toList()
            if (ai.firstOrNull()?.opcode != Opcode.MOVE_OBJECT_FROM16) error("rz0.I: la primera instruccion no es move-object/from16")
            var pos = 0
            for (ins in ai) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("rz0.I: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            val hook = if (wifiOnly == true) "onSongWifi" else "onSongAny"
            a.addInstructions(
                0,
                "invoke-static/range {p1 .. p2}, $PRELOAD_HELPER->$hook(Landroid/content/Context;Ljava/lang/Object;)V"
            )
        }
    }
}
