package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val CACHE_HELPER = "Lapp/eclipse/extension/canvas/CanvasCache;"
private const val PRELOAD_HELPER = "Lapp/eclipse/extension/canvas/CanvasPreload;"

/**
 * Eclipse 0.6.57: los ExoPlayer de los Canvas (n34.v -> oy2.a()) leen el video directo de la red. Eclipse ya trae
 * una cache de media3 (fw8.v.d(Context) -> ey8) y una fabrica de fuente con cache (az0, usada en xe0.l para las
 * canciones).
 *
 * 1) n34.v(Context, String, int, boolean): `CanvasCache.begin()` justo antes de `oy2.a()` y `CanvasCache.end()` justo
 *    despues (marca que ESE ExoPlayer es de un Canvas; oy2 lo usan otros sitios que no se tocan). n34.v la llaman
 *    n34.h (Canvas del reproductor) y otra vista de video animado.
 * 2) u82.<init>(Context, g72) (la fabrica de fuentes por defecto: vb0.get casos 1 y 3 -> `u82(l24(ctx, 12), g72)`): la
 *    fuente de red l24 pasa por `CanvasCache.wrap(ctx, l24)`, que la envuelve con az0 solo mientras begin/end esta activo.
 * 3) Opcion `preload` (v1.95.0): al inicio de ww0.F(Context, Song, lv1) se llama a `CanvasPreload.onSongWifi/onSongAny
 *    (ctx, song)` con `invoke-static/range {p1 .. p2}`; si la cancion es la actual de la cola, tras unos segundos se
 *    resuelve y baja a la cache el Canvas de la SIGUIENTE (ver CanvasPreload.java).
 */
@Suppress("unused")
val canvasCachePatch = bytecodePatch(
    name = "Canvas: cache compartida",
    description = "(Solo Canvas de Spotify y de la lista de la comunidad; Tidal y Apple no se tocan.) Los videos de los Canvas pasan por la misma cache de disco que usa Eclipse para las canciones. " +
        "Los Canvas ya vistos cargan casi al instante y los dos videos de una cancion (portada y fondo) comparten " +
        "lo ya bajado. La primera descarga demora igual salvo que uses la precarga (opcion). Ocupa algo de espacio extra " +
        "en la cache de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val preload by booleanOption(
        key = "preload",
        default = true,
        title = "Precargar el Canvas de la siguiente cancion",
        description = "Mientras suena la cancion actual, baja el Canvas de la siguiente (el de la cola, con shuffle y " +
            "\"a continuacion\") a la cache para que cargue al instante. Solo videos normales (no HLS/m3u8). Usa algo de datos."
    )

    val wifiOnly by booleanOption(
        key = "wifiOnly",
        default = true,
        title = "Precargar solo con Wi-Fi",
        description = "No precarga si la red esta marcada como de uso limitado (datos moviles). Solo aplica a la precarga."
    )

    execute {
        // ---- 2) u82.<init>(Context, g72): envolver la fuente de red l24 ----
        val u82 = mutableClassDefBy(classDefBy("Lu82;"))
        val init = u82.methods.singleOrNull { m ->
            m.name == "<init>" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Lg72;")
        } ?: error("No se encontro u82.<init>(Context, g72) (version de Eclipse distinta de 0.6.57?)")
        val gi = (init.implementation ?: error("u82.<init> sin codigo")).instructions.toList()

        val u82Hits = gi.indices.filter { i ->
            val ref = (gi[i] as? ReferenceInstruction)?.reference as? MethodReference
            gi[i].opcode == Opcode.INVOKE_DIRECT && ref != null && ref.definingClass == "Lu82;" &&
                ref.name == "<init>" && ref.parameterTypes.map { it.toString() } == listOf("Lr32;", "Lg72;")
        }
        if (u82Hits.size != 1) error("u82.<init>: se esperaba 1 llamada a u82.<init>(r32, g72) (hay ${u82Hits.size})")
        val callAt = u82Hits[0]
        val call = gi[callAt] as FiveRegisterInstruction
        val factoryReg = call.registerD

        // La instruccion anterior debe ser l24.<init>(Context, I) sobre ese mismo registro.
        val prev = gi.getOrNull(callAt - 1)
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev == null || prev.opcode != Opcode.INVOKE_DIRECT || prevRef == null ||
            prevRef.definingClass != "Ll24;" || prevRef.name != "<init>" ||
            prevRef.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;", "I")
        ) error("u82.<init>: antes de la llamada se esperaba l24.<init>(Context, I)")
        val mCall = prev as FiveRegisterInstruction
        if (mCall.registerC != factoryReg) error("u82.<init>: l24 y la fabrica no son el mismo registro")
        val ctxReg = mCall.registerD
        if (factoryReg > 15 || ctxReg > 15) error("u82.<init>: registros fuera de v0..v15")

        init.addInstructions(
            callAt,
            """
                invoke-static {v$ctxReg, v$factoryReg}, $CACHE_HELPER->wrap(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$factoryReg
                check-cast v$factoryReg, Lr32;
            """
        )

        // ---- 1) n34.v: begin/end alrededor de oy2.a() ----
        val n34 = mutableClassDefBy(classDefBy("Ln34;"))
        val h = n34.methods.singleOrNull { m ->
            m.name == "v" && m.returnType == "Lgz2;" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Ljava/lang/String;", "I", "Z")
        } ?: error("No se encontro n34.v(Context, String, int, boolean)")
        val hi = (h.implementation ?: error("n34.v sin codigo")).instructions.toList()

        val aHits = hi.indices.filter { i ->
            val ref = (hi[i] as? ReferenceInstruction)?.reference as? MethodReference
            hi[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Loy2;" &&
                ref.name == "a" && ref.returnType == "Lgz2;" && ref.parameterTypes.isEmpty()
        }
        if (aHits.size != 1) error("n34.v: se esperaba 1 llamada a oy2.a() (hay ${aHits.size})")
        val aAt = aHits[0]
        if (hi.getOrNull(aAt + 1)?.opcode != Opcode.MOVE_RESULT_OBJECT) error("n34.v: tras oy2.a() se esperaba move-result-object")

        // v0.20.201: al inicio de n34.v se anota la URL (p1) para que la cache solo se use con Canvas de Spotify/comunidad.
        run {
            val first = hi.firstOrNull() ?: error("n34.v sin instrucciones")
            var pos = 0
            for (ins in hi) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("n34.v: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            if (first.opcode == Opcode.MOVE_RESULT_OBJECT) error("n34.v: la primera instruccion es un move-result")
        }

        // Primero la de despues (para no mover el indice de la de antes).
        h.addInstructions(aAt + 2, "invoke-static {}, $CACHE_HELPER->end()V")
        h.addInstructions(aAt, "invoke-static {}, $CACHE_HELPER->begin()V")
        h.addInstructions(0, "invoke-static {p1}, $CACHE_HELPER->setUrl(Ljava/lang/String;)V")

        // ---- 3) precarga: gancho al inicio de ww0.F ----
        if (preload == true) {
            val ww0 = mutableClassDefBy(classDefBy("Lww0;"))
            val a = ww0.methods.singleOrNull { m ->
                m.name == "F" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.map { it.toString() } ==
                    listOf("Landroid/content/Context;", "Lcom/eclipse/android/data/models/Song;", "Llv1;")
            } ?: error("No se encontro ww0.F(Context, Song, Continuation)")
            val impl = a.implementation ?: error("ww0.F sin codigo")
            // Verificado en 0.6.57: 20 registros -> p0=v16, p1=v17 (Context), p2=v18 (Song), p3=v19.
            if (impl.registerCount != 20) error("ww0.F: se esperaban 20 registros (hay ${impl.registerCount})")
            val ai = impl.instructions.toList()
            if (ai.firstOrNull()?.opcode != Opcode.MOVE_OBJECT_FROM16) error("ww0.F: la primera instruccion no es move-object/from16")
            var pos = 0
            for (ins in ai) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("ww0.F: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            val hook = if (wifiOnly == true) "onSongWifi" else "onSongAny"
            a.addInstructions(
                0,
                "invoke-static/range {p1 .. p2}, $PRELOAD_HELPER->$hook(Landroid/content/Context;Ljava/lang/Object;)V"
            )
        }
    }
}
