package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val CACHE_HELPER = "Lapp/eclipse/extension/canvas/CanvasCache;"
private const val PRELOAD_HELPER = "Lapp/eclipse/extension/canvas/CanvasPreload;"

/**
 * Eclipse 0.6.55: los ExoPlayer de los Canvas (kw0.H -> ox2.a()) leen el video directo de la red. Eclipse ya trae
 * una cache de media3 (au8.v.d(Context) -> aw8) y una fabrica de fuente con cache (ky0, usada en ie0.k para las
 * canciones).
 *
 * 1) kw0.H(Context, String, int, boolean): `CanvasCache.begin()` justo antes de `ox2.a()` y `CanvasCache.end()` justo
 *    despues (marca que ESE ExoPlayer es de un Canvas; ox2 lo usan otros sitios que no se tocan). kw0.H la llaman
 *    kw0.f (Canvas del reproductor) y ry1.p (otra vista de video animado).
 * 2) v72.<init>(Context, h62) (la fabrica de fuentes por defecto: nb0.get casos 1 y 3 -> `v72(m14(ctx, 12), h62)`): la
 *    fuente de red m14 pasa por `CanvasCache.wrap(ctx, m14)`, que la envuelve con ky0 solo mientras begin/end esta activo.
 * 3) Opcion `preload` (v1.95.0): al inicio de oo2.a(Context, Song, ou1) se llama a `CanvasPreload.onSongWifi/onSongAny
 *    (ctx, song)` con `invoke-static/range {p1 .. p2}`; si la cancion es la actual de la cola, tras unos segundos se
 *    resuelve y baja a la cache el Canvas de la SIGUIENTE (ver CanvasPreload.java).
 */
@Suppress("unused")
val canvasCachePatch = bytecodePatch(
    name = "Canvas: cache compartida",
    description = "Los videos de los Canvas pasan por la misma cache de disco que usa Eclipse para las canciones. " +
        "Los Canvas ya vistos cargan casi al instante y los dos videos de una cancion (portada y fondo) comparten " +
        "lo ya bajado. La primera descarga demora igual salvo que uses la precarga (opcion). Ocupa algo de espacio extra " +
        "en la cache de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val preload by booleanOption(
        key = "preload",
        default = true,
        title = "Precargar el Canvas de la siguiente cancion",
        description = "Mientras suena la cancion actual, baja el Canvas de la siguiente (el de la cola, con shuffle y " +
            "\"a continuacion\") a la cache para que cargue al instante. Solo videos normales (no HLS/m3u8). Usa algo de datos."
    )

    val wifiOnly by booleanOption(
        key = "wifiOnly",
        default = true,
        title = "Precargar solo con Wi-Fi",
        description = "No precarga si la red esta marcada como de uso limitado (datos moviles). Solo aplica a la precarga."
    )

    execute {
        // ---- 2) v72.<init>(Context, h62): envolver la fuente de red m14 ----
        val v72 = mutableClassDefBy(classDefBy("Lv72;"))
        val init = v72.methods.singleOrNull { m ->
            m.name == "<init>" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Lh62;")
        } ?: error("No se encontro v72.<init>(Context, h62) (version de Eclipse distinta de 0.6.55?)")
        val gi = (init.implementation ?: error("v72.<init> sin codigo")).instructions.toList()

        val v72Hits = gi.indices.filter { i ->
            val ref = (gi[i] as? ReferenceInstruction)?.reference as? MethodReference
            gi[i].opcode == Opcode.INVOKE_DIRECT && ref != null && ref.definingClass == "Lv72;" &&
                ref.name == "<init>" && ref.parameterTypes.map { it.toString() } == listOf("Lv22;", "Lh62;")
        }
        if (v72Hits.size != 1) error("v72.<init>: se esperaba 1 llamada a v72.<init>(v22, h62) (hay ${v72Hits.size})")
        val callAt = v72Hits[0]
        val call = gi[callAt] as FiveRegisterInstruction
        val factoryReg = call.registerD

        // La instruccion anterior debe ser m14.<init>(Context, I) sobre ese mismo registro.
        val prev = gi.getOrNull(callAt - 1)
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev == null || prev.opcode != Opcode.INVOKE_DIRECT || prevRef == null ||
            prevRef.definingClass != "Lm14;" || prevRef.name != "<init>" ||
            prevRef.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;", "I")
        ) error("v72.<init>: antes de la llamada se esperaba m14.<init>(Context, I)")
        val mCall = prev as FiveRegisterInstruction
        if (mCall.registerC != factoryReg) error("v72.<init>: m14 y la fabrica no son el mismo registro")
        val ctxReg = mCall.registerD
        if (factoryReg > 15 || ctxReg > 15) error("v72.<init>: registros fuera de v0..v15")

        init.addInstructions(
            callAt,
            """
                invoke-static {v$ctxReg, v$factoryReg}, $CACHE_HELPER->wrap(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$factoryReg
                check-cast v$factoryReg, Lv22;
            """
        )

        // ---- 1) kw0.H: begin/end alrededor de ox2.a() ----
        val kw0 = mutableClassDefBy(classDefBy("Lkw0;"))
        val h = kw0.methods.singleOrNull { m ->
            m.name == "H" && m.returnType == "Lgy2;" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Ljava/lang/String;", "I", "Z")
        } ?: error("No se encontro kw0.H(Context, String, int, boolean)")
        val hi = (h.implementation ?: error("kw0.H sin codigo")).instructions.toList()

        val aHits = hi.indices.filter { i ->
            val ref = (hi[i] as? ReferenceInstruction)?.reference as? MethodReference
            hi[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Lox2;" &&
                ref.name == "a" && ref.returnType == "Lgy2;" && ref.parameterTypes.isEmpty()
        }
        if (aHits.size != 1) error("kw0.H: se esperaba 1 llamada a ox2.a() (hay ${aHits.size})")
        val aAt = aHits[0]
        if (hi.getOrNull(aAt + 1)?.opcode != Opcode.MOVE_RESULT_OBJECT) error("kw0.H: tras ox2.a() se esperaba move-result-object")

        // Primero la de despues (para no mover el indice de la de antes).
        h.addInstructions(aAt + 2, "invoke-static {}, $CACHE_HELPER->end()V")
        h.addInstructions(aAt, "invoke-static {}, $CACHE_HELPER->begin()V")

        // ---- 3) precarga: gancho al inicio de oo2.a ----
        if (preload == true) {
            val oo2 = mutableClassDefBy(classDefBy("Loo2;"))
            val a = oo2.methods.singleOrNull { m ->
                m.name == "a" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.map { it.toString() } ==
                    listOf("Landroid/content/Context;", "Lcom/eclipse/android/data/models/Song;", "Lou1;")
            } ?: error("No se encontro oo2.a(Context, Song, Continuation)")
            val impl = a.implementation ?: error("oo2.a sin codigo")
            // Verificado en 0.6.55: 21 registros -> p0=v17, p1=v18 (Context), p2=v19 (Song), p3=v20.
            if (impl.registerCount != 21) error("oo2.a: se esperaban 21 registros (hay ${impl.registerCount})")
            val ai = impl.instructions.toList()
            if (ai.firstOrNull()?.opcode != Opcode.MOVE_OBJECT_FROM16) error("oo2.a: la primera instruccion no es move-object/from16")
            var pos = 0
            for (ins in ai) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("oo2.a: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            val hook = if (wifiOnly == true) "onSongWifi" else "onSongAny"
            a.addInstructions(
                0,
                "invoke-static/range {p1 .. p2}, $PRELOAD_HELPER->$hook(Landroid/content/Context;Ljava/lang/Object;)V"
            )
        }
    }
}
