package app.eclipse.patches.canvas

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OffsetInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val CACHE_HELPER = "Lapp/eclipse/extension/canvas/CanvasCache;"
private const val PRELOAD_HELPER = "Lapp/eclipse/extension/canvas/CanvasPreload;"

/**
 * Eclipse 0.6.61: los ExoPlayer de los Canvas (qj4.u -> kz2.a()) leen el video directo de la red. Eclipse ya trae
 * una cache de media3 (kx8.v.d(Context) -> kz8) y una fabrica de fuente con cache (yz0, usada para las
 * canciones).
 *
 * 1) qj4.u(Context, String, int, boolean): `CanvasCache.begin()` justo antes de `kz2.a()` y `CanvasCache.end()` justo
 *    despues (marca que ESE ExoPlayer es de un Canvas; kz2 lo usan otros sitios que no se tocan). qj4.u la llaman
 *    (en 0.6.57 n34.h, Canvas del reproductor; no revisado en 0.6.61) y otra vista de video animado.
 * 2) q92.<init>(Context, b82) (la fabrica de fuentes por defecto: sc0.get casos 1 y 3 -> `q92(h34(ctx), b82)`): la
 *    fuente de red h34 pasa por `CanvasCache.wrap(ctx, h34)`, que la envuelve con yz0 solo mientras begin/end esta activo.
 * 3) Opcion `preload` (v1.95.0): al inicio de ux0.F(Context, Song, jw1) se llama a `CanvasPreload.onSongWifi/onSongAny
 *    (ctx, song)` con `invoke-static/range {p1 .. p2}`; si la cancion es la actual de la cola, tras unos segundos se
 *    resuelve y baja a la cache el Canvas de la SIGUIENTE (ver CanvasPreload.java).
 */
@Suppress("unused")
val canvasCachePatch = bytecodePatch(
    name = "Canvas: cache compartida",
    description = "(Solo Canvas de Spotify y de la lista de la comunidad; Tidal y Apple no se tocan.) Los videos de los Canvas pasan por la misma cache de disco que usa Eclipse para las canciones. " +
        "Los Canvas ya vistos cargan casi al instante y los dos videos de una cancion (portada y fondo) comparten " +
        "lo ya bajado. La primera descarga demora igual salvo que uses la precarga (opcion). Ocupa algo de espacio extra " +
        "en la cache de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val preload by booleanOption(
        key = "preload",
        default = true,
        title = "Precargar el Canvas de la siguiente cancion",
        description = "Mientras suena la cancion actual, baja el Canvas de la siguiente (el de la cola, con shuffle y " +
            "\"a continuacion\") a la cache para que cargue al instante. Solo videos normales (no HLS/m3u8). Usa algo de datos."
    )

    val wifiOnly by booleanOption(
        key = "wifiOnly",
        default = true,
        title = "Precargar solo con Wi-Fi",
        description = "No precarga si la red esta marcada como de uso limitado (datos moviles). Solo aplica a la precarga."
    )

    execute {
        // ---- 2) q92.<init>(Context, b82): envolver la fuente de red h34 ----
        val u82 = mutableClassDefBy(classDefBy("Lq92;"))
        val init = u82.methods.singleOrNull { m ->
            m.name == "<init>" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Lb82;")
        } ?: error("No se encontro q92.<init>(Context, b82) (version de Eclipse distinta de 0.6.61?)")
        val gi = (init.implementation ?: error("q92.<init> sin codigo")).instructions.toList()

        val u82Hits = gi.indices.filter { i ->
            val ref = (gi[i] as? ReferenceInstruction)?.reference as? MethodReference
            gi[i].opcode == Opcode.INVOKE_DIRECT && ref != null && ref.definingClass == "Lq92;" &&
                ref.name == "<init>" && ref.parameterTypes.map { it.toString() } == listOf("Lm42;", "Lb82;")
        }
        if (u82Hits.size != 1) error("q92.<init>: se esperaba 1 llamada a q92.<init>(m42, b82) (hay ${u82Hits.size})")
        val callAt = u82Hits[0]
        val call = gi[callAt] as FiveRegisterInstruction
        val factoryReg = call.registerD

        // La instruccion anterior debe ser h34.<init>(Context, I) sobre ese mismo registro.
        val prev = gi.getOrNull(callAt - 1)
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev == null || prev.opcode != Opcode.INVOKE_DIRECT || prevRef == null ||
            prevRef.definingClass != "Lh34;" || prevRef.name != "<init>" ||
            prevRef.parameterTypes.map { it.toString() } != listOf("Landroid/content/Context;")
        ) error("q92.<init>: antes de la llamada se esperaba h34.<init>(Context)")
        val mCall = prev as FiveRegisterInstruction
        if (mCall.registerC != factoryReg) error("q92.<init>: h34 y la fabrica no son el mismo registro")
        val ctxReg = mCall.registerD
        if (factoryReg > 15 || ctxReg > 15) error("q92.<init>: registros fuera de v0..v15")

        init.addInstructions(
            callAt,
            """
                invoke-static {v$ctxReg, v$factoryReg}, $CACHE_HELPER->wrap(Landroid/content/Context;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$factoryReg
                check-cast v$factoryReg, Lm42;
            """
        )

        // ---- 1) qj4.u: begin/end alrededor de kz2.a() ----
        val n34 = mutableClassDefBy(classDefBy("Lqj4;"))
        val h = n34.methods.singleOrNull { m ->
            m.name == "u" && m.returnType == "Lc03;" && m.parameterTypes.map { it.toString() } ==
                listOf("Landroid/content/Context;", "Ljava/lang/String;", "I", "Z")
        } ?: error("No se encontro qj4.u(Context, String, int, boolean)")
        val hi = (h.implementation ?: error("qj4.u sin codigo")).instructions.toList()

        val aHits = hi.indices.filter { i ->
            val ref = (hi[i] as? ReferenceInstruction)?.reference as? MethodReference
            hi[i].opcode == Opcode.INVOKE_VIRTUAL && ref != null && ref.definingClass == "Lkz2;" &&
                ref.name == "a" && ref.returnType == "Lc03;" && ref.parameterTypes.isEmpty()
        }
        if (aHits.size != 1) error("qj4.u: se esperaba 1 llamada a kz2.a() (hay ${aHits.size})")
        val aAt = aHits[0]
        if (hi.getOrNull(aAt + 1)?.opcode != Opcode.MOVE_RESULT_OBJECT) error("qj4.u: tras kz2.a() se esperaba move-result-object")

        // v0.20.201: al inicio de qj4.u se anota la URL (p1) para que la cache solo se use con Canvas de Spotify/comunidad.
        run {
            val first = hi.firstOrNull() ?: error("qj4.u sin instrucciones")
            var pos = 0
            for (ins in hi) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("qj4.u: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            if (first.opcode == Opcode.MOVE_RESULT_OBJECT) error("qj4.u: la primera instruccion es un move-result")
        }

        // Primero la de despues (para no mover el indice de la de antes).
        h.addInstructions(aAt + 2, "invoke-static {}, $CACHE_HELPER->end()V")
        h.addInstructions(aAt, "invoke-static {}, $CACHE_HELPER->begin()V")
        h.addInstructions(0, "invoke-static/range {p1 .. p1}, $CACHE_HELPER->setUrl(Ljava/lang/String;)V")

        // ---- 3) precarga: gancho al inicio de ux0.F ----
        if (preload == true) {
            val ww0 = mutableClassDefBy(classDefBy("Lux0;"))
            val a = ww0.methods.singleOrNull { m ->
                m.name == "F" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.map { it.toString() } ==
                    listOf("Landroid/content/Context;", "Lcom/eclipse/android/data/models/Song;", "Ljw1;")
            } ?: error("No se encontro ux0.F(Context, Song, Continuation)")
            val impl = a.implementation ?: error("ux0.F sin codigo")
            // Verificado en 0.6.61: 20 registros -> p0=v16, p1=v17 (Context), p2=v18 (Song), p3=v19.
            if (impl.registerCount != 20) error("ux0.F: se esperaban 20 registros (hay ${impl.registerCount})")
            val ai = impl.instructions.toList()
            if (ai.firstOrNull()?.opcode != Opcode.MOVE_OBJECT_FROM16) error("ux0.F: la primera instruccion no es move-object/from16")
            var pos = 0
            for (ins in ai) {
                if (ins is OffsetInstruction && ins.opcode != Opcode.PACKED_SWITCH && ins.opcode != Opcode.SPARSE_SWITCH &&
                    pos + ins.codeOffset == 0
                ) error("ux0.F: alguien salta al inicio del metodo")
                pos += ins.codeUnits
            }
            val hook = if (wifiOnly == true) "onSongWifi" else "onSongAny"
            a.addInstructions(
                0,
                "invoke-static/range {p1 .. p2}, $PRELOAD_HELPER->$hook(Landroid/content/Context;Ljava/lang/Object;)V"
            )
        }
    }
}
