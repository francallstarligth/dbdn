package app.eclipse.patches.share

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch

private const val JAML = "Lapp/eclipse/extension/share/JamLink;"

/**
 * v0.20.360 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Parte 1 (manifiesto): MainActivity reclama https://jamlink.pages.dev (autoVerify,
 * necesita https://jamlink.pages.dev/.well-known/assetlinks.json con la huella de la firma de Morphe). Se edita el AndroidManifest.xml como texto
 * (igual que `get("res")` en otros parches): se inserta el intent-filter justo antes del `</activity>` de MainActivity.
 */
@Suppress("unused")
val jamOpenManifestPatch = resourcePatch(
    name = "Abrir jam directo: manifiesto",
    description = "Anade al manifiesto el enlace jamlink.pages.dev para que Android abra Eclipse directo. Lo usa \"Abrir enlace de jam directo en la app\".",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val mf = get("AndroidManifest.xml")
        val txt = mf.readText()
        if (txt.contains("jamlink.pages.dev")) return@execute
        val start = txt.indexOf("com.eclipse.android.MainActivity\"")
        if (start < 0) error("Abrir jam directo: no se encontro MainActivity en el manifiesto")
        val end = txt.indexOf("</activity>", start)
        if (end < 0) error("Abrir jam directo: MainActivity sin </activity>")
        val filter = "<intent-filter android:autoVerify=\"true\">" +
            "<action android:name=\"android.intent.action.VIEW\"/>" +
            "<category android:name=\"android.intent.category.DEFAULT\"/>" +
            "<category android:name=\"android.intent.category.BROWSABLE\"/>" +
            "<data android:scheme=\"https\" android:host=\"jamlink.pages.dev\"/>" +
            "</intent-filter>"
        mf.writeText(txt.substring(0, end) + filter + txt.substring(end))
    }
}

/**
 * Parte 2 (codigo): al inicio de MainActivity.onCreate(Bundle) y onNewIntent(Intent) se cambia el dato del Intent
 * (https://jamlink.pages.dev/?i=CODIGO -> debridmusic://jam?id=CODIGO), que la app ya sabe abrir. No usa registros libres.
 */
@Suppress("unused")
val jamOpenPatch = bytecodePatch(
    name = "Abrir enlace de jam directo en la app",
    description = "Los enlaces de jamlink.pages.dev se abren directo en Eclipse (sin pasar por el navegador). " +
        "Necesita el archivo assetlinks.json en la pagina con la huella de tu firma.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(jamOpenManifestPatch)
    extendWith("extensions/extension.mpe")

    execute {
        val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))

        val oc = main.methods.singleOrNull {
            it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
        } ?: error("Abrir jam directo: no se encontro MainActivity.onCreate")
        oc.addInstructions(0, "invoke-static {p0}, $JAML->rewriteActivity(Landroid/app/Activity;)V")

        val ni = main.methods.singleOrNull {
            it.name == "onNewIntent" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/content/Intent;")
        } ?: error("Abrir jam directo: no se encontro MainActivity.onNewIntent")
        ni.addInstructions(0, "invoke-static {p1}, $JAML->rewrite(Landroid/content/Intent;)V")
    }
}
