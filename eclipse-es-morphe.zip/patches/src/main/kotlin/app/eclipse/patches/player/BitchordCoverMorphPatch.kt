package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"
private const val MORPH = "Lapp/eclipse/extension/player/LayerMorph;"

/**
 * v0.20.37 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableMorph) en los mismos dos sitios que "Bitchord: Letras estilo Apple Music"; el trabajo
 * esta en BitchordLyrics.morph(): en Letra y Cola la portada grande se achica al lugar de la portada chica
 * (Eclipse mezcla la posicion de cada capa entre pestanas), y al volver a Artwork crece de nuevo.
 */
@Suppress("unused")
val bitchordCoverMorphPatch = bytecodePatch(
    name = "Bitchord: la portada chica crece (Letra)",
    description = "Al ir a Letra o Cola, la portada, el titulo, el artista, la estrella y los tres puntos suben a la cabecera moviendose " +
        "(y al volver a Artwork bajan). Necesita 'Bitchord: Letras estilo Apple Music'. Crea el diseno de nuevo desde Nuevo reproductor > Bitchord. " +
        "Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordLyricsPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // v0.20.249 (SIN COMPILAR NI PROBAR): portado a 0.6.70. Nombres: qc7=st7, sc7=ut7, vh6=pq7, q97=mq7, i21=d51, jn4=eu4, uw6=hd7.
        val dl6 = mutableClassDefBy(classDefBy("Lst7;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lut7;"
        } ?: error("No se encontro st7.c(ut7, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        val jh6 = mutableClassDefBy(classDefBy("Lpq7;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro pq7.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // Movimiento. mq7.d dibuja UNA capa: tamano con mq7.M(eu4, F, F) y posicion con eu4.a (x) y eu4.b (y), que en 0.6.70
        // se leen de dos llamadas a d51.u() (antes una sola copia del registro). Se cambia ese eu4 por uno mezclado
        // (LayerMorph.tf) en los 3 sitios. Si LayerMorph falla, devuelve el eu4 original.
        val di6 = mutableClassDefBy(classDefBy("Lmq7;"))
        val d = di6.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size >= 2 &&
                it.parameterTypes[0] == "Ld51;" && it.parameterTypes[1] == "Ld51;"
        } ?: error("No se encontro mq7.d(d51, d51, ...)")
        val ins = d.implementation!!.instructions.toList()

        // sitios 2 y 3 (x e y): invoke-virtual {d51}, Ld51;->u()Leu4; + move-result-object
        val tIdx = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_VIRTUAL && r != null && r.definingClass == "Ld51;" && r.name == "u" &&
                r.returnType == "Leu4;" && r.parameterTypes.isEmpty()
        }
        if (tIdx.size != 2) error("mq7.d: se esperaban 2 llamados a d51.u() (hay ${tIdx.size})")
        class MorphSite(val at: Int, val layer: Int, val dst: Int)
        val sites = tIdx.map { i ->
            if (ins[i + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("mq7.d: falta move-result-object tras d51.u()")
            val layer = (ins[i] as FiveRegisterInstruction).registerC
            val dst = (ins[i + 1] as OneRegisterInstruction).registerA
            if (layer > 15 || dst > 15) error("mq7.d: registros altos en d51.u() (v$layer, v$dst)")
            if (layer == dst) error("mq7.d: la capa y el destino de d51.u() son el mismo registro")
            MorphSite(i + 2, layer, dst)
        }

        // sitio 1 (tamano): invoke-static {eu4, F, F}, Lmq7;->M(Leu4;FF)J ; la capa sale de un iget Ld51;->a justo antes.
        val mIdx = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lmq7;" && r.name == "M" &&
                r.parameterTypes == listOf("Leu4;", "F", "F")
        }
        if (mIdx.size != 1) error("mq7.d: se esperaba 1 llamado a mq7.M (hay ${mIdx.size})")
        val mZb = (ins[mIdx[0]] as FiveRegisterInstruction).registerC
        // En 0.6.70 el eu4 sale de `iget-object v4, v0, Ld51;->d:Leu4;` (campo d, no a): el registro B es la capa.
        val idGet = (mIdx[0] - 1 downTo maxOf(mIdx[0] - 6, 0)).firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
            ins[i].opcode == Opcode.IGET_OBJECT && r != null && r.definingClass == "Ld51;" && r.type == "Leu4;" &&
                (ins[i] as OneRegisterInstruction).registerA == mZb
        } ?: error("mq7.d: no se encontro el iget Ld51;->d:Leu4; antes de mq7.M")
        val mLayer = (ins[idGet] as TwoRegisterInstruction).registerB
        if (mZb > 15 || mLayer > 15) error("mq7.d: registros altos en mq7.M (v$mZb, v$mLayer)")
        if (mLayer == mZb) error("mq7.d: la capa y el eu4 de mq7.M son el mismo registro")
        if (sites.any { it.at < mIdx[0] }) error("mq7.d: orden inesperado (d51.u() antes de mq7.M)")

        // Tambien al dibujar el reproductor (mq7.q), para que morphMode este puesto cuando se renueva la tarjeta.
        val qm = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lhd7;"
        } ?: error("No se encontro mq7.q")
        qm.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // De abajo hacia arriba para no correr los indices.
        for (s in sites.sortedByDescending { it.at }) {
            d.addInstructions(
                s.at,
                """
                    invoke-static {v${s.layer}, v${s.dst}}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                    move-result-object v${s.dst}
                    check-cast v${s.dst}, Leu4;
                """
            )
        }
        d.addInstructions(
            mIdx[0],
            """
                invoke-static {v$mLayer, v$mZb}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$mZb
                check-cast v$mZb, Leu4;
            """
        )
    }
}
