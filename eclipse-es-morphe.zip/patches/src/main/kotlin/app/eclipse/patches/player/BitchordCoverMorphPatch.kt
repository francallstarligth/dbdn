package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"
private const val MORPH = "Lapp/eclipse/extension/player/LayerMorph;"

/**
 * v0.20.37 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableMorph) en los mismos dos sitios que "Bitchord: Letras estilo Apple Music"; el trabajo
 * esta en BitchordLyrics.morph(): en Letra y Cola la portada grande se achica al lugar de la portada chica
 * (Eclipse mezcla la posicion de cada capa entre pestanas), y al volver a Artwork crece de nuevo.
 */
@Suppress("unused")
val bitchordCoverMorphPatch = bytecodePatch(
    name = "Bitchord: la portada chica crece (Letra)",
    description = "Al ir a Letra o Cola, la portada, el titulo, el artista, la estrella y los tres puntos suben a la cabecera moviendose " +
        "(y al volver a Artwork bajan). Necesita 'Bitchord: Letras estilo Apple Music'. Crea el diseno de nuevo desde Nuevo reproductor > Bitchord. " +
        "Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordLyricsPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // v0.20.270 (SIN COMPILAR NI PROBAR): portado a 0.6.73. Nombres 70->73: st7=yu7, ut7=av7, pq7=tr7, mq7=qr7, d51=u51, eu4=iv4, hd7=le7.
        val dl6 = mutableClassDefBy(classDefBy("Lyu7;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lav7;"
        } ?: error("No se encontro st7.c(ut7, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        val jh6 = mutableClassDefBy(classDefBy("Ltr7;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro pq7.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // Movimiento. qr7.d dibuja UNA capa. En 0.6.73 el iv4 (posicion/tamano) se lee UNA sola vez al inicio con
        // `iget-object vX, vCapa, Lu51;->d:Liv4;` y de ahi sale el tamano (qr7.M), x (iv4.b) e y (iv4.a); los dos
        // llamados u51.u() de 0.6.70 ya no existen (inlineados). Se cambia ese iv4 por uno mezclado (LayerMorph.tf)
        // justo despues de ese iget: asi los 3 usos reciben el valor mezclado. Si LayerMorph falla, devuelve el original.
        val di6 = mutableClassDefBy(classDefBy("Lqr7;"))
        val d = di6.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size >= 2 &&
                it.parameterTypes[0] == "Lu51;" && it.parameterTypes[1] == "Lu51;"
        } ?: error("No se encontro qr7.d(u51, u51, ...)")
        val ins = d.implementation!!.instructions.toList()

        val getIdx = ins.indices.take(40).firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
            ins[i].opcode == Opcode.IGET_OBJECT && r != null && r.definingClass == "Lu51;" && r.name == "d" && r.type == "Liv4;"
        } ?: error("qr7.d: no se encontro iget u51.d:iv4 al inicio")
        val layerReg = (ins[getIdx] as TwoRegisterInstruction).registerB
        val dstReg = (ins[getIdx] as TwoRegisterInstruction).registerA
        if (layerReg > 15 || dstReg > 15) error("qr7.d: registros altos en el iget (v$layerReg, v$dstReg)")
        if (layerReg == dstReg) error("qr7.d: la capa y el destino del iget son el mismo registro")

        // Comprobaciones: 1 llamado a qr7.M(iv4, F, F) y 2 lecturas iget-wide iv4.a / iv4.b (tamano, x, y).
        val mCount = ins.count { i ->
            val r = (i as? ReferenceInstruction)?.reference as? MethodReference
            i.opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lqr7;" && r.name == "M" &&
                r.parameterTypes == listOf("Liv4;", "F", "F")
        }
        if (mCount != 1) error("qr7.d: se esperaba 1 llamado a qr7.M (hay $mCount)")
        val wideCount = ins.count { i ->
            val r = (i as? ReferenceInstruction)?.reference as? FieldReference
            i.opcode == Opcode.IGET_WIDE && r != null && r.definingClass == "Liv4;" && (r.name == "a" || r.name == "b")
        }
        if (wideCount != 2) error("qr7.d: se esperaban 2 lecturas de iv4.a/b (hay $wideCount)")

        // Tambien al dibujar el reproductor (mq7.q), para que morphMode este puesto cuando se renueva la tarjeta.
        val qm = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lle7;"
        } ?: error("No se encontro mq7.q")
        qm.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // v0.20.276 (SIN COMPILAR NI PROBAR): en 0.6.73 la X de la capa NO sale de qr7.d sino de xp7.invoke (una lambda de
        // posicion), que lee `u51.d` (el iv4 ORIGINAL) otra vez: por eso la portada se achicaba hacia el centro. Se mezcla
        // tambien ahi. xp7.invoke: v5=param, v4=this, v0..v3 libres al inicio; indice 3 = `iget-object v5, v5, u51.d`.
        val xp = mutableClassDefBy(classDefBy("Lxp7;"))
        val inv = xp.methods.singleOrNull {
            it.name == "invoke" && it.returnType == "Ljava/lang/Object;" && it.parameterTypes == listOf("Ljava/lang/Object;")
        } ?: error("No se encontro xp7.invoke")
        val xi = inv.implementation!!.instructions.toList()
        val xGet = xi.indices.take(10).firstOrNull { i ->
            val r = (xi[i] as? ReferenceInstruction)?.reference as? FieldReference
            xi[i].opcode == Opcode.IGET_OBJECT && r != null && r.definingClass == "Lu51;" && r.name == "d" && r.type == "Liv4;"
        } ?: error("xp7.invoke: no se encontro iget u51.d:iv4")
        val xa = xi[xGet] as TwoRegisterInstruction
        val xRead = xi[xGet + 1]
        val xr = (xRead as? ReferenceInstruction)?.reference as? FieldReference
        if (xRead.opcode != Opcode.IGET_WIDE || xr == null || xr.definingClass != "Liv4;" || xr.name != "a")
            error("xp7.invoke: despues del iget no viene iget-wide iv4.a")
        if (xa.registerA != xa.registerB) error("xp7.invoke: se esperaba iget v5, v5")
        if (xa.registerA > 15 || (xRead as OneRegisterInstruction).registerA != 0) error("xp7.invoke: registros inesperados")
        val xReg = xa.registerA
        // 1o el de despues (para no mover los indices), 2o el de antes.
        inv.addInstructions(
            xGet + 1,
            """
                invoke-static {v0, v$xReg}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$xReg
                check-cast v$xReg, Liv4;
            """
        )
        inv.addInstructions(xGet, "move-object v0, v$xReg")

        d.addInstructions(
            getIdx + 1,
            """
                invoke-static {v$layerReg, v$dstReg}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$dstReg
                check-cast v$dstReg, Liv4;
            """
        )
    }
}
