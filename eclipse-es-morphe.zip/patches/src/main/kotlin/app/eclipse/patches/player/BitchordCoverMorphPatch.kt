package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"

/**
 * v0.20.37 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableMorph) en los mismos dos sitios que "Bitchord: Letras estilo Apple Music"; el trabajo
 * esta en BitchordLyrics.morph(): en Letra y Cola la portada grande se achica al lugar de la portada chica
 * (Eclipse mezcla la posicion de cada capa entre pestanas), y al volver a Artwork crece de nuevo.
 */
@Suppress("unused")
val bitchordCoverMorphPatch = bytecodePatch(
    name = "Bitchord: la portada chica crece (Letra)",
    description = "En Letra y Cola la portada grande se achica hasta la esquina de arriba a la izquierda, y al volver a Artwork " +
        "crece hasta su lugar. Necesita 'Bitchord: Letras estilo Apple Music'. Crea el diseno de nuevo desde Nuevo reproductor > Bitchord. " +
        "Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordLyricsPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val dl6 = mutableClassDefBy(classDefBy("Ldl6;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "b" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lfl6;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        val jh6 = mutableClassDefBy(classDefBy("Ljh6;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")
    }
}
