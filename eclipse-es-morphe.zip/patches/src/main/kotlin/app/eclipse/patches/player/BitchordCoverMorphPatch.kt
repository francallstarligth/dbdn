package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"
private const val MORPH = "Lapp/eclipse/extension/player/LayerMorph;"

/**
 * v0.20.37 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableMorph) en los mismos dos sitios que "Bitchord: Letras estilo Apple Music"; el trabajo
 * esta en BitchordLyrics.morph(): en Letra y Cola la portada grande se achica al lugar de la portada chica
 * (Eclipse mezcla la posicion de cada capa entre pestanas), y al volver a Artwork crece de nuevo.
 */
@Suppress("unused")
val bitchordCoverMorphPatch = bytecodePatch(
    name = "Bitchord: la portada chica crece (Letra)",
    description = "Al ir a Letra o Cola, la portada, el titulo, el artista, la estrella y los tres puntos suben a la cabecera moviendose " +
        "(y al volver a Artwork bajan). Necesita 'Bitchord: Letras estilo Apple Music'. Crea el diseno de nuevo desde Nuevo reproductor > Bitchord. " +
        "Si falla, desmarcalo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordLyricsPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val dl6 = mutableClassDefBy(classDefBy("Lqc7;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lsc7;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        val jh6 = mutableClassDefBy(classDefBy("Lvh6;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // v0.20.39: movimiento. di6.d (dibuja UNA capa) calcula tamano con di6.M(zb4, F, F) y la posicion con zb4.a (x) y
        // zb4.b (y). Se cambia ese zb4 por uno mezclado (LayerMorph.tf) en los dos sitios que lo leen dentro del cuerpo:
        // (1) justo antes de di6.M (su registro de zb4 sigue vivo y se copia luego a otro para la y), (2) justo despues de
        // dw0.t() (que da la x). Solo cambia las 5 capas marcadas; si LayerMorph falla, devuelve el zb4 original.
        val di6 = mutableClassDefBy(classDefBy("Lq97;"))
        val d = di6.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size >= 2 &&
                it.parameterTypes[0] == "Li21;" && it.parameterTypes[1] == "Li21;"
        } ?: error("No se encontro di6.d(dw0, dw0, ...)")
        val ins = d.implementation!!.instructions.toList()

        // sitio 2 (x): invoke-virtual {dw0}, Li21;->t()Ljn4; + move-result-object
        val tIdx = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_VIRTUAL && r != null && r.definingClass == "Li21;" && r.name == "t" &&
                r.returnType == "Ljn4;"
        }
        if (tIdx.size != 1) error("di6.d: se esperaba 1 llamado a dw0.t() (hay ${tIdx.size})")
        if (ins[tIdx[0] + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("di6.d: falta move-result-object tras dw0.t()")
        val tLayer = (ins[tIdx[0]] as FiveRegisterInstruction).registerC
        val tDst = (ins[tIdx[0] + 1] as OneRegisterInstruction).registerA
        if (tLayer > 15 || tDst > 15) error("di6.d: registros altos en dw0.t() (v$tLayer, v$tDst)")

        // sitio 1 (tamano y y): invoke-static {zb4, F, F}, Lq97;->M(Ljn4;FF)J ; la capa sale de un iget Li21;->a justo antes.
        val mIdx = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lq97;" && r.name == "M" &&
                r.parameterTypes == listOf("Ljn4;", "F", "F")
        }
        if (mIdx.size != 1) error("di6.d: se esperaba 1 llamado a di6.M (hay ${mIdx.size})")
        val mZb = (ins[mIdx[0]] as FiveRegisterInstruction).registerC
        val idGet = (mIdx[0] - 1 downTo maxOf(mIdx[0] - 6, 0)).firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? FieldReference
            ins[i].opcode == Opcode.IGET_OBJECT && r != null && r.definingClass == "Li21;" && r.name == "a"
        } ?: error("di6.d: no se encontro el iget Li21;->a antes de di6.M")
        val mLayer = (ins[idGet] as TwoRegisterInstruction).registerB
        if (mZb > 15 || mLayer > 15) error("di6.d: registros altos en di6.M (v$mZb, v$mLayer)")
        if (tIdx[0] < mIdx[0]) error("di6.d: orden inesperado (dw0.t() antes de di6.M)")

        // v0.20.53: tambien al dibujar el reproductor (di6.q), para que morphMode este puesto cuando se renueva la tarjeta.
        val qm = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Luw6;"
        } ?: error("No se encontro di6.q")
        qm.addInstructions(0, "invoke-static {}, $EXT->enableMorph()V")

        // De abajo hacia arriba para no correr los indices.
        d.addInstructions(
            tIdx[0] + 2,
            """
                invoke-static {v$tLayer, v$tDst}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$tDst
                check-cast v$tDst, Ljn4;
            """
        )
        d.addInstructions(
            mIdx[0],
            """
                invoke-static {v$mLayer, v$mZb}, $MORPH->tf(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$mZb
                check-cast v$mZb, Ljn4;
            """
        )
    }
}
