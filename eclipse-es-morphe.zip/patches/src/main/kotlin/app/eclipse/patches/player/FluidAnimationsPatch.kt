package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.364 (SIN COMPILAR NI PROBAR). Un solo parche con las animaciones fluidas; cada efecto tiene su casilla.
 * Los efectos son sub-parches sin nombre (como en "Reproductor: animaciones"): miniPopPatch, pressScalePatch, coverGrowPatch.
 */
@Suppress("unused")
val fluidAnimationsPatch = bytecodePatch(
    name = "Animaciones fluidas",
    description = "Animaciones suaves: pop del mini reproductor con el boton, botones que se achican al tocar y caratula que " +
        "crece al dar play. Cada una tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val miniPop by booleanOption(
        key = "miniPop",
        default = true,
        title = "Pop del mini reproductor",
        description = "Al tocar siguiente o anterior en el mini reproductor se achica un poco y vuelve, igual que al deslizar."
    )

    val pressScale by booleanOption(
        key = "pressScale",
        default = true,
        title = "Botones que se achican al tocar",
        description = "Botones y tarjetas se achican un poquito mientras los presionas."
    )

    val coverGrow by booleanOption(
        key = "coverGrow",
        default = true,
        title = "Caratula que crece al dar play",
        description = "En pausa la caratula queda en su tamano normal y al dar play crece un poquito (necesita que el skin tenga respirar al pausar)."
    )

    execute {
        if (miniPop == true) miniPopPatch.execute(this)
        if (pressScale == true) pressScalePatch.execute(this)
        if (coverGrow == true) coverGrowPatch.execute(this)
    }
}
