package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.366 (SIN COMPILAR NI PROBAR). Un solo parche con las animaciones fluidas; cada efecto tiene su casilla.
 * Los efectos son sub-parches sin nombre (como en "Reproductor: animaciones"): miniPopPatch, coverGrowPatch, miniGrowPatch.
 */
@Suppress("unused")
val fluidAnimationsPatch = bytecodePatch(
    name = "Animaciones fluidas",
    description = "Animaciones suaves: pop del mini reproductor con el boton y caratula que " +
        "crece al dar play. Cada una tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val miniPop by booleanOption(
        key = "miniPop",
        default = true,
        title = "Pop del mini reproductor",
        description = "Al tocar siguiente o anterior en el mini reproductor se achica un poco y vuelve, igual que al deslizar."
    )

    val coverGrow by booleanOption(
        key = "coverGrow",
        default = true,
        title = "Caratula que crece al dar play",
        description = "En pausa la caratula queda en su tamano normal y al dar play crece un poquito (necesita que el skin tenga respirar al pausar)."
    )

    val miniGrow by booleanOption(
        key = "miniGrow",
        default = false,
        title = "Reproductor grande: crece desde el mini (experimento)",
        description = "Al abrir, el reproductor grande crece desde abajo al centro (sin subir) y al cerrar se achica hacia el mini. " +
            "Apaga \"Entrada del reproductor\" en \"Reproductor: animaciones\" y no lo uses con \"Salida mas lenta\"."
    )

    execute {
        if (miniPop == true) miniPopPatch.execute(this)
        if (coverGrow == true) coverGrowPatch.execute(this)
        if (miniGrow == true) miniGrowPatch.execute(this)
    }
}
