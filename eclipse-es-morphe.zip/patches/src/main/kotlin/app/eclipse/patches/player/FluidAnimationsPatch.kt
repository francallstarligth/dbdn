package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.380: se QUITA la casilla miniGrow ("Reproductor grande: crece desde el mini"): no se noto y el usuario pidio quitarla (MiniGrowPatch.kt y FluidB.java borrados).
 * v0.20.377: "miniGrow" reemplazado otra vez: ahora TODA la hoja del reproductor sale chiquita del mini y crece (MiniGrowPatch.kt + FluidB.java).
 * v0.20.374: "miniGrow" reemplazado: ahora la portada sale de la portada del mini y viaja a su sitio al abrir (MiniGrowPatch.kt).
 * v0.20.373: miniSlide sin diagnostico (la 372 se probo: funciona).
 * v0.20.368 (SIN COMPILAR NI PROBAR): miniSlide ahora engancha el mini de verdad (Lt62.i); se QUITA el pop del mini (miniPop).
 * v0.20.367: casilla nueva miniSlide (deslizar con el boton en el mini Native); miniPop pasa a apagada (era otro efecto).
 * v0.20.366. Un solo parche con las animaciones fluidas; cada efecto tiene su casilla.
 * Los efectos son sub-parches sin nombre (como en "Reproductor: animaciones"): miniSlidePatch, coverGrowPatch.
 */
@Suppress("unused")
val fluidAnimationsPatch = bytecodePatch(
    name = "Animaciones fluidas",
    description = "Animaciones suaves: el mini reproductor se desliza tambien con el boton y la caratula " +
        "crece al dar play. Cada una tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val miniSlide by booleanOption(
        key = "miniSlide",
        default = true,
        title = "Mini reproductor: deslizar tambien con el boton siguiente",
        description = "Al tocar siguiente en el mini reproductor de la skin Native (Apple Music), el contenido se desliza igual que al arrastrar con el dedo."
    )

    val coverGrow by booleanOption(
        key = "coverGrow",
        default = true,
        title = "Caratula que crece al dar play",
        description = "En pausa la caratula queda en su tamano normal y al dar play crece un poquito (necesita que el skin tenga respirar al pausar)."
    )

    execute {
        if (miniSlide == true) miniSlidePatch.execute(this)
        if (coverGrow == true) coverGrowPatch.execute(this)
    }
}
