package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.368 (SIN COMPILAR NI PROBAR): miniSlide ahora engancha el mini de verdad (Lt62.i); se QUITA el pop del mini (miniPop).
 * v0.20.367: casilla nueva miniSlide (deslizar con el boton en el mini Native); miniPop pasa a apagada (era otro efecto).
 * v0.20.366. Un solo parche con las animaciones fluidas; cada efecto tiene su casilla.
 * Los efectos son sub-parches sin nombre (como en "Reproductor: animaciones"): miniSlidePatch, coverGrowPatch, miniGrowPatch.
 */
@Suppress("unused")
val fluidAnimationsPatch = bytecodePatch(
    name = "Animaciones fluidas",
    description = "Animaciones suaves: el mini reproductor se desliza tambien con el boton y la caratula " +
        "crece al dar play. Cada una tiene su casilla.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val miniSlide by booleanOption(
        key = "miniSlide",
        default = true,
        title = "Mini reproductor: deslizar tambien con el boton siguiente",
        description = "Al tocar siguiente en el mini reproductor de la skin Native (Apple Music), el contenido se desliza igual que al arrastrar con el dedo."
    )

    val coverGrow by booleanOption(
        key = "coverGrow",
        default = true,
        title = "Caratula que crece al dar play",
        description = "En pausa la caratula queda en su tamano normal y al dar play crece un poquito (necesita que el skin tenga respirar al pausar)."
    )

    val miniGrow by booleanOption(
        key = "miniGrow",
        default = false,
        title = "Reproductor grande: crece desde el mini (experimento)",
        description = "Al abrir, el reproductor grande crece desde abajo al centro (sin subir) y al cerrar se achica hacia el mini. " +
            "Apaga \"Entrada del reproductor\" en \"Reproductor: animaciones\" y no lo uses con \"Salida mas lenta\"."
    )

    execute {
        if (miniSlide == true) miniSlidePatch.execute(this)
        if (coverGrow == true) coverGrowPatch.execute(this)
        if (miniGrow == true) miniGrowPatch.execute(this)
    }
}
