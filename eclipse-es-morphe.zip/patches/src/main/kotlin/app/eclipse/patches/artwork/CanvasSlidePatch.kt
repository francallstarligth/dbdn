package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val EXT = "Lapp/eclipse/extension/artwork/CoverUnderlay;"

/**
 * v0.20.46 (SIN COMPILAR / SIN PROBAR). Parche aparte (se puede desmarcar). En canciones CON Canvas, la portada que se
 * ve mientras el video espera (los ~1,8 s) entra deslizando igual que la portada normal (la vieja sale, la nueva entra
 * pegada, con el mismo reloj), en vez de aparecer de golpe encima. El video sale despues, ya quieto, con su fundido.
 * El trabajo esta en CoverUnderlay.CoverDrawable; este parche solo enciende el interruptor: gancho al inicio de
 * di6.q (el mismo metodo que usa el parche de arrastre; no usa registros).
 */
@Suppress("unused")
val canvasSlidePatch = bytecodePatch(
    name = "Canvas: la portada que espera tambien se desliza",
    description = "En canciones con Canvas, la portada que se ve antes de que salga el video entra deslizando junto con " +
        "la portada normal, no de golpe. Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(slideSkipPatch, animatedCoverNoFlashPatch)

    extendWith("extensions/extension.mpe")

    execute {
        val di6 = mutableClassDefBy(classDefBy("Ldi6;"))
        val q = di6.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Ly46;"
        } ?: error("No se encontro di6.q")
        q.addInstructions(0, "invoke-static {}, $EXT->enableSlide()V")
    }
}
