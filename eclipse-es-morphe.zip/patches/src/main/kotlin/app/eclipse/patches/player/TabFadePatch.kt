package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.459 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR). Cambio de pestana con fundido tipo "se apaga la vieja, aparece la nueva".
 *
 * Eclipse cambia de pestana con la navegacion de Compose; las 4 transiciones por defecto (enter/exit/popEnter/popExit) son
 * lambdas de `Lcd;->invoke` (casos 22, 23, 24, 25 del packed-switch). Hoy: entrada de pestana = fadeIn(tween 180 ms),
 * salida = fadeOut(tween 180 ms), las dos a la vez (casi un corte seco).
 *
 * Este parche solo cambia 2 de ellas (las otras dos, popEnter/popExit, no distinguen pestanas y tocarlas cambiaria el "atras"):
 *  - ENTRADA, rama "es pestana" (caso 22, la que sigue al `Ltk1;->s0` con el set tab_*): tween(200 ms, delay 100 ms).
 *  - SALIDA (caso 23): fadeOut con tween de 100 ms (antes 180). Ojo: esa salida no mira si es pestana, asi que vale para
 *    todas las rutas que usen ese fadeOut.
 * Resultado: la vieja se apaga en ~100 ms y la nueva entra despues, en ~200 ms. Solo se sobrescriben registros que en esa
 * rama ya no se usan (la rama termina en return), sin tocar destinos de salto.
 */
@Suppress("unused")
val tabFadePatch = bytecodePatch(
    name = "Pestanas: fundido al cambiar",
    description = "Al cambiar de pestana (Inicio, Buscar, Biblioteca, Descubrir) la pantalla vieja se apaga rapido y la " +
        "nueva aparece con fundido. Desmarcalo para volver al fundido normal de Eclipse.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cd = mutableClassDefBy(classDefBy("Lcd;"))
        val inv = cd.methods.singleOrNull {
            it.name == "invoke" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("Pestanas fundido: no se encontro Lcd;->invoke (version de Eclipse distinta de 0.6.75?)")
        val ins = (inv.implementation ?: error("Pestanas fundido: Lcd;->invoke sin codigo")).instructions.toList()

        fun isStatic(i: Int, cls: String, name: String): Boolean {
            if (i < 0 || i >= ins.size) return false
            val x = ins[i]
            if (x.opcode != Opcode.INVOKE_STATIC) return false
            val r = (x as ReferenceInstruction).reference as? MethodReference ?: return false
            return r.definingClass == cls && r.name == name
        }

        // ENTRADA (rama pestana): Ltk1;->s0(set, ruta) -> move-result -> if-eqz -> Lpab;->I (tween) -> move-result-object -> Li03;->e (fadeIn)
        val s0 = ins.indices.filter { isStatic(it, "Ltk1;", "s0") }
        if (s0.size != 1) error("Pestanas fundido: se esperaba 1 llamada a Ltk1;->s0 en Lcd;->invoke y hay ${s0.size}")
        val enterAt = s0[0] + 3
        if (ins[s0[0] + 2].opcode != Opcode.IF_EQZ || !isStatic(enterAt, "Lpab;", "I") || !isStatic(enterAt + 2, "Li03;", "e")) {
            error("Pestanas fundido: la rama de entrada de pestana no tiene la forma esperada")
        }

        // SALIDA (caso 23): Lpab;->I con v8 (180 ms) seguido de Li03;->f (fadeOut); antes de el, el if-eqz del flag sin animacion.
        val exits = ins.indices.filter {
            isStatic(it, "Lpab;", "I") && isStatic(it + 2, "Li03;", "f") &&
                (ins[it] as FiveRegisterInstruction).registerC == 8
        }
        if (exits.size != 1) error("Pestanas fundido: se esperaba 1 salida fadeOut(v8) y hay ${exits.size}")
        val exitAt = exits[0]
        val exitIf = exitAt - 3
        if (ins[exitIf].opcode != Opcode.IF_EQZ) error("Pestanas fundido: la rama de salida no tiene la forma esperada")

        // Primero el indice mas alto, para no mover el otro.
        // Entrada: tween(duracion 200, delay 100, easing por defecto): v8=200, v14=100, v10=4 (mascara: solo easing por defecto).
        inv.addInstructions(
            enterAt,
            """
            const/16 v8, 0xc8
            const/16 v14, 0x64
            const/4 v10, 0x4
            """
        )
        // Salida: v8 pasa de 180 a 100 ms antes del if-eqz (el if-eqz y el destino de su salto no se tocan).
        inv.addInstructions(
            exitIf,
            """
            const/16 v8, 0x64
            """
        )
    }
}
