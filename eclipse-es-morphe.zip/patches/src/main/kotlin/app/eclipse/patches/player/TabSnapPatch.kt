package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

/**
 * v0.20.233 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Arregla el parpadeo de Letra<->Cola en el canvas
 * (Apple Music V2 editable, Bitchord).
 *
 * Causa (leida en el codigo): s31.d(String) cambia al instante los nombres de pestana (b = destino, c = origen) y lanza
 * la corrutina del fundido (a0.b) con CoroutineStart.DEFAULT, que arranca mas tarde. Hasta que corre su primer paso
 * (snapTo(0)) el progreso `d` sigue en 1 (valor del fundido anterior) y s31.e da pesos al reves por un instante:
 * la Cola aparece entera (vacia, con "Nada a continuacion") o se destruye y se recrea. Luego snapTo(0) los corrige.
 *
 * Arreglo: en s31.d, la llamada `yx0.H(scope, null, null, bloque, 3)` (launch con contexto y start por defecto)
 * pasa a `yx0.H(scope, null, UNDISPATCHED, bloque, 1)`: el snapTo(0) corre en el mismo instante que cambian los nombres.
 */
@Suppress("unused")
val tabSnapPatch = bytecodePatch(
    name = "Pestanas: sin flash al cambiar Letra/Cola",
    description = "Arregla el parpadeo de la Cola (cartel \"Nada a continuacion\" y portadas vacias) al cambiar entre Letra y " +
        "Cola en los reproductores Custom (Apple Music V2 editable, Bitchord). El fundido de pestanas arrancaba un cuadro " +
        "tarde y mostraba un cuadro con los paneles al reves.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val s31 = mutableClassDefBy(classDefBy("Ls31;"))
        val d = s31.methods.singleOrNull {
            it.name == "d" && it.returnType == "V" && it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/String;"
        } ?: error("Pestanas: no se encontro s31.d(String) (version de Eclipse distinta de 0.6.61?)")
        val impl = d.implementation ?: error("Pestanas: s31.d sin codigo")

        val launches = impl.instructions.withIndex().filter { (_, ins) ->
            ins.opcode == Opcode.INVOKE_STATIC &&
                ((ins as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Lyx0;" && it.name == "H" && it.parameterTypes.size == 5
                } == true
        }
        if (launches.size != 1) error("Pestanas: se esperaba 1 llamada a yx0.H en s31.d y hay ${launches.size}")
        val at = launches.single().index

        // Antes de la llamada: v4 = mascara 1 (solo el contexto por defecto), v1 = UNDISPATCHED (v1 y v4 libres aqui:
        // v1 ya se uso en el `new a0`, v4 es p1 y ya se reasigna con `const/4 v4, 3`).
        d.addInstructions(
            at,
            """
            const/4 v4, 0x1
            sget-object v1, Lky1;->UNDISPATCHED:Lky1;
            invoke-static {v3, v2, v1, v0, v4}, Lyx0;->H(Lfy1;Ltx1;Lky1;Lsf3;I)Ljq9;
            """
        )
        d.removeInstruction(at + 3) // la llamada original
    }
}
