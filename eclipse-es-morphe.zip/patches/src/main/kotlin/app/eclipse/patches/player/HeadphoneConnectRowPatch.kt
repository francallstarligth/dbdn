package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val HEADPHONE_ROUTE = "Lapp/eclipse/extension/player/HeadphoneRoute;"

@Suppress("unused")
val headphoneConnectRowPatch = bytecodePatch(
    name = "Conectar: fila de audifonos",
    description = "Agrega la fila de tus audifonos (Bluetooth, cable o USB) en la hoja \"Conectar a un dispositivo\", " +
        "debajo de \"Este dispositivo\". Solo aparece cuando hay audifonos conectados. Al tocarla intenta cambiar la " +
        "salida de audio con el sistema de rutas de Android; si el sistema no lo permite, abre el selector de salida.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // b71.g dibuja la hoja. Orden verificado en 0.6.47: const-string "This device" -> pk1.c (fila) -> by9.f
        // (separador) -> `move-object/from16 v7, v23` (v23 = composer). La fila nueva va justo despues del
        // separador, envuelta en un grupo de reemplazo de Compose (c0 / q) igual que hace el compilador con un `if`.
        // Si algo no coincide, solo se omite con un println (la app queda como estaba).
        try {
            val b71 = mutableClassDefBy(classDefBy("Lb71;"))
            val g = b71.methods.singleOrNull {
                it.name == "g" && it.parameterTypes.size == 3 && it.parameterTypes.all { p -> p.toString() == "Ljava/lang/Object;" }
            } ?: error("b71.g no encontrado")
            val ins = (g.implementation ?: error("b71.g sin codigo")).instructions.toList()

            fun methodOf(i: Int): MethodReference? =
                (ins[i] as? ReferenceInstruction)?.reference as? MethodReference

            val thisDevice = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CONST_STRING &&
                    ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "This device"
            }
            if (thisDevice.size != 1) error("b71.g: se esperaba 1 \"This device\" (hay ${thisDevice.size})")
            val pk = (thisDevice[0] until ins.size).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE &&
                    methodOf(i)?.let { it.definingClass == "Lpk1;" && it.name == "c" } == true
            } ?: error("b71.g: pk1.c no encontrado")
            val div = (pk + 1 until minOf(pk + 40, ins.size)).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE &&
                    methodOf(i)?.let { it.definingClass == "Lby9;" && it.name == "f" } == true
            } ?: error("b71.g: by9.f no encontrado")
            val at = div + 1
            val next = ins[at]
            if (next.opcode != Opcode.MOVE_OBJECT_FROM16 ||
                (next as OneRegisterInstruction).registerA != 7 ||
                (next as TwoRegisterInstruction).registerB != 23
            ) {
                error("b71.g: se esperaba move-object/from16 v7, v23 tras el separador")
            }

            g.addInstructionsWithLabels(
                at,
                """
                    invoke-static {}, $HEADPHONE_ROUTE->present()Z
                    move-result v19
                    if-eqz v19, :hp_else
                    const v24, 0x2a1b0c01
                    invoke-virtual/range {v23 .. v24}, Lqi1;->c0(I)V
                    move-object/from16 v30, v23
                    invoke-static {}, Lu05;->x()Ldo3;
                    move-result-object v19
                    invoke-static {}, $HEADPHONE_ROUTE->title()Ljava/lang/String;
                    move-result-object v20
                    invoke-static {}, $HEADPHONE_ROUTE->subtitle()Ljava/lang/String;
                    move-result-object v21
                    const-wide/16 v22, 0x0
                    move-wide/from16 v24, v0
                    const/16 v26, 0x0
                    move-wide/from16 v27, v0
                    invoke-static {}, $HEADPHONE_ROUTE->click()Ljava/lang/Object;
                    move-result-object v29
                    check-cast v29, Ld43;
                    const/16 v31, 0x30
                    const/16 v32, 0x8
                    invoke-static/range {v19 .. v32}, Lpk1;->c(Ldo3;Ljava/lang/String;Ljava/lang/String;JJLdo3;JLd43;Lki1;II)V
                    const/16 v31, 0x0
                    invoke-virtual/range {v30 .. v31}, Lqi1;->q(Z)V
                    move-object/from16 v23, v30
                    goto :hp_end
                    :hp_else
                    const v24, 0x2a1b0c02
                    invoke-virtual/range {v23 .. v24}, Lqi1;->c0(I)V
                    const/16 v24, 0x0
                    invoke-virtual/range {v23 .. v24}, Lqi1;->q(Z)V
                    :hp_end
                    nop
                """
            )
        } catch (e: Exception) {
            println("Fila de audifonos omitida: ${e.message}")
        }
    }
}
