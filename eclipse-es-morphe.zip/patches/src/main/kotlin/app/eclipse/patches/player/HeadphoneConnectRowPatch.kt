package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val HEADPHONE_ROUTE = "Lapp/eclipse/extension/player/HeadphoneRoute;"

@Suppress("unused")
val headphoneConnectRowPatch = bytecodePatch(
    name = "Conectar: fila de audifonos",
    description = "Agrega la fila de tus audifonos (Bluetooth, cable o USB) en la hoja \"Conectar a un dispositivo\", " +
        "debajo de \"Este dispositivo\". Solo aparece cuando hay audifonos conectados. Al tocarla intenta cambiar la " +
        "salida de audio con el reproductor de Eclipse (AudioTrack.setPreferredDevice); si no puede, abre el selector de " +
        "salida de Android. Tambien deja de mostrar \"Este dispositivo\" como activo cuando suena en audifonos.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // v0.20.272 (0.6.73, SIN COMPILAR NI PROBAR): pv1->fw1 (OJO: el metodo que dibuja la hoja pasa de `g` a `f`; cuerpo identico, 0 diferencias con cmp.py),
        // tv1->jw1 (e), xi3->bk3, p51->g61 (ctor de 26 parametros identico), raa->zba; las dos AudioSink sin pareja automatica se resolvieron a mano:
        // ms3(ctor Lo63;)->pt3(ctor Ll73;) y da2(ctor Lz92;)->xa2(ctor Lta2;) (mismo ctor, 81 y 67 instrucciones, this = v8, ambos con setPreferredDevice).
        // v0.20.219 (0.6.61, SIN COMPILAR NI PROBAR): es1->at1, hs1->dt1, he3->cf3, iq1->fr1, yp9->dr9, rx1.N->py1.P, vn7.P->wr7.O,
        // xn3/a23->so3/w23, e62/a62->z62/v62, u21->q31, vw6->nx6. Codigo de at1.g igual al de es1.g hasta el gancho (verificado en el dex).
        // v0.20.168 (0.6.55): es1.g (antes b71.g) dibuja la hoja. Desde 0.6.54 el separador ya no es fijo (es condicional),
        // asi que la fila va DESPUES de que las dos ramas confluyen: `iget-object vX, v0, es1.A` (indice 490, destino de
        // salto) + getValue + move-result-object + check-cast List; el gancho va en el indice 494 (no es destino de
        // salto). Registros (liveness calculada sobre el dex de 0.6.55): en 494 estan muertos v16..v37, v13 = composer
        // (iq1) y v48/v49 = color (J). La fila se arma por reflexion en HeadphoneRoute.row(composer, color).
        // Si algo no coincide, solo se omite con un println (la app queda como estaba).
        try {
            val es1 = mutableClassDefBy(classDefBy("Lfw1;"))
            val g = es1.methods.singleOrNull {
                it.name == "f" && it.parameterTypes.size == 3 && it.parameterTypes.all { p -> p.toString() == "Ljava/lang/Object;" }
            } ?: error("fw1.f no encontrado (0.6.73)")
            val ins = (g.implementation ?: error("es1.g sin codigo")).instructions.toList()
            fun methodOf(i: Int): MethodReference? =
                (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            val thisDevice = ins.indices.filter { i ->
                ins[i].opcode == Opcode.CONST_STRING &&
                    ((ins[i] as ReferenceInstruction).reference as? StringReference)?.string == "This device"
            }
            if (thisDevice.size != 1) error("es1.g: se esperaba 1 \"This device\" (hay ${thisDevice.size})")
            val call = (thisDevice[0] until ins.size).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE &&
                    methodOf(i)?.let { it.definingClass == "Ljw1;" && it.name == "e" } == true
            } ?: error("es1.g: hs1.e no encontrado")
            val range = ins[call] as RegisterRangeInstruction
            if (range.startRegister != 13 || range.registerCount != 16) {
                error("es1.g: hs1.e con registros inesperados (v${range.startRegister}, ${range.registerCount})")
            }
            // tras la llamada: move-wide/from16 v48, v18 (color) y move-object/from16 v13, v26 (composer)
            val mw = ins[call + 1]
            if (mw.opcode != Opcode.MOVE_WIDE_FROM16 || (mw as OneRegisterInstruction).registerA != 48 ||
                (mw as TwoRegisterInstruction).registerB != 18
            ) error("es1.g: se esperaba move-wide/from16 v48, v18 tras hs1.e")
            val mc = ins[call + 2]
            if (mc.opcode != Opcode.MOVE_OBJECT_FROM16 || (mc as OneRegisterInstruction).registerA != 13 ||
                (mc as TwoRegisterInstruction).registerB != 26
            ) error("es1.g: se esperaba move-object/from16 v13, v26 tras hs1.e")
            val iget = (call + 3 until minOf(call + 60, ins.size)).firstOrNull { i ->
                ins[i].opcode == Opcode.IGET_OBJECT &&
                    ((ins[i] as ReferenceInstruction).reference as? FieldReference)
                        ?.let { it.definingClass == "Lfw1;" && it.name == "A" && it.type == "Lzba;" } == true
            } ?: error("es1.g: no se encontro el iget es1.A")
            if (ins[iget + 1].opcode != Opcode.INVOKE_INTERFACE || methodOf(iget + 1)?.name != "getValue" ||
                ins[iget + 2].opcode != Opcode.MOVE_RESULT_OBJECT || ins[iget + 3].opcode != Opcode.CHECK_CAST
            ) error("es1.g: tras es1.A no viene getValue + move-result-object + check-cast")
            val hook = iget + 4
            // Primero el indice mayor (fila), luego el menor ("Este dispositivo"), para no mover indices.
            g.addInstructions(
                hook,
                """
                    move-object/from16 v16, v13
                    move-wide/from16 v17, v48
                    invoke-static/range {v16 .. v18}, $HEADPHONE_ROUTE->row(Ljava/lang/Object;J)V
                """
            )
            // Fila "Este dispositivo": registros de hs1.e en `call` (verificados en 0.6.55): v15 subtitulo, v20 icono final
            // (trailing), v25 click (he3). Si Eclipse dice que suena aqui (icono != null) pero la salida real es un
            // audifono, se muestra como no activa. Temporal v29 (muerto en `call`).
            try {
                g.addInstructionsWithLabels(
                    call,
                    """
                        invoke-static {}, $HEADPHONE_ROUTE->tick()I
                        move-result v29
                        invoke-static/range {v25 .. v25}, $HEADPHONE_ROUTE->wrapPhone(Ljava/lang/Object;)Ljava/lang/Object;
                        move-result-object v25
                        check-cast v25, Lbk3;
                        invoke-static/range {v20 .. v20}, $HEADPHONE_ROUTE->phoneInactive(Ljava/lang/Object;)Z
                        move-result v29
                        if-eqz v29, :ph_keep
                        invoke-static {}, $HEADPHONE_ROUTE->tapText()Ljava/lang/String;
                        move-result-object v15
                        const/16 v20, 0x0
                        :ph_keep
                        nop
                    """
                )
            } catch (e: Exception) {
                println("Estado de Este dispositivo omitido: ${e.message}")
            }
        } catch (e: Exception) {
            println("Fila de audifonos omitida: ${e.message}")
        }
        // v1.92.1: cambio directo de salida. kd3 y vw1 son los AudioSink de Eclipse (tienen
        // setPreferredDevice(AudioDeviceInfo)). Al final de su constructor se registran en HeadphoneRoute para poder
        // llamarlos al tocar la fila. this = penultimo registro (p0); se comprueba que la ultima instruccion antes del
        // return-void lo usa como objeto (iput) y que nadie lo reescribe.
        fun hookSink(cls: String, param: String) {
            try {
                val c = mutableClassDefBy(classDefBy(cls))
                val ctor = c.methods.singleOrNull {
                    it.name == "<init>" && it.parameterTypes.size == 1 && it.parameterTypes[0].toString() == param
                } ?: error("$cls.<init>($param) no encontrado")
                val impl = ctor.implementation ?: error("$cls.<init> sin codigo")
                val list = impl.instructions.toList()
                val last = list.lastIndex
                if (list[last].opcode != Opcode.RETURN_VOID) error("$cls.<init>: no termina en return-void")
                val thisReg = impl.registerCount - 2
                val readOnly = listOf("IPUT", "SPUT", "APUT", "IF_", "CHECK_CAST", "MONITOR", "RETURN", "THROW")
                val writes = list.filter { x ->
                    x is OneRegisterInstruction && x.registerA == thisReg &&
                        readOnly.none { x.opcode.name.startsWith(it) }
                }
                if (writes.isNotEmpty()) error("$cls.<init>: se reescribe this (v$thisReg)")
                ctor.addInstructions(last, "invoke-static {p0}, $HEADPHONE_ROUTE->register(Ljava/lang/Object;)V")
            } catch (e: Exception) {
                println("Cambio directo de salida: gancho $cls omitido: ${e.message}")
            }
        }
        hookSink("Lpt3;", "Ll73;")
        hookSink("Lxa2;", "Lta2;")

        // v0.20.9: el texto de salida de abajo (outputName, p. ej. "SOUNDPEATS C30") lo calcula Eclipse y se guarda en
        // ow0.s (parametro 21 del constructor de ow0, `move-object/from16 p1, p21` + `iput-object p1, p0, ow0.s`).
        // Antes de ese iput se pasa el texto por HeadphoneRoute.outputName: si el usuario forzo la bocina del telefono
        // muestra "Este dispositivo". El constructor tiene .locals 0, asi que el registro 1 es p1.
        try {
            val ow0 = mutableClassDefBy(classDefBy("Lg61;"))
            val ctor = ow0.methods.singleOrNull {
                it.name == "<init>" && it.parameterTypes.size == 26
            } ?: error("ow0.<init> no encontrado")
            val impl = ctor.implementation ?: error("ow0.<init> sin codigo")
            val list = impl.instructions.toList()
            val idx = list.indices.filter { i ->
                val ref = (list[i] as? ReferenceInstruction)?.reference as? FieldReference
                list[i].opcode == Opcode.IPUT_OBJECT && ref != null &&
                    ref.definingClass == "Lg61;" && ref.name == "s"
            }
            if (idx.size != 1) error("ow0.s: se esperaba 1 iput (hay ${idx.size})")
            val i = idx[0]
            val put = list[i] as TwoRegisterInstruction
            val prev = list[i - 1]
            if (prev.opcode != Opcode.MOVE_OBJECT_FROM16 || (prev as TwoRegisterInstruction).registerB != 21 ||
                prev.registerA != 1 || put.registerA != 1
            ) error("ow0.<init>: el iput de ow0.s no viene de p21 por p1")
            ctor.addInstructions(
                i,
                """
                    invoke-static {p1}, $HEADPHONE_ROUTE->outputName(Ljava/lang/String;)Ljava/lang/String;
                    move-result-object p1
                """
            )
        } catch (e: Exception) {
            println("Texto de salida dinamico omitido: ${e.message}")
        }
    }
}
