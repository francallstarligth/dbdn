package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"

/**
 * v0.20.29 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableLyrics) antes de que Bitchord arme su diseno; el trabajo esta en BitchordLyrics.java.
 * Ganchos (los mismos dos sitios que ya usa "Reproductor integrado: Bitchord"):
 *  - dl6.b(fl6, Context, Z): al elegir la tarjeta Bitchord.
 *  - jh6.a(): al elegir la plantilla Bitchord en "Nuevo reproductor".
 */
@Suppress("unused")
val bitchordLyricsPatch = bytecodePatch(
    name = "Bitchord: Letras estilo Apple Music",
    description = "Bitchord con la pestana Letra como Apple Music V2: cabecera arriba (portada chica, titulo, estrella, " +
        "tres puntos), letra en medio, y abajo barra, botones, volumen y fila de iconos que se esconden a los 3 s o al deslizar la letra. " +
        "La pestana Artwork queda igual. Para un diseno que ya tengas, crea uno nuevo desde Nuevo reproductor > Bitchord.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordTemplatePatch)

    extendWith("extensions/extension.mpe")

    execute {
        val dl6 = mutableClassDefBy(classDefBy("Ldl6;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "b" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lfl6;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableLyrics()V")

        val jh6 = mutableClassDefBy(classDefBy("Ljh6;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableLyrics()V")
    }
}
