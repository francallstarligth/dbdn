package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference

private const val EXT = "Lapp/eclipse/extension/player/BitchordTemplate;"
private const val BG = "Lapp/eclipse/extension/canvas/BlurredCanvasBackground;"

/**
 * v0.20.29 (SIN COMPILAR / SIN PROBAR). Parche aparte, apagado por defecto. Solo activa un interruptor
 * (BitchordTemplate.enableLyrics) antes de que Bitchord arme su diseno; el trabajo esta en BitchordLyrics.java.
 * Ganchos (los mismos dos sitios que ya usa "Reproductor integrado: Bitchord"):
 *  - dl6.b(fl6, Context, Z): al elegir la tarjeta Bitchord.
 *  - jh6.a(): al elegir la plantilla Bitchord en "Nuevo reproductor".
 */
@Suppress("unused")
val bitchordLyricsPatch = bytecodePatch(
    name = "Bitchord: Letras estilo Apple Music",
    description = "Bitchord con la pestana Letra como Apple Music V2: cabecera arriba (portada chica, titulo, estrella, " +
        "tres puntos), letra en medio, y abajo barra, botones, volumen y fila de iconos que se esconden a los 3 s o al deslizar la letra. " +
        "La pestana Artwork queda igual. Para un diseno que ya tengas, crea uno nuevo desde Nuevo reproductor > Bitchord.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(bitchordTemplatePatch)

    extendWith("extensions/extension.mpe")

    val reflection by booleanOption(
        key = "lyricsReflection",
        default = false,
        title = "Reflejo en Letra y Cola",
        description = "Apagado (normal): en Letra y Cola el fondo es la portada fija borrosa a pantalla completa. " +
            "Encendido: se usa el reflejo de la portada (como en las canciones sin Canvas), sin cargar el video del Canvas."
    )

    execute {
        val dl6 = mutableClassDefBy(classDefBy("Lod7;"))
        val setStyle = dl6.methods.firstOrNull {
            it.name == "c" && it.parameterTypes.size == 3 && it.parameterTypes[0] == "Lqd7;"
        } ?: error("No se encontro dl6.b(fl6, Context, Z)")
        setStyle.addInstructions(0, "invoke-static {}, $EXT->enableLyrics()V")

        val jh6 = mutableClassDefBy(classDefBy("Lji6;"))
        val build = jh6.methods.firstOrNull { it.name == "a" && it.parameterTypes.isEmpty() }
            ?: error("No se encontro jh6.a()")
        build.addInstructions(0, "invoke-static {}, $EXT->enableLyrics()V")

        // v0.20.32: eg6.g (contenido del reproductor Custom) empieza con `iget-object vX, this, Lk97;->u:Ls31;`
        // (qw0 = estado de pestana artwork/lyrics/queue). Justo despues se le pasa a BlurredCanvasBackground.setPane
        // para que en Letra y Cola use la portada fija y no el Canvas.
        val eg6 = mutableClassDefBy(classDefBy("Lk97;"))
        val content = eg6.methods.firstOrNull { m ->
            m.name == "g" && m.returnType == "Ljava/lang/Object;" && m.parameterTypes.size == 3
        } ?: error("No se encontro eg6.g")
        val list = (content.implementation ?: error("eg6.g sin codigo")).instructions.toList()
        val getIdx = list.indices.firstOrNull { i ->
            val ref = (list[i] as? ReferenceInstruction)?.reference as? FieldReference
            list[i].opcode == Opcode.IGET_OBJECT && ref != null && ref.definingClass == "Lk97;" &&
                ref.name == "u" && ref.type == "Ls31;"
        } ?: error("eg6.g: no se encontro iget-object eg6.u (qw0)")
        if (getIdx > 8) error("eg6.g: eg6.u (qw0) aparece muy abajo (indice $getIdx)")
        val holderReg = (list[getIdx] as TwoRegisterInstruction).registerA
        if (holderReg > 15) error("eg6.g: registro v$holderReg fuera de rango")
        val hook = if (reflection == true) "setPaneReflect" else "setPane"
        content.addInstructions(getIdx + 1, "invoke-static {v$holderReg}, $BG->$hook(Ljava/lang/Object;)V")

        // v0.20.53: al dibujar el reproductor Custom (di6.q, sin usar registros) se renueva el diseno de la tarjeta Bitchord.
        val di6q = mutableClassDefBy(classDefBy("Lja7;"))
        val qm = di6q.methods.singleOrNull {
            it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lmx6;"
        } ?: error("No se encontro di6.q")
        qm.addInstructions(0, "invoke-static {}, $EXT->onPlayerOpen()V")
    }
}
