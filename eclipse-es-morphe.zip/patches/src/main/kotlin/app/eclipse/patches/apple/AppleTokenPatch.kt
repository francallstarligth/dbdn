package app.eclipse.patches.apple

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

/** Gestor del token anonimo de Apple que ya trae Eclipse (w40 en 0.6.57; f20 en 0.6.47): usa "webtoken: ..." en sus logs. */
private const val WEB_TOKEN_MARKER = "webtoken: exception "

/** Gestor del token que pide al servidor de Eclipse (c10 en 0.6.57; ry en 0.6.47). */
private const val DEV_TOKEN_MARKER = "dev-token fetch returned "

private val CONST_OPS = setOf(Opcode.CONST_4, Opcode.CONST_16, Opcode.CONST)

@Suppress("unused")
val appleTokenPatch = bytecodePatch(
    name = "Apple Music: token propio",
    description = "Si Eclipse no consigue token de Apple Music (ni el suyo ni el del servidor), usa uno anonimo " +
        "del reproductor web de Apple, sin cuenta, para que las portadas animadas de Apple puedan funcionar.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val debug by booleanOption(
        key = "debug",
        default = false,
        title = "Mostrar avisos de depuracion",
        description = "Muestra avisos en pantalla con el paso en que se queda la busqueda del token de Apple. Dejalo apagado para uso normal."
    )

    execute {
        val debugFlag = if (debug == true) "0x1" else "0x0"

        /** Antes del `return-object` final que devuelve null, pide el token a AppleToken. */
        fun hook(marker: String, label: String, required: Boolean): Boolean {
            val immutable = classDefByStrings(marker).firstOrNull()
            if (immutable == null) {
                if (required) error("No se encontro la clase de $label (version de Eclipse distinta de 0.6.57?)")
                return false
            }
            val mutable = mutableClassDefBy(immutable)
            for (method in mutable.methods) {
                if (method.returnType != "Ljava/lang/String;" || method.parameterTypes.isNotEmpty()) continue
                val impl = method.implementation ?: continue
                val insns = impl.instructions.toList()
                val idx = insns.indices.lastOrNull { i ->
                    i >= 1 &&
                        insns[i].opcode == Opcode.RETURN_OBJECT &&
                        insns[i - 1].opcode in CONST_OPS
                } ?: continue
                val reg = (insns[idx] as OneRegisterInstruction).registerA

                method.addInstructionsWithLabels(
                    idx,
                    """
                        const/16 v$reg, $debugFlag
                        invoke-static/range {v$reg .. v$reg}, Lapp/eclipse/extension/apple/AppleToken;->setDebug(Z)V
                        invoke-static {}, Lapp/eclipse/extension/apple/AppleToken;->guest()Ljava/lang/String;
                        move-result-object v$reg
                    """
                )
                return true
            }
            if (required) error("No se encontro la rama sin token en $label")
            return false
        }

        // Principal: el token anonimo propio de Eclipse (lo usan las portadas animadas de Apple).
        hook(WEB_TOKEN_MARKER, "el token web de Apple", required = true)
        // Secundario: el token del servidor (lo usa la busqueda de albumes). Si no esta, no pasa nada.
        hook(DEV_TOKEN_MARKER, "el token del servidor", required = false)
    }
}
