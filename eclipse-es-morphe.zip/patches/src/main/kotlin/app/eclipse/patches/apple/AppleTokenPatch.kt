package app.eclipse.patches.apple

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

/** Texto que solo existe en AMTokenMgr (clase ry en 0.6.47), en el metodo que pide el token al servidor. */
private const val MARKER = "dev-token fetch returned "

@Suppress("unused")
val appleTokenPatch = bytecodePatch(
    name = "Apple Music: token propio",
    description = "Si el servidor de Eclipse no entrega el token de Apple Music, consigue uno anonimo " +
        "del reproductor web de Apple (sin cuenta) para que las portadas animadas de Apple funcionen.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase del token de Apple (version de Eclipse distinta de 0.6.47?)")
        val mutable = mutableClassDefBy(immutable)

        var patched = false
        for (method in mutable.methods) {
            if (method.returnType != "Ljava/lang/String;" || method.parameterTypes.isNotEmpty()) continue
            val impl = method.implementation ?: continue
            val insns = impl.instructions.toList()
            // Rama "sin token": monitor-exit; const/4 pX, 0; return-object pX
            val idx = insns.indices.firstOrNull { i ->
                i >= 2 &&
                    insns[i].opcode == Opcode.RETURN_OBJECT &&
                    insns[i - 1].opcode == Opcode.CONST_4 &&
                    insns[i - 2].opcode == Opcode.MONITOR_EXIT
            } ?: continue

            method.addInstructionsWithLabels(
                idx,
                """
                    invoke-static {}, Lapp/eclipse/extension/apple/AppleToken;->guest()Ljava/lang/String;
                    move-result-object p0
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro la rama sin token en el metodo del token de Apple")
    }
}
