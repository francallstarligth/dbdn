package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference

private const val BACK = "Lapp/eclipse/extension/player/PlayerBack;"

/**
 * Gesto de retroceder (v1.98.2 PROBADO OK por el usuario; v1.98.3 quita el diagnostico). Gesto de retroceder del reproductor grande, estilo Bitchord: mientras
 * se mantiene el gesto el reproductor se achica (hasta ~0.90) segun el progreso; al cancelar vuelve a su tamano; al
 * soltar sigue el cierre normal de Eclipse (el de v1.97.7 si esta marcado).
 * - rh0 (callback del BackHandler de Compose): rh0.c / rh0.d reciben el evento (cr5, cr5.b = progreso), rh0.a es cancelar,
 *   rh0.b es completar (jh1.f() llama a onBack). La extension solo atiende al BackHandler cuyo onBack es wq4 caso 15.
 * - wt9.a: tras leer jr.d() se llama PlayerBack.jr(jr) (guarda el estado del jr para provocar recomposicion) y tras el
 *   alpha (`r15.g(mh5, F)`) se llama PlayerBack.wrap(modifier), que aplica graphicsLayer(scaleX, scaleY) por reflexion.
 */
@Suppress("unused")
val playerBackGesturePatch = bytecodePatch(
    description = "Experimento. Mientras mantienes el gesto de retroceder, el reproductor grande se achica segun cuanto " +
        "arrastras; si lo cancelas vuelve a su tamano; al soltar baja como siempre. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- wt9.a: gancho del jr y escala tras el alpha ----
        val dr8 = mutableClassDefBy(classDefBy("Lwka;"))
        val m = dr8.methods.singleOrNull {
            it.name == "a" && it.returnType == "V" &&
                it.parameterTypes.map { p -> p.toString() } ==
                listOf("Ldk3;", "F", "Z", "Ldk3;", "Lbs3;", "Lfq1;", "Leu1;", "I", "I")
        } ?: error("No se encontro gw9.a (Eclipse 0.6.70)")
        val ins = (m.implementation ?: error("dr8.a sin codigo")).instructions.toList()

        val pares = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_VIRTUAL_RANGE && r != null && r.definingClass == "Lqt;" &&
                r.name == "d" && r.parameterTypes.isEmpty()
        }.mapNotNull { h ->
            val d = (h + 1..minOf(h + 8, ins.size - 1)).firstOrNull { ins[it].opcode == Opcode.DIV_FLOAT_2ADDR }
            if (d == null) null else h to d
        }
        if (pares.size != 1) error("gw9.a: se esperaba 1 jr.d()+division (hay ${pares.size})")
        val (h, div) = pares[0]
        val jrReg = (ins[h] as RegisterRangeInstruction).startRegister

        val alfa = ins.indices.filter { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lvb8;" && r.name == "d" &&
                r.parameterTypes.map { p -> p.toString() } == listOf("Lrb6;", "F")
        }
        if (alfa.size != 1) error("gw9.a: se esperaba 1 r15.g(mh5, F) (hay ${alfa.size})")
        val a = alfa[0]
        if (ins[a + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("wt9.a: tras r15.g no hay move-result-object")
        val modReg = (ins[a + 1] as OneRegisterInstruction).registerA

        // primero el indice mayor, para que la segunda insercion no lo mueva
        m.addInstructions(
            a + 2,
            """
                invoke-static/range {v$modReg .. v$modReg}, $BACK->wrap(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v$modReg
                check-cast v$modReg, Lrb6;
            """.trimIndent()
        )
        m.addInstructions(div + 1, "invoke-static/range {v$jrReg .. v$jrReg}, $BACK->jr(Ljava/lang/Object;)V")

        // ---- rh0: eventos del gesto ----
        val rh0 = mutableClassDefBy(classDefBy("Ltp0;"))
        fun metodo(nombre: String, params: List<String>) = rh0.methods.singleOrNull {
            it.name == nombre && it.returnType == "V" && it.parameterTypes.map { p -> p.toString() } == params
        } ?: error("No se encontro rh0.$nombre")

        val evento = "invoke-static {p0, p1}, $BACK->evento(Ljava/lang/Object;Ljava/lang/Object;)V"
        metodo("c", listOf("Li07;")).addInstructions(0, evento)
        metodo("d", listOf("Li07;")).addInstructions(0, evento)
        metodo("a", emptyList()).addInstructions(0, "invoke-static {p0}, $BACK->cancelado(Ljava/lang/Object;)V")
    }
}
