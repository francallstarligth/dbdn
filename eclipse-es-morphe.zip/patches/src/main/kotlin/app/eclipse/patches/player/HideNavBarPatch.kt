package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val NAV_HIDE = "Lapp/eclipse/extension/player/NavHide;"

/**
 * v0.20.420 (SIN COMPILAR EN GITHUB NI PROBAR; sin kotlinc aqui). Esconde los botones de navegacion (cuadrado, circulo,
 * triangulo) mientras el reproductor grande esta abierto. Parche APARTE de "Reproductor: ocultar la barra de estado":
 * no comparte codigo ni reloj con ella (`NavHide` tiene su propio control de barra, solo navigationBars). Mismo gancho que la
 * barra de estado (inicio de `Lex7;->e()`, abrir el reproductor), pero llama a `NavHide.start()`. Si se desmarca, la barra de
 * estado sigue igual. Con navegacion por gestos el sistema no da el control y no pasa nada.
 * Si no se encuentra `Lex7;->e()`, el parche falla.
 */
@Suppress("unused")
val hideNavBarPatch = bytecodePatch(
    name = "Reproductor: ocultar los botones de navegacion",
    description = "Mientras el reproductor grande esta abierto se esconden los botones de abajo (cuadrado, circulo, triangulo) " +
        "con desvanecido; asi el reproductor se acomoda igual que con gestos. Al cerrarlo vuelven. Deslizando desde abajo " +
        "aparecen un momento. Va aparte de la barra de estado. Con navegacion por gestos no hace nada.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val ex7 = mutableClassDefBy(classDefBy("Lex7;"))
        val f = ex7.methods.singleOrNull {
            it.name == "e" && it.returnType == "V" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro ex7.e (Eclipse 0.6.75)")
        f.addInstructions(0, "invoke-static {}, $NAV_HIDE->start()V")
    }
}
