package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

/**
 * v0.20.58 (SIN COMPILAR / SIN PROBAR). Las animaciones de Eclipse (Compose) leen la "velocidad de animaciones" del
 * sistema (Opciones de desarrollador) a traves de dw5 (MotionDurationScale; db6.s() = factor; en 0.6.55 era hu5). Este parche hace que
 * db6.s() devuelva siempre 1.0, asi las animaciones duran lo mismo en cualquier telefono (aunque este en 0.5x, 2x o apagado).
 * Solo cambia ESTE metodo (iget del estado q + g()F pasa a const 1.0f). No toca el resto del sistema.
 */
@Suppress("unused")
val fixedAnimationSpeedPatch = bytecodePatch(
    description = "Las animaciones de Eclipse duran siempre lo mismo, sin importar la velocidad de animaciones que tengas " +
        "puesta en Opciones de desarrollador del telefono. Desmarcalo si quieres que Eclipse la respete.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val ii5 = mutableClassDefBy(classDefBy("Ldb6;"))
        val s = ii5.methods.singleOrNull {
            it.name == "s" && it.returnType == "F" && it.parameterTypes.isEmpty()
        } ?: error("No se encontro db6.s() (version de Eclipse distinta de 0.6.70?)")
        // .locals 0: el unico registro es p0 (this); se reutiliza para devolver 1.0f
        s.addInstructions(
            0,
            """
                const/high16 p0, 0x3f800000
                return p0
            """
        )
    }
}
