package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

/**
 * Eclipse 0.6.47 trae el SDK de Google Cast, que registra eventos de analitica (`ClientCastAnalytics`,
 * `ApplicationAnalytics...`) y los manda con la libreria de Google "datatransport" (backend `CctBackendFactory`,
 * clave "X-Goog-Api-Key"). El envio real lo hace `kh2.c(fm0, I)V` (0.6.55: jc2.c(wj0, I)V) (el "Uploader": llama al backend `oz0`/`f9.g`).
 *
 * Arreglo: `return-void` al inicio de `z32.c`, asi nunca se sube nada. Cast para enviar a Chromecast no usa esto.
 * Los eventos quedan en la base local de la libreria (que tiene limite de tamano y borra los viejos).
 */
@Suppress("unused")
val castAnalyticsOffPatch = bytecodePatch(
    description = "Corta el envio de eventos de analitica del SDK de Google Cast a los servidores de Google. " +
        "Enviar a Chromecast sigue igual.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val z32 = mutableClassDefBy(classDefBy("Lei2;"))
        val method = z32.methods.firstOrNull {
            it.name == "c" && it.returnType == "V" && it.parameterTypes.size == 2 &&
                it.parameterTypes[0].toString() == "Lwm0;" && it.parameterTypes[1].toString() == "I"
        } ?: error("No se encontro kh2.c(fm0, I) (version de Eclipse distinta de 0.6.70?)")
        method.addInstructions(0, "return-void")
    }
}
