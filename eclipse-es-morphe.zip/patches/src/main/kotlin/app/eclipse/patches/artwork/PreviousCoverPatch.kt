package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"

/**
 * v1.99.1/v1.100.0 (SIN COMPILAR NI PROBAR): al cambiar de cancion, el FONDO borroso se queda con la imagen ANTERIOR y la PORTADA
 * nitida muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse 0.6.47 dibuja esas imagenes con `by9.c` -> `by9.d` -> Coil SubcomposeAsyncImage; el contenido es la lambda
 * `w71.k` (caso q=1) que elige por estado: `a91` (vacio) y `z81` (cargando) dibujan el placeholder gris (`qa2.b`) o nada;
 * `b91` (exito) convierte el Drawable en painter (`je2.m0` -> i36) y lo dibuja con `bc2.g`.
 * `by9.c` se usa en TODA la app, por eso solo se toca el del reproductor: los 6 sitios `di6.b` (x2, portada), `di6.c` (x2, fondo con
 * blur), `xi6.e` (fondo con blur) y `xi6.p` (portada, sin blur) construyen un `sn3` (parametros de la imagen) y justo despues
 * se lo marca con `PrevCover.tagBg/tagCover(sn3)`; ese mismo `sn3` llega a la lambda.
 * 1) w71.k, rama exito: antes de `je2.m0` -> `PrevCover.fade(sn3, drawable)` (v1.100.0: fundido entre la imagen anterior y la
 *    nueva) y tras `je2.m0` -> `PrevCover.remember(sn3, painter)`.
 * 2) w71.k, ramas a91 y z81: justo tras abrir el grupo (`qi1.c0`), `PrevCover.saved(sn3)`; si devuelve un Drawable (cuadro
 *    de la portada) se convierte con `je2.m0` en painter; si devuelve un painter (fondo) se usa directo. Se dibuja con
 *    `bc2.g(sn3, fillMaxSize, painter, composer, 0)` y NO se llama a `qa2.b`.
 */
@Suppress("unused")
val previousCoverPatch = bytecodePatch(
    name = "Cambio de cancion: mantener la imagen anterior (experimento)",
    description = "Experimento. Al cambiar de cancion, el fondo borroso del reproductor se queda con la imagen anterior " +
        "y la portada muestra un cuadro oscuro translucido con una nota musical mientras carga la nueva. " +
        "Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) marcar el sn3 de cada sitio del reproductor ----
        var tagged = 0
        for (clsName in listOf("Ldi6;", "Lxi6;")) {
            val cls = mutableClassDefBy(classDefBy(clsName))
            for (method in cls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val callsBy9 = list.any { ins ->
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lby9;" && r.name == "c"
                }
                if (!callsBy9) continue
                val inits = list.indices.filter { i ->
                    val ins = list[i]
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lsn3;" && r.name == "<init>" &&
                        (ins.opcode == Opcode.INVOKE_DIRECT || ins.opcode == Opcode.INVOKE_DIRECT_RANGE)
                }
                // Portada nitida (sin blur): di6.b y xi6.p. Fondo (con blur by9.k): di6.c y xi6.e.
                val tagFn = when ("${cls.type}.${method.name}") {
                    "Ldi6;.b", "Lxi6;.p" -> "tagCover"
                    "Ldi6;.c" -> "tagBg"
                    "Lxi6;.e" -> "tagBg2"
                    else -> error("${cls.type}.${method.name}: llama a by9.c pero no esta en el mapa de sitios")
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for (i in inits.reversed()) {
                    val ins = list[i]
                    val reg = when (ins) {
                        is RegisterRangeInstruction -> ins.startRegister
                        is FiveRegisterInstruction -> ins.registerC
                        else -> error("${cls.type}.${method.name}: sn3.<init> con formato inesperado")
                    }
                    // v1.100.12: la portada de di6.b (reproductor inmersivo) tambien se marca con tagImm.
                    val extra = if ("${cls.type}.${method.name}" == "Ldi6;.b")
                        "\n                        invoke-static/range {v$reg .. v$reg}, $EXT->tagImm(Ljava/lang/Object;)V" else ""
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$reg .. v$reg}, $EXT->$tagFn(Ljava/lang/Object;)V" + extra
                    )
                    tagged++
                }
            }
        }
        if (tagged != 6) error("Se esperaban 6 sitios sn3 en di6/xi6 (hay $tagged; version de Eclipse distinta de 0.6.47?)")

        // ---- 2) w71.k (caso q=1) ----
        val w71 = mutableClassDefBy(classDefBy("Lw71;"))
        val k = w71.methods.singleOrNull { it.name == "k" && it.parameterTypes.size == 4 }
            ?: error("No se encontro w71.k")
        val ins = k.implementation!!.instructions.toList()

        fun methodRef(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference

        // Rama exito: je2.m0(Drawable, List, ki1) -> move-result-object (painter) -> ... bc2.g(sn3, mh5, painter, ki1, I)
        val m0 = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lje2;" && r.name == "m0"
        }
        if (m0.size != 1) error("w71.k: se esperaba 1 llamado a je2.m0 (hay ${m0.size})")
        val m0i = m0[0]
        if (ins[m0i + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("w71.k: falta move-result-object tras je2.m0")
        val painterReg = (ins[m0i + 1] as OneRegisterInstruction).registerA
        val g = (m0i + 2 until minOf(m0i + 14, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lbc2;" && r.name == "g" &&
                r.parameterTypes.size == 5
        }
        if (g.size != 1) error("w71.k: no se encontro bc2.g tras je2.m0")
        val gCall = ins[g[0]] as FiveRegisterInstruction
        val sn3Reg = gCall.registerC
        if (gCall.registerE != painterReg) error("w71.k: bc2.g no recibe el painter de je2.m0")
        if (sn3Reg != 9 || painterReg > 15) error("w71.k: registros inesperados (sn3=v$sn3Reg, painter=v$painterReg)")

        // Cierre de la rama "cargando": lo que sigue a qa2.b(Lun3; Lmh5; Lsn3; Laf1; Lki1; I) es `const/4 v9, 0` + qi1.q(Z).
        val qa2b = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC_RANGE && r != null && r.definingClass == "Lqa2;" && r.name == "b"
        }
        if (qa2b.size != 1) error("w71.k: se esperaba 1 llamado a qa2.b (hay ${qa2b.size})")
        val closeIdx = qa2b[0] + 1
        if (ins[closeIdx].opcode != Opcode.CONST_4) error("w71.k: estructura inesperada tras qa2.b")

        // Ramas a91 / z81: instance-of, if-eqz, check-cast (composer), const (clave del grupo), invoke-virtual qi1.c0(I).
        fun branchStart(type: String, groupKey: Int): Int {
            val idx = ins.indices.filter { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
                ins[i].opcode == Opcode.INSTANCE_OF && r != null && r.type == type
            }
            if (idx.size != 1) error("w71.k: se esperaba 1 instance-of $type (hay ${idx.size})")
            val a = idx[0]
            if (ins[a + 1].opcode != Opcode.IF_EQZ ||
                ins[a + 2].opcode != Opcode.CHECK_CAST ||
                ins[a + 3].opcode != Opcode.CONST ||
                (ins[a + 3] as NarrowLiteralInstruction).narrowLiteral != groupKey ||
                ins[a + 4].opcode != Opcode.INVOKE_VIRTUAL || methodRef(a + 4)?.name != "c0"
            ) error("w71.k: estructura inesperada en la rama $type")
            if ((ins[a + 2] as OneRegisterInstruction).registerA != 3) error("w71.k: el composer no esta en v3 ($type)")
            return a + 5
        }
        val zAt = branchStart("Lz81;", 75304853)
        val aAt = branchStart("La91;", 279522055)
        if (ins[aAt].opcode != Opcode.CONST_4) error("w71.k: estructura inesperada tras la rama a91")

        // El modifier (fillMaxSize) sale de vd9.v(ko0); ko0 esta en v1 en ambas ramas.
        val vd9 = (zAt until minOf(zAt + 6, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lvd9;" && r.name == "v"
        }
        if (vd9.size != 1) error("w71.k: no se encontro vd9.v en la rama z81")
        val koReg = (ins[vd9[0]] as FiveRegisterInstruction).registerC
        if (koReg != 1) error("w71.k: ko0 no esta en v1 (esta en v$koReg)")

        // De abajo hacia arriba, para no correr los indices que faltan.
        // (a) exito: guardar el painter.
        k.addInstructions(
            m0i + 2,
            "invoke-static {v$sn3Reg, v$painterReg}, $EXT->remember(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        // (a2) exito: fundido. El Drawable cargado esta en v0 y el sn3 en v9; justo tras `check-cast v7, Lun3;` (que sigue a
        //      `if-nez v0, :cond_59`, o sea solo se llega con v0 no nulo) y antes del `instance-of v7, Lun3;` que prepara la lista.
        val ofIdx = (m0i - 1 downTo maxOf(m0i - 12, 0)).firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
            ins[i].opcode == Opcode.INSTANCE_OF && r != null && r.type == "Lun3;"
        } ?: error("w71.k: no se encontro el instance-of Lun3 antes de je2.m0")
        if (ins[ofIdx - 1].opcode != Opcode.CHECK_CAST || (ins[ofIdx - 1] as OneRegisterInstruction).registerA != 7)
            error("w71.k: estructura inesperada antes del instance-of Lun3")
        k.addInstructions(
            ofIdx,
            """
                invoke-static {v9, v0}, $EXT->fade(Ljava/lang/Object;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
                move-result-object v0
            """
        )

        // (b) cargando (z81): si hay algo guardado, dibujarlo y saltar al cierre de la rama (sin qa2.b).
        //     saved() devuelve un Drawable (portada: cuadro con nota) o un painter i36 (fondo). Drawable -> je2.m0 -> painter.
        //     Libres en esa rama: v2 (la clave ya se uso), v4, v6. v9 = sn3, v1 = ko0, v3 = composer.
        k.addInstructionsWithLabels(
            zAt,
            """
                invoke-static {v9}, $EXT->saved(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v2
                if-eqz v2, :orig
                instance-of v4, v2, Landroid/graphics/drawable/Drawable;
                if-eqz v4, :isPainter
                check-cast v2, Landroid/graphics/drawable/Drawable;
                sget-object v4, Lgj2;->q:Lgj2;
                invoke-static {v2, v4, v3}, Lje2;->m0(Landroid/graphics/drawable/Drawable;Ljava/util/List;Lki1;)Li36;
                move-result-object v2
                goto :draw
                :isPainter
                check-cast v2, Li36;
                :draw
                invoke-static {v1}, Lvd9;->v(Lko0;)Lmh5;
                move-result-object v4
                const/4 v6, 0x0
                invoke-static {v9, v4, v2, v3, v6}, Lbc2;->g(Lsn3;Lmh5;Li36;Lki1;I)V
                goto :close
            """,
            ExternalLabel("orig", k.getInstruction(zAt)),
            ExternalLabel("close", k.getInstruction(closeIdx))
        )

        // (c) vacio (a91): igual, pero la rama ya termina justo despues (const/4 v9, 0 + qi1.q), asi que se sigue de largo.
        //     Libres: v0 (la clave ya se uso), v2, v4.
        k.addInstructionsWithLabels(
            aAt,
            """
                invoke-static {v9}, $EXT->saved(Ljava/lang/Object;)Ljava/lang/Object;
                move-result-object v0
                if-eqz v0, :orig
                instance-of v4, v0, Landroid/graphics/drawable/Drawable;
                if-eqz v4, :isPainter
                check-cast v0, Landroid/graphics/drawable/Drawable;
                sget-object v4, Lgj2;->q:Lgj2;
                invoke-static {v0, v4, v3}, Lje2;->m0(Landroid/graphics/drawable/Drawable;Ljava/util/List;Lki1;)Li36;
                move-result-object v0
                goto :draw
                :isPainter
                check-cast v0, Li36;
                :draw
                invoke-static {v1}, Lvd9;->v(Lko0;)Lmh5;
                move-result-object v2
                const/4 v4, 0x0
                invoke-static {v9, v2, v0, v3, v4}, Lbc2;->g(Lsn3;Lmh5;Li36;Lki1;I)V
            """,
            ExternalLabel("orig", k.getInstruction(aAt))
        )
    }
}
