package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"
/** true si la instruccion nombra el registro r (lectura o escritura). */
private fun touches(i: Instruction, r: Int): Boolean = when (i) {
    is RegisterRangeInstruction -> r >= i.startRegister && r < i.startRegister + i.registerCount
    is FiveRegisterInstruction -> listOf(i.registerC, i.registerD, i.registerE, i.registerF, i.registerG)
        .take(i.registerCount).contains(r)
    is ThreeRegisterInstruction -> i.registerA == r || i.registerB == r || i.registerC == r
    is TwoRegisterInstruction -> i.registerA == r || i.registerB == r
    is OneRegisterInstruction -> i.registerA == r
    else -> false
}

private const val EXT_UNDERLAY = "Lapp/eclipse/extension/artwork/CoverUnderlay;"

/**
 * v0.20.251 (Eclipse 0.6.70, SIN COMPILAR NI PROBAR): nombres 61->70 (ja7->mq7, hb7->jr7, yc0.f->m67.d, ty3->o34, uf1.k->jj1.k [ahora 66 registros,
 * estructura cambiada: ver el paso 2], tb7->xr7, un4->rt4, mx6->hd7, cs7.J->nd8.s0, qx1.g->r62.c, bw1.i->o12.b, xg1/yg1->dj1/ej1 [cargando/vacio]).
 *
 * v0.20.219 (Eclipse 0.6.61, SIN COMPILAR NI PROBAR): nombres 57->61 (q97->ja7, ka7->hb7, a2b.b->yc0.f, xx3->ty3, ze1->uf1,
 * uq7->cs7 [J], sw1->qx1 [g], dv1->bw1 [i], zx3->vy3, cg1->xg1, dg1->yg1, wa7->tb7, wm4->un4, uw6->mx6). Estructura igual (ze1.k=uf1.k
 * con 49 registros y mismas claves de grupo). El comentario de abajo conserva los nombres de 0.6.57.
 *
 * v0.20.173 (Eclipse 0.6.57): nombres 47->55 (by9.c->a2b.a, w71.k->ze1.k, je2.m0->uq7.y, bc2.g->sw1.e, qa2.b->dv1.c, c0->d0, di6/xi6->q97/ka7).
 * La rama exito/cargando/vacio de ze1.k ya NO usa los registros de 0.6.47 (ver comentarios en el paso 2); lo guardado se dibuja
 * con PrevCover.drawSaved (reflexion). Lo de abajo describe 0.6.47.
 *
 * v1.99.1/v1.100.0 (SIN COMPILAR NI PROBAR): al cambiar de cancion, el FONDO borroso se queda con la imagen ANTERIOR y la PORTADA
 * nitida muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse 0.6.47 dibuja esas imagenes con `by9.c` -> `by9.d` -> Coil SubcomposeAsyncImage; el contenido es la lambda
 * `w71.k` (caso q=1) que elige por estado: `a91` (vacio) y `z81` (cargando) dibujan el placeholder gris (`qa2.b`) o nada;
 * `b91` (exito) convierte el Drawable en painter (`je2.m0` -> i36) y lo dibuja con `bc2.g`.
 * `by9.c` se usa en TODA la app, por eso solo se toca el del reproductor: los 6 sitios `di6.b` (x2, portada), `di6.c` (x2, fondo con
 * blur), `xi6.e` (fondo con blur) y `xi6.p` (portada, sin blur) construyen un `sn3` (parametros de la imagen) y justo despues
 * se lo marca con `PrevCover.tagBg/tagCover(sn3)`; ese mismo `sn3` llega a la lambda.
 * 1) w71.k, rama exito: antes de `je2.m0` -> `PrevCover.fade(sn3, drawable)` (v1.100.0: fundido entre la imagen anterior y la
 *    nueva) y tras `je2.m0` -> `PrevCover.remember(sn3, painter)`.
 * 2) w71.k, ramas a91 y z81: justo tras abrir el grupo (`qi1.c0`), `PrevCover.saved(sn3)`; si devuelve un Drawable (cuadro
 *    de la portada) se convierte con `je2.m0` en painter; si devuelve un painter (fondo) se usa directo. Se dibuja con
 *    `bc2.g(sn3, fillMaxSize, painter, composer, 0)` y NO se llama a `qa2.b`.
 */
@Suppress("unused")
val previousCoverPatch = bytecodePatch(
    description = "Al cambiar de cancion (botones, arrastre o sola), la portada, su reflejo y el desenfoque se mezclan con un " +
        "fundido suave, sin movimiento. En canciones con Canvas, la portada que espera al video tambien entra con fundido. " +
        "Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(animatedCoverNoFlashPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) marcar el sn3 de cada sitio del reproductor ----
        var tagged = 0
        for (clsName in listOf("Lqr7;", "Lps7;")) {
            val cls = mutableClassDefBy(classDefBy(clsName))
            for (method in cls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val callsBy9 = list.any { ins ->
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lje7;" && r.name == "a"
                }
                if (!callsBy9) continue
                val inits = list.indices.filter { i ->
                    val ins = list[i]
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lr44;" && r.name == "<init>" &&
                        (ins.opcode == Opcode.INVOKE_DIRECT || ins.opcode == Opcode.INVOKE_DIRECT_RANGE)
                }
                // Portada nitida (sin blur): di6.b y xi6.p. Fondo (con blur by9.k): di6.c y xi6.e.
                val tagFn = when ("${cls.type}.${method.name}") {
                    "Lqr7;.b", "Lps7;.p" -> "tagCover"
                    "Lqr7;.c" -> "tagBg"
                    "Lps7;.e" -> "tagBg2"
                    else -> error("${cls.type}.${method.name}: llama a m67.d (0.6.61: yc0.f) pero no esta en el mapa de sitios")
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for (i in inits.reversed()) {
                    val ins = list[i]
                    val reg = when (ins) {
                        is RegisterRangeInstruction -> ins.startRegister
                        is FiveRegisterInstruction -> ins.registerC
                        else -> error("${cls.type}.${method.name}: sn3.<init> con formato inesperado")
                    }
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$reg .. v$reg}, $EXT->$tagFn(Ljava/lang/Object;)V"
                    )
                    tagged++
                }
            }
        }
        if (tagged != 6) error("Se esperaban 6 sitios o34 en mq7/jr7 (hay $tagged; version de Eclipse distinta de 0.6.70?)")

        // ---- 2) jj1.k (0.6.70; antes uf1.k) ----
        // 0.6.70: la lambda de contenido de la imagen es el caso de jj1.k que hace `instance-of ej1/dj1/cj1/fj1` (estados vacio,
        // cargando, error, exito). Registros en ese caso (verificado en el dex): sn3 (o34) = v15 hasta el exito y v3 desde
        // `move-object v3, v15`; composer (tt1) = v13 (v5 en el exito); BoxScope (ex0) = p1 = v62 (y v0 hasta los ramales
        // vacio/cargando); Drawable del exito = v2; painter (rb7) = v1 tras nd8.s0. Ramas con claves de grupo propias.
        val lam = mutableClassDefBy(classDefBy("Lak1;"))
        val k = lam.methods.singleOrNull { it.name == "k" && it.parameterTypes.size == 4 }
            ?: error("No se encontro ak1.k (0.6.70: jj1.k)")
        val kImpl = k.implementation ?: error("ak1.k sin codigo")
        if (kImpl.registerCount != 66) error("ak1.k: se esperaban 66 registros (hay ${kImpl.registerCount})")
        val ins = kImpl.instructions.toList()

        fun methodRef(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
        fun typeOf(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
        fun fieldOf(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? com.android.tools.smali.dexlib2.iface.reference.FieldReference

        // Exito: nd8.s0(Drawable, List, Ltt1) -> move-result-object (painter) -> ... r62.c(o34, ga6, painter, nt1, I)
        val yIdx = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lnd8;" && r.name == "s0" &&
                r.parameterTypes.size == 3
        }
        if (yIdx.size != 1) error("ak1.k: se esperaba 1 llamado a nd8.s0 (hay ${yIdx.size})")
        val y = yIdx[0]
        if (ins[y + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("ak1.k: falta move-result-object tras nd8.s0")
        val drawableReg = (ins[y] as FiveRegisterInstruction).registerC
        val painterReg = (ins[y + 1] as OneRegisterInstruction).registerA
        val gIdx = (y + 2 until minOf(y + 14, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lr62;" && r.name == "c" &&
                r.parameterTypes.size == 5
        }
        if (gIdx.size != 1) error("ak1.k: no se encontro r62.c tras nd8.s0")
        val gCall = ins[gIdx[0]] as FiveRegisterInstruction
        val sn3Reg = gCall.registerC
        if (gCall.registerE != painterReg) error("ak1.k: r62.c no recibe el painter de nd8.s0")
        if (sn3Reg != 13 || painterReg != 0 || drawableReg != 0) {
            error("ak1.k: registros inesperados (o34=v$sn3Reg, painter=v$painterReg, drawable=v$drawableReg)")
        }

        // Drawable del exito: iget-object v2, v2, wj1.a (unico), antes de nd8.s0.
        val dIdx = ins.indices.filter { i ->
            val f = fieldOf(i)
            ins[i].opcode == Opcode.IGET_OBJECT && f != null && f.definingClass == "Lwj1;" && f.name == "a" && i < y
        }
        if (dIdx.size != 1) error("ak1.k: se esperaba 1 lectura de wj1.a (hay ${dIdx.size})")
        val d0i = dIdx[0]
        if ((ins[d0i] as TwoRegisterInstruction).registerA != drawableReg) error("ak1.k: wj1.a no cae en v$drawableReg")
        // 0.6.73: entre wj1.a y nd8.s0 v13 se copia a v14 y se restaura (move-object v14, v13 ... move-object v13, v14): esperado.
        run {
            val writes = (d0i + 1 until y).filter { i ->
                ins[i].opcode.setsRegister() && (ins[i] as? OneRegisterInstruction)?.registerA == sn3Reg
            }
            if (writes.size > 1) error("ak1.k: v$sn3Reg se reescribe ${writes.size} veces entre wj1.a y nd8.s0")
            for (i in writes) {
                val t = ins[i] as? TwoRegisterInstruction
                if (ins[i].opcode != Opcode.MOVE_OBJECT || t == null || t.registerB != 14) error("ak1.k: v$sn3Reg se reescribe (idx $i) sin ser la restauracion desde v14")
            }
        }

        // Ramas dj1 (cargando) y ej1 (vacio): instance-of, if-eqz, const (clave del grupo), invoke-virtual tt1.d0(I)
        fun branch(type: String, groupKey: Int): Int {
            val idx = ins.indices.filter { i -> ins[i].opcode == Opcode.INSTANCE_OF && typeOf(i)?.type == type }
            if (idx.size != 1) error("ak1.k: se esperaba 1 instance-of $type (hay ${idx.size})")
            val a = idx[0]
            if (ins[a + 1].opcode != Opcode.IF_EQZ ||
                ins[a + 2].opcode != Opcode.CONST ||
                (ins[a + 2] as NarrowLiteralInstruction).narrowLiteral != groupKey ||
                ins[a + 3].opcode != Opcode.INVOKE_VIRTUAL || methodRef(a + 3)?.name != "d0"
            ) error("ak1.k: estructura inesperada en la rama $type")
            if ((ins[a + 3] as FiveRegisterInstruction).registerC != 12) error("ak1.k: el composer no esta en v12 ($type)")
            return a + 4
        }
        val emptyAt = branch("Lvj1;", -369595621)      // vacio: sigue tt1.q(Z) (cierra el grupo)
        val loadAt = branch("Luj1;", 1427493377)       // cargando: sigue jc4.f(v0) (BoxScope) y la lambda con el placeholder
        if (ins[emptyAt].opcode != Opcode.INVOKE_VIRTUAL || methodRef(emptyAt)?.name != "q") error("ak1.k: falta tt1.q(Z) en la rama vacia")
        // En la rama cargando, v0 es el BoxScope: lo usa jc4.f(ex0) justo despues.
        val jc = methodRef(loadAt)
        if (ins[loadAt].opcode != Opcode.INVOKE_STATIC || jc == null || jc.definingClass != "Lnd4;" || jc.name != "s" ||
            (ins[loadAt] as FiveRegisterInstruction).registerC != 2) error("ak1.k: la rama cargando no empieza con nd4.s(v2)")
        // Cierre de la rama cargando: lo que sigue a o12.b(...) es `const v0, 1427929422` + d0 + q + q.
        val bIdx = (loadAt until minOf(loadAt + 30, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC_RANGE && r != null && r.definingClass == "Lf22;" && r.name == "b"
        }
        if (bIdx.size != 1) error("ak1.k: se esperaba 1 llamado a o12.b en la rama cargando (hay ${bIdx.size})")
        val closeIdx = bIdx[0] + 1
        if (ins[closeIdx].opcode != Opcode.CONST || (ins[closeIdx] as NarrowLiteralInstruction).narrowLiteral != 1427929422) {
            error("ak1.k: estructura inesperada tras o12.b")
        }
        // 0.6.73: en la rama cargando, antes de f22.b el composer (v12) se copia a v15 (`move-object v15, v12`); el cierre usa v15.
        val copy15 = (loadAt until closeIdx).filter { i ->
            ins[i].opcode == Opcode.MOVE_OBJECT && (ins[i] as TwoRegisterInstruction).registerA == 15 && (ins[i] as TwoRegisterInstruction).registerB == 12
        }
        if (copy15.size != 1) error("ak1.k: no se encontro move-object v15, v12 en la rama cargando")

        // BoxScope (ex0) = p1 = v62 (nunca se reescribe).
        val scopeReg = kImpl.registerCount - 4
        if (scopeReg != 62) error("ak1.k: BoxScope esperado en v62 (hay v$scopeReg)")

        // De abajo hacia arriba, para no correr los indices que faltan (vacio < cargando < exito).
        // (a) exito: guardar el painter (tras el move-result de nd8.s0).
        k.addInstructions(
            y + 2,
            "invoke-static {v$sn3Reg, v$painterReg}, $EXT->remember(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        // (a2) exito: fundido. El Drawable (v2, puede ser nulo: fade lo devuelve igual) y el o34 (v3) justo tras leer wj1.a.
        k.addInstructions(
            d0i + 1,
            """
                invoke-static {v$sn3Reg, v$drawableReg}, $EXT->fade(Ljava/lang/Object;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
                move-result-object v$drawableReg
            """
        )

        // (b) cargando (uj1): si hay algo guardado, el ayudante lo dibuja y se salta al cierre de la rama (sin f22.b).
        //     0.6.73: drawSaved(r44 = v13, composer = v12, BoxScope = v2) -> true si dibujo. v1 es el resultado (muerto aqui: lo
        //     pisa nd4.s); v15 se deja con el composer porque el cierre (d0 + q + q) lo usa.
        k.addInstructionsWithLabels(
            loadAt,
            """
                invoke-static {v13, v12, v2}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v1
                if-eqz v1, :orig
                move-object v15, v12
                goto :close
            """,
            ExternalLabel("orig", k.getInstruction(loadAt)),
            ExternalLabel("close", k.getInstruction(closeIdx))
        )

        // (c) vacio (vj1): igual, pero la rama ya termina justo despues (ju1.q(Z)), asi que se sigue de largo.
        //     0.6.73: el BoxScope se lee de p1 (v62) a v9 (v9 es el bool del instance-of, muerto aqui).
        k.addInstructions(
            emptyAt,
            """
                move-object/from16 v9, v$scopeReg
                invoke-static {v13, v12, v9}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v9
            """
        )

        // ---- 4) (antes parche \"deslizar la portada\") avisar cuando se pulsa Siguiente / Anterior: wa7.r(Object, Object) ----
        run {
            val kj6 = mutableClassDefBy(classDefBy("Ldt7;"))
            val sMethod = kj6.methods.singleOrNull {
                it.name == "r" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0] == "Ljava/lang/Object;" && it.parameterTypes[1] == "Ljava/lang/Object;"
            } ?: error("No se encontro xr7.r(Object, Object) (0.6.61: tb7.r)")
            val sImpl = sMethod.implementation ?: error("wa7.r sin implementacion")
            val sIns = sImpl.instructions.toList()
            val castIdx = sIns.indices.firstOrNull { i ->
                val r = (sIns[i] as? ReferenceInstruction)?.reference as? TypeReference
                sIns[i].opcode == Opcode.CHECK_CAST && r != null && r.type == "Lvu4;"
            } ?: error("xr7.r: no se encontro check-cast Lvu4;")
            val sRegs = sImpl.registerCount
            val sP1 = sRegs - 2
            val sP2 = sRegs - 1
            if (sP1 > 15 || sP2 > 15) error("wa7.r: registros altos (v$sP1, v$sP2)")
            sMethod.addInstructions(
                castIdx + 1,
                "invoke-static {v$sP1, v$sP2}, $EXT->onSkip(Ljava/lang/Object;Ljava/lang/Object;)V"
            )
        }

        // ---- 5) (antes parche \"Canvas: la portada que espera tambien se desliza\") enciende el interruptor de CoverUnderlay ----
        run {
            val q97 = mutableClassDefBy(classDefBy("Lqr7;"))
            val qMethod = q97.methods.singleOrNull {
                it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lle7;"
            } ?: error("No se encontro mq7.q (0.6.61: ja7.q)")
            qMethod.addInstructions(0, "invoke-static {}, $EXT_UNDERLAY->enableSlide()V")
        }
    }
}
