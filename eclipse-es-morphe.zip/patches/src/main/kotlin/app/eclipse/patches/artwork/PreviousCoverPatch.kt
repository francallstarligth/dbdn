package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"
/** true si la instruccion nombra el registro r (lectura o escritura). */
private fun touches(i: Instruction, r: Int): Boolean = when (i) {
    is RegisterRangeInstruction -> r >= i.startRegister && r < i.startRegister + i.registerCount
    is FiveRegisterInstruction -> listOf(i.registerC, i.registerD, i.registerE, i.registerF, i.registerG)
        .take(i.registerCount).contains(r)
    is ThreeRegisterInstruction -> i.registerA == r || i.registerB == r || i.registerC == r
    is TwoRegisterInstruction -> i.registerA == r || i.registerB == r
    is OneRegisterInstruction -> i.registerA == r
    else -> false
}

private const val EXT_UNDERLAY = "Lapp/eclipse/extension/artwork/CoverUnderlay;"

/**
 * v0.20.173 (Eclipse 0.6.55): nombres 47->55 (by9.c->to7.a, w71.k->de1.k, je2.m0->ks7.y, bc2.g->qv1.e, qa2.b->zz1.c, c0->d0, di6/xi6->j87/d97).
 * La rama exito/cargando/vacio de de1.k ya NO usa los registros de 0.6.47 (ver comentarios en el paso 2); lo guardado se dibuja
 * con PrevCover.drawSaved (reflexion). Lo de abajo describe 0.6.47.
 *
 * v1.99.1/v1.100.0 (SIN COMPILAR NI PROBAR): al cambiar de cancion, el FONDO borroso se queda con la imagen ANTERIOR y la PORTADA
 * nitida muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse 0.6.47 dibuja esas imagenes con `by9.c` -> `by9.d` -> Coil SubcomposeAsyncImage; el contenido es la lambda
 * `w71.k` (caso q=1) que elige por estado: `a91` (vacio) y `z81` (cargando) dibujan el placeholder gris (`qa2.b`) o nada;
 * `b91` (exito) convierte el Drawable en painter (`je2.m0` -> i36) y lo dibuja con `bc2.g`.
 * `by9.c` se usa en TODA la app, por eso solo se toca el del reproductor: los 6 sitios `di6.b` (x2, portada), `di6.c` (x2, fondo con
 * blur), `xi6.e` (fondo con blur) y `xi6.p` (portada, sin blur) construyen un `sn3` (parametros de la imagen) y justo despues
 * se lo marca con `PrevCover.tagBg/tagCover(sn3)`; ese mismo `sn3` llega a la lambda.
 * 1) w71.k, rama exito: antes de `je2.m0` -> `PrevCover.fade(sn3, drawable)` (v1.100.0: fundido entre la imagen anterior y la
 *    nueva) y tras `je2.m0` -> `PrevCover.remember(sn3, painter)`.
 * 2) w71.k, ramas a91 y z81: justo tras abrir el grupo (`qi1.c0`), `PrevCover.saved(sn3)`; si devuelve un Drawable (cuadro
 *    de la portada) se convierte con `je2.m0` en painter; si devuelve un painter (fondo) se usa directo. Se dibuja con
 *    `bc2.g(sn3, fillMaxSize, painter, composer, 0)` y NO se llama a `qa2.b`.
 */
@Suppress("unused")
val previousCoverPatch = bytecodePatch(
    description = "Al cambiar de cancion (botones, arrastre o sola), la portada, su reflejo y el desenfoque se mezclan con un " +
        "fundido suave, sin movimiento. En canciones con Canvas, la portada que espera al video tambien entra con fundido. " +
        "Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(animatedCoverNoFlashPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) marcar el sn3 de cada sitio del reproductor ----
        var tagged = 0
        for (clsName in listOf("Lj87;", "Ld97;")) {
            val cls = mutableClassDefBy(classDefBy(clsName))
            for (method in cls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val callsBy9 = list.any { ins ->
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lto7;" && r.name == "a"
                }
                if (!callsBy9) continue
                val inits = list.indices.filter { i ->
                    val ins = list[i]
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lyw3;" && r.name == "<init>" &&
                        (ins.opcode == Opcode.INVOKE_DIRECT || ins.opcode == Opcode.INVOKE_DIRECT_RANGE)
                }
                // Portada nitida (sin blur): di6.b y xi6.p. Fondo (con blur by9.k): di6.c y xi6.e.
                val tagFn = when ("${cls.type}.${method.name}") {
                    "Lj87;.b", "Ld97;.p" -> "tagCover"
                    "Lj87;.c" -> "tagBg"
                    "Ld97;.e" -> "tagBg2"
                    else -> error("${cls.type}.${method.name}: llama a by9.c pero no esta en el mapa de sitios")
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for (i in inits.reversed()) {
                    val ins = list[i]
                    val reg = when (ins) {
                        is RegisterRangeInstruction -> ins.startRegister
                        is FiveRegisterInstruction -> ins.registerC
                        else -> error("${cls.type}.${method.name}: sn3.<init> con formato inesperado")
                    }
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$reg .. v$reg}, $EXT->$tagFn(Ljava/lang/Object;)V"
                    )
                    tagged++
                }
            }
        }
        if (tagged != 6) error("Se esperaban 6 sitios sn3 en di6/xi6 (hay $tagged; version de Eclipse distinta de 0.6.47?)")

        // ---- 2) de1.k (caso q=1) ----
        // 0.6.55: la lambda de contenido de la imagen es de1.k (4 Object, regs 49, p1 = v45 = BoxScope tt0). Estados (hf1 vacio,
        // gf1 cargando, ff1 error, if1 exito) ya NO usan los registros de 0.6.47: sn3 (yw3) = v5, composer (lp1) = v2,
        // Drawable del exito = v1, painter = v1 (tras ks7.y). v3 (resultado de instance-of) esta muerto en las ramas hf1/gf1.
        val de1 = mutableClassDefBy(classDefBy("Lde1;"))
        val k = de1.methods.singleOrNull { it.name == "k" && it.parameterTypes.size == 4 }
            ?: error("No se encontro de1.k")
        val kImpl = k.implementation ?: error("de1.k sin codigo")
        if (kImpl.registerCount != 49) error("de1.k: se esperaban 49 registros (hay ${kImpl.registerCount})")
        val ins = kImpl.instructions.toList()

        fun methodRef(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference

        // Rama exito: ks7.y(Drawable, List, fp1) -> move-result-object (painter) -> ... qv1.e(yw3, kt5, ut6, fp1, I)
        val yIdx = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lks7;" && r.name == "y" &&
                r.parameterTypes.size == 3
        }
        if (yIdx.size != 1) error("de1.k: se esperaba 1 llamado a ks7.y (hay ${yIdx.size})")
        val y = yIdx[0]
        if (ins[y + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("de1.k: falta move-result-object tras ks7.y")
        val yCall = ins[y] as FiveRegisterInstruction
        val drawableReg = yCall.registerC
        val painterReg = (ins[y + 1] as OneRegisterInstruction).registerA
        val gIdx = (y + 2 until minOf(y + 14, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Lqv1;" && r.name == "e" &&
                r.parameterTypes.size == 5
        }
        if (gIdx.size != 1) error("de1.k: no se encontro qv1.e tras ks7.y")
        val gCall = ins[gIdx[0]] as FiveRegisterInstruction
        val sn3Reg = gCall.registerC
        if (gCall.registerE != painterReg) error("de1.k: qv1.e no recibe el painter de ks7.y")
        if (sn3Reg != 5 || painterReg != 1 || drawableReg != 1) {
            error("de1.k: registros inesperados (sn3=v$sn3Reg, painter=v$painterReg, drawable=v$drawableReg)")
        }

        // Cierre de la rama "cargando": lo que sigue a zz1.c(ax3, kt5, yw3, pl1, fp1, I) es `const/4 v0, 0` + lp1.q(Z).
        val zz1c = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC_RANGE && r != null && r.definingClass == "Lzz1;" && r.name == "c"
        }
        if (zz1c.size != 1) error("de1.k: se esperaba 1 llamado a zz1.c (hay ${zz1c.size})")
        val closeIdx = zz1c[0] + 1
        if (ins[closeIdx].opcode != Opcode.CONST_4) error("de1.k: estructura inesperada tras zz1.c")

        // Ramas hf1 / gf1: instance-of, if-eqz, check-cast (composer), const (clave del grupo), invoke-virtual lp1.d0(I).
        fun branchStart(type: String, groupKey: Int): Int {
            val idx = ins.indices.filter { i ->
                val r = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
                ins[i].opcode == Opcode.INSTANCE_OF && r != null && r.type == type
            }
            if (idx.size != 1) error("de1.k: se esperaba 1 instance-of $type (hay ${idx.size})")
            val a = idx[0]
            if (ins[a + 1].opcode != Opcode.IF_EQZ ||
                ins[a + 2].opcode != Opcode.CHECK_CAST ||
                ins[a + 3].opcode != Opcode.CONST ||
                (ins[a + 3] as NarrowLiteralInstruction).narrowLiteral != groupKey ||
                ins[a + 4].opcode != Opcode.INVOKE_VIRTUAL || methodRef(a + 4)?.name != "d0"
            ) error("de1.k: estructura inesperada en la rama $type")
            if ((ins[a + 2] as OneRegisterInstruction).registerA != 2) error("de1.k: el composer no esta en v2 ($type)")
            if ((ins[a] as TwoRegisterInstruction).registerA != 3) error("de1.k: el resultado de instance-of no esta en v3 ($type)")
            return a + 5
        }
        val gfAt = branchStart("Lgf1;", 75304853)
        val hfAt = branchStart("Lhf1;", 279522055)
        if (ins[hfAt].opcode != Opcode.CONST_4) error("de1.k: estructura inesperada tras la rama hf1")
        // Que nadie use v3 dentro de las ramas hasta el cierre (es el registro de pasaje).
        for (i in gfAt until closeIdx) {
            if (touches(ins[i], 3)) error("de1.k: v3 se usa en la rama gf1 (idx $i)")
        }

        // BoxScope (tt0) = p1 = v45 (nunca se reescribe). Se pasa al ayudante en v3.
        val scopeReg = kImpl.registerCount - 4

        // De abajo hacia arriba, para no correr los indices que faltan.
        // (a) exito: guardar el painter (tras el move-result de ks7.y).
        k.addInstructions(
            y + 2,
            "invoke-static {v$sn3Reg, v$painterReg}, $EXT->remember(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        // (a2) exito: fundido. El Drawable cargado esta en v1 (no nulo) y el sn3 en v5; antes del `instance-of ax3` que prepara la lista.
        val ofIdx = (y - 1 downTo maxOf(y - 12, 0)).firstOrNull { i ->
            val r = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
            ins[i].opcode == Opcode.INSTANCE_OF && r != null && r.type == "Lax3;"
        } ?: error("de1.k: no se encontro el instance-of Lax3 antes de ks7.y")
        if (ins[ofIdx - 1].opcode != Opcode.CHECK_CAST) error("de1.k: estructura inesperada antes del instance-of Lax3")
        for (i in ofIdx until y) {
            val a = (ins[i] as? OneRegisterInstruction)?.registerA ?: continue
            if (a == drawableReg && ins[i].opcode.setsRegister()) error("de1.k: v$drawableReg se reescribe antes de ks7.y")
        }
        k.addInstructions(
            ofIdx,
            """
                invoke-static {v$sn3Reg, v$drawableReg}, $EXT->fade(Ljava/lang/Object;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
                move-result-object v$drawableReg
            """
        )

        // (b) cargando (gf1): si hay algo guardado, el ayudante lo dibuja y se salta al cierre de la rama (sin zz1.c).
        //     drawSaved(sn3, composer, scope): Drawable (portada: cuadro con nota) o painter ut6 (fondo) guardado -> true si dibujo.
        k.addInstructionsWithLabels(
            gfAt,
            """
                move-object/from16 v3, v$scopeReg
                invoke-static {v$sn3Reg, v2, v3}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v3
                if-eqz v3, :orig
                goto :close
            """,
            ExternalLabel("orig", k.getInstruction(gfAt)),
            ExternalLabel("close", k.getInstruction(closeIdx))
        )

        // (c) vacio (hf1): igual, pero la rama ya termina justo despues (const/4 v0, 0 + lp1.q), asi que se sigue de largo.
        k.addInstructions(
            hfAt,
            """
                move-object/from16 v3, v$scopeReg
                invoke-static {v$sn3Reg, v2, v3}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
            """
        )

        // ---- 4) (antes parche \"deslizar la portada\") avisar cuando se pulsa Siguiente / Anterior: p97.r(Object, Object) ----
        run {
            val kj6 = mutableClassDefBy(classDefBy("Lp97;"))
            val sMethod = kj6.methods.singleOrNull {
                it.name == "r" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0] == "Ljava/lang/Object;" && it.parameterTypes[1] == "Ljava/lang/Object;"
            } ?: error("No se encontro p97.r(Object, Object)")
            val sImpl = sMethod.implementation ?: error("p97.r sin implementacion")
            val sIns = sImpl.instructions.toList()
            val castIdx = sIns.indices.firstOrNull { i ->
                val r = (sIns[i] as? ReferenceInstruction)?.reference as? TypeReference
                sIns[i].opcode == Opcode.CHECK_CAST && r != null && r.type == "Lyl4;"
            } ?: error("p97.r: no se encontro check-cast Lyl4;")
            val sRegs = sImpl.registerCount
            val sP1 = sRegs - 2
            val sP2 = sRegs - 1
            if (sP1 > 15 || sP2 > 15) error("p97.r: registros altos (v$sP1, v$sP2)")
            sMethod.addInstructions(
                castIdx + 1,
                "invoke-static {v$sP1, v$sP2}, $EXT->onSkip(Ljava/lang/Object;Ljava/lang/Object;)V"
            )
        }

        // ---- 5) (antes parche \"Canvas: la portada que espera tambien se desliza\") enciende el interruptor de CoverUnderlay ----
        run {
            val j87 = mutableClassDefBy(classDefBy("Lj87;"))
            val qMethod = j87.methods.singleOrNull {
                it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Llv6;"
            } ?: error("No se encontro j87.q")
            qMethod.addInstructions(0, "invoke-static {}, $EXT_UNDERLAY->enableSlide()V")
        }
    }
}
