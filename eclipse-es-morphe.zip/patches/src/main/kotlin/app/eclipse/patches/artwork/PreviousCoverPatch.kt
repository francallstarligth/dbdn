package app.eclipse.patches.artwork

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ThreeRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.TwoRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

private const val EXT = "Lapp/eclipse/extension/artwork/PrevCover;"
/** true si la instruccion nombra el registro r (lectura o escritura). */
private fun touches(i: Instruction, r: Int): Boolean = when (i) {
    is RegisterRangeInstruction -> r >= i.startRegister && r < i.startRegister + i.registerCount
    is FiveRegisterInstruction -> listOf(i.registerC, i.registerD, i.registerE, i.registerF, i.registerG)
        .take(i.registerCount).contains(r)
    is ThreeRegisterInstruction -> i.registerA == r || i.registerB == r || i.registerC == r
    is TwoRegisterInstruction -> i.registerA == r || i.registerB == r
    is OneRegisterInstruction -> i.registerA == r
    else -> false
}

private const val EXT_UNDERLAY = "Lapp/eclipse/extension/artwork/CoverUnderlay;"

/**
 * v0.20.251 (Eclipse 0.6.70, SIN COMPILAR NI PROBAR): nombres 61->70 (ja7->mq7, hb7->jr7, yc0.f->m67.d, ty3->o34, uf1.k->jj1.k [ahora 66 registros,
 * estructura cambiada: ver el paso 2], tb7->xr7, un4->rt4, mx6->hd7, cs7.J->lbb.J0, qx1.g->y52.c, bw1.i->o12.b, xg1/yg1->dj1/ej1 [cargando/vacio]).
 *
 * v0.20.219 (Eclipse 0.6.61, SIN COMPILAR NI PROBAR): nombres 57->61 (q97->ja7, ka7->hb7, a2b.b->yc0.f, xx3->ty3, ze1->uf1,
 * uq7->cs7 [J], sw1->qx1 [g], dv1->bw1 [i], zx3->vy3, cg1->xg1, dg1->yg1, wa7->tb7, wm4->un4, uw6->mx6). Estructura igual (ze1.k=uf1.k
 * con 49 registros y mismas claves de grupo). El comentario de abajo conserva los nombres de 0.6.57.
 *
 * v0.20.173 (Eclipse 0.6.57): nombres 47->55 (by9.c->a2b.a, w71.k->ze1.k, je2.m0->uq7.y, bc2.g->sw1.e, qa2.b->dv1.c, c0->d0, di6/xi6->q97/ka7).
 * La rama exito/cargando/vacio de ze1.k ya NO usa los registros de 0.6.47 (ver comentarios en el paso 2); lo guardado se dibuja
 * con PrevCover.drawSaved (reflexion). Lo de abajo describe 0.6.47.
 *
 * v1.99.1/v1.100.0 (SIN COMPILAR NI PROBAR): al cambiar de cancion, el FONDO borroso se queda con la imagen ANTERIOR y la PORTADA
 * nitida muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse 0.6.47 dibuja esas imagenes con `by9.c` -> `by9.d` -> Coil SubcomposeAsyncImage; el contenido es la lambda
 * `w71.k` (caso q=1) que elige por estado: `a91` (vacio) y `z81` (cargando) dibujan el placeholder gris (`qa2.b`) o nada;
 * `b91` (exito) convierte el Drawable en painter (`je2.m0` -> i36) y lo dibuja con `bc2.g`.
 * `by9.c` se usa en TODA la app, por eso solo se toca el del reproductor: los 6 sitios `di6.b` (x2, portada), `di6.c` (x2, fondo con
 * blur), `xi6.e` (fondo con blur) y `xi6.p` (portada, sin blur) construyen un `sn3` (parametros de la imagen) y justo despues
 * se lo marca con `PrevCover.tagBg/tagCover(sn3)`; ese mismo `sn3` llega a la lambda.
 * 1) w71.k, rama exito: antes de `je2.m0` -> `PrevCover.fade(sn3, drawable)` (v1.100.0: fundido entre la imagen anterior y la
 *    nueva) y tras `je2.m0` -> `PrevCover.remember(sn3, painter)`.
 * 2) w71.k, ramas a91 y z81: justo tras abrir el grupo (`qi1.c0`), `PrevCover.saved(sn3)`; si devuelve un Drawable (cuadro
 *    de la portada) se convierte con `je2.m0` en painter; si devuelve un painter (fondo) se usa directo. Se dibuja con
 *    `bc2.g(sn3, fillMaxSize, painter, composer, 0)` y NO se llama a `qa2.b`.
 */
@Suppress("unused")
val previousCoverPatch = bytecodePatch(
    description = "Al cambiar de cancion (botones, arrastre o sola), la portada, su reflejo y el desenfoque se mezclan con un " +
        "fundido suave, sin movimiento. En canciones con Canvas, la portada que espera al video tambien entra con fundido. " +
        "Si falla, desmarcalo.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    dependsOn(animatedCoverNoFlashPatch)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- 1) marcar el sn3 de cada sitio del reproductor ----
        var tagged = 0
        for (clsName in listOf("Lmq7;", "Ljr7;")) {
            val cls = mutableClassDefBy(classDefBy(clsName))
            for (method in cls.methods) {
                val impl = method.implementation ?: continue
                val list = impl.instructions.toList()
                val callsBy9 = list.any { ins ->
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lm67;" && r.name == "d"
                }
                if (!callsBy9) continue
                val inits = list.indices.filter { i ->
                    val ins = list[i]
                    val r = (ins as? ReferenceInstruction)?.reference as? MethodReference
                    r != null && r.definingClass == "Lo34;" && r.name == "<init>" &&
                        (ins.opcode == Opcode.INVOKE_DIRECT || ins.opcode == Opcode.INVOKE_DIRECT_RANGE)
                }
                // Portada nitida (sin blur): di6.b y xi6.p. Fondo (con blur by9.k): di6.c y xi6.e.
                val tagFn = when ("${cls.type}.${method.name}") {
                    "Lmq7;.b", "Ljr7;.p" -> "tagCover"
                    "Lmq7;.c" -> "tagBg"
                    "Ljr7;.e" -> "tagBg2"
                    else -> error("${cls.type}.${method.name}: llama a m67.d (0.6.61: yc0.f) pero no esta en el mapa de sitios")
                }
                // De atras hacia adelante: insertar no corre los indices anteriores.
                for (i in inits.reversed()) {
                    val ins = list[i]
                    val reg = when (ins) {
                        is RegisterRangeInstruction -> ins.startRegister
                        is FiveRegisterInstruction -> ins.registerC
                        else -> error("${cls.type}.${method.name}: sn3.<init> con formato inesperado")
                    }
                    method.addInstructions(
                        i + 1,
                        "invoke-static/range {v$reg .. v$reg}, $EXT->$tagFn(Ljava/lang/Object;)V"
                    )
                    tagged++
                }
            }
        }
        if (tagged != 6) error("Se esperaban 6 sitios o34 en mq7/jr7 (hay $tagged; version de Eclipse distinta de 0.6.70?)")

        // ---- 2) jj1.k (0.6.70; antes uf1.k) ----
        // 0.6.70: la lambda de contenido de la imagen es el caso de jj1.k que hace `instance-of ej1/dj1/cj1/fj1` (estados vacio,
        // cargando, error, exito). Registros en ese caso (verificado en el dex): sn3 (o34) = v15 hasta el exito y v3 desde
        // `move-object v3, v15`; composer (tt1) = v13 (v5 en el exito); BoxScope (ex0) = p1 = v62 (y v0 hasta los ramales
        // vacio/cargando); Drawable del exito = v2; painter (rb7) = v1 tras lbb.J0. Ramas con claves de grupo propias.
        val lam = mutableClassDefBy(classDefBy("Ljj1;"))
        val k = lam.methods.singleOrNull { it.name == "k" && it.parameterTypes.size == 4 }
            ?: error("No se encontro jj1.k (0.6.61: uf1.k)")
        val kImpl = k.implementation ?: error("jj1.k sin codigo")
        if (kImpl.registerCount != 66) error("jj1.k: se esperaban 66 registros (hay ${kImpl.registerCount})")
        val ins = kImpl.instructions.toList()

        fun methodRef(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference
        fun typeOf(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? TypeReference
        fun fieldOf(i: Int) = (ins[i] as? ReferenceInstruction)?.reference as? com.android.tools.smali.dexlib2.iface.reference.FieldReference

        // Exito: lbb.J0(Drawable, List, Ltt1) -> move-result-object (painter) -> ... y52.c(o34, ga6, painter, nt1, I)
        val yIdx = ins.indices.filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Llbb;" && r.name == "J0" &&
                r.parameterTypes.size == 3
        }
        if (yIdx.size != 1) error("jj1.k: se esperaba 1 llamado a lbb.J0 (hay ${yIdx.size})")
        val y = yIdx[0]
        if (ins[y + 1].opcode != Opcode.MOVE_RESULT_OBJECT) error("jj1.k: falta move-result-object tras lbb.J0")
        val drawableReg = (ins[y] as FiveRegisterInstruction).registerC
        val painterReg = (ins[y + 1] as OneRegisterInstruction).registerA
        val gIdx = (y + 2 until minOf(y + 14, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC && r != null && r.definingClass == "Ly52;" && r.name == "c" &&
                r.parameterTypes.size == 5
        }
        if (gIdx.size != 1) error("jj1.k: no se encontro y52.c tras lbb.J0")
        val gCall = ins[gIdx[0]] as FiveRegisterInstruction
        val sn3Reg = gCall.registerC
        if (gCall.registerE != painterReg) error("jj1.k: y52.c no recibe el painter de lbb.J0")
        if (sn3Reg != 3 || painterReg != 1 || drawableReg != 2) {
            error("jj1.k: registros inesperados (o34=v$sn3Reg, painter=v$painterReg, drawable=v$drawableReg)")
        }

        // Drawable del exito: iget-object v2, v2, fj1.a (unico), antes de lbb.J0.
        val dIdx = ins.indices.filter { i ->
            val f = fieldOf(i)
            ins[i].opcode == Opcode.IGET_OBJECT && f != null && f.definingClass == "Lfj1;" && f.name == "a" && i < y
        }
        if (dIdx.size != 1) error("jj1.k: se esperaba 1 lectura de fj1.a (hay ${dIdx.size})")
        val d0i = dIdx[0]
        if ((ins[d0i] as TwoRegisterInstruction).registerA != drawableReg) error("jj1.k: fj1.a no cae en v$drawableReg")
        for (i in d0i + 1 until y) {
            if (ins[i].opcode.setsRegister() && (ins[i] as? OneRegisterInstruction)?.registerA == sn3Reg) {
                error("jj1.k: v$sn3Reg se reescribe entre fj1.a y lbb.J0 (idx $i)")
            }
        }

        // Ramas dj1 (cargando) y ej1 (vacio): instance-of, if-eqz, const (clave del grupo), invoke-virtual tt1.d0(I)
        fun branch(type: String, groupKey: Int): Int {
            val idx = ins.indices.filter { i -> ins[i].opcode == Opcode.INSTANCE_OF && typeOf(i)?.type == type }
            if (idx.size != 1) error("jj1.k: se esperaba 1 instance-of $type (hay ${idx.size})")
            val a = idx[0]
            if (ins[a + 1].opcode != Opcode.IF_EQZ ||
                ins[a + 2].opcode != Opcode.CONST ||
                (ins[a + 2] as NarrowLiteralInstruction).narrowLiteral != groupKey ||
                ins[a + 3].opcode != Opcode.INVOKE_VIRTUAL || methodRef(a + 3)?.name != "d0"
            ) error("jj1.k: estructura inesperada en la rama $type")
            if ((ins[a + 3] as FiveRegisterInstruction).registerC != 13) error("jj1.k: el composer no esta en v13 ($type)")
            return a + 4
        }
        val emptyAt = branch("Lej1;", -369595621)      // vacio: sigue tt1.q(Z) (cierra el grupo)
        val loadAt = branch("Ldj1;", 1427493377)       // cargando: sigue jc4.f(v0) (BoxScope) y la lambda con el placeholder
        if (ins[emptyAt].opcode != Opcode.INVOKE_VIRTUAL || methodRef(emptyAt)?.name != "q") error("jj1.k: falta tt1.q(Z) en la rama vacia")
        // En la rama cargando, v0 es el BoxScope: lo usa jc4.f(ex0) justo despues.
        val jc = methodRef(loadAt)
        if (ins[loadAt].opcode != Opcode.INVOKE_STATIC || jc == null || jc.definingClass != "Ljc4;" || jc.name != "f" ||
            (ins[loadAt] as FiveRegisterInstruction).registerC != 0) error("jj1.k: la rama cargando no empieza con jc4.f(v0)")
        // Cierre de la rama cargando: lo que sigue a o12.b(...) es `const v0, 1427929422` + d0 + q + q.
        val bIdx = (loadAt until minOf(loadAt + 30, ins.size)).filter { i ->
            val r = methodRef(i)
            ins[i].opcode == Opcode.INVOKE_STATIC_RANGE && r != null && r.definingClass == "Lo12;" && r.name == "b"
        }
        if (bIdx.size != 1) error("jj1.k: se esperaba 1 llamado a o12.b en la rama cargando (hay ${bIdx.size})")
        val closeIdx = bIdx[0] + 1
        if (ins[closeIdx].opcode != Opcode.CONST || (ins[closeIdx] as NarrowLiteralInstruction).narrowLiteral != 1427929422) {
            error("jj1.k: estructura inesperada tras o12.b")
        }
        // o34 = v15 en esas ramas (se copia a v3 antes de o12.b) y el composer v13 se copia a v5.
        val copies = (loadAt until closeIdx).filter { i ->
            ins[i].opcode == Opcode.MOVE_OBJECT && (ins[i] as TwoRegisterInstruction).registerA == 3 && (ins[i] as TwoRegisterInstruction).registerB == 15
        }
        if (copies.size != 1) error("jj1.k: no se encontro move-object v3, v15 en la rama cargando")
        val copies5 = (loadAt until closeIdx).filter { i ->
            ins[i].opcode == Opcode.MOVE_OBJECT && (ins[i] as TwoRegisterInstruction).registerA == 5 && (ins[i] as TwoRegisterInstruction).registerB == 13
        }
        if (copies5.size != 1) error("jj1.k: no se encontro move-object v5, v13 en la rama cargando")

        // BoxScope (ex0) = p1 = v62 (nunca se reescribe).
        val scopeReg = kImpl.registerCount - 4
        if (scopeReg != 62) error("jj1.k: BoxScope esperado en v62 (hay v$scopeReg)")

        // De abajo hacia arriba, para no correr los indices que faltan (vacio < cargando < exito).
        // (a) exito: guardar el painter (tras el move-result de lbb.J0).
        k.addInstructions(
            y + 2,
            "invoke-static {v$sn3Reg, v$painterReg}, $EXT->remember(Ljava/lang/Object;Ljava/lang/Object;)V"
        )

        // (a2) exito: fundido. El Drawable (v2, puede ser nulo: fade lo devuelve igual) y el o34 (v3) justo tras leer fj1.a.
        k.addInstructions(
            d0i + 1,
            """
                invoke-static {v$sn3Reg, v$drawableReg}, $EXT->fade(Ljava/lang/Object;Landroid/graphics/drawable/Drawable;)Landroid/graphics/drawable/Drawable;
                move-result-object v$drawableReg
            """
        )

        // (b) cargando (dj1): si hay algo guardado, el ayudante lo dibuja y se salta al cierre de la rama (sin o12.b).
        //     drawSaved(o34 = v15, composer = v13, BoxScope = v0) -> true si dibujo. v2 es el resultado (esta muerto aqui);
        //     v5 se deja con el composer porque el cierre (d0 + q + q) lo usa.
        k.addInstructionsWithLabels(
            loadAt,
            """
                invoke-static {v15, v13, v0}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v2
                if-eqz v2, :orig
                move-object v5, v13
                goto :close
            """,
            ExternalLabel("orig", k.getInstruction(loadAt)),
            ExternalLabel("close", k.getInstruction(closeIdx))
        )

        // (c) vacio (ej1): igual, pero la rama ya termina justo despues (tt1.q(Z)), asi que se sigue de largo.
        //     Aqui v0 ya se piso con la clave del grupo: el BoxScope se lee de p1 (v62). v4 esta libre.
        k.addInstructions(
            emptyAt,
            """
                move-object/from16 v4, v$scopeReg
                invoke-static {v15, v13, v4}, $EXT->drawSaved(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v4
            """
        )

        // ---- 4) (antes parche \"deslizar la portada\") avisar cuando se pulsa Siguiente / Anterior: wa7.r(Object, Object) ----
        run {
            val kj6 = mutableClassDefBy(classDefBy("Lxr7;"))
            val sMethod = kj6.methods.singleOrNull {
                it.name == "r" && it.parameterTypes.size == 2 &&
                    it.parameterTypes[0] == "Ljava/lang/Object;" && it.parameterTypes[1] == "Ljava/lang/Object;"
            } ?: error("No se encontro xr7.r(Object, Object) (0.6.61: tb7.r)")
            val sImpl = sMethod.implementation ?: error("wa7.r sin implementacion")
            val sIns = sImpl.instructions.toList()
            val castIdx = sIns.indices.firstOrNull { i ->
                val r = (sIns[i] as? ReferenceInstruction)?.reference as? TypeReference
                sIns[i].opcode == Opcode.CHECK_CAST && r != null && r.type == "Lrt4;"
            } ?: error("xr7.r: no se encontro check-cast Lrt4;")
            val sRegs = sImpl.registerCount
            val sP1 = sRegs - 2
            val sP2 = sRegs - 1
            if (sP1 > 15 || sP2 > 15) error("wa7.r: registros altos (v$sP1, v$sP2)")
            sMethod.addInstructions(
                castIdx + 1,
                "invoke-static {v$sP1, v$sP2}, $EXT->onSkip(Ljava/lang/Object;Ljava/lang/Object;)V"
            )
        }

        // ---- 5) (antes parche \"Canvas: la portada que espera tambien se desliza\") enciende el interruptor de CoverUnderlay ----
        run {
            val q97 = mutableClassDefBy(classDefBy("Lmq7;"))
            val qMethod = q97.methods.singleOrNull {
                it.name == "q" && it.parameterTypes.size == 20 && it.parameterTypes[13] == "Lhd7;"
            } ?: error("No se encontro mq7.q (0.6.61: ja7.q)")
            qMethod.addInstructions(0, "invoke-static {}, $EXT_UNDERLAY->enableSlide()V")
        }
    }
}
