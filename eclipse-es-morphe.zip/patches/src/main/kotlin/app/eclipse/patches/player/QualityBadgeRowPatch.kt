package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

/** Alto del icono en dp (12.0f): el icono escala proporcional. Subir/bajar para agrandar/achicar. */
private const val ICON_HEIGHT_DP = "0x41400000"

private fun field(ins: Instruction, cls: String, name: String): Boolean {
    if (ins.opcode != Opcode.SGET_OBJECT) return false
    val ref = (ins as ReferenceInstruction).reference as? FieldReference ?: return false
    return ref.definingClass == cls && ref.name == name
}

private fun invokeStatic(ins: Instruction, cls: String, name: String): Boolean {
    if (ins.opcode != Opcode.INVOKE_STATIC) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == cls && ref.name == name
}

private fun newOd4(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.NEW_INSTANCE) return false
    val ref = (ins as ReferenceInstruction).reference as? TypeReference ?: return false
    return ref.type == "Lod4;"
}

private fun initOd4(ins: Instruction): Boolean {
    if (ins.opcode != Opcode.INVOKE_DIRECT) return false
    val ref = (ins as ReferenceInstruction).reference as? MethodReference ?: return false
    return ref.definingClass == "Lod4;" && ref.name == "<init>"
}

@Suppress("unused")
val qualityBadgeRowPatch = bytecodePatch(
    name = "Icono de calidad: texto al lado",
    description = "En la capa del icono de calidad (Hi-Res / Lossless / Atmos), la opcion \"Texto de nivel bajo el " +
        "icono\" ahora pone el texto a la DERECHA del icono (en fila) en vez de debajo. El icono ya no se estira: " +
        "mide 12 dp de alto (escala proporcional).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lxi6;"))
        val method = cls.methods.firstOrNull { m ->
            m.name == "k" && m.parameterTypes.map { it.toString() } ==
                listOf("I", "Ldw0;", "Low0;", "Lki1;", "Lt43;", "Z")
        } ?: error("No se encontro xi6.k")

        val list = (method.implementation ?: error("xi6.k sin codigo")).instructions.toList()

        // 1) Column(Top, CenterHorizontally): sget vq0.F; sget vd9.e; const; invoke kb1.a
        val colIdx = list.indices.filter { i ->
            i + 3 < list.size &&
                field(list[i], "Lvq0;", "F") &&
                field(list[i + 1], "Lvd9;", "e") &&
                invokeStatic(list[i + 3], "Lkb1;", "a")
        }
        if (colIdx.size != 1) error("xi6.k: se esperaba 1 Column y hay ${colIdx.size}")

        // 2) modificador del icono: new od4(1f,true) -> g48.g(od4, 1f)
        val newIdx = list.indices.filter { newOd4(list[it]) }
        val initIdx = list.indices.filter { initOd4(list[it]) }
        if (newIdx.size != 1 || initIdx.size != 1) error("xi6.k: od4 inesperado (${newIdx.size}/${initIdx.size})")
        val gIdx = (initIdx[0] + 1 until minOf(initIdx[0] + 6, list.size)).filter {
            invokeStatic(list[it], "Lg48;", "g")
        }
        if (gIdx.size != 1) error("xi6.k: se esperaba 1 g48.g tras od4 y hay ${gIdx.size}")

        // De atras hacia adelante para que los indices no se muevan.
        // g48.g(mod, 1f) (fillMaxWidth) -> g48.i(mod, ICON_HEIGHT) (Modifier.height en dp)
        method.removeInstruction(gIdx[0])
        method.addInstructions(
            gIdx[0],
            """
                const/high16 v5, $ICON_HEIGHT_DP
                invoke-static {v4, v5}, Lg48;->i(Lmh5;F)Lmh5;
            """
        )
        // quitar el init de od4 y cambiar su new-instance por el Modifier vacio
        method.removeInstruction(initIdx[0])
        method.removeInstruction(newIdx[0])
        method.addInstructions(newIdx[0], "sget-object v4, Ljh5;->q:Ljh5;")

        // Column -> Row(spacedBy 4dp, CenterVertically): gh7.a(Lw20;Lwk0;Lki1;I)
        val c = colIdx[0]
        method.removeInstruction(c + 3)
        method.removeInstruction(c + 2)
        method.removeInstruction(c + 1)
        method.removeInstruction(c)
        method.addInstructions(
            c,
            """
                sget-object v5, Lvq0;->C:Lwk0;
                new-instance v6, Lx20;
                new-instance v7, Lo;
                const/16 v8, 0xb
                invoke-direct {v7, v8}, Lo;-><init>(I)V
                const/high16 v8, 0x40800000
                const/4 v10, 0x0
                invoke-direct {v6, v8, v10, v7}, Lx20;-><init>(FZLt43;)V
                const/16 v7, 0x36
                invoke-static {v6, v5, v0, v7}, Lgh7;->a(Lw20;Lwk0;Lki1;I)Lhh7;
            """
        )
    }
}
