package app.eclipse.patches.ai

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val FREE = "Lapp/eclipse/extension/ai/FreeAi;"

/**
 * v0.20.236 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Apagado por defecto.
 *
 * Como funciona Eclipse (leido en el APK): Umbra y el DJ de texto los hace el SERVIDOR (api.eclipsemusic.app) con la llave de IA
 * del usuario guardada en su "vault". La app decide que proveedores estan "configurados" (y por eso muestra u oculta Umbra)
 * con `GET /api/ai/providers` (v1.f -> corrutina `Ls.invokeSuspend`, hilo de fondo). Por eso la llave gratis hay que
 * instalarla ANTES de esa consulta. Dos ganchos, los dos llaman a FreeAi.ensure(Context, almacen seguro):
 *  1. En `Ls.invokeSuspend`, caso de `GET /api/ai/providers`: justo despues de `Lro6;->m(ctx)` (v1 = Context, v14 = uk8) y
 *     antes de leer auth_token. Usa v2 como escrito (se reasigna despues con la URL).
 *  2. Al INICIO de `oh3.invokeSuspend` (toda peticion de Umbra/DJ): por si la llave no se instalo antes. v0/v1 libres.
 */
@Suppress("unused")
val freeAiPatch = bytecodePatch(
    name = "IA gratis: pedir llave al servidor puente",
    description = "Si no pusiste ninguna llave de IA en AI Models, Umbra y el DJ de texto funcionan igual: la app pide una llave " +
        "gratis de Groq a un servidor puente, la guarda y sigue. Si ya tenes llave propia (o ya hay una en tu cuenta) no hace nada.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // ---- Gancho 1: GET /api/ai/providers (Ls.invokeSuspend) ----
        val sCls = mutableClassDefBy(classDefBy("Ls;"))
        val sInv = sCls.methods.singleOrNull {
            it.name == "invokeSuspend" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("IA gratis: no se encontro Ls.invokeSuspend (version de Eclipse distinta de 0.6.70?)")
        val ins = (sInv.implementation ?: error("IA gratis: Ls.invokeSuspend sin codigo")).instructions.toList()

        val urlAt = ins.indexOfFirst {
            it.opcode == Opcode.CONST_STRING &&
                ((it as ReferenceInstruction).reference as? StringReference)?.string == "https://api.eclipsemusic.app/api/ai/providers"
        }
        if (urlAt < 0) error("IA gratis: no se encontro la URL de /api/ai/providers en Ls.invokeSuspend")

        var mAt = -1
        for (i in urlAt downTo 0) {
            val x = ins[i]
            if (x.opcode == Opcode.INVOKE_VIRTUAL &&
                ((x as ReferenceInstruction).reference as? MethodReference)?.let { it.definingClass == "Lwh6;" && it.name == "u" } == true
            ) { mAt = i; break }
        }
        if (mAt < 0) error("IA gratis: no se encontro Lwh6;->u antes de la URL")

        // Esperado: invoke-virtual {v14, v1}, Lro6;->m ; move-result-object v14 ; const-string v1, "auth_token"
        val call = ins[mAt] as FiveRegisterInstruction
        val res = ins[mAt + 1]
        val nxt = ins[mAt + 2]
        if (call.registerCount != 2 || call.registerD != 1 ||
            res.opcode != Opcode.MOVE_RESULT_OBJECT || (res as OneRegisterInstruction).registerA != 14 ||
            nxt.opcode != Opcode.CONST_STRING ||
            ((nxt as ReferenceInstruction).reference as? StringReference)?.string != "auth_token"
        ) error("IA gratis: la secuencia alrededor de Lwh6;->u no es la esperada")

        sInv.addInstructions(
            mAt + 2,
            """
            iget-object v2, v14, Ll29;->b:Landroid/content/SharedPreferences;
            invoke-static {v1, v2}, $FREE->ensure(Landroid/content/Context;Landroid/content/SharedPreferences;)V
            """
        )

        // ---- Gancho 2: oh3.invokeSuspend (peticiones de Umbra/DJ) ----
        val oh3 = mutableClassDefBy(classDefBy("Ljl3;"))
        val m = oh3.methods.singleOrNull {
            it.name == "invokeSuspend" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("IA gratis: no se encontro jl3.invokeSuspend (version de Eclipse distinta de 0.6.70?)")

        if (m.implementation == null || m.implementation!!.registerCount < 14) {
            error("IA gratis: jl3.invokeSuspend no tiene los registros esperados")
        }

        m.addInstructions(
            0,
            """
            iget-object v0, p0, Ljl3;->s:Landroid/content/Context;
            sget-object v1, Ll29;->c:Lwh6;
            invoke-virtual {v1, v0}, Lwh6;->u(Landroid/content/Context;)Ll29;
            move-result-object v1
            iget-object v1, v1, Ll29;->b:Landroid/content/SharedPreferences;
            invoke-static {v0, v1}, $FREE->ensure(Landroid/content/Context;Landroid/content/SharedPreferences;)V
            """
        )
    }
}
