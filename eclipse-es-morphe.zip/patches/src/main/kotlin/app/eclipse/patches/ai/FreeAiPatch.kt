package app.eclipse.patches.ai

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch

private const val FREE = "Lapp/eclipse/extension/ai/FreeAi;"

/**
 * v0.20.235 (SIN COMPILAR NI PROBAR). Eclipse 0.6.61. Apagado por defecto.
 *
 * Umbra (chat, listas) y el DJ de texto llaman a api.eclipsemusic.app a traves de z54.i -> oh3 (corrutina en hilo de fondo).
 * El servidor usa la llave de IA del usuario guardada en el "vault". Gancho al INICIO de oh3.invokeSuspend: pasa el Context
 * (oh3.s) y el almacen seguro (uk8.a, SharedPreferences cifradas, obtenido igual que lo hace oh3: Luk8;->b (Lro6) .m(ctx))
 * a FreeAi.ensure, que si el usuario no tiene ninguna llave pide una al Worker, la sube al vault y la guarda.
 *
 * Registros: oh3.invokeSuspend tiene v0..v11 libres al inicio (v12 = this, v13 = resultado); se usan v0 y v1.
 */
@Suppress("unused")
val freeAiPatch = bytecodePatch(
    name = "IA gratis: pedir llave al servidor puente",
    description = "Si no pusiste ninguna llave de IA en AI Models, Umbra y el DJ de texto funcionan igual: la app pide una llave " +
        "gratis de Groq a un servidor puente, la guarda y sigue. Si ya tenes llave propia no hace nada.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val oh3 = mutableClassDefBy(classDefBy("Loh3;"))
        val m = oh3.methods.singleOrNull {
            it.name == "invokeSuspend" && it.returnType == "Ljava/lang/Object;" &&
                it.parameterTypes.size == 1 && it.parameterTypes[0] == "Ljava/lang/Object;"
        } ?: error("IA gratis: no se encontro oh3.invokeSuspend (version de Eclipse distinta de 0.6.61?)")

        if (m.implementation == null || m.implementation!!.registerCount < 14) {
            error("IA gratis: oh3.invokeSuspend no tiene los registros esperados")
        }

        m.addInstructions(
            0,
            """
            iget-object v0, p0, Loh3;->s:Landroid/content/Context;
            sget-object v1, Luk8;->b:Lro6;
            invoke-virtual {v1, v0}, Lro6;->m(Landroid/content/Context;)Luk8;
            move-result-object v1
            iget-object v1, v1, Luk8;->a:Landroid/content/SharedPreferences;
            invoke-static {v0, v1}, $FREE->ensure(Landroid/content/Context;Landroid/content/SharedPreferences;)V
            """
        )
    }
}
