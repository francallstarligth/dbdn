package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Log al inicio de x90.B(Song) ("play"): es la funcion central de reproducir una cancion en 0.6.47. */
private const val MARKER = ">>> play() ENTERED for '"

@Suppress("unused")
val pausePreviousPatch = bytecodePatch(
    name = "Pausar cancion anterior al cambiar",
    description = "Al elegir o saltar a otra cancion, pausa de inmediato la que sonaba mientras carga la nueva " +
        "(en vez de seguir sonando con la barra avanzando).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val mutable = mutableClassDefBy(classDefBy("Lx90;"))

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val isPlay = impl.instructions.any { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (!isPlay) continue

            // Primera lectura del campo X (Job de carga anterior) dentro de B: justo antes de cancelar la carga
            // previa y lanzar la nueva. Es la cola comun a reproduccion local y "remote".
            val index = impl.instructions.indexOfFirst { ins ->
                ins.opcode == Opcode.IGET_OBJECT &&
                    ((ins as ReferenceInstruction).reference as? FieldReference)
                        ?.let { it.definingClass == "Lx90;" && it.name == "X" && it.type == "Lfk8;" } == true
            }
            if (index < 0) error("No se encontro el punto de insercion en x90.B (version distinta de 0.6.47?)")

            // v0 se sobrescribe justo despues (iget-object v0, p0, x90->X), asi que se puede usar.
            method.addInstructions(
                index,
                """
                    iget-object v0, p0, Lx90;->y:Lip2;
                    invoke-static {v0}, Lapp/eclipse/extension/player/PausePrevious;->pause(Ljava/lang/Object;)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro x90.B (el metodo con '$MARKER')")
    }
}
