package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Log al inicio de xe0.H(Song) ("play"): es la funcion central de reproducir una cancion en 0.6.57 (he0.G en 0.6.55). */
private const val MARKER = ">>> play() ENTERED for '"

@Suppress("unused")
val pausePreviousPatch = bytecodePatch(
    name = "Pausar cancion anterior al cambiar",
    description = "Al elegir o saltar a otra cancion, pausa de inmediato la que sonaba mientras carga la nueva " +
        "(en vez de seguir sonando con la barra avanzando).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val mutable = mutableClassDefBy(classDefBy("Ljh0;"))

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val isPlay = impl.instructions.any { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (!isPlay) continue

            // v1.13.0: el gancho va al INICIO de x90.B (antes de todo el trabajo previo: logs, estado, analitica...),
            // para que la pausa llegue lo antes posible y no se oiga el resto de la cancion anterior.
            // 0.6.57: xe0.H tiene 18 registros, p0 = v16 (no cabe en 4 bits para iget-object): se copia a v0 con
            // move-object/from16 (v0 esta libre al entrar: su primer uso es un const-string en el idx 6).
            method.addInstructions(
                0,
                """
                    move-object/from16 v0, p0
                    iget-object v0, v0, Ljh0;->y:Ll43;
                    invoke-static {v0}, Lapp/eclipse/extension/player/PausePrevious;->pause(Ljava/lang/Object;)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro vf0.L (el metodo con '$MARKER'; version de Eclipse distinta de 0.6.61?)")

        // 2) vf0.f0(Uri, Song) (0.6.55: he0.a0; prepare f()->i() en 57) (x90.W en 0.6.47): reutiliza el MISMO ExoPlayer (y) para la cancion nueva, pero llama a
        //    e0(!a0) (setPlayWhenReady) ANTES de setMediaItems/prepare(f). Con el reproductor viejo pausado, eso reanuda
        //    unos milisegundos del audio viejo que quedaba en el buffer. Se mueve e0 a despues de f().
        //    0.6.55: el argumento de e0 YA NO es un `true` fijo: es v1 = (xor-int/lit8 v1, v0, 1) = !a0. Por eso se copia
        //    ese registro a v5 (VERIFICADO en 57 libre del idx 106 al 156: no se lee ni se escribe) y se llama e0(v5) tras f().
        var reordered = false
        for (method in mutable.methods) {
            if (method.name != "h0") continue
            val types = method.parameterTypes.map { it.toString() }
            if (types.size != 2 || types[0] != "Landroid/net/Uri;") continue
            val list = (method.implementation ?: continue).instructions.toList()

            fun isPlayerCall(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction, name: String, paramCount: Int): Boolean {
                val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference ?: return false
                return ref.definingClass == "Ll43;" && ref.name == name && ref.parameterTypes.size == paramCount
            }

            val e0s = list.indices.filter { isPlayerCall(list[it], "k0", 1) }
            if (e0s.size != 1) error("vf0.f0: se esperaba 1 llamada a ey2.e0(Z) y hay ${e0s.size}")
            val playIndex = e0s[0]
            val prepareIndex = list.indices.firstOrNull { it > playIndex && isPlayerCall(list[it], "j", 0) }
                ?: error("No se encontro prepare() i() despues de e0 en vf0.f0")

            val call = list[playIndex] as? FiveRegisterInstruction ?: error("vf0.f0: e0 no es invoke-virtual normal")
            val playerReg = call.registerC
            val argReg = call.registerD
            val prev = list[playIndex - 1]
            if (prev.opcode != Opcode.XOR_INT_LIT8 || (prev as OneRegisterInstruction).registerA != argReg) {
                error("vf0.f0: antes de e0 no esta el xor-int/lit8 esperado (version de Eclipse distinta de 0.6.61?)")
            }
            if (playerReg > 15 || argReg > 15) error("vf0.f0: registros fuera de rango")

            // Primero lo de mas abajo (despues de f()), para que los indices de arriba no se muevan.
            method.addInstructions(prepareIndex + 1, "invoke-virtual {v$playerReg, v5}, Ll43;->k0(Z)V")
            method.removeInstruction(playIndex)
            method.addInstructions(playIndex, "move v5, v$argReg")
            reordered = true
            break
        }
        if (!reordered) error("No se encontro vf0.f0(Uri, Song)")
    }
}
