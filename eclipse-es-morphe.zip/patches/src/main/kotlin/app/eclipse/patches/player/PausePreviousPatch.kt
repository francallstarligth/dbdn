package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Log al inicio de x90.B(Song) ("play"): es la funcion central de reproducir una cancion en 0.6.47. */
private const val MARKER = ">>> play() ENTERED for '"

@Suppress("unused")
val pausePreviousPatch = bytecodePatch(
    name = "Pausar cancion anterior al cambiar",
    description = "Al elegir o saltar a otra cancion, pausa de inmediato la que sonaba mientras carga la nueva " +
        "(en vez de seguir sonando con la barra avanzando).",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val mutable = mutableClassDefBy(classDefBy("Lx90;"))

        var patched = false
        for (method in mutable.methods) {
            val impl = method.implementation ?: continue
            val isPlay = impl.instructions.any { ins ->
                ins.opcode == Opcode.CONST_STRING &&
                    ((ins as ReferenceInstruction).reference as StringReference).string == MARKER
            }
            if (!isPlay) continue

            // v1.13.0: el gancho va al INICIO de x90.B (antes de todo el trabajo previo: logs, estado, analitica...),
            // para que la pausa llegue lo antes posible y no se oiga el resto de la cancion anterior.
            // B tiene .locals 14: v0 esta libre al entrar (se sobrescribe despues) y p0 = v14 cabe en 4 bits.
            method.addInstructions(
                0,
                """
                    iget-object v0, p0, Lx90;->y:Lip2;
                    invoke-static {v0}, Lapp/eclipse/extension/player/PausePrevious;->pause(Ljava/lang/Object;)V
                """
            )
            patched = true
            break
        }
        if (!patched) error("No se encontro x90.B (el metodo con '$MARKER')")

        // 2) x90.W(Uri, Song): reutiliza el MISMO ExoPlayer (y) para la cancion nueva, pero llama a
        //    e0(true) (setPlayWhenReady) ANTES de setMediaItems(s3)/prepare(f). Con el reproductor viejo pausado,
        //    eso reanuda unos milisegundos del audio viejo que quedaba en el buffer. Se mueve e0 a despues de f().
        var reordered = false
        for (method in mutable.methods) {
            if (method.name != "W") continue
            val types = method.parameterTypes.map { it.toString() }
            if (types.size != 2 || types[0] != "Landroid/net/Uri;") continue
            val list = (method.implementation ?: continue).instructions

            fun isPlayerCall(ins: com.android.tools.smali.dexlib2.iface.instruction.Instruction, name: String, paramCount: Int): Boolean {
                val ref = (ins as? ReferenceInstruction)?.reference as? MethodReference ?: return false
                return ref.definingClass == "Lip2;" && ref.name == name && ref.parameterTypes.size == paramCount
            }

            val playIndex = list.indexOfFirst { isPlayerCall(it, "e0", 1) }
            if (playIndex < 0) error("No se encontro e0(Z) en x90.W")
            val prepareIndex = list.indexOfFirst { it !== list[playIndex] && isPlayerCall(it, "f", 0) }
                .takeIf { it > playIndex } ?: error("No se encontro prepare() f() despues de e0 en x90.W")

            method.removeInstruction(playIndex)
            // Tras quitar una instruccion, f() quedo en prepareIndex - 1; se inserta justo despues.
            method.addInstructions(
                prepareIndex,
                "invoke-virtual {v6, v5}, Lip2;->e0(Z)V"
            )
            reordered = true
            break
        }
        if (!reordered) error("No se encontro x90.W(Uri, Song)")
    }
}
