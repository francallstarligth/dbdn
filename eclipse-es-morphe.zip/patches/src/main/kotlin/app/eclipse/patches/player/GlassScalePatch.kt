package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction

/**
 * v0.20.440 (Eclipse 0.6.75, SIN COMPILAR NI PROBAR): todos los vidrios dibujan su fondo mas chico.
 *
 * Visto en el dex 75: `La82;->Q(F)F` = 1 - 0.7 * min(radio/7, 1). Es la escala del fondo de los vidrios
 * (`Lfg5.f`, `Lpg5.c`, `Lpr9.e`, `Lch5.a`, `Lbh5.f`; son sus unicos llamadores). Con blur >= 7 dp da 0.3.
 * Arreglo: la constante 0.7f (0x3f333333 = 1060320051) pasa a 0.75f (0x3f400000), o sea minimo 0.25.
 */
private const val ANTES = 1060320051 // 0.7f
private const val DESPUES = "0x3f400000" // 0.75f

@Suppress("unused")
val glassScalePatch = bytecodePatch(
    name = "Vidrios: fondo mas chico (25 %)",
    description = "Todos los vidrios (barra de abajo, mini reproductor, botones) dibujan y difuminan su fondo a " +
        "25 % del tamano (antes 30 %), asi cuestan menos. Los bordes del efecto de lente pueden verse un poco mas " +
        "suaves. Desmarcalo para apagarlo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val a82 = mutableClassDefBy(classDefBy("La82;"))
        val metodo = a82.methods.singleOrNull {
            it.name == "Q" && it.returnType == "F" && it.parameterTypes.map { p -> p.toString() } == listOf("F")
        } ?: error("No se encontro a82.Q (escala del vidrio; Eclipse 0.6.75)")
        val ins = (metodo.implementation ?: error("a82.Q sin codigo")).instructions.toList()
        val hallados = ins.indices.filter { i ->
            val a = ins[i]
            a.opcode == Opcode.CONST && (a as NarrowLiteralInstruction).narrowLiteral == ANTES
        }
        if (hallados.size != 1) error("a82.Q: se esperaba 1 constante 0.7f (hay ${hallados.size})")
        val reg = (ins[hallados[0]] as OneRegisterInstruction).registerA
        metodo.replaceInstruction(hallados[0], "const v$reg, $DESPUES")
    }
}
