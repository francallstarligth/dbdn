package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val SLIDE = "Lapp/eclipse/extension/player/MiniSlide;"

/**
 * v0.20.373 (Eclipse 0.6.75; la 372 se probo: "funciona" desde el primer toque). Version LIMPIA: se quitan el log, el cartelito y el gancho de `Ljh0.K`.
 * Mini reproductor "pildora" de la skin Native: el boton SIGUIENTE hace el mismo deslizamiento que al soltar el dedo tras arrastrar.
 * El mini es `Lt62.i(Lrb6;Z;Leu1;I)` (classes2.dex); su boton siguiente es `Ln40(Ljh0, 17)`. Su gesto `Lws6` (pointerInput) nace al dibujar el mini;
 * al soltar el dedo se lanza `Lvs6` (anima `Lqt`, cambia de cancion con `Ljh0.K(false)` y vuelve a 0).
 * (1) `Lws6.<init>`: antes del `return-void` -> `MiniSlide.registerWs(p0)` (guarda el gesto con todos sus datos).
 * (2) `Ln40.a()`: antes del `packed-switch` (v0 = this, v1 = caso) -> si `MiniSlide.nextClick(caso, this)` devuelve true, `return-object Unit`.
 * Solo se toca el caso 17. Si algo falla, el boton hace lo de siempre.
 */
@Suppress("unused")
val miniSlidePatch = bytecodePatch(
    description = "Al tocar siguiente en el mini reproductor (skin Native), el contenido se desliza igual que al arrastrar con el dedo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (1) en el boton siguiente del mini (Ln40 caso 17): lanzar el deslizamiento en vez de cambiar de golpe
        run {
            val cls = mutableClassDefBy(classDefBy("Ln40;"))
            val m = cls.methods.singleOrNull { it.name == "a" && it.parameterTypes.isEmpty() && it.returnType == "Ljava/lang/Object;" }
                ?: error("Deslizar con el boton: no se encontro Ln40.a")
            val ins = (m.implementation ?: error("Deslizar con el boton: Ln40.a sin codigo")).instructions.toList()
            val sw = ins.indices.filter { ins[it].opcode == Opcode.PACKED_SWITCH }
            if (sw.size != 1) error("Deslizar con el boton: se esperaba 1 packed-switch en Ln40.a y hay ${sw.size}")
            m.addInstructionsWithLabels(
                sw[0],
                """
                invoke-static {v1, v0}, $SLIDE->nextClick(ILjava/lang/Object;)Z
                move-result v10
                if-eqz v10, :ms_normal
                sget-object v10, Lscb;->a:Lscb;
                return-object v10
                :ms_normal
                nop
                """
            )
        }

        // (2) guardar el gesto Lws6 (nace al dibujar el mini) con todos sus datos
        run {
            val cls = mutableClassDefBy(classDefBy("Lws6;"))
            val m = cls.methods.singleOrNull {
                it.name == "<init>" && it.parameterTypes.map { p -> p.toString() } ==
                    listOf("Z", "Lte7;", "Luh6;", "F", "Lo12;", "Lqt;", "Z", "Lle8;", "Ljh0;", "Lte7;", "Luh6;", "Luh6;")
            } ?: error("Deslizar con el boton: no se encontro Lws6.<init> (Eclipse 0.6.75)")
            val ins = (m.implementation ?: error("Deslizar con el boton: Lws6.<init> sin codigo")).instructions.toList()
            val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
            if (ret.size != 1) error("Deslizar con el boton: se esperaba 1 return-void en Lws6.<init> y hay ${ret.size}")
            m.addInstructions(
                ret[0],
                """
                invoke-static {p0}, $SLIDE->registerWs(Ljava/lang/Object;)V
                """
            )
        }
    }
}
