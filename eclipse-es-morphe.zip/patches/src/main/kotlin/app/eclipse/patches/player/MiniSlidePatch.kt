package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val SLIDE = "Lapp/eclipse/extension/player/MiniSlide;"

/**
 * v0.20.369 DIAGNOSTICO: (3) `Ljh0.K(Z)` (siguiente): al inicio llama `MiniSlide.dbgK(this)`, que anota quien llamo y copia el log al portapapeles.
 * v0.20.368 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Mini reproductor "pildora" de la skin Native (portada, titulo, pausa y SIGUIENTE):
 * el boton siguiente hace el mismo deslizamiento que al soltar el dedo tras arrastrar.
 * Visto en el dex: el mini es `Lt62.i(Lrb6;Z;Leu1;I)` (con Z = false solo muestra pausa y siguiente; el boton siguiente es `Ln40(Ljh0, 17)`).
 * Crea su gesto `Lws6` (pointerInput) que al soltar el dedo llama `Lts6.a()`: calcula la direccion (-1/0/1) y lanza
 * `Lkxb.I(Lts6.s scope, null, null, new Lvs6(Lqt, F offset, Lll8, F densidad, Z, I direccion, Lle8, Ljh0, Luh6, Lte7, Luh6, Luh6, null), 3)`.
 * `Lvs6`: anima el Lqt a -+distancia (200 ms), actualiza la cancion, llama `Ljh0.K(false)` (direccion > 0) o `Ljh0.R()` y vuelve el Lqt a 0.
 * (1) `Lts6.<init>`: antes del `return-void` -> `MiniSlide.register(p0)` (guarda el Lts6 con todos sus datos).
 * (2) `Ln40.a()`: antes del `packed-switch` (v0 = this, v1 = caso) -> si `MiniSlide.nextClick(caso, this)` devuelve true, `return-object Unit`.
 * Solo se toca el caso 17 (siguiente del mini). Si algo falla, el boton hace lo de siempre.
 * NO verificado: que compile; que Morphe aplique; que Z = false sea el mini de Native; el lado del deslizamiento; el aspecto.
 */
@Suppress("unused")
val miniSlidePatch = bytecodePatch(
    description = "Al tocar siguiente en el mini reproductor (skin Native), el contenido se desliza igual que al arrastrar con el dedo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (1) guardar el manejador de "soltar el dedo" del mini con todos sus datos
        run {
            val cls = mutableClassDefBy(classDefBy("Lts6;"))
            val m = cls.methods.singleOrNull {
                it.name == "<init>" &&
                    it.parameterTypes.map { p -> p.toString() } ==
                    listOf("F", "Lxhb;", "Lo12;", "Lte7;", "Lqt;", "Lll8;", "Z", "Lle8;", "Ljh0;", "Luh6;", "Lte7;", "Luh6;", "Luh6;")
            } ?: error("Deslizar con el boton: no se encontro Lts6.<init> (Eclipse 0.6.75)")
            val ins = (m.implementation ?: error("Deslizar con el boton: Lts6.<init> sin codigo")).instructions.toList()
            val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
            if (ret.size != 1) error("Deslizar con el boton: se esperaba 1 return-void en Lts6.<init> y hay ${ret.size}")
            m.addInstructions(
                ret[0],
                """
                invoke-static {p0}, $SLIDE->register(Ljava/lang/Object;)V
                """
            )
        }

        // (2) en el boton siguiente del mini (Ln40 caso 17): lanzar el deslizamiento en vez de cambiar de golpe
        run {
            val cls = mutableClassDefBy(classDefBy("Ln40;"))
            val m = cls.methods.singleOrNull { it.name == "a" && it.parameterTypes.isEmpty() && it.returnType == "Ljava/lang/Object;" }
                ?: error("Deslizar con el boton: no se encontro Ln40.a")
            val ins = (m.implementation ?: error("Deslizar con el boton: Ln40.a sin codigo")).instructions.toList()
            val sw = ins.indices.filter { ins[it].opcode == Opcode.PACKED_SWITCH }
            if (sw.size != 1) error("Deslizar con el boton: se esperaba 1 packed-switch en Ln40.a y hay ${sw.size}")
            m.addInstructionsWithLabels(
                sw[0],
                """
                invoke-static {v1, v0}, $SLIDE->nextClick(ILjava/lang/Object;)Z
                move-result v10
                if-eqz v10, :ms_normal
                sget-object v10, Lscb;->a:Lscb;
                return-object v10
                :ms_normal
                nop
                """
            )
        }

        // (3) DIAGNOSTICO: al inicio de Ljh0.K(Z) (siguiente) copiar el log al portapapeles
        run {
            val cls = mutableClassDefBy(classDefBy("Ljh0;"))
            val m = cls.methods.singleOrNull { it.name == "K" && it.parameterTypes.map { p -> p.toString() } == listOf("Z") && it.returnType == "V" }
                ?: error("Deslizar con el boton: no se encontro Ljh0.K(Z)")
            m.addInstructions(
                0,
                """
                invoke-static {p0}, $SLIDE->dbgK(Ljava/lang/Object;)V
                """
            )
        }
    }
}
