package app.eclipse.patches.player

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val SLIDE = "Lapp/eclipse/extension/player/MiniSlide;"

/**
 * v0.20.367 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Mini reproductor de la skin Native: el boton siguiente/anterior hace el mismo
 * deslizamiento que al soltar el dedo tras arrastrar.
 * Visto en el dex: `Ls32.g` (composable del mini) crea `Lsj3(Lqt offset, F umbral, Lo12 scope, F distancia, Lsf4, Ljh0, Luh6)` (arrastre) y 3 lambdas
 * `Lij3(Lo12, Lsf4, Ljh0, Luh6, I modo)`: modo 0 = anterior (Ltj3 modo 2 -> Ljh0.R), modo 1 = `Ljh0.q0` (play/pausa, no se toca), modo 2 = siguiente
 * (Ltj3 modo 1 -> Ljh0.K(false)). Al soltar el dedo `Lqj3` lanza `Lrj3(F offset, F distancia, Lqt, Lsf4, Ljh0, Luh6, null)`: anima el offset a +-distancia,
 * llama K(false) (offset < 0) o R() (offset >= 0) y vuelve el offset a 0.
 * (1) `Lsj3.<init>(Lqt;FLo12;FLsf4;Ljh0;Luh6;)V`: antes del `return-void` -> `MiniSlide.register(v2 = Lqt, v5 = distancia)`.
 * (2) `Lij3.a()`: antes del `packed-switch` (v1 = modo, v4 = scope, v2 = Unit) -> si `MiniSlide.go(modo, scope, sf4, jh0, uh6)` devuelve true, `return-object v2`.
 * NO verificado: que compile; que Morphe aplique; el orden de botones (anterior/siguiente); que la skin del usuario use `Ls32.g`; el aspecto.
 */
@Suppress("unused")
val miniSlidePatch = bytecodePatch(
    description = "Al tocar siguiente o anterior en el mini reproductor (skin Native), el contenido se desliza igual que al arrastrar con el dedo.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        // (1) guardar el Animatable del desplazamiento y la distancia
        run {
            val cls = mutableClassDefBy(classDefBy("Lsj3;"))
            val m = cls.methods.singleOrNull {
                it.name == "<init>" &&
                    it.parameterTypes.map { p -> p.toString() } ==
                    listOf("Lqt;", "F", "Lo12;", "F", "Lsf4;", "Ljh0;", "Luh6;")
            } ?: error("Deslizar con el boton: no se encontro Lsj3.<init>(Lqt;F...) (Eclipse 0.6.75)")
            val ins = (m.implementation ?: error("Deslizar con el boton: Lsj3.<init> sin codigo")).instructions.toList()
            val ret = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
            if (ret.size != 1) error("Deslizar con el boton: se esperaba 1 return-void en Lsj3.<init> y hay ${ret.size}")
            m.addInstructions(
                ret[0],
                """
                invoke-static {v2, v5}, $SLIDE->register(Ljava/lang/Object;F)V
                """
            )
        }

        // (2) en los botones anterior/siguiente: lanzar el deslizamiento en vez de cambiar de golpe
        run {
            val cls = mutableClassDefBy(classDefBy("Lij3;"))
            val m = cls.methods.singleOrNull { it.name == "a" && it.parameterTypes.isEmpty() && it.returnType == "Ljava/lang/Object;" }
                ?: error("Deslizar con el boton: no se encontro Lij3.a")
            val ins = (m.implementation ?: error("Deslizar con el boton: Lij3.a sin codigo")).instructions.toList()
            val sw = ins.indices.filter { ins[it].opcode == Opcode.PACKED_SWITCH }
            if (sw.size != 1) error("Deslizar con el boton: se esperaba 1 packed-switch en Lij3.a y hay ${sw.size}")
            m.addInstructionsWithLabels(
                sw[0],
                """
                iget-object v6, v0, Lij3;->s:Lsf4;
                iget-object v7, v0, Lij3;->t:Ljh0;
                iget-object v8, v0, Lij3;->u:Luh6;
                invoke-static {v1, v4, v6, v7, v8}, $SLIDE->go(ILjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Z
                move-result v5
                if-eqz v5, :ms_normal
                return-object v2
                :ms_normal
                nop
                """
            )
        }
    }
}
