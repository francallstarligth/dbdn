package app.eclipse.patches.apple

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.extensions.InstructionExtensions.replaceInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference
import com.android.tools.smali.dexlib2.iface.reference.TypeReference

/**
 * Librerias nativas de Apple Music en Eclipse 0.6.75 (nombres leidos del APK Base; sin "lib" ni ".so").
 * Todas pertenecen al paquete de Apple (inicio de sesion + descifrado de la reproduccion): ninguna otra libreria de la
 * app depende de ellas ni de `c++_shared` (se reviso la cadena de dependencias de cada .so de arm64). Se quedan
 * `eclipseaudio`, `eclipseac4`, `eclipsealac`, `eclipseusb` y `onnxruntime` (Automix).
 */
private val APPLE_LIBS = listOf(
    "androidappmusic", "CoreFoundation", "CoreFP", "CoreADI", "CoreLSKD",
    "medialibrarycore", "mediaplatform", "storeservicescore", "daapkit",
    "dispatch", "BlocksRuntime", "icudata_sv_apple", "icui18n_sv_apple", "icuuc_sv_apple",
    "curl", "xml2", "c++_shared", "eclipseappleaccount", "eclipsefairplay"
)
private val ABIS = listOf("arm64-v8a", "armeabi-v7a")

/**
 * v0.20.375 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * Quita del APK las librerias nativas de Apple Music (inicio de sesion y reproduccion de Apple): unos 135 MB.
 * El APK de 211 MB queda en unos 75 MB. Automix (ONNX) y el audio propio de Eclipse NO se tocan.
 *
 * Sin estas librerias: `AppleFairPlay.isAvailable()` atrapa el fallo de `System.loadLibrary` y queda en false (la app
 * muestra "Native Apple Music playback is unavailable"); el servicio de login corre en otro proceso (`:apple_account`) y
 * solo se abre desde Ajustes > Integraciones > Apple Music (que oculta "Apple Music: ocultar en Ajustes").
 * Las portadas y metadatos de Apple (internet, sin estas librerias) siguen igual.
 * NO verificado: que la app arranque sin ellas en el cel; que Morphe excluya las librerias del APK final.
 */
@Suppress("unused")
val appleLibsRemovePatch = resourcePatch(
    name = "Apple Music: quitar librerias (APK mas liviano)",
    description = "Quita del APK las librerias de Apple Music (inicio de sesion y reproduccion de Apple), unos 135 MB. " +
        "Automix no cambia. Las canciones de Apple dejan de sonar y no se puede iniciar sesion.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val present = listApkEntries("lib/")
        if (present.none { it.endsWith("/libandroidappmusic.so") }) {
            error("Apple Music: no se encontro libandroidappmusic.so en el APK (version de Eclipse distinta de 0.6.75?)")
        }
        for (abi in ABIS) {
            for (name in APPLE_LIBS) {
                delete("lib/$abi/lib$name.so")
            }
        }
    }
}

private fun isString(i: Instruction, s: String): Boolean =
    (i.opcode == Opcode.CONST_STRING || i.opcode == Opcode.CONST_STRING_JUMBO) &&
        ((i as ReferenceInstruction).reference as? StringReference)?.string == s

/**
 * v0.20.376 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * OCULTA (no borra codigo) "Apple Music" en Ajustes. La 375 solo tocaba `Lyn1;->r` (otra pantalla: el usuario siguio
 * viendo la fila en Ajustes > Integraciones). Ahora son 3 sitios:
 *
 * 1) LISTA de Ajustes (la pantalla plana: Fuentes de musica / Integraciones / Almacenamiento / Acerca de): sale de un mapa fijo
 *    en `Lxv6;-><clinit>` (`Lxv6;->c`: "Integrations" -> [Apple Music, Last.fm, AI Models]). Se cambia el
 *    `filled-new-array` de esa lista para que no lleve el registro de "Apple Music".
 * 2) BUSCADOR de Ajustes: `Lyv6;-><clinit>` arma un mapa titulo -> palabras clave con pares `Lgd7`; la entrada
 *    "Apple Music" se renombra a "Last.fm", y como la entrada real de "Last.fm" viene DESPUES, la reemplaza en el mapa
 *    (la ultima clave gana) y "Apple Music" desaparece.
 * 3) La fila de `Lyn1;->r` (otro diseno de Ajustes): se borra la llamada `Loba;->l` que la dibuja (de la 375).
 *
 * NO toca: la pantalla interna `Lmf9;->f`, el diseno agrupado (`Lao1;`/`Lfq2;`, subtitulo "Apple Music, Last.fm, and AI
 * models"), ni `Ld40;->b`. La pagina de Apple Music dice tener tambien calidad, metadatos y portada; al ocultar la
 * entrada se pierde el acceso a esos ajustes (no se reviso que hay dentro).
 * NO verificado: que compile; que Morphe aplique; que el mapa del buscador se arme con "la ultima clave gana".
 */
@Suppress("unused")
val appleHideSettingsRowPatch = bytecodePatch(
    name = "Apple Music: ocultar en Ajustes",
    description = "Oculta \"Apple Music\" (inicio de sesion) en Ajustes > Integraciones y en el buscador de Ajustes.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        // 1) Lista plana de Ajustes: Lxv6.<clinit>
        val xv6 = mutableClassDefBy(classDefBy("Lxv6;"))
        val xv6Init = xv6.methods.firstOrNull { it.name == "<clinit>" }
            ?: error("Apple Music en Ajustes: no se encontro Lxv6.<clinit> (Eclipse 0.6.75)")
        val xv6Ins = (xv6Init.implementation ?: error("Lxv6.<clinit> sin codigo")).instructions.toList()
        val xvAt = xv6Ins.indexOfFirst { isString(it, "Apple Music") }
        if (xvAt < 0) error("Apple Music en Ajustes: no se encontro el texto \"Apple Music\" en Lxv6.<clinit>")
        val appleReg = (xv6Ins[xvAt] as OneRegisterInstruction).registerA
        val arrAt = (xvAt + 1 until minOf(xv6Ins.size, xvAt + 6)).firstOrNull { k ->
            val i = xv6Ins[k]
            i.opcode == Opcode.FILLED_NEW_ARRAY &&
                ((i as ReferenceInstruction).reference as? TypeReference)?.type == "[Ljava/lang/String;"
        } ?: error("Apple Music en Ajustes: no se encontro el filled-new-array de la lista de Integraciones")
        val arr = xv6Ins[arrAt] as FiveRegisterInstruction
        val regs = listOf(arr.registerC, arr.registerD, arr.registerE, arr.registerF, arr.registerG).take(arr.registerCount)
        if (!regs.contains(appleReg)) error("Apple Music en Ajustes: la lista de Integraciones no usa el registro de \"Apple Music\"")
        val rest = regs.toMutableList().also { it.remove(appleReg) }
        if (rest.isEmpty()) error("Apple Music en Ajustes: la lista de Integraciones quedaria vacia")
        xv6Init.replaceInstruction(
            arrAt,
            "filled-new-array {" + rest.joinToString(", ") { "v$it" } + "}, [Ljava/lang/String;"
        )

        // 2) Buscador de Ajustes: Lyv6.<clinit> (la entrada "Apple Music" pasa a llamarse "Last.fm" y la real de Last.fm la pisa)
        val yv6 = mutableClassDefBy(classDefBy("Lyv6;"))
        val yv6Init = yv6.methods.firstOrNull { it.name == "<clinit>" }
            ?: error("Apple Music en el buscador: no se encontro Lyv6.<clinit> (Eclipse 0.6.75)")
        val yv6Ins = (yv6Init.implementation ?: error("Lyv6.<clinit> sin codigo")).instructions.toList()
        val yvAt = yv6Ins.indexOfFirst { isString(it, "Apple Music") }
        if (yvAt < 0) error("Apple Music en el buscador: no se encontro la entrada \"Apple Music\"")
        val lastAfter = (yvAt + 1 until yv6Ins.size).any { isString(yv6Ins[it], "Last.fm") }
        if (!lastAfter) error("Apple Music en el buscador: no hay una entrada \"Last.fm\" despues de la de Apple Music")
        val yvReg = (yv6Ins[yvAt] as OneRegisterInstruction).registerA
        yv6Init.replaceInstruction(yvAt, "const-string v$yvReg, \"Last.fm\"")

        // 3) Otro diseno de Ajustes: Lyn1.r (de la 375)
        val cls = mutableClassDefBy(classDefBy("Lyn1;"))
        val method = cls.methods.firstOrNull { m ->
            m.name == "r" && m.parameterTypes.size == 2 &&
                m.implementation?.instructions?.any { isString(it, "Apple Music") } == true &&
                m.implementation?.instructions?.any { isString(it, "Not connected") } == true
        } ?: error("Apple Music en Ajustes: no se encontro Lyn1.r con la fila \"Apple Music\" (Eclipse 0.6.75)")

        val ins = (method.implementation ?: error("Lyn1.r sin codigo")).instructions.toList()
        val at = ins.indexOfFirst { isString(it, "Apple Music") }
        if (at < 0) error("Apple Music en Ajustes: no se encontro el texto \"Apple Music\" en Lyn1.r")

        // La llamada que dibuja la fila va unas instrucciones despues (en 0.6.75: 3 despues).
        val call = (at + 1 until minOf(ins.size, at + 8)).firstOrNull { k ->
            val i = ins[k]
            i.opcode == Opcode.INVOKE_STATIC_RANGE &&
                ((i as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Loba;" && it.name == "l" && it.returnType == "V" && it.parameterTypes.size == 6
                } == true
        } ?: error("Apple Music en Ajustes: no se encontro la llamada Loba.l que dibuja la fila")

        method.removeInstruction(call)
    }
}
