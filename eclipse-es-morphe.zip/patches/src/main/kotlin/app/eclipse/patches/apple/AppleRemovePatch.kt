package app.eclipse.patches.apple

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.patch.resourcePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.Instruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/**
 * Librerias nativas de Apple Music en Eclipse 0.6.75 (nombres leidos del APK Base; sin "lib" ni ".so").
 * Todas pertenecen al paquete de Apple (inicio de sesion + descifrado de la reproduccion): ninguna otra libreria de la
 * app depende de ellas ni de `c++_shared` (se reviso la cadena de dependencias de cada .so de arm64). Se quedan
 * `eclipseaudio`, `eclipseac4`, `eclipsealac`, `eclipseusb` y `onnxruntime` (Automix).
 */
private val APPLE_LIBS = listOf(
    "androidappmusic", "CoreFoundation", "CoreFP", "CoreADI", "CoreLSKD",
    "medialibrarycore", "mediaplatform", "storeservicescore", "daapkit",
    "dispatch", "BlocksRuntime", "icudata_sv_apple", "icui18n_sv_apple", "icuuc_sv_apple",
    "curl", "xml2", "c++_shared", "eclipseappleaccount", "eclipsefairplay"
)
private val ABIS = listOf("arm64-v8a", "armeabi-v7a")

/**
 * v0.20.375 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * Quita del APK las librerias nativas de Apple Music (inicio de sesion y reproduccion de Apple): unos 135 MB.
 * El APK de 211 MB queda en unos 75 MB. Automix (ONNX) y el audio propio de Eclipse NO se tocan.
 *
 * Sin estas librerias: `AppleFairPlay.isAvailable()` atrapa el fallo de `System.loadLibrary` y queda en false (la app
 * muestra "Native Apple Music playback is unavailable"); el servicio de login corre en otro proceso (`:apple_account`) y
 * solo se abre desde Ajustes > Integraciones > Apple Music (que oculta "Apple Music: ocultar en Ajustes").
 * Las portadas y metadatos de Apple (internet, sin estas librerias) siguen igual.
 * NO verificado: que la app arranque sin ellas en el cel; que Morphe excluya las librerias del APK final.
 */
@Suppress("unused")
val appleLibsRemovePatch = resourcePatch(
    name = "Apple Music: quitar librerias (APK mas liviano)",
    description = "Quita del APK las librerias de Apple Music (inicio de sesion y reproduccion de Apple), unos 135 MB. " +
        "Automix no cambia. Las canciones de Apple dejan de sonar y no se puede iniciar sesion.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val present = listApkEntries("lib/")
        if (present.none { it.endsWith("/libandroidappmusic.so") }) {
            error("Apple Music: no se encontro libandroidappmusic.so en el APK (version de Eclipse distinta de 0.6.75?)")
        }
        for (abi in ABIS) {
            for (name in APPLE_LIBS) {
                delete("lib/$abi/lib$name.so")
            }
        }
    }
}

private fun isString(i: Instruction, s: String): Boolean =
    (i.opcode == Opcode.CONST_STRING || i.opcode == Opcode.CONST_STRING_JUMBO) &&
        ((i as ReferenceInstruction).reference as? StringReference)?.string == s

/**
 * v0.20.375 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL; sin kotlinc aqui, revisado a mano; Eclipse 0.6.75).
 * Oculta la fila "Apple Music" de Ajustes > Integraciones (la pantalla plana de Ajustes: Fuentes de musica,
 * Integraciones, Almacenamiento). Esa fila se dibuja con UNA llamada `Loba;->l(I I Leu1; Ldk3; String; String)V` justo
 * despues de `const-string "Apple Music"` en `Lyn1;->r`; el parche solo borra esa llamada (quedan Last.fm,
 * Modelos de IA y Servicios vinculados).
 *
 * NO toca (siguen mostrando Apple Music): la pantalla interna de Integraciones (`Lmf9;->f`, con "Subscription,
 * quality, metadata and artwork"), el buscador de Ajustes (`Lyv6;`/`Lxv6;`) ni el otro diseno de Ajustes agrupado
 * (`Lao1;`/`Lfq2;`, subtitulo "Apple Music, Last.fm, and AI models"). Ojo: esa pantalla de Apple Music dice tener
 * tambien calidad, metadatos y portada; al ocultar la fila se pierde la entrada a esos ajustes (no se reviso que hay dentro).
 * NO verificado: que compile; que Morphe aplique; que Ajustes se vea bien sin la fila.
 */
@Suppress("unused")
val appleHideSettingsRowPatch = bytecodePatch(
    name = "Apple Music: ocultar en Ajustes",
    description = "Quita la opcion \"Apple Music\" de Ajustes > Integraciones (la del inicio de sesion).",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val cls = mutableClassDefBy(classDefBy("Lyn1;"))
        val method = cls.methods.firstOrNull { m ->
            m.name == "r" && m.parameterTypes.size == 2 &&
                m.implementation?.instructions?.any { isString(it, "Apple Music") } == true &&
                m.implementation?.instructions?.any { isString(it, "Not connected") } == true
        } ?: error("Apple Music en Ajustes: no se encontro Lyn1.r con la fila \"Apple Music\" (Eclipse 0.6.75)")

        val ins = (method.implementation ?: error("Lyn1.r sin codigo")).instructions.toList()
        val at = ins.indexOfFirst { isString(it, "Apple Music") }
        if (at < 0) error("Apple Music en Ajustes: no se encontro el texto \"Apple Music\"")

        // La llamada que dibuja la fila va unas instrucciones despues (en 0.6.75: 3 despues).
        val call = (at + 1 until minOf(ins.size, at + 8)).firstOrNull { k ->
            val i = ins[k]
            i.opcode == Opcode.INVOKE_STATIC_RANGE &&
                ((i as ReferenceInstruction).reference as? MethodReference)?.let {
                    it.definingClass == "Loba;" && it.name == "l" && it.returnType == "V" && it.parameterTypes.size == 6
                } == true
        } ?: error("Apple Music en Ajustes: no se encontro la llamada Loba.l que dibuja la fila")

        method.removeInstruction(call)
    }
}
