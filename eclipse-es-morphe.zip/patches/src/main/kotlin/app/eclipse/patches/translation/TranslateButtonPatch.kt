package app.eclipse.patches.translation

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.FiveRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val BUTTON = "Lapp/eclipse/extension/player/TranslateButton;"

/**
 * v0.20.217 (SIN COMPILAR NI PROBAR). Boton redondo de traducir en el panel de letras (portado a Eclipse 0.6.61).
 * `lb.b` (0.6.61; en 0.6.57 era mb.b) (lambda con los textos "Translate" / "Hide translation") hace, cuando NO esta cargando:
 *   invoke-virtual composer, key, fr1.d0(I)      <- abre el grupo del texto
 *   invoke-interface estado, dr9.getValue()      <- indice `hook` (aqui se inserta el gancho)
 *   move-result-object vX                        <- vX queda libre antes de esto: se usa de temporal
 *   ... texto ... e5a.b(...) ; invoke-virtual composer, v8(=false), fr1.q(Z)  <- cierra el grupo (etiqueta `close`)
 * Gancho: TranslateButton.draw(composer, estado); si devuelve true se salta el texto (goto close).
 * Si algo no coincide con lo esperado, el parche se omite y Eclipse queda como estaba.
 */
@Suppress("unused")
val translateButtonPatch = bytecodePatch(
    name = "Letras: boton de traducir redondo",
    description = "Cambia el texto \"Translate\" del panel de letras por un boton redondo con el icono de traducir (como " +
        "en Apple Music): tenue sin traducir y un poco mas claro cuando la traduccion esta puesta.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        try {
            val mb = mutableClassDefBy(classDefBy("Llb;"))
            fun strOf(i: com.android.tools.smali.dexlib2.iface.instruction.Instruction): String? =
                if (i.opcode == Opcode.CONST_STRING) ((i as ReferenceInstruction).reference as? StringReference)?.string else null
            val b = mb.methods.singleOrNull { m ->
                m.implementation?.instructions?.any { strOf(it) == "Hide translation" } == true
            } ?: error("lb: no se encontro el metodo con \"Hide translation\"")
            val ins = b.implementation!!.instructions.toList()
            fun methodOf(i: Int): MethodReference? = (ins[i] as? ReferenceInstruction)?.reference as? MethodReference

            val hide = ins.indices.filter { strOf(ins[it]) == "Hide translation" }
            if (hide.size != 1) error("se esperaba 1 \"Hide translation\" (hay ${hide.size})")
            if (ins.indices.count { strOf(ins[it]) == "Translate" } != 1) error("se esperaba 1 \"Translate\"")

            // d0 (abre el grupo) justo antes del getValue del estado
            val d0 = (hide[0] downTo 0).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_VIRTUAL && methodOf(i)?.let { it.definingClass == "Lfr1;" && it.name == "d0" } == true
            } ?: error("no se encontro fr1.d0 antes del texto")
            val gv = d0 + 1
            if (ins[gv].opcode != Opcode.INVOKE_INTERFACE || methodOf(gv)?.name != "getValue" ||
                ins[gv + 1].opcode != Opcode.MOVE_RESULT_OBJECT
            ) error("tras fr1.d0 no viene getValue + move-result-object")
            val composer = (ins[d0] as FiveRegisterInstruction).registerC
            val state = (ins[gv] as FiveRegisterInstruction).registerC
            val temp = (ins[gv + 1] as OneRegisterInstruction).registerA
            if (maxOf(composer, state, temp) > 15) error("registros fuera de v0..v15 ($composer, $state, $temp)")
            if (temp == composer || temp == state) error("el temporal coincide con composer/estado")

            // cierre del grupo: el primer fr1.q(Z) despues del texto (e5a.b)
            val textCall = (gv until ins.size).firstOrNull { i ->
                ins[i].opcode == Opcode.INVOKE_STATIC_RANGE && methodOf(i)?.let { it.definingClass == "Le5a;" && it.name == "b" } == true
            } ?: error("no se encontro e5a.b del texto")
            val close = textCall + 1
            if (ins[close].opcode != Opcode.INVOKE_VIRTUAL ||
                methodOf(close)?.let { it.definingClass == "Lfr1;" && it.name == "q" } != true ||
                (ins[close] as FiveRegisterInstruction).registerC != composer
            ) error("tras e5a.b no viene fr1.q(Z) sobre el mismo composer")
            // el registro de `false` de q(Z) no se toca entre el inicio y el cierre salvo su const 0 (se salta el texto)
            val falseReg = (ins[close] as FiveRegisterInstruction).registerD
            val writes = (0 until d0).filter { i -> (ins[i] as? OneRegisterInstruction)?.registerA == falseReg }
            if (writes.isEmpty()) error("v$falseReg nunca se escribe antes del texto")

            b.addInstructionsWithLabels(
                gv,
                """
                    invoke-static {v$composer, v$state}, $BUTTON->draw(Ljava/lang/Object;Ljava/lang/Object;)Z
                    move-result v$temp
                    if-nez v$temp, :close
                """,
                ExternalLabel("close", b.getInstruction(close))
            )
        } catch (e: Exception) {
            println("Boton de traducir redondo omitido: ${e.message}")
        }
    }
}
