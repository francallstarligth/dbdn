package app.eclipse.patches.apple

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructionsWithLabels
import app.morphe.patcher.extensions.InstructionExtensions.getInstruction
import app.morphe.patcher.patch.bytecodePatch
import app.morphe.patcher.util.smali.ExternalLabel
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

/** Identifica la clase qf2 (mismo texto que usan los otros parches). */
private const val MARKER = "pick: no animated artwork found for '"

/** Texto que aparece en el filtro de qf2.c(Song, Lew, Continuation), el metodo que pide la portada a Apple. */
private const val GATE_STRING = "tidal_isrc:"

@Suppress("unused")
val appleLibraryArtworkPatch = bytecodePatch(
    name = "Apple Music: portadas en biblioteca",
    description = "Hace que Eclipse tambien busque la portada animada de Apple Music en las canciones " +
        "agregadas a tu biblioteca o playlists (hoy solo la busca en las canciones que vienen de la busqueda). " +
        "Usa el artista y el album de la cancion.",
    default = false
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    execute {
        val immutable = classDefByStrings(MARKER).firstOrNull()
            ?: error("No se encontro la clase con: $MARKER (version de Eclipse distinta de 0.6.47?)")
        val mutable = mutableClassDefBy(immutable)

        // qf2.c(Song, ew, Continuation): devuelve Object y contiene "tidal_isrc:".
        // (qf2.b tambien contiene ese texto, pero devuelve rf2.)
        val method = mutable.methods.firstOrNull { m ->
            m.returnType == "Ljava/lang/Object;" &&
                (m.implementation?.instructions?.any { ins ->
                    ins.opcode == Opcode.CONST_STRING &&
                        ((ins as ReferenceInstruction).reference as StringReference).string == GATE_STRING
                } == true)
        } ?: error("No se encontro el metodo que pide la portada a Apple")

        val instructions = method.implementation!!.instructions.toList()

        val stringIdx = instructions.indexOfFirst { ins ->
            ins.opcode == Opcode.CONST_STRING &&
                ((ins as ReferenceInstruction).reference as StringReference).string == GATE_STRING
        }

        // Filtro original: if-nez p2, :cond_4  (hay ID de pista de Apple) ... si no, solo sigue si el id
        // empieza por "tidal_isrc:"; en cualquier otro caso devuelve null (las canciones de la biblioteca,
        // con id "addon:...", se descartaban aqui).
        val gateIdx = (stringIdx + 1 until instructions.size).first { instructions[it].opcode == Opcode.IF_NEZ }

        // Destino: el primer iput-object posterior sobre el campo "q" de la continuacion (guarda la cancion).
        val targetIdx = (gateIdx until instructions.size).first { i ->
            val ins = instructions[i]
            ins.opcode == Opcode.IPUT_OBJECT &&
                ((ins as ReferenceInstruction).reference as FieldReference).name == "q"
        }

        // Salta el filtro: el resto del metodo ya comprueba el album/titulo antes de buscar en Apple.
        method.addInstructionsWithLabels(
            gateIdx,
            "goto :skip_gate",
            ExternalLabel("skip_gate", method.getInstruction(targetIdx))
        )
    }
}
