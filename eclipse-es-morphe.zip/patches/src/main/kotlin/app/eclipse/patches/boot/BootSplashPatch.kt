package app.eclipse.patches.boot

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode

private const val SPLASH = "Lapp/eclipse/extension/boot/BootSplash;"

/**
 * v0.20.126 (SIN COMPILAR / SIN PROBAR). Pantalla de carga con un disco de vinilo que gira y el eclipse naranja detras.
 *
 * VERIFICADO en el smali de 0.6.47: com.eclipse.android.MainActivity.onCreate (.locals 12, p0 = this) termina con
 * `invoke-static {p0, v0}, Lue1;->a(Lte1;Laf1;)V` (el setContent de Compose) y un unico `return-void`. Justo antes de ese
 * return-void se llama BootSplash.show(this): agrega una capa negra encima del contenido con el disco girando y la quita
 * con un fundido cuando la app ya va fluida (ver BootSplash.java).
 */
@Suppress("unused")
val bootSplashPatch = bytecodePatch(
    name = "Pantalla de carga: disco girando",
    description = "Al abrir Eclipse muestra una pantalla negra con un disco de vinilo girando y el eclipse naranja " +
        "detras, hasta que la app termina de cargar. Desmarcalo para volver a la pantalla normal.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))
        val onCreate = main.methods.singleOrNull {
            it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
        } ?: error("No se encontro MainActivity.onCreate (version de Eclipse distinta de 0.6.47?)")
        val ins = (onCreate.implementation ?: error("MainActivity.onCreate sin codigo")).instructions.toList()
        val rets = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
        if (rets.size != 1) error("MainActivity.onCreate: se esperaba 1 return-void y hay ${rets.size}")
        onCreate.addInstructions(rets[0], "invoke-static/range {p0 .. p0}, $SPLASH->show(Landroid/app/Activity;)V")
    }
}
