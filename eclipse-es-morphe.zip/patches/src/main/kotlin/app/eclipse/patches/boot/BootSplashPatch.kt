package app.eclipse.patches.boot

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.extensions.InstructionExtensions.removeInstruction
import app.morphe.patcher.patch.booleanOption
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.NarrowLiteralInstruction
import com.android.tools.smali.dexlib2.iface.instruction.OneRegisterInstruction
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.instruction.RegisterRangeInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val SPLASH = "Lapp/eclipse/extension/boot/BootSplash;"

/**
 * v0.20.253 (Eclipse 0.6.70, SIN COMPILAR NI PROBAR): portado. bn1.a=ip1.a (setContent), ms3=gx3 (HomeViewModel; a(gx3,Z,dz1)), hr9=vaa (j), ys7.w(zq1,I)=ua8.d(nt1,I), gx1.e=e32.e (Image). Comparados en el dex 70: mismas posiciones (Boolean.FALSE idx 45, "HomeViewModel" idx 76, 120f idx 119, Image idx 140). Los comentarios siguen con nombres viejos.
 * v0.20.218 (SIN COMPILAR NI PROBAR): portado a 0.6.61. Nombres 0.6.57 -> 0.6.61: fm1=bn1 (setContent), qr3=ms3 (HomeViewModel), cq9=hr9 (en 0.6.61 el exito guarda con hr9.j(Object) y no con k), pr7.x=ys7.w (splash propio), iw1.e=gx1.e (Image). Los comentarios de abajo siguen con nombres viejos.
 * v0.20.126 (v0.20.136: ademas engancha ih3.a, HomeViewModel, para saber cuando cargo el Inicio; v0.20.134: vuelve a venir marcado por defecto; se quito el parche del disco del sistema). Pantalla de carga con un disco de vinilo que gira y el eclipse naranja detras.
 *
 * VERIFICADO en el smali de 0.6.55: com.eclipse.android.MainActivity.onCreate (.locals 12, p0 = this) termina con
 * `invoke-static {p0, v0}, Lue1;->a(Lte1;Laf1;)V` (el setContent de Compose) y un unico `return-void`. Justo antes de ese
 * return-void se llama BootSplash.show(this): agrega una capa negra encima del contenido con el disco girando y la quita
 * con un fundido cuando la app ya va fluida (ver BootSplash.java).
 */
@Suppress("unused")
val bootSplashPatch = bytecodePatch(
    name = "Pantalla de carga: disco girando",
    description = "Al abrir Eclipse muestra una pantalla negra con un disco de vinilo girando y el eclipse naranja " +
        "detras, hasta que la app termina de cargar.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    val inApp by booleanOption(
        key = "inAppSplash",
        default = true,
        title = "Disco tambien en el splash de Eclipse",
        description = "El icono que Eclipse muestra en sus propias pantallas de carga (p18.d) se cambia por el mismo disco girando. Desmarcalo para dejar el icono."
    )

    execute {
        val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))
        val onCreate = main.methods.singleOrNull {
            it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
        } ?: error("No se encontro MainActivity.onCreate (version de Eclipse distinta de 0.6.55?)")
        val ins = (onCreate.implementation ?: error("MainActivity.onCreate sin codigo")).instructions.toList()
        // v0.20.166 (0.6.55): onCreate tiene 2 return-void (el primero es la rama que abre TvActivity y hace finish()).
        // Se engancha el ULTIMO, que debe venir justo despues del setContent de Compose (jl1.a(il1, pl1)).
        val rets = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
        if (rets.isEmpty() || rets.last() != ins.lastIndex) error("MainActivity.onCreate: el ultimo return-void no es el final")
        val setContent = (ins[rets.last() - 1] as? ReferenceInstruction)?.reference as? MethodReference
        if (ins[rets.last() - 1].opcode != Opcode.INVOKE_STATIC || setContent == null ||
            setContent.definingClass != "Lip1;" || setContent.name != "a"
        ) {
            error("MainActivity.onCreate: antes del ultimo return-void no esta jl1.a (setContent)")
        }
        onCreate.addInstructions(rets.last(), "invoke-static/range {p0 .. p0}, $SPLASH->show(Landroid/app/Activity;)V")

        // v0.20.136: senal de "el Inicio cargo". VERIFICADO en el smali de 0.6.55: ih3 es el HomeViewModel; su funcion
        // estatica a(Lrq3;ZLou1;)Object pide el Inicio armado. Rama de exito: guarda los datos (Lsn9;->k) y justo despues
        // viene `sget-object Boolean.FALSE` (ya no esta cargando). Rama de fallo: registra "compose/home failed: " y
        // "HomeViewModel". En las dos se llama BootSplash.homeLoaded() (sin registros: llamada estatica sin parametros).
        val vm = mutableClassDefBy(classDefBy("Lgx3;"))
        val load = vm.methods.singleOrNull {
            it.name == "a" && it.parameterTypes.map { p -> p.toString() } == listOf("Lgx3;", "Z", "Ldz1;")
        } ?: error("No se encontro ih3.a (HomeViewModel; version de Eclipse distinta de 0.6.55?)")
        val list = (load.implementation ?: error("ih3.a sin codigo")).instructions.toList()

        val falseAt = list.indices.filter {
            val ins = list[it]
            ins.opcode == Opcode.SGET_OBJECT &&
                ((ins as ReferenceInstruction).reference as? FieldReference)
                    ?.let { r -> r.definingClass == "Ljava/lang/Boolean;" && r.name == "FALSE" } == true
        }
        if (falseAt.size != 1) error("ih3.a: se esperaba 1 Boolean.FALSE y hay ${falseAt.size}")
        val prev = list[falseAt[0] - 1]
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev.opcode != Opcode.INVOKE_VIRTUAL || prevRef == null || prevRef.name != "j" ||
            prevRef.definingClass != "Lvaa;"
        ) {
            error("ih3.a: antes de Boolean.FALSE no esta la llamada Lvaa;->j")
        }

        val failAt = list.indices.filter {
            val ins = list[it]
            ins.opcode == Opcode.CONST_STRING &&
                ((ins as ReferenceInstruction).reference as? StringReference)?.string == "HomeViewModel"
        }
        if (failAt.size != 1) error("ih3.a: se esperaba 1 const-string HomeViewModel y hay ${failAt.size}")

        // Primero el indice mas alto (fallo) para que el de exito siga valido.
        val hook = "invoke-static {}, $SPLASH->homeLoaded()V"
        val (hi, lo) = if (failAt[0] > falseAt[0]) failAt[0] to falseAt[0] else falseAt[0] to failAt[0]
        load.addInstructions(hi, hook)
        load.addInstructions(lo, hook)

        // v0.20.147: el icono del splash propio de Eclipse (p18.d: Box negro + Image de eclipse_sun, 120 dp, "splashScale" y
        // "splashAlpha") se cambia por el disco girando. VERIFICADO en el smali de 0.6.55: p18.d(Lfp1;I)V tiene una sola llamada
        // `invoke-static/range {v0 .. v9}, Lj12;->e(Li36;String;Lmh5;Lki;Lbn1;F Lja1;Lfp1;I I)V` (el Image; modifier = inicio+2,
        // composer = inicio+7) y una sola constante 120f (0x42f00000) que es el tamano en dp.
        if (inApp == true) {
            val p18 = mutableClassDefBy(classDefBy("Lua8;"))
            val d = p18.methods.singleOrNull {
                it.name == "d" && it.parameterTypes.map { p -> p.toString() } == listOf("Lnt1;", "I")
            } ?: error("No se encontro p18.d (splash de Eclipse; version distinta de 0.6.55?)")
            val dl = (d.implementation ?: error("p18.d sin codigo")).instructions.toList()

            val callAt = dl.indices.filter {
                val i = dl[it]
                i.opcode == Opcode.INVOKE_STATIC_RANGE &&
                    ((i as ReferenceInstruction).reference as? MethodReference)
                        ?.let { r -> r.definingClass == "Le32;" && r.name == "e" } == true
            }
            if (callAt.size != 1) error("p18.d: se esperaba 1 llamada a bc2.e y hay ${callAt.size}")
            val start = (dl[callAt[0]] as RegisterRangeInstruction).startRegister
            val modReg = start + 2
            val compReg = start + 7
            if (compReg > 15) error("p18.d: registros fuera de v0..v15 (composer v$compReg)")

            val constAt = dl.indices.filter {
                dl[it].opcode == Opcode.CONST_HIGH16 && (dl[it] as NarrowLiteralInstruction).narrowLiteral == 0x42f00000
            }
            if (constAt.size != 1) error("p18.d: se esperaba 1 constante 120f y hay ${constAt.size}")
            if (constAt[0] >= callAt[0]) error("p18.d: la constante 120f no esta antes del Image")
            val constReg = (dl[constAt[0]] as OneRegisterInstruction).registerA

            // Primero el indice mas alto (la llamada), para que el de la constante siga valido.
            d.addInstructions(callAt[0], "invoke-static {v$modReg, v$compReg}, $SPLASH->drawIn(Ljava/lang/Object;Ljava/lang/Object;)V")
            d.removeInstruction(callAt[0] + 1)   // la llamada vieja a bc2.e quedo una instruccion mas abajo
            d.addInstructions(constAt[0], "invoke-static {}, $SPLASH->boxDp()F\nmove-result v$constReg")
            d.removeInstruction(constAt[0] + 2)  // el const/high16 viejo quedo dos instrucciones mas abajo
        }
    }
}
