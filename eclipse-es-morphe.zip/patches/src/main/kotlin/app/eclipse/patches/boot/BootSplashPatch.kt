package app.eclipse.patches.boot

import app.eclipse.patches.shared.Constants.COMPATIBILITY_ECLIPSE
import app.morphe.patcher.extensions.InstructionExtensions.addInstructions
import app.morphe.patcher.patch.bytecodePatch
import com.android.tools.smali.dexlib2.Opcode
import com.android.tools.smali.dexlib2.iface.instruction.ReferenceInstruction
import com.android.tools.smali.dexlib2.iface.reference.FieldReference
import com.android.tools.smali.dexlib2.iface.reference.MethodReference
import com.android.tools.smali.dexlib2.iface.reference.StringReference

private const val SPLASH = "Lapp/eclipse/extension/boot/BootSplash;"

/**
 * v0.20.126 (v0.20.136: ademas engancha ih3.a, HomeViewModel, para saber cuando cargo el Inicio; v0.20.134: vuelve a venir marcado por defecto; se quito el parche del disco del sistema). Pantalla de carga con un disco de vinilo que gira y el eclipse naranja detras.
 *
 * VERIFICADO en el smali de 0.6.47: com.eclipse.android.MainActivity.onCreate (.locals 12, p0 = this) termina con
 * `invoke-static {p0, v0}, Lue1;->a(Lte1;Laf1;)V` (el setContent de Compose) y un unico `return-void`. Justo antes de ese
 * return-void se llama BootSplash.show(this): agrega una capa negra encima del contenido con el disco girando y la quita
 * con un fundido cuando la app ya va fluida (ver BootSplash.java).
 */
@Suppress("unused")
val bootSplashPatch = bytecodePatch(
    name = "Pantalla de carga: disco girando",
    description = "Al abrir Eclipse muestra una pantalla negra con un disco de vinilo girando y el eclipse naranja " +
        "detras, hasta que la app termina de cargar.",
    default = true
) {
    compatibleWith(COMPATIBILITY_ECLIPSE)

    extendWith("extensions/extension.mpe")

    execute {
        val main = mutableClassDefBy(classDefBy("Lcom/eclipse/android/MainActivity;"))
        val onCreate = main.methods.singleOrNull {
            it.name == "onCreate" && it.parameterTypes.map { p -> p.toString() } == listOf("Landroid/os/Bundle;")
        } ?: error("No se encontro MainActivity.onCreate (version de Eclipse distinta de 0.6.47?)")
        val ins = (onCreate.implementation ?: error("MainActivity.onCreate sin codigo")).instructions.toList()
        val rets = ins.indices.filter { ins[it].opcode == Opcode.RETURN_VOID }
        if (rets.size != 1) error("MainActivity.onCreate: se esperaba 1 return-void y hay ${rets.size}")
        onCreate.addInstructions(rets[0], "invoke-static/range {p0 .. p0}, $SPLASH->show(Landroid/app/Activity;)V")

        // v0.20.136: senal de "el Inicio cargo". VERIFICADO en el smali de 0.6.47: ih3 es el HomeViewModel; su funcion
        // estatica a(Lih3;ZLrn1;)Object pide el Inicio armado. Rama de exito: guarda los datos (Ldl8;->k) y justo despues
        // viene `sget-object Boolean.FALSE` (ya no esta cargando). Rama de fallo: registra "compose/home failed: " y
        // "HomeViewModel". En las dos se llama BootSplash.homeLoaded() (sin registros: llamada estatica sin parametros).
        val vm = mutableClassDefBy(classDefBy("Lih3;"))
        val load = vm.methods.singleOrNull {
            it.name == "a" && it.parameterTypes.map { p -> p.toString() } == listOf("Lih3;", "Z", "Lrn1;")
        } ?: error("No se encontro ih3.a (HomeViewModel; version de Eclipse distinta de 0.6.47?)")
        val list = (load.implementation ?: error("ih3.a sin codigo")).instructions.toList()

        val falseAt = list.indices.filter {
            val ins = list[it]
            ins.opcode == Opcode.SGET_OBJECT &&
                ((ins as ReferenceInstruction).reference as? FieldReference)
                    ?.let { r -> r.definingClass == "Ljava/lang/Boolean;" && r.name == "FALSE" } == true
        }
        if (falseAt.size != 1) error("ih3.a: se esperaba 1 Boolean.FALSE y hay ${falseAt.size}")
        val prev = list[falseAt[0] - 1]
        val prevRef = (prev as? ReferenceInstruction)?.reference as? MethodReference
        if (prev.opcode != Opcode.INVOKE_VIRTUAL || prevRef == null || prevRef.name != "k" ||
            prevRef.definingClass != "Ldl8;"
        ) {
            error("ih3.a: antes de Boolean.FALSE no esta la llamada Ldl8;->k")
        }

        val failAt = list.indices.filter {
            val ins = list[it]
            ins.opcode == Opcode.CONST_STRING &&
                ((ins as ReferenceInstruction).reference as? StringReference)?.string == "HomeViewModel"
        }
        if (failAt.size != 1) error("ih3.a: se esperaba 1 const-string HomeViewModel y hay ${failAt.size}")

        // Primero el indice mas alto (fallo) para que el de exito siga valido.
        val hook = "invoke-static {}, $SPLASH->homeLoaded()V"
        val (hi, lo) = if (failAt[0] > falseAt[0]) failAt[0] to falseAt[0] else falseAt[0] to failAt[0]
        load.addInstructions(hi, hook)
        load.addInstructions(lo, hook)
    }
}
