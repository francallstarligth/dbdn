package androidx.media3.decoder;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * v0.20.423 (SIN COMPILAR NI PROBAR). Version minima con el nombre que busca la libreria nativa de ffmpeg
 * (libffmpegJNI.so): solo guarda el buffer de salida y sabe agrandarlo (`grow`). Nada de la app lo usa.
 */
public class SimpleDecoderOutputBuffer {
    public ByteBuffer data;

    public ByteBuffer init(int size) {
        data = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
        data.position(0);
        data.limit(size);
        return data;
    }

    public ByteBuffer grow(int size) {
        ByteBuffer old = data;
        if (old != null && old.capacity() >= size) {
            old.position(0);
            old.limit(size);
            return old;
        }
        ByteBuffer n = ByteBuffer.allocateDirect(size).order(ByteOrder.nativeOrder());
        if (old != null) {
            old.position(0);
            old.limit(old.capacity());
            n.put(old);
        }
        n.position(0);
        n.limit(size);
        data = n;
        return n;
    }
}
