package androidx.media3.decoder.ffmpeg;

/** v0.20.423 (SIN COMPILAR NI PROBAR). Funciones nativas de libffmpegJNI.so (nombre fijo, ver FfmpegAudioDecoder). */
public final class FfmpegLibrary {
    private FfmpegLibrary() {}

    public static native String ffmpegGetVersion();

    public static native int ffmpegGetInputBufferPaddingSize();

    public static native boolean ffmpegHasDecoder(String codecName);
}
