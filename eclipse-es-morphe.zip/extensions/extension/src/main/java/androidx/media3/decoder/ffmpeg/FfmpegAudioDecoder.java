package androidx.media3.decoder.ffmpeg;

import androidx.media3.decoder.SimpleDecoderOutputBuffer;
import java.nio.ByteBuffer;

/**
 * v0.20.423 (SIN COMPILAR NI PROBAR). Solo las funciones nativas de libffmpegJNI.so (del decodificador de ffmpeg para Media3,
 * LGPL, compilado por github.com/Lekuno/media3-ffmpeg-audio-android). El nombre del paquete y de la clase NO se pueden cambiar:
 * la libreria busca `Java_androidx_media3_decoder_ffmpeg_FfmpegAudioDecoder_*` y el metodo `growOutputBuffer`.
 */
public final class FfmpegAudioDecoder {

    public long nativeContext;

    public native long ffmpegInitialize(String codecName, byte[] extraData, boolean outputFloat, int rate, int channels);

    public native int ffmpegDecode(long context, ByteBuffer inputData, int inputSize,
                                   SimpleDecoderOutputBuffer outputBuffer, ByteBuffer outputData, int outputSize);

    public native int ffmpegGetChannelCount(long context);

    public native int ffmpegGetSampleRate(long context);

    public native long ffmpegReset(long context, byte[] extraData);

    public native void ffmpegRelease(long context);

    /** La libreria nativa llama a este metodo cuando la salida no cabe en el buffer. */
    @SuppressWarnings("unused")
    private ByteBuffer growOutputBuffer(SimpleDecoderOutputBuffer outputBuffer, int requiredSize) {
        return outputBuffer.grow(requiredSize);
    }
}
