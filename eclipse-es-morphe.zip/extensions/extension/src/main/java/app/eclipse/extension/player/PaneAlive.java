package app.eclipse.extension.player;

import android.util.Log;

import java.lang.reflect.Method;

/**
 * v0.20.70 (SIN COMPILAR / SIN PROBAR). Eclipse (hj6.b) arma la pantalla de Cola solo cuando su peso (qw0.e) pasa de 0.001,
 * y la destruye cuando baja a 0: por eso al tocar Cola se crea desde cero (lista vacia, portadas grises).
 * Aqui Cola nunca baja de {@link #FLOOR}: queda armada (con su lista y portadas ya cargadas) pero invisible (alpha ~0.002)
 * y con escala 0 (no recibe toques), hasta que el peso real sube.
 * Ganchos (PaneAlivePatch): {@link #begin} al inicio de qw0.e(String), {@link #end} antes de su return,
 * {@link #hide} justo despues de que hj6.b pone el alpha a la pantalla.
 */
public final class PaneAlive {
    private static final String TAG = "EclipseES.PaneAlive";
    static final float FLOOR = 0.002f;

    private static String cur;
    private static boolean tried;
    private static boolean broken;
    private static Method layer; // vd9.F(Modifier, scaleX, scaleY, alpha, rotationZ, shape, renderEffect, mask)

    private PaneAlive() {}

    private static boolean ready() {
        if (broken) return false;
        if (layer != null) return true;
        if (tried) return false;
        tried = true;
        try {
            Class<?> c = Class.forName("vd9");
            for (Method m : c.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (m.getName().equals("F") && p.length == 8 && p[1] == float.class && p[2] == float.class
                        && p[3] == float.class && p[4] == float.class && p[7] == int.class
                        && java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && m.getReturnType() == p[0]) {
                    m.setAccessible(true);
                    layer = m;
                    return true;
                }
            }
            Log.w(TAG, "no se encontro vd9.F");
        } catch (Throwable t) {
            Log.w(TAG, "se apaga: " + t);
        }
        broken = true;
        return false;
    }

    public static void begin(String name) {
        cur = name;
    }

    public static float end(float w) {
        try {
            if ("queue".equals(cur) && w < FLOOR && ready()) return FLOOR;
        } catch (Throwable t) {
            broken = true;
        }
        return w;
    }

    /** mod = modificador ya con alpha; w = peso de esa pantalla. Si esta en el minimo: escala 0 (sin toques). */
    public static Object hide(Object mod, float w) {
        try {
            if (w > FLOOR + 0.0004f || !ready()) return mod;
            // mascara de r15.g (alpha dado, rotationZ dado) pero con scaleX y scaleY dados: 0x7effb & ~3
            return layer.invoke(null, mod, 0f, 0f, w, 0f, null, null, 0x7eff8);
        } catch (Throwable t) {
            broken = true;
            Log.w(TAG, "hide se apaga: " + t);
            return mod;
        }
    }
}
