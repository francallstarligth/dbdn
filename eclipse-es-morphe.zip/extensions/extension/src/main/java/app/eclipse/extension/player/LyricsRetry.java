package app.eclipse.extension.player;

import java.util.HashMap;

/**
 * v0.20.122 (SIN COMPILAR / SIN PROBAR). Reintento automatico de la letra. El parche (LyricsRetryPatch) llama
 * shouldRetry(idCancion) cuando la busqueda de letra de Eclipse vuelve vacia: devuelve true hasta MAX veces seguidas por
 * cancion (la cuenta se reinicia si pasaron mas de WINDOW_MS desde el ultimo intento). Si devuelve true, Eclipse vuelve a
 * lanzar la busqueda, y maybeDelay() (llamado al inicio de y9.h, que corre en el hilo de IO) espera DELAY_MS antes de pedir.
 */
public final class LyricsRetry {
    private static final int MAX = 2;
    private static final long WINDOW_MS = 15000L;
    private static final long DELAY_MS = 1500L;

    private static final HashMap<String, long[]> state = new HashMap<String, long[]>();
    private static volatile boolean pending;

    private LyricsRetry() {}

    public static boolean shouldRetry(String id) {
        try {
            if (id == null) return false;
            long now = System.currentTimeMillis();
            synchronized (state) {
                long[] s = state.get(id);
                if (s == null || now - s[1] > WINDOW_MS) {
                    s = new long[]{0L, now};
                    state.put(id, s);
                    if (state.size() > 64) {
                        state.clear();
                        state.put(id, s);
                    }
                }
                if (s[0] >= MAX) return false;
                s[0]++;
                s[1] = now;
            }
            pending = true;
            LyricsDiag.toast("Letra: reintentando (sin letra la primera vez)");
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Se llama al inicio de y9.h (hilo de IO): si hay un reintento pendiente, espera un poco antes de pedir la letra. */
    public static void maybeDelay() {
        try {
            if (!pending) return;
            pending = false;
            Thread.sleep(DELAY_MS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (Throwable ignored) {}
    }
}
