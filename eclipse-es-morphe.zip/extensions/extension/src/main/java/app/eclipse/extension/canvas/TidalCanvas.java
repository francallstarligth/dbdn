package app.eclipse.extension.canvas;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Portada animada de Tidal buscada por TITULO + ARTISTA (sin depender de IDs de la cancion).
 * Usa la busqueda publica del reproductor embebido de Tidal (sin cuenta): el album de la pista
 * trae "videoCover" (UUID) que se convierte en un mp4 fijo del CDN de Tidal.
 * Puerto de TidalCanvas.kt de LastWave-Native (GPL-3.0).
 *
 * Bloqueante (red): solo desde el hilo de fondo de CanvasLookup. Nunca lanza excepciones.
 */
final class TidalCanvas {
    private static final String TAG = "TidalCanvas";
    private static final String SEARCH = "https://api.tidal.com/v1/search";
    private static final String EMBED_TOKEN = "vNVdglQOjFJJGG2U";
    private static final int TIMEOUT_MS = 8000;
    private static final String UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private TidalCanvas() {}

    /**
     * @param reachable [0] se pone en true si Tidal respondio (aunque no haya video); false = fallo de red.
     * @return URL mp4 del video, o null
     */
    static String lookup(String title, String artist, String album, boolean[] reachable) {
        try {
            String country = Locale.getDefault().getCountry();
            if (country == null || country.length() != 2) country = "US";
            country = country.toUpperCase(Locale.ROOT);

            String r = searchIn(title, artist, album, country, reachable);
            if (r == null && !"US".equals(country)) r = searchIn(title, artist, album, "US", reachable);
            return r;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            return null;
        }
    }

    private static String searchIn(String title, String artist, String album, String country, boolean[] reachable) throws Exception {
        // Consulta mas precisa primero (con album), luego solo artista + titulo.
        String[] queries = (album == null || album.trim().isEmpty())
                ? new String[] { artist + " " + title }
                : new String[] { album + " " + artist + " " + title, artist + " " + title };
        for (String q : queries) {
            String url = SEARCH + "?query=" + URLEncoder.encode(q, "UTF-8")
                    + "&limit=10&types=TRACKS&countryCode=" + country;
            String body = httpGet(url);
            if (body == null) continue;
            reachable[0] = true;
            JSONObject tracks = new JSONObject(body).optJSONObject("tracks");
            if (tracks == null) continue;
            JSONArray items = tracks.optJSONArray("items");
            if (items == null) continue;
            for (int i = 0; i < items.length(); i++) {
                JSONObject t = items.optJSONObject(i);
                if (t == null) continue;
                String name = t.optString("title", "");
                List<String> artists = new ArrayList<String>();
                JSONArray arr = t.optJSONArray("artists");
                if (arr != null) {
                    for (int k = 0; k < arr.length(); k++) {
                        JSONObject a = arr.optJSONObject(k);
                        if (a != null) artists.add(a.optString("name", ""));
                    }
                }
                if (!isMatch(name, artists, title, artist)) continue;
                JSONObject alb = t.optJSONObject("album");
                if (alb == null) continue;
                String cover = alb.optString("videoCover", "");
                String u = coverUrl(cover);
                if (u != null) {
                    Log.d(TAG, "videoCover para '" + name + "'");
                    return u;
                }
            }
        }
        return null;
    }

    private static boolean isMatch(String gotName, List<String> gotArtists, String wantName, String wantArtist) {
        String g = CommunityCanvas.norm(gotName);
        String w = CommunityCanvas.norm(wantName);
        if (!g.equals(w)) {
            // "Tema (feat. X)" vs "Tema": se compara tambien sin parentesis/corchetes.
            if (!stripExtras(gotName).equals(stripExtras(wantName)) || stripExtras(wantName).isEmpty()) return false;
        }
        List<String> wanted = splitArtists(wantArtist);
        List<String> credited = new ArrayList<String>();
        for (String a : gotArtists) {
            String n = CommunityCanvas.norm(a);
            if (!n.isEmpty()) credited.add(n);
        }
        if (wanted.isEmpty() || credited.isEmpty()) return false;
        for (String want : wanted) {
            boolean found = false;
            for (String c : credited) {
                if (c.equals(want) || c.contains(want) || want.contains(c)) { found = true; break; }
            }
            if (!found) return false;
        }
        return true;
    }

    private static String stripExtras(String s) {
        if (s == null) return "";
        return CommunityCanvas.norm(s.replaceAll("\\([^)]*\\)|\\[[^\\]]*\\]", " "));
    }

    private static List<String> splitArtists(String raw) {
        List<String> out = new ArrayList<String>();
        if (raw == null) return out;
        String[] parts = raw.split("(?i)(?:\\s*,\\s*|\\s*&\\s*|\\s+×\\s+|\\s+x\\s+|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bfeaturing\\b|\\bwith\\b)");
        for (String p : parts) {
            String n = CommunityCanvas.norm(p);
            if (!n.isEmpty()) out.add(n);
        }
        return out;
    }

    /** UUID de 5 grupos -> mp4 del CDN de Tidal. */
    static String coverUrl(String id) {
        if (id == null) return null;
        String[] parts = id.split("-");
        if (parts.length != 5) return null;
        return "https://resources.tidal.com/videos/" + parts[0] + "/" + parts[1] + "/" + parts[2] + "/"
                + parts[3] + "/" + parts[4] + "/1280x1280.mp4";
    }

    private static String httpGet(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("X-Tidal-Token", EMBED_TOKEN);
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                Log.d(TAG, "GET " + code);
                return null;
            }
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                return new String(out.toByteArray(), Charset.forName("UTF-8"));
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            Log.d(TAG, "GET error: " + t);
            return null;
        }
    }
}
