package app.eclipse.extension.player;

import android.os.Looper;
import android.view.Choreographer;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * v0.20.450 (SIN COMPILAR NI PROBAR). Letras: desplazamiento en OLA.
 *
 * Eclipse 0.6.75 sube toda la lista de letras junta (animateScrollBy con resorte) cuando cambia la linea activa.
 * Aqui, en vez de eso, el scroll es instantaneo y cada fila se dibuja desplazada hacia donde estaba (translationY = distancia)
 * y vuelve a su sitio con un retraso propio: la linea activa sale primero y las que vienen detras la siguen,
 * una tras otra, con {@link #STEP_MS} de diferencia.
 *
 * Piezas (todas en el hilo principal):
 *  - {@link #start}: la llama `Lno5.invokeSuspend` (autoscroll) en lugar del resorte. Registra una "ola" (distancia, linea activa) y devuelve true;
 *    el smali entonces hace el scroll instantaneo (`Lyd8;->D`). Si devuelve false (apagado, error, demasiadas olas) sigue el resorte original.
 *  - {@link #line} (`Lqp5.k`): indice del item de LazyColumn de cada linea (`Len5`). {@link #cur} (inicio de `Lg22.B`): linea de la fila que se compone.
 *    {@link #bind} (justo despues de crear la lambda `Lll`): ata esa lambda de capa grafica a su indice.
 *  - {@link #dy} (final del caso con `Ld0b` + 2 `Lhea` de `Lll.invoke`): devuelve la translationY de la fila (se aplica con `Loq3;->f(F)V`).
 *    Lee un estado de Compose propio (como CodecNear) que un Choreographer cambia en cada fotograma mientras haya olas,
 *    asi la capa se vuelve a ejecutar sola.
 *
 * Varias olas a la vez se SUMAN (cada una agrega su salto al inicio y lo va quitando), asi que si la linea cambia otra vez a media ola no hay saltos.
 */
public final class LyricWave {
    private LyricWave() {}

    /** Retraso entre una fila y la siguiente (ms). */
    private static final float STEP_MS = 35f;
    /** Duracion del movimiento de cada fila (ms). */
    private static final float DUR_MS = 520f;
    /** Maximo de filas distintas que se retrasan (las mas lejanas usan el mismo retraso). */
    private static final int MAX_STEPS = 7;
    /** Olas simultaneas maximas; con mas se deja el resorte original. */
    private static final int MAX_WAVES = 6;
    /** Si una ola nunca llega a dibujarse (pantalla de letras oculta) se descarta a los 2 s. */
    private static final long STALE_NS = 2_000_000_000L;

    private static final class Wave {
        final float dist;
        final int active;
        final long created = System.nanoTime();
        long t0;
        boolean started;
        Wave(float dist, int active) { this.dist = dist; this.active = active; }
        long endNs() { return t0 + (long) ((MAX_STEPS * STEP_MS + DUR_MS) * 1_000_000f); }
    }

    /** Mapa por IDENTIDAD con claves debiles (las lineas Len5 y las lambdas Lll pueden tener equals propio). */
    private static final class IdMap {
        private static final class Ref extends WeakReference<Object> {
            final int hash;
            int v;
            Ref(Object o, int v, ReferenceQueue<Object> q) { super(o, q); this.hash = System.identityHashCode(o); this.v = v; }
        }
        private final HashMap<Integer, ArrayList<Ref>> map = new HashMap<Integer, ArrayList<Ref>>();
        private final ReferenceQueue<Object> q = new ReferenceQueue<Object>();

        synchronized int get(Object o) {
            if (o == null) return -1;
            ArrayList<Ref> l = map.get(System.identityHashCode(o));
            if (l == null) return -1;
            for (int i = 0; i < l.size(); i++) {
                Ref r = l.get(i);
                if (r.get() == o) return r.v;
            }
            return -1;
        }

        synchronized void put(Object o, int v) {
            if (o == null) return;
            purge();
            int h = System.identityHashCode(o);
            ArrayList<Ref> l = map.get(h);
            if (l == null) {
                l = new ArrayList<Ref>(1);
                map.put(h, l);
            }
            for (int i = 0; i < l.size(); i++) {
                Ref r = l.get(i);
                if (r.get() == o) { r.v = v; return; }
            }
            l.add(new Ref(o, v, q));
        }

        private void purge() {
            Object x;
            while ((x = q.poll()) != null) {
                Ref r = (Ref) x;
                ArrayList<Ref> l = map.get(r.hash);
                if (l != null) {
                    l.remove(r);
                    if (l.isEmpty()) map.remove(r.hash);
                }
            }
        }
    }

    private static final IdMap lines = new IdMap(); // Len5 -> indice del item
    private static final IdMap rows = new IdMap();  // Lll  -> indice del item
    private static final ArrayList<Wave> waves = new ArrayList<Wave>();
    private static Object curLine;

    private static boolean broken;
    private static boolean looping;
    private static Object tick;
    private static Method getV, setV;
    private static int n;
    private static Choreographer choreo;

    private static final Choreographer.FrameCallback FRAME = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            try {
                long now = System.nanoTime();
                synchronized (waves) {
                    for (int i = waves.size() - 1; i >= 0; i--) {
                        Wave w = waves.get(i);
                        if (w.started ? now > w.endNs() : now - w.created > STALE_NS) waves.remove(i);
                    }
                }
                // se cambia el estado tambien en el ultimo fotograma, para que las filas queden dibujadas en su sitio final
                if (tick != null) setV.invoke(tick, Integer.valueOf(++n));
                boolean more;
                synchronized (waves) { more = !waves.isEmpty(); }
                if (more) choreo.postFrameCallback(this);
                else looping = false;
            } catch (Throwable e) {
                broken = true;
                looping = false;
                synchronized (waves) { waves.clear(); }
            }
        }
    };

    private static synchronized Object tick() throws Exception {
        if (tick == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class); // mutableStateOf(valor)
            mk.setAccessible(true);
            Object s = mk.invoke(null, Integer.valueOf(0));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            getV = g;
            setV = st;
            tick = s;
        }
        return tick;
    }

    /** Lqp5.k: la linea `line` (Len5) es el item `index` de la lista. */
    public static void line(Object line, int index) {
        try {
            if (broken || line == null) return;
            if (lines.get(line) != index) lines.put(line, index);
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Inicio de Lg22.B: la fila que se compone ahora es de esta linea (Len5). */
    public static void cur(Object line) {
        curLine = line;
    }

    /** Justo despues de crear la lambda de capa grafica `Lll` de la fila: se ata al indice de la linea actual. */
    public static void bind(Object lll) {
        try {
            if (broken || lll == null) return;
            int idx = lines.get(curLine);
            if (idx >= 0) rows.put(lll, idx);
        } catch (Throwable e) {
            broken = true;
        }
    }

    /**
     * Lno5.invokeSuspend: el autoscroll va a mover la lista `dist` px (positivo = el contenido sube) para dejar la linea `active` en su sitio.
     * @return true si la ola se encargo (el smali hace scroll instantaneo); false = usar el resorte original.
     */
    public static boolean start(float dist, int active) {
        try {
            if (broken) return false;
            if (Looper.myLooper() != Looper.getMainLooper()) return false;
            if (Float.isNaN(dist) || Math.abs(dist) < 1f) return false;
            tick();
            if (choreo == null) choreo = Choreographer.getInstance();
            synchronized (waves) {
                if (waves.size() >= MAX_WAVES) return false;
                waves.add(new Wave(dist, active));
            }
            setV.invoke(tick, Integer.valueOf(++n)); // las filas recalculan su capa en el mismo fotograma que el scroll
            if (!looping) {
                looping = true;
                choreo.postFrameCallback(FRAME);
            }
            return true;
        } catch (Throwable e) {
            broken = true;
            return false;
        }
    }

    /**
     * Final del caso `Ld0b + 2 Lhea` de Lll.invoke: translationY (px) de la fila.
     * @param lll la lambda (this)
     */
    public static float dy(Object lll) {
        try {
            if (broken) return 0f;
            Object t = tick();
            getV.invoke(t); // lectura de estado de Compose: la capa se vuelve a ejecutar cuando cambia
            float sum = 0f;
            synchronized (waves) {
                if (waves.isEmpty()) return 0f;
                int idx = rows.get(lll);
                if (idx < 0) return 0f;
                long now = System.nanoTime();
                for (int i = 0; i < waves.size(); i++) {
                    Wave w = waves.get(i);
                    if (!w.started) {
                        w.started = true;
                        w.t0 = now; // arranca en el primer dibujo, cuando el scroll instantaneo ya esta puesto
                    }
                    // Siguen a la linea activa las filas hacia las que viaja el contenido: abajo si sube, arriba si baja.
                    int k = w.dist > 0f ? idx - w.active : w.active - idx;
                    if (k < 0) k = 0;
                    if (k > MAX_STEPS) k = MAX_STEPS;
                    float el = (now - w.t0) / 1_000_000f - k * STEP_MS;
                    float x = el / DUR_MS;
                    if (x >= 1f) continue;
                    float p = 0f;
                    if (x > 0f) {
                        float u = 1f - x;
                        p = 1f - u * u * u * u; // easeOutQuart
                    }
                    sum += w.dist * (1f - p);
                }
            }
            return sum;
        } catch (Throwable e) {
            broken = true;
            return 0f;
        }
    }
}
