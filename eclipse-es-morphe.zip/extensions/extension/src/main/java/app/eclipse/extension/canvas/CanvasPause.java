package app.eclipse.extension.canvas;

/**
 * v0.20.157 (SIN COMPILAR / SIN PROBAR). Pausa los videos del Canvas (portada animada y reflejo) mientras la pestana del
 * reproductor es Letra o Cola, en vez de dejarlos reproduciendo o destruirlos.
 *
 * Todos los Canvas pasan por xi6.h(url, reproduciendo, modifier, composer, int). El parche "Canvas: pausar en Letra y
 * Cola" llama a {@link #play(boolean)} al inicio de xi6.h y usa el resultado como "reproduciendo". xi6.h ya sabe
 * pausar/reanudar su ExoPlayer cuando ese valor cambia (efecto con setPlayWhenReady), asi que al volver a Artwork el video
 * sigue desde donde quedo, sin recargar.
 */
@SuppressWarnings("unused")
public final class CanvasPause {
    private CanvasPause() {}

    /** true en cuanto el gancho de xi6.h corrio al menos una vez (el parche esta aplicado). */
    static volatile boolean enabled;

    /** Gancho de xi6.h: recibe "reproduciendo" y devuelve false si la pestana es Letra/Cola. Cualquier fallo devuelve el original. */
    public static boolean play(boolean playing) {
        enabled = true;
        if (!playing) return false;
        try {
            // notArtwork() lee el estado de la pestana (snapshot state) dentro de la composicion: al cambiar de pestana se redibuja.
            return !BlurredCanvasBackground.notArtwork();
        } catch (Throwable t) {
            return playing;
        }
    }
}
