package app.eclipse.extension.audio;

import android.media.MediaCodecInfo;
import android.media.MediaCodecList;
import android.util.Log;

import androidx.media3.decoder.SimpleDecoderOutputBuffer;
import androidx.media3.decoder.ffmpeg.FfmpegAudioDecoder;
import androidx.media3.decoder.ffmpeg.FfmpegLibrary;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * v0.20.423 (SIN COMPILAR NI PROBAR EN EL CEL). Decodifica Dolby Digital Plus (E-AC-3, el "Dolby Atmos" de Amazon/Apple/Tidal)
 * por software con ffmpeg cuando el cel NO trae decodificador Dolby (ej. Red Magic 10 Pro: DTS en vez de Dolby). Se cuelga de
 * `Lr7;` (el envoltorio del AudioSink que Eclipse ya usa para decodificar AC-4 por software): convierte cada paquete E-AC-3 a
 * PCM y se lo pasa al sink real, igual que hace con AC-4. Sale el 5.1 base (sin los objetos 3D del Atmos).
 *
 * Los nombres ofuscados (0.6.75) que se tocan por reflexion: `Lr7;` (campo `s` = sink `Lrt3;`, metodo `A3(II)Ltg3;`),
 * `Lrt3;` (`E1(Ltg3;)I`, `M1(Ltg3;[I)V`, `r1(IJByteBuffer)Z`) y `Ltg3;` (campo `o` = mime). Si algo falla al cargar, todo
 * queda como antes (supports() da false).
 */
public final class Eac3Soft {
    private static final String TAG = "Eac3Soft";
    private static final int OUT_SIZE = 65536;

    private static boolean libTried, libOk;
    private static Boolean deviceHas;
    private static boolean reflOk;
    private static Field fMime, fSink;
    private static Method mA3, mSinkSupports, mSinkConfigure, mSinkWrite;

    private static boolean active;
    private static boolean lastResult;
    private static FfmpegAudioDecoder dec;
    private static long ctx;
    private static boolean wantFloat;
    private static int sinkChannels = -1;
    private static boolean sinkFloat;
    private static ByteBuffer inDirect;
    private static SimpleDecoderOutputBuffer outBuf;
    private static ByteBuffer pending;
    private static long pendingTime;

    private Eac3Soft() {}

    private static boolean loadLib() {
        if (libTried) return libOk;
        libTried = true;
        try {
            System.loadLibrary("avutil");
            System.loadLibrary("swresample");
            System.loadLibrary("avcodec");
            System.loadLibrary("ffmpegJNI");
            libOk = FfmpegLibrary.ffmpegHasDecoder("eac3");
            Log.i(TAG, "ffmpeg " + FfmpegLibrary.ffmpegGetVersion() + " eac3=" + libOk);
        } catch (Throwable t) {
            Log.w(TAG, "no se pudo cargar ffmpeg", t);
            libOk = false;
        }
        return libOk;
    }

    private static boolean deviceHasEac3() {
        if (deviceHas != null) return deviceHas;
        boolean has = false;
        try {
            for (MediaCodecInfo i : new MediaCodecList(MediaCodecList.REGULAR_CODECS).getCodecInfos()) {
                if (i.isEncoder()) continue;
                for (String t : i.getSupportedTypes()) {
                    if ("audio/eac3".equalsIgnoreCase(t) || "audio/eac3-joc".equalsIgnoreCase(t)) has = true;
                }
            }
        } catch (Throwable ignored) {
            has = true; // ante la duda, no tocar nada
        }
        deviceHas = has;
        return has;
    }

    private static boolean setupRefl(Object lr7, Object format) {
        if (reflOk) return true;
        try {
            Class<?> c = lr7.getClass();
            fSink = c.getDeclaredField("s");
            fSink.setAccessible(true);
            mA3 = c.getDeclaredMethod("A3", int.class, int.class);
            mA3.setAccessible(true);
            Class<?> fmt = format.getClass();
            fMime = fmt.getDeclaredField("o");
            fMime.setAccessible(true);
            Class<?> sk = fSink.getType();
            mSinkSupports = sk.getDeclaredMethod("E1", fmt);
            mSinkSupports.setAccessible(true);
            mSinkConfigure = sk.getDeclaredMethod("M1", fmt, int[].class);
            mSinkConfigure.setAccessible(true);
            mSinkWrite = sk.getDeclaredMethod("r1", int.class, long.class, ByteBuffer.class);
            mSinkWrite.setAccessible(true);
            reflOk = true;
        } catch (Throwable t) {
            Log.w(TAG, "reflexion fallo", t);
            reflOk = false;
        }
        return reflOk;
    }

    /** Lr7.B3(format): true si este formato lo decodificamos nosotros. */
    public static boolean supports(Object format) {
        try {
            if (format == null) return false;
            if (!reflOk) {
                // el mime esta en el campo `o` de Ltg3; no hace falta el resto para esta pregunta
                Field f = format.getClass().getDeclaredField("o");
                f.setAccessible(true);
                fMime = f;
            }
            String mime = (String) fMime.get(format);
            if (!"audio/eac3".equals(mime) && !"audio/eac3-joc".equals(mime)) return false;
            if (deviceHasEac3()) return false;
            return loadLib();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Lr7.M1(format, ...): arranca el decodificador. true = ya lo manejamos (Lr7 no hace nada mas). */
    public static boolean configure(Object lr7, Object format) {
        try {
            release();
            if (!supports(format) || !setupRefl(lr7, format)) {
                active = false;
                return false;
            }
            dec = new FfmpegAudioDecoder();
            wantFloat = true;
            ctx = dec.ffmpegInitialize("eac3", null, true, 48000, 6);
            if (ctx == 0) {
                Log.w(TAG, "ffmpegInitialize dio 0");
                dec = null;
                active = false;
                return false;
            }
            if (inDirect == null) {
                int pad = Math.max(FfmpegLibrary.ffmpegGetInputBufferPaddingSize(), 64);
                inDirect = ByteBuffer.allocateDirect(65536 + pad).order(ByteOrder.nativeOrder());
            }
            outBuf = new SimpleDecoderOutputBuffer();
            sinkChannels = -1;
            pending = null;
            active = true;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "configure fallo", t);
            active = false;
            return false;
        }
    }

    /** Lr7.r1(...): true = lo manejamos y el resultado esta en result(). */
    public static boolean handle(Object lr7, int count, long timeUs, ByteBuffer in) {
        if (!active || dec == null) return false;
        try {
            Object sink = fSink.get(lr7);
            if (pending == null) {
                int size = in.remaining();
                if (size <= 0) {
                    lastResult = true;
                    return true;
                }
                int pad = Math.max(FfmpegLibrary.ffmpegGetInputBufferPaddingSize(), 64);
                if (inDirect.capacity() < size + pad) {
                    inDirect = ByteBuffer.allocateDirect(size + pad).order(ByteOrder.nativeOrder());
                }
                inDirect.clear();
                int p = in.position();
                inDirect.put(in.duplicate());
                for (int i = 0; i < pad; i++) inDirect.put((byte) 0);
                inDirect.position(0);
                inDirect.limit(size);
                ByteBuffer outData = outBuf.init(OUT_SIZE);
                int res = dec.ffmpegDecode(ctx, inDirect, size, outBuf, outData, OUT_SIZE);
                in.position(in.limit()); // el paquete se consume siempre
                if (res < 0) {
                    Log.w(TAG, "paquete malo (" + res + "), se salta");
                    lastResult = true;
                    return true;
                }
                if (res == 0) {
                    lastResult = true;
                    return true;
                }
                int ch = dec.ffmpegGetChannelCount(ctx);
                if (ch <= 0) {
                    lastResult = true;
                    return true;
                }
                ByteBuffer pcm = outBuf.data;
                pcm.position(0);
                pcm.limit(res);
                if (ch != sinkChannels) {
                    configureSink(lr7, sink, ch);
                }
                pending = sinkFloat ? pcm : toShort(pcm);
                pendingTime = timeUs;
            }
            boolean done = (Boolean) mSinkWrite.invoke(sink, 1, pendingTime, pending);
            if (done) pending = null;
            lastResult = done;
            return true;
        } catch (InvocationTargetException e) {
            Throwable c = e.getCause();
            if (c instanceof RuntimeException) throw (RuntimeException) c;
            if (c instanceof Error) throw (Error) c;
            throw new RuntimeException(c);
        } catch (RuntimeException e) {
            throw e;
        } catch (Throwable t) {
            throw new RuntimeException(t);
        }
    }

    public static boolean result() {
        return lastResult;
    }

    private static void configureSink(Object lr7, Object sink, int ch) throws Exception {
        Object fmt = mA3.invoke(lr7, ch, 4); // 4 = PCM float
        int s = (Integer) mSinkSupports.invoke(sink, fmt);
        sinkFloat = s != 0;
        if (!sinkFloat) fmt = mA3.invoke(lr7, ch, 2); // 2 = PCM 16 bits
        mSinkConfigure.invoke(sink, fmt, null);
        sinkChannels = ch;
    }

    private static ByteBuffer toShort(ByteBuffer f) {
        ByteBuffer o = ByteBuffer.allocateDirect(f.remaining() / 2).order(ByteOrder.nativeOrder());
        while (f.remaining() >= 4) {
            int v = Math.round(f.getFloat() * 32768f);
            if (v > 32767) v = 32767;
            if (v < -32768) v = -32768;
            o.putShort((short) v);
        }
        o.flip();
        return o;
    }

    /** Lr7.flush(): despues de un seek. */
    public static void flush() {
        pending = null;
        if (dec != null && ctx != 0) {
            try {
                long n = dec.ffmpegReset(ctx, null);
                if (n != 0) ctx = n;
            } catch (Throwable ignored) {
            }
        }
    }

    /** Lr7.reset() y Lr7.a(): se libera todo. */
    public static void release() {
        pending = null;
        if (dec != null && ctx != 0) {
            try {
                dec.ffmpegRelease(ctx);
            } catch (Throwable ignored) {
            }
        }
        dec = null;
        ctx = 0;
        active = false;
    }
}
