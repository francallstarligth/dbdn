package app.eclipse.extension.player;

import android.os.SystemClock;

/**
 * v0.20.63 (SIN COMPILAR / SIN PROBAR). Al cambiar de pestana del reproductor (Artwork / Letra / Cola), Eclipse (qw0.d)
 * cambia la pestana de una vez, pero el avance de la animacion (qw0.d:Ljr) queda en 1.0 hasta que arranca una corrutina
 * que lo pone en 0 y lo anima. En ese hueco la pantalla nueva se dibuja completa (peso 1), luego se borra y entra con fundido.
 * Ganchos (TabSwitchPatch): {@link #pending} al lanzar la corrutina en qw0.d, {@link #snapped} cuando la corrutina ya puso
 * el avance en 0, y {@link #prog} sobre el avance leido en qw0.e. Mientras esta pendiente, el avance se lee como 0.
 * Tope de 150 ms: si la corrutina nunca llega, se vuelve al valor real (no se queda en blanco).
 */
public final class TabSwitch {
    private static final long MAX_MS = 150;
    private static volatile long pendingAt;

    private TabSwitch() {}

    public static void pending() {
        try {
            pendingAt = SystemClock.uptimeMillis();
        } catch (Throwable t) {
            pendingAt = 0;
        }
    }

    public static void snapped() {
        pendingAt = 0;
    }

    public static float prog(float p) {
        try {
            long t = pendingAt;
            if (t == 0) return p;
            if (SystemClock.uptimeMillis() - t < MAX_MS) return 0f;
            pendingAt = 0;
        } catch (Throwable ignored) {
            pendingAt = 0;
        }
        return p;
    }
}
