package app.eclipse.extension.umbra;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * v0.20.391 (PRUEBA): agrega un campo "albums" a las reglas de la Smart Playlist (`intent/rules`) para ver si el servidor lo entiende.
 * Solo actua si las reglas tienen como artista a "The Weeknd" (para no tocar otras playlists). Si algo falla no hace nada.
 */
public final class UmbraAlbums {
    private static final String TAG = "UmbraAlbums";

    private UmbraAlbums() {}

    /** Se llama al inicio de Lcc4.k(Context, JSONObject reglas, ...) con el JSON de reglas. */
    public static void agregar(Object o) {
        try {
            if (!(o instanceof JSONObject)) return;
            JSONObject reglas = (JSONObject) o;
            JSONArray artistas = reglas.optJSONArray("artists");
            if (artistas == null) return;
            boolean weeknd = false;
            for (int i = 0; i < artistas.length(); i++) {
                String a = artistas.optString(i, "");
                if (a.equalsIgnoreCase("The Weeknd")) { weeknd = true; break; }
            }
            if (!weeknd) return;
            JSONArray albums = new JSONArray();
            albums.put("Starboy");
            albums.put("Dawn FM");
            reglas.put("albums", albums);
        } catch (Throwable t) {
            Log.w(TAG, "agregar", t);
        }
    }
}
