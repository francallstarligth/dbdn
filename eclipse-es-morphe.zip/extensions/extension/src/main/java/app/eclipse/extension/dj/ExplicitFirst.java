package app.eclipse.extension.dj;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * v0.20.436 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Al buscar la pista de Tidal / del addon que corresponde a una `Song`
 * (`Lgza;->b` addons y `Lgza;->c` Tidal), la app se queda con el PRIMER resultado que encaja (titulo, artista, album, duracion) y no mira
 * si es explicito. Las canciones del DJ llegan sin marca de explicita (`isExplicit` = null), asi que si la version limpia sale primero
 * en los resultados, suena esa. `sort()` pone las versiones EXPLICITAS primero (orden estable) antes de elegir.
 * No cambia nada si la cancion esta marcada como NO explicita o si su titulo dice "clean".
 */
public final class ExplicitFirst {
    private static final Pattern CLEAN = Pattern.compile("(?i)\\bclean\\b");

    private ExplicitFirst() {}

    /** song = `Song`; list = candidatos (TidalTrack o EclipseAddonTrack). Devuelve la lista con las explicitas primero. */
    public static List<?> sort(Object song, List<?> list) {
        try {
            if (list == null || list.size() < 2) return list;
            if (song != null) {
                Object ex = call(song, "isExplicit");
                if (Boolean.FALSE.equals(ex)) return list;
                Object title = call(song, "getTitle");
                if (title instanceof CharSequence && CLEAN.matcher((CharSequence) title).find()) return list;
            }
            List<Object> yes = new ArrayList<>();
            List<Object> no = new ArrayList<>();
            for (Object it : list) {
                if (isExplicit(it)) yes.add(it);
                else no.add(it);
            }
            if (yes.isEmpty() || no.isEmpty()) return list;
            yes.addAll(no);
            return yes;
        } catch (Throwable t) {
            return list;
        }
    }

    private static boolean isExplicit(Object o) {
        if (o == null) return false;
        String[] getters = {"getExplicit", "isExplicit", "getIsExplicit"};
        for (String g : getters) {
            Object v = call(o, g);
            if (v instanceof Boolean) return (Boolean) v;
        }
        String[] fields = {"explicit", "isExplicit"};
        for (String f : fields) {
            try {
                Field fl = o.getClass().getDeclaredField(f);
                fl.setAccessible(true);
                Object v = fl.get(o);
                if (v instanceof Boolean) return (Boolean) v;
            } catch (Throwable ignored) {}
        }
        return false;
    }

    private static Object call(Object o, String name) {
        try {
            Method m = o.getClass().getMethod(name);
            return m.invoke(o);
        } catch (Throwable t) {
            return null;
        }
    }
}
