package app.eclipse.extension.player;

import android.content.ContentProvider;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * v0.20.87 (SIN COMPILAR / SIN PROBAR). Prueba: muestra un aviso corto al abrir Eclipse para saber si los parches
 * de esta version estan en la app instalada. Se llama desde TelemetryInitializer.onCreate (ContentProvider que
 * Android crea al arrancar la app). No toca letras ni nada mas; todo va en try/catch.
 */
public final class ProbePing {
    private static final String TAG = "EclipseES";
    private static final String VERSION = "0.20.88";

    private static volatile Context saved;

    private ProbePing() { }

    /** Contexto guardado al abrir Eclipse (null si aun no corrio hi). */
    public static Context ctx() { return saved; }

    public static void hi(ContentProvider p) {
        try {
            final Context ctx = p.getContext();
            if (ctx == null) return;
            saved = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
            try { Log.i(TAG, "Parches Eclipse ES " + VERSION + " activos"); } catch (Throwable ignored) { }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        Toast.makeText(ctx, "Parches Eclipse ES " + VERSION + " activos", Toast.LENGTH_LONG).show();
                    } catch (Throwable ignored) { }
                }
            }, 3000);
        } catch (Throwable ignored) { }
    }
}
