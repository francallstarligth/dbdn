package app.eclipse.extension.player;

import android.content.ContentProvider;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * v0.20.87 (SIN COMPILAR / SIN PROBAR). Prueba: muestra un aviso corto al abrir Eclipse para saber si los parches
 * de esta version estan en la app instalada. Se llama desde TelemetryInitializer.onCreate (ContentProvider que
 * Android crea al arrancar la app). No toca letras ni nada mas; todo va en try/catch.
 */
public final class ProbePing {
    private static final String TAG = "EclipseES";
    private static final String VERSION = "0.20.89";

    private static volatile Context saved;

    private ProbePing() { }

    /** v0.20.89: marca 1 = entro a y9.h (cualquier pedido de letra). */
    public static void m1() { say("Letra 1: pedido de letra"); }

    /** v0.20.89: marca 2 = proveedor elegido (v1 de y9.h). */
    public static void mark(Object o) { say("Letra 2: proveedor " + o); }

    private static void say(final String text) {
        try {
            final Context c = saved;
            if (c == null) return;
            try { Log.i(TAG, text); } catch (Throwable ignored) { }
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(c, text, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable ignored) { }
    }

    /** Contexto guardado al abrir Eclipse (null si aun no corrio hi). */
    public static Context ctx() { return saved; }

    public static void hi(ContentProvider p) {
        try {
            final Context ctx = p.getContext();
            if (ctx == null) return;
            saved = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
            try { Log.i(TAG, "Parches Eclipse ES " + VERSION + " activos"); } catch (Throwable ignored) { }
            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        Toast.makeText(ctx, "Parches Eclipse ES " + VERSION + " activos", Toast.LENGTH_LONG).show();
                    } catch (Throwable ignored) { }
                }
            }, 3000);
        } catch (Throwable ignored) { }
    }
}
