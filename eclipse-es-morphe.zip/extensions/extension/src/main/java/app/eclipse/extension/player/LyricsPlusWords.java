package app.eclipse.extension.player;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * v0.20.80 (SIN COMPILAR / SIN PROBAR en el telefono). Lo usa el parche "Letras: YouLyPlus por palabra".
 *
 * Eclipse (ov4.e) solo lee "syncedLyrics" y "plainLyrics" de la respuesta de YouLyPlus. Mochy Music (YouLyPlus.kt)
 * ademas lee el campo "lyrics": una lista de lineas {text, time, duration, syllabus:[{text,time,duration,isBackground}],
 * element:{singer}} con tiempos en milisegundos. Aqui se agrupan las silabas en PALABRAS y se arma un JSONArray en el
 * formato que Eclipse ya entiende (el de ov4.l): [{t, e, text, words:[{t,e,text}], voice}] con tiempos en SEGUNDOS.
 * El smali llama a ov4.l con ese arreglo y arma el resultado como lo hace Eclipse con las otras fuentes.
 *
 * convert() devuelve null (= no tocar nada, Eclipse sigue como siempre) si: hay "syncedLyrics" con texto, no hay
 * "lyrics", o algo falla. Java puro + org.json.
 */
public final class LyricsPlusWords {
    private LyricsPlusWords() {}

    private static final class Word {
        String text;
        double start;
        double end;
    }

    private static final class Syl {
        String text;
        double start;
        double end;
        boolean bg;
    }

    private static final class Entry {
        double t;
        JSONObject obj;
    }

    /** Devuelve las lineas en el formato de ov4.l, o null si no hay que tocar nada. */
    public static JSONArray convert(JSONObject resp) {
        try {
            if (resp == null) return null;
            if (hasText(resp.opt("syncedLyrics"))) return null;
            JSONArray src = resp.optJSONArray("lyrics");
            if (src == null || src.length() == 0) return null;

            List<Entry> out = new ArrayList<Entry>();
            for (int i = 0; i < src.length(); i++) {
                JSONObject it = src.optJSONObject(i);
                if (it == null) continue;
                addLine(it, out);
            }
            if (out.isEmpty()) return null;
            Collections.sort(out, new Comparator<Entry>() {
                @Override public int compare(Entry a, Entry b) { return Double.compare(a.t, b.t); }
            });
            JSONArray arr = new JSONArray();
            for (Entry e : out) arr.put(e.obj);
            return arr;
        } catch (Throwable t) {
            return null;
        }
    }

    /** true si el valor es un texto con algo escrito (el JSON null de Android sale como el texto "null"). */
    private static boolean hasText(Object o) {
        if (!(o instanceof String)) return false;
        String s = ((String) o).trim();
        return !s.isEmpty() && !"null".equals(s);
    }

    private static void addLine(JSONObject it, List<Entry> out) throws Exception {
        double lineStart = it.optDouble("time", Double.NaN);
        double lineDur = it.optDouble("duration", Double.NaN);
        String voice = voiceOf(it);

        JSONArray sy = it.optJSONArray("syllabus");
        List<Syl> main = new ArrayList<Syl>();
        List<Syl> bg = new ArrayList<Syl>();
        if (sy != null) {
            List<Syl> all = new ArrayList<Syl>();
            for (int i = 0; i < sy.length(); i++) {
                JSONObject s = sy.optJSONObject(i);
                if (s == null) continue;
                String text = s.optString("text", "");
                if ("null".equals(text)) text = "";
                double st = s.optDouble("time", Double.NaN);
                if (Double.isNaN(st)) continue;
                double du = s.optDouble("duration", Double.NaN);
                Syl y = new Syl();
                y.text = text;
                y.start = st / 1000.0;
                y.end = Double.isNaN(du) || du <= 0 ? Double.NaN : (st + du) / 1000.0;
                y.bg = s.optBoolean("isBackground", false);
                all.add(y);
            }
            // si no trae duracion, la silaba termina cuando empieza la siguiente de su grupo
            for (Syl y : all) (y.bg ? bg : main).add(y);
            fillEnds(main);
            fillEnds(bg);
        }

        if (main.isEmpty() && bg.isEmpty()) {
            // linea sin silabas: solo el texto con el tiempo de la linea (como una linea LRC)
            if (Double.isNaN(lineStart)) return;
            String text = it.optString("text", "");
            if ("null".equals(text)) text = "";
            JSONObject o = new JSONObject();
            o.put("t", lineStart / 1000.0);
            if (!Double.isNaN(lineDur) && lineDur > 0) o.put("e", (lineStart + lineDur) / 1000.0);
            o.put("text", text.trim());
            if (voice.length() > 0) o.put("voice", voice);
            Entry e = new Entry();
            e.t = lineStart / 1000.0;
            e.obj = o;
            out.add(e);
            return;
        }

        if (!main.isEmpty()) {
            Entry e = lineFrom(main, voice, lineStart, lineDur, bg.isEmpty());
            if (e != null) out.add(e);
        }
        if (!bg.isEmpty()) {
            Entry e = lineFrom(bg, "bg", lineStart, lineDur, false);
            if (e != null) out.add(e);
        }
    }

    private static void fillEnds(List<Syl> list) {
        for (int i = 0; i < list.size(); i++) {
            Syl y = list.get(i);
            if (!Double.isNaN(y.end) && y.end > y.start) continue;
            if (i + 1 < list.size() && list.get(i + 1).start > y.start) y.end = list.get(i + 1).start;
            else y.end = y.start + 0.3;
        }
    }

    private static Entry lineFrom(List<Syl> syl, String voice, double lineStart, double lineDur,
                                  boolean useLineBounds) throws Exception {
        List<Word> words = group(syl);
        if (words.isEmpty()) return null;
        double t = words.get(0).start;
        double e = words.get(words.size() - 1).end;
        if (useLineBounds) {
            if (!Double.isNaN(lineStart) && lineStart / 1000.0 <= t) t = lineStart / 1000.0;
            if (!Double.isNaN(lineStart) && !Double.isNaN(lineDur) && lineDur > 0) {
                double le = (lineStart + lineDur) / 1000.0;
                if (le > e) e = le;
            }
        }
        StringBuilder text = new StringBuilder();
        JSONArray wa = new JSONArray();
        for (Word w : words) {
            if (text.length() > 0) text.append(' ');
            text.append(w.text);
            JSONObject wo = new JSONObject();
            wo.put("t", w.start);
            wo.put("e", w.end);
            wo.put("text", w.text);
            wa.put(wo);
        }
        JSONObject o = new JSONObject();
        o.put("t", t);
        o.put("e", e);
        o.put("text", text.toString());
        o.put("words", wa);
        if (voice != null && voice.length() > 0) o.put("voice", voice);
        Entry en = new Entry();
        en.t = t;
        en.obj = o;
        return en;
    }

    /** Une silabas en palabras. Los limites de palabra vienen de los espacios del propio texto (como en Mochy). */
    private static List<Word> group(List<Syl> syl) {
        List<Word> words = new ArrayList<Word>();
        boolean spaced = false;
        for (int i = 0; i < syl.size(); i++) {
            String s = syl.get(i).text;
            if (s.length() == 0) continue;
            boolean lead = Character.isWhitespace(s.charAt(0)) && i > 0;
            boolean trail = Character.isWhitespace(s.charAt(s.length() - 1)) && i < syl.size() - 1;
            if (lead || trail) { spaced = true; break; }
        }
        if (!spaced) {
            // sin espacios en toda la linea: cada trozo ya es una palabra (como hace Mochy)
            for (Syl y : syl) addWord(words, y.text.trim(), y.start, y.end);
            return words;
        }
        StringBuilder buf = new StringBuilder();
        double ws = 0, we = 0;
        boolean open = false;
        for (Syl y : syl) {
            String s = y.text;
            if (s.length() == 0) continue;
            if (Character.isWhitespace(s.charAt(0)) && open) {
                addWord(words, buf.toString(), ws, we);
                buf.setLength(0);
                open = false;
            }
            String core = s.trim();
            if (core.length() > 0) {
                int sp = indexOfWhitespace(core);
                if (sp < 0) {
                    if (!open) { ws = y.start; open = true; }
                    buf.append(core);
                    we = y.end;
                } else {
                    // un trozo con varias palabras: se reparte el tiempo segun el largo de cada una
                    String[] parts = core.split("\\s+");
                    int total = 0;
                    for (String p : parts) total += p.length();
                    double cur = y.start, span = y.end - y.start;
                    for (int k = 0; k < parts.length; k++) {
                        double d = total == 0 ? 0 : span * parts[k].length() / total;
                        if (k == 0 && open) {
                            buf.append(parts[k]);
                            addWord(words, buf.toString(), ws, cur + d);
                            buf.setLength(0);
                            open = false;
                        } else if (k == parts.length - 1) {
                            ws = cur;
                            we = y.end;
                            buf.setLength(0);
                            buf.append(parts[k]);
                            open = true;
                        } else {
                            addWord(words, parts[k], cur, cur + d);
                        }
                        cur += d;
                    }
                }
            }
            if (Character.isWhitespace(s.charAt(s.length() - 1)) && open) {
                addWord(words, buf.toString(), ws, we);
                buf.setLength(0);
                open = false;
            }
        }
        if (open) addWord(words, buf.toString(), ws, we);
        return words;
    }

    private static int indexOfWhitespace(String s) {
        for (int i = 0; i < s.length(); i++) if (Character.isWhitespace(s.charAt(i))) return i;
        return -1;
    }

    private static void addWord(List<Word> words, String text, double start, double end) {
        if (text == null || text.length() == 0) return;
        Word w = new Word();
        w.text = text;
        w.start = start;
        w.end = end > start ? end : start + 0.05;
        words.add(w);
    }

    /** "v2", "v3"... (segunda voz en adelante) -> "v2"; la primera voz o sin dato -> "" (voz normal). */
    private static String voiceOf(JSONObject it) {
        JSONObject el = it.optJSONObject("element");
        if (el == null) return "";
        String s = el.optString("singer", "");
        if (s == null) return "";
        s = s.trim().toLowerCase();
        if (s.length() < 2 || s.charAt(0) != 'v') return "";
        try {
            int n = Integer.parseInt(s.substring(1));
            return n >= 2 ? "v2" : "";
        } catch (NumberFormatException ex) {
            return "";
        }
    }
}
