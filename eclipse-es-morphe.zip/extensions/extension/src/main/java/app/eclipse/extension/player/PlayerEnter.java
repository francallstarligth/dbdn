package app.eclipse.extension.player;

import android.content.res.Resources;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * EXPERIMENTO (v1.97.6): animacion de ENTRADA del reproductor grande. dr8.a (la hoja) coloca su contenido con
 * offset { y = max(0, jr.valor) } y jr arranca en 0, por eso aparece de golpe. Cuando dr8.a se compone con un jr NUEVO
 * (= la hoja acaba de aparecer), se escribe el estado interno del jr (jr.c -> ps.r -> c56.setValue) con el alto de la
 * pantalla y se baja a 0 cuadro a cuadro (Choreographer, ~320 ms, frenado suave). Todo con reflexion y try/catch: si algo
 * no coincide, no hace nada. No toca la salida.
 */
public final class PlayerEnter {
    private static final String TAG = "PlayerEnter";
    private static final long DURACION_NS = 320_000_000L;

    private static WeakReference<Object> ultimoJr;
    private static Object estado;      // c56 (MutableState<Float>)
    private static Method setValue;
    private static float alto;
    private static long inicioNs;
    private static int generacion;

    private PlayerEnter() {}

    /** v0.20.18: hora (uptimeMillis) en que el usuario pidio abrir el reproductor (bl6.e). */
    private static volatile long abrirMs;
    private static final long VENTANA_MS = 1500L;

    /** Lo llama bl6.e() (abrir el reproductor). */
    public static void abrir() { abrirMs = SystemClock.uptimeMillis(); }

    /** Se llama en cada composicion de dr8.a justo despues de leer jr.d(). Anima siempre (version anterior). */
    public static void hook(Object jr) { hook(jr, false); }

    /** v0.20.18: solo anima si el usuario acaba de abrir el reproductor; si la hoja se recrea sola (cambio de cancion), no. */
    public static void hookGated(Object jr) { hook(jr, true); }

    private static void hook(Object jr, boolean gated) {
        try {
            if (jr == null) return;
            Object prev = ultimoJr == null ? null : ultimoJr.get();
            if (prev == jr) return; // misma hoja: no reiniciar
            ultimoJr = new WeakReference<Object>(jr);
            if (gated) {
                long t = abrirMs;
                if (t == 0 || SystemClock.uptimeMillis() - t > VENTANA_MS) return; // hoja recreada: sin animacion
                abrirMs = 0; // una sola animacion por pedido de abrir
            }

            Field fc = jr.getClass().getDeclaredField("c");
            fc.setAccessible(true);
            Object ps = fc.get(jr);
            Field fr = ps.getClass().getDeclaredField("r");
            fr.setAccessible(true);
            Object st = fr.get(ps);
            Method m = st.getClass().getMethod("setValue", Object.class);

            estado = st;
            setValue = m;
            alto = Resources.getSystem().getDisplayMetrics().heightPixels;
            inicioNs = 0;
            final int gen = ++generacion;

            // Valor inicial ya (en la misma composicion): la hoja arranca fuera de pantalla, sin cuadro suelto en 0.
            m.invoke(st, Float.valueOf(alto));

            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
                @Override public void doFrame(long frameTimeNanos) {
                    paso(frameTimeNanos, gen, this);
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "hook fallo", t);
        }
    }

    private static void paso(long ahoraNs, int gen, Choreographer.FrameCallback cb) {
        try {
            if (gen != generacion || estado == null) return; // llego otra hoja: se cancela esta
            if (inicioNs == 0) inicioNs = ahoraNs;
            float t = (ahoraNs - inicioNs) / (float) DURACION_NS;
            if (t >= 1f) {
                setValue.invoke(estado, Float.valueOf(0f));
                return;
            }
            float u = 1f - t;
            float e = 1f - u * u * u; // frenado suave (ease-out cubico)
            setValue.invoke(estado, Float.valueOf(alto * (1f - e)));
            Choreographer.getInstance().postFrameCallback(cb);
        } catch (Throwable th) {
            Log.w(TAG, "paso fallo", th);
        }
    }
}
