package app.eclipse.extension.tidal;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Recuerda "ISRC de la cancion -> ID de album de Tidal".
 *
 * Eclipse averigua el album de Tidal de una cancion agregada a la biblioteca a traves de su ISRC,
 * pero lo guarda solo con el ID de pista que acaba de averiguar; despues, al mostrar la portada,
 * busca con el ID que trae la propia cancion (que en las agregadas no existe) y no lo encuentra.
 * Este mapa une ambos extremos. Nunca lanza excepciones.
 */
@SuppressWarnings("unused")
public final class IsrcAlbum {
    private static final ConcurrentHashMap<String, Integer> MAP = new ConcurrentHashMap<String, Integer>();

    private IsrcAlbum() {}

    public static void put(String isrc, Object albumId) {
        try {
            if (isrc == null || isrc.isEmpty() || !(albumId instanceof Integer)) return;
            if (MAP.size() > 2000) MAP.clear();
            MAP.put(isrc, (Integer) albumId);
        } catch (Throwable ignored) {}
    }

    public static Integer get(String isrc) {
        try {
            if (isrc == null || isrc.isEmpty()) return null;
            return MAP.get(isrc);
        } catch (Throwable t) {
            return null;
        }
    }
}
