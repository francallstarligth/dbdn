package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * v0.20.363 (SIN COMPILAR NI PROBAR). Pop del mini reproductor al tocar siguiente/anterior con el BOTON.
 * El deslizar ya hace el pop (Lis9 lanza Ljs9: la escala baja a 0.9 en 80 ms y vuelve a 1.0 con el movimiento del skin).
 * Aqui se guardan (por Lis9.<init>) el scope, el Animatable (Lqt) y el movimiento (Lrs9) del mini reproductor, y cuando una
 * capa del skin ejecuta "next"/"previous" (Les9.a, modo 1 -> Lzr9.b) se lanza el mismo Ljs9 (modo 1) con Lkxb.I(scope, null, null, js9, 3).
 * Todo por reflexion y en try/catch: si algo no cuadra, no hace nada.
 */
public final class MiniPop {
    private static final String TAG = "MiniPop";
    private static volatile Object scope;
    private static volatile Object anim;
    private static volatile Object motion;
    private static volatile long last;
    private static Constructor<?> ctor;
    private static Method launch;

    private MiniPop() {}

    public static void register(Object s, Object a, Object m) {
        scope = s;
        anim = a;
        motion = m;
    }

    public static void onAction(String action) {
        try {
            if (!"next".equals(action) && !"previous".equals(action)) return;
            Object s = scope, a = anim, m = motion;
            if (s == null || a == null || m == null) return;
            long now = SystemClock.uptimeMillis();
            if (now - last < 150) return;
            last = now;
            if (ctor == null) {
                Class<?> k = Class.forName("js9");
                for (Constructor<?> c : k.getDeclaredConstructors()) {
                    Class<?>[] p = c.getParameterTypes();
                    if (p.length == 4 && p[3] == int.class && p[0].getName().equals("qt") && p[1].getName().equals("rs9")) {
                        c.setAccessible(true);
                        ctor = c;
                        break;
                    }
                }
            }
            if (launch == null) {
                Class<?> kx = Class.forName("kxb");
                for (Method mm : kx.getDeclaredMethods()) {
                    Class<?>[] p = mm.getParameterTypes();
                    if (mm.getName().equals("I") && Modifier.isStatic(mm.getModifiers()) && p.length == 5
                            && p[4] == int.class && p[3].getName().equals("tk3") && p[0].getName().equals("o12")) {
                        mm.setAccessible(true);
                        launch = mm;
                        break;
                    }
                }
            }
            if (ctor == null || launch == null) return;
            Object job = ctor.newInstance(a, m, null, 1);
            launch.invoke(null, s, null, null, job, 3);
        } catch (Throwable t) {
            Log.w(TAG, "onAction", t);
        }
    }
}
