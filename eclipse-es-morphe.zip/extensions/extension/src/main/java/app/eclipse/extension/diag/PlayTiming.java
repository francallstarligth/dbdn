package app.eclipse.extension.diag;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * v0.20.441 (SIN COMPILAR NI PROBAR): prueba de tiempos al tocar una cancion. `mark()` se llama al inicio de `Ljh0;->W` (la cadena que
 * resuelve la cancion con el addon: [CHAIN] identidad / ISRC / busqueda por nombre). La primera llamada abre una sesion (otras en los
 * siguientes 20 s se ignoran); 12 s despues lee el logcat de la propia app (`logcat -d`, solo trae lo de este proceso), se queda con las
 * lineas de audio/addon/red desde 1,5 s antes del inicio y las copia al portapapeles con un Toast. Cada linea trae su hora (ms), asi se ve cuanto
 * tarda cada paso. No cambia nada del audio.
 */
public final class PlayTiming {
    private static final Object LOCK = new Object();
    private static long start = 0;

    private PlayTiming() {}

    public static void mark() {
        try {
            final long now = System.currentTimeMillis();
            synchronized (LOCK) {
                if (start != 0 && now - start < 20000) return;
                start = now;
            }
            Thread th = new Thread(new Runnable() {
                @Override public void run() { collect(now); }
            }, "PlayTiming");
            th.setDaemon(true);
            th.start();
        } catch (Throwable ignored) {
        }
    }

    private static boolean wanted(String line) {
        String l = line.toLowerCase(Locale.ROOT);
        return l.contains("audioplayer") || l.contains("tidal") || l.contains("tido") || l.contains("addon")
            || l.contains("okhttp") || l.contains("exoplayer") || l.contains("eac3") || l.contains("chain")
            || l.contains("resolve") || l.contains("stream") || l.contains("playback") || l.contains("manifest");
    }

    private static void collect(long t0) {
        try {
            Thread.sleep(12000);
            SimpleDateFormat f = new SimpleDateFormat("MM-dd HH:mm:ss.SSS", Locale.US);
            String desde = f.format(new Date(t0 - 1500));
            List<String> keep = new ArrayList<String>();
            Process p = Runtime.getRuntime().exec(new String[] {"logcat", "-d", "-v", "threadtime", "-t", "3000"});
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                if (line.length() < 20) continue;
                if (line.substring(0, 18).compareTo(desde) < 0) continue;
                if (!wanted(line)) continue;
                keep.add(line.length() > 260 ? line.substring(0, 260) : line);
            }
            try { r.close(); } catch (Throwable ignored) {}
            StringBuilder sb = new StringBuilder();
            sb.append("PlayTiming v0.20.441 | primer paso de la cadena (Ljh0.W): ").append(f.format(new Date(t0))).append('\n');
            sb.append("lineas: ").append(keep.size()).append('\n');
            int from = Math.max(0, keep.size() - 250);
            for (int i = from; i < keep.size(); i++) sb.append(keep.get(i)).append('\n');
            final String text = sb.toString();
            final int n = keep.size();
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("PlayTiming", text));
                        Toast.makeText(ctx, "Tiempos copiados (" + n + " lineas)", Toast.LENGTH_LONG).show();
                    } catch (Throwable ignored) {
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }
}
