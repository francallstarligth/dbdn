package app.eclipse.extension.automix;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Planificador local de Automix para Eclipse 0.6.47 (reemplaza al plan del servidor api.eclipsemusic.app).
 *
 * Entra con los dos ISRC (ya normalizados por Eclipse) y el fundido pedido (segundos) y devuelve el JSON
 * que entiende wx6.G (el mismo formato que mandaba el servidor): status "ready" + plan. El motor nativo de
 * Eclipse ejecuta lo que aqui se decide (fundido, barrido de filtro, bass swap).
 *
 * Los datos de tempo salen de fuentes de BPM intercambiables ({@link BpmSource}). Hoy: Deezer por ISRC.
 * Para anadir otra fuente: implementar BpmSource y agregarla en {@link #SOURCES}; se prueban en orden.
 * Sin BPM de alguna cancion se usan valores fijos (DEFAULT_*).
 *
 * Las reglas de estilo estan inspiradas en Harmoni (rango BPM 40-220, alineacion de octava de tempo,
 * duracion minima 45 s, distancia de tempo), pero los umbrales de estilo/filtro son MIOS y estan aqui arriba
 * para ajustarlos al oido.
 */
public final class LocalAutomix {
    private LocalAutomix() {}

    // ===================== AJUSTES (se tocan aqui) =====================
    /** Beatmatch (cambiar la velocidad de la entrante). Apagado: la velocidad se queda en 1.0. */
    static final boolean ENABLE_BEATMATCH = false;
    /** Distancia de tempo (|1 - bpmSale/bpmEntra|) hasta la que se considera "parecido". */
    static final double CLOSE_TEMPO = 0.08;
    /** Beatmatch solo si la distancia es menor o igual a esto (y ENABLE_BEATMATCH). */
    static final double BEATMATCH_MAX_DIST = 0.06;

    /** Barrido del filtro de la que sale (Hz): desde 20000 hasta... */
    static final double SWEEP_START_HZ = 20000.0;
    static final double SWEEP_END_CLOSE_HZ = 6000.0;   // tempos parecidos: barrido suave
    static final double SWEEP_END_FAR_HZ = 1200.0;     // tempos distintos: barrido fuerte (tapa el choque de ritmo)
    static final double SWEEP_END_UNKNOWN_HZ = 2200.0; // sin BPM: el valor que traia el servidor por defecto

    static final boolean BASS_SWAP = true;
    static final double BASS_SWAP_FRACTION = 0.5;

    /** El fundido pedido por el usuario es el tope; con BPM se ajusta a compases de 4 tiempos. */
    static final double MIN_FADE_SECONDS = 2.0;
    static final double MIN_BAR_FADE_SECONDS = 4.0;

    static final double BPM_MIN = 40.0, BPM_MAX = 220.0;

    /** Fuentes de BPM, en orden. */
    static final List<BpmSource> SOURCES = new ArrayList<BpmSource>();
    static {
        SOURCES.add(new DeezerBpmSource());
    }

    // ===================== Fuentes de BPM =====================
    public interface BpmSource {
        /** BPM de la cancion por su ISRC, o null si no lo sabe. Puede bloquear (red); lo llama un hilo aparte. */
        Double bpm(String isrc);
    }

    /** Deezer: GET https://api.deezer.com/track/isrc:XXXX -> campo "bpm" (0 = sin dato). */
    static final class DeezerBpmSource implements BpmSource {
        static volatile String base = "https://api.deezer.com/track/isrc:";
        private static final Pattern BPM = Pattern.compile("\"bpm\"\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)");

        @Override public Double bpm(String isrc) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(base + isrc).openConnection();
                c.setConnectTimeout(2500);
                c.setReadTimeout(2500);
                c.setRequestProperty("Accept", "application/json");
                if (c.getResponseCode() != 200) return null;
                InputStream in = c.getInputStream();
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        if (out.size() > 200000) break;
                    }
                    Matcher m = BPM.matcher(out.toString("UTF-8"));
                    if (!m.find()) return null;
                    double v = Double.parseDouble(m.group(1));
                    return v > 0 ? Double.valueOf(v) : null;
                } finally {
                    in.close();
                }
            } catch (Throwable t) {
                return null;
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    // ===================== Cache =====================
    private static final Pattern ISRC = Pattern.compile("^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$");
    private static final String PREFS = "eclipse_local_automix";
    private static final long NEGATIVE_TTL_MS = 30L * 60L * 1000L;
    private static final long WAIT_MS = 4000L;

    private static final ConcurrentHashMap<String, Double> found = new ConcurrentHashMap<String, Double>();
    private static final ConcurrentHashMap<String, Long> missed = new ConcurrentHashMap<String, Long>();

    private static SharedPreferences prefs() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Context) return ((Context) app).getSharedPreferences(PREFS, 0);
        } catch (Throwable ignored) {}
        return null;
    }

    /** Devuelve el BPM ya conocido (memoria o disco) sin tocar la red; null si no esta. */
    static Double cached(String isrc) {
        Double d = found.get(isrc);
        if (d != null) return d;
        SharedPreferences p = prefs();
        if (p != null) {
            float f = p.getFloat("bpm:" + isrc, 0f);
            if (f > 0f) {
                d = Double.valueOf(f);
                found.put(isrc, d);
                return d;
            }
        }
        return null;
    }

    private static void store(String isrc, double bpm) {
        found.put(isrc, Double.valueOf(bpm));
        try {
            SharedPreferences p = prefs();
            if (p != null) p.edit().putFloat("bpm:" + isrc, (float) bpm).apply();
        } catch (Throwable ignored) {}
    }

    /** Busca el BPM en las fuentes (bloquea). Guarda el resultado en la cache. */
    static Double lookup(String isrc) {
        for (BpmSource s : SOURCES) {
            Double d = null;
            try { d = s.bpm(isrc); } catch (Throwable ignored) {}
            if (d != null && d.doubleValue() >= BPM_MIN && d.doubleValue() <= BPM_MAX) {
                store(isrc, d.doubleValue());
                return d;
            }
        }
        missed.put(isrc, Long.valueOf(System.currentTimeMillis()));
        return null;
    }

    private static boolean recentlyMissed(String isrc) {
        Long t = missed.get(isrc);
        return t != null && System.currentTimeMillis() - t.longValue() < NEGATIVE_TTL_MS;
    }

    /** BPM de las dos canciones; consulta en paralelo y espera como mucho WAIT_MS. */
    private static Double[] bpms(String outIsrc, String inIsrc) {
        final String[] ids = {outIsrc, inIsrc};
        final Double[] res = new Double[2];
        List<Thread> threads = new ArrayList<Thread>();
        for (int i = 0; i < 2; i++) {
            final int k = i;
            String id = ids[k];
            if (id == null || !ISRC.matcher(id).matches()) continue;
            res[k] = cached(id);
            if (res[k] != null || recentlyMissed(id)) continue;
            Thread t = new Thread(new Runnable() {
                @Override public void run() { res[k] = lookup(ids[k]); }
            }, "LocalAutomix-bpm");
            t.setDaemon(true);
            t.start();
            threads.add(t);
        }
        long deadline = System.currentTimeMillis() + WAIT_MS;
        for (Thread t : threads) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            try { t.join(left); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        return new Double[]{res[0], res[1]};
    }

    // ===================== Reglas =====================
    static boolean validBpm(Double b) {
        return b != null && b.doubleValue() >= BPM_MIN && b.doubleValue() <= BPM_MAX;
    }

    /** Pliega el BPM de la entrante por octavas (x2, /2) para que quede lo mas cerca posible del de la que sale. */
    static double alignOctave(double out, double in) {
        double best = in;
        double[] cands = {in, in * 2.0, in / 2.0};
        double bestDist = Math.abs(out / in - 1.0);
        for (double c : cands) {
            if (c < BPM_MIN || c > BPM_MAX) continue;
            double d = Math.abs(out / c - 1.0);
            if (d < bestDist) { bestDist = d; best = c; }
        }
        return best;
    }

    /** Resultado de decidir; separado del JSON para poder probarlo. */
    static final class Decision {
        String style;
        String tier;
        double fade;
        double rate = 1.0;
        boolean bassSwap;
        double bassSwapFraction;
        double sweepStartHz;
        double sweepEndHz;
        Double outBpm;
        Double inBpm;
        String reason;
    }

    static Decision decide(Double outBpm, Double inBpm, double requestedFade) {
        Decision d = new Decision();
        double fade = requestedFade >= MIN_FADE_SECONDS ? requestedFade : MIN_FADE_SECONDS;
        d.fade = fade;
        d.bassSwap = BASS_SWAP;
        d.bassSwapFraction = BASS_SWAP_FRACTION;
        d.sweepStartHz = SWEEP_START_HZ;
        d.tier = "local";

        if (validBpm(outBpm) && validBpm(inBpm)) {
            double o = outBpm.doubleValue();
            double in = alignOctave(o, inBpm.doubleValue());
            double ratio = o / in;
            double dist = Math.abs(ratio - 1.0);
            d.outBpm = outBpm;
            d.inBpm = Double.valueOf(in);

            // Fundido en compases de 4 tiempos (a lo sumo el que pidio el usuario).
            double bar = 4.0 * 60.0 / o;
            double bars = Math.floor(fade / bar);
            if (bars >= 1.0 && bars * bar >= MIN_BAR_FADE_SECONDS) d.fade = bars * bar;

            if (dist <= CLOSE_TEMPO) {
                d.style = "dj_blend";
                d.sweepEndHz = SWEEP_END_CLOSE_HZ;
                d.reason = "local-tempo-close";
                if (ENABLE_BEATMATCH && dist <= BEATMATCH_MAX_DIST) {
                    d.tier = "beatmatched";
                    d.rate = ratio;
                    d.reason = "local-beatmatch";
                }
            } else {
                d.style = "dj_filter";
                d.sweepEndHz = SWEEP_END_FAR_HZ;
                d.reason = "local-tempo-far";
            }
        } else {
            d.style = "dj_filter";
            d.sweepEndHz = SWEEP_END_UNKNOWN_HZ;
            d.reason = "local-no-bpm";
        }
        return d;
    }

    private static String num(double v) {
        return String.format(Locale.ROOT, "%.4f", v);
    }

    static String toJson(Decision d) {
        StringBuilder b = new StringBuilder(512);
        b.append("{\"status\":\"ready\",\"plan\":{");
        b.append("\"shouldStart\":true,\"markerVisible\":true,\"blocked\":false,");
        b.append("\"reason\":\"").append(d.reason).append("\",");
        b.append("\"tier\":\"").append(d.tier).append("\",");
        b.append("\"transitionStyle\":\"").append(d.style).append("\",");
        b.append("\"transitionStart\":0,\"transitionEnd\":0,");
        b.append("\"fadeSeconds\":").append(num(d.fade)).append(',');
        b.append("\"incomingCueTime\":0,\"incomingHandoffTime\":0,");
        b.append("\"incomingPlaybackRate\":").append(num(d.rate)).append(',');
        b.append("\"handoffFraction\":0.5,");
        b.append("\"bassSwap\":").append(d.bassSwap ? "true" : "false").append(',');
        b.append("\"bassSwapFraction\":").append(num(d.bassSwapFraction)).append(',');
        b.append("\"filterSweep\":{\"outgoing\":\"lowpass\",\"incoming\":\"highpass\",\"startHz\":")
                .append(num(d.sweepStartHz)).append(",\"endHz\":").append(num(d.sweepEndHz)).append("},");
        b.append("\"vocalOverlap\":0");
        if (d.outBpm != null) b.append(",\"outgoingBpm\":").append(num(d.outBpm.doubleValue()));
        if (d.inBpm != null) b.append(",\"incomingBpm\":").append(num(d.inBpm.doubleValue()));
        b.append(",\"policyReasons\":[\"").append(d.reason).append("\"]");
        b.append("}}");
        return b.toString();
    }

    /**
     * Gancho de wf0.invokeSuspend: reemplaza el pedido HTTP al servidor. Nunca devuelve null ni lanza:
     * si algo falla, plan con valores fijos.
     */
    public static String planJson(String outIsrc, String inIsrc, int fadeSeconds) {
        Double[] b = {null, null};
        try {
            b = bpms(outIsrc, inIsrc);
        } catch (Throwable ignored) {}
        Decision d;
        try {
            d = decide(b[0], b[1], fadeSeconds);
        } catch (Throwable t) {
            d = decide(null, null, fadeSeconds);
        }
        return toJson(d);
    }
}
