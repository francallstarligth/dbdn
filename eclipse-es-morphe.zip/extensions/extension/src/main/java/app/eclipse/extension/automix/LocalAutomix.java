package app.eclipse.extension.automix;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Planificador local de Automix para Eclipse 0.6.47 (reemplaza al plan del servidor api.eclipsemusic.app).
 *
 * Entra con los dos ISRC (ya normalizados por Eclipse) y el fundido pedido (segundos) y devuelve el JSON
 * que entiende wx6.G (el mismo formato que mandaba el servidor): status "ready" + plan. El motor nativo de
 * Eclipse ejecuta lo que aqui se decide (fundido, barrido de filtro, bass swap).
 *
 * Los datos de tempo salen de fuentes de BPM intercambiables ({@link BpmSource}). Hoy: Deezer por ISRC.
 * Para anadir otra fuente: implementar BpmSource y agregarla en {@link #SOURCES}; se prueban en orden.
 * Sin BPM de alguna cancion se usan valores fijos (DEFAULT_*).
 *
 * Las reglas de estilo estan inspiradas en Harmoni (rango BPM 40-220, alineacion de octava de tempo,
 * duracion minima 45 s, distancia de tempo), pero los umbrales de estilo/filtro son MIOS y estan aqui arriba
 * para ajustarlos al oido.
 */
public final class LocalAutomix {
    private LocalAutomix() {}

    // ===================== AJUSTES (se tocan aqui) =====================
    /** Beatmatch (cambiar la velocidad de la entrante). Apagado: la velocidad se queda en 1.0. */
    static final boolean ENABLE_BEATMATCH = true;
    /** Beatmatch solo si hay downbeats de las dos canciones (fase alineada); sin fase, igualar tempo suena peor que no hacerlo. */
    static final boolean BEATMATCH_NEEDS_PHASE = true;
    /** Empezar el fundido en un downbeat de la que sale (cerca de donde empieza su final) en vez de solo "al final menos el fundido". */
    static final boolean SMART_START = true;
    /** Como mucho cuantos segundos antes del inicio por defecto puede adelantarse el fundido (limita el dano si el reloj de la ficha no es el esperado). */
    static final double MAX_EARLY_START = 15.0;
    /** Como mucho cuantos segundos se salta del inicio de la entrante para que su primer downbeat caiga al empezar el fundido. */
    static final double MAX_CUE = 4.0;
    /** Distancia de tempo (|1 - bpmSale/bpmEntra|) hasta la que se considera "parecido". */
    static final double CLOSE_TEMPO = 0.08;
    /** Beatmatch solo si la distancia es menor o igual a esto (y ENABLE_BEATMATCH). */
    static final double BEATMATCH_MAX_DIST = 0.06;

    /** Barrido del filtro de la que sale (Hz): desde 20000 hasta... */
    static final double SWEEP_START_HZ = 20000.0;
    static final double SWEEP_END_NEAR_HZ = 3000.0;    // tempos casi iguales: barrido marcado pero musical
    static final double SWEEP_END_FAR_HZ = 900.0;      // tempos distintos: barrido fuerte (tapa el choque de ritmo)
    static final double SWEEP_FAR_DIST = 0.25;         // a esta distancia de tempo (o mas) se usa el barrido fuerte; en medio se interpola
    static final double SWEEP_END_UNKNOWN_HZ = 2200.0; // sin BPM: el valor que traia el servidor por defecto

    static final boolean BASS_SWAP = true;
    static final double BASS_SWAP_FRACTION = 0.5;

    /** El fundido pedido por el usuario es el tope; con BPM se ajusta a compases de 4 tiempos. */
    static final double MIN_FADE_SECONDS = 2.0;
    static final double MIN_BAR_FADE_SECONDS = 4.0;

    static final double BPM_MIN = 40.0, BPM_MAX = 220.0;

    /** Fichas del analizador de Eclipse con confianza de beat menor a esto se ignoran (queda Deezer / valores fijos). */
    static final double MIN_BEAT_CONFIDENCE = 0.2;

    /** Fuentes de BPM, en orden. */
    static final List<BpmSource> SOURCES = new ArrayList<BpmSource>();
    static {
        SOURCES.add(new DeezerBpmSource());
    }

    // ===================== Fuentes de BPM =====================
    public interface BpmSource {
        /** BPM de la cancion por su ISRC, o null si no lo sabe. Puede bloquear (red); lo llama un hilo aparte. */
        Double bpm(String isrc);
    }

    /** Deezer: GET https://api.deezer.com/track/isrc:XXXX -> campo "bpm" (0 = sin dato). */
    static final class DeezerBpmSource implements BpmSource {
        static volatile String base = "https://api.deezer.com/track/isrc:";
        private static final Pattern BPM = Pattern.compile("\"bpm\"\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)");

        @Override public Double bpm(String isrc) {
            HttpURLConnection c = null;
            try {
                c = (HttpURLConnection) new URL(base + isrc).openConnection();
                c.setConnectTimeout(2500);
                c.setReadTimeout(2500);
                c.setRequestProperty("Accept", "application/json");
                if (c.getResponseCode() != 200) return null;
                InputStream in = c.getInputStream();
                try {
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    byte[] buf = new byte[4096];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        out.write(buf, 0, n);
                        if (out.size() > 200000) break;
                    }
                    Matcher m = BPM.matcher(out.toString("UTF-8"));
                    if (!m.find()) return null;
                    double v = Double.parseDouble(m.group(1));
                    return v > 0 ? Double.valueOf(v) : null;
                } finally {
                    in.close();
                }
            } catch (Throwable t) {
                return null;
            } finally {
                if (c != null) c.disconnect();
            }
        }
    }

    // ===================== Cache =====================
    private static final Pattern ISRC = Pattern.compile("^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$");
    private static final String PREFS = "eclipse_local_automix";
    private static final long NEGATIVE_TTL_MS = 30L * 60L * 1000L;
    private static final long WAIT_MS = 4000L;

    private static final ConcurrentHashMap<String, Double> found = new ConcurrentHashMap<String, Double>();
    private static final ConcurrentHashMap<String, Long> missed = new ConcurrentHashMap<String, Long>();

    private static SharedPreferences prefs() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Context) return ((Context) app).getSharedPreferences(PREFS, 0);
        } catch (Throwable ignored) {}
        return null;
    }

    /** Devuelve el BPM ya conocido (memoria o disco) sin tocar la red; null si no esta. */
    static Double cached(String isrc) {
        Double d = found.get(isrc);
        if (d != null) return d;
        SharedPreferences p = prefs();
        if (p != null) {
            float f = p.getFloat("bpm:" + isrc, 0f);
            if (f > 0f) {
                d = Double.valueOf(f);
                found.put(isrc, d);
                return d;
            }
        }
        return null;
    }

    private static void store(String isrc, double bpm) {
        store(isrc, bpm, null, null);
    }

    private static void store(String isrc, double bpm, Double conf, String key) {
        found.put(isrc, Double.valueOf(bpm));
        missed.remove(isrc);
        try {
            SharedPreferences p = prefs();
            if (p != null) {
                SharedPreferences.Editor e = p.edit().putFloat("bpm:" + isrc, (float) bpm);
                if (conf != null) e.putFloat("conf:" + isrc, (float) conf.doubleValue());
                if (key != null) e.putString("key:" + isrc, key);
                e.apply();
            }
        } catch (Throwable ignored) {}
    }

    // ===================== Ficha del analizador de Eclipse (tf0.a) =====================
    private static Pattern numKey(String name) {
        return Pattern.compile("\"" + name + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?)");
    }
    private static final Pattern CARD_BPM = numKey("bpm");
    private static final Pattern CARD_ABPM = numKey("analyzedBpm");
    private static final Pattern CARD_INTERVAL = numKey("beatInterval");
    private static final Pattern CARD_CONF = numKey("beatConfidence");
    private static final Pattern CARD_KEY = Pattern.compile("\"key\"\\s*:\\s*\"([^\"]{1,16})\"");

    /** ISRC como lo normaliza Eclipse (yf0.e): sin guiones, sin espacios en los bordes, mayusculas. */
    static String normalize(String isrc) {
        return isrc.replace("-", "").trim().toUpperCase(Locale.ROOT);
    }

    private static Double firstNumber(Pattern p, String s) {
        Matcher m = p.matcher(s);
        if (!m.find()) return null;
        try {
            double v = Double.parseDouble(m.group(1));
            return (Double.isNaN(v) || Double.isInfinite(v)) ? null : Double.valueOf(v);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** BPM de la ficha: "bpm", si no "analyzedBpm", si no 60 / beatInterval (segundos o milisegundos). */
    static Double bpmFromCard(String card) {
        Double a = firstNumber(CARD_BPM, card);
        if (validBpm(a)) return a;
        Double b = firstNumber(CARD_ABPM, card);
        if (validBpm(b)) return b;
        Double iv = firstNumber(CARD_INTERVAL, card);
        if (iv != null && iv.doubleValue() > 0) {
            double sec = iv.doubleValue() > 20.0 ? iv.doubleValue() / 1000.0 : iv.doubleValue();
            Double c = Double.valueOf(60.0 / sec);
            if (validBpm(c)) return c;
        }
        return null;
    }

    /**
     * Gancho de tf0.a: recibe el ISRC y la ficha que Eclipse acaba de calcular en el telefono (antes de subirla).
     * Guarda el BPM en la misma cache que usa el plan (tiene prioridad sobre Deezer). Nunca lanza ni bloquea.
     */
    public static void onCard(String isrc, String card) {
        try {
            if (isrc == null || card == null) return;
            String id = normalize(isrc);
            if (!ISRC.matcher(id).matches()) return;
            markCard(id);
            Double conf = firstNumber(CARD_CONF, card);
            if (conf != null && conf.doubleValue() < MIN_BEAT_CONFIDENCE) return;
            CardInfo ci = parseInfo(card);
            Double bpm = reconcileBpm(bpmFromCard(card), ci == null ? null : ci.beatBpm);
            if (ci != null) storeInfo(id, ci);
            if (bpm == null) return;
            Matcher km = CARD_KEY.matcher(card);
            store(id, bpm.doubleValue(), conf, km.find() ? km.group(1) : null);
        } catch (Throwable ignored) {}
    }

    // ===================== Datos de tiempo de la ficha (inicio del fundido, downbeats) =====================
    private static final Pattern CARD_DURATION = numKey("duration");
    private static final Pattern CARD_OUTRO = numKey("outroStartTime");

    /** Lo que se guarda de la ficha para colocar el fundido. Tiempos en segundos. */
    static final class CardInfo {
        double duration = -1;      // duracion de la cancion segun la ficha
        double outro = -1;         // inicio del final (outroStartTime)
        double firstDownbeat = -1; // primer downbeat
        double[] downbeats;        // primeros 4 + ultimos 60 downbeats (ascendente)
        Double beatBpm;            // BPM calculado de los intervalos de beats[]

        boolean hasDownbeats() { return downbeats != null && downbeats.length > 0; }
    }

    private static double[] numArray(String card, String name) {
        Matcher m = Pattern.compile("\"" + name + "\"\\s*:\\s*\\[([^\\]\\[{]*)\\]").matcher(card);
        if (!m.find()) return null;
        String[] parts = m.group(1).split(",");
        double[] tmp = new double[parts.length];
        int n = 0;
        for (String p : parts) {
            String t = p.trim();
            if (t.length() == 0) continue;
            try {
                double v = Double.parseDouble(t);
                if (!Double.isNaN(v) && !Double.isInfinite(v) && v >= 0) tmp[n++] = v;
            } catch (NumberFormatException ignored) {}
        }
        if (n == 0) return null;
        double[] out = new double[n];
        System.arraycopy(tmp, 0, out, 0, n);
        java.util.Arrays.sort(out);
        return out;
    }

    private static double maxOf(double[] a) {
        double m = 0;
        if (a != null) for (double v : a) if (v > m) m = v;
        return m;
    }

    private static double[] scaled(double[] a, double k) {
        if (a == null || k == 1.0) return a;
        double[] o = new double[a.length];
        for (int i = 0; i < a.length; i++) o[i] = a[i] * k;
        return o;
    }

    /** BPM por la mediana de los intervalos entre beats (mas fino que el campo bpm). null si no hay datos fiables. */
    static Double bpmFromBeats(double[] beats) {
        if (beats == null || beats.length < 8) return null;
        double[] d = new double[beats.length - 1];
        int n = 0;
        for (int i = 1; i < beats.length; i++) {
            double x = beats[i] - beats[i - 1];
            if (x >= 0.15 && x <= 2.0) d[n++] = x;
        }
        if (n < 6) return null;
        double[] c = new double[n];
        System.arraycopy(d, 0, c, 0, n);
        java.util.Arrays.sort(c);
        double med = (n % 2 == 1) ? c[n / 2] : (c[n / 2 - 1] + c[n / 2]) / 2.0;
        double bpm = 60.0 / med;
        for (int i = 0; i < 2 && bpm < BPM_MIN; i++) bpm *= 2.0;
        for (int i = 0; i < 2 && bpm > BPM_MAX; i++) bpm /= 2.0;
        return (bpm >= BPM_MIN && bpm <= BPM_MAX) ? Double.valueOf(bpm) : null;
    }

    /** Junta el BPM del campo de la ficha con el de los intervalos de beats: si coinciden (o van a octava) manda el de beats. */
    static Double reconcileBpm(Double card, Double beats) {
        if (!validBpm(beats)) return validBpm(card) ? card : null;
        if (!validBpm(card)) return beats;
        double b = beats.doubleValue(), c = card.doubleValue();
        double best = b;
        double[] cands = {b, b * 2.0, b / 2.0};
        double bd = Math.abs(b / c - 1.0);
        for (double x : cands) {
            if (x < BPM_MIN || x > BPM_MAX) continue;
            double dd = Math.abs(x / c - 1.0);
            if (dd < bd) { bd = dd; best = x; }
        }
        return bd <= 0.08 ? Double.valueOf(best) : card;
    }

    static CardInfo parseInfo(String card) {
        CardInfo ci = new CardInfo();
        Double dur = firstNumber(CARD_DURATION, card);
        if (dur != null && dur.doubleValue() > 0) {
            double dv = dur.doubleValue();
            ci.duration = dv > 20000.0 ? dv / 1000.0 : dv;
        }
        Double outro = firstNumber(CARD_OUTRO, card);
        double[] db = numArray(card, "downbeats");
        double[] beats = numArray(card, "beats");
        double k = 1.0;
        if (ci.duration > 0) {
            double mx = Math.max(maxOf(db), Math.max(maxOf(beats), outro == null ? 0 : outro.doubleValue()));
            if (mx > ci.duration * 1.5 && mx / 1000.0 <= ci.duration * 1.05) k = 0.001;
        }
        db = scaled(db, k);
        beats = scaled(beats, k);
        if (outro != null && outro.doubleValue() > 0) ci.outro = outro.doubleValue() * k;
        ci.beatBpm = bpmFromBeats(beats);
        if (db != null) {
            if (db.length > 64) {
                double[] keep = new double[64];
                System.arraycopy(db, 0, keep, 0, 4);
                System.arraycopy(db, db.length - 60, keep, 4, 60);
                db = keep;
            }
            ci.downbeats = db;
            ci.firstDownbeat = db[0];
        }
        boolean any = ci.duration > 0 || ci.outro > 0 || ci.hasDownbeats();
        return any ? ci : null;
    }

    private static final ConcurrentHashMap<String, CardInfo> infos = new ConcurrentHashMap<String, CardInfo>();

    private static String serialize(CardInfo ci) {
        StringBuilder b = new StringBuilder(256);
        b.append(String.format(Locale.ROOT, "%.3f|%.3f|%.3f|", ci.duration, ci.outro, ci.firstDownbeat));
        if (ci.downbeats != null) {
            for (int i = 0; i < ci.downbeats.length; i++) {
                if (i > 0) b.append(',');
                b.append(String.format(Locale.ROOT, "%.3f", ci.downbeats[i]));
            }
        }
        return b.toString();
    }

    private static CardInfo deserialize(String s) {
        try {
            String[] p = s.split("\\|", -1);
            if (p.length < 4) return null;
            CardInfo ci = new CardInfo();
            ci.duration = Double.parseDouble(p[0]);
            ci.outro = Double.parseDouble(p[1]);
            ci.firstDownbeat = Double.parseDouble(p[2]);
            if (p[3].length() > 0) {
                String[] q = p[3].split(",");
                double[] a = new double[q.length];
                for (int i = 0; i < q.length; i++) a[i] = Double.parseDouble(q[i]);
                ci.downbeats = a;
            }
            return ci;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void storeInfo(String id, CardInfo ci) {
        infos.put(id, ci);
        try {
            SharedPreferences p = prefs();
            if (p != null) p.edit().putString("info:" + id, serialize(ci)).apply();
        } catch (Throwable ignored) {}
    }

    static CardInfo infoFor(String isrc) {
        try {
            if (isrc == null) return null;
            String id = normalize(isrc);
            CardInfo ci = infos.get(id);
            if (ci != null) return ci;
            SharedPreferences p = prefs();
            if (p == null) return null;
            String s = p.getString("info:" + id, null);
            if (s == null) return null;
            ci = deserialize(s);
            if (ci != null) infos.put(id, ci);
            return ci;
        } catch (Throwable t) {
            return null;
        }
    }

    private static final ConcurrentHashMap<String, Boolean> carded = new ConcurrentHashMap<String, Boolean>();

    private static void markCard(String id) {
        carded.put(id, Boolean.TRUE);
        try {
            SharedPreferences p = prefs();
            if (p != null) p.edit().putBoolean("card:" + id, true).apply();
        } catch (Throwable ignored) {}
    }

    /**
     * Gancho de dg0.D (el "ya analizada/subida" de Eclipse). true = no analizar; false = analizar.
     * Solo da true si ESTA cancion ya paso por el analizador con el parche instalado (ficha vista en onCard);
     * asi las canciones que Eclipse analizo antes se re-analizan una vez para sacar su BPM local.
     * Ante cualquier fallo devuelve true (no analizar, como si ya estuviera hecha).
     */
    public static boolean analyzed(String isrc) {
        try {
            if (isrc == null) return true;
            String id = normalize(isrc);
            if (carded.containsKey(id)) return true;
            SharedPreferences p = prefs();
            if (p == null) return true;
            if (p.getBoolean("card:" + id, false)) {
                carded.put(id, Boolean.TRUE);
                return true;
            }
            return false;
        } catch (Throwable t) {
            return true;
        }
    }

    // ===================== Paso 3: canciones sin ISRC + disparo del analisis =====================
    /** true: si a una cancion le falta algun BPM local, el plan pide a Eclipse analizarla antes (estado "needs"). */
    static final boolean ANALYZE_ON_NEEDS = true;

    private static final Pattern FAKE_CARD = Pattern.compile("\"isrc\"\\s*:\\s*\"(ZZ[A-Z0-9]{10})\"");
    /** Pedidos de analisis por ISRC: {hora del ultimo pedido (ms), numero de pedidos}. */
    private static final ConcurrentHashMap<String, long[]> asked = new ConcurrentHashMap<String, long[]>();
    /** Un ISRC sin ficha solo se vuelve a pedir pasado este tiempo (dentro de la misma reproduccion: no, para que el 2.o plan salga "ready"). */
    static final long ASK_RETRY_MS = 120000L;
    /** Maximo de pedidos de analisis por ISRC y sesion. */
    static final int ASK_MAX = 3;

    private static boolean mayAsk(String id, long now) {
        synchronized (asked) {
            long[] a = asked.get(id);
            if (a == null) {
                asked.put(id, new long[]{now, 1L});
                return true;
            }
            if (a[1] >= ASK_MAX) return false;
            if (now - a[0] < ASK_RETRY_MS) return false;
            a[0] = now;
            a[1]++;
            return true;
        }
    }

    /** ISRC inventado (prefijo ZZ, 12 caracteres): nunca debe salir del telefono. */
    static boolean isFake(String isrc) {
        return isrc != null && isrc.length() == 12 && isrc.startsWith("ZZ");
    }

    /** ISRC estable e inventado a partir del id de la cancion: ZZ + 3 alfanumericos + 7 digitos (cumple el formato). */
    static String fakeIsrc(String id) {
        long h = 0xcbf29ce484222325L;
        for (int i = 0; i < id.length(); i++) {
            h ^= id.charAt(i);
            h *= 0x100000001b3L;
        }
        long v = h >>> 1;
        int letters = (int) (v % 46656L);
        v /= 46656L;
        long digits = v % 10000000L;
        String l = Integer.toString(letters, 36).toUpperCase(Locale.ROOT);
        while (l.length() < 3) l = "0" + l;
        String d = Long.toString(digits);
        while (d.length() < 7) d = "0" + d;
        return "ZZ" + l + d;
    }

    /**
     * Gancho de los 3 Song.getIsrc() de Eclipse (ig0.a, ig0.d x2): devuelve el ISRC real de la cancion y, si no tiene
     * (null o vacio), uno inventado a partir de su id. Nunca lanza; ante fallo devuelve el ISRC original.
     */
    public static String isrcFor(Object song) {
        String real = null;
        try {
            Object r = song.getClass().getMethod("getIsrc").invoke(song);
            if (r instanceof String) real = (String) r;
        } catch (Throwable ignored) {}
        try {
            if (real != null && normalize(real).length() > 0) return real;
            Object id = song.getClass().getMethod("getId").invoke(song);
            if (id instanceof String && ((String) id).length() > 0) return fakeIsrc((String) id);
        } catch (Throwable ignored) {}
        return real;
    }

    /** Gancho de la subida de la ficha (xf0, caso 0): true = NO subir (la ficha lleva un ISRC inventado). */
    public static boolean blockUpload(String card) {
        try {
            return card != null && FAKE_CARD.matcher(card).find();
        } catch (Throwable t) {
            return false;
        }
    }

    private static void addNeed(List<String> out, String isrc) {
        if (isrc == null) return;
        String id = normalize(isrc);
        if (!ISRC.matcher(id).matches()) return;
        if (analyzed(id)) return;
        if (!mayAsk(id, System.currentTimeMillis())) return;
        if (!out.contains(id)) out.add(id);
    }

    /**
     * Si a alguna de las dos canciones le falta ficha local y aun no se la hemos pedido a Eclipse en esta sesion,
     * devuelve el JSON {"status":"needs","needs":[...]}: ig0.d analiza esas canciones con su analizador y vuelve a
     * pedir el plan (segunda llamada: ya no hay needs, sale el plan normal). Sin pendientes devuelve null.
     */
    static String needsJson(String outIsrc, String inIsrc) {
        List<String> need = new ArrayList<String>();
        addNeed(need, outIsrc);
        addNeed(need, inIsrc);
        if (need.isEmpty()) return null;
        StringBuilder b = new StringBuilder(96);
        b.append("{\"status\":\"needs\",\"needs\":[");
        for (int i = 0; i < need.size(); i++) {
            if (i > 0) b.append(',');
            b.append('"').append(need.get(i)).append('"');
        }
        return b.append("]}").toString();
    }

    /** Busca el BPM en las fuentes (bloquea). Guarda el resultado en la cache. */
    static Double lookup(String isrc) {
        if (isFake(isrc)) {
            missed.put(isrc, Long.valueOf(System.currentTimeMillis()));
            return null;
        }
        for (BpmSource s : SOURCES) {
            Double d = null;
            try { d = s.bpm(isrc); } catch (Throwable ignored) {}
            if (d != null && d.doubleValue() >= BPM_MIN && d.doubleValue() <= BPM_MAX) {
                store(isrc, d.doubleValue());
                return d;
            }
        }
        missed.put(isrc, Long.valueOf(System.currentTimeMillis()));
        return null;
    }

    private static boolean recentlyMissed(String isrc) {
        Long t = missed.get(isrc);
        return t != null && System.currentTimeMillis() - t.longValue() < NEGATIVE_TTL_MS;
    }

    /** BPM de las dos canciones; consulta en paralelo y espera como mucho WAIT_MS. */
    private static Double[] bpms(String outIsrc, String inIsrc) {
        final String[] ids = {outIsrc, inIsrc};
        final Double[] res = new Double[2];
        List<Thread> threads = new ArrayList<Thread>();
        for (int i = 0; i < 2; i++) {
            final int k = i;
            String id = ids[k];
            if (id == null || !ISRC.matcher(id).matches()) continue;
            res[k] = cached(id);
            if (res[k] != null || recentlyMissed(id)) continue;
            Thread t = new Thread(new Runnable() {
                @Override public void run() { res[k] = lookup(ids[k]); }
            }, "LocalAutomix-bpm");
            t.setDaemon(true);
            t.start();
            threads.add(t);
        }
        long deadline = System.currentTimeMillis() + WAIT_MS;
        for (Thread t : threads) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            try { t.join(left); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        return new Double[]{res[0], res[1]};
    }

    // ===================== Reglas =====================
    static boolean validBpm(Double b) {
        return b != null && b.doubleValue() >= BPM_MIN && b.doubleValue() <= BPM_MAX;
    }

    /** Pliega el BPM de la entrante por octavas (x2, /2) para que quede lo mas cerca posible del de la que sale. */
    static double alignOctave(double out, double in) {
        double best = in;
        double[] cands = {in, in * 2.0, in / 2.0};
        double bestDist = Math.abs(out / in - 1.0);
        for (double c : cands) {
            if (c < BPM_MIN || c > BPM_MAX) continue;
            double d = Math.abs(out / c - 1.0);
            if (d < bestDist) { bestDist = d; best = c; }
        }
        return best;
    }

    /** Resultado de decidir; separado del JSON para poder probarlo. */
    static final class Decision {
        String style;
        String tier;
        double fade;
        double rate = 1.0;
        double start;   // transitionStart (s absolutos en la que sale); 0 = el de Eclipse
        double cue;     // incomingCueTime (s); 0 = desde el principio
        boolean bassSwap;
        double bassSwapFraction;
        double sweepStartHz;
        double sweepEndHz;
        Double outBpm;
        Double inBpm;
        String reason;
    }

    /** Barrido final del filtro segun la distancia de tempo: casi igual = NEAR, lejos = FAR, en medio interpola (escala log). */
    static double sweepEnd(double dist) {
        double t = Math.min(1.0, Math.max(0.0, dist / SWEEP_FAR_DIST));
        return Math.exp(Math.log(SWEEP_END_NEAR_HZ) * (1.0 - t) + Math.log(SWEEP_END_FAR_HZ) * t);
    }

    /**
     * Coloca el inicio del fundido en un downbeat de la que sale, entre (fin - fundido - MAX_EARLY_START) y
     * (fin - fundido), lo mas cerca posible de donde empieza su final. Si ademas la entrante tiene downbeats,
     * pide un cue para que su primer downbeat caiga al empezar. Devuelve true si la fase quedo alineada.
     */
    static boolean placeStart(Decision d, CardInfo oi, CardInfo ii) {
        if (oi == null || oi.duration < 45.0 || oi.duration > 3600.0) return false;
        double def = oi.duration - d.fade;
        double lo = def - MAX_EARLY_START;
        if (lo < 1.0) return false;
        double target = def;
        if (oi.outro > 0 && oi.outro < oi.duration) target = Math.min(def, Math.max(lo, oi.outro));
        boolean snapped = false;
        if (oi.hasDownbeats()) {
            double best = -1, bestDist = Double.MAX_VALUE;
            for (double db : oi.downbeats) {
                if (db < lo - 0.01 || db > def + 0.01) continue;
                double dist = Math.abs(db - target);
                if (dist < bestDist) { bestDist = dist; best = db; }
            }
            if (best > 0) { target = best; snapped = true; }
        }
        if (snapped || target < def - 0.5) d.start = target;
        if (!snapped || ii == null || !ii.hasDownbeats()) return false;
        double f = ii.firstDownbeat;
        if (f > MAX_CUE) return false;
        if (f > 0.05) d.cue = f;
        return true;
    }

    static Decision decide(Double outBpm, Double inBpm, double requestedFade) {
        return decide(outBpm, inBpm, requestedFade, null, null);
    }

    static Decision decide(Double outBpm, Double inBpm, double requestedFade, CardInfo oi, CardInfo ii) {
        Decision d = new Decision();
        double fade = requestedFade >= MIN_FADE_SECONDS ? requestedFade : MIN_FADE_SECONDS;
        d.fade = fade;
        d.bassSwap = BASS_SWAP;
        d.bassSwapFraction = BASS_SWAP_FRACTION;
        d.sweepStartHz = SWEEP_START_HZ;
        d.tier = "local";

        if (validBpm(outBpm) && validBpm(inBpm)) {
            double o = outBpm.doubleValue();
            double in = alignOctave(o, inBpm.doubleValue());
            double ratio = o / in;
            double dist = Math.abs(ratio - 1.0);
            d.outBpm = outBpm;
            d.inBpm = Double.valueOf(in);

            // Fundido en compases de 4 tiempos (a lo sumo el que pidio el usuario).
            double bar = 4.0 * 60.0 / o;
            double bars = Math.floor(fade / bar);
            if (bars >= 1.0 && bars * bar >= MIN_BAR_FADE_SECONDS) d.fade = bars * bar;

            d.sweepEndHz = sweepEnd(dist);
            if (dist <= CLOSE_TEMPO) {
                d.style = "dj_blend";
                d.reason = "local-tempo-close";
            } else {
                d.style = "dj_filter";
                d.reason = "local-tempo-far";
            }
            boolean aligned = false;
            if (SMART_START) {
                try { aligned = placeStart(d, oi, ii); } catch (Throwable t) { d.start = 0; d.cue = 0; }
            }
            if (ENABLE_BEATMATCH && dist <= BEATMATCH_MAX_DIST && (aligned || !BEATMATCH_NEEDS_PHASE)) {
                d.tier = "beatmatched";
                d.rate = ratio;
                d.reason = "local-beatmatch";
            }
            if (aligned && !"local-beatmatch".equals(d.reason)) d.reason = d.reason + "-aligned";
        } else {
            d.style = "dj_filter";
            d.sweepEndHz = SWEEP_END_UNKNOWN_HZ;
            d.reason = "local-no-bpm";
        }
        return d;
    }

    private static String num(double v) {
        return String.format(Locale.ROOT, "%.4f", v);
    }

    static String toJson(Decision d) {
        StringBuilder b = new StringBuilder(512);
        b.append("{\"status\":\"ready\",\"plan\":{");
        b.append("\"shouldStart\":true,\"markerVisible\":true,\"blocked\":false,");
        b.append("\"reason\":\"").append(d.reason).append("\",");
        b.append("\"tier\":\"").append(d.tier).append("\",");
        b.append("\"transitionStyle\":\"").append(d.style).append("\",");
        b.append("\"transitionStart\":").append(num(d.start)).append(",\"transitionEnd\":0,");
        b.append("\"fadeSeconds\":").append(num(d.fade)).append(',');
        b.append("\"incomingCueTime\":").append(num(d.cue)).append(",\"incomingHandoffTime\":0,");
        b.append("\"incomingPlaybackRate\":").append(num(d.rate)).append(',');
        b.append("\"handoffFraction\":0.5,");
        b.append("\"bassSwap\":").append(d.bassSwap ? "true" : "false").append(',');
        b.append("\"bassSwapFraction\":").append(num(d.bassSwapFraction)).append(',');
        b.append("\"filterSweep\":{\"outgoing\":\"lowpass\",\"incoming\":\"highpass\",\"startHz\":")
                .append(num(d.sweepStartHz)).append(",\"endHz\":").append(num(d.sweepEndHz)).append("},");
        b.append("\"vocalOverlap\":0");
        if (d.outBpm != null) b.append(",\"outgoingBpm\":").append(num(d.outBpm.doubleValue()));
        if (d.inBpm != null) b.append(",\"incomingBpm\":").append(num(d.inBpm.doubleValue()));
        b.append(",\"policyReasons\":[\"").append(d.reason).append("\"]");
        b.append("}}");
        return b.toString();
    }

    /**
     * Gancho de wf0.invokeSuspend: reemplaza el pedido HTTP al servidor. Nunca devuelve null ni lanza:
     * si algo falla, plan con valores fijos.
     */
    public static String planJson(String outIsrc, String inIsrc, int fadeSeconds) {
        if (ANALYZE_ON_NEEDS) {
            try {
                String n = needsJson(outIsrc, inIsrc);
                if (n != null) return n;
            } catch (Throwable ignored) {}
        }
        Double[] b = {null, null};
        try {
            b = bpms(outIsrc, inIsrc);
        } catch (Throwable ignored) {}
        Decision d;
        try {
            d = decide(b[0], b[1], fadeSeconds, infoFor(outIsrc), infoFor(inIsrc));
        } catch (Throwable t) {
            d = decide(null, null, fadeSeconds);
        }
        return toJson(d);
    }
}
