package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;

/**
 * v0.20.62 (SIN COMPILAR / SIN PROBAR). Al entrar a Cola, Eclipse (e20.m) crea la lista de filas VACIA y la llena un
 * instante despues (LaunchedEffect -> e20.x). En ese instante la pantalla ve "lista vacia" y dibuja el mensaje
 * "Nothing up next" (e20.j). El gancho (QueueNoFlashPatch) llama a {@link #fix} justo despues de `Lt78;->isEmpty()Z`:
 * si la lista esta vacia pero la cola REAL (yz6) si tiene canciones, devuelve false (no mostrar el mensaje todavia).
 * Si la lista sigue vacia pasado {@link #MAX_WAIT_MS}, o algo falla, devuelve el valor original (se comporta como siempre).
 */
public final class QueueNoFlash {
    private static final String TAG = "EclipseES.QueueNoFlash";
    /** Tope: si la lista no se llena en este tiempo, se muestra el mensaje como en Eclipse original. */
    private static final long MAX_WAIT_MS = 1200;

    private static boolean tried;
    private static boolean broken;
    private static Field instField;   // yz6.y (singleton)
    private static Method queueList;  // yz6.q() : List
    private static Field upNextField; // yz6.j : Ldl8 (StateFlow)

    /** Desde cuando (uptime) se ve la lista vacia con cola real. 0 = no esta esperando. */
    private static long emptySince;

    /**
     * @param list    la lista de filas (t78)
     * @param orig    lo que devolvio isEmpty() original
     * @return true = mostrar "Nada a continuacion"
     */
    public static boolean fix(Object list, boolean orig) {
        try {
            if (broken) return orig;
            if (!orig) {
                emptySince = 0;
                return false;
            }
            if (!realHasSongs()) {
                emptySince = 0;
                return true; // de verdad no hay nada: mensaje normal
            }
            long now = SystemClock.uptimeMillis();
            if (emptySince == 0) emptySince = now;
            return now - emptySince > MAX_WAIT_MS;
        } catch (Throwable t) {
            broken = true;
            Log.w(TAG, "se apaga: " + t);
            return orig;
        }
    }

    private static boolean realHasSongs() throws Exception {
        if (!tried) {
            tried = true;
            try {
                Class<?> c = Class.forName("yz6");
                instField = c.getDeclaredField("y");
                instField.setAccessible(true);
                queueList = c.getDeclaredMethod("q");
                queueList.setAccessible(true);
                upNextField = c.getDeclaredField("j");
                upNextField.setAccessible(true);
            } catch (Throwable t) {
                Log.w(TAG, "no se encontro yz6: " + t);
                broken = true;
                return false;
            }
        }
        Object q = instField.get(null);
        if (q == null) return false;
        Object l = queueList.invoke(q);
        if (l instanceof Collection && !((Collection<?>) l).isEmpty()) return true;
        Object flow = upNextField.get(q);
        if (flow != null) {
            Method gv = flow.getClass().getMethod("getValue");
            gv.setAccessible(true);
            Object v = gv.invoke(flow);
            if (v instanceof List && !((List<?>) v).isEmpty()) return true;
        }
        return false;
    }

    // ---- v0.20.67: llenar la lista en el PRIMER cuadro (QueueFirstFramePatch) ----
    private static java.lang.ref.WeakReference<Object> filledFor;
    private static Method fillM;      // e20.x(yz6, t78, en5)
    private static boolean fillBroken;

    /**
     * Se llama justo antes de que e20.m mire si la lista esta vacia. Eclipse crea la lista vacia y la llena despues
     * (LaunchedEffect, un cuadro mas tarde): por eso se ve "lista vacia" y portadas grises. Aqui se llama a la MISMA
     * funcion de Eclipse (e20.x) en el mismo momento, solo si la lista esta vacia, no hay busqueda, la cola real
     * tiene canciones y esta lista no se lleno ya. No guarda nada: usa los mismos datos de siempre.
     */
    public static void prefill(Object yz6, Object list, Object upNext, Object search) {
        try {
            if (fillBroken || broken || yz6 == null || list == null || upNext == null) return;
            if (!(list instanceof java.util.List) || !((java.util.List<?>) list).isEmpty()) return;
            if (filledFor != null && filledFor.get() == list) return;
            if (search != null) {
                Method gv = search.getClass().getMethod("getValue");
                gv.setAccessible(true);
                if (gv.invoke(search) != null) return;
            }
            if (!realHasSongs()) return;
            if (fillM == null) {
                Class<?> e = Class.forName("e20");
                for (Method m : e.getDeclaredMethods()) {
                    if (m.getName().equals("x") && m.getParameterTypes().length == 3
                            && m.getParameterTypes()[0].isInstance(yz6)
                            && m.getParameterTypes()[1].isInstance(list)
                            && m.getParameterTypes()[2].isInstance(upNext)) {
                        fillM = m;
                        break;
                    }
                }
                if (fillM == null) {
                    fillBroken = true;
                    Log.w(TAG, "prefill: no se encontro e20.x");
                    return;
                }
                fillM.setAccessible(true);
            }
            filledFor = new java.lang.ref.WeakReference<>(list);
            consumed = false;
            inPrefill = true;
            try {
                fillM.invoke(null, yz6, list, upNext);
            } finally {
                inPrefill = false;
            }
        } catch (Throwable t) {
            fillBroken = true;
            Log.w(TAG, "prefill se apaga: " + t);
        }
    }

    private static boolean consumed;
    private static boolean inPrefill;

    /**
     * Gancho al inicio de e20.x(yz6, lista, upNext): la primera vez que el LaunchedEffect de Eclipse intenta llenar la
     * lista que {@link #prefill} ya lleno, se le da una lista de mentira (se llena sola y se tira); asi no se borra y
     * rellena la lista que ya se ve (eso recrearia las filas y las portadas). Las demas veces devuelve la lista real.
     */
    public static Object target(Object list) {
        try {
            if (!inPrefill && !fillBroken && !broken && list != null && !consumed && filledFor != null && filledFor.get() == list) {
                consumed = true;
                return list.getClass().getDeclaredConstructor().newInstance();
            }
        } catch (Throwable t) {
            fillBroken = true;
            Log.w(TAG, "target se apaga: " + t);
        }
        return list;
    }

    private QueueNoFlash() {}
}
