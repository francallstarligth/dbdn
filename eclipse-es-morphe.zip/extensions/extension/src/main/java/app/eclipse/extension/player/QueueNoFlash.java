package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;

/**
 * v0.20.62 (SIN COMPILAR / SIN PROBAR). Al entrar a Cola, Eclipse (e20.m) crea la lista de filas VACIA y la llena un
 * instante despues (LaunchedEffect -> e20.x). En ese instante la pantalla ve "lista vacia" y dibuja el mensaje
 * "Nothing up next" (e20.j). El gancho (QueueNoFlashPatch) llama a {@link #fix} justo despues de `Lt78;->isEmpty()Z`:
 * si la lista esta vacia pero la cola REAL (yz6) si tiene canciones, devuelve false (no mostrar el mensaje todavia).
 * Si la lista sigue vacia pasado {@link #MAX_WAIT_MS}, o algo falla, devuelve el valor original (se comporta como siempre).
 */
public final class QueueNoFlash {
    private static final String TAG = "EclipseES.QueueNoFlash";
    /** Tope: si la lista no se llena en este tiempo, se muestra el mensaje como en Eclipse original. */
    private static final long MAX_WAIT_MS = 1200;

    private static boolean tried;
    private static boolean broken;
    private static Field instField;   // yz6.y (singleton)
    private static Method queueList;  // yz6.q() : List
    private static Field upNextField; // yz6.j : Ldl8 (StateFlow)

    /** Desde cuando (uptime) se ve la lista vacia con cola real. 0 = no esta esperando. */
    private static long emptySince;

    /**
     * @param list    la lista de filas (t78)
     * @param orig    lo que devolvio isEmpty() original
     * @return true = mostrar "Nada a continuacion"
     */
    public static boolean fix(Object list, boolean orig) {
        try {
            if (broken) return orig;
            if (!orig) {
                emptySince = 0;
                return false;
            }
            if (!realHasSongs()) {
                emptySince = 0;
                return true; // de verdad no hay nada: mensaje normal
            }
            long now = SystemClock.uptimeMillis();
            if (emptySince == 0) emptySince = now;
            return now - emptySince > MAX_WAIT_MS;
        } catch (Throwable t) {
            broken = true;
            Log.w(TAG, "se apaga: " + t);
            return orig;
        }
    }

    private static boolean realHasSongs() throws Exception {
        if (!tried) {
            tried = true;
            try {
                Class<?> c = Class.forName("yz6");
                instField = c.getDeclaredField("y");
                instField.setAccessible(true);
                queueList = c.getDeclaredMethod("q");
                queueList.setAccessible(true);
                upNextField = c.getDeclaredField("j");
                upNextField.setAccessible(true);
            } catch (Throwable t) {
                Log.w(TAG, "no se encontro yz6: " + t);
                broken = true;
                return false;
            }
        }
        Object q = instField.get(null);
        if (q == null) return false;
        Object l = queueList.invoke(q);
        if (l instanceof Collection && !((Collection<?>) l).isEmpty()) return true;
        Object flow = upNextField.get(q);
        if (flow != null) {
            Method gv = flow.getClass().getMethod("getValue");
            gv.setAccessible(true);
            Object v = gv.invoke(flow);
            if (v instanceof List && !((List<?>) v).isEmpty()) return true;
        }
        return false;
    }

    private QueueNoFlash() {}
}
