package app.eclipse.extension.audio;

/**
 * "Todo a float": en kd3 (sink de audio de Eclipse) la conversion a float solo se hace para fuentes de mas de 16 bit
 * (pi9.M). Este gancho recibe el resultado original y la codificacion de entrada, y tambien dice "true" para PCM de
 * 16 bit (encoding 2), de modo que pase por kd3.g (a float) antes del procesador nativo lg2.
 */
@SuppressWarnings("unused")
public final class FloatAudio {
    /** Codificacion PCM de 16 bit (C.ENCODING_PCM_16BIT). */
    private static final int ENCODING_PCM_16BIT = 2;

    private FloatAudio() {}

    public static boolean floatAll(boolean orig, int encoding) {
        return orig || encoding == ENCODING_PCM_16BIT;
    }
}
