package app.eclipse.extension.apple;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Token anonimo de Apple Music sacado de los scripts del reproductor web (music.apple.com).
 * Se usa solo cuando el propio metodo de Eclipse no consigue token. Sin cuenta ni cookies.
 * Llamar desde un hilo de red (nunca el principal).
 */
public final class AppleToken {
    private static final String TAG = "EclipseAppleToken";
    private static final String UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/124.0.0.0 Safari/537.36";
    private static final long RETRY_AFTER_MS = 10L * 60L * 1000L;
    private static final int MAX_SCRIPTS = 25;
    private static final String[] HOSTS = {"https://music.apple.com", "https://beta.music.apple.com"};
    private static final Pattern SCRIPT = Pattern.compile("/assets/[^\"'\\s)<>]+\\.js");
    private static final Pattern JWT = Pattern.compile(
            "ey[A-Za-z0-9_-]+\\.ey[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]+");
    private static final Pattern EXP = Pattern.compile("\"exp\"\\s*:\\s*(\\d+)");

    private static String cached;
    private static long cachedExpiresAtMs;
    private static long retryAfterMs;
    private static volatile boolean debug = false;

    private AppleToken() {}

    /** Avisos en pantalla con el paso donde se queda. Lo fija el parche (opcion "debug"). */
    public static void setDebug(boolean enabled) { debug = enabled; }

    /** Devuelve un token valido o null si no se pudo conseguir. */
    public static synchronized String guest() {
        try {
            long now = System.currentTimeMillis();
            if (cached != null && now < cachedExpiresAtMs - 60_000L) return cached;
            if (now < retryAfterMs) return null;

            toast("Apple: buscando token propio...");
            boolean htmlOk = false;
            int scriptCount = 0, read = 0;
            for (String host : HOSTS) {
                String html = get(host + "/us/browse");
                if (html == null) html = get(host + "/");
                if (html == null) continue;
                htmlOk = true;
                List<String> scripts = scriptsOf(html);
                scriptCount += scripts.size();
                for (String path : scripts) {
                    String js = get(host + path);
                    if (js == null) continue;
                    read++;
                    String best = pickToken(js, now);
                    if (best != null) {
                        cached = best;
                        cachedExpiresAtMs = expiryMs(best);
                        Log.d(TAG, "token listo");
                        toast("Apple: token propio OK");
                        return best;
                    }
                }
            }
            String why = "sin token (HTML " + (htmlOk ? "ok" : "no") + ", scripts " + scriptCount
                    + ", leidos " + read + ")";
            Log.w(TAG, why);
            toast("Apple: " + why);
            retryAfterMs = now + RETRY_AFTER_MS;
        } catch (Throwable t) {
            Log.w(TAG, "fallo: " + t);
            toast("Apple: error " + t);
            retryAfterMs = System.currentTimeMillis() + RETRY_AFTER_MS;
        }
        return null;
    }

    /** Scripts del HTML, con los "index" primero. Visible para pruebas. */
    static List<String> scriptsOf(String html) {
        Set<String> all = new LinkedHashSet<>();
        Matcher m = SCRIPT.matcher(html);
        while (m.find()) all.add(m.group());
        List<String> first = new ArrayList<>(), rest = new ArrayList<>();
        for (String s : all) (s.contains("index") || s.contains("/app") ? first : rest).add(s);
        first.addAll(rest);
        return first.size() > MAX_SCRIPTS ? new ArrayList<>(first.subList(0, MAX_SCRIPTS)) : first;
    }

    /** Elige un JWT no vencido; prefiere el del reproductor web. Visible para pruebas. */
    static String pickToken(String js, long nowMs) {
        String first = null;
        Matcher m = JWT.matcher(js);
        Set<String> seen = new LinkedHashSet<>();
        while (m.find()) {
            String jwt = m.group();
            if (!seen.add(jwt)) continue;
            long exp = expiryMs(jwt);
            if (exp <= nowMs) continue;
            if (isWebPlayer(jwt)) return jwt;
            if (first == null) first = jwt;
        }
        return first;
    }

    static long expiryMs(String jwt) {
        try {
            Matcher m = EXP.matcher(payload(jwt));
            if (m.find()) return Long.parseLong(m.group(1)) * 1000L;
        } catch (Throwable ignored) {}
        return 0L;
    }

    private static boolean isWebPlayer(String jwt) {
        try {
            String[] p = jwt.split("\\.");
            String header = new String(Base64.getUrlDecoder().decode(pad(p[0])), StandardCharsets.UTF_8);
            return header.contains("WebPlayKid") || payload(jwt).contains("AMPWebPlay");
        } catch (Throwable t) {
            return false;
        }
    }

    private static String payload(String jwt) {
        String[] p = jwt.split("\\.");
        return new String(Base64.getUrlDecoder().decode(pad(p[1])), StandardCharsets.UTF_8);
    }

    private static String pad(String s) {
        int r = s.length() % 4;
        return r == 0 ? s : s + "====".substring(r);
    }

    private static String get(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            if (c.getResponseCode() != 200) return null;
            try (InputStream in = c.getInputStream()) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 8_000_000) break;
                }
                return out.toString("UTF-8");
            }
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void toast(final String msg) {
        if (!debug) return;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
