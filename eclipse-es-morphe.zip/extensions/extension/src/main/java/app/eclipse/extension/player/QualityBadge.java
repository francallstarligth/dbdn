package app.eclipse.extension.player;

import android.content.res.Resources;
import java.lang.reflect.Field;

/**
 * Ayuda del parche "Icono de calidad: texto al lado": el tamano del icono (dp) y del texto (sp) sale del ALTO de
 * la capa en el editor (dw0.d = LayerTransform zb4, zb4.d = height, fraccion de la pantalla), igual que las barras.
 * Capas con proporcion fija (alto 0): se usa el ANCHO (zb4.c). Si nada se puede leer: 12 dp / 9 sp.
 */
@SuppressWarnings("unused")
public final class QualityBadge {
    private static final float DEFAULT_ICON_DP = 12f;
    private static final int DEFAULT_TEXT_SP = 9;
    /** Icono = alto de la capa (dp) x 0.32; texto (sp) = alto de la capa (dp) x 0.23. */
    private static final float ICON_K = 0.32f;
    private static final float TEXT_K = 0.23f;

    /** Capas con proporcion fija (alto 0, control "Component Size" = ancho): icono = ancho_dp x 0.18; texto = x 0.135. */
    private static final float ICON_KW = 0.18f;
    private static final float TEXT_KW = 0.135f;

    private static boolean tried;
    private static Field transformField;
    private static Field widthField;
    private static Field heightField;

    private QualityBadge() {}

    /** {alto en dp, ancho en dp} de la capa (0 si no se pudo leer). */
    private static float[] layerDp(Object layer) {
        float[] out = new float[] {0f, 0f};
        try {
            if (layer == null) return out;
            synchronized (QualityBadge.class) {
                if (!tried) {
                    tried = true;
                    transformField = layer.getClass().getDeclaredField("d");
                    transformField.setAccessible(true);
                    Object tr = transformField.get(layer);
                    widthField = tr.getClass().getDeclaredField("c");
                    widthField.setAccessible(true);
                    heightField = tr.getClass().getDeclaredField("d");
                    heightField.setAccessible(true);
                }
            }
            if (transformField == null) return out;
            Object tr = transformField.get(layer);
            float density = Resources.getSystem().getDisplayMetrics().density;
            float screenH = Resources.getSystem().getDisplayMetrics().heightPixels / density;
            float screenW = Resources.getSystem().getDisplayMetrics().widthPixels / density;
            double h = heightField.getDouble(tr);
            double w = widthField.getDouble(tr);
            if (h > 0) out[0] = (float) (h * screenH);
            if (w > 0) out[1] = (float) (w * screenW);
        } catch (Throwable t) {
            // se queda en 0 -> valores por defecto
        }
        return out;
    }

    public static float iconDp(Object layer) {
        float[] d = layerDp(layer);
        float v = d[0] > 0 ? d[0] * ICON_K : d[1] > 0 ? d[1] * ICON_KW : DEFAULT_ICON_DP;
        return Math.max(6f, Math.min(80f, v));
    }

    public static int textSp(Object layer) {
        float[] d = layerDp(layer);
        float v = d[0] > 0 ? d[0] * TEXT_K : d[1] > 0 ? d[1] * TEXT_KW : DEFAULT_TEXT_SP;
        return Math.max(6, Math.min(60, Math.round(v)));
    }
}
