package app.eclipse.extension.player;

import android.content.res.Resources;
import java.lang.reflect.Field;

/**
 * Ayuda del parche "Icono de calidad: texto al lado": el tamano del icono (dp) y del texto (sp) sale del ALTO de
 * la capa en el editor (dw0.d = LayerTransform zb4, zb4.d = height, fraccion de la pantalla), igual que las barras.
 * Si algo falla o la capa no tiene alto (0), se usan 12 dp / 9 sp.
 */
@SuppressWarnings("unused")
public final class QualityBadge {
    private static final float DEFAULT_ICON_DP = 12f;
    private static final int DEFAULT_TEXT_SP = 9;
    /** Icono = alto de la capa (dp) x 0.32; texto (sp) = alto de la capa (dp) x 0.23. */
    private static final float ICON_K = 0.32f;
    private static final float TEXT_K = 0.23f;

    private static boolean tried;
    private static Field transformField;
    private static Field heightField;

    private QualityBadge() {}

    /** Alto de la capa en dp, o -1 si no se pudo leer. */
    private static float layerHeightDp(Object layer) {
        try {
            if (layer == null) return -1f;
            synchronized (QualityBadge.class) {
                if (!tried) {
                    tried = true;
                    transformField = layer.getClass().getDeclaredField("d");
                    transformField.setAccessible(true);
                    Object tr = transformField.get(layer);
                    heightField = tr.getClass().getDeclaredField("d");
                    heightField.setAccessible(true);
                }
            }
            if (transformField == null || heightField == null) return -1f;
            double h = heightField.getDouble(transformField.get(layer));
            if (!(h > 0)) return -1f;
            float density = Resources.getSystem().getDisplayMetrics().density;
            float screenDp = Resources.getSystem().getDisplayMetrics().heightPixels / density;
            return (float) (h * screenDp);
        } catch (Throwable t) {
            return -1f;
        }
    }

    public static float iconDp(Object layer) {
        float h = layerHeightDp(layer);
        if (h <= 0) return DEFAULT_ICON_DP;
        return Math.max(6f, Math.min(80f, h * ICON_K));
    }

    public static int textSp(Object layer) {
        float h = layerHeightDp(layer);
        if (h <= 0) return DEFAULT_TEXT_SP;
        return Math.max(6, Math.min(60, Math.round(h * TEXT_K)));
    }
}
