package app.eclipse.extension.player;

import android.graphics.Canvas;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.116 (SIN COMPILAR / SIN PROBAR). Brillo de las letras con UN shader (AGSL), como Mochy (LyricsGlowLine.kt, BloomAgsl):
 * en vez de dibujar el texto 8 veces desplazado, se dibuja UNA vez en una capa aparte (RenderNode) y a esa capa se le pone un
 * efecto (RuntimeShader) que suma 8 muestras de la letra a un radio fijo y las deja como halo.
 * Para que el texto de Eclipse se dibuje en la capa y no en la pantalla, se cambia por un momento el Canvas interno de Compose
 * (uk.a, campo publico no final que Compose mismo cambia al grabar capas); SIEMPRE se restaura en el finally.
 * Todo por reflexion (no depende del compileSdk). Android 13+ (AGSL). Si algo falla, draw() devuelve false y LyricsPop usa el halo
 * de copias de antes.
 */
final class LyricsGlowShader {
    private LyricsGlowShader() {}

    interface Content {
        void run() throws Exception;
    }

    private static final String AGSL =
            "uniform shader content;\n"
            + "uniform float2 size;\n"
            + "uniform float bloomR;\n"
            + "uniform float bloom;\n"
            + "half4 sampleIn(float2 p) {\n"
            + "    if (p.x < 0.0 || p.y < 0.0 || p.x > size.x || p.y > size.y) return half4(0.0);\n"
            + "    return content.eval(p);\n"
            + "}\n"
            + "half4 main(float2 coord) {\n"
            + "    half4 b = sampleIn(coord + float2(bloomR, bloomR))\n"
            + "            + sampleIn(coord + float2(bloomR, -bloomR))\n"
            + "            + sampleIn(coord + float2(-bloomR, bloomR))\n"
            + "            + sampleIn(coord + float2(-bloomR, -bloomR))\n"
            + "            + sampleIn(coord + float2(bloomR, 0.0))\n"
            + "            + sampleIn(coord - float2(bloomR, 0.0))\n"
            + "            + sampleIn(coord + float2(0.0, bloomR))\n"
            + "            + sampleIn(coord - float2(0.0, bloomR));\n"
            + "    half4 o = b * (bloom * 0.125);\n"
            + "    o.a = min(o.a, 1.0);\n"
            + "    o.rgb = min(o.rgb, half3(o.a));\n"
            + "    return o;\n"
            + "}\n";

    private static final int POOL = 6;

    /** Un nodo + un shader por uso: el nodo grabado se lee al renderizar, asi que cada brillo del cuadro necesita el suyo. */
    private static final class Entry {
        Object node, shader;
    }

    private static boolean broken, inited;
    private static Constructor<?> rnCtor, rsCtor;
    private static Method mSetPos, mBegin, mEnd, mSetEffect, mCreateEffect, mU1, mU2, mDrawNode;
    private static final Entry[] pool = new Entry[POOL];
    private static int next;

    private static Object owner;          // el uk (Canvas de Compose) de este cuadro; lo pone el parche
    private static Field ownerCanvas;     // uk.a

    // v0.20.118: avisos de diagnostico quitados (el shader ya esta confirmado); say() queda vacio.
    static void say(String key, final String msg) {}

    private static String why(Throwable ex) {
        Throwable t = ex;
        while (t.getCause() != null && t.getCause() != t) t = t.getCause();
        String m = t.getClass().getSimpleName() + ": " + t.getMessage();
        return m.length() > 160 ? m.substring(0, 160) : m;
    }

    /** Lo llama el parche de smali justo despues de sacar el lienzo uk. */
    public static void setOwner(Object uk) {
        owner = uk;
    }

    private static void init() throws Exception {
        if (inited) return;
        Class<?> rn = Class.forName("android.graphics.RenderNode");
        Class<?> re = Class.forName("android.graphics.RenderEffect");
        Class<?> rs = Class.forName("android.graphics.RuntimeShader");
        rnCtor = rn.getConstructor(String.class);
        mSetPos = rn.getMethod("setPosition", int.class, int.class, int.class, int.class);
        mBegin = rn.getMethod("beginRecording", int.class, int.class);
        mEnd = rn.getMethod("endRecording");
        mSetEffect = rn.getMethod("setRenderEffect", re);
        mCreateEffect = re.getMethod("createRuntimeShaderEffect", rs, String.class);
        rsCtor = rs.getConstructor(String.class);
        mU1 = rs.getMethod("setFloatUniform", String.class, float.class);
        mU2 = rs.getMethod("setFloatUniform", String.class, float.class, float.class);
        mDrawNode = Canvas.class.getMethod("drawRenderNode", rn);
        inited = true;
    }

    /**
     * Dibuja el halo de lo que dibuje content (el texto de Eclipse) dentro del rectangulo [l,t,r,b] (coordenadas locales de c).
     * @return true si dibujo el halo; false si no se pudo (nada se toco en c).
     */
    static boolean draw(Canvas c, float l, float t, float r, float b, float radiusPx, float strength, Content content) {
        if (broken || c == null) return false;
        if (owner == null) { say("noowner", "Brillo: sin shader (no llego el canvas de Eclipse). Usa 8 copias"); return false; }
        if (android.os.Build.VERSION.SDK_INT < 33) { say("sdk", "Brillo: sin shader (hace falta Android 13+). Usa 8 copias"); return false; }
        try {
            if (!c.isHardwareAccelerated()) { say("hw", "Brillo: sin shader (canvas por software). Usa 8 copias"); return false; }
            init();
            if (ownerCanvas == null) {
                ownerCanvas = owner.getClass().getField("a");
                ownerCanvas.setAccessible(true);
            }
            int il = (int) Math.floor(l), it = (int) Math.floor(t), ir = (int) Math.ceil(r), ib = (int) Math.ceil(b);
            int w = ir - il, h = ib - it;
            if (w <= 1 || h <= 1 || w > 4096 || h > 4096) return false;
            Entry e = pool[next];
            if (e == null) {
                e = new Entry();
                e.node = rnCtor.newInstance("lyricsGlow");
                e.shader = rsCtor.newInstance(AGSL);
                pool[next] = e;
            }
            next = (next + 1) % POOL;
            mSetPos.invoke(e.node, il, it, ir, ib);
            Canvas rec = (Canvas) mBegin.invoke(e.node, w, h);
            Object prev = ownerCanvas.get(owner);
            boolean swapped = false;
            try {
                ownerCanvas.set(owner, rec);
                swapped = true;
                rec.translate(-il, -it);
                content.run();
            } finally {
                if (swapped) ownerCanvas.set(owner, prev);
                mEnd.invoke(e.node);
            }
            mU2.invoke(e.shader, "size", (float) w, (float) h);
            mU1.invoke(e.shader, "bloomR", radiusPx);
            mU1.invoke(e.shader, "bloom", strength);
            Object effect = mCreateEffect.invoke(null, e.shader, "content");
            mSetEffect.invoke(e.node, effect);
            mDrawNode.invoke(c, e.node);
            say("ok", "Brillo: shader OK (no dio error; mira si se ve bien)");
            return true;
        } catch (Throwable ex) {
            broken = true;
            System.out.println("LyricsGlowShader: desactivado por error: " + ex);
            say("fail", "Brillo: shader FALLO, usa 8 copias. " + why(ex));
            return false;
        }
    }
}
