package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Ayuda del parche "Custom: fundido transparente de la portada".
 *
 * El fondo inmersivo del reproductor Custom (mq7.a) es una caja con la portada y, encima, el degradado del
 * edgeFade. Para que ese degradado BORRE la portada (en vez de pintar un color encima) la caja necesita su propia
 * capa fuera de pantalla (graphicsLayer con CompositingStrategy.Offscreen). Eclipse ya trae esa lambda:
 * lg1(17) = "{ compositingStrategy = Offscreen }" y vd9.D(Modifier, lambda) = graphicsLayer.
 * Se llama por reflexion con los nombres de 0.6.70. Si algo falla, se devuelve el modificador sin cambios.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class FadeMask {
    private static boolean tried;
    private static Constructor lambdaCtor;
    private static Class vd9;
    private static Method graphicsLayer;

    private FadeMask() {}

    public static Object wrap(Object modifier) {
        try {
            if (modifier == null) return null;
            Object lambda;
            synchronized (FadeMask.class) {
                if (!tried) {
                    tried = true;
                    try {
                        Class lg1 = Class.forName("tj2");
                        lambdaCtor = lg1.getDeclaredConstructor(int.class);
                        lambdaCtor.setAccessible(true);
                        vd9 = Class.forName("je7");
                    } catch (Throwable ignored) {
                        lambdaCtor = null;
                    }
                }
                if (lambdaCtor == null) return modifier;
                lambda = lambdaCtor.newInstance(16);
                if (graphicsLayer == null) {
                    for (Method m : vd9.getDeclaredMethods()) {
                        if (!m.getName().equals("C") || !Modifier.isStatic(m.getModifiers())) continue;
                        Class[] p = m.getParameterTypes();
                        if (p.length == 2 && p[0].isInstance(modifier) && p[1].isInstance(lambda)
                                && p[0].isAssignableFrom(m.getReturnType())) {
                            m.setAccessible(true);
                            graphicsLayer = m;
                            break;
                        }
                    }
                }
                if (graphicsLayer == null) return modifier;
            }
            Object out = graphicsLayer.invoke(null, modifier, lambda);
            return out == null ? modifier : out;
        } catch (Throwable t) {
            return modifier;
        }
    }
}
