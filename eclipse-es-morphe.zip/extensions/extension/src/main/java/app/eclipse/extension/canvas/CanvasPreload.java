package app.eclipse.extension.canvas;

import android.content.Context;
import android.net.ConnectivityManager;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Precarga del Canvas de la SIGUIENTE cancion (opcion "preload" del parche "Canvas: cache compartida").
 *
 * Gancho: inicio de ww0.F(Context, Song, Continuation) -> onSongWifi / onSongAny(ctx, song). Si `song` es la cancion actual
 * de la cola (nt7.l()), espera unos segundos (por si el usuario salta) y entonces:
 *  1) resuelve la URL del Canvas de la siguiente (nt7.x()) llamando a ww0.F por el truco de la lambda `qz`
 *     (SuspendLambda de un LaunchedEffect: su invokeSuspend llama a ww0.F y deja la URL en un q06);
 *  2) baja el video por la fuente con cache (CanvasCache.build), asi queda en la cache de Eclipse con la misma
 *     clave (uri.toString()) que usan los ExoPlayer de los Canvas.
 * Todo por reflexion sobre clases ofuscadas de Eclipse 0.6.47; si algo falla no hace nada y deja un Log "CanvasPreload".
 * No se baja HLS (.m3u8): ahi solo se bajaria la lista, no los segmentos.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasPreload {
    private static final String TAG = "CanvasPreload";
    /** Espera antes de precargar: si el usuario salta de cancion, no se baja nada. */
    private static final long DEBOUNCE_MS = 3000;
    /** Maximo a leer de un video. */
    private static final long MAX_BYTES = 10L * 1024 * 1024;
    /** Maximo de tiempo bajando un video. */
    private static final long MAX_DOWNLOAD_MS = 45_000;
    /** Maximo de espera para resolver la URL. */
    private static final long RESOLVE_TIMEOUT_MS = 25_000;
    private static final int MAX_DONE = 40;

    private static final ScheduledThreadPoolExecutor EXEC = new ScheduledThreadPoolExecutor(1, r -> {
        Thread t = new Thread(r, "CanvasPreload");
        t.setDaemon(true);
        return t;
    });
    private static final Set<String> DONE = Collections.synchronizedSet(new LinkedHashSet<String>());
    private static volatile boolean working;
    private static ScheduledFuture<?> pending;

    private CanvasPreload() {}

    /** Solo con red sin limite (Wi-Fi). */
    public static void onSongWifi(Context ctx, Object song) {
        dispatch(ctx, song, true);
    }

    /** Con cualquier red (tambien datos moviles). */
    public static void onSongAny(Context ctx, Object song) {
        dispatch(ctx, song, false);
    }

    private static void dispatch(final Context ctx, Object song, final boolean wifiOnly) {
        try {
            // Mientras precargamos, la propia resolucion vuelve a pasar por ww0.F: se ignora.
            if (working || ctx == null || song == null) return;
            Object queue = queue();
            if (queue == null) return;
            Object cur = call(queue, "l");
            final String id = idOf(song);
            if (cur == null || id == null || !id.equals(idOf(cur))) return;
            Object next = call(queue, "x");
            final String nid = idOf(next);
            if (nid == null || nid.equals(id) || DONE.contains(nid)) return;
            if (wifiOnly && metered(ctx)) return;

            final Context app = ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx;
            synchronized (CanvasPreload.class) {
                if (pending != null) pending.cancel(false);
                pending = EXEC.schedule(new Runnable() {
                    @Override public void run() { work(app, wifiOnly, id, nid); }
                }, DEBOUNCE_MS, TimeUnit.MILLISECONDS);
            }
        } catch (Throwable t) {
            Log.w(TAG, "dispatch: " + t);
        }
    }

    private static void work(Context ctx, boolean wifiOnly, String id, String nid) {
        working = true;
        try {
            // Revisar que nada cambio durante la espera.
            Object queue = queue();
            if (queue == null) return;
            Object cur = call(queue, "l");
            Object next = call(queue, "x");
            if (cur == null || next == null || !id.equals(idOf(cur)) || !nid.equals(idOf(next))) return;
            if (wifiOnly && metered(ctx)) return;
            if (DONE.contains(nid)) return;

            String url = resolve(ctx, next);
            if (url == null || url.isEmpty()) {
                Log.d(TAG, "siguiente sin Canvas: " + nid);
                markDone(nid);
                return;
            }
            String low = url.toLowerCase();
            if (!(low.startsWith("http://") || low.startsWith("https://"))) { markDone(nid); return; }
            int q = low.indexOf('?');
            String path = q >= 0 ? low.substring(0, q) : low;
            if (path.endsWith(".m3u8")) {
                Log.d(TAG, "HLS no se precarga: " + url);
                markDone(nid);
                return;
            }
            if (!CanvasCache.allowed(url)) { // v0.20.201: solo Spotify y comunidad
                Log.d(TAG, "no es de Spotify/comunidad, no se precarga: " + url);
                markDone(nid);
                return;
            }
            long n = download(ctx, url);
            Log.d(TAG, "precargado " + n + " bytes: " + url);
            markDone(nid);
        } catch (Throwable t) {
            Log.w(TAG, "work: " + t);
        } finally {
            working = false;
        }
    }

    private static void markDone(String nid) {
        synchronized (DONE) {
            DONE.add(nid);
            while (DONE.size() > MAX_DONE) {
                java.util.Iterator<String> it = DONE.iterator();
                it.next();
                it.remove();
            }
        }
    }

    // ---------------------------------------------------------------- cola

    private static Class<?> er7;
    private static Field er7Instance;
    private static Method songId;

    private static Object queue() throws Exception {
        if (er7 == null) {
            Class<?> c = Class.forName("pu7");
            Field f = c.getDeclaredField("y");
            f.setAccessible(true);
            er7Instance = f;
            er7 = c;
        }
        return er7Instance.get(null);
    }

    private static Object call(Object target, String name) throws Exception {
        Method m = target.getClass().getDeclaredMethod(name);
        m.setAccessible(true);
        return m.invoke(target);
    }

    private static String idOf(Object song) {
        try {
            if (song == null) return null;
            if (songId == null) {
                Method m = song.getClass().getMethod("getId");
                songId = m;
            }
            Object v = songId.invoke(song);
            return v instanceof String ? (String) v : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static boolean metered(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm != null && cm.isActiveNetworkMetered();
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- resolver la URL

    private static String resolve(Context ctx, Object song) throws Exception {
        final String[] url = new String[1];
        final CountDownLatch done = new CountDownLatch(1);

        Class<?> q06c = Class.forName("j16");
        Class<?> kv1c = Class.forName("iw1");
        final Object emptyContext = Class.forName("wt2").getField("q").get(null);
        final Object unit = Class.forName("loa").getField("a").get(null);

        // j16 = MutableState: setValue(url).
        Object state = Proxy.newProxyInstance(q06c.getClassLoader(), new Class<?>[]{q06c}, new InvocationHandler() {
            @Override public Object invoke(Object proxy, Method m, Object[] args) {
                switch (m.getName()) {
                    case "setValue":
                        url[0] = args[0] instanceof String ? (String) args[0] : null;
                        return null;
                    case "getValue":
                        return url[0];
                    case "hashCode":
                        return System.identityHashCode(proxy);
                    case "equals":
                        return proxy == args[0];
                    case "toString":
                        return "CanvasPreloadState";
                    default:
                        return null;
                }
            }
        });
        // iw1 = Continuation sin dispatcher: avisa cuando termina (bien o con error).
        Object completion = Proxy.newProxyInstance(kv1c.getClassLoader(), new Class<?>[]{kv1c}, new InvocationHandler() {
            @Override public Object invoke(Object proxy, Method m, Object[] args) {
                switch (m.getName()) {
                    case "getContext":
                        return emptyContext;
                    case "resumeWith":
                        done.countDown();
                        return null;
                    case "hashCode":
                        return System.identityHashCode(proxy);
                    case "equals":
                        return proxy == args[0];
                    case "toString":
                        return "CanvasPreloadCompletion";
                    default:
                        return null;
                }
            }
        });

        Class<?> songC = Class.forName("com.eclipse.android.data.models.Song");
        Class<?> izC = Class.forName("p00");
        // p00(Song, Context, j16, iw1, int) con int = 5 deja r = 5: rama por defecto de invokeSuspend (si song != null: ux0.F -> setValue(url)).
        Constructor<?> k = izC.getConstructor(songC, Context.class, q06c, kv1c, int.class);
        Object iz = k.newInstance(song, ctx, state, completion, 5);
        izC.getMethod("resumeWith", Object.class).invoke(iz, unit);

        if (!done.await(RESOLVE_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
            Log.w(TAG, "tiempo agotado resolviendo el Canvas");
            return null;
        }
        return url[0];
    }

    // ---------------------------------------------------------------- bajar el video a la cache

    private static long download(Context ctx, String url) throws Exception {
        Object upstream = Class.forName("h34").getConstructor(Context.class).newInstance(ctx);
        Object factory = CanvasCache.build(ctx, upstream);
        if (factory == null) throw new IllegalStateException("sin cache de Eclipse");

        Object source = Class.forName("m42").getMethod("o0").invoke(factory);
        Class<?> y22 = Class.forName("p42");
        Class<?> g32 = Class.forName("x42");
        Constructor<?> k = g32.getConstructor(android.net.Uri.class, long.class, int.class, byte[].class,
                java.util.Map.class, long.class, long.class, String.class, int.class);
        // DataSpec(uri, offset 0, GET, sin cuerpo, sin headers, posicion 0, largo sin definir, clave por defecto, sin flags)
        Object spec = k.newInstance(android.net.Uri.parse(url), 0L, 1, null,
                Collections.emptyMap(), 0L, -1L, null, 0);

        Method open = y22.getMethod("c", g32);
        Method read = Class.forName("j42").getMethod("read", byte[].class, int.class, int.class);
        Method close = y22.getMethod("close");

        long total = 0;
        long deadline = System.nanoTime() + MAX_DOWNLOAD_MS * 1_000_000L;
        byte[] buf = new byte[64 * 1024];
        try {
            open.invoke(source, spec);
            while (total < MAX_BYTES && System.nanoTime() < deadline) {
                int n = (Integer) read.invoke(source, buf, 0, buf.length);
                if (n < 0) break;
                total += n;
            }
        } finally {
            try { close.invoke(source); } catch (Throwable ignored) {}
        }
        return total;
    }
}
