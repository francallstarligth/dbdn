package app.eclipse.extension.ai;

import java.nio.charset.StandardCharsets;

/**
 * Puente a Phonon (voz local de Gradium) por JNI. Todavia NO esta conectado a nada de Eclipse.
 * Las dos librerias (libphonon_jni.so y libptts_ffi.so) las baja la app al primer uso.
 * Todas las llamadas bloquean: usar fuera del hilo principal y desde un solo hilo a la vez.
 */
public final class PhononNative {
    private PhononNative() {}

    /** Recibe el audio (24 kHz, mono, float de -1 a 1). Devolver false para parar. */
    public interface Sink {
        boolean onAudio(float[] pcm, int n);
    }

    static native boolean nativeLoad(byte[] ffiPath);
    static native byte[] nativeLoadError();
    static native long nativeNew(byte[] dir, byte[] lang);
    static native boolean nativeSetVoice(long h, byte[] name);
    static native boolean nativeSetTemperature(long h, float t);
    static native byte[] nativeVoices(long h);
    static native boolean nativeSpeak(long h, byte[] text, Sink sink);
    static native byte[] nativeLastError(long h);
    static native void nativeFree(long h);

    private static byte[] b(String s) {
        return s.getBytes(StandardCharsets.UTF_8);
    }

    private static String s(byte[] a) {
        return a == null ? null : new String(a, StandardCharsets.UTF_8);
    }

    /** Carga el puente y la libreria de Phonon desde sus rutas completas. */
    public static void load(String bridgeSoPath, String ffiSoPath) {
        System.load(bridgeSoPath);
        if (!nativeLoad(b(ffiSoPath))) {
            throw new IllegalStateException("Phonon: " + s(nativeLoadError()));
        }
    }

    /** Abre el modelo (carpeta con config.json, tokenizer.json, model.q8.gguf, voz). Lento: hacerlo una vez. */
    public static long open(String modelDir, String lang) {
        long h = nativeNew(b(modelDir), b(lang));
        if (h == 0) throw new IllegalStateException("Phonon: " + s(nativeLastError(0)));
        return h;
    }

    public static void setVoice(long h, String name) {
        if (!nativeSetVoice(h, b(name))) throw new IllegalStateException("Phonon: " + s(nativeLastError(h)));
    }

    public static String[] voices(long h) {
        String v = s(nativeVoices(h));
        return (v == null || v.isEmpty()) ? new String[0] : v.split("\n");
    }

    /** Habla el texto y va entregando el audio a [sink]. Si [sink] devuelve false, para sin error. */
    public static void speak(long h, String text, Sink sink) {
        final boolean[] stopped = {false};
        Sink wrapped = (pcm, n) -> {
            boolean keep = sink.onAudio(pcm, n);
            if (!keep) stopped[0] = true;
            return keep;
        };
        if (!nativeSpeak(h, b(text), wrapped) && !stopped[0]) {
            throw new IllegalStateException("Phonon: " + s(nativeLastError(h)));
        }
    }

    public static void close(long h) {
        if (h != 0) nativeFree(h);
    }
}
