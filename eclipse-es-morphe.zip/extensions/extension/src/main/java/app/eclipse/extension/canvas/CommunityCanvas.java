package app.eclipse.extension.canvas;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/**
 * Fuente sin cuenta ni cookie: una lista publica hecha por la comunidad (cancion + artista -> video en bucle).
 * Formato del archivo: { "items": [ { "song": ..., "artist": ..., "album": ..., "url": "https://...mp4" }, ... ] }
 *
 * Es bloqueante (red): solo se llama desde el hilo de fondo de CanvasLookup. Nunca lanza excepciones.
 */
final class CommunityCanvas {
    private static final String TAG = "CommunityCanvas";

    /** No es final a proposito: las pruebas la cambian. */
    private static String manifestUrl = "https://vivimusicanvas.mkmdevilmi.workers.dev/canvas.json";

    private static final long TTL_MS = 30L * 60L * 1000L;
    private static final long RETRY_MS = 60_000L;
    private static final int TIMEOUT_MS = 8000;
    private static final int MAX_BYTES = 25 * 1024 * 1024;
    private static final String UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private static final class Entry {
        final String song;   // ya normalizado
        final String artist; // ya normalizado
        final String url;
        Entry(String song, String artist, String url) { this.song = song; this.artist = artist; this.url = url; }
    }

    private static volatile List<Entry> entries = Collections.emptyList();
    private static long fetchedAtMs = 0L;
    private static long retryAfterMs = 0L;

    private CommunityCanvas() {}

    /** true si la lista esta cargada (asi un "no esta" es una respuesta valida y no un fallo de red). */
    static boolean manifestLoaded() {
        return !entries.isEmpty();
    }

    /** @return URL https del video, o null. */
    static String lookup(String title, String artist) {
        try {
            List<Entry> list = manifest();
            if (list.isEmpty()) return null;
            String wantTitle = norm(title);
            String wantArtist = norm(artist);
            if (wantTitle.isEmpty() || wantArtist.isEmpty()) return null;
            String loose = null;
            for (Entry e : list) {
                if (!artistMatches(wantArtist, e.artist)) continue;
                if (e.song.equals(wantTitle)) return e.url; // coincidencia exacta: gana siempre
                if (loose == null && titleLooselyMatches(wantTitle, e.song)) loose = e.url;
            }
            return loose;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            return null;
        }
    }

    // ---------------------------------------------------------------- coincidencia

    private static boolean artistMatches(String want, String listed) {
        if (listed.isEmpty()) return false;
        if (want.equals(listed)) return true;
        // "Quevedo, Bizarrap" vs "Quevedo": uno contiene al otro (con minimo de largo para no emparejar por casualidad).
        if (Math.min(want.length(), listed.length()) < 3) return false;
        return want.contains(listed) || listed.contains(want);
    }

    private static boolean titleLooselyMatches(String want, String listed) {
        if (listed.isEmpty()) return false;
        if (Math.min(want.length(), listed.length()) < 6) return false;
        return want.contains(listed) || listed.contains(want);
    }

    // v1.54.0: patrones compilados una sola vez (norm se llama 2 veces por entrada al procesar la lista).
    private static final java.util.regex.Pattern ACCENTS = java.util.regex.Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
    private static final java.util.regex.Pattern NON_ALNUM = java.util.regex.Pattern.compile("[^a-z0-9\\s]");
    private static final java.util.regex.Pattern SPACES = java.util.regex.Pattern.compile("\\s+");

    static String norm(String s) {
        if (s == null) return "";
        String t = ACCENTS.matcher(Normalizer.normalize(s, Normalizer.Form.NFD)).replaceAll("");
        t = NON_ALNUM.matcher(t.toLowerCase(Locale.ROOT)).replaceAll(" ");
        return SPACES.matcher(t).replaceAll(" ").trim();
    }

    // ---------------------------------------------------------------- lista

    private static volatile boolean refreshing;

    /**
     * v1.54.0: si ya hay lista (aunque este vencida) se usa al instante y se actualiza en segundo plano; solo la
     * primera carga espera a la red. Antes, al vencer (cada 30 min) el cambio de cancion esperaba la descarga completa.
     */
    private static List<Entry> manifest() {
        List<Entry> cur = entries;
        if (cur.isEmpty()) return load(false);
        long now = System.currentTimeMillis();
        if (now - fetchedAtMs >= TTL_MS && now >= retryAfterMs && !refreshing) {
            refreshing = true;
            Thread t = new Thread(new Runnable() {
                @Override public void run() {
                    try { load(true); } finally { refreshing = false; }
                }
            }, "CommunityCanvasRefresh");
            t.setDaemon(true);
            t.start();
        }
        return cur;
    }

    private static synchronized List<Entry> load(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && !entries.isEmpty() && now - fetchedAtMs < TTL_MS) return entries;
        if (now < retryAfterMs) return entries;

        String body = httpGetText(manifestUrl);
        List<Entry> parsed = body == null ? Collections.<Entry>emptyList() : parse(body);
        if (parsed.isEmpty()) {
            retryAfterMs = now + RETRY_MS; // no insistir cada vez; se conserva la lista anterior si habia
            return entries;
        }
        entries = parsed;
        fetchedAtMs = now;
        Log.d(TAG, "lista cargada: " + parsed.size() + " entradas");
        return entries;
    }

    static List<Entry> parse(String body) {
        ArrayList<Entry> out = new ArrayList<Entry>();
        try {
            JSONArray items = new JSONObject(body).optJSONArray("items");
            if (items == null) return out;
            for (int i = 0; i < items.length(); i++) {
                JSONObject o = items.optJSONObject(i);
                if (o == null) continue;
                String url = o.optString("url", "").trim();
                if (!url.startsWith("https://")) continue; // solo https
                String song = norm(o.optString("song", ""));
                String artist = norm(o.optString("artist", ""));
                if (song.isEmpty() || artist.isEmpty()) continue;
                out.add(new Entry(song, artist, url));
            }
        } catch (Throwable t) {
            Log.w(TAG, "lista con formato inesperado: " + t);
            out.clear();
        }
        return out;
    }

    private static String httpGetText(String url) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                Log.d(TAG, "GET " + code);
                return null;
            }
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                int total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > MAX_BYTES) return null;
                    out.write(buf, 0, n);
                }
                return new String(out.toByteArray(), Charset.forName("UTF-8"));
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            Log.d(TAG, "GET error: " + t);
            return null;
        }
    }
}
