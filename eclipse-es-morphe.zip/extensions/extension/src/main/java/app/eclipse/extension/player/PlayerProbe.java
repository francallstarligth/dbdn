package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * DIAGNOSTICO (v1.97.3): copia al portapapeles la cadena de quien dibuja el reproductor grande. Se llama sin
 * argumentos al inicio de las 3 funciones que dibujan "PLAYING FROM" (r18.x, gm.i, oi9.f). En Compose los composables
 * se llaman unos a otros como metodos normales, asi que la pila de llamadas (Throwable) trae los "padres": de ahi se
 * saca la hoja que sube y baja. Se guardan hasta 6 cadenas DISTINTAS y cada vez que aparece una nueva se copia todo
 * al portapapeles (y un Toast corto avisa). Si algo falla, no hace nada.
 */
public final class PlayerProbe {
    private static final String TAG = "PlayerProbe";
    private static final List<String> seen = new ArrayList<String>();

    private PlayerProbe() {}

    // ---- v1.97.4: cambios de los interruptores de a43.c (a43.m / a43.r / a43.s devuelven un Boolean) ----
    private static final boolean[] lastBool = new boolean[3];
    private static final boolean[] haveBool = new boolean[3];
    private static final List<String> events = new ArrayList<String>();
    private static long t0;
    private static long lastToast;

    public static void boolM(boolean v) { bool(0, "m", v); }
    public static void boolR(boolean v) { bool(1, "r", v); }
    public static void boolS(boolean v) { bool(2, "s", v); }

    private static synchronized void bool(int i, String name, boolean v) {
        try {
            if (haveBool[i] && lastBool[i] == v) return;
            long now = SystemClock.uptimeMillis();
            if (t0 == 0) t0 = now;
            String first = haveBool[i] ? "" : " (primer valor)";
            haveBool[i] = true;
            lastBool[i] = v;
            events.add("t+" + (now - t0) + "ms  a43." + name + " = " + v + first);
            if (events.size() > 60) events.remove(0);
            final StringBuilder all = new StringBuilder("PlayerProbe v1.97.4 (interruptores de a43.c)");
            for (int k = 0; k < events.size(); k++) all.append("\n").append(events.get(k));
            Log.d(TAG, all.toString());
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            final boolean toast = now - lastToast > 4000;
            if (toast) lastToast = now;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("PlayerProbe", all.toString()));
                        if (toast) Toast.makeText(ctx, "Diagnostico copiado", Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) { }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "bool fallo", t);
        }
    }

    // ---- v1.97.5: posicion de la hoja del reproductor (dr8.a: desplazamiento / alto, 0..1) ----
    private static final class Ses {
        long start, last;
        int count;
        float first, lastV;
        StringBuilder sb = new StringBuilder();
    }
    private static final List<Ses> sesiones = new ArrayList<Ses>();
    private static final Handler H = new Handler(Looper.getMainLooper());
    private static Context posCtx;
    private static final Runnable COPIAR = new Runnable() {
        @Override public void run() { copiarPos(); }
    };

    public static synchronized void pos(float v) {
        try {
            long now = SystemClock.uptimeMillis();
            float r = Math.round(v * 1000f) / 1000f;
            Ses s = sesiones.isEmpty() ? null : sesiones.get(sesiones.size() - 1);
            if (s != null && now - s.last <= 1500) {
                if (s.lastV == r) return;
            } else {
                s = new Ses();
                s.start = now;
                s.first = r;
                sesiones.add(s);
                if (sesiones.size() > 4) sesiones.remove(0);
            }
            if (s.count < 60) s.sb.append("\n  +").append(now - s.start).append("ms ").append(r);
            s.count++;
            s.last = now;
            s.lastV = r;
            if (posCtx == null) {
                Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                if (app instanceof Context) posCtx = (Context) app;
            }
            H.removeCallbacks(COPIAR);
            H.postDelayed(COPIAR, 700);
        } catch (Throwable t) {
            Log.w(TAG, "pos fallo", t);
        }
    }

    private static synchronized void copiarPos() {
        try {
            StringBuilder all = new StringBuilder("PlayerProbe v1.97.5 (posicion de la hoja, dr8.a)");
            for (int i = 0; i < sesiones.size(); i++) {
                Ses s = sesiones.get(i);
                all.append("\n\nsesion ").append(i + 1).append(": ").append(s.count).append(" valores en ")
                        .append(s.last - s.start).append("ms").append(s.count > 60 ? " (solo los primeros 60)" : "")
                        .append(s.sb);
            }
            Log.d(TAG, all.toString());
            if (posCtx == null) return;
            ClipboardManager cm = (ClipboardManager) posCtx.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("PlayerProbe", all.toString()));
            Toast.makeText(posCtx, "Diagnostico copiado", Toast.LENGTH_SHORT).show();
        } catch (Throwable t) {
            Log.w(TAG, "copiarPos fallo", t);
        }
    }

    public static void hitA() { show("A r18.x"); }
    public static void hitB() { show("B gm.i"); }
    public static void hitC() { show("C oi9.f"); }
    public static void hitD() { show("D a43.c (host)"); }
    public static void hitE() { show("E lf2.r (Custom/Bitchord)"); }
    public static void hitF() { show("F q18.e"); }

    private static synchronized void show(String tag) {
        try {
            StackTraceElement[] st = new Throwable().getStackTrace();
            StringBuilder sb = new StringBuilder(tag);
            String prev = "";
            int n = 0;
            for (int i = 2; i < st.length && n < 40; i++) {
                String c = st[i].getClassName();
                if (c.startsWith("java.") || c.startsWith("android.") || c.startsWith("dalvik.")
                        || c.startsWith("kotlin.") || c.startsWith("com.android.")) continue;
                String item = c.substring(c.lastIndexOf('.') + 1) + "." + st[i].getMethodName();
                if (item.equals(prev)) continue;
                prev = item;
                sb.append("\n  ").append(item);
                n++;
            }
            String chain = sb.toString();
            if (seen.contains(chain) || seen.size() >= 6) return;
            seen.add(chain);
            final StringBuilder all = new StringBuilder("PlayerProbe v1.97.3");
            for (int i = 0; i < seen.size(); i++) all.append("\n\n#").append(i + 1).append(' ').append(seen.get(i));
            Log.d(TAG, all.toString());
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            final int count = seen.size();
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("PlayerProbe", all.toString()));
                        Toast.makeText(ctx, "Diagnostico copiado (" + count + ")", Toast.LENGTH_SHORT).show();
                    } catch (Throwable t) {
                        Log.w(TAG, "portapapeles", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "fallo", t);
        }
    }
}
