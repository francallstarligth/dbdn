package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * DIAGNOSTICO (v1.97.3): copia al portapapeles la cadena de quien dibuja el reproductor grande. Se llama sin
 * argumentos al inicio de las 3 funciones que dibujan "PLAYING FROM" (r18.x, gm.i, oi9.f). En Compose los composables
 * se llaman unos a otros como metodos normales, asi que la pila de llamadas (Throwable) trae los "padres": de ahi se
 * saca la hoja que sube y baja. Se guardan hasta 6 cadenas DISTINTAS y cada vez que aparece una nueva se copia todo
 * al portapapeles (y un Toast corto avisa). Si algo falla, no hace nada.
 */
public final class PlayerProbe {
    private static final String TAG = "PlayerProbe";
    private static final List<String> seen = new ArrayList<String>();

    private PlayerProbe() {}

    public static void hitA() { show("A r18.x"); }
    public static void hitB() { show("B gm.i"); }
    public static void hitC() { show("C oi9.f"); }
    public static void hitD() { show("D a43.c (host)"); }
    public static void hitE() { show("E lf2.r (Custom/Bitchord)"); }
    public static void hitF() { show("F q18.e"); }

    private static synchronized void show(String tag) {
        try {
            StackTraceElement[] st = new Throwable().getStackTrace();
            StringBuilder sb = new StringBuilder(tag);
            String prev = "";
            int n = 0;
            for (int i = 2; i < st.length && n < 40; i++) {
                String c = st[i].getClassName();
                if (c.startsWith("java.") || c.startsWith("android.") || c.startsWith("dalvik.")
                        || c.startsWith("kotlin.") || c.startsWith("com.android.")) continue;
                String item = c.substring(c.lastIndexOf('.') + 1) + "." + st[i].getMethodName();
                if (item.equals(prev)) continue;
                prev = item;
                sb.append("\n  ").append(item);
                n++;
            }
            String chain = sb.toString();
            if (seen.contains(chain) || seen.size() >= 6) return;
            seen.add(chain);
            final StringBuilder all = new StringBuilder("PlayerProbe v1.97.3");
            for (int i = 0; i < seen.size(); i++) all.append("\n\n#").append(i + 1).append(' ').append(seen.get(i));
            Log.d(TAG, all.toString());
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            final int count = seen.size();
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("PlayerProbe", all.toString()));
                        Toast.makeText(ctx, "Diagnostico copiado (" + count + ")", Toast.LENGTH_SHORT).show();
                    } catch (Throwable t) {
                        Log.w(TAG, "portapapeles", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "fallo", t);
        }
    }
}
