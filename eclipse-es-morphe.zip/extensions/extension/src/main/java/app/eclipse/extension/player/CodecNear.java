package app.eclipse.extension.player;

import android.app.Application;
import android.content.res.Resources;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * v0.20.403 (SIN COMPILAR NI PROBAR). Codec (capa Quality Badge) pegado al final del TEXTO REAL del titulo (Tocadiscos).
 *
 * Convencion de diseno: SOLO las capas (cualquier tipo: badge, imagen de capsula, forma) cuyo nombre empieza con "Codec" (ej. "Codec titulo") se mueve; las demas no se tocan.
 * Se pone con su borde izquierdo en el INICIO del titulo (borde izquierdo de la caja de Song Title).
 * El parche la corre en X el ancho real del texto del titulo + {@link #GAP_DP}. Si el titulo no cabe en su caja, el codec queda al final de la caja (el final visible del titulo).
 *
 * Como funciona (Eclipse 0.6.75):
 *  - {@link #fromState} (final de `Lh61.<init>`): lee `Song.title` y avisa con un estado de Compose propio (`Lxf8;.w`) para que la capa se redibuje.
 *  - {@link #dx} (final de la lambda de graphicsLayer `Lpr7;.invoke`, caso con `Loq3.e/p/i/m`): con la capa (Lv51) devuelve la traslacion X
 *    (se aplica con `Loq3;->r(F)V` = translationX; r->u en `Lmw8` es el 4o campo de la lista de GraphicsLayerScope). Para SONG_TITLE guarda la capa
 *    (transform `Lmv4` a=x, b=y, c=ancho en fraccion de pantalla; texto `Lspa` b=tamano, g=espaciado, h=mayusculas); para QUALITY_BADGE calcula el corrimiento.
 *  - Medida: Paint con la fuente Inter variable que trae el APK (la TTF mas grande de res/, 'wght' 700), tamano = fontSize * density (verificado a mano:
 *    "Jungle" 24,39 -> 213 px calculados contra 219 px en una captura de 1080 px de ancho; "Caida libre" 334 contra 337).
 * Si algo falla se queda el codec donde esta (dx = 0).
 */
public final class CodecNear {
    private CodecNear() {}

    /** Separacion entre el titulo y el codec (dp). */
    private static final float GAP_DP = 10f;

    private static volatile String title;
    private static volatile String format;
    private static volatile Object titleLayer;
    private static Object tick;
    private static Method getV, setV;
    private static int n;
    private static boolean broken;
    private static Handler main;
    private static Typeface face;
    private static boolean faceTried;
    private static Method kindM;
    private static float cacheW = Float.NaN;
    private static String cacheTitle;
    private static float cacheSize = -1f;

    private static synchronized Object tick() throws Exception {
        if (tick == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Integer.valueOf(0));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            getV = g;
            setV = st;
            main = new Handler(Looper.getMainLooper());
            tick = s;
        }
        return tick;
    }

    /** Lh61.<init>: foto del estado del reproductor (a = Song). */
    public static void fromState(Object h61) {
        try {
            if (broken || h61 == null) return;
            Field fa = h61.getClass().getDeclaredField("a");
            fa.setAccessible(true);
            Object song = fa.get(h61);
            String t = null;
            String fm = null;
            if (song != null) {
                try {
                    Object o = song.getClass().getMethod("getFormat").invoke(song);
                    if (o instanceof String) fm = (String) o;
                } catch (Throwable ignored) {
                }
                Field ft = song.getClass().getDeclaredField("title");
                ft.setAccessible(true);
                Object o = ft.get(song);
                if (o instanceof String) t = (String) o;
            }
            format = fm;
            String old = title;
            if (t == null ? old == null : t.equals(old)) return;
            title = t;
            tick();
            main.post(new Runnable() {
                @Override public void run() {
                    try {
                        setV.invoke(tick, Integer.valueOf(++n));
                    } catch (Throwable e) {
                        broken = true;
                    }
                }
            });
        } catch (Throwable e) {
            broken = true;
        }
    }

    private static String kind(Object layer) throws Exception {
        if (kindM == null) {
            Method m = layer.getClass().getDeclaredMethod("i");
            m.setAccessible(true);
            kindM = m;
        }
        Object k = kindM.invoke(layer);
        return k instanceof Enum ? ((Enum<?>) k).name() : "";
    }

    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    /** Fuente Inter del APK (la TTF mas grande de res/); si no se puede, la negrita del sistema. */
    private static Typeface face() {
        if (faceTried) return face;
        faceTried = true;
        Typeface t = Typeface.DEFAULT_BOLD;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Application app = (Application) at.getMethod("currentApplication").invoke(null);
            ZipFile z = new ZipFile(app.getPackageCodePath());
            ZipEntry best = null;
            Enumeration<? extends ZipEntry> en = z.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.getName().startsWith("res/") && e.getName().endsWith(".ttf") && (best == null || e.getSize() > best.getSize())) best = e;
            }
            if (best != null) {
                File out = new File(app.getCacheDir(), "codec_inter.ttf");
                if (!out.exists() || out.length() != best.getSize()) {
                    InputStream in = z.getInputStream(best);
                    FileOutputStream os = new FileOutputStream(out);
                    byte[] buf = new byte[16384];
                    int r;
                    while ((r = in.read(buf)) > 0) os.write(buf, 0, r);
                    os.close();
                    in.close();
                }
                Typeface v = new Typeface.Builder(out).setFontVariationSettings("'wght' 700").build();
                if (v != null) t = v;
            }
            z.close();
        } catch (Throwable e) {
            // se queda la negrita del sistema
        }
        face = t;
        return t;
    }

    private static float textWidth(String s, float sizePx) {
        if (s.equals(cacheTitle) && sizePx == cacheSize && !Float.isNaN(cacheW)) return cacheW;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setTypeface(face());
        p.setTextSize(sizePx);
        float w = p.measureText(s);
        cacheTitle = s;
        cacheSize = sizePx;
        cacheW = w;
        return w;
    }

    /**
     * El badge centra su contenido dentro de la capa: el texto empieza (anchoCapa - anchoContenido)/2 despues del borde izquierdo de la capa
     * (solo si el badge dibuja su propia capsula; si no, la capsula es otra capa y todas se mueven igual). Se resta para que el texto del codec quede pegado al titulo sin tocar el editor.
     * Contenido = texto del formato de la cancion (Inter 700, fontSize*1.15 sp) + 2*relleno. Si no se puede calcular, 0.
     */
    private static float slack(Object layer, float density, float screenW) {
        try {
            String fm = format;
            if (fm == null || fm.trim().isEmpty()) return 0f;
            Object cfg = field(layer, "s"); // Ltq0 (config del badge); null = valores por defecto (fontSize 12, relleno 8, con fondo)
            double fs = 12d, hp = 8d;
            boolean bg = true, up = true;
            if (cfg != null) {
                fs = ((Double) field(cfg, "e")).doubleValue();
                hp = ((Double) field(cfg, "h")).doubleValue();
                bg = Boolean.TRUE.equals(field(cfg, "a"));
                up = Boolean.TRUE.equals(field(cfg, "g"));
            }
            Object tr = field(layer, "d");
            double lw = ((Double) field(tr, "c")).doubleValue() * screenW;
            String txt = up ? fm.trim().toUpperCase() : fm.trim();
            float sp = Resources.getSystem().getDisplayMetrics().scaledDensity;
            Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
            p.setTypeface(face());
            p.setTextSize((float) (fs * 1.15d) * sp);
            float tw = p.measureText(txt);
            float pad = (float) hp * density;
            float content = tw + 2f * pad;
            float sl = ((float) lw - content) / 2f;
            return bg ? sl : 0f; // sin fondo propio la capsula es otra capa (misma caja): todas se mueven igual y el texto sigue centrado en ella
        } catch (Throwable e) {
            return 0f;
        }
    }

    /**
     * Lpr7.invoke: traslacion X de la capa (px). 0 para todo lo que no sea el codec.
     * @param layer Lv51 (la capa)
     */
    public static float dx(Object layer) {
        try {
            if (broken || layer == null) return 0f;
            String k = kind(layer);
            if ("SONG_TITLE".equals(k)) {
                titleLayer = layer;
                return 0f;
            }
            Object nm = field(layer, "c"); // nombre de la capa: se mueve CUALQUIER tipo de capa (badge, imagen, forma) cuyo nombre empiece con "Codec"
            if (!(nm instanceof String) || !((String) nm).trim().toLowerCase().startsWith("codec")) return 0f;
            tick();
            getV.invoke(tick); // lectura de estado de Compose: se redibuja cuando cambia el titulo
            String t = title;
            Object tl = titleLayer;
            if (t == null || tl == null) return 0f;
            Object cfg = field(tl, "f");   // Lspa (texto)
            Object tr = field(tl, "d");    // Lmv4 (a=x, b=y, c=ancho, d=alto, e=giro)
            if (cfg == null || tr == null) return 0f;
            double size = field(cfg, "b") instanceof Double ? ((Double) field(cfg, "b")).doubleValue() : 0d;
            double ls = field(cfg, "g") instanceof Double ? ((Double) field(cfg, "g")).doubleValue() : 0d;
            boolean up = Boolean.TRUE.equals(field(cfg, "h"));
            double wFrac = ((Double) field(tr, "c")).doubleValue();
            if (size <= 0d || wFrac <= 0d) return 0f;
            float density = Resources.getSystem().getDisplayMetrics().density;
            float screenW = Resources.getSystem().getDisplayMetrics().widthPixels;
            String s = up ? t.toUpperCase() : t;
            float w = textWidth(s, (float) size * density) + (float) ls * density * s.length();
            float box = (float) wFrac * screenW;
            float shift = (w < box ? w : box) + GAP_DP * density; // si el titulo no cabe (marquesina), el final visible es el final de la caja
            return shift - slack(layer, density, screenW);
        } catch (Throwable e) {
            broken = true;
            return 0f;
        }
    }
}
