package app.eclipse.extension.artwork;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;

/**
 * Mantiene la vista de la portada animada (un PlayerView) casi invisible hasta que el video dibuja su primer cuadro,
 * y entonces la muestra con un fundido. Mientras tanto se ve la portada fija de abajo.
 * El primer cuadro se detecta cuando la "cortina" (exo_shutter) del PlayerView deja de estar visible.
 * Si algo falla o no llega el primer cuadro en 10 s, la vista se muestra igual (comportamiento de siempre).
 */
public final class CoverFade {
    private static final long POLL_MS = 33L;
    private static final long TIMEOUT_MS = 10000L;
    private static final long FADE_MS = 250L;

    private CoverFade() {}

    public static void prepare(final View view) {
        try {
            app.eclipse.extension.canvas.CanvasCenter.attach(view); // v1.35.0: centra Canvas verticales
        } catch (Throwable ignored) {}
        try {
            final View shutter = findShutter(view);
            if (shutter == null) return; // sin cambios

            view.setAlpha(0.01f);
            final long start = SystemClock.uptimeMillis();
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        boolean ready = shutter.getVisibility() != View.VISIBLE;
                        boolean timedOut = SystemClock.uptimeMillis() - start > TIMEOUT_MS;
                        if (ready || timedOut) {
                            view.animate().alpha(1f).setDuration(FADE_MS).start();
                            return;
                        }
                        handler.postDelayed(this, POLL_MS);
                    } catch (Throwable t) {
                        try { view.setAlpha(1f); } catch (Throwable ignored) {}
                    }
                }
            });
        } catch (Throwable t) {
            try { view.setAlpha(1f); } catch (Throwable ignored) {}
        }
    }

    private static View findShutter(View view) {
        int id = view.getResources().getIdentifier("exo_shutter", "id", view.getContext().getPackageName());
        return id == 0 ? null : view.findViewById(id);
    }
}
