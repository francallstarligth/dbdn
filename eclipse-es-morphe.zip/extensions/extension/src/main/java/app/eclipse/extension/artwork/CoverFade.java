package app.eclipse.extension.artwork;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Mantiene la vista de la portada animada (un PlayerView) casi invisible hasta que el video dibuja su primer cuadro,
 * y entonces la muestra con un fundido. Mientras tanto se ve la portada fija de abajo.
 * El primer cuadro se detecta cuando la "cortina" (exo_shutter) del PlayerView deja de estar visible.
 * Si algo falla o no llega el primer cuadro en 10 s, la vista se muestra igual (comportamiento de siempre).
 *
 * v1.56.0: si se conoce la portada de la cancion (CoverUnderlay), se pone encima del video, a pantalla completa, y se
 * desvanece al llegar el primer cuadro: cruce portada -> video en vez de hueco + video. Sin portada conocida, igual que antes.
 */
public final class CoverFade {
    private static final long POLL_MS = 33L;
    private static final long TIMEOUT_MS = 10000L;
    private static final long FADE_MS = 400L;

    /** v0.20.7: el video (de cualquier fuente: Tidal, Apple, comunidad, Spotify) espera este tiempo con la portada a la vista. */
    private static final long SHOW_DELAY_MS = 1000L; // v0.20.262: antes 1800
    /** Dos vistas de la misma cancion creadas dentro de esta ventana (nitido + reflejo) comparten la misma hora de salida. */
    private static final long SAME_SONG_WINDOW_MS = 8000L;
    private static int delaySeq = -1;     // v0.20.12: cambio de cancion (CoverUnderlay.songSeq) al que se aplico el retraso
    private static long delayStart;       // cuando se creo la primera vista de esa cancion
    private static long delayReadyAt;     // hora (uptimeMillis) desde la que el video puede salir

    /**
     * v0.20.13: BlurredCanvasBackground lo pone en true justo antes de crear el video del REFLEJO. La vista que se cree
     * en ese momento no lleva la portada puesta encima: se ve el reflejo normal de abajo (el de las canciones sin Canvas)
     * hasta que sale el video con fundido.
     */
    public static volatile boolean reflectionNext;

    /**
     * v0.20.56: reflejo liviano del Canvas. BlurredCanvasBackground deja aqui el factor de reduccion (k) y el tamano en px
     * de la vista chica. La vista del video se crea DESPUES de la composicion (no se puede avisar con una marca), asi que
     * se reconoce por su tamano: si mide lo mismo que la caja chica, es el reflejo liviano.
     */
    public static volatile float lightK = 1f;
    public static volatile int lightWpx, lightHpx;

    /** Factor de reduccion de una vista de w x h px: lightK si coincide con la caja chica del reflejo liviano; si no, 1. */
    public static float kFor(int w, int h) {
        float k = lightK;
        if (k > 1f && Math.abs(w - lightWpx) <= 3 && Math.abs(h - lightHpx) <= 3) return k;
        return 1f;
    }

    /** v0.20.15: lo enciende el parche "Canvas: mantener el fondo anterior (reflejo)" (gancho al inicio de xi6.h). Apagado = v0.20.11. */
    private static volatile boolean keepBg;

    public static void enableKeepBg() { keepBg = true; }

    private CoverFade() {}

    /**
     * Hora desde la que puede salir el video de esta vista; 0 = sin retraso (misma cancion, al salir y volver).
     * v0.20.12: se decide por CAMBIO REAL DE CANCION, no por la URL de la portada (canciones del mismo album la comparten).
     */
    private static synchronized long readyAtFor(long now) {
        try {
            int seq = CoverUnderlay.songSeq();
            if (seq == delaySeq) {
                if (now - delayStart < SAME_SONG_WINDOW_MS) return delayReadyAt;
                return 0L;
            }
            delaySeq = seq;
            delayStart = now;
            delayReadyAt = now + SHOW_DELAY_MS;
            return delayReadyAt;
        } catch (Throwable t) {
            return 0L;
        }
    }

    public static void prepare(final View view) {
        try {
            app.eclipse.extension.canvas.CanvasCenter.attach(view); // v1.35.0: centra Canvas verticales
        } catch (Throwable ignored) {}
        try {
            final View shutter = findShutter(view);
            if (shutter == null) return; // sin cambios

            // v0.20.15: refl[0] = esta vista es el REFLEJO (fondo borroso): no lleva la portada encima y sale con fundido.
            final boolean[] refl = new boolean[1];
            refl[0] = keepBg && reflectionNext;
            final View overlay = refl[0] ? null : installUnderlay(view, refl);
            if (overlay == null) view.setAlpha(0.01f);
            final long start = SystemClock.uptimeMillis();
            final long readyAt = readyAtFor(start);
            try {
                PrevCover.trace("CoverFade.prepare esReflejo=" + refl[0] + " conPortadaEncima=" + (overlay != null) + " retraso=" + (readyAt - start) + "ms");
            } catch (Throwable ignored) {}
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        boolean ready = shutter.getVisibility() != View.VISIBLE
                                && SystemClock.uptimeMillis() >= readyAt;
                        boolean timedOut = SystemClock.uptimeMillis() - start > TIMEOUT_MS;
                        if (ready || timedOut) {
                            try {
                                PrevCover.trace("CoverFade sale esReflejo=" + refl[0] + " " + (overlay != null && !refl[0] ? "portada->video (fundido)" : "video aparece (alpha)")
                                        + " tras " + (SystemClock.uptimeMillis() - start) + "ms" + (timedOut ? " (TIMEOUT)" : ""));
                            } catch (Throwable ignored) {}
                            if (overlay != null && !refl[0]) fadeOutOverlay(view, overlay);
                            else {
                                if (overlay != null) removeOverlay(view, overlay);
                                view.animate().alpha(1f).setDuration(FADE_MS).start();
                            }
                            return;
                        }
                        handler.postDelayed(this, POLL_MS);
                    } catch (Throwable t) {
                        try { view.setAlpha(1f); } catch (Throwable ignored) {}
                        try { if (overlay != null) removeOverlay(view, overlay); } catch (Throwable ignored) {}
                    }
                }
            });
        } catch (Throwable t) {
            try { view.setAlpha(1f); } catch (Throwable ignored) {}
        }
    }

    /** Pone la portada de la cancion encima del PlayerView. Devuelve esa vista, o null si no se pudo (queda el comportamiento anterior). */
    private static View installUnderlay(final View view, final boolean[] refl) {
        try {
            String url = CoverUnderlay.currentUrl();
            if (url == null || !(view instanceof ViewGroup)) return null;
            final View overlay = new View(view.getContext());
            overlay.setBackground(new CoverUnderlay.CoverDrawable(url));
            if (keepBg) {
                // v0.20.15: si al medirse la vista es el REFLEJO (mas ancha que la pantalla), se le quita la portada de
                // encima y se deja casi transparente hasta que salga el video (igual que el caso marcado de antes).
                overlay.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
                    @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int orr, int ob) {
                        try {
                            int w = r - l;
                            if (w <= 0) return;
                            v.removeOnLayoutChangeListener(this);
                            int screen = v.getResources().getDisplayMetrics().widthPixels;
                            if (w > screen + 8 || kFor(w, b - t) > 1f) { // v0.20.56: o es el reflejo liviano (caja chica)
                                refl[0] = true;
                                v.setBackground(null);
                                view.setAlpha(0.01f);
                            }
                        } catch (Throwable ignored) {}
                    }
                });
            }
            overlay.setClickable(false);
            ((ViewGroup) view).addView(overlay, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return overlay;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void fadeOutOverlay(final View view, final View overlay) {
        overlay.animate().alpha(0f).setDuration(FADE_MS).withEndAction(new Runnable() {
            @Override public void run() { removeOverlay(view, overlay); }
        }).start();
    }

    private static void removeOverlay(View view, View overlay) {
        try { ((ViewGroup) view).removeView(overlay); } catch (Throwable ignored) {}
    }

    private static View findShutter(View view) {
        int id = view.getResources().getIdentifier("exo_shutter", "id", view.getContext().getPackageName());
        return id == 0 ? null : view.findViewById(id);
    }
}
