package app.eclipse.extension.artwork;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Mantiene la vista de la portada animada (un PlayerView) casi invisible hasta que el video dibuja su primer cuadro,
 * y entonces la muestra con un fundido. Mientras tanto se ve la portada fija de abajo.
 * El primer cuadro se detecta cuando la "cortina" (exo_shutter) del PlayerView deja de estar visible.
 * Si algo falla o no llega el primer cuadro en 10 s, la vista se muestra igual (comportamiento de siempre).
 *
 * v1.56.0: si se conoce la portada de la cancion (CoverUnderlay), se pone encima del video, a pantalla completa, y se
 * desvanece al llegar el primer cuadro: cruce portada -> video en vez de hueco + video. Sin portada conocida, igual que antes.
 */
public final class CoverFade {
    private static final long POLL_MS = 33L;
    private static final long TIMEOUT_MS = 10000L;
    private static final long FADE_MS = 400L;

    /** v0.20.7: el video (de cualquier fuente: Tidal, Apple, comunidad, Spotify) espera este tiempo con la portada a la vista. */
    private static final long SHOW_DELAY_MS = 1800L;
    /** Dos vistas de la misma cancion creadas dentro de esta ventana (nitido + reflejo) comparten la misma hora de salida. */
    private static final long SAME_SONG_WINDOW_MS = 8000L;
    private static String delayUrl;       // portada de la cancion para la que se aplico el retraso
    private static long delayStart;       // cuando se creo la primera vista de esa cancion
    private static long delayReadyAt;     // hora (uptimeMillis) desde la que el video puede salir

    private CoverFade() {}

    /** Hora desde la que puede salir el video de esta vista; 0 = sin retraso (misma cancion, al salir y volver). */
    private static synchronized long readyAtFor(long now) {
        try {
            String url = CoverUnderlay.currentUrl();
            if (url != null && url.equals(delayUrl)) {
                if (now - delayStart < SAME_SONG_WINDOW_MS) return delayReadyAt;
                return 0L;
            }
            delayUrl = url;
            delayStart = now;
            delayReadyAt = now + SHOW_DELAY_MS;
            return delayReadyAt;
        } catch (Throwable t) {
            return 0L;
        }
    }

    public static void prepare(final View view) {
        try {
            app.eclipse.extension.canvas.CanvasCenter.attach(view); // v1.35.0: centra Canvas verticales
        } catch (Throwable ignored) {}
        try {
            final View shutter = findShutter(view);
            if (shutter == null) return; // sin cambios

            final View overlay = installUnderlay(view);
            if (overlay == null) view.setAlpha(0.01f);
            final long start = SystemClock.uptimeMillis();
            final long readyAt = readyAtFor(start);
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        boolean ready = shutter.getVisibility() != View.VISIBLE
                                && SystemClock.uptimeMillis() >= readyAt;
                        boolean timedOut = SystemClock.uptimeMillis() - start > TIMEOUT_MS;
                        if (ready || timedOut) {
                            if (overlay != null) fadeOutOverlay(view, overlay);
                            else view.animate().alpha(1f).setDuration(FADE_MS).start();
                            return;
                        }
                        handler.postDelayed(this, POLL_MS);
                    } catch (Throwable t) {
                        try { view.setAlpha(1f); } catch (Throwable ignored) {}
                        try { if (overlay != null) removeOverlay(view, overlay); } catch (Throwable ignored) {}
                    }
                }
            });
        } catch (Throwable t) {
            try { view.setAlpha(1f); } catch (Throwable ignored) {}
        }
    }

    /** Pone la portada de la cancion encima del PlayerView. Devuelve esa vista, o null si no se pudo (queda el comportamiento anterior). */
    private static View installUnderlay(View view) {
        try {
            String url = CoverUnderlay.currentUrl();
            if (url == null || !(view instanceof ViewGroup)) return null;
            View overlay = new View(view.getContext());
            overlay.setBackground(new CoverUnderlay.CoverDrawable(url));
            overlay.setClickable(false);
            ((ViewGroup) view).addView(overlay, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return overlay;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void fadeOutOverlay(final View view, final View overlay) {
        overlay.animate().alpha(0f).setDuration(FADE_MS).withEndAction(new Runnable() {
            @Override public void run() { removeOverlay(view, overlay); }
        }).start();
    }

    private static void removeOverlay(View view, View overlay) {
        try { ((ViewGroup) view).removeView(overlay); } catch (Throwable ignored) {}
    }

    private static View findShutter(View view) {
        int id = view.getResources().getIdentifier("exo_shutter", "id", view.getContext().getPackageName());
        return id == 0 ? null : view.findViewById(id);
    }
}
