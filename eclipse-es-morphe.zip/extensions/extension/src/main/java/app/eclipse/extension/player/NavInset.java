package app.eclipse.extension.player;

/**
 * v0.20.421 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL). Margen de abajo del "area segura" del reproductor grande.
 * Con navegacion por botones el sistema da ~48 dp abajo (con gestos, bastante menos); el reproductor ancla sus controles
 * a ese margen y por eso suben y pisan el titulo. fix() recibe el margen de abajo en dp (gancho en zs7.f, justo despues de
 * convertirlo de pixeles a dp) y, si parece la barra de botones (>= 40 dp), lo cambia por 0 (igual que con los botones escondidos, v0.20.422).
 * Gestos (< 40 dp) y botones escondidos (0 dp) quedan igual. Es puro calculo: no toca ninguna barra ni reloj.
 */
public final class NavInset {
    private static final float UMBRAL_BOTONES_DP = 40f;
    private static final float MARGEN_GESTOS_DP = 0f;

    private NavInset() {}

    public static float fix(float bottomDp) {
        return bottomDp >= UMBRAL_BOTONES_DP ? MARGEN_GESTOS_DP : bottomDp;
    }
}
