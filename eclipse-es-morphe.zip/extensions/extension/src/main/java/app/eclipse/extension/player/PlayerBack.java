package app.eclipse.extension.player;

import android.util.Log;
import android.view.Choreographer;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Gesto de retroceder del reproductor grande, estilo Bitchord (v1.98.2 probado; v1.98.3 sin diagnostico). Mientras el
 * usuario mantiene el gesto predictivo, el reproductor se achica segun el progreso (hasta ~0.90); si cancela vuelve a
 * su tamano; si suelta, sigue el cierre normal de Eclipse. Piezas:
 *  - evento/cancelado: enganchados al inicio de rh0.c/rh0.d/rh0.a (el BackHandler de Compose). Solo se atiende el
 *    BackHandler del reproductor: el de a43.c (onBack = ud q=5) o el de zg4.g (onBack = wq4 q=15).
 *  - jr: gancho en dr8.a que guarda el estado interno del jr (igual que PlayerEnter). Escribir un valor pequenho
 *    ahi (progreso * 0.5 px) hace recomponer dr8.a.
 *  - wrap: gancho en dr8.a tras el alpha; si escala < 1 aplica un graphicsLayer(scaleX, scaleY) por reflexion (vd9.F).
 * Todo con reflexion y try/catch: si algo no coincide, no hace nada.
 */
public final class PlayerBack {
    private static final String TAG = "PlayerBack";
    private static final float ACHICAR_MAX = 0.10f;      // escala final 0.90
    private static final long VUELTA_NS = 160_000_000L;  // volver a tamano normal al cancelar
    // mascara de vd9.F: 520187 original (alpha dado); ahora scaleX/scaleY dados (bits 0,1 a 0) y alpha por defecto (bit 2 a 1)
    private static final int MASCARA = (520187 | 4) & ~3;

    private static WeakReference<Object> ultimoJr;
    private static Object estado;   // c56 (MutableState<Float>) del jr actual
    private static Method setValue;
    private static float escala = 1f;
    private static float progreso = 0f;
    private static int generacion;

    private static Method capa;
    private static boolean capaFallo;
    private static Field campoD, campoC, campoQ, campoProgreso;

    private PlayerBack() {}

    /** dr8.a, tras leer jr.d(): guarda el estado del jr; si es una hoja nueva, vuelve a tamano normal. */
    public static void jr(Object jr) {
        try {
            if (jr == null) return;
            Object prev = ultimoJr == null ? null : ultimoJr.get();
            if (prev == jr) return;
            ultimoJr = new WeakReference<Object>(jr);
            generacion++;
            escala = 1f;
            progreso = 0f;
            Field fc = jr.getClass().getDeclaredField("c");
            fc.setAccessible(true);
            Object ps = fc.get(jr);
            Field fr = ps.getClass().getDeclaredField("r");
            fr.setAccessible(true);
            Object st = fr.get(ps);
            setValue = st.getClass().getMethod("setValue", Object.class);
            estado = st;
        } catch (Throwable t) {
            Log.w(TAG, "jr fallo", t);
        }
    }

    /** dr8.a, tras el alpha: aplica la escala del gesto (o devuelve el modifier tal cual). */
    public static Object wrap(Object mod) {
        try {
            float s = escala;
            if (mod == null || s >= 0.9999f || capaFallo) return mod;
            if (capa == null) {
                Class<?> vd9 = Class.forName("vd9");
                Class<?> mh5 = Class.forName("mh5");
                Class<?> ny7 = Class.forName("ny7");
                Class<?> zl0 = Class.forName("zl0");
                Method m = vd9.getDeclaredMethod("F", mh5, float.class, float.class, float.class, float.class,
                        ny7, zl0, int.class);
                m.setAccessible(true);
                capa = m;
            }
            Float f = Float.valueOf(s);
            return capa.invoke(null, mod, f, f, Float.valueOf(1f), Float.valueOf(0f), null, null,
                    Integer.valueOf(MASCARA));
        } catch (Throwable t) {
            capaFallo = true;
            Log.w(TAG, "wrap fallo", t);
            return mod;
        }
    }

    /** rh0.c / rh0.d (inicio y progreso del gesto): recibe el BackHandler (rh0) y el evento (cr5). */
    public static void evento(Object rh0, Object ev) {
        try {
            if (!esDelReproductor(rh0)) return;
            if (campoProgreso == null) {
                campoProgreso = ev.getClass().getDeclaredField("b"); // cr5.b = progress
                campoProgreso.setAccessible(true);
            }
            float p = campoProgreso.getFloat(ev);
            if (p < 0f) p = 0f;
            if (p > 1f) p = 1f;
            generacion++; // cancela una vuelta en curso
            aplicar(p);
        } catch (Throwable t) {
            Log.w(TAG, "evento fallo", t);
        }
    }

    /** rh0.a (gesto cancelado): vuelve al tamano normal con una animacion corta. */
    public static void cancelado(Object rh0) {
        try {
            if (!esDelReproductor(rh0)) return;
            final int gen = ++generacion;
            final float p0 = progreso;
            if (p0 <= 0f) {
                aplicar(0f);
                return;
            }
            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
                private long inicio;
                @Override public void doFrame(long ahora) {
                    try {
                        if (gen != generacion) return;
                        if (inicio == 0) inicio = ahora;
                        float t = (ahora - inicio) / (float) VUELTA_NS;
                        if (t >= 1f) {
                            aplicar(0f);
                            return;
                        }
                        float u = 1f - t;
                        aplicar(p0 * u * u);
                        Choreographer.getInstance().postFrameCallback(this);
                    } catch (Throwable th) {
                        Log.w(TAG, "vuelta fallo", th);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "cancelado fallo", t);
        }
    }

    private static void aplicar(float p) throws Exception {
        progreso = p;
        escala = 1f - ACHICAR_MAX * p;
        // escribir un valor distinto en el estado del jr hace recomponer dr8.a (ahi se lee `escala`)
        if (estado != null && setValue != null) setValue.invoke(estado, Float.valueOf(p * 0.5f));
    }

    /** true si ese rh0 es el BackHandler del reproductor: rh0.d (jh1) -> jh1.c (onBack) es wq4 q=15 o ud q=5. */
    private static boolean esDelReproductor(Object rh0) {
        try {
            if (rh0 == null) return false;
            if (campoD == null) {
                campoD = rh0.getClass().getDeclaredField("d");
                campoD.setAccessible(true);
            }
            Object n5 = campoD.get(rh0);
            if (n5 == null) return false;
            if (campoC == null) {
                campoC = n5.getClass().getDeclaredField("c");
                campoC.setAccessible(true);
            }
            Object onBack = campoC.get(n5);
            if (onBack == null) return false;
            String cn = onBack.getClass().getName();
            int objetivo;
            if ("wq4".equals(cn)) objetivo = 15;       // BackHandler de zg4.g
            else if ("ud".equals(cn)) objetivo = 5;    // BackHandler de a43.c (la pantalla del reproductor)
            else return false;
            if (campoQ == null || campoQ.getDeclaringClass() != onBack.getClass()) {
                campoQ = onBack.getClass().getDeclaredField("q");
                campoQ.setAccessible(true);
            }
            return campoQ.getInt(onBack) == objetivo;
        } catch (Throwable t) {
            return false;
        }
    }
}
