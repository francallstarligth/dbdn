package app.eclipse.extension.audio;

import android.content.Context;

import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * v0.20.453 (SIN COMPILAR NI PROBAR): primera cancion mas rapida.
 * (1) `warm()` se llama al inicio de EclipseApplication.onCreate: en un hilo aparte resuelve el DNS y abre una conexion HTTPS a
 *     api.eclipsemusic.app (por donde Eclipse pide al addon), para que la primera cancion no pague esa primera conexion. Si falla, no pasa nada.
 * (2) `get/put` guardan en memoria lo que resuelve Ljh0;->W (addon + cancion + texto -> EclipseAddonTrack). Si la misma cancion se
 *     vuelve a resolver (repetir, volver atras), sale al instante. Clave = addon + id de la cancion + texto; guarda max. 300 y 6 horas.
 */
public final class FirstSong {
    private static final long TTL_MS = 6L * 60 * 60 * 1000;
    private static final int MAX = 300;
    private static final Object LOCK = new Object();
    private static boolean warmed = false;

    private static final class Hit {
        final Object track;
        final long at;
        Hit(Object track, long at) { this.track = track; this.at = at; }
    }

    private static final Map<String, Hit> CACHE = new LinkedHashMap<String, Hit>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Hit> eldest) { return size() > MAX; }
    };

    private FirstSong() {}

    public static void warm(final Context ctx) {
        try {
            synchronized (LOCK) {
                if (warmed) return;
                warmed = true;
            }
            Thread th = new Thread(new Runnable() {
                @Override public void run() { doWarm(ctx); }
            }, "FirstSongWarm");
            th.setDaemon(true);
            th.start();
        } catch (Throwable ignored) {
        }
    }

    /** v0.20.456: lee la lista de addons instalados (Ldb2;->j(ctx).a() por reflexion) para que su carga en frio no caiga en la 1a cancion. */
    private static void warmAddons(Context ctx) {
        try {
            if (ctx == null) return;
            Class<?> hv2 = Class.forName("hv2");
            Object companion = hv2.getField("e").get(null);
            Method j = companion.getClass().getMethod("j", Context.class);
            Object repo = j.invoke(companion, ctx.getApplicationContext());
            if (repo != null) repo.getClass().getMethod("a").invoke(repo);
        } catch (Throwable ignored) {
        }
    }

    private static void doWarm(Context ctx) {
        try {
            InetAddress.getAllByName("api.eclipsemusic.app");
        } catch (Throwable ignored) {
        }
        warmAddons(ctx);
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://api.eclipsemusic.app/").openConnection();
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            c.getResponseCode();
        } catch (Throwable ignored) {
        } finally {
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) { }
        }
    }

    private static Object call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        return m.invoke(o);
    }

    private static String key(Object addon, Object song, Object text) {
        try {
            if (addon == null || song == null) return null;
            Object manifest = call(addon, "getManifest");
            Object name = manifest == null ? null : call(manifest, "getName");
            Object id = call(song, "getId");
            if (id == null) return null;
            return name + "|" + id + "|" + text;
        } catch (Throwable t) {
            return null;
        }
    }

    public static Object get(Object addon, Object song, Object text) {
        try {
            String k = key(addon, song, text);
            if (k == null) return null;
            synchronized (CACHE) {
                Hit e = CACHE.get(k);
                if (e == null) return null;
                if (System.currentTimeMillis() - e.at > TTL_MS) {
                    CACHE.remove(k);
                    return null;
                }
                return e.track;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    public static void put(Object addon, Object song, Object text, Object track) {
        try {
            if (track == null) return;
            String k = key(addon, song, text);
            if (k == null) return;
            synchronized (CACHE) {
                CACHE.put(k, new Hit(track, System.currentTimeMillis()));
            }
        } catch (Throwable ignored) {
        }
    }
}
