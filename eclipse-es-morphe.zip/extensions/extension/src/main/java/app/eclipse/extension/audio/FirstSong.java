package app.eclipse.extension.audio;

import android.content.Context;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * v0.20.457 (SIN COMPILAR NI PROBAR): `warm` ahora calienta TIDO (los addons activos que reproducen), no solo api.eclipsemusic.app:
 *     saca la lista de addons instalados, y por cada uno (max. 3) hace DNS a su baseURL, pide el token de acceso con `Lgv2;->d` (lo guarda en `Lnb;->a`,
 *     5 min) y hace un primer pedido con el MISMO cliente de red de Eclipse (`Lgv2;->c`, via `Lbj8`) para que la conexion quede en su pool.
 * v0.20.453 (SIN COMPILAR NI PROBAR): primera cancion mas rapida.
 * (1) `warm()` se llama al inicio de EclipseApplication.onCreate: en un hilo aparte resuelve el DNS y abre una conexion HTTPS a
 *     api.eclipsemusic.app (por donde Eclipse pide al addon), para que la primera cancion no pague esa primera conexion. Si falla, no pasa nada.
 * (2) `get/put` guardan en memoria lo que resuelve Ljh0;->W (addon + cancion + texto -> EclipseAddonTrack). Si la misma cancion se
 *     vuelve a resolver (repetir, volver atras), sale al instante. Clave = addon + id de la cancion + texto; guarda max. 300 y 6 horas.
 */
public final class FirstSong {
    private static final long TTL_MS = 6L * 60 * 60 * 1000;
    private static final int MAX = 300;
    private static final Object LOCK = new Object();
    private static boolean warmed = false;

    private static final class Hit {
        final Object track;
        final long at;
        Hit(Object track, long at) { this.track = track; this.at = at; }
    }

    private static final Map<String, Hit> CACHE = new LinkedHashMap<String, Hit>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Hit> eldest) { return size() > MAX; }
    };

    private FirstSong() {}

    public static void warm(final Context ctx) {
        try {
            synchronized (LOCK) {
                if (warmed) return;
                warmed = true;
            }
            Thread th = new Thread(new Runnable() {
                @Override public void run() { doWarm(ctx); }
            }, "FirstSongWarm");
            th.setDaemon(true);
            th.start();
        } catch (Throwable ignored) {
        }
    }

    private static Method find(Class<?> c, String name, Class<?>... args) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                Method m = k.getDeclaredMethod(name, args);
                m.setAccessible(true);
                return m;
            } catch (NoSuchMethodException ignored) {
            }
        }
        return null;
    }

    private static Object invoke(Object o, String name) throws Exception {
        if (o == null) return null;
        Method m = find(o.getClass(), name);
        return m == null ? null : m.invoke(o);
    }

    private static Object field(Object o, String name) throws Exception {
        if (o == null) return null;
        for (Class<?> k = o.getClass(); k != null; k = k.getSuperclass()) {
            try {
                Field f = k.getDeclaredField(name);
                f.setAccessible(true);
                return f.get(o);
            } catch (NoSuchFieldException ignored) {
            }
        }
        return null;
    }

    private static Object staticField(String cls, String name) throws Exception {
        Field f = Class.forName(cls).getDeclaredField(name);
        f.setAccessible(true);
        return f.get(null);
    }

    /** Addons instalados, activos y que reproducen (Lhv2;->b lazy -> Ljn1;->f -> Lvi8;->q -> lista). Puede estar vacia al arrancar. */
    private static List<Object> installedAddons(Object repo) {
        List<Object> out = new ArrayList<Object>();
        try {
            Object jn1 = invoke(field(repo, "b"), "getValue");
            Object list = invoke(field(field(jn1, "f"), "q"), "getValue");
            if (!(list instanceof Iterable)) return out;
            for (Object a : (Iterable<?>) list) {
                try {
                    if (!Boolean.TRUE.equals(invoke(a, "isEnabled"))) continue;
                    Object manifest = invoke(a, "getManifest");
                    if (!Boolean.TRUE.equals(invoke(manifest, "getCanStream"))) continue;
                    out.add(a);
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /**
     * v0.20.457: calienta los addons activos (Tido, etc.). Todo dentro de try/catch: si algo no cuadra, se ignora y la app sigue igual.
     * (1) deja lista la sesion de Eclipse (Le69 via Lry6;->v) para que `Lgv2;->d` pueda leer el token de login;
     * (2) por cada addon: DNS a su baseURL, `Lgv2;->d(addon, baseURL)` (pide y guarda el token de acceso) y un primer pedido
     *     con `Lgv2;->c` (cliente de Eclipse; `Lgv2;->d` comparte su pool) por `new Lbj8(cliente, pedido, false).e()`.
     */
    private static void warmAddons(Context ctx) {
        try {
            if (ctx == null) return;
            Context app = ctx.getApplicationContext();
            if (app == null) app = ctx;
            try {
                Object comp = staticField("e69", "c");
                Method v = find(comp.getClass(), "v", Context.class);
                if (v != null) v.invoke(comp, app);
            } catch (Throwable ignored) {
            }
            Object companion = staticField("hv2", "e");
            Method j = find(companion.getClass(), "j", Context.class);
            if (j == null) return;
            Object repo = j.invoke(companion, app);
            if (repo == null) return;
            List<Object> addons = installedAddons(repo);
            for (int i = 0; i < 12 && addons.isEmpty(); i++) {
                Thread.sleep(500);
                addons = installedAddons(repo);
            }
            if (addons.isEmpty()) return;

            Class<?> addonCls = Class.forName("com.eclipse.android.data.models.addon.InstalledAddon");
            Object gv2 = staticField("gv2", "a");
            Object client = staticField("gv2", "c");
            Method d = find(gv2.getClass(), "d", addonCls, String.class);
            Constructor<?> call = Class.forName("bj8").getDeclaredConstructor(Class.forName("s67"), Class.forName("ju8"), boolean.class);
            call.setAccessible(true);
            Set<String> seen = new HashSet<String>();
            for (Object a : addons) {
                if (seen.size() >= 3) break;
                try {
                    Object base = invoke(a, "getBaseURL");
                    if (!(base instanceof String) || ((String) base).length() == 0 || !seen.add((String) base)) continue;
                    try {
                        InetAddress.getAllByName(new URL((String) base).getHost());
                    } catch (Throwable ignored) {
                    }
                    Object req = d.invoke(gv2, a, base);
                    Object resp = call.newInstance(client, req, false);
                    Object tv8 = invoke(resp, "e");
                    invoke(tv8, "close");
                } catch (Throwable ignored) {
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static void doWarm(Context ctx) {
        warmAddons(ctx);
        try {
            InetAddress.getAllByName("api.eclipsemusic.app");
        } catch (Throwable ignored) {
        }
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://api.eclipsemusic.app/").openConnection();
            c.setRequestMethod("HEAD");
            c.setConnectTimeout(4000);
            c.setReadTimeout(4000);
            c.getResponseCode();
        } catch (Throwable ignored) {
        } finally {
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) { }
        }
    }

    private static Object call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        return m.invoke(o);
    }

    private static String key(Object addon, Object song, Object text) {
        try {
            if (addon == null || song == null) return null;
            Object manifest = call(addon, "getManifest");
            Object name = manifest == null ? null : call(manifest, "getName");
            Object id = call(song, "getId");
            if (id == null) return null;
            return name + "|" + id + "|" + text;
        } catch (Throwable t) {
            return null;
        }
    }

    public static Object get(Object addon, Object song, Object text) {
        try {
            String k = key(addon, song, text);
            if (k == null) return null;
            synchronized (CACHE) {
                Hit e = CACHE.get(k);
                if (e == null) return null;
                if (System.currentTimeMillis() - e.at > TTL_MS) {
                    CACHE.remove(k);
                    return null;
                }
                return e.track;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    public static void put(Object addon, Object song, Object text, Object track) {
        try {
            if (track == null) return;
            String k = key(addon, song, text);
            if (k == null) return;
            synchronized (CACHE) {
                CACHE.put(k, new Hit(track, System.currentTimeMillis()));
            }
        } catch (Throwable ignored) {
        }
    }
}
