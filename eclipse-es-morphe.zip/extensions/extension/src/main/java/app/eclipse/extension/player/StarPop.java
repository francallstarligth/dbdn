package app.eclipse.extension.player;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.CornerPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.util.Collection;

/**
 * v0.20.409 (SIN COMPILAR NI PROBAR). Al marcar una cancion como favorita (estrella), animacion como la del reproductor de Mochy:
 * una estrella grande aparece en el centro (blanca -> dorada con brillo), se desvanece, y sobre el titulo sale un aviso de texto un par de segundos.
 *
 * Gancho: final de `Lh61.<init>` (estado del reproductor; `a` = Song, `e` = isFavorite). Se dispara cuando la MISMA cancion pasa de e=false a e=true
 * (al cambiar de cancion solo se recuerda el estado, no se anima). Todo es una vista de Android encima de la ventana (no toca el diseno).
 * Si algo falla se ignora en silencio.
 */
public final class StarPop {
    private StarPop() {}

    /** Texto del aviso sobre el titulo. */
    private static final String TOAST = "Añadida a la biblioteca y a favoritas";
    private static final long STAR_MS = 1200L;
    private static final long TOAST_MS = 2200L;

    private static String lastKey;
    private static Boolean lastFav;
    private static Handler main;
    private static volatile Activity resumed;
    private static boolean hooked;

    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    /** Lh61.<init>: a = Song, e = isFavorite. */
    public static void fromState(Object h61) {
        try {
            if (h61 == null) return;
            Object song = field(h61, "a");
            if (song == null) return;
            boolean fav = Boolean.TRUE.equals(field(h61, "e"));
            String key = keyOf(song);
            boolean fire;
            synchronized (StarPop.class) {
                fire = lastKey != null && key.equals(lastKey) && lastFav != null && !lastFav.booleanValue() && fav;
                lastKey = key;
                lastFav = Boolean.valueOf(fav);
            }
            if (fire) {
                if (main == null) main = new Handler(Looper.getMainLooper());
                main.post(new Runnable() {
                    @Override public void run() {
                        try {
                            show();
                        } catch (Throwable ignored) {
                        }
                    }
                });
            }
        } catch (Throwable ignored) {
        }
    }

    private static String keyOf(Object song) {
        StringBuilder sb = new StringBuilder();
        String[] names = {"id", "title", "artist"};
        for (String n : names) {
            try {
                Field f = song.getClass().getDeclaredField(n);
                f.setAccessible(true);
                Object v = f.get(song);
                sb.append(n).append('=').append(v).append('|');
            } catch (Throwable ignored) {
            }
        }
        return sb.toString();
    }

    private static Application app() throws Exception {
        Class<?> at = Class.forName("android.app.ActivityThread");
        return (Application) at.getMethod("currentApplication").invoke(null);
    }

    /** Actividad visible: la que registran los callbacks, o (la primera vez) la que dice ActivityThread. */
    private static Activity top() {
        try {
            Application a = app();
            if (!hooked && a != null) {
                hooked = true;
                a.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity act) { resumed = act; }
                    @Override public void onActivityPaused(Activity act) { if (resumed == act) resumed = null; }
                    @Override public void onActivityCreated(Activity act, Bundle b) {}
                    @Override public void onActivityStarted(Activity act) {}
                    @Override public void onActivityStopped(Activity act) {}
                    @Override public void onActivitySaveInstanceState(Activity act, Bundle b) {}
                    @Override public void onActivityDestroyed(Activity act) { if (resumed == act) resumed = null; }
                });
            }
        } catch (Throwable ignored) {
        }
        Activity r = resumed;
        if (r != null) return r;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object t = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Object map = fa.get(t);
            Collection<?> vals = (Collection<?>) map.getClass().getMethod("values").invoke(map);
            for (Object rec : vals) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Activity act = (Activity) fact.get(rec);
                if (act != null) {
                    resumed = act;
                    return act;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    private static void show() {
        final Activity act = top();
        if (act == null || act.isFinishing()) return;
        final ViewGroup decor = (ViewGroup) act.getWindow().getDecorView();
        final float d = act.getResources().getDisplayMetrics().density;
        final int w = decor.getWidth();
        final int h = decor.getHeight();
        if (w <= 0 || h <= 0) return;

        final FrameLayout root = new FrameLayout(act);
        root.setClickable(false);
        root.setFocusable(false);
        final StarView star = new StarView(act, d);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams((int) (220 * d), (int) (220 * d));
        sp.leftMargin = (int) (w * 0.5f - 110 * d);
        sp.topMargin = (int) (h * 0.42f - 110 * d);
        root.addView(star, sp);

        final TextView tv = new TextView(act);
        tv.setText(TOAST);
        tv.setTextColor(Color.argb(170, 255, 255, 255));
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        tv.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tv.setSingleLine(true);
        tv.setGravity(Gravity.START);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.leftMargin = (int) (w * 0.223f);
        tp.topMargin = (int) (h * 0.80f);
        tv.setAlpha(0f);
        root.addView(tv, tp);

        decor.addView(root, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        root.bringToFront();

        ValueAnimator a = ValueAnimator.ofFloat(0f, 1f);
        a.setDuration(STAR_MS);
        a.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator va) {
                star.setProgress((Float) va.getAnimatedValue());
            }
        });
        a.start();

        tv.animate().alpha(1f).setDuration(220).start();
        tv.postDelayed(new Runnable() {
            @Override public void run() {
                tv.animate().alpha(0f).setDuration(300).start();
            }
        }, TOAST_MS - 300);
        root.postDelayed(new Runnable() {
            @Override public void run() {
                try {
                    decor.removeView(root);
                } catch (Throwable ignored) {
                }
            }
        }, TOAST_MS + 100);
    }

    /** Estrella de 5 puntas con esquinas redondeadas y brillo; p = 0..1 es el avance de toda la animacion. */
    private static final class StarView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final ArgbEvaluator ev = new ArgbEvaluator();
        private float p;
        private final float r;

        StarView(Context c, float density) {
            super(c);
            r = 62f * density;
            setLayerType(LAYER_TYPE_SOFTWARE, null); // setShadowLayer (brillo) necesita capa por software
            fill.setStyle(Paint.Style.FILL_AND_STROKE);
            fill.setStrokeJoin(Paint.Join.ROUND);
            fill.setStrokeWidth(r * 0.16f);
            fill.setPathEffect(new CornerPathEffect(r * 0.14f));
            glow.set(fill);
            double inner = r * 0.48d;
            for (int i = 0; i < 10; i++) {
                double ang = -Math.PI / 2d + i * Math.PI / 5d;
                double rad = (i % 2 == 0) ? r : inner;
                float x = (float) (Math.cos(ang) * rad);
                float y = (float) (Math.sin(ang) * rad);
                if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
            }
            path.close();
        }

        void setProgress(float v) {
            p = v;
            invalidate();
        }

        @Override protected void onDraw(Canvas cv) {
            // escala: 0 -> 1.2 (rebote) -> 1.0 -> sube un poco al irse
            float s;
            if (p < 0.2f) s = 0.3f + 0.9f * (p / 0.2f);
            else if (p < 0.38f) s = 1.2f - 0.2f * ((p - 0.2f) / 0.18f);
            else if (p < 0.72f) s = 1f;
            else s = 1f + 0.12f * ((p - 0.72f) / 0.28f);
            float alpha = p < 0.72f ? 1f : 1f - (p - 0.72f) / 0.28f;
            // color: blanco -> dorado claro -> dorado
            float c = p < 0.15f ? 0f : (p > 0.55f ? 1f : (p - 0.15f) / 0.40f);
            int base = (Integer) ev.evaluate(c, Color.WHITE, Color.rgb(255, 196, 0));
            int a255 = (int) (255 * alpha);
            fill.setColor(base);
            fill.setAlpha(a255);
            fill.clearShadowLayer();
            float glowR = r * 0.55f * c;
            if (glowR > 0.5f) fill.setShadowLayer(glowR, 0f, 0f, Color.argb((int) (200 * alpha), 255, 179, 0));
            cv.save();
            cv.translate(getWidth() / 2f, getHeight() / 2f + r * 0.06f);
            cv.scale(s, s);
            cv.drawPath(path, fill);
            cv.restore();
        }
    }
}
