package app.eclipse.extension.translate;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * v0.20.161 (SIN COMPILAR / SIN PROBAR). Traduccion de letras GRATIS, sin clave ni cuenta de Eclipse.
 *
 * Eclipse traduce las letras en jx4.b(jx4, ArrayList lineas, String idiomaDestino, String proveedor) con un POST a
 * api.eclipsemusic.app (necesita la cuenta de Eclipse y, para DeepL, la clave del usuario). El gancho de
 * FreeTranslationPatch llama a {@link #translate} al inicio de jx4.b: con el proveedor "model" (la opcion "Modelo de IA",
 * que aqui se muestra como "Gratis (Google)") se traduce desde el telefono con el endpoint NO oficial de Google Translate
 * (translate.googleapis.com, client=gtx). Devuelve null si no es ese proveedor o si algo falla: entonces jx4.b sigue
 * como siempre.
 *
 * Se manda TODA la letra en un solo pedido (lineas unidas con "\n"); si el resultado no trae el mismo numero de lineas,
 * se traduce por lotes mas chicos y, como ultimo recurso, linea por linea. Cache en memoria por (idioma + letra).
 */
@SuppressWarnings("unused")
public final class FreeTranslate {
    private static final String TAG = "FreeTranslate";
    private static final String URL = "https://translate.googleapis.com/translate_a/single";
    private static final int TIMEOUT_MS = 10000;
    private static final int MAX_CHARS = 3500;      // por pedido
    private static final int MAX_LINE_CALLS = 120;  // tope del ultimo recurso (linea por linea)

    private static final Map<String, List<String>> CACHE = new LinkedHashMap<String, List<String>>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, List<String>> e) { return size() > 40; }
    };

    private FreeTranslate() {}

    /** Gancho de jx4.b. null = no lo manejo (jx4.b sigue con su flujo). */
    public static List<String> translate(ArrayList<String> lines, String targetLang, String provider) {
        try {
            if (!"model".equals(provider) || lines == null || lines.isEmpty()) return null;
            String lang = langCode(targetLang);
            String key = lang + "\u0001" + join(lines, "\u0001");
            synchronized (CACHE) {
                List<String> hit = CACHE.get(key);
                if (hit != null) return new ArrayList<String>(hit);
            }
            List<String> out = run(lines, lang);
            if (out == null) return null;
            synchronized (CACHE) { CACHE.put(key, new ArrayList<String>(out)); }
            return out;
        } catch (Throwable t) {
            Log.w(TAG, "fallo: " + t);
            return null;
        }
    }

    private static List<String> run(List<String> lines, String lang) throws Exception {
        int n = lines.size();
        String[] res = new String[n];
        // indices con texto (las lineas vacias se quedan vacias)
        List<Integer> idx = new ArrayList<Integer>();
        for (int i = 0; i < n; i++) {
            String s = lines.get(i);
            if (s != null && s.trim().length() > 0) idx.add(i); else res[i] = "";
        }
        int pos = 0;
        int lineCalls = 0;
        while (pos < idx.size()) {
            // lote: hasta MAX_CHARS caracteres
            int end = pos;
            int chars = 0;
            while (end < idx.size()) {
                int len = clean(lines.get(idx.get(end))).length() + 1;
                if (end > pos && chars + len > MAX_CHARS) break;
                chars += len;
                end++;
            }
            List<String> batch = new ArrayList<String>();
            for (int k = pos; k < end; k++) batch.add(clean(lines.get(idx.get(k))));
            List<String> tr = translateBatch(batch, lang);
            if (tr == null || tr.size() != batch.size()) {
                // ultimo recurso: linea por linea (con tope)
                tr = new ArrayList<String>();
                for (String one : batch) {
                    String r = null;
                    if (++lineCalls <= MAX_LINE_CALLS) {
                        List<String> l1 = translateBatch(java.util.Collections.singletonList(one), lang);
                        if (l1 != null && l1.size() == 1) r = l1.get(0);
                    }
                    tr.add(r != null ? r : one);
                }
            }
            for (int k = pos; k < end; k++) res[idx.get(k)] = tr.get(k - pos);
            pos = end;
        }
        List<String> out = new ArrayList<String>(n);
        for (int i = 0; i < n; i++) out.add(res[i] != null ? res[i] : "");
        return out;
    }

    private static String clean(String s) {
        return s.replace('\n', ' ').replace('\r', ' ').trim();
    }

    /** Una llamada: lineas unidas por "\n"; devuelve las traducidas si el numero coincide, si no null. */
    private static List<String> translateBatch(List<String> batch, String lang) throws Exception {
        String q = join(batch, "\n");
        String body = "q=" + URLEncoder.encode(q, "UTF-8");
        String url = URL + "?client=gtx&sl=auto&tl=" + URLEncoder.encode(lang, "UTF-8") + "&dt=t&ie=UTF-8&oe=UTF-8";
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36");
            OutputStream os = c.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.close();
            int code = c.getResponseCode();
            if (code != 200) {
                lastErr = "G" + code;
                Log.w(TAG, "HTTP " + code);
                return null;
            }
            InputStream is = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) > 0) bo.write(buf, 0, r);
            is.close();
            JSONArray root = new JSONArray(bo.toString("UTF-8"));
            JSONArray segs = root.optJSONArray(0);
            if (segs == null) return null;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < segs.length(); i++) {
                JSONArray seg = segs.optJSONArray(i);
                if (seg != null && !seg.isNull(0)) sb.append(seg.optString(0, ""));
            }
            String[] parts = sb.toString().split("\n", -1);
            List<String> out = new ArrayList<String>();
            for (String p : parts) out.add(p.trim());
            // Google a veces deja un "\n" final: quitar vacios del final si sobran
            while (out.size() > batch.size() && out.get(out.size() - 1).length() == 0) out.remove(out.size() - 1);
            return out.size() == batch.size() ? out : null;
        } finally {
            c.disconnect();
        }
    }

    // ---------------- v0.20.162: comentarios del DJ ----------------

    private static final Map<String, String> DJ_CACHE = new LinkedHashMap<String, String>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, String> e) { return size() > 60; }
    };

    /**
     * Gancho del constructor de eu3 (DJSegment): recibe el comentario del DJ (texto que manda el servidor de Eclipse) y lo
     * devuelve en espanol. Solo si el idioma del telefono es espanol. Orden: DeepL (si hay clave en `lyrics_settings` ->
     * `deepl_api_key`), Google gratis, y si todo falla el texto original. Nunca en el hilo principal (red): ahi devuelve el original.
     */
    private static volatile String lastErr = "";

    /** Espera maxima (ms) cuando el constructor corre en el hilo principal y la traduccion se hace en un hilo aparte (v0.20.193). */
    private static final long MAIN_JOIN_MS = 3000;

    /** v0.20.194: sin etiquetas de diagnostico; si algo falla o tarda mas de MAIN_JOIN_MS devuelve el texto original. */
    public static String dj(final String text) {
        try {
            if (text == null || text.trim().length() == 0) return text;
            if (!"es".equals(Locale.getDefault().getLanguage())) return text;
            if (android.os.Looper.getMainLooper().getThread() != Thread.currentThread()) return djCore(text);
            // Hilo principal (la red no se puede ahi): traducir en un hilo aparte y esperar hasta MAIN_JOIN_MS. Si no llega a tiempo
            // el hilo sigue y guarda la traduccion en cache para la proxima vez que salga el mismo texto.
            final String[] res = new String[1];
            Thread th = new Thread(new Runnable() {
                @Override public void run() { res[0] = djCore(text); }
            }, "dj-translate");
            th.setDaemon(true);
            th.start();
            try { th.join(MAIN_JOIN_MS); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
            return res[0] != null ? res[0] : text;
        } catch (Throwable t) {
            return text;
        }
    }

    private static String djCore(String text) {
        try {
            synchronized (DJ_CACHE) {
                String hit = DJ_CACHE.get(text);
                if (hit != null) return hit;
            }
            String out = null;
            String key = deeplKey();
            if (key != null) {
                try { out = deepl(text, key); } catch (Throwable t) { Log.w(TAG, "dj DeepL fallo: " + t); }
            }
            if (out == null) {
                try {
                    List<String> g = translateBatch(java.util.Collections.singletonList(clean(text)), "es");
                    if (g != null && g.size() == 1 && g.get(0).length() > 0) out = g.get(0);
                } catch (Throwable t) { Log.w(TAG, "dj Google fallo: " + t); }
            }
            if (out == null) return text;
            synchronized (DJ_CACHE) { DJ_CACHE.put(text, out); }
            return out;
        } catch (Throwable t) {
            return text;
        }
    }

    /** Clave de DeepL que el usuario puso en Apariencia de la letra (SharedPreferences `lyrics_settings`, `deepl_api_key`). */
    private static String deeplKey() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof android.content.Context)) return null;
            String k = ((android.content.Context) app).getSharedPreferences("lyrics_settings", 0).getString("deepl_api_key", "");
            return (k != null && k.trim().length() > 0) ? k.trim() : null;
        } catch (Throwable t) {
            return null;
        }
    }

    private static String deepl(String text, String key) throws Exception {
        String host = key.endsWith(":fx") ? "https://api-free.deepl.com" : "https://api.deepl.com";
        JSONObject body = new JSONObject();
        body.put("text", new JSONArray().put(text));
        body.put("target_lang", "ES");
        HttpURLConnection c = (HttpURLConnection) new URL(host + "/v2/translate").openConnection();
        try {
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("Authorization", "DeepL-Auth-Key " + key);
            OutputStream os = c.getOutputStream();
            os.write(body.toString().getBytes("UTF-8"));
            os.close();
            int code = c.getResponseCode();
            if (code != 200) {
                lastErr = "D" + code;
                Log.w(TAG, "DeepL HTTP " + code); // 456 = cuota agotada: se sigue con Google
                return null;
            }
            InputStream is = c.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) > 0) bo.write(buf, 0, r);
            is.close();
            JSONArray tr = new JSONObject(bo.toString("UTF-8")).optJSONArray("translations");
            if (tr == null || tr.length() == 0) return null;
            String t = tr.getJSONObject(0).optString("text", "");
            return t.length() > 0 ? t : null;
        } finally {
            c.disconnect();
        }
    }

    private static String join(List<String> l, String sep) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(sep);
            sb.append(l.get(i) == null ? "" : l.get(i));
        }
        return sb.toString();
    }

    /** El ajuste "target_language" puede traer un codigo ("es", "pt-BR") o un nombre ("Spanish"). */
    private static String langCode(String t) {
        if (t == null || t.length() == 0) return "en";
        String s = t.trim();
        if (s.length() <= 5 && (s.indexOf(' ') < 0)) return s.replace('_', '-');
        String l = s.toLowerCase(Locale.ROOT);
        if (l.startsWith("span")) return "es";
        if (l.startsWith("engl")) return "en";
        if (l.startsWith("fren")) return "fr";
        if (l.startsWith("germ")) return "de";
        if (l.startsWith("ital")) return "it";
        if (l.startsWith("port")) return "pt";
        if (l.startsWith("russ")) return "ru";
        if (l.startsWith("japan")) return "ja";
        if (l.startsWith("kore")) return "ko";
        if (l.startsWith("chin")) return "zh-CN";
        if (l.startsWith("arab")) return "ar";
        if (l.startsWith("hind")) return "hi";
        if (l.startsWith("turk")) return "tr";
        if (l.startsWith("dutch")) return "nl";
        if (l.startsWith("pol")) return "pl";
        return s;
    }
}
