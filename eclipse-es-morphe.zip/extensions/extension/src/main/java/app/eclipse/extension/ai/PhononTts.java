package app.eclipse.extension.ai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.net.ConnectivityManager;
import android.os.Build;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/**
 * v0.20.355: modelo MULTILINGUE (release phonon-multi-1: en, fr, de, pt, es). Carpeta nueva filesDir/phonon-multi (baja todo de nuevo);
 *  la carpeta vieja "phonon" se borra solo cuando el modelo nuevo ya abrio. La voz clonada sigue siendo la misma (mismo SHA256).
 * v0.20.348: la temperatura (por defecto 0.7) ahora viene de una opcion del parche (configTemp); antes fija en 1.0.
 * v0.20.347: temperatura 1.0 para que suene menos plana.
 * v0.20.346: modelo sin comprimir (model.safetensors) con respaldo al q8, y notificacion de descarga.
 * v0.20.345 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL). Voz del DJ LOCAL con Phonon (Gradium, phonon-40m-es).
 * La app NO lleva las librerias ni el modelo: la primera vez los baja de los releases de francallstarligth/phonon-test
 * (solo con red NO medida, o sea Wi-Fi), los guarda en filesDir/phonon y los carga desde ahi.
 * Nunca bloquea al DJ: si todavia no esta listo, speak() devuelve null (sigue Gradium/Cloudflare/Edge) y la preparacion
 * (bajar + cargar el modelo) corre en un hilo aparte. Nunca lanza.
 * Devuelve un WAV (16 bit, 24 kHz, mono) de 44 bytes de encabezado limpio, igual que Gradium.
 */
public final class PhononTts {
    private static final String TAG = "PhononTts";
    private static final String BASE = "https://github.com/francallstarligth/phonon-test/releases/download/";
    private static final String LIB = BASE + "phonon-lib-1/";
    private static final String MODEL = BASE + "phonon-multi-1/";
    private static final String VOICE_OLD = BASE + "phonon-modelo-1/"; // la voz clonada vive aqui (mismo archivo que zGR5...@300 de phonon-multi-1)
    private static final int MAX_CHARS = 1500;
    private static final int RATE = 24000;
    private static final long RETRY_MS = 10L * 60L * 1000L;

    // {ruta relativa en filesDir/phonon, url, sha256 o null (sin comprobar), "1" si es opcional}
    private static final String[][] FILES = {
        {"libptts_ffi.so", LIB + "libptts_ffi.so",
            "6807d75d45ec034afb4d28469ab6f153765c9dd62dd8b0a879831a513c050ceb", "0"},
        {"libphonon_jni.so", LIB + "libphonon_jni.so",
            "3cdfec31974f7bd6f3885b89737b9d7087ea2d38df6c3ec54b82bcacdaa7bf0a", "0"},
        {"config.json", MODEL + "config.json", null, "0"},
        {"tokenizer.json", MODEL + "tokenizer.json", null, "0"},
        {"default-voice.safetensors", MODEL + "default-voice.safetensors", null, "0"},
        {"voices/voz-clonada.safetensors", VOICE_OLD + "voz-clonada.safetensors",
            "71597dea53d3ce29a7334f4f1438a2dd6cbbd8bf78e05a7cfd6b6ba81936beac", "1"},
    };

    // Modelo: primero el sin comprimir (opcional); si no baja o no abre, el comprimido.
    private static final String[] MODEL_ST = {"model.safetensors", MODEL + "model.safetensors", null, "1"};
    private static final String[] MODEL_Q8 = {"model.q8.gguf", MODEL + "model.q8.gguf", null, "0"};
    private static final float TEMP_DEFAULT = 0.7f;
    private static volatile float temp = TEMP_DEFAULT; // v0.20.348: la pone el parche (opcion "Temperatura de Phonon") antes de hablar

    /** v0.20.348: la llama el gancho del parche con el texto de la opcion. Si no es un numero valido (0.1 a 2.0), queda 0.7. Nunca lanza. */
    public static void configTemp(String s) {
        float v = TEMP_DEFAULT;
        try {
            if (s != null) {
                float x = Float.parseFloat(s.trim().replace(',', '.'));
                if (x >= 0.1f && x <= 2.0f) v = x;
            }
        } catch (Throwable ignored) {
        }
        temp = v;
    }
    /** v0.20.350: la llama el parche al abrir Eclipse (MainActivity.onCreate). Pone la temperatura y prende Phonon en segundo plano
     *  para que la primera frase del DJ ya salga con Phonon. Nunca lanza ni bloquea (kick() usa un hilo aparte). */
    public static void warmup(String t) {
        try {
            configTemp(t);
            if (handle == 0) kick();
        } catch (Throwable ignored) {
        }
    }
    private static volatile boolean pauses = true; // v0.20.352: opcion del parche "Pausas en las comas de Phonon"

    /** v0.20.352: la llama el gancho del parche. true = se pone "..." tras cada coma para empujar a Phonon a hacer pausa. */
    public static void configPausas(boolean on) {
        pauses = on;
    }

    /** v0.20.354: ahora UN solo punto (".") en vez de dos; el usuario nota que Phonon si respeta los puntos.
     *  v0.20.353: pone ".." despues de cada coma (no entre digitos, como en 1,5) y despues de cada raya (em dash o en dash),
     *  salvo que ya traiga un punto. No toca la "y" ni los guiones cortos. */
    private static String pausas(String t) {
        try {
            String r = t.replaceAll("(?:(?<!\\d),|,(?!\\d))(?!\\s*\\.)", ", .");
            return r.replaceAll("([\u2014\u2013])(?!\\s*\\.)", "$1 .");
        } catch (Throwable e) {
            return t;
        }
    }
    private static final int NOTE_ID = 7400345;
    private static final String CHANNEL = "phonon_voz";

    private static final Object LOCK = new Object();
    private static volatile boolean busy;      // hilo de preparacion corriendo
    private static volatile boolean dead;      // fallo al cargar: no insistir en este arranque
    private static volatile long nextTry;
    private static volatile long handle;                // 0 = modelo aun no abierto

    private PhononTts() {}

    /** @return WAV o null si Phonon aun no esta listo o fallo. Nunca lanza. */
    public static byte[] speak(String text) {
        try {
            if (text == null || dead) return null;
            if (handle == 0) {
                kick();
                return null;
            }
            text = EdgeTts.clean(text);
            if (text.isEmpty()) return null;
            if (pauses) text = pausas(text);
            if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS);
            synchronized (LOCK) {
                if (handle == 0) return null;
                final ByteArrayOutputStream pcm = new ByteArrayOutputStream(RATE * 2 * 4);
                PhononNative.speak(handle, text, new PhononNative.Sink() {
                    @Override
                    public boolean onAudio(float[] a, int n) {
                        byte[] b = new byte[n * 2];
                        for (int i = 0; i < n; i++) {
                            float f = a[i];
                            if (f > 1f) f = 1f; else if (f < -1f) f = -1f;
                            int s = Math.round(f * 32767f);
                            b[2 * i] = (byte) s;
                            b[2 * i + 1] = (byte) (s >> 8);
                        }
                        pcm.write(b, 0, b.length);
                        return true;
                    }
                });
                byte[] d = pcm.toByteArray();
                if (d.length < RATE / 5) { // menos de 0,1 s: no es una frase
                    Log.w(TAG, "casi sin audio (" + d.length + " bytes)");
                    return null;
                }
                return wav(d);
            }
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
            return null;
        }
    }

    private static byte[] wav(byte[] d) {
        byte[] w = new byte[44 + d.length];
        put(w, 0, "RIFF");
        le32(w, 4, 36 + d.length);
        put(w, 8, "WAVE");
        put(w, 12, "fmt ");
        le32(w, 16, 16);
        w[20] = 1; w[21] = 0;           // PCM
        w[22] = 1; w[23] = 0;           // mono
        le32(w, 24, RATE);
        le32(w, 28, RATE * 2);
        w[32] = 2; w[33] = 0;           // block align
        w[34] = 16; w[35] = 0;          // 16 bit
        put(w, 36, "data");
        le32(w, 40, d.length);
        System.arraycopy(d, 0, w, 44, d.length);
        return w;
    }

    private static void put(byte[] b, int o, String s) {
        for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i);
    }

    private static void le32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    /** Arranca (una sola vez a la vez) la preparacion en un hilo aparte. */
    private static void kick() {
        if (busy || dead || System.currentTimeMillis() < nextTry) return;
        busy = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    prepare();
                } catch (Throwable e) {
                    Log.w(TAG, "preparacion fallo: " + e);
                    nextTry = System.currentTimeMillis() + RETRY_MS;
                    try { note(app(), "Phonon: algo fallo", "Se reintenta en unos minutos.", false, 15000L); } catch (Throwable ignore) {}
                } finally {
                    busy = false;
                }
            }
        }, "PhononPrepare");
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    private static Context app() throws Exception {
        Object a = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        return (Context) a;
    }

    private static void prepare() throws Exception {
        Context ctx = app();
        if (ctx == null) { nextTry = System.currentTimeMillis() + 60000L; return; }
        File dir = new File(ctx.getFilesDir(), "phonon-multi");
        dir.mkdirs();
        File st = new File(dir, "model.safetensors");
        File q8 = new File(dir, "model.q8.gguf");
        File noSt = new File(dir, "no-safetensors"); // marca: el sin comprimir no sirvio, usar el q8
        boolean wantSt = !noSt.exists();

        List<String[]> list = new ArrayList<String[]>();
        for (String[] f : FILES) list.add(f);
        list.add(wantSt ? MODEL_ST : MODEL_Q8);

        // 1) Bajar lo que falte (solo con red no medida)
        int total = 0;
        for (String[] f : list) if (!f[0].startsWith("voices/") && !have(dir, f[0])) total++;
        boolean showed = false;
        int n = 0;
        for (String[] f : list) {
            File out = new File(dir, f[0]);
            if (out.isFile() && out.length() > 0) continue;
            if (!unmetered(ctx)) {
                Log.i(TAG, "sin Wi-Fi: no se baja " + f[0]);
                if (showed) note(ctx, "Phonon: falta Wi-Fi", "Se sigue cuando haya Wi-Fi.", false, 15000L);
                nextTry = System.currentTimeMillis() + 60000L;
                return;
            }
            boolean optional = "1".equals(f[3]);
            boolean quiet = f[0].startsWith("voices/");
            if (!quiet) {
                n++;
                showed = true;
                note(ctx, "Descargando voz de Phonon", n + " de " + total, true, 0L);
            }
            if (!download(f[1], out, f[2]) && !optional) {
                note(ctx, "No se pudo bajar la voz de Phonon", "Se reintenta en unos minutos.", false, 20000L);
                nextTry = System.currentTimeMillis() + RETRY_MS;
                return;
            }
        }
        // si el sin comprimir no bajo, usar el comprimido
        if (wantSt && !st.isFile()) {
            try { noSt.createNewFile(); } catch (Throwable ignore) {}
            if (!q8.isFile()) {
                showed = true;
                note(ctx, "Descargando voz de Phonon", "modelo comprimido", true, 0L);
                if (!download(MODEL_Q8[1], q8, null)) {
                    note(ctx, "No se pudo bajar la voz de Phonon", "Se reintenta en unos minutos.", false, 20000L);
                    nextTry = System.currentTimeMillis() + RETRY_MS;
                    return;
                }
            }
        }
        // con los dos archivos a la vez no se sabe cual abre la libreria: dejar uno solo
        if (st.isFile() && q8.isFile()) q8.delete();

        // 2) Cargar las librerias y abrir el modelo
        File ffi = new File(dir, "libptts_ffi.so");
        File jni = new File(dir, "libphonon_jni.so");
        ffi.setReadOnly();
        jni.setReadOnly();
        long h;
        try {
            PhononNative.load(jni.getAbsolutePath(), ffi.getAbsolutePath());
        } catch (Throwable t) {
            dead = true;
            Log.w(TAG, "no cargo Phonon: " + t);
            if (showed) note(ctx, "Phonon no pudo cargar", "Se usa la voz de siempre.", false, 20000L);
            return;
        }
        try {
            h = PhononNative.open(dir.getAbsolutePath(), "es");
        } catch (Throwable t) {
            Log.w(TAG, "no abrio el modelo: " + t);
            if (!st.isFile()) {
                dead = true;
                if (showed) note(ctx, "Phonon no pudo cargar", "Se usa la voz de siempre.", false, 20000L);
                return;
            }
            // el sin comprimir no abrio: volver al comprimido
            st.delete();
            try { noSt.createNewFile(); } catch (Throwable ignore) {}
            showed = true;
            note(ctx, "Descargando voz de Phonon", "modelo comprimido", true, 0L);
            if (!download(MODEL_Q8[1], q8, null)) {
                note(ctx, "No se pudo bajar la voz de Phonon", "Se reintenta en unos minutos.", false, 20000L);
                nextTry = System.currentTimeMillis() + RETRY_MS;
                return;
            }
            try {
                h = PhononNative.open(dir.getAbsolutePath(), "es");
            } catch (Throwable t2) {
                dead = true;
                Log.w(TAG, "tampoco abrio el comprimido: " + t2);
                note(ctx, "Phonon no pudo cargar", "Se usa la voz de siempre.", false, 20000L);
                return;
            }
        }
        try {
            String pick = null;
            for (String v : PhononNative.voices(h)) {
                if (v.toLowerCase().contains("clonada")) { pick = v; break; }
            }
            if (pick != null) PhononNative.setVoice(h, pick);
            Log.i(TAG, "modelo: " + (st.isFile() ? "safetensors" : "q8") + " voces: "
                + java.util.Arrays.toString(PhononNative.voices(h)) + " usando: " + (pick != null ? pick : "por defecto"));
        } catch (Throwable t) {
            Log.w(TAG, "no pude elegir la voz clonada, queda la de por defecto: " + t);
        }
        try {
            if (!PhononNative.setTemperature(h, temp)) Log.w(TAG, "la libreria no acepto la temperatura " + temp + "; queda la suya");
            else Log.i(TAG, "temperatura: " + temp);
        } catch (Throwable t) {
            Log.w(TAG, "temperatura: " + t);
        }
        synchronized (LOCK) { handle = h; }
        try { // v0.20.355: el modelo nuevo ya abrio; borrar la carpeta vieja (solo espanol) para liberar espacio
            File old = new File(ctx.getFilesDir(), "phonon");
            File[] fs = old.listFiles();
            if (fs != null) {
                for (File x : fs) {
                    File[] sub = x.listFiles();
                    if (sub != null) for (File y : sub) y.delete();
                    x.delete();
                }
            }
            old.delete();
        } catch (Throwable ignore) {}
        if (showed) note(ctx, "Phonon listo", "La voz local ya esta lista.", false, 8000L);
    }

    private static boolean have(File dir, String rel) {
        File f = new File(dir, rel);
        return f.isFile() && f.length() > 0;
    }

    /** Notificacion silenciosa (canal de importancia baja). Si Android no deja avisar, no pasa nada. Nunca lanza. */
    private static void note(Context ctx, String title, String text, boolean ongoing, long timeoutMs) {
        try {
            if (Build.VERSION.SDK_INT < 26) return;
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Voz local (Phonon)", NotificationManager.IMPORTANCE_LOW));
            Notification.Builder b = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(ongoing ? android.R.drawable.stat_sys_download : android.R.drawable.stat_sys_download_done)
                .setContentTitle(title)
                .setContentText(text)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true);
            if (ongoing) b.setProgress(0, 0, true);
            if (timeoutMs > 0) b.setTimeoutAfter(timeoutMs);
            nm.notify(NOTE_ID, b.build());
        } catch (Throwable t) {
            Log.w(TAG, "notificacion: " + t);
        }
    }

    private static boolean unmetered(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            return !cm.isActiveNetworkMetered();
        } catch (Throwable t) {
            return true;
        }
    }

    /** Baja a un .tmp, comprueba el SHA256 si hay, y lo renombra. true si quedo bien. */
    private static boolean download(String url, File out, String sha) {
        File tmp = new File(out.getPath() + ".tmp");
        HttpURLConnection c = null;
        try {
            File parent = out.getParentFile();
            if (parent != null) parent.mkdirs();
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "descarga " + out.getName() + ": HTTP " + code);
                return false;
            }
            long want = c.getContentLengthLong();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            long got = 0;
            InputStream in = c.getInputStream();
            OutputStream os = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    md.update(buf, 0, n);
                    got += n;
                }
            } finally {
                os.close();
                in.close();
            }
            if (got == 0 || (want > 0 && got != want)) {
                Log.w(TAG, "descarga incompleta " + out.getName() + ": " + got + "/" + want);
                tmp.delete();
                return false;
            }
            if (sha != null) {
                StringBuilder sb = new StringBuilder();
                for (byte b : md.digest()) sb.append(String.format("%02x", b));
                if (!sb.toString().equals(sha)) {
                    Log.w(TAG, "SHA256 no coincide en " + out.getName());
                    tmp.delete();
                    return false;
                }
            }
            if (out.exists()) out.delete();
            if (!tmp.renameTo(out)) { tmp.delete(); return false; }
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "descarga " + out.getName() + " fallo: " + t);
            tmp.delete();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
