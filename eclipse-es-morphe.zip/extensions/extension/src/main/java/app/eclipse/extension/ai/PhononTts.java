package app.eclipse.extension.ai;

import android.content.Context;
import android.net.ConnectivityManager;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

/**
 * v0.20.345 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL). Voz del DJ LOCAL con Phonon (Gradium, phonon-40m-es).
 * La app NO lleva las librerias ni el modelo: la primera vez los baja de los releases de francallstarligth/phonon-test
 * (solo con red NO medida, o sea Wi-Fi), los guarda en filesDir/phonon y los carga desde ahi.
 * Nunca bloquea al DJ: si todavia no esta listo, speak() devuelve null (sigue Gradium/Cloudflare/Edge) y la preparacion
 * (bajar + cargar el modelo) corre en un hilo aparte. Nunca lanza.
 * Devuelve un WAV (16 bit, 24 kHz, mono) de 44 bytes de encabezado limpio, igual que Gradium.
 */
public final class PhononTts {
    private static final String TAG = "PhononTts";
    private static final String BASE = "https://github.com/francallstarligth/phonon-test/releases/download/";
    private static final String LIB = BASE + "phonon-lib-1/";
    private static final String MODEL = BASE + "phonon-modelo-1/";
    private static final int MAX_CHARS = 1500;
    private static final int RATE = 24000;
    private static final long RETRY_MS = 10L * 60L * 1000L;

    // {ruta relativa en filesDir/phonon, url, sha256 o null (sin comprobar), "1" si es opcional}
    private static final String[][] FILES = {
        {"libptts_ffi.so", LIB + "libptts_ffi.so",
            "6807d75d45ec034afb4d28469ab6f153765c9dd62dd8b0a879831a513c050ceb", "0"},
        {"libphonon_jni.so", LIB + "libphonon_jni.so",
            "3cdfec31974f7bd6f3885b89737b9d7087ea2d38df6c3ec54b82bcacdaa7bf0a", "0"},
        {"config.json", MODEL + "config.json", null, "0"},
        {"tokenizer.json", MODEL + "tokenizer.json", null, "0"},
        {"model.q8.gguf", MODEL + "model.q8.gguf", null, "0"},
        {"default-voice.safetensors", MODEL + "default-voice.safetensors", null, "0"},
        {"voices/voz-clonada.safetensors", MODEL + "voz-clonada.safetensors",
            "71597dea53d3ce29a7334f4f1438a2dd6cbbd8bf78e05a7cfd6b6ba81936beac", "1"},
    };

    private static final Object LOCK = new Object();
    private static volatile boolean busy;      // hilo de preparacion corriendo
    private static volatile boolean dead;      // fallo al cargar: no insistir en este arranque
    private static volatile long nextTry;
    private static volatile long handle;                // 0 = modelo aun no abierto

    private PhononTts() {}

    /** @return WAV o null si Phonon aun no esta listo o fallo. Nunca lanza. */
    public static byte[] speak(String text) {
        try {
            if (text == null || dead) return null;
            if (handle == 0) {
                kick();
                return null;
            }
            text = EdgeTts.clean(text);
            if (text.isEmpty()) return null;
            if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS);
            synchronized (LOCK) {
                if (handle == 0) return null;
                final ByteArrayOutputStream pcm = new ByteArrayOutputStream(RATE * 2 * 4);
                PhononNative.speak(handle, text, new PhononNative.Sink() {
                    @Override
                    public boolean onAudio(float[] a, int n) {
                        byte[] b = new byte[n * 2];
                        for (int i = 0; i < n; i++) {
                            float f = a[i];
                            if (f > 1f) f = 1f; else if (f < -1f) f = -1f;
                            int s = Math.round(f * 32767f);
                            b[2 * i] = (byte) s;
                            b[2 * i + 1] = (byte) (s >> 8);
                        }
                        pcm.write(b, 0, b.length);
                        return true;
                    }
                });
                byte[] d = pcm.toByteArray();
                if (d.length < RATE / 5) { // menos de 0,1 s: no es una frase
                    Log.w(TAG, "casi sin audio (" + d.length + " bytes)");
                    return null;
                }
                return wav(d);
            }
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
            return null;
        }
    }

    private static byte[] wav(byte[] d) {
        byte[] w = new byte[44 + d.length];
        put(w, 0, "RIFF");
        le32(w, 4, 36 + d.length);
        put(w, 8, "WAVE");
        put(w, 12, "fmt ");
        le32(w, 16, 16);
        w[20] = 1; w[21] = 0;           // PCM
        w[22] = 1; w[23] = 0;           // mono
        le32(w, 24, RATE);
        le32(w, 28, RATE * 2);
        w[32] = 2; w[33] = 0;           // block align
        w[34] = 16; w[35] = 0;          // 16 bit
        put(w, 36, "data");
        le32(w, 40, d.length);
        System.arraycopy(d, 0, w, 44, d.length);
        return w;
    }

    private static void put(byte[] b, int o, String s) {
        for (int i = 0; i < s.length(); i++) b[o + i] = (byte) s.charAt(i);
    }

    private static void le32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    /** Arranca (una sola vez a la vez) la preparacion en un hilo aparte. */
    private static void kick() {
        if (busy || dead || System.currentTimeMillis() < nextTry) return;
        busy = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    prepare();
                } catch (Throwable e) {
                    Log.w(TAG, "preparacion fallo: " + e);
                    nextTry = System.currentTimeMillis() + RETRY_MS;
                } finally {
                    busy = false;
                }
            }
        }, "PhononPrepare");
        t.setPriority(Thread.MIN_PRIORITY);
        t.start();
    }

    private static Context app() throws Exception {
        Object a = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        return (Context) a;
    }

    private static void prepare() throws Exception {
        Context ctx = app();
        if (ctx == null) { nextTry = System.currentTimeMillis() + 60000L; return; }
        File dir = new File(ctx.getFilesDir(), "phonon");
        dir.mkdirs();

        // 1) Bajar lo que falte (solo con red no medida)
        for (String[] f : FILES) {
            File out = new File(dir, f[0]);
            if (out.isFile() && out.length() > 0) continue;
            if (!unmetered(ctx)) {
                Log.i(TAG, "sin Wi-Fi: no se baja " + f[0]);
                nextTry = System.currentTimeMillis() + 60000L;
                return;
            }
            boolean optional = "1".equals(f[3]);
            if (!download(f[1], out, f[2]) && !optional) {
                nextTry = System.currentTimeMillis() + RETRY_MS;
                return;
            }
        }

        // 2) Cargar las librerias y abrir el modelo
        File ffi = new File(dir, "libptts_ffi.so");
        File jni = new File(dir, "libphonon_jni.so");
        ffi.setReadOnly();
        jni.setReadOnly();
        long h;
        try {
            PhononNative.load(jni.getAbsolutePath(), ffi.getAbsolutePath());
            h = PhononNative.open(dir.getAbsolutePath(), "es");
        } catch (Throwable t) {
            dead = true;
            Log.w(TAG, "no cargo Phonon: " + t);
            return;
        }
        try {
            String pick = null;
            for (String v : PhononNative.voices(h)) {
                if (v.toLowerCase().contains("clonada")) { pick = v; break; }
            }
            if (pick != null) PhononNative.setVoice(h, pick);
            Log.i(TAG, "voces: " + java.util.Arrays.toString(PhononNative.voices(h)) + " usando: " + (pick != null ? pick : "por defecto"));
        } catch (Throwable t) {
            Log.w(TAG, "no pude elegir la voz clonada, queda la de por defecto: " + t);
        }
        synchronized (LOCK) { handle = h; }
    }

    private static boolean unmetered(Context ctx) {
        try {
            ConnectivityManager cm = (ConnectivityManager) ctx.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            return !cm.isActiveNetworkMetered();
        } catch (Throwable t) {
            return true;
        }
    }

    /** Baja a un .tmp, comprueba el SHA256 si hay, y lo renombra. true si quedo bien. */
    private static boolean download(String url, File out, String sha) {
        File tmp = new File(out.getPath() + ".tmp");
        HttpURLConnection c = null;
        try {
            File parent = out.getParentFile();
            if (parent != null) parent.mkdirs();
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(true);
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "descarga " + out.getName() + ": HTTP " + code);
                return false;
            }
            long want = c.getContentLengthLong();
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            long got = 0;
            InputStream in = c.getInputStream();
            OutputStream os = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) {
                    os.write(buf, 0, n);
                    md.update(buf, 0, n);
                    got += n;
                }
            } finally {
                os.close();
                in.close();
            }
            if (got == 0 || (want > 0 && got != want)) {
                Log.w(TAG, "descarga incompleta " + out.getName() + ": " + got + "/" + want);
                tmp.delete();
                return false;
            }
            if (sha != null) {
                StringBuilder sb = new StringBuilder();
                for (byte b : md.digest()) sb.append(String.format("%02x", b));
                if (!sb.toString().equals(sha)) {
                    Log.w(TAG, "SHA256 no coincide en " + out.getName());
                    tmp.delete();
                    return false;
                }
            }
            if (out.exists()) out.delete();
            if (!tmp.renameTo(out)) { tmp.delete(); return false; }
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "descarga " + out.getName() + " fallo: " + t);
            tmp.delete();
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
