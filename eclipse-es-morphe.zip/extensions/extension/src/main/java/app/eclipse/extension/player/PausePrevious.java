package app.eclipse.extension.player;

import android.os.Handler;
import android.os.Looper;

import java.lang.reflect.Method;

/**
 * Pausa el reproductor ANTERIOR en cuanto Eclipse empieza a cargar una cancion nueva.
 * Recibe la instancia vieja de ExoPlayer (campo x90.y) y llama a su setPlayWhenReady(false) (metodo e0(boolean)).
 * Se pausa solo esa instancia: la cancion nueva se carga en un reproductor nuevo que arranca por su cuenta.
 */
@SuppressWarnings("unused")
public final class PausePrevious {
    private static volatile Method pauseMethod;

    private PausePrevious() {}

    public static void pause(final Object player) {
        if (player == null) return;
        try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                doPause(player);
            } else {
                new Handler(Looper.getMainLooper()).post(new Runnable() {
                    @Override public void run() { doPause(player); }
                });
            }
        } catch (Throwable ignored) {
        }
    }

    private static void doPause(Object player) {
        try {
            Method m = pauseMethod;
            if (m == null || !m.getDeclaringClass().isInstance(player)) {
                m = player.getClass().getMethod("e0", boolean.class);
                m.setAccessible(true);
                pauseMethod = m;
            }
            m.invoke(player, Boolean.FALSE);
        } catch (Throwable ignored) {
        }
    }
}
