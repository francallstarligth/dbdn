package app.eclipse.extension.es;

import java.util.HashMap;
import java.util.Locale;

/**
 * Traduce textos de la UI de Eclipse al espanol en tiempo de ejecucion.
 * Si el idioma del telefono/app no es "es", devuelve el texto original.
 */
@SuppressWarnings("unused")
public final class Translator {
    private static final HashMap<String, String> MAP = Dictionary.build();

    private Translator() {}

    public static String t(String original) {
        if (original == null) return null;
        try {
            if (!"es".equals(Locale.getDefault().getLanguage())) return original;
            String translated = MAP.get(original);
            return translated != null ? translated : original;
        } catch (Throwable ignored) {
            return original;
        }
    }
}
