package app.eclipse.extension.es;

import java.util.HashMap;
import java.util.Locale;

/**
 * Traduce textos de la UI de Eclipse al espanol en tiempo de ejecucion.
 * Si el idioma del telefono/app no es "es", devuelve el texto original.
 */
@SuppressWarnings("unused")
public final class Translator {
    private static final HashMap<String, String> MAP = Dictionary.build();

    /** Textos de Configuracion que la app compara por igualdad con la constante en ingles. */
    private static final String[] NAMES = {
        "Account", "App Skin", "Check for Update", "Download over Cellular",
        "Gapless Playback", "Lyrics", "Privacy", "Settings", "Stream over Cellular", "Version",
        "Add Playlist Songs", "Animated Art", "App Icon", "Artist Signatures", "Audio Pipeline",
        "Audio Quality", "Bit-Perfect Output", "Custom Skins", "Downloaded Music",
        "Easter Egg Seek Bars", "Eclipse and Privacy", "Font Licenses", "Music Profile",
        "Playback Speed", "Record Logs", "Release Date", "Signature API", "Song Transitions",
        "Sound Check", "Sync Now", "Transfer Music from Other Services"
    };
    private static volatile HashMap<String, String> back;

    private Translator() {}

    /**
     * Traduccion inversa SOLO de los textos de NAMES: el nombre que llega ya traducido
     * ("Privacidad") vuelve a ingles para que la comparacion de la app con su constante acierte.
     * Si el idioma no es "es" o el texto no es uno de esos, devuelve el mismo texto.
     */
    public static String back(String s) {
        if (s == null) return null;
        try {
            if (!"es".equals(Locale.getDefault().getLanguage())) return s;
            HashMap<String, String> b = back;
            if (b == null) {
                b = new HashMap<>();
                for (String n : NAMES) {
                    String es = MAP.get(n);
                    if (es != null) b.put(es, n);
                }
                back = b;
            }
            String o = b.get(s);
            return o != null ? o : s;
        } catch (Throwable ignored) {
            return s;
        }
    }

    public static String t(String original) {
        if (original == null) return null;
        try {
            if (!"es".equals(Locale.getDefault().getLanguage())) return original;
            String translated = MAP.get(original);
            return translated != null ? translated : original;
        } catch (Throwable ignored) {
            return original;
        }
    }
}
