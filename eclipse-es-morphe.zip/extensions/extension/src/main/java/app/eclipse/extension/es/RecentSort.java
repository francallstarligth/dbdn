package app.eclipse.extension.es;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Arregla el orden "Agregado recientemente": la app solo daba vuelta la lista
 * (reversed), sin mirar la fecha. Aqui se reordena por addedAt, de mas nuevo a mas viejo.
 *
 * Reglas:
 *  - Entra la lista ya dada vuelta (comportamiento original) y el orden es estable.
 *  - Los elementos sin fecha quedan arriba y conservan su orden original (son los recien agregados).
 *  - Ante cualquier problema se devuelve la lista tal como llego (como antes).
 */
@SuppressWarnings("unused")
public final class RecentSort {
    private RecentSort() {}

    private static final class Entry {
        final Object item;
        final long time;
        Entry(Object item, long time) { this.item = item; this.time = time; }
    }

    public static List<Object> resort(List<?> reversed) {
        try {
            if (reversed == null || reversed.size() < 2) return castList(reversed);
            Method getter = null;
            for (Object o : reversed) {
                if (o != null) {
                    getter = o.getClass().getMethod("getAddedAt");
                    break;
                }
            }
            if (getter == null || !Date.class.isAssignableFrom(getter.getReturnType())) {
                return castList(reversed);
            }
            ArrayList<Entry> entries = new ArrayList<>(reversed.size());
            for (Object o : reversed) {
                long t = Long.MAX_VALUE; // sin fecha = recien agregado, va arriba
                if (o != null) {
                    Object d = getter.invoke(o);
                    if (d instanceof Date) t = ((Date) d).getTime();
                }
                entries.add(new Entry(o, t));
            }
            Collections.sort(entries, new Comparator<Entry>() {
                @Override public int compare(Entry a, Entry b) {
                    return Long.compare(b.time, a.time); // mas nuevo primero
                }
            });
            ArrayList<Object> out = new ArrayList<>(entries.size());
            for (Entry e : entries) out.add(e.item);
            return out;
        } catch (Throwable ignored) {
            return castList(reversed);
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Object> castList(List<?> l) {
        return (List<Object>) l;
    }
}
