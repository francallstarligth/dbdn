package app.eclipse.extension.es;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Arregla el orden "Agregado recientemente": la app solo daba vuelta la lista
 * (reversed), sin mirar la fecha. Aqui se reordena por addedAt, de mas nuevo a mas viejo.
 *
 * Reglas:
 *  - Entra la lista ya dada vuelta (comportamiento original) y el orden es estable.
 *  - Los elementos sin fecha quedan arriba y conservan su orden original (son los recien agregados).
 *  - Ante cualquier problema se devuelve la lista tal como llego (como antes).
 */
@SuppressWarnings("unused")
public final class RecentSort {
    private RecentSort() {}

    /** Ultima lista \"Agregado recientemente\" mostrada; null si el orden activo es otro. */
    private static volatile List<Object> display;

    private static final class Entry {
        final Object item;
        final long time;
        Entry(Object item, long time) { this.item = item; this.time = time; }
    }

    public static List<Object> resort(List<?> reversed) {
        try {
            if (reversed == null || reversed.size() < 2) return castList(reversed);
            Method getter = null;
            for (Object o : reversed) {
                if (o != null) {
                    getter = o.getClass().getMethod("getAddedAt");
                    break;
                }
            }
            if (getter == null || !Date.class.isAssignableFrom(getter.getReturnType())) {
                return castList(reversed);
            }
            ArrayList<Entry> entries = new ArrayList<>(reversed.size());
            for (Object o : reversed) {
                long t = Long.MAX_VALUE; // sin fecha = recien agregado, va arriba
                if (o != null) {
                    Object d = getter.invoke(o);
                    if (d instanceof Date) t = ((Date) d).getTime();
                }
                entries.add(new Entry(o, t));
            }
            Collections.sort(entries, new Comparator<Entry>() {
                @Override public int compare(Entry a, Entry b) {
                    return Long.compare(b.time, a.time); // mas nuevo primero
                }
            });
            ArrayList<Object> out = new ArrayList<>(entries.size());
            for (Entry e : entries) out.add(e.item);
            display = out; // orden que ve el usuario (para alinear la cola)
            return out;
        } catch (Throwable ignored) {
            return castList(reversed);
        }
    }

    /** Se llama cada vez que la app recalcula el orden: si no es "Agregado recientemente", se olvida. */
    public static void reset() {
        display = null;
    }

    /**
     * La app arma la cola al reves de la lista mostrada (Siguiente subia en la pantalla).
     * Si el orden de la cola es el inverso del orden de pantalla (aunque falten o sobren
     * algunas canciones), se da vuelta. Aleatorio, otros ordenes y busquedas no se tocan.
     */
    public static List<?> alignList(List<?> queue) {
        try {
            if (isReversedVsDisplay(queue)) {
                ArrayList<Object> out = new ArrayList<Object>(queue);
                Collections.reverse(out);
                return out;
            }
        } catch (Throwable ignored) { }
        return queue;
    }

    /** Indice de la cancion tocada dentro de la lista devuelta por alignList. */
    public static int alignIndex(List<?> queue, int index) {
        try {
            if (isReversedVsDisplay(queue) && index >= 0 && index < queue.size()) {
                return queue.size() - 1 - index;
            }
        } catch (Throwable ignored) { }
        return index;
    }

    private static boolean isReversedVsDisplay(List<?> q) {
        List<Object> d = display;
        if (d == null || q == null || q == d) return false;
        int n = q.size();
        if (n < 2 || d.size() < 2) return false;
        java.util.HashMap<Object, Integer> pos = new java.util.HashMap<Object, Integer>();
        for (int i = 0; i < d.size(); i++) {
            Object k = key(d.get(i));
            if (k != null && !pos.containsKey(k)) pos.put(k, i);
        }
        int found = 0;
        int last = Integer.MAX_VALUE;
        for (int i = 0; i < n; i++) {
            Object k = key(q.get(i));
            Integer p = k == null ? null : pos.get(k);
            if (p == null) continue;
            if (p >= last) return false; // no es estrictamente decreciente
            last = p;
            found++;
        }
        return found >= 2 && found * 10 >= n * 9;
    }

    /** Identifica la cancion por su id (o por si misma si no hay getId). */
    private static Object key(Object song) {
        if (song == null) return null;
        try {
            Object id = song.getClass().getMethod("getId").invoke(song);
            if (id != null) return id;
        } catch (Throwable ignored) { }
        return song;
    }

    @SuppressWarnings("unchecked")
    private static List<Object> castList(List<?> l) {
        return (List<Object>) l;
    }
}
