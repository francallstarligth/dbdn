package app.eclipse.extension.es;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * Arregla el orden "Agregado recientemente": la app solo daba vuelta la lista
 * (reversed), sin mirar la fecha. Aqui se reordena por addedAt, de mas nuevo a mas viejo.
 *
 * Reglas:
 *  - Entra la lista ya dada vuelta (comportamiento original) y el orden es estable.
 *  - Los elementos sin fecha quedan arriba y conservan su orden original (son los recien agregados).
 *  - Ante cualquier problema se devuelve la lista tal como llego (como antes).
 */
@SuppressWarnings("unused")
public final class RecentSort {
    private RecentSort() {}

    /** Ultima lista \"Agregado recientemente\" mostrada; null si el orden activo es otro. */
    private static volatile List<Object> display;

    private static final class Entry {
        final Object item;
        final long time;
        Entry(Object item, long time) { this.item = item; this.time = time; }
    }

    public static List<Object> resort(List<?> reversed) {
        try {
            if (reversed == null || reversed.size() < 2) return castList(reversed);
            Method getter = null;
            for (Object o : reversed) {
                if (o != null) {
                    getter = o.getClass().getMethod("getAddedAt");
                    break;
                }
            }
            if (getter == null || !Date.class.isAssignableFrom(getter.getReturnType())) {
                return castList(reversed);
            }
            ArrayList<Entry> entries = new ArrayList<>(reversed.size());
            for (Object o : reversed) {
                long t = Long.MAX_VALUE; // sin fecha = recien agregado, va arriba
                if (o != null) {
                    Object d = getter.invoke(o);
                    if (d instanceof Date) t = ((Date) d).getTime();
                }
                entries.add(new Entry(o, t));
            }
            Collections.sort(entries, new Comparator<Entry>() {
                @Override public int compare(Entry a, Entry b) {
                    return Long.compare(b.time, a.time); // mas nuevo primero
                }
            });
            ArrayList<Object> out = new ArrayList<>(entries.size());
            for (Entry e : entries) out.add(e.item);
            display = out; // orden que ve el usuario (para alinear la cola)
            return out;
        } catch (Throwable ignored) {
            return castList(reversed);
        }
    }

    /** Se llama cada vez que la app recalcula el orden: si no es "Agregado recientemente", se olvida. */
    public static void reset() {
        display = null;
    }

    /**
     * La app arma la cola con la lista al reves de la que se ve (Siguiente subia en la pantalla).
     * Si la cola es exactamente la lista mostrada dada vuelta, se devuelve en el orden de pantalla.
     * En cualquier otro caso (aleatorio, otros ordenes, busquedas) no se toca nada.
     */
    public static List<?> alignList(List<?> queue) {
        try {
            if (isReverseOfDisplay(queue)) return new ArrayList<Object>(display);
        } catch (Throwable ignored) { }
        return queue;
    }

    /** Indice de la cancion tocada dentro de la lista devuelta por alignList. */
    public static int alignIndex(List<?> queue, int index) {
        try {
            if (isReverseOfDisplay(queue) && index >= 0 && index < queue.size()) {
                return queue.size() - 1 - index;
            }
        } catch (Throwable ignored) { }
        return index;
    }

    private static boolean isReverseOfDisplay(List<?> q) {
        List<Object> d = display;
        if (d == null || q == null || q == d) return false;
        int n = q.size();
        if (n < 2 || n != d.size()) return false;
        if (!sameSong(q.get(0), d.get(n - 1)) || !sameSong(q.get(n - 1), d.get(0))) return false;
        for (int i = 0; i < n; i++) {
            if (!sameSong(q.get(i), d.get(n - 1 - i))) return false;
        }
        return true;
    }

    private static boolean sameSong(Object a, Object b) {
        if (a == b) return true;
        if (a == null || b == null) return false;
        if (a.equals(b)) return true;
        try {
            Object ia = a.getClass().getMethod("getId").invoke(a);
            Object ib = b.getClass().getMethod("getId").invoke(b);
            return ia != null && ia.equals(ib);
        } catch (Throwable t) {
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    private static List<Object> castList(List<?> l) {
        return (List<Object>) l;
    }
}
