package app.eclipse.extension.diag;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Diagnostico temporal del Automix de Eclipse. Solo muestra avisos (Toast) y escribe en el log;
 * nunca cambia la reproduccion ni lanza excepciones. Los avisos son cortos (2 lineas de ~16 caracteres)
 * porque Android recorta los Toast.
 *
 * Plan (servidor api.eclipsemusic.app, clase wf0):
 *   PLAN HTTP <codigo>      el servidor respondio con error
 *   PLAN FALLO              no hubo respuesta (sin red / DNS / tiempo agotado)
 *   PLAN OK ...             llego un plan "ready" (tier, fundido, blocked, motivo)
 *   PLAN st:<estado>        llego una respuesta que NO es "ready" (y cuantos analisis pide: needs)
 *   (2.o aviso) sty:<estilo> bs<0|1>  /  f<0|1> r<velocidad> <bpm sal>><bpm entra>
 *                           estilo de transicion, bass swap, barrido de filtro, velocidad de la entrante, BPMs
 * Coordinador del analisis (clase ig0):
 *   ANALISIS pedido        el servidor pidio analizar n canciones
 *   SIN AUDIO LOCAL        se salta el analisis (la cancion es streaming)
 *   YA SUBIDO / NO SUBIDO  si esa cancion ya se subio antes (dg0.D)
 *   ANALISIS FALLO         el analisis lanzo una excepcion
 * Analisis nativo (clase tf0):
 *   BPM <x> C<y>            analyzedBpm y beatConfidence que calculo la libreria nativa
 *   SIN MODELOS             no se pudieron bajar los modelos (el analisis sigue sin ellos)
 */
@SuppressWarnings("unused")
public final class AutomixDiag {
    private static final String TAG = "AutomixDiag";
    private static final long REPEAT_MS = 30000L;

    private static String lastPlanMsg = "";
    private static long lastPlanAt = 0L;
    private static String lastAnalysisId = "";
    private static boolean readyShown = false;
    private static final java.util.HashMap<String, Long> onceAt = new java.util.HashMap<String, Long>();

    private AutomixDiag() {}

    // ---- Ganchos en wf0.invokeSuspend (pedido del plan) ----

    /** El servidor contesto con un codigo de error. */
    public static void httpFail(int code) {
        try {
            toastPlan(fmtHttp(code));
        } catch (Throwable t) {
            Log.w(TAG, "httpFail fallo: " + t);
        }
    }

    /** No hubo respuesta: excepcion de red. */
    public static void planFailed(String message) {
        try {
            toastPlan(fmtFailed(message));
        } catch (Throwable t) {
            Log.w(TAG, "planFailed fallo: " + t);
        }
    }

    /** Llego un plan con status "ready". */
    public static void planReady(String tier, boolean blocked, double fadeSeconds, String reason) {
        try {
            readyShown = toastPlan(fmtReady(tier, blocked, fadeSeconds, reason));
        } catch (Throwable t) {
            Log.w(TAG, "planReady fallo: " + t);
        }
    }

    /**
     * Segundo aviso del plan "ready": lo que decide si hay efecto DJ.
     * Solo se muestra si el aviso "PLAN OK" se mostro justo antes (misma regla de no repeticion).
     * filter = rg0.q (null si no hay barrido de filtro); bpms pueden ser null.
     */
    public static void planDetail(String style, boolean bassSwap, Object filter, double rate,
                                  Double outBpm, Double inBpm) {
        try {
            boolean show = readyShown;
            readyShown = false;
            if (!show) return;
            toast(fmtDetail(style, bassSwap, filter != null, rate, outBpm, inBpm));
        } catch (Throwable t) {
            Log.w(TAG, "planDetail fallo: " + t);
        }
    }

    // ---- Ganchos en ig0.a (coordinador del analisis) ----

    /** El servidor pidio analizar canciones. text = "analysis needed: id1,id2". */
    public static void analysisNeeded(String text) {
        try {
            toastOnce("needed", fmtNeeded(text));
        } catch (Throwable t) {
            Log.w(TAG, "analysisNeeded fallo: " + t);
        }
    }

    /** Se salto el analisis: la cancion no tiene audio local (streaming). */
    public static void noLocalAudio(String text) {
        try {
            Log.d(TAG, "noLocalAudio: " + text);
            toastOnce("noaudio", "SIN AUDIO LOCAL\n(solo streaming)");
        } catch (Throwable t) {
            Log.w(TAG, "noLocalAudio fallo: " + t);
        }
    }

    /** El analisis lanzo una excepcion. text = "analyze <id> failed: <mensaje>". */
    public static void analysisFailed(String text) {
        try {
            Log.d(TAG, "analysisFailed: " + text);
            toastOnce("failed", fmtAnalysisFailed(text));
        } catch (Throwable t) {
            Log.w(TAG, "analysisFailed fallo: " + t);
        }
    }

    /** dg0.D(id): true = esa cancion ya se subio antes (se salta el analisis). */
    public static void alreadyUploaded(boolean uploaded) {
        try {
            toastOnce(uploaded ? "up1" : "up0", uploaded ? "YA SUBIDO\n(se salta)" : "NO SUBIDO\n(sigue)");
        } catch (Throwable t) {
            Log.w(TAG, "alreadyUploaded fallo: " + t);
        }
    }

    /** Llego una respuesta que no es "ready" (o sin plan). needs = ids que el servidor pide analizar. */
    public static void planNotReady(String status, String needs) {
        try {
            toastPlan(fmtNotReady(status, needs));
        } catch (Throwable t) {
            Log.w(TAG, "planNotReady fallo: " + t);
        }
    }

    // ---- Ganchos en tf0 (analisis nativo) ----

    /** Resultado de nativeAnalysisJson para la cancion id. Una vez por cancion. */
    public static void analysis(String json, String id) {
        try {
            String key = id == null ? "" : id;
            synchronized (AutomixDiag.class) {
                if (key.equals(lastAnalysisId)) return;
                lastAnalysisId = key;
            }
            if (json != null) Log.d(TAG, "analysis " + cut(key, 24) + ": " + cut(json, 600));
            toast(fmtAnalysis(json));
        } catch (Throwable t) {
            Log.w(TAG, "analysis fallo: " + t);
        }
    }

    /** No se pudieron bajar/cargar los modelos (el codigo sigue sin ellos). */
    public static void noModels(String message) {
        try {
            Log.d(TAG, "noModels: " + message);
            toastPlan("SIN MODELOS\n(analisis sigue)");
        } catch (Throwable t) {
            Log.w(TAG, "noModels fallo: " + t);
        }
    }

    // ---- Formatos (sin Android, se pueden probar aparte) ----

    static String fmtHttp(int code) {
        return "PLAN HTTP " + code + "\n(servidor)";
    }

    static String fmtFailed(String message) {
        String m = message == null ? "" : message.toLowerCase();
        String why;
        if (m.contains("resolve") || m.contains("unknownhost") || m.contains("no address")) why = "sin DNS/red";
        else if (m.contains("timeout") || m.contains("timed out")) why = "tiempo agotado";
        else if (m.contains("refused")) why = "conexion rechazada";
        else if (m.contains("ssl") || m.contains("cert")) why = "error SSL";
        else why = cut(message == null ? "?" : message.trim(), 16);
        return "PLAN FALLO\n" + why;
    }

    static String fmtReady(String tier, boolean blocked, double fadeSeconds, String reason) {
        String t = (tier == null || tier.isEmpty()) ? "?" : tier;
        String r = (reason == null || reason.isEmpty()) ? "" : " " + cut(reason, 4);
        return "PLAN OK t:" + cut(t, 6) + "\n"
                + "f" + one(fadeSeconds) + " blk:" + (blocked ? "1" : "0") + r;
    }

    static String fmtDetail(String style, boolean bassSwap, boolean filter, double rate,
                            Double outBpm, Double inBpm) {
        String st = (style == null || style.isEmpty()) ? "?" : cut(style, 8);
        return "sty:" + st + " bs" + (bassSwap ? "1" : "0") + "\n"
                + "f" + (filter ? "1" : "0") + " r" + two(rate) + " " + bpmInt(outBpm) + ">" + bpmInt(inBpm);
    }

    static String bpmInt(Double v) {
        return v == null ? "?" : String.valueOf(Math.round(v.doubleValue()));
    }

    static String fmtNeeded(String text) {
        String ids = text == null ? "" : text;
        int k = ids.indexOf(": ");
        if (k >= 0) ids = ids.substring(k + 2);
        int n = 0;
        if (!ids.trim().isEmpty()) {
            n = 1;
            for (int i = 0; i < ids.length(); i++) if (ids.charAt(i) == ',') n++;
        }
        return "ANALISIS pedido\n(" + n + " cancion)";
    }

    static String fmtAnalysisFailed(String text) {
        String m = text == null ? "" : text;
        int k = m.indexOf("failed: ");
        if (k >= 0) m = m.substring(k + 8);
        if (m.isEmpty() || m.equals("null")) m = "?";
        return "ANALISIS FALLO\n" + cut(m, 16);
    }

    static String fmtNotReady(String status, String needs) {
        String s = (status == null || status.isEmpty()) ? "?" : status;
        int n = 0;
        if (needs != null && !needs.trim().isEmpty()) {
            n = 1;
            for (int i = 0; i < needs.length(); i++) if (needs.charAt(i) == ',') n++;
        }
        return "PLAN st:" + cut(s, 8) + "\nneeds:" + n;
    }

    static String fmtAnalysis(String json) {
        if (json == null || json.isEmpty()) return "BPM: sin datos\n(json vacio)";
        try {
            JSONObject o = new JSONObject(json);
            boolean hasBpm = o.has("analyzedBpm");
            double bpm = o.optDouble("analyzedBpm", -1.0);
            double conf = o.optDouble("beatConfidence", -1.0);
            if (!hasBpm) {
                // Formato distinto al esperado: mostrar las primeras claves para poder leerlo.
                StringBuilder k = new StringBuilder();
                Iterator<String> it = o.keys();
                while (it.hasNext() && k.length() < 30) {
                    if (k.length() > 0) k.append(',');
                    k.append(it.next());
                }
                return "BPM: ? (sin clave)\n" + cut(k.toString(), 16);
            }
            JSONArray beats = o.optJSONArray("beats");
            JSONArray downs = o.optJSONArray("downbeats");
            return "BPM " + one(bpm) + " C" + two(conf) + "\n"
                    + "b" + (beats == null ? "?" : String.valueOf(beats.length()))
                    + " db" + (downs == null ? "?" : String.valueOf(downs.length()));
        } catch (Throwable t) {
            return "BPM: no leible\n" + cut(json, 16);
        }
    }

    private static String one(double v) {
        return String.format(java.util.Locale.ROOT, "%.1f", v);
    }

    private static String two(double v) {
        return String.format(java.util.Locale.ROOT, "%.2f", v);
    }

    static String cut(String s, int max) {
        if (s == null) return "";
        return s.length() > max ? s.substring(0, max) : s;
    }

    // ---- Avisos ----

    /** Un mismo aviso del plan no se repite durante 30 s (el plan se reintenta varias veces por cancion). */
    private static boolean toastPlan(String msg) {
        long now = System.currentTimeMillis();
        synchronized (AutomixDiag.class) {
            if (msg.equals(lastPlanMsg) && now - lastPlanAt < REPEAT_MS) return false;
            lastPlanMsg = msg;
            lastPlanAt = now;
        }
        toast(msg);
        return true;
    }

    /** Aviso de ig0: el mismo tipo (key) no se repite durante 30 s. */
    private static void toastOnce(String key, String msg) {
        long now = System.currentTimeMillis();
        synchronized (AutomixDiag.class) {
            Long last = onceAt.get(key);
            if (last != null && now - last.longValue() < REPEAT_MS) return;
            onceAt.put(key, Long.valueOf(now));
        }
        toast(msg);
    }

    private static void toast(final String msg) {
        try {
            Log.d(TAG, msg.replace('\n', ' '));
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
