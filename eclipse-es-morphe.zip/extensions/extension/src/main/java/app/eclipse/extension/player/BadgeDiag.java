package app.eclipse.extension.player;

/**
 * Diagnostico temporal del icono del Quality Badge (di6.t): agrega al final del texto del badge
 * [tier|modo del icono|icon/NOICON] para ver en el telefono que recibe la app con una cancion real.
 */
@SuppressWarnings("unused")
public final class BadgeDiag {
    private static String info = "";

    private BadgeDiag() {}

    public static void set(Object tier, Object mode, Object icon) {
        try {
            info = " [" + tier + "|" + mode + "|" + (icon != null ? "icon" : "NOICON") + "]";
        } catch (Throwable t) {
            info = " [diag error]";
        }
    }

    public static String text(String text) {
        return text == null ? null : text + info;
    }
}
