package app.eclipse.extension.player;

/**
 * Diseno Bitchord NUEVO (Bitchord.eclipseplayer, schemaVersion 4: layout, presentation, lyrics y queue ya incluidos).
 * Lo usa BitchordTemplate.json() cuando el parche de Letras esta activo. Una sola constante (< 65535 bytes).
 */
final class BitchordDesign {
    static final String JSON =
        "{\"id\":\"82609163-dcc7-4355-9189-b4f7f99a8525\",\"name\":\"Bitchord\",\"schemaVersion\":4,\"background\":{\"type\":\"blurred" +
        "Artwork\",\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1},\"gradient\":{\"start\":{\"hue\":0.56,\"saturation" +
        "\":0.6,\"brightness\":0.95,\"alpha\":1},\"end\":{\"hue\":0.75,\"saturation\":0.6,\"brightness\":0.7,\"alpha\":1},\"angleDegree" +
        "s\":135},\"blur\":0.3067617118358612,\"dim\":0.3,\"opacity\":1},\"layers\":[{\"id\":\"fb19fb50-e506-45a3-8873-cac654931881" +
        "\",\"kind\":\"artwork\",\"name\":\"Artwork\",\"transform\":{\"x\":0.5,\"y\":0.28,\"width\":1,\"height\":0.56,\"rotationDegrees\":0," +
        "\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brig" +
        "htness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":tru" +
        "e,\"locked\":false,\"masksLayerBelow\":false,\"swipeToSkip\":false,\"artwork\":{\"preferAnimated\":true,\"edgeFade\":{\"edg" +
        "e\":\"bottom\",\"fraction\":0.35,\"stops\":[[0,0],[0.3,0.18],[0.65,0.72],[0.92,1],[1,1]],\"color\":{\"hue\":0,\"saturation" +
        "\":0,\"brightness\":0,\"alpha\":1,\"role\":\"immersive\"}}},\"states\":{\"queue\":{\"visible\":false},\"lyrics\":{\"visible\":fal" +
        "se}}},{\"id\":\"fa00ac6d-c1f4-4b60-9612-608b5861c3ac\",\"kind\":\"songTitle\",\"name\":\"Song Title\",\"transform\":{\"x\":0.3" +
        "74,\"y\":0.531,\"width\":0.6031219363212585,\"height\":0.03556248685712678,\"rotationDegrees\":0,\"aspectRatio\":{\"free\"" +
        ":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1}," +
        "\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"T\u00edtulo de la ca" +
        "nci\u00f3n\",\"fontSize\":20.49510955810547,\"weight\":\"bold\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":" +
        "false,\"letterSpacing\":0,\"uppercase\":false,\"marquee\":{\"enabled\":true,\"speed\":40,\"gap\":48,\"startDelayMs\":1200}}," +
        "\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"queue\":{\"visible\":false},\"lyrics\":{\"visible\":" +
        "false}}},{\"id\":\"75ce49f5-58df-4773-955d-0211bc324bc4\",\"kind\":\"artistName\",\"name\":\"Artist Name\",\"transform\":{\"x" +
        "\":0.33899999999999997,\"y\":0.5640000000000001,\"width\":0.5375998616218567,\"height\":0.03,\"rotationDegrees\":0,\"asp" +
        "ectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"bright" +
        "ness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"conten" +
        "t\":\"Nombre del artista\",\"fontSize\":18.247268676757812,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"leadin" +
        "g\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false,\"marquee\":{\"enabled\":true,\"speed\":40,\"gap\":48,\"s" +
        "tartDelayMs\":1200}},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"queue\":{\"visible\":false}," +
        "\"lyrics\":{\"visible\":false}}},{\"id\":\"9154bf8b-1abb-47e1-b94d-28ec120a0ea5\",\"kind\":\"shape\",\"name\":\"Menu disc\",\"t" +
        "ransform\":{\"x\":0.879,\"y\":0.545,\"width\":0.088,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":" +
        "1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1}" +
        ",\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visibl" +
        "e\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"queue\":{\"visible\":false},\"lyrics\":{\"visible\":false}}" +
        "},{\"id\":\"844f2bcc-1214-4071-a7eb-6f3096d41d11\",\"kind\":\"threeDotMenu\",\"name\":\"Menu\",\"transform\":{\"x\":0.879,\"y\":" +
        "0.545,\"width\":0.07230528444051743,\"height\":0.02265349814219462,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\"" +
        ":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alph" +
        "a\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":fals" +
        "e,\"masksLayerBelow\":false,\"symbolOverride\":\"menu.dots\",\"states\":{\"queue\":{\"visible\":false},\"lyrics\":{\"visible\"" +
        ":false}}},{\"id\":\"1cc4a21a-b6fc-4a42-b754-539956030e55\",\"kind\":\"favorite\",\"name\":\"Favorite\",\"transform\":{\"x\":0." +
        "7647921594975924,\"y\":0.5451221602056466,\"width\":0.07079613208770752,\"height\":0.042477679252624495,\"rotationDeg" +
        "rees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\"" +
        ":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visi" +
        "ble\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"favorite.star\",\"states\":{\"queue\":{\"visible\"" +
        ":false},\"lyrics\":{\"visible\":false}}},{\"id\":\"e29a161a-0cee-4d93-874e-a7d2af0d08f2\",\"kind\":\"shape\",\"name\":\"Menu " +
        "disc Copy\",\"transform\":{\"x\":0.7639999999999999,\"y\":0.545,\"width\":0.088,\"height\":0,\"rotationDegrees\":0,\"aspectR" +
        "atio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0" +
        ",\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\"" +
        ":{\"type\":\"circle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"queue\":{\"visible\":false},\"" +
        "lyrics\":{\"visible\":false}}},{\"id\":\"31338703-76da-40a7-a77a-f4fd26b4881f\",\"kind\":\"songTitle\",\"name\":\"Song Title" +
        "\",\"transform\":{\"x\":0.51,\"y\":0.32,\"width\":0.47,\"height\":0.4,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"app" +
        "earance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRad" +
        "ius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"Song Title\",\"fontSize\":18" +
        ",\"weight\":\"bold\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\"" +
        ":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"artwork\":{\"visible\":false}},\"layout\":" +
        "{\"container\":\"header\",\"size\":{\"height\":\"content\"}}},{\"id\":\"948a4011-b6cd-47f5-a09a-7cd9ab837e43\",\"kind\":\"artis" +
        "tName\",\"name\":\"Artist Name\",\"transform\":{\"x\":0.51,\"y\":0.71,\"width\":0.47,\"height\":0.35,\"rotationDegrees\":0,\"asp" +
        "ectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"bright" +
        "ness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"conten" +
        "t\":\"Artist Name\",\"fontSize\":15,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":fal" +
        "se,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"artwo" +
        "rk\":{\"visible\":false}},\"layout\":{\"container\":\"header\",\"size\":{\"height\":\"content\"}},\"hitTarget\":{\"minWidth\":44," +
        "\"minHeight\":44},\"accessibilityLabel\":\"Artist Name\"},{\"id\":\"8d1227ac-153e-4931-bae2-c83f38578389\",\"kind\":\"favor" +
        "ite\",\"name\":\"Favorite\",\"transform\":{\"x\":0.84,\"y\":0.5,\"width\":0.067,\"height\":0.34,\"rotationDegrees\":0,\"aspectRa" +
        "tio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1" +
        ",\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked" +
        "\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"favorite.star\",\"states\":{\"artwork\":{\"visible\":false}},\"layou" +
        "t\":{\"container\":\"header\"},\"hitTarget\":{\"minWidth\":44,\"minHeight\":44},\"accessibilityLabel\":\"Favorite\"},{\"id\":\"d" +
        "04c0f60-a952-4170-a8ec-0fd16d38147d\",\"kind\":\"threeDotMenu\",\"name\":\"Menu\",\"transform\":{\"x\":0.965,\"y\":0.5,\"width" +
        "\":0.067,\"height\":0.34,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"no" +
        "rmal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShado" +
        "w\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"menu.dots" +
        "\",\"states\":{\"artwork\":{\"visible\":false}},\"layout\":{\"container\":\"header\"},\"hitTarget\":{\"minWidth\":44,\"minHeight" +
        "\":44},\"accessibilityLabel\":\"Menu\"},{\"id\":\"e0c5d0ac-0747-4092-8520-9e5586f9d307\",\"kind\":\"artwork\",\"name\":\"Artwo" +
        "rk\",\"transform\":{\"x\":0.095,\"y\":0.5,\"width\":0.19,\"height\":0.76,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":" +
        "1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha" +
        "\":1},\"cornerRadius\":{\"uniform\":{\"_0\":8}},\"innerShadow\":false,\"backgroundBlur\":0},\"functionOverride\":\"closePane" +
        "\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"swipeToSkip\":false,\"artwork\":{\"fit\":\"fill\"},\"states\":" +
        "{\"artwork\":{\"visible\":false}},\"layout\":{\"container\":\"header\",\"size\":{\"width\":{\"units\":64},\"height\":{\"units\":64" +
        "}}}},{\"id\":\"23c5a2b5-5249-4b48-bb87-e7f1af8cd07e\",\"kind\":\"shape\",\"name\":\"Cover tap\",\"transform\":{\"x\":0.095,\"y\"" +
        ":0.5,\"width\":0.19,\"height\":0.76,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opac" +
        "ity\":0.01,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"unifo" +
        "rm\":{\"_0\":8}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"roundedRect\"},\"functionOverride\":\"close" +
        "Pane\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"states\":{\"artwork\":{\"visible\":false}},\"layout\":{\"" +
        "container\":\"header\",\"size\":{\"width\":{\"units\":64},\"height\":{\"units\":64}}},\"hitTarget\":{\"minWidth\":64,\"minHeight" +
        "\":64}},{\"id\":\"22e1a3aa-769d-4541-8f2c-214164943b90\",\"kind\":\"progressBar\",\"name\":\"Progress\",\"transform\":{\"x\":0." +
        "5,\"y\":0.23,\"width\":0.845,\"height\":0.4,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1" +
        ",\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\"" +
        ":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"seekBarSty" +
        "le\":\"classic\",\"layout\":{\"container\":\"progress\",\"size\":{\"height\":{\"units\":24}}}},{\"id\":\"d4ed63bc-89a2-45fe-9e11" +
        "-9935053860ee\",\"kind\":\"elapsed\",\"name\":\"Elapsed\",\"transform\":{\"x\":0.149,\"y\":0.535,\"width\":0.14,\"height\":0.3,\"r" +
        "otationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0," +
        "\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBl" +
        "ur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"leading\",\"allo" +
        "wsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"" +
        "layout\":{\"container\":\"progress\",\"size\":{\"height\":\"content\"}}},{\"id\":\"cf4842c8-ce2f-4929-901f-a23afa3f9e36\",\"ki" +
        "nd\":\"remaining\",\"name\":\"Remaining\",\"transform\":{\"x\":0.851,\"y\":0.535,\"width\":0.14,\"height\":0.3,\"rotationDegrees" +
        "\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0" +
        ",\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":" +
        "{\"content\":\"3:42\",\"fontSize\":13,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"trailing\",\"allowsOverflow\":f" +
        "alse,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"remaining\":{\"" +
        "prefix\":\"-\"},\"layout\":{\"container\":\"progress\",\"size\":{\"height\":\"content\"}}},{\"id\":\"aa49f5d1-966a-4a8f-aa8a-361" +
        "160fa4d04\",\"kind\":\"qualityBadge\",\"name\":\"Quality Badge\",\"transform\":{\"x\":0.5,\"y\":0.535,\"width\":0.4,\"height\":0." +
        "4,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.7032073736190796,\"blendMode\":\"norma" +
        "l\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":" +
        "false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"badge\":{\"showsBackground\":fal" +
        "se,\"shape\":\"capsule\",\"backgroundOpacity\":0.12,\"fontSize\":12.69775390625,\"bold\":false,\"uppercase\":false,\"horizo" +
        "ntalPadding\":8,\"compact\":false,\"mode\":\"tier\",\"animated\":\"shimmer\",\"icon\":\"auto\"},\"layout\":{\"container\":\"progre" +
        "ss\"}},{\"id\":\"5facc0f3-f526-47c9-bdcd-c08b6bc393e7\",\"kind\":\"previous\",\"name\":\"Previous\",\"transform\":{\"x\":0.202," +
        "\"y\":0.4,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opa" +
        "city\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform" +
        "\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"sym" +
        "bolOverride\":\"previous.double\",\"layout\":{\"container\":\"transport\"}},{\"id\":\"1baeb6ce-55b6-4548-9bde-c686f816d09c" +
        "\",\"kind\":\"playPause\",\"name\":\"Play\\/Pause\",\"transform\":{\"x\":0.5,\"y\":0.4,\"width\":0.1197,\"height\":0,\"rotationDegr" +
        "ees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"" +
        "saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlu" +
        "r\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"play.thick\",\"layout\":{\"container" +
        "\":\"transport\"}},{\"id\":\"abed0017-2eda-4ea1-a64c-1d2001d5644a\",\"kind\":\"next\",\"name\":\"Next\",\"transform\":{\"x\":0.8," +
        "\"y\":0.4,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opa" +
        "city\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform" +
        "\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"sym" +
        "bolOverride\":\"next.double\",\"layout\":{\"container\":\"transport\"}},{\"id\":\"4ad7080f-4a7d-453a-a538-21c1507663d4\",\"k" +
        "ind\":\"image\",\"name\":\"Volume min\",\"transform\":{\"x\":0.102,\"y\":0.405,\"width\":0.05,\"height\":0,\"rotationDegrees\":0," +
        "\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"satur" +
        "ation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0}" +
        ",\"imageData\":\"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAQeUlEQVR4Ae3BC\\/CldX0f4OenZLMSZl0J67KBVXbpElkqpFw" +
        "UXeUomODCOBJTkjWTNmAnyKhLUNvRdlJbTTMaM426atXYeBnsIFMVqQ0XE7kU+UNDrUgULwejaOOBqWOpg4bRlk8zbaaTWi+Ae959f+f9Pk9Lo" +
        "pQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFN" +
        "LopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilT" +
        "FNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKeRjW4QR" +
        "8FvcpXWpJlPIQbMTP42U4FX+Kt+CP8A2lKy2JUh6EDXgp\\/h6O9v\\/7Mt6DP8BC6UJLopQfYQc+jJ1+tDleg\\/cpo9eSKOWHeB4uxToPzZ\\/gB" +
        "fiqMlotiVJ+gDfiNz1838TzcaUySi2JUr7HYbgaJ9k\\/\\/gHepYxOS6KUv+GJ+CgOt\\/\\/8JU7GHcqotCRK+Wtn4w+x2f53O56M+5XRaEmU8lc" +
        "uwpss1yvwemU0WhJl8t6CF1u+z+E5uFMZhZZEmaz1+DDONIwFzsYnlVFoSZRJOgx\\/im2GdTquU0ahJVEmZxs+iUcb3h5cpoxCS6JMypNxI37C" +
        "gfEivE0ZhZZEmYy\\/i8vwCAfOBXinMgotiTIJr8DrHHh7cJkyCi2JsvL+EC8wDrtxtTIKLYmysh6Bt+M3jMfpuE4ZhZZEWVmX4NeMxz14Dm5VR" +
        "qElUVbSJ3CicbkbZ+AOZRRaEmXl3IxTjc9tOBd3KqPQkigr5UrsNk4LPAt3KKPQkigr44N4nnF7Em5VRqElUVbCJfg143c6rlNGoSVRuvcGXKw" +
        "P5+AKZRRaEqVrr8Ur9eM8vFcZhZZE6dY\\/xWv05UV4mzIKLYnSpRfhrfrzErxVGYWWROnOeXi3Pl2ENyuj0JIoXfkVvF+\\/LsA7lVFoSZRuPBt" +
        "X6dsFeKcyCi2J0oVn4lr9Ow\\/vVUahJVFG76m4yWo4D+9VRqElUUbteNyGZjXswWXKKLQkymg9AZ\\/BI6yOPbjMsLbhcbgV31b+r5ZEGaWj8Xk" +
        "80mo5B1cYzmn4AzyAb+F6\\/BnehwdMXEuijM4WfBnrrJ5zcIVhPBcf9v39W\\/yyiWtJlFHZhK9gvdW0G1cbxlV4th9sDWfgfhPVkiijsR2fwXq" +
        "razeutnyH4RYc7Yf7In4O95mglkQZhTNxCTZZbbtxteU7EZ\\/w4NyN4\\/ANE9OSKAfUevwLvNw0nI7rLN8JuApbPDj34G\\/hPhPSkigHzA5cgW" +
        "NNx+m4zvLtwA3Y4sGb42R800S0JMrgNuEUfBDrTcsurFm+rbgJWz0038FRWJiAlkRZusNwJJ6On8dx2G6admHN8m3CLdjuofsuHo+FFdeSKA\\/" +
        "bOhyEg3AQfhLr8Sisx9NwBo7D\\/TjOtN2D5+BWy7cRazjWw\\/NdPB4LK6wlsaLWYT1+Co\\/FTyIevAdwMA7FRmzAY\\/AYPBqPxqNxCB6F9ViHn" +
        "8Ajcbjyve7Bc3Cr5TsE1+MkD9938XgsrKiWxIr4WZyMn8ZOPA5HYgO+hZ3KgXYPzsSnLN96XIPT\\/Hi+hKfha1ZQS6JzG\\/GPcC52KGN2D87Ep" +
        "yzfOlyOs\\/z43oPzraCWRMeOxx\\/hSKUHd+MM3GEYl2KP\\/ePp+LgV05Lo1Mm4VenJ3TgDdxjG23Ch\\/WOOE3GfFdKS6NBGfAqPU3qywAxzw3g" +
        "tXmn\\/eRV+2wppSXTopfh9pTcLzDA3jBfjLfafb+FEfMGKaEl05lB8FCcpvbkN5+JOw\\/iH+D3714dwLh6wAloSnTka1+NIpTcL7ManDONVeLX" +
        "967\\/hGbjdCmhJdOYEXIPNSo9Ox3WG8Sq82v73JlxsBbQkOvNsXKX0ag8uM4zX4pX2vwX+Du7RuZZEZ34d71F6dRHebBhvwMWW4wK8U+daEp15" +
        "FV6t9Op1+MeG8QZcbDluxy7cp2Mtic68HS9UevVuvMAw3oYLLc8zcIOOtSQ6sg4fxm6lV1fiF\\/Edy\\/cunG95\\/h2eq2MtiY6sxwdwttKrq\\/" +
        "FL+LblexfOtzx34Lm4U6daEh05BNfiFKVXf4Kz8R3Ldyn2WK6X4\\/d1qiXRkUNwPU5SevV+PN8wLsUey3Ubno77dKgl0ZFDcD1OUnr1RrzUMD6" +
        "I51m+p+AWHWpJdGQDbsTxSq9egddbvnW4HGdZvn+FF+tQS6IjG3Ajjld6dR7ea\\/nW4XKcZfm+gpPwdZ1pSXRkA27E8UqvduNqy7cOV+IMwzgX" +
        "H9CZlkRHNmINxyo9ugfPwa2Wbz2uwWmGcSXO1pmWREc2Yg3HKj26DefiTsu3HtfgNMP4NJ6LP9eRlkRHNmINxyo9+gs8E3PLdzCuxZMN52xcqS" +
        "MtiY5sxBqOVXq0wAxzy7ceH8DZhvNK\\/K6OtCQ6cihuxjFKjxaYYW751uMqPMNwrsA5OtKS6MihuBnHKD1aYIa55VuHy3GW4Xwau\\/BNnWhJdO" +
        "RQ3IxjlB4tMMPcMC7FHsO5GzN8QSdaEh3ZhFuwXenRAjPMDeNdON+wzsaVOtGS6Mgm3ILtSo8WmGFuGG\\/AxYb1avxznWhJdGQTbsF2pUcLzDA" +
        "3jFfh1Yb1Pvw6HtCBlkRHtmANRyk9WmCGuWG8GG8xrJvxLHxbB1oSHdmCNRyl9GiBGeaG8WK8xbA+i6fiXh1oSXRkC9ZwlNKjBWaYG8Ze7DOsu" +
        "\\/AULHSgJdGRLVjDUUqPFphhbhh7sc+w7sZpmOtAS6IjW3ETtio9WmCGuWHsxT7DexJu1YGWREe24iZsVXq0wAxzw9iLfYa3C2s60JLoyFbchK" +
        "1KjxaYYW4Ye7HP8HZhTQdaEh3ZhhtxhNKjBWaYG8Ze7DO8XVjTgZZER7bhRhyh9GiBGeaGsRf7DG8X1nSgJdGRbbgRRyg9WmCGuWHsxT7D24U1" +
        "HWhJdGQHbsAWpUcLzDA3jL3YZ3i7sKYDLYmO7MAN2KL0aIEZ5oaxF\\/sM7ym4RQdaEh3ZgRuwRenRAjPMDWMv9hnWXXgKFjrQkujIDtyALUqPF" +
        "phhbhh7sc+wPo4z8W0daEl0ZCc+hsOVHi0ww9ww9mKfYb0JF+tES6IjO\\/ExHK70aIEZ5oaxF\\/sM61x8QCdaEh3ZiY\\/hcKVHC8wwN4y92Gc4" +
        "d+FkfF0nWhIdOQHXYLPSowVmmBvGXuwznDfipTrSkujICbgGm5UeLTDD3DD2Yp9h3Itn4RM60pLoyAm4BpuVHi0ww9ww9mKfYazhmfiOjrQkOn" +
        "IKPoLNSo8WmGFuGHuxzzB+A\\/9aZ1oSHTkFH8FmpUcLzDA3jL3YZ\\/m+hhNxj860JDpyCj6CzUqPFphhbhgvxNst33twvg61JDpyIj6h9GqBGe" +
        "aG8Tv4J5brXuzGLTrUkujITvwxfkbp0QIzzA3jXTjfct2OXbhPh1oSHdmGG3GE0qMFZphbvnW4HGdZrovwZp1qSXRkE27BdqVHC8wwt3wH41o8" +
        "2fL8V5yCu3SqJdGRjVjDsUqPFphhbvk2Yg3HWp7LsEfHWhIdORgfwplKjxaYYW75tmANR1meX8Af61hLojP\\/Br+q9GiBGeaWbwduwBbL8Vk8C" +
        "ffpWEuiM6\\/A65QeLTDD3PKdiE9Ynt\\/C7+hcS6Iz5+BypUcLzDC3fCfhI9hi\\/\\/sMTsb9OteS6MxOXIvNSm8WmGFu+U7ANdhs\\/\\/pLPBFft" +
        "AJaEp05DNfgRKU3C8wwt3w78TEcbv+6EO+wIloSHXoZ\\/qXSmwVmmFu+HbgBW+w\\/V2O3FdKS6NBG\\/BmOVHqywAxzy7cDN2CL\\/eMb+Fl83Qp" +
        "pSXRqFz6u9GSBGeaWbxtuxBH2jzPxUSumJdGxp+E6HKT0YIEZ5pZvK27CVj++t+IlVlBLonMn4EPYrozdAjPMLd8WrOEoP545TsR9VlBLYgU8F" +
        "i\\/Dr+AoZawWmGFu+TbhFmz38P0FTsI9VlRLYoUcirNxEU5WxmaBGeaWbxNuwXYPzwP4GdxjhbUkVtDB+Ns4A2fiCNyPTfaPe\\/E\\/8dN+sM3K" +
        "91pghrnlOxQ34xgPXXA8Pm3FtSRW3Dpsxjb8D\\/tH\\/B\\/ND\\/YAtmIbtuNx2IzH4CBsNT0LzDC3fBuxhmM9NA\\/gOHzOBLQkyiDWYR0ehQ3Yi" +
        "Q9gnelYYIa55duAG3G8B+9uPA1fNBEtiXLA7MS12GwaFphhbvkOwfU4yYPzNZyKr5qQlkQ5oDbgKjzV6ltghrnlOxhX4Fl+tM\\/jVNxrYloSZR" +
        "T+Pc622haYYW4Ye7HPD3cNzsH9JqglUUbjg3ie1bXADHPDeCyuxXG+v9fjFSasJVFG5UrstpoWmGFuOE\\/AZ\\/2\\/vokX4v0mriVRRudaPNPqW" +
        "WCGuWEdjbdhB27HhVgoWhJllG7GqVbLAjPMHRjPwG24V\\/nfWhJltD6Jn7M6FphhroxCS6KM2h041mpYYIa5MgotiTJq63EHtunfAjPMlVFoSZ" +
        "TRW485jtS3BWaYK6PQkihdOAR3YrN+LTDDXBmFlkTpxgZ8CYfq0wIzzJVRaEmUrmzEXdigPwvMMFdGoSVRunMY7sLB+rLADHNlFFoSpUub8BWs" +
        "148FZpgro9CSKN3agi9jnT7chnNxpzIKLYnSta34cxxk\\/BbYjU8po9CSKN07Gp\\/HI43fLqwpo9CSKCvhCfgMHmHcduNqZRRaEmVlHIH\\/hMO" +
        "N1x5cpoxCS6KslE34L1hnnC7AO5VRaEmUlbMDd+Ag4\\/PP8BplFFoSZSVtxZ1YZ1zeiJcqo9CSKCtrC+7Ewcbj3XiBMgotibLSDsMXscE4fAi\\" +
        "/pIxCS6KsvI34HDY78D6Gs\\/Ad5YBrSZRJOAS3Y5sD66P4RXxbOeBaEmUy1uM\\/41gHzjtwoTIKLYkyOTfjVAfG8\\/F+ZRRaEmWSrsRuw7oHp+" +
        "ELyii0JMpkfRDPM5zb8HTcp4xCS6JM2jtwgWG8GRcpo9GSKJP3Blxsue7FkzBXRqMlUcpf+S38tuV5K16ijEpLopS\\/9nz8Ho6wf\\/13PBFfVU" +
        "alJVHK33AoXo7fxE\\/ZP\\/4+LlFGpyVRyvdxDN6MX\\/Dj+VVcqoxSS6KUH+JsvANHeGgewHm4RBmtlkQpP8KheDn2YLsf7bt4Fv6DMmotiVIep" +
        "GNwIfZgi+9vjjPxJWX0WhKlPESb8cs4H4\\/CI\\/EfcTsuwd1KF1oSpTxMG7ATn8O9SndaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmq" +
        "SVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFK" +
        "mqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJl" +
        "FKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUafpfIpO0TMleHq8AAAAASUVORK5CYII=\",\"visible\":true,\"locked\":f" +
        "alse,\"masksLayerBelow\":false,\"layout\":{\"container\":\"volume\"}},{\"id\":\"1c9f8aa9-8be7-4ba7-9e5f-1f863bfa424c\",\"ki" +
        "nd\":\"volumeSlider\",\"name\":\"Volume\",\"transform\":{\"x\":0.5,\"y\":0.405,\"width\":0.689,\"height\":0.82,\"rotationDegrees" +
        "\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"" +
        "brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\"" +
        ":true,\"locked\":false,\"masksLayerBelow\":false,\"layout\":{\"container\":\"volume\"}},{\"id\":\"ffbcaae0-5c5a-40e3-bc2d-0" +
        "50fec65adb1\",\"kind\":\"image\",\"name\":\"Volume max\",\"transform\":{\"x\":0.896,\"y\":0.405,\"width\":0.05,\"height\":0,\"rota" +
        "tionDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":" +
        "{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"bac" +
        "kgroundBlur\":0},\"imageData\":\"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAYDklEQVR4Ae3BDdjedV0o8M9v0Fo0ce2wx" +
        "nh6ZA9rOEkHCpMxBG7AADV5M99fUisxFV96UbJOluVR03NELBM7Kh6tg5IJgmdACo6HjfFy6yAdMGQTEXFCQPMvjgl8u07nujpXV6aM3b\\/\\/\\" +
        "/b+f+\\/v5lIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJ" +
        "SKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJ" +
        "KaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipDREP4\\/9cRO2YYfUmhIRUhqC+XguXofdMBu34Gpcja\\/in3C\\/VE2JCCm1aHe8AO" +
        "\\/EL\\/jP3Yx78A+4EmuwQxqoEhFSatHf4oV23lX4A6zFDmkgSkRIqSUb8QS7Zi3ejHXSLisRIaUW3ITHG4wGV+CPca30qJWIkFJlF+FZBq\\/Bp" +
        "Xg7rpd2WokIKVW0F9ZhqXq+hwvwNmyWHrESEVKqaAWu0Y5v4PdxrvSIlIiQUkVvxPu061N4FbZJP1aJCClVdAFO1L47cRKulf5TJSKkVMl8XIT" +
        "DDMcP8Ra8T\\/qRSkRIqZI5uARHGq4r8Dxslf6dEhFSquhDOM3wbcPzcbH0b0pESKmi1+P9uuM9eLP0r0pESKmio3GZblmDE7DdmCsRIaWK9sJa" +
        "7K9bbsMhuNsYKxEhpcoW4puYrVu+h1\\/C7cZUiQgpteBAXI6f0y07sBJfMYZKREipJYfgKuyuWx7GybjQmCkRIaUWHYB\\/xCzdcxSuMEZKREip" +
        "ZRNYi311z3H4B2OiRIQ00mbh6bgXBfdiK7bptgV4K56PRbrl5fi4MVAiQhpZc\\/FBvNT\\/twk7cCuuwjfxeWzTTQvxPPwGluuOF+BTZrgSEdJI" +
        "2her8QQ\\/2bV4GW7SXXNxMF6DJ2Op4TsZF5jBSkRII2cS12KhR2473oizdd8U\\/hQvNnzPwMVmqBIR0kiZxBbs5tH5FF6GHbrvuTgbP2e4jsHl" +
        "ZqASEdLImMQW7GbXXIyTsEP3LcCHcKrhOhzrzDAlIqSRMIkt2M1gPA\\/nGR3Pxkexl+EIHIQbzCAlIqTOm8QW7GZwNuJQNEbHXjgTLzYcD+OXc" +
        "JMZokSE1GmT2ILdDN4L8Cmj5zj8DfbSvofweNxqBigRIXXWJLZgN3VchpPQGD174Uy8WPsexH643YgrESF10iS2YDf1bMThuM\\/oOg5n4gnatQ" +
        "OLcacRViJC6pwluBm7qesbWIU7jbZ5OB9Hadd2PA53GVElIqROWYJNmKW+O3AEtpgZbsLjtet+7Iu7jaASEVJnLMEmzNKOrTge15s5bsLjtesG" +
        "HIFtRkyJCKkTlmATZmnXMbjczHI9lmvXu\\/D7RkyJCGnolmATZmnfSficmed6LNee7ViFrxghJSKkoVqCTZhlOI7HpWamq\\/FU7bkRh+B+I6JE" +
        "hDQ0S7AJswzPMbjczHU1nqo9b8GfGxElIqShWIJNmGW4Dsc6M9vVeKp23I8nY5MRUCJCat0yfA2zDNdWPBvXmvm+hKO041ocie06rkSE1Kpl2I" +
        "hi+L6DY7HReFiPQ7Xj9fiAjisRIbVmGTai6IY7cRRuMR7mYjMWqG8bnojbdViJCKkVy7ARRXfcgSOwxfhYin\\/ET6vvC\\/hlHVYiQqpuGTai6J" +
        "bbcThuN15Oxme146X4pI4qESFVtQwbUXTPZqzEXcbP+\\/BG9X0Vx+K7OqhEhFTNMmxE0U2bcBjuMZ6uwQr1vR4f0EElIqQqlmEjiu66Eatwn\\/" +
        "G0F27BPHXdjEPQ6JgSEdLALccGFN12A47ANuNrBdZhd3WdjAt0TIkIaaCWYwOK7rsUz0FjvL0U\\/0tda3AcduiQEhHSwCzHBhSj4TocjcZ4m4P" +
        "LcJh6tuF4rNchJSKkgViODShGRx89NOp7EvbA1brpibgae6jnPDxPh5SIkHbZcmxAMVr66KFR11H4azyIK\\/AhbNA978Mb1XMvDsUtOqJEhLRL" +
        "lmMDitHTRw+Nek7FZ\\/x738ZLcLlumY8bMKGed+MMHVEiQnrUlmMDitHURw+NOuahj\\/38aCfjAt3yLFyknjtwEO7WASUipEflibgBxejqo4dG" +
        "HSfiAj\\/eC\\/Ap3XIJjlPPG3CWDigRIe205ehjd6Otjx4adZyCv\\/eTvRYf1B1L8BU8Rh034xA0hqxEhLRTnoWPYYHR10cPjTpOwvkemT\\/Cn+" +
        "qO38V71HMyLjBkJSKkR+wteJeZo48eGnWchPM9cr+Oj+qGufgylqpjDY7DDkNUIkJ6RD6CV5pZ+uihUcdJON\\/OeRk+oRuehkvxMwZvG47HekN" +
        "UIkL6sRbhvXiRmaePHhp1nITz7ZwH8XSs0Q0fwOvUcR6eZ4hKROioudgbj8V38c\\/Yjh1+stmYjdn4aczFY\\/EA7sb3sR07\\/GiT6OH5WIJlZq" +
        "Y+emjUcQJW23n3Yn\\/cbfgOxf\\/BfIN3Lw7FLYakRISOmIUT8Tgcjv3xWHwf83AvvoWbsQU34AE8DntiERZhHhZgHh6D2fhp\\/BP2wG7Yhu\\/i" +
        "dmzFFtyMn8Vr8IvY38zXRw+NOk7Aao\\/OpTje8M3FWixXx7txhiEpEaEDFuFcHCm1qY8eGnWcgNUevd\\/G+wzf7+I96ujjBNxtCEpEGLKT8Ak8" +
        "RmpbHz006jgBqz16O7ACNxiufXEtFhi8rTge1xuCEhGGZBb+BH8oDUsfPTTqOAGr7Zpv4knYZrg+i5PV8XJ83BCUiDAkH8RvScPURw+NOk7Aar" +
        "vuHLzCcD0bn1PHh3GaISgRYQhOwGpp2ProoVHH0bjMYLwQ5xqe+ehjscG7Fj3cr2UlIrRsD1yF5dKw9dFDo46jcZnBuB8H4DbD8w681eDdgcNw" +
        "u5aViNCyU\\/EZqQv66KFRx9G4zODcgEOx3XAsx5fwcwbvGFyuZSUitOyTeLHUBX300KjjaFxmsM7Auw3HbFyOVQbvDLxby0pEaNE8XItflLqgj" +
        "x4adRyNywzWV3EYGsPxEnzC4F2Ak7WsRIQWHYzrpK7oo4dGHUfjMoPXwxrDsRBfxj4G62asxH1aVCJCiw7GdVJX9NFDo45VWGvwzsErDM\\/H8H" +
        "KD9V0ci69qUYkILVqBa6Su6KOHRh2rsNbgfQeH4A7D8VRcbfBegE9pUYkILVqBa6Su6KOHRh2rsFYdv4n\\/aTgOwD9gH4P1frxRi0pEaNEKXCN" +
        "1RR89NOpYhbXqWIejsUP7JrEWkwbrShyP+7WkRIQWrcA1Ulf00UOjjlVYq4778HT0tW8+rsL+BuubWIk7taREhBatwDVSV\\/TRQ6OOFbgQC9Vx" +
        "Jt6kfXPxJRxs8I7AlVpSIkKLVuAaqSv66KFRxwpciIXq+AYOxj3aNQeX4EiD9wacpSUlIrRoBa6RuqKPHhp1rMCFWKie5+LvtO8zONXgfRrP15" +
        "ISEVq0AtdIXdFHD406VuBCLFTPajxT+\\/4KrzZ4X8Xh2KYFJSK0aAWukbqijx4adazAhVionn\\/CobhVu\\/4If2Lwrsep2KwFJSK06CnoS13RR" +
        "w+NOlbgQixU1xtwlnb9Jj6sjkPQ14ISEVp0Es6XuqKPHhp1HIhLsFBdZ+JN2vV8nKuOU3C+FpSI0KLX4\\/1SV\\/TRQ6OOA3EJFqrrfJyiXUfjM" +
        "nW8AWdpQYkILXof3ih1RR89NOo4EJdgobqmcRy2a8+BuAQLDd6ZeJMWlIjQos\\/iZKkr+uihUceBuAQL1XUjVuE+7ZnCNCYM3vk4RQtKRGjJHr" +
        "gMh0pd0UcPjToOxCVYqK5vYRVu154FWI\\/9DN7VOAb3q6xEhJbMx3oslbqijx4adRyIS7BQXVtxDDZqzzyswxMM3jqchLtVViJCSxbjM3iK1BV" +
        "99NCo4wB8EXur7xhcrj174DIcavC+jlW4S2UlIrRkClfgF6Su6KOHRh0H4IvYW30vx8e1ZzY+i2cavM1YibtUViJCS6YwjQmpK\\/rooVHHAfgi" +
        "9lbfW\\/Dn2vVRvMLgbcZK3KWyEhFaMoVpTEhd0UcPjToOwBext\\/rOxqu16504w+BtxkrcpbISEVoyhWlMSF3RRw+NOg7AF7G3+j6Bl+Nh7Xkt" +
        "\\/sLgbcZK3KWyEhFaMoVpTEhd0UcPjTqWYg0Wqe+v8Brtei3+wuBtxkrcpbISEVoyhWlMSF3RRw+NOpZiDRap7214u3adjrMM3tX4FdytshIRW" +
        "jKFaUxIXdFHD406lmINFqnv1Thbu07HWQavjx4alZWI0JIpTGNC6oo+emjUsRRrsEh9p+B87TodZxm81TgZO1RWIkJLpjCNCakr+uihUcdSrME" +
        "i9R2Oddp1Os4yeOfgFVpQIkJLpjCNCakr+uihUcdSrMEidW3FMdioXafjLIP3NrxdC0pEaMkUpjEhdUUfPTTqmMI0JtT1LazC7dp1Os4yeK\\/G" +
        "2VpQIkJLpjCNCakr+uihUccUpjGhrluwEvdo1+k4y+A9AxdrQYkILZnCNCakruijh0YdU5jGhLq+gFPQaNdp+JDB2orjcb0WlIjQkilMY0Lqij" +
        "56aNQxhWlMqOtsvFr7\\/jdeYLC+jadhixaUiNCSKUxjQuqKPnpo1DGFaUyo64U4V7vmYhoHGaxbsBL3aEGJCC2ZwjQmpK7oo4dGHVOYxoR6tuJ" +
        "IbNKuSVyFCYP1ZRyFRgtKRGjJFKYxIXVFHz006pjEWkyqZwOOQKNdT8O0wVuNk7FDC0pEaMkUpjEhdUUfPTTqmMRaTKrnwzhN+07DhwzeOXiFl" +
        "pSI0JIpTGNC6oo+emjUMYm1mFTPC3Gu9p2NVxm8t+HtWlIiQksW4zN4itQVl+I5aNQxibWYVMdWHIlN2rUHvoQVBu\\/l+LiWlIjQkklMY1+pK6" +
        "7HkdimjkmsxaQ6NuAINNq1COvxOIP3DFysJSUitGQB1mM\\/qSs24TDco45FWIfF6vgwTtO+Ffg8FhisrTge12tJiQgtmYd1eILUFZuxEnepYxH" +
        "WYbE6nou\\/075fwzkG79t4GrZoSYkILZmLL+FgqStux+G4XR2LsA6LDd5tOAR3a9+ZeIPBuwUrcY+WlIjQkjm4BEdKXXEHjsAWdSzCOiw2eGfi" +
        "Tdo3GxfjaIP3BZyCRktKRGjJLHwCL5K64js4FhvVsQjrsNhg3YsebtC+vXARDjV478GbtahEhBa9Eh+RumIrno1r1bEI67DYYF2E52CH9p2Kz6" +
        "jjKFyhRSUitGhfrMfeUlccjnXqWID12M\\/gNDgItxqOz+OZBu\\/rWIH7tKhEhJZdhGdJXfEMXKyOBViP\\/QzOq\\/DXhmMJ1mMvg\\/dJvFTLSkR" +
        "o2a\\/iPKkrTsLn1LEA67GfwViHww3P7+C96ngO\\/l7LSkRo2R5Yi4OkLjgel6pjAdZjP7uuwRNxm+GYi2kcZPDuwArcqWUlIgzBM\\/F5qQsOxz" +
        "p1LMB67GfX\\/QY+YnhW4ip1\\/B1eiAe1rESEIdgdq\\/F0aZi24nhcr475uAiH2TV\\/jVcZrr\\/Ea9TxYvytISgRYUjmYCOmpGG5E0fhFnUswlp" +
        "MefTW4zDDtRcuxsEG7w4cjK2GoESEIZqDG7FYGobbcThuV8ck1mLSo\\/MdPB7bDNfpOEsdH8MrDUmJCEO2O87DyVLbNmMl7lLHUqzBIjtvO34R" +
        "dxiuubgOj1fHUbjCkJSI0AGzcSL+K5ZLbbkRq3CfOg7AF7G3nfMwVuFqw3cSzlfHJhyK+wxJiQgdMhcH4FgcjwlsxwIEAg\\/iITyMB\\/EQ7seD" +
        "eAA\\/xAPYhh\\/gAWzHvdiOH2A7duA+PIAH8D08BS\\/C3ngI\\/wX3YpmZ6VI8B406VuBCLLRzXopPGr7ZWIOV6ngH\\/tAQlYjQUbOxEJP4Pn6IH" +
        "2I7HsSDeAgP40E8jIfxsP9nh0dnNhZjAg\\/g+3gTfs3Mcx2ORqOOVVhr55yGD+uGlbgEexq8e3A0bjBEJSKkR+QjeKWZpY8eGnWcgNUeuRfiXN" +
        "3xaTxXHVfiWOwwRCUipEfsLXiXmaOPHhp1PAsX+ckexsvxCd2xDFdhnjpeh780ZCUipJ3yLHwMC4y+Pnpo1LEKa\\/14D+AoXK1b3o\\/Xq2MrDs" +
        "VthqxEhLTTlqOP3Y22Pnpo1LEUa7HAj7YVB+MO3bIQG7C3Ov4ez9EBJSKkR+WJuAHF6Oqjh0Yde+BiHOE\\/ugLPxjbd82a8Wz0n4kIdUCJCetS" +
        "W4WuYZTT10UOjnnk4A6fiIXwNX8KH8KDumYfrsEQdm7EC9+iAEhHSLlmCm7Gb0dNHD436lmN3fFm3\\/SrOU88H8VodUSJC2mWTuBU\\/ZbT00UM" +
        "j\\/V9LcD1+Vh334plYryNKREgDsQjfwGyjo48eGmkO+jhAPRtwBBodUSJCGpgF+BZmGw199NBIb8U71PW7+O86pESENFALcBt+Rvf10UNjvJ2M" +
        "z6rrFpyIm3RIiQhp4PbCddhXt\\/XRQ2N8HYAN+Cl1\\/Tf8gY4pESFVMQ\\/X43G6q48eGuNpHjZhgbq+gQOxTceUiJCq2RO3YZ5u6qOHxnhai1X" +
        "q+xV8XgeViJCq2hO3YZ7u6aOHxvh5J85Q34U4UUeViJCq2xO3YZ5u6aOHxng5FZ9R3\\/fwZNyqo0pESK3YE7dhnu7oo4fG+DgAG\\/BT6vs9vFe" +
        "HlYiQWrMnvo4FuqGPHhrjYR42YYH6bsFT0OiwEhFSq+ZiMxYYvj56aIyH67FcfT\\/AcbhSx5WIkFo3F5uxwHD10UNjZtsTF6CnHefgFUZAiQhp" +
        "KOZiMxYYnj56aMxc+2Id9tGOb+BJaIyAEhHS0MzFZiwwHH300JiZeliNOdrxAyzFHUZEiQhpqObiZuyjfX300Jh53ox3a89D6OFKI6REhDR0c3" +
        "Ar9tGuPnpozBxz8Dc4Vbteh780YkpESJ0wB7diH+3po4fGzLAAV2GJdn0SLzWCSkRInTEHt2If7eijh8boOxBXYq52fQ2HYLsRVCJC6pQ5uBX7" +
        "qK+PHhqj7SU4B7tp1\\/exBFuNqBIRUufMwY1YrK4v4BQ0RtcH8DrtewiH4VojrESE1ElzcCMWq+dsvNpomosL0TMcv46PGnElIqTOmoMbsVgdL" +
        "8S5Rs8ULsb+huPDOM0MUCJC6rQ5uBGLDdbX8WzcZHRM4gw8A1OGo49DzBAlIqTOm4OrsdzgvBpnGw3z8dv4Lcw3PPdgKe4xQ5SIkEbCHJyD59t" +
        "1n8NJum9PvAR\\/gH0M17dxCO40g5SIkEbKC\\/AxzPHo3Ill2Ka79sCJ+DMsMXw\\/wL64ywxTIkIaOUtxAZ5g53wTT8VW3XUs\\/geW64Z78STcY" +
        "QYqESGNpDn4M\\/yOR+YeLMNdumkF3o2jdcdtOAj3maFKREgj7Wl4EY7F\\/n60a\\/As3K17DsA78Mv4Wd1xJX4Z281gJSKkGWEenoI\\/xs+j4Bp" +
        "cjk+j0S2TOAMvw1zdcg5eYQyUiJBmlNl4CjbhHt0zH6\\/DGzBf97wV7zQmSkRIqSUH4tPYX\\/cEno\\/zjJESEVJqwSG4Vjc9hGOxxpgpESGlyv" +
        "bAFThY99yPJ2OTMVQiQkqVHYdLdM+3cRDuMqZKREipsvPwq7rlWhyDxhgrESGlil6Ev9EtF+JESYkIKVUyH5fiYN3xXvye9K9KREipkr0wjWWG" +
        "7\\/v4DZwr\\/ZsSEVKqZD6uwv6GawNOxm3Sv1MiQkqVzMdV2N9w7MC78E5sl\\/6DEhFSqmQ+LsQq7fs2TkRf+k+ViJBSJbNxPp6hXefiNGyTfqw" +
        "SEVKq6PV4v3Z8D7+JT0mPSIkIKVW0P67EAnWtx6m4U3rESkRIqaJZuAjPUMc38GG8U9ppJSKkVNkcbMKkwbkXF+L9+LL0qJSIkFIL5uLrWGjX3" +
        "IFP4iO4RdolJSKk1JI9sQXz7byb8UH8Le6WBqJEhJRaNAdfwOEemXU4E6vRSANVIkJKLZuLp+EEHIzH4Z\\/xGNyFr+DL+Edchx1SFSUipDREe+" +
        "Cx+AV8C\\/+M+6VWlIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYi" +
        "QUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgpp" +
        "fFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPP0LABjOaloe7ZYAAAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"masksL" +
        "ayerBelow\":false,\"layout\":{\"container\":\"volume\"}},{\"id\":\"7572ef5e-b229-4570-8068-97b309663d24\",\"kind\":\"shape\"," +
        "\"name\":\"Pill\",\"transform\":{\"x\":0.5,\"y\":0.4412,\"width\":0.337,\"height\":1.0164,\"rotationDegrees\":0,\"aspectRatio\":" +
        "{\"free\":{}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"a" +
        "lpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"capsule\"" +
        "},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"layout\":{\"container\":\"bottomRow\"}},{\"id\":\"37f1c128-ff" +
        "e7-4f78-9924-be2a59dae618\",\"kind\":\"shape\",\"name\":\"Pill divider\",\"transform\":{\"x\":0.5,\"y\":0.4412,\"width\":0.0016" +
        ",\"height\":0.8638,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.35,\"blendMode\":\"norm" +
        "al\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\"" +
        ":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"rectangle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false," +
        "\"layout\":{\"container\":\"bottomRow\"}},{\"id\":\"50dccc76-d7c1-4969-8940-42a9acf3b481\",\"kind\":\"lyrics\",\"name\":\"Lyric" +
        "s\",\"transform\":{\"x\":0.164,\"y\":0.4412,\"width\":0.09,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1" +
        ",\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alph" +
        "a\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":fals" +
        "e,\"masksLayerBelow\":false,\"symbolOverride\":\"lyrics.apple\",\"layout\":{\"container\":\"bottomRow\"}},{\"id\":\"2eb91d76-" +
        "38ae-4a15-bf8e-7ea39cfc633a\",\"kind\":\"connect\",\"name\":\"Connect\",\"transform\":{\"x\":0.417,\"y\":0.4412,\"width\":0.076" +
        "6,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode" +
        "\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"inner" +
        "Shadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"conn" +
        "ect.apple\",\"layout\":{\"container\":\"bottomRow\"}},{\"id\":\"2579303a-f9b7-4a5a-8418-b04dc9cd9159\",\"kind\":\"share\",\"na" +
        "me\":\"Persona\",\"transform\":{\"x\":0.583,\"y\":0.4412,\"width\":0.068,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"r" +
        "atio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightn" +
        "ess\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"" +
        "locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"person.apple\",\"layout\":{\"container\":\"bottomRow\"}},{\"id" +
        "\":\"d8c131fb-2d67-4189-b15a-58dcf8adc96d\",\"kind\":\"queue\",\"name\":\"Queue\",\"transform\":{\"x\":0.835,\"y\":0.4412,\"widt" +
        "h\":0.0804,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"b" +
        "lendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}" +
        "},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverrid" +
        "e\":\"queue.list\",\"layout\":{\"container\":\"bottomRow\"}},{\"id\":\"76d61cd9-452f-45bf-98d4-bf653602a18f\",\"kind\":\"outpu" +
        "tName\",\"name\":\"Output\",\"transform\":{\"x\":0.495,\"y\":0.445,\"width\":1,\"height\":1,\"rotationDegrees\":0,\"aspectRatio\"" +
        ":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"" +
        "alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"0:00\"" +
        ",\"fontSize\":11.824885368347168,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"center\",\"allowsOverflow\":fals" +
        "e,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"outputName\":{\"pr" +
        "efix\":\"\",\"showIcon\":false,\"useAccessoryName\":true},\"layout\":{\"container\":\"route\",\"size\":{\"width\":{\"fraction\":1" +
        "},\"height\":\"content\"}}}],\"createdAt\":8.15537378951E8,\"updatedAt\":8.163793622709999E8,\"lyricsPresentation\":\"ful" +
        "lscreenBlur\",\"lyrics\":{\"style\":\"apple\",\"activeScale\":1.08,\"activeGlow\":0,\"pastBlur\":0,\"pastDim\":0.45,\"wordFill" +
        "\":\"continuousLine\",\"lookAheadMs\":0,\"easing\":\"spring\",\"lineTransition\":\"crossfade\",\"translation\":\"below\",\"fillS" +
        "oftness\":0.65,\"sungOpacity\":1,\"unsungOpacity\":0.4},\"queue\":{\"rowStyle\":\"artwork\",\"reorderAnimation\":\"lift\",\"no" +
        "wPlayingRow\":\"bars\",\"showAddedBy\":true,\"pane\":{\"toolbar\":[\"shuffle\",\"repeat\",\"autoplay\",\"automix\"],\"sections\":" +
        "true,\"swipeToRemove\":true,\"reorder\":true,\"showAll\":true}},\"presentation\":{\"states\":[\"artwork\",\"lyrics\",\"queue\"" +
        "],\"initial\":\"artwork\",\"transition\":{\"durationMs\":250,\"easing\":\"easeOut\"},\"panes\":[{\"id\":\"main\",\"container\":\"pa" +
        "neArea\",\"contents\":[\"lyrics\",\"queue\"],\"clip\":true}],\"dock\":{\"container\":\"dock\",\"hideOnScroll\":true,\"idleHideMs" +
        "\":3000,\"durationMs\":320,\"easing\":\"easeInOut\",\"releaseHeight\":true,\"dragDeadzone\":8}},\"layout\":{\"containers\":[{" +
        "\"id\":\"header\",\"name\":\"Compact Song Header\",\"reference\":\"safeArea\",\"edges\":{\"top\":12,\"leading\":28,\"trailing\":28" +
        "},\"height\":\"content\"},{\"id\":\"dock\",\"name\":\"Playback Controls\",\"reference\":\"safeArea\",\"edges\":{\"bottom\":0,\"lead" +
        "ing\":0,\"trailing\":0},\"height\":\"content\",\"padding\":{\"top\":8,\"bottom\":23},\"arrangement\":\"column\",\"spacing\":20,\"a" +
        "lignment\":\"fill\"},{\"id\":\"progress\",\"name\":\"Progress and Time\",\"parent\":\"dock\",\"width\":{\"fraction\":1},\"height\":" +
        "{\"units\":60},\"padding\":{\"leading\":0,\"trailing\":0}},{\"id\":\"transport\",\"name\":\"Transport\",\"parent\":\"dock\",\"width" +
        "\":{\"fraction\":1},\"height\":{\"units\":81},\"padding\":{\"leading\":0,\"trailing\":0}},{\"id\":\"volume\",\"name\":\"Volume\",\"p" +
        "arent\":\"dock\",\"width\":{\"fraction\":1},\"height\":{\"units\":24},\"padding\":{\"leading\":0,\"trailing\":0}},{\"id\":\"paneAr" +
        "ea\",\"name\":\"Lyrics \\/ Queue\",\"reference\":\"safeArea\",\"fillBetween\":{\"above\":\"header\",\"below\":\"dock\"}},{\"id\":\"bo" +
        "ttomRow\",\"name\":\"Lyrics, Output and Queue\",\"parent\":\"dock\",\"width\":{\"fraction\":1},\"height\":{\"units\":43.29},\"pa" +
        "dding\":{\"leading\":0,\"trailing\":0}},{\"id\":\"route\",\"name\":\"Output Label\",\"parent\":\"dock\",\"width\":{\"fraction\":1}," +
        "\"height\":\"content\",\"padding\":{\"bottom\":0.71,\"trailing\":0.7},\"arrangement\":\"column\"}]},\"requiredCapabilities\":{" +
        "\"anchoredContainers\":1,\"continuousLyricFill\":1,\"immersiveArtworkFade\":1,\"inlinePanes\":1,\"interactiveQueuePane\"" +
        ":1,\"presentationStates\":1,\"recedingDock\":1,\"statefulControls\":1}}";

    private BitchordDesign() {}
}
