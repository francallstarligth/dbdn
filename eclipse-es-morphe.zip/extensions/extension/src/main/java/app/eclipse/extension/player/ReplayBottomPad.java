package app.eclipse.extension.player;

/**
 * Ayuda del parche "Replay: espacio extra abajo".
 *
 * La lista de Replay (ct8.o en Eclipse 0.6.75) deja abajo un espacio = alto medido de la barra inferior + 32 dp.
 * Con las skins Native, Apple Music y Spotify la barra flotante (orbes + miniplayer) no entra en esa medida y el
 * boton "Compartir mi Replay" queda tapado. Aqui se pide un minimo de 115 dp (en la skin de Eclipse el espacio ya
 * es parecido, asi que casi no cambia nada).
 */
@SuppressWarnings("unused")
public final class ReplayBottomPad {
    private static final float MIN_DP = 115f;

    private ReplayBottomPad() {}

    /** Recibe el espacio de abajo en dp (float de Compose) y devuelve el que se usara. */
    public static float fix(float bottomDp) {
        try {
            return bottomDp < MIN_DP ? MIN_DP : bottomDp;
        } catch (Throwable t) {
            return bottomDp;
        }
    }
}
