package app.eclipse.extension.player;

/**
 * Ayuda del parche "Replay: espacio extra abajo".
 *
 * La lista de Replay (ct8.o en Eclipse 0.6.75) deja abajo un espacio = alto medido de la barra inferior + 32 dp.
 * Con las skins Native/Apple Music y Spotify la barra de abajo no entra en esa medida y el boton
 * "Compartir mi Replay" queda tapado. Aqui se pide un minimo de espacio:
 *  - Native / Apple Music (y la de Eclipse, donde ya casi alcanza): 115 dp (probado por el usuario, "quedo").
 *  - Spotify: 185 dp (su barra es mas alta: miniplayer + Inicio/Buscar/Biblioteca/Crear, ~375 px).
 * La skin activa esta en las preferencias "eclipse_prefs", clave "appUIStyle" (eclipse / spotify / native; visto en
 * el constructor de xz, el gestor de skins de 0.6.75). Si algo falla se usa el minimo de 115 dp.
 */
@SuppressWarnings("unused")
public final class ReplayBottomPad {
    private static final float MIN_DP = 115f;
    private static final float MIN_DP_SPOTIFY = 185f;

    private ReplayBottomPad() {}

    /** Recibe el espacio de abajo en dp (float de Compose) y devuelve el que se usara. */
    public static float fix(float bottomDp) {
        try {
            float min = isSpotify() ? MIN_DP_SPOTIFY : MIN_DP;
            return bottomDp < min ? min : bottomDp;
        } catch (Throwable t) {
            return bottomDp;
        }
    }

    private static boolean isSpotify() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof android.content.Context)) return false;
            String skin = ((android.content.Context) app)
                .getSharedPreferences("eclipse_prefs", 0).getString("appUIStyle", "eclipse");
            return "spotify".equalsIgnoreCase(skin);
        } catch (Throwable t) {
            return false;
        }
    }
}
