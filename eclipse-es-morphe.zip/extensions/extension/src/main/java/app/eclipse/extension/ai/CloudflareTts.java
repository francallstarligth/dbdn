package app.eclipse.extension.ai;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * v0.20.241 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). Voz del DJ de respaldo con Cloudflare Workers AI
 * (Deepgram Aura-2 espanol, voz "celeste"), pedida a nuestro Worker: GET /tts?t=texto&v=celeste -> MP3.
 * No usa llaves: el Worker llama al modelo. El plan gratis de Cloudflare da ~18 frases al dia en total (cupo compartido).
 * Devuelve el MP3, o null si algo falla (limite, sin cupo, sin red). Nunca lanza. Quien llama cae a Edge.
 */
public final class CloudflareTts {
    private static final String TAG = "CloudflareTts";
    private static final String WORKER = "https://dj-puente.franc-all-starligth.workers.dev/tts";
    private static final String VOICE = "celeste";
    static final int MAX_CHARS = 300; // el Worker corta en 300
    private static final long PAUSE_LIMIT_MS = 10L * 60L * 1000L;
    private static final long PAUSE_QUOTA_MS = 30L * 60L * 1000L;
    private static final long PAUSE_ERR_MS = 60L * 1000L;

    // Solo para pruebas locales
    static String testUrl;

    private static volatile long pausedUntil;

    private CloudflareTts() {}

    /** @return MP3 o null. Nunca lanza. */
    public static byte[] speak(String text) {
        HttpURLConnection c = null;
        try {
            if (text == null) return null;
            if (System.currentTimeMillis() < pausedUntil) return null;
            text = cut(EdgeTts.clean(text));
            if (text.isEmpty()) return null;
            String u = (testUrl != null ? testUrl : WORKER) + "?t=" + URLEncoder.encode(text, "UTF-8") + "&v=" + VOICE;
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(20000);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            if (code != 200) {
                String err = "";
                try {
                    InputStream es = c.getErrorStream();
                    if (es != null) err = new String(readAll(es), StandardCharsets.UTF_8);
                } catch (Throwable ignore) {}
                Log.w(TAG, "Worker " + code + ": " + (err.length() > 200 ? err.substring(0, 200) : err));
                if (code == 429) pause(PAUSE_LIMIT_MS);
                else if (code == 502 || code == 503) pause(PAUSE_QUOTA_MS);
                else pause(PAUSE_ERR_MS);
                return null;
            }
            byte[] a = readAll(c.getInputStream());
            if (!looksLikeMp3(a)) {
                String head = new String(a, 0, Math.min(a.length, 120), StandardCharsets.UTF_8);
                Log.w(TAG, "Respuesta que no es MP3 (" + a.length + " bytes): " + head);
                pause(PAUSE_ERR_MS);
                return null;
            }
            return a;
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
            pause(PAUSE_ERR_MS);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static void pause(long ms) {
        pausedUntil = System.currentTimeMillis() + ms;
    }

    static void resetPause() {
        pausedUntil = 0;
    }

    /** MP3 con sincronizacion de cuadro (FF Fx) o con etiqueta ID3. */
    static boolean looksLikeMp3(byte[] a) {
        if (a == null || a.length < 200) return false;
        if (a[0] == 'I' && a[1] == 'D' && a[2] == '3') return true;
        return (a[0] & 255) == 0xFF && (a[1] & 0xE0) == 0xE0;
    }

    /** Recorta a MAX_CHARS, de preferencia al final de una frase, para no cortar a media palabra. */
    static String cut(String s) {
        if (s == null) return "";
        s = s.trim();
        if (s.length() <= MAX_CHARS) return s;
        String h = s.substring(0, MAX_CHARS);
        int k = Math.max(h.lastIndexOf('.'), Math.max(h.lastIndexOf('!'), h.lastIndexOf('?')));
        if (k < 100) k = Math.max(h.lastIndexOf(','), h.lastIndexOf(' '));
        if (k < 40) return h.trim();
        return h.substring(0, k + 1).trim();
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }
}
