package app.eclipse.extension.player;

import android.graphics.Canvas;
import android.graphics.Region;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.79 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 *
 * Eclipse dibuja la linea activa (tn1.E0) con UN solo texto (vy8 = TextLayoutResult) y un degradado blanco/gris cuyo
 * borde sigue los tiempos del proveedor de letras. Aqui se hace el efecto SILABA POR SILABA (como Apple Music): la
 * silaba por la que va pasando el relleno se agranda y se levanta entera; las ya cantadas bajan de tamano suave hacia
 * la izquierda; la que viene justo delante empieza a subir un poco. El ritmo es el del relleno (o sea, el del
 * proveedor); lo unico que pone este codigo es DONDE se corta cada silaba (Syllables.java: reglas de espanol e ingles).
 *  1) begin(): guarda vy8, la fila, el borde del relleno y el tamano de letra.
 *  2) draw(): con las cajas de las letras (vy8.g = inicio de linea, vy8.b = caja de una letra) arma las silabas de la
 *     fila, calcula la escala de cada una; dibuja la linea normal SIN las silabas afectadas (recorte que las excluye)
 *     y luego dibuja la linea otra vez por cada silaba afectada, mas grande alrededor de su centro y recortada a su
 *     caja (cy7.C por reflexion).
 * Las demas silabas no se tocan; el texto de abajo y el acomodo de las lineas largas tampoco.
 * Todo con reflexion y a prueba de fallos: si algo no coincide, draw() devuelve false y se ve como en Eclipse.
 * v0.20.78: en modo SILABAS el tamano ya no depende solo de DONDE esta el borde sino de CUANTO TIEMPO lleva el
 * relleno dentro de la silaba (como la referencia tipo Apple Music, donde solo crecen las silabas sostenidas): si el
 * borde la cruza rapido no crece; si se queda, crece de a poco (DELAY, GROW) y al salir baja suave (FALL). El estado
 * (nivel 0..1 por silaba) se guarda entre cuadros y se reinicia si cambia la linea, si el borde retrocede (seek) o si
 * pasa mas de medio segundo sin dibujar. Modo letra por letra: igual que la v0.20.76.
 * El modo por silabas lo enciende el parche aparte "Letras: silaba por silaba" (llama a enableSyllables() al empezar
 * tn1.E0). Sin ese parche, cada letra es su propia unidad (el efecto letra por letra de la v0.20.76).
 * v0.20.79: el modo SILABAS (drawFlow, al final del archivo) se rehizo estilo Mochy: todas las silabas suben suave y solo
 * crecen las sostenidas (velocidad del relleno), con resortes amortiguados y las vecinas se apartan. Las constantes
 * DELAY/GROW/FALL de arriba ya no se usan.
 * Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** true = por silabas (lo enciende enableSyllables); false = letra por letra (v0.20.76). */
    private static boolean syllables;
    private static boolean cacheSyl;
    /** Cuanto crece la silaba del borde (1.12 = 12% mas grande; en la v0.20.77 era 1.15 y se pegaba con las vecinas). */
    private static final float MAX_SCALE = 1.12f;
    /** Cuanto sube la silaba del borde, en tamanos de letra (0.06 = 6%). */
    private static final float LIFT = 0.06f;
    /** Ya cantada: en tamanos de letra, a que distancia del final de la silaba vuelve al tamano normal. */
    private static final float BACK = 1.5f;
    /** Por cantar: en tamanos de letra, desde que distancia del inicio de la silaba empieza a subir. */
    private static final float AHEAD = 0.35f;

    /** Modo silabas: segundos que el borde debe llevar dentro de la silaba antes de que empiece a crecer. */
    private static final float DELAY = 0.22f;
    /** Modo silabas: segundos (con el borde adentro, ya pasado DELAY) para llegar al tamano maximo. */
    private static final float GROW = 0.45f;
    /** Modo silabas: segundos que tarda en volver al tamano normal cuando el borde ya salio. */
    private static final float FALL = 0.50f;

    // Entrada de este cuadro (la llena begin()).
    private static Object curTl;
    private static int curLine;
    private static float curEdge, curFont;

    // Silabas (unidades) de la linea: caja de cada una (cache por vy8 + fila).
    private static Object cacheTl;
    private static int cacheLine = -1;
    private static int n;
    private static float[] lx0 = new float[0], lx1 = new float[0], lt = new float[0], lb = new float[0];

    // Estado por silaba entre cuadros (modo silabas): nivel 0..1 y segundos con el borde adentro.
    private static String cacheText;
    private static float[] lvl = new float[0], dwell = new float[0];
    private static long lastNs;
    private static float prevEdge = Float.NaN;

    // Idioma del texto entero (cache por vy8).
    private static Object langTl;
    private static boolean langEs = true;

    private static boolean broken;
    private static Class<?> cls;
    private static Field fInput, fText, fPara, fLines, fAnn;
    private static Method mLineStart, mBox, mDraw;
    private static Field rl, rt, rr, rb;

    private static void init(Object tl) throws Exception {
        Class<?> c = tl.getClass();
        if (c == cls) return;
        Field input = c.getDeclaredField("a");   // vy8.a = uy8 (entrada del texto)
        Field para = c.getDeclaredField("b");    // vy8.b = cl5 (parrafo)
        input.setAccessible(true);
        para.setAccessible(true);
        Field ann = input.getType().getDeclaredField("a");    // uy8.a = ct (AnnotatedString)
        ann.setAccessible(true);
        Field txt = ann.getType().getDeclaredField("r");      // ct.r = String
        txt.setAccessible(true);
        Field lines = para.getType().getDeclaredField("f");   // cl5.f = numero de lineas
        lines.setAccessible(true);
        Method ls = c.getDeclaredMethod("g", int.class);      // vy8.g(linea) = inicio de la linea
        Method box = c.getDeclaredMethod("b", int.class);     // vy8.b(letra) = caja (g47)
        ls.setAccessible(true);
        box.setAccessible(true);
        Class<?> rc = box.getReturnType();
        Field a = rc.getDeclaredField("a");
        Field b = rc.getDeclaredField("b");
        Field cc = rc.getDeclaredField("c");
        Field d = rc.getDeclaredField("d");
        a.setAccessible(true);
        b.setAccessible(true);
        cc.setAccessible(true);
        d.setAccessible(true);
        // cy7.C(ad4, vy8, km4): dibuja el texto con degradado (estatico).
        Class<?> cy = c.getClassLoader().loadClass("cy7");
        Method draw = null;
        for (Method m : cy.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (m.getName().equals("C") && p.length == 3 && p[1] == c
                    && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                draw = m;
            }
        }
        if (draw == null) throw new NoSuchMethodException("cy7.C(ad4, vy8, km4)");
        draw.setAccessible(true);
        fInput = input; fPara = para; fAnn = ann; fText = txt; fLines = lines;
        mLineStart = ls; mBox = box; mDraw = draw;
        rl = a; rt = b; rr = cc; rb = d;
        cacheTl = null;
        cacheLine = -1;
        langTl = null;
        cls = c;
    }

    /** Lo llama el parche "Letras: silaba por silaba" al empezar cada dibujo de fila (barato). */
    public static void enableSyllables() {
        syllables = true;
    }

    /** Guarda los datos del cuadro: vy8, indice de fila (= linea del texto), x del borde del relleno y tamano de letra (px). */
    public static void begin(Object tl, int line, float edge, float fontPx) {
        curTl = tl;
        curLine = line;
        curEdge = edge;
        curFont = fontPx;
    }

    /** Llena las cajas de las silabas de la linea (letras si el modo por silabas no esta encendido); usa cache si es la misma linea. */
    private static boolean load(Object tl, int line) throws Exception {
        if (tl == cacheTl && line == cacheLine && cacheSyl == syllables) return n > 0;
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        // El estado de tiempo se conserva si es la MISMA linea de texto aunque Compose haya creado otro vy8.
        boolean sameKey = text != null && text.equals(cacheText) && line == cacheLine && cacheSyl == syllables;
        int prevN = n;
        cacheTl = tl;
        cacheLine = line;
        cacheText = text;
        cacheSyl = syllables;
        n = 0;
        if (text == null || line < 0 || line >= lines) return false;
        if (tl != langTl) {
            langEs = Syllables.looksSpanish(text);
            langTl = tl;
        }
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(0, le - ls);
        if (lx0.length < cap) {
            lx0 = new float[cap]; lx1 = new float[cap]; lt = new float[cap]; lb = new float[cap];
        }
        int i = ls;
        while (i < le) {
            if (Character.isWhitespace(text.charAt(i))) { i++; continue; }
            int j = i;
            while (j < le && !Character.isWhitespace(text.charAt(j))) j++;
            // Palabra [i, j): se corta en silabas (o cada letra es una unidad).
            boolean[] brk = syllables ? Syllables.breaks(text.substring(i, j), langEs) : null;
            for (int k = i; k < j; k++) {
                Object r = mBox.invoke(tl, k);
                float l = rl.getFloat(r), rg = rr.getFloat(r);
                float x0 = Math.min(l, rg), x1 = Math.max(l, rg);
                float tp = rt.getFloat(r), bt = rb.getFloat(r);
                boolean fresh = (k == i) || !syllables || brk[k - i];
                if (fresh || n == 0) {
                    lx0[n] = x0; lx1[n] = x1; lt[n] = tp; lb[n] = bt;
                    n++;
                } else {
                    int u = n - 1;
                    if (x0 < lx0[u]) lx0[u] = x0;
                    if (x1 > lx1[u]) lx1[u] = x1;
                    if (tp < lt[u]) lt[u] = tp;
                    if (bt > lb[u]) lb[u] = bt;
                }
            }
            i = j;
        }
        if (!(sameKey && prevN == n)) resetState();
        return n > 0;
    }

    /** Pone en cero el nivel de crecimiento de todas las silabas (linea nueva, seek, mucho tiempo sin dibujar). */
    private static void resetState() {
        if (lvl.length < n) {
            lvl = new float[n];
            dwell = new float[n];
        }
        java.util.Arrays.fill(lvl, 0, Math.min(n, lvl.length), 0f);
        java.util.Arrays.fill(dwell, 0, Math.min(n, dwell.length), 0f);
        lastNs = 0L;
        prevEdge = Float.NaN;
    }

    private static float smooth(float x) {
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return x * x * (3f - 2f * x);
    }

    /**
     * Dibuja la fila con el efecto silaba por silaba.
     * @return true si ya dibujo todo (el parche salta la llamada original); false si no hay nada que agrandar o
     *         algo fallo antes de dibujar (el parche deja la llamada original, como Eclipse).
     */
    public static boolean draw(Canvas c, Object ad4, Object brush) {
        if (broken || curTl == null || c == null) return false;
        Object tl = curTl;
        try {
            init(tl);
            if (syllables) return drawFlow(c, ad4, brush, tl);
            if (!load(tl, curLine)) return false;
            float font = curFont;
            if (!(font > 1f)) return false;
            float edge = curEdge;
            // Escala de cada silaba segun donde esta el borde del relleno.
            float[] sc = new float[n];
            int cnt = 0;
            float hideL = Float.MAX_VALUE, hideR = -Float.MAX_VALUE;
            float dt = 0f;
            if (syllables) {
                long now = System.nanoTime();
                if (lastNs == 0L || now - lastNs > 500000000L
                        || (!Float.isNaN(prevEdge) && edge < prevEdge - font * 0.5f)) {
                    java.util.Arrays.fill(lvl, 0, n, 0f);
                    java.util.Arrays.fill(dwell, 0, n, 0f);
                } else {
                    dt = Math.min((now - lastNs) / 1.0e9f, 0.1f);
                }
                lastNs = now;
                prevEdge = edge;
            }
            for (int i = 0; i < n; i++) {
                float f;
                if (syllables) {
                    if (edge < lx0[i]) {                       // todavia no llega: en cero
                        lvl[i] = 0f;
                        dwell[i] = 0f;
                    } else if (edge <= lx1[i]) {               // el relleno esta dentro de esta silaba
                        dwell[i] += dt;
                        if (dwell[i] > DELAY) lvl[i] = Math.min(1f, lvl[i] + dt / GROW);
                    } else {                                   // ya la paso: baja suave
                        lvl[i] = Math.max(0f, lvl[i] - dt / FALL);
                    }
                    f = smooth(lvl[i]);
                } else if (edge < lx0[i]) f = smooth(1f - ((lx0[i] - edge) / font) / AHEAD);   // por cantar
                else if (edge <= lx1[i]) f = 1f;                                        // el relleno va por esta silaba
                else f = 1f - smooth(((edge - lx1[i]) / font) / BACK);                  // ya cantada
                float s = 1f + (MAX_SCALE - 1f) * f;
                if (s < 1.004f) { sc[i] = 0f; continue; }
                sc[i] = s;
                cnt++;
                if (lx0[i] < hideL) hideL = lx0[i];
                if (lx1[i] > hideR) hideR = lx1[i];
            }
            if (cnt == 0) return false;

            // 1) La linea normal SIN las silabas afectadas.
            c.save();
            try {
                try {
                    c.clipOutRect(hideL, -100000f, hideR, 100000f);
                } catch (NoSuchMethodError e) {
                    c.clipRect(hideL, -100000f, hideR, 100000f, Region.Op.DIFFERENCE);
                }
                mDraw.invoke(null, ad4, tl, brush);
            } catch (Throwable t) {
                broken = true;
                System.out.println("LyricsPop: desactivado por error: " + t);
                return false;
            } finally {
                c.restore();
            }

            // 2) Cada silaba afectada, mas grande (la mas grande al final, encima de las demas).
            boolean[] done = new boolean[n];
            for (int k = 0; k < cnt; k++) {
                int best = -1;
                for (int i = 0; i < n; i++) {
                    if (sc[i] > 0f && !done[i] && (best < 0 || sc[i] < sc[best])) best = i;
                }
                if (best < 0) break;
                done[best] = true;
                float s = sc[best];
                float cx = (lx0[best] + lx1[best]) * 0.5f;
                float cy = (lt[best] + lb[best]) * 0.5f;
                float hw = (lx1[best] - lx0[best]) * 0.5f * s;
                float lift = font * LIFT * ((s - 1f) / (MAX_SCALE - 1f));
                c.save();
                try {
                    // v0.20.91: recorte vertical solo a la fila de la silaba (ya escalada y levantada), para que la fila de abajo no asome como rayitas
                    // v0.20.93: sin margen (con margen se colaban los descendentes de la fila de arriba como rayitas)
                    float cTop = cy - lift - (cy - lt[best]) * s + font * 0.01f;
                    float cBot = cy - lift + (lb[best] - cy) * s;
                    c.clipRect(cx - hw, cTop, cx + hw, cBot);
                    c.translate(cx, cy - lift);
                    c.scale(s, s);
                    c.translate(-cx, -cy);
                    mDraw.invoke(null, ad4, tl, brush);
                } catch (Throwable t) {
                    broken = true;
                    System.out.println("LyricsPop: desactivado por error: " + t);
                    break;
                } finally {
                    c.restore();
                }
            }
            return true;
        } catch (Throwable t) {
            broken = true;
            System.out.println("LyricsPop: desactivado por error: " + t);
            return false;
        }
    }

    // ======================= v0.20.79: modo SILABAS "con vida" (estilo Mochy) =======================
    // Todas las silabas SUBEN suave a su lugar cuando llega el relleno (las que faltan esperan un poquito mas abajo);
    // solo las SOSTENIDAS crecen (se mide la velocidad del relleno: si va lento, la nota es larga). Cada nivel
    // (subida, crecimiento) sigue su objetivo con un resorte amortiguado, asi no hay saltos secos.
    /** Cuanto esperan abajo las silabas que aun no se cantan (en tamanos de letra). */
    private static final float DROP = 0.12f;
    /** Cuanto sube de mas una silaba sostenida (en tamanos de letra). */
    private static final float HELD_LIFT = 0.10f;
    /** Cuanto crece una silaba sostenida (1.075 = 7.5%, como Mochy). */
    private static final float HELD_SCALE = 1.15f;
    /** La silaba empieza a subir esta distancia (en tamanos de letra) antes de que llegue el relleno. */
    private static final float RISE_LEAD = 0.45f;
    /** Segundos que tarda la subida en alcanzar su objetivo. */
    private static final float RISE_FOLLOW = 0.09f;
    /** v0.20.97: segundos que tarda en BAJAR a la espera cuando una fila empieza (suave, sin salto). */
    private static final float RISE_SINK = 0.35f;
    /** Segundos que tarda el crecimiento en alcanzar su objetivo (respira mas lento que la subida). */
    private static final float SWELL_FOLLOW = 0.30f;
    /** v0.20.96: segundos que tarda en BAJAR (mas rapido que al crecer, para estar chica cuando acaba la silaba). */
    private static final float SWELL_FALL = 0.07f;
    /** v0.20.96: segundos antes del final de la silaba en que empieza a bajar / en que ya debe estar chica. */
    private static final float REL_START = 0.50f, REL_END = 0.12f;
    /** Segundos por letra: por debajo de FAST no crece nada; por encima de SLOW crece completo. */
    private static final float FAST_SPC = 0.10f, SLOW_SPC = 0.34f;
    /** Crece rapido al empezar la silaba (primer 20%) y baja en el ultimo 12%. */
    private static final float ATTACK = 0.20f, RELEASE = 0.30f;
    /** Segundos para suavizar la medida de velocidad del relleno cuando frena (nota larga) y cuando acelera. */
    private static final float SPEED_SMOOTH = 0.15f, SPEED_UP = 0.04f;
    /** Velocidad del relleno (tamanos de letra por segundo) por debajo de la cual se cuenta como pausa, no como nota larga. */
    private static final float MIN_SPEED = 0.05f;

    /** Una fila de la linea: cajas de sus silabas y estado de la animacion entre cuadros. */
    private static final class Row {
        Object tl;
        int n;
        float[] x0, x1, top, bot;
        int[] lc;
        float[] rise, riseV, swell, swellV;
        long lastNs;
        float prevEdge = Float.NaN, spd, stall;
    }

    private static final java.util.HashMap<String, Row> rows = new java.util.HashMap<String, Row>();

    private static Row rowFor(Object tl, int line) throws Exception {
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        if (text == null || line < 0 || line >= lines) return null;
        String key = line + "#" + text;
        Row old = rows.get(key);
        if (old != null && old.tl == tl) return old;
        if (tl != langTl) {
            langEs = Syllables.looksSpanish(text);
            langTl = tl;
        }
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(1, le - ls);
        float[] x0 = new float[cap], x1 = new float[cap], tp = new float[cap], bt = new float[cap];
        int[] lc = new int[cap];
        int n = 0;
        int i = ls;
        while (i < le) {
            if (Character.isWhitespace(text.charAt(i))) { i++; continue; }
            int j = i;
            while (j < le && !Character.isWhitespace(text.charAt(j))) j++;
            boolean[] brk = Syllables.breaks(text.substring(i, j), langEs);
            for (int k = i; k < j; k++) {
                Object r = mBox.invoke(tl, k);
                float l = rl.getFloat(r), rg = rr.getFloat(r);
                float a = Math.min(l, rg), b = Math.max(l, rg);
                float t = rt.getFloat(r), d = rb.getFloat(r);
                if (k == i || brk[k - i] || n == 0) {
                    x0[n] = a; x1[n] = b; tp[n] = t; bt[n] = d; lc[n] = 1;
                    n++;
                } else {
                    int u = n - 1;
                    if (a < x0[u]) x0[u] = a;
                    if (b > x1[u]) x1[u] = b;
                    if (t < tp[u]) tp[u] = t;
                    if (d > bt[u]) bt[u] = d;
                    lc[u]++;
                }
            }
            i = j;
        }
        if (rows.size() > 24) rows.clear();
        Row r = (old != null && old.n == n) ? old : new Row();
        boolean fresh = r != old;
        r.tl = tl;
        r.n = n;
        r.x0 = x0; r.x1 = x1; r.top = tp; r.bot = bt; r.lc = lc;
        if (fresh) {
            r.rise = new float[n]; r.riseV = new float[n];
            r.swell = new float[n]; r.swellV = new float[n];
            r.lastNs = 0L;
        }
        rows.put(key, r);
        return r;
    }

    /** Resorte amortiguado (critico): x sigue a target en unos "follow" segundos, sin saltos ni rebote. */
    private static void damp(float[] x, float[] v, int i, float target, float follow, float dt) {
        if (dt <= 0f) return;
        float omega = 2f / Math.max(0.0001f, follow);
        float k = omega * dt;
        float e = 1f / (1f + k + 0.48f * k * k + 0.235f * k * k * k);
        float change = x[i] - target;
        float temp = (v[i] + omega * change) * dt;
        v[i] = (v[i] - omega * temp) * e;
        x[i] = target + (change + temp) * e;
        if (x[i] < 0f) { x[i] = 0f; v[i] = 0f; } else if (x[i] > 1f) { x[i] = 1f; v[i] = 0f; }
    }

    /** 0 = ya subida y quieta, 1 = esperando abajo y quieta, -1 = en movimiento (se dibuja sola). */
    private static int classOf(Row r, int i) {
        if (r.swell[i] >= 0.004f) return -1;
        if (r.rise[i] >= 0.996f) return 0;
        if (r.rise[i] <= 0.004f) return 1;
        return -1;
    }

    private static boolean drawFlow(Canvas c, Object ad4, Object brush, Object tl) throws Throwable {
        Row r = rowFor(tl, curLine);
        if (r == null || r.n == 0) return false;
        final float font = curFont;
        if (!(font > 1f)) return false;
        final float edge = curEdge;
        final int n = r.n;
        long now = System.nanoTime();
        boolean snap = r.lastNs == 0L || now - r.lastNs > 500000000L
                || (!Float.isNaN(r.prevEdge) && edge < r.prevEdge - font * 0.5f);
        float dt = snap ? 0f : Math.min((now - r.lastNs) / 1.0e9f, 0.1f);
        if (snap) {
            r.stall = 0f;
            r.spd = -1f;                                // todavia sin medir: no crece nada hasta tener una medida
        } else if (dt > 0.002f) {
            float inst = Math.max(0f, (edge - r.prevEdge) / dt);
            if (inst < MIN_SPEED * font) r.stall += dt; else r.stall = 0f;
            if (r.stall > 0.05f) {
                r.spd = 0f;                             // el relleno esta quieto (pausa): no es una nota larga
            } else if (r.spd < 0f || inst > r.spd) {
                r.spd = (r.spd < 0f) ? inst : r.spd + (inst - r.spd) * Math.min(1f, dt / SPEED_UP);   // acelera: se nota rapido
            } else {
                r.spd += (inst - r.spd) * Math.min(1f, dt / SPEED_SMOOTH);                            // frena: se suaviza
            }
        }
        if (snap || dt > 0.002f) {
            r.lastNs = now;
            r.prevEdge = edge;
        }
        final float lead = RISE_LEAD * font;
        for (int i = 0; i < n; i++) {
            float w = r.x1[i] - r.x0[i];
            float tr;                                   // objetivo de la subida
            if (edge >= r.x1[i]) tr = 1f;
            else tr = smooth((edge - r.x0[i] + lead) / (lead + 0.9f * Math.max(w, 1f)));
            float ts = 0f;                              // objetivo del crecimiento (solo notas largas)
            if (edge >= r.x0[i] && edge < r.x1[i] - 0.02f * font && w > 1f && r.spd > MIN_SPEED * font) {
                float spc = (w / Math.max(1, r.lc[i])) / r.spd;      // segundos por letra
                float hold = smooth((spc - FAST_SPC) / (SLOW_SPC - FAST_SPC));
                float pw = (edge - r.x0[i]) / w;
                // v0.20.96: la bajada se mide en SEGUNDOS que faltan para que el relleno salga de la silaba (no en ancho):
                // empieza REL_START antes del final y llega a 0 en REL_END, asi al terminar la silaba (y la linea) ya esta chica
                float remain = (r.x1[i] - edge) / Math.max(1f, r.spd);
                ts = hold * smooth(pw / ATTACK) * smooth((remain - REL_END) / (REL_START - REL_END));
            }
            if (snap) {
                // v0.20.97: al empezar (fila nueva o linea nueva) todo parte en su lugar normal (como lo dibujaba Eclipse
                // antes) y las que faltan BAJAN suave a su espera, en vez de saltar de golpe hacia abajo
                r.rise[i] = 1f; r.riseV[i] = 0f;
                r.swell[i] = 0f; r.swellV[i] = 0f;
            } else {
                damp(r.rise, r.riseV, i, tr, tr < r.rise[i] ? RISE_SINK : RISE_FOLLOW, dt);
                damp(r.swell, r.swellV, i, ts, ts < r.swell[i] ? SWELL_FALL : SWELL_FOLLOW, dt);
            }
        }
        // Tamano, altura y desplazamiento lateral de cada silaba (las vecinas se apartan para dar lugar).
        float[] sc = new float[n], dy = new float[n], dx = new float[n], delta = new float[n];
        float total = 0f;
        boolean idle = true;
        for (int i = 0; i < n; i++) {
            float sw = r.swell[i];
            sc[i] = 1f + (HELD_SCALE - 1f) * sw;
            delta[i] = (sc[i] - 1f) * (r.x1[i] - r.x0[i]);
            total += delta[i];
            int cls = classOf(r, i);
            if (cls == 0) dy[i] = 0f;
            else if (cls == 1) dy[i] = font * DROP;
            else dy[i] = (1f - r.rise[i]) * font * DROP - sw * font * HELD_LIFT;
            if (cls != 0) idle = false;
        }
        float before = 0f;
        for (int i = 0; i < n; i++) {
            float after = total - before - delta[i];
            dx[i] = 0.5f * (before - after);
            before += delta[i];
            if (Math.abs(dx[i]) > 0.01f) idle = false;
        }
        if (idle) return false;                         // todo en su lugar: que lo dibuje Eclipse como siempre

        int i = 0;
        while (i < n) {
            int cls = classOf(r, i);
            int j = i;
            if (cls >= 0) {
                while (j + 1 < n && classOf(r, j + 1) == cls && Math.abs(dx[j + 1] - dx[i]) < 0.01f) j++;
            }
            float bl = (i == 0) ? -100000f : (r.x1[i - 1] + r.x0[i]) * 0.5f;
            float br = (j == n - 1) ? 100000f : (r.x1[j] + r.x0[j + 1]) * 0.5f;
            float s = (cls < 0) ? sc[i] : 1f;
            c.save();
            try {
                c.translate(dx[i], dy[i]);
                if (s > 1.0005f) {
                    float cx = (r.x0[i] + r.x1[i]) * 0.5f, cyy = (r.top[i] + r.bot[i]) * 0.5f;
                    c.translate(cx, cyy);
                    c.scale(s, s);
                    c.translate(-cx, -cyy);
                }
                float gTop = r.top[i], gBot = r.bot[i];
                for (int g = i + 1; g <= j; g++) { if (r.top[g] < gTop) gTop = r.top[g]; if (r.bot[g] > gBot) gBot = r.bot[g]; }
                c.clipRect(bl, gTop + font * 0.01f, br, gBot);   // v0.20.93: solo la fila de la silaba, sin margen (el margen dejaba pasar rayitas de la fila vecina)
                mDraw.invoke(null, ad4, tl, brush);
            } catch (Throwable t) {
                broken = true;
                System.out.println("LyricsPop: desactivado por error: " + t);
                return i > 0;                            // si ya dibujo algo, no dejar que Eclipse dibuje encima
            } finally {
                c.restore();
            }
            i = j + 1;
        }
        return true;
    }
}
