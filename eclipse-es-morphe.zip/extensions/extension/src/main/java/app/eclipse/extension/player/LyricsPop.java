package app.eclipse.extension.player;

import android.graphics.Canvas;
import android.graphics.Region;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.76 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 *
 * Eclipse dibuja la linea activa (tn1.E0) con UN solo texto (vy8 = TextLayoutResult) y un degradado blanco/gris.
 * Aqui se hace el efecto LETRA POR LETRA: la letra donde esta el borde del relleno es la mas grande y las que ya se
 * cantaron van bajando de tamano hacia la izquierda (como en la referencia: "V grande, e mediana, r chica"); la que
 * viene justo delante empieza a subir un poco. Ademas cada letra sube un poquito (se "levanta").
 *  1) begin(): guarda vy8, la fila, el borde del relleno y el tamano de letra.
 *  2) draw(): con las cajas de las letras (vy8.g = inicio de linea, vy8.b = caja de una letra) calcula la escala de
 *     cada letra; dibuja la linea normal SIN las letras afectadas (recorte que las excluye) y luego dibuja la linea
 *     otra vez por cada letra afectada, mas grande alrededor de su centro y recortada a su caja (cy7.C por reflexion).
 * Las demas letras no se tocan; el texto de abajo y el acomodo de las lineas largas tampoco.
 * Todo con reflexion y a prueba de fallos: si algo no coincide, draw() devuelve false y se ve como en Eclipse.
 * Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** Cuanto crece la letra del borde (1.15 = 15% mas grande). */
    private static final float MAX_SCALE = 1.15f;
    /** Cuanto sube la letra del borde, en tamanos de letra (0.06 = 6%). */
    private static final float LIFT = 0.06f;
    /** Hacia la izquierda (ya cantado): en tamanos de letra, a que distancia del borde vuelve al tamano normal. */
    private static final float BACK = 2.0f;
    /** Hacia la derecha (por cantar): en tamanos de letra, desde donde empieza a subir. */
    private static final float AHEAD = 0.4f;

    // Entrada de este cuadro (la llena begin()).
    private static Object curTl;
    private static int curLine;
    private static float curEdge, curFont;

    // Cajas de las letras de la linea (cache por vy8 + fila).
    private static Object cacheTl;
    private static int cacheLine = -1;
    private static int n;
    private static float[] lx0 = new float[0], lx1 = new float[0], lt = new float[0], lb = new float[0];

    private static boolean broken;
    private static Class<?> cls;
    private static Field fInput, fText, fPara, fLines, fAnn;
    private static Method mLineStart, mBox, mDraw;
    private static Field rl, rt, rr, rb;

    private static void init(Object tl) throws Exception {
        Class<?> c = tl.getClass();
        if (c == cls) return;
        Field input = c.getDeclaredField("a");   // vy8.a = uy8 (entrada del texto)
        Field para = c.getDeclaredField("b");    // vy8.b = cl5 (parrafo)
        input.setAccessible(true);
        para.setAccessible(true);
        Field ann = input.getType().getDeclaredField("a");    // uy8.a = ct (AnnotatedString)
        ann.setAccessible(true);
        Field txt = ann.getType().getDeclaredField("r");      // ct.r = String
        txt.setAccessible(true);
        Field lines = para.getType().getDeclaredField("f");   // cl5.f = numero de lineas
        lines.setAccessible(true);
        Method ls = c.getDeclaredMethod("g", int.class);      // vy8.g(linea) = inicio de la linea
        Method box = c.getDeclaredMethod("b", int.class);     // vy8.b(letra) = caja (g47)
        ls.setAccessible(true);
        box.setAccessible(true);
        Class<?> rc = box.getReturnType();
        Field a = rc.getDeclaredField("a");
        Field b = rc.getDeclaredField("b");
        Field cc = rc.getDeclaredField("c");
        Field d = rc.getDeclaredField("d");
        a.setAccessible(true);
        b.setAccessible(true);
        cc.setAccessible(true);
        d.setAccessible(true);
        // cy7.C(ad4, vy8, km4): dibuja el texto con degradado (estatico).
        Class<?> cy = c.getClassLoader().loadClass("cy7");
        Method draw = null;
        for (Method m : cy.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (m.getName().equals("C") && p.length == 3 && p[1] == c
                    && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                draw = m;
            }
        }
        if (draw == null) throw new NoSuchMethodException("cy7.C(ad4, vy8, km4)");
        draw.setAccessible(true);
        fInput = input; fPara = para; fAnn = ann; fText = txt; fLines = lines;
        mLineStart = ls; mBox = box; mDraw = draw;
        rl = a; rt = b; rr = cc; rb = d;
        cacheTl = null;
        cacheLine = -1;
        cls = c;
    }

    /** Guarda los datos del cuadro: vy8, indice de fila (= linea del texto), x del borde del relleno y tamano de letra (px). */
    public static void begin(Object tl, int line, float edge, float fontPx) {
        curTl = tl;
        curLine = line;
        curEdge = edge;
        curFont = fontPx;
    }

    /** Llena las cajas de las letras (no espacios) de la linea; usa cache si es la misma linea. */
    private static boolean load(Object tl, int line) throws Exception {
        if (tl == cacheTl && line == cacheLine) return n > 0;
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        cacheTl = tl;
        cacheLine = line;
        n = 0;
        if (text == null || line < 0 || line >= lines) return false;
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(0, le - ls);
        if (lx0.length < cap) {
            lx0 = new float[cap]; lx1 = new float[cap]; lt = new float[cap]; lb = new float[cap];
        }
        for (int i = ls; i < le; i++) {
            if (Character.isWhitespace(text.charAt(i))) continue;
            Object r = mBox.invoke(tl, i);
            float l = rl.getFloat(r), rg = rr.getFloat(r);
            lx0[n] = Math.min(l, rg);
            lx1[n] = Math.max(l, rg);
            lt[n] = rt.getFloat(r);
            lb[n] = rb.getFloat(r);
            n++;
        }
        return n > 0;
    }

    private static float smooth(float x) {
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return x * x * (3f - 2f * x);
    }

    /**
     * Dibuja la fila con el efecto letra por letra.
     * @return true si ya dibujo todo (el parche salta la llamada original); false si no hay nada que agrandar o
     *         algo fallo antes de dibujar (el parche deja la llamada original, como Eclipse).
     */
    public static boolean draw(Canvas c, Object ad4, Object brush) {
        if (broken || curTl == null || c == null) return false;
        Object tl = curTl;
        try {
            init(tl);
            if (!load(tl, curLine)) return false;
            float font = curFont;
            if (!(font > 1f)) return false;
            float edge = curEdge;
            // Escala de cada letra segun su distancia al borde.
            float[] sc = new float[n];
            int cnt = 0;
            float hideL = Float.MAX_VALUE, hideR = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                float cx = (lx0[i] + lx1[i]) * 0.5f;
                float d = (edge - cx) / font;           // > 0: ya cantada (a la izquierda del borde)
                float f;
                if (d >= 0f) f = 1f - smooth(d / BACK);
                else f = smooth((d + AHEAD) / AHEAD);
                float s = 1f + (MAX_SCALE - 1f) * f;
                if (s < 1.004f) { sc[i] = 0f; continue; }
                sc[i] = s;
                cnt++;
                if (lx0[i] < hideL) hideL = lx0[i];
                if (lx1[i] > hideR) hideR = lx1[i];
            }
            if (cnt == 0) return false;

            // 1) La linea normal SIN las letras afectadas.
            c.save();
            try {
                try {
                    c.clipOutRect(hideL, -100000f, hideR, 100000f);
                } catch (NoSuchMethodError e) {
                    c.clipRect(hideL, -100000f, hideR, 100000f, Region.Op.DIFFERENCE);
                }
                mDraw.invoke(null, ad4, tl, brush);
            } catch (Throwable t) {
                broken = true;
                System.out.println("LyricsPop: desactivado por error: " + t);
                return false;
            } finally {
                c.restore();
            }

            // 2) Cada letra afectada, mas grande (la mas grande al final, encima de las demas).
            boolean[] done = new boolean[n];
            for (int k = 0; k < cnt; k++) {
                int best = -1;
                for (int i = 0; i < n; i++) {
                    if (sc[i] > 0f && !done[i] && (best < 0 || sc[i] < sc[best])) best = i;
                }
                if (best < 0) break;
                done[best] = true;
                float s = sc[best];
                float cx = (lx0[best] + lx1[best]) * 0.5f;
                float cy = (lt[best] + lb[best]) * 0.5f;
                float hw = (lx1[best] - lx0[best]) * 0.5f * s;
                float lift = font * LIFT * ((s - 1f) / (MAX_SCALE - 1f));
                c.save();
                try {
                    c.clipRect(cx - hw, -100000f, cx + hw, 100000f);
                    c.translate(cx, cy - lift);
                    c.scale(s, s);
                    c.translate(-cx, -cy);
                    mDraw.invoke(null, ad4, tl, brush);
                } catch (Throwable t) {
                    broken = true;
                    System.out.println("LyricsPop: desactivado por error: " + t);
                    break;
                } finally {
                    c.restore();
                }
            }
            return true;
        } catch (Throwable t) {
            broken = true;
            System.out.println("LyricsPop: desactivado por error: " + t);
            return false;
        }
    }
}
