package app.eclipse.extension.player;

import android.graphics.Canvas;
import android.graphics.Region;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.79 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 *
 * Eclipse dibuja la linea activa (tn1.E0) con UN solo texto (vy8 = TextLayoutResult) y un degradado blanco/gris cuyo
 * borde sigue los tiempos del proveedor de letras. Aqui se hace el efecto SILABA POR SILABA (como Apple Music): la
 * silaba por la que va pasando el relleno se agranda y se levanta entera; las ya cantadas bajan de tamano suave hacia
 * la izquierda; la que viene justo delante empieza a subir un poco. El ritmo es el del relleno (o sea, el del
 * proveedor); lo unico que pone este codigo es DONDE se corta cada silaba (Syllables.java: reglas de espanol e ingles).
 *  1) begin(): guarda vy8, la fila, el borde del relleno y el tamano de letra.
 *  2) draw(): con las cajas de las letras (vy8.g = inicio de linea, vy8.b = caja de una letra) arma las silabas de la
 *     fila, calcula la escala de cada una; dibuja la linea normal SIN las silabas afectadas (recorte que las excluye)
 *     y luego dibuja la linea otra vez por cada silaba afectada, mas grande alrededor de su centro y recortada a su
 *     caja (cy7.C por reflexion).
 * Las demas silabas no se tocan; el texto de abajo y el acomodo de las lineas largas tampoco.
 * Todo con reflexion y a prueba de fallos: si algo no coincide, draw() devuelve false y se ve como en Eclipse.
 * v0.20.78: en modo SILABAS el tamano ya no depende solo de DONDE esta el borde sino de CUANTO TIEMPO lleva el
 * relleno dentro de la silaba (como la referencia tipo Apple Music, donde solo crecen las silabas sostenidas): si el
 * borde la cruza rapido no crece; si se queda, crece de a poco (DELAY, GROW) y al salir baja suave (FALL). El estado
 * (nivel 0..1 por silaba) se guarda entre cuadros y se reinicia si cambia la linea, si el borde retrocede (seek) o si
 * pasa mas de medio segundo sin dibujar. Modo letra por letra: igual que la v0.20.76.
 * El modo por silabas lo enciende el parche aparte "Letras: silaba por silaba" (llama a enableSyllables() al empezar
 * tn1.E0). Sin ese parche, cada letra es su propia unidad (el efecto letra por letra de la v0.20.76).
 * v0.20.79: el modo SILABAS (drawFlow, al final del archivo) se rehizo estilo Mochy: todas las silabas suben suave y solo
 * crecen las sostenidas (velocidad del relleno), con resortes amortiguados y las vecinas se apartan. Las constantes
 * DELAY/GROW/FALL de arriba ya no se usan.
 * Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** true = por silabas (lo enciende enableSyllables); false = letra por letra (v0.20.76). */
    private static boolean syllables;
    private static boolean cacheSyl;
    /** Cuanto crece la silaba del borde (1.12 = 12% mas grande; en la v0.20.77 era 1.15 y se pegaba con las vecinas). */
    private static final float MAX_SCALE = 1.12f;
    /** Cuanto sube la silaba del borde, en tamanos de letra (0.06 = 6%). */
    private static final float LIFT = 0.06f;
    /** Ya cantada: en tamanos de letra, a que distancia del final de la silaba vuelve al tamano normal. */
    private static final float BACK = 1.5f;
    /** Por cantar: en tamanos de letra, desde que distancia del inicio de la silaba empieza a subir. */
    private static final float AHEAD = 0.35f;

    /** Modo silabas: segundos que el borde debe llevar dentro de la silaba antes de que empiece a crecer. */
    private static final float DELAY = 0.22f;
    /** Modo silabas: segundos (con el borde adentro, ya pasado DELAY) para llegar al tamano maximo. */
    private static final float GROW = 0.45f;
    /** Modo silabas: segundos que tarda en volver al tamano normal cuando el borde ya salio. */
    private static final float FALL = 0.50f;

    // Entrada de este cuadro (la llena begin()).
    private static Object curTl;
    private static int curLine;
    private static float curEdge, curFont;

    // Silabas (unidades) de la linea: caja de cada una (cache por vy8 + fila).
    private static Object cacheTl;
    private static int cacheLine = -1;
    private static int n;
    private static float[] lx0 = new float[0], lx1 = new float[0], lt = new float[0], lb = new float[0];

    // Estado por silaba entre cuadros (modo silabas): nivel 0..1 y segundos con el borde adentro.
    private static String cacheText;
    private static float[] lvl = new float[0], dwell = new float[0];
    private static long lastNs;
    private static float prevEdge = Float.NaN;

    // Idioma del texto entero (cache por vy8).
    private static Object langTl;
    private static boolean langEs = true;

    private static boolean broken;
    private static Class<?> cls;
    private static Field fInput, fText, fPara, fLines, fAnn;
    private static Method mLineStart, mBox, mDraw;
    private static Field rl, rt, rr, rb;

    private static void init(Object tl) throws Exception {
        Class<?> c = tl.getClass();
        if (c == cls) return;
        Field input = c.getDeclaredField("a");   // vy8.a = uy8 (entrada del texto)
        Field para = c.getDeclaredField("b");    // vy8.b = cl5 (parrafo)
        input.setAccessible(true);
        para.setAccessible(true);
        Field ann = input.getType().getDeclaredField("a");    // uy8.a = ct (AnnotatedString)
        ann.setAccessible(true);
        Field txt = ann.getType().getDeclaredField("r");      // ct.r = String
        txt.setAccessible(true);
        Field lines = para.getType().getDeclaredField("f");   // cl5.f = numero de lineas
        lines.setAccessible(true);
        Method ls = c.getDeclaredMethod("g", int.class);      // vy8.g(linea) = inicio de la linea
        Method box = c.getDeclaredMethod("b", int.class);     // vy8.b(letra) = caja (g47)
        ls.setAccessible(true);
        box.setAccessible(true);
        Class<?> rc = box.getReturnType();
        Field a = rc.getDeclaredField("a");
        Field b = rc.getDeclaredField("b");
        Field cc = rc.getDeclaredField("c");
        Field d = rc.getDeclaredField("d");
        a.setAccessible(true);
        b.setAccessible(true);
        cc.setAccessible(true);
        d.setAccessible(true);
        // cy7.C(ad4, vy8, km4): dibuja el texto con degradado (estatico).
        Class<?> cy = c.getClassLoader().loadClass("js7");
        Method draw = null;
        for (Method m : cy.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (m.getName().equals("N") && p.length == 3 && p[1] == c
                    && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                draw = m;
            }
        }
        if (draw == null) throw new NoSuchMethodException("hs7.N(kn4, p1a, dx4)");
        draw.setAccessible(true);
        fInput = input; fPara = para; fAnn = ann; fText = txt; fLines = lines;
        mLineStart = ls; mBox = box; mDraw = draw;
        rl = a; rt = b; rr = cc; rb = d;
        cacheTl = null;
        cacheLine = -1;
        langTl = null;
        cls = c;
    }

    /** Lo llama el parche "Letras: silaba por silaba" al empezar cada dibujo de fila (barato). */
    public static void enableSyllables() {
        syllables = true;
    }

    /** v0.20.99: lo llama el parche "Letras: brillo suave" al empezar cada dibujo de fila. Sin ese parche no hay brillo. */
    /** v0.20.111: llamado justo antes del clipRect de Eclipse en tn1.E0: idx = renglon, font = tamano de letra en px, lines = renglones. */
    public static void clipCtx(int idx, float font, java.util.ArrayList lines) {
        try {
            float m = tailsOn ? font * TAIL_MARGIN : 0f;
            clipBotAdd = (lines != null && idx < lines.size() - 1) ? m : 0f;
        } catch (Throwable t) {
            clipBotAdd = 0f;
        }
    }

    /** v0.20.114: ya no alarga nada arriba; el metodo se queda porque el smali de LyricsTailsPatch.kt lo sigue llamando. */
    public static float clipTop(float top) {
        return top;
    }

    public static float clipBottom(float bottom) {
        return bottom + clipBotAdd;
    }

    /** v0.20.116: el parche de smali pasa aqui el uk (Canvas de Compose) para que el brillo con shader pueda grabar en una capa. */
    public static void setCanvasOwner(Object uk) {
        LyricsGlowShader.setOwner(uk);
    }

    public static void enableTails() {
        tailsOn = true;
    }

    public static void enableGlow() {
        glowOn = true;
    }

    /** Guarda los datos del cuadro: vy8, indice de fila (= linea del texto), x del borde del relleno y tamano de letra (px). */
    public static void begin(Object tl, int line, float edge, float fontPx) {
        curTl = tl;
        curLine = line;
        curEdge = edge;
        curFont = fontPx;
    }

    /** Llena las cajas de las silabas de la linea (letras si el modo por silabas no esta encendido); usa cache si es la misma linea. */
    private static boolean load(Object tl, int line) throws Exception {
        if (tl == cacheTl && line == cacheLine && cacheSyl == syllables) return n > 0;
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        // El estado de tiempo se conserva si es la MISMA linea de texto aunque Compose haya creado otro vy8.
        boolean sameKey = text != null && text.equals(cacheText) && line == cacheLine && cacheSyl == syllables;
        int prevN = n;
        cacheTl = tl;
        cacheLine = line;
        cacheText = text;
        cacheSyl = syllables;
        n = 0;
        if (text == null || line < 0 || line >= lines) return false;
        if (tl != langTl) {
            langEs = Syllables.looksSpanish(text);
            langTl = tl;
        }
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(0, le - ls);
        if (lx0.length < cap) {
            lx0 = new float[cap]; lx1 = new float[cap]; lt = new float[cap]; lb = new float[cap];
        }
        int i = ls;
        while (i < le) {
            if (Character.isWhitespace(text.charAt(i))) { i++; continue; }
            int j = i;
            while (j < le && !Character.isWhitespace(text.charAt(j))) j++;
            // Palabra [i, j): se corta en silabas (o cada letra es una unidad).
            boolean[] brk = syllables ? Syllables.breaks(text.substring(i, j), langEs) : null;
            for (int k = i; k < j; k++) {
                Object r = mBox.invoke(tl, k);
                float l = rl.getFloat(r), rg = rr.getFloat(r);
                float x0 = Math.min(l, rg), x1 = Math.max(l, rg);
                float tp = rt.getFloat(r), bt = rb.getFloat(r);
                boolean fresh = (k == i) || !syllables || brk[k - i];
                if (fresh || n == 0) {
                    lx0[n] = x0; lx1[n] = x1; lt[n] = tp; lb[n] = bt;
                    n++;
                } else {
                    int u = n - 1;
                    if (x0 < lx0[u]) lx0[u] = x0;
                    if (x1 > lx1[u]) lx1[u] = x1;
                    if (tp < lt[u]) lt[u] = tp;
                    if (bt > lb[u]) lb[u] = bt;
                }
            }
            i = j;
        }
        if (!(sameKey && prevN == n)) resetState();
        return n > 0;
    }

    /** Pone en cero el nivel de crecimiento de todas las silabas (linea nueva, seek, mucho tiempo sin dibujar). */
    private static void resetState() {
        if (lvl.length < n) {
            lvl = new float[n];
            dwell = new float[n];
        }
        java.util.Arrays.fill(lvl, 0, Math.min(n, lvl.length), 0f);
        java.util.Arrays.fill(dwell, 0, Math.min(n, dwell.length), 0f);
        lastNs = 0L;
        prevEdge = Float.NaN;
    }

    private static float smooth(float x) {
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return x * x * (3f - 2f * x);
    }

    /**
     * Dibuja la fila con el efecto silaba por silaba.
     * @return true si ya dibujo todo (el parche salta la llamada original); false si no hay nada que agrandar o
     *         algo fallo antes de dibujar (el parche deja la llamada original, como Eclipse).
     */
    public static boolean draw(Canvas c, Object ad4, Object brush) {
        if (broken || curTl == null || c == null) return false;
        Object tl = curTl;
        try {
            init(tl);
            if (syllables) return drawFlow(c, ad4, brush, tl);
            if (!load(tl, curLine)) return false;
            float font = curFont;
            if (!(font > 1f)) return false;
            float edge = curEdge;
            // Escala de cada silaba segun donde esta el borde del relleno.
            float[] sc = new float[n];
            int cnt = 0;
            float hideL = Float.MAX_VALUE, hideR = -Float.MAX_VALUE;
            float dt = 0f;
            if (syllables) {
                long now = System.nanoTime();
                if (lastNs == 0L || now - lastNs > 500000000L
                        || (!Float.isNaN(prevEdge) && edge < prevEdge - font * 0.5f)) {
                    java.util.Arrays.fill(lvl, 0, n, 0f);
                    java.util.Arrays.fill(dwell, 0, n, 0f);
                } else {
                    dt = Math.min((now - lastNs) / 1.0e9f, 0.1f);
                }
                lastNs = now;
                prevEdge = edge;
            }
            for (int i = 0; i < n; i++) {
                float f;
                if (syllables) {
                    if (edge < lx0[i]) {                       // todavia no llega: en cero
                        lvl[i] = 0f;
                        dwell[i] = 0f;
                    } else if (edge <= lx1[i]) {               // el relleno esta dentro de esta silaba
                        dwell[i] += dt;
                        if (dwell[i] > DELAY) lvl[i] = Math.min(1f, lvl[i] + dt / GROW);
                    } else {                                   // ya la paso: baja suave
                        lvl[i] = Math.max(0f, lvl[i] - dt / FALL);
                    }
                    f = smooth(lvl[i]);
                } else if (edge < lx0[i]) f = smooth(1f - ((lx0[i] - edge) / font) / AHEAD);   // por cantar
                else if (edge <= lx1[i]) f = 1f;                                        // el relleno va por esta silaba
                else f = 1f - smooth(((edge - lx1[i]) / font) / BACK);                  // ya cantada
                float s = 1f + (MAX_SCALE - 1f) * f;
                if (s < 1.004f) { sc[i] = 0f; continue; }
                sc[i] = s;
                cnt++;
                if (lx0[i] < hideL) hideL = lx0[i];
                if (lx1[i] > hideR) hideR = lx1[i];
            }
            if (cnt == 0) return false;

            // 1) La linea normal SIN las silabas afectadas.
            c.save();
            try {
                try {
                    c.clipOutRect(hideL, -100000f, hideR, 100000f);
                } catch (NoSuchMethodError e) {
                    c.clipRect(hideL, -100000f, hideR, 100000f, Region.Op.DIFFERENCE);
                }
                mDraw.invoke(null, ad4, tl, brush);
            } catch (Throwable t) {
                broken = true;
                System.out.println("LyricsPop: desactivado por error: " + t);
                return false;
            } finally {
                c.restore();
            }

            // 2) Cada silaba afectada, mas grande (la mas grande al final, encima de las demas).
            boolean[] done = new boolean[n];
            for (int k = 0; k < cnt; k++) {
                int best = -1;
                for (int i = 0; i < n; i++) {
                    if (sc[i] > 0f && !done[i] && (best < 0 || sc[i] < sc[best])) best = i;
                }
                if (best < 0) break;
                done[best] = true;
                float s = sc[best];
                float cx = (lx0[best] + lx1[best]) * 0.5f;
                float cy = (lt[best] + lb[best]) * 0.5f;
                float hw = (lx1[best] - lx0[best]) * 0.5f * s;
                float lift = font * LIFT * ((s - 1f) / (MAX_SCALE - 1f));
                c.save();
                try {
                    // v0.20.91: recorte vertical solo a la fila de la silaba (ya escalada y levantada), para que la fila de abajo no asome como rayitas
                    // v0.20.93: sin margen (con margen se colaban los descendentes de la fila de arriba como rayitas)
                    float cTop = cy - lift - (cy - lt[best]) * s + font * 0.01f;
                    float cBot = cy - lift + (lb[best] - cy) * s;
                    c.clipRect(cx - hw, cTop, cx + hw, cBot);
                    c.translate(cx, cy - lift);
                    c.scale(s, s);
                    c.translate(-cx, -cy);
                    mDraw.invoke(null, ad4, tl, brush);
                } catch (Throwable t) {
                    broken = true;
                    System.out.println("LyricsPop: desactivado por error: " + t);
                    break;
                } finally {
                    c.restore();
                }
            }
            return true;
        } catch (Throwable t) {
            broken = true;
            System.out.println("LyricsPop: desactivado por error: " + t);
            return false;
        }
    }

    // ======================= v0.20.79: modo SILABAS "con vida" (estilo Mochy) =======================
    // Todas las silabas SUBEN suave a su lugar cuando llega el relleno (las que faltan esperan un poquito mas abajo);
    // solo las SOSTENIDAS crecen (se mide la velocidad del relleno: si va lento, la nota es larga). Cada nivel
    // (subida, crecimiento) sigue su objetivo con un resorte amortiguado, asi no hay saltos secos.
    /** Cuanto esperan abajo las silabas que aun no se cantan (en tamanos de letra). */
    private static final float DROP = 0.094f;   // v0.20.109: como Mochy (3 dp de 32 sp)
    /** Cuanto sube de mas una silaba sostenida (en tamanos de letra). */
    private static final float HELD_LIFT = 0.078f;   // v0.20.109: como Mochy (2.5 dp de 32 sp)
    /** Cuanto crece una silaba sostenida (1.075 = 7.5%, como Mochy). */
    private static final float HELD_SCALE = 1.075f;   // v0.20.109: 7.5% como Mochy (antes 15%)
    /** La silaba empieza a subir esta distancia (en tamanos de letra) antes de que llegue el relleno. */
    private static final float RISE_LEAD = 0.45f;
    /** Segundos que tarda la subida en alcanzar su objetivo. */
    private static final float RISE_FOLLOW = 0.08f;   // v0.20.109: como Mochy
    /** v0.20.97: segundos que tarda en BAJAR a la espera cuando una fila empieza (suave, sin salto). */
    private static final float RISE_SINK = 0.35f;
    /** Segundos que tarda el crecimiento en alcanzar su objetivo (respira mas lento que la subida). */
    private static final float SWELL_FOLLOW = 0.40f;
    /** v0.20.96: segundos que tarda en BAJAR (mas rapido que al crecer, para estar chica cuando acaba la silaba). */
    private static final float SWELL_FALL = 0.12f;
    /** v0.20.101: brillo = GLOW_RINGS capas apiladas (de fuera hacia dentro), cada una muy tenue; al sumarse dan una caida suave sin bordes marcados. */
    private static final int GLOW_RINGS = 1;   // v0.20.115: UNA capa de 8 copias (Mochy usa un solo radio): antes 3 en la 114 y 6 antes
    private static final float GLOW_RADIUS = 0.03f;   // radio de la capa mas externa (en tamanos de letra); v0.20.114: antes 0.14 (Mochy: 2.6 px sobre letra de ~90 px)
    private static final float GLOW_LAYER_ALPHA = 0.70f;   // v0.20.115: antes 0.30 (114) y 0.115 (113)
    /** Brillo minimo para dibujarlo / brillo de una silaba normal (no sostenida) bajo el relleno. */
    private static final float GLOW_MIN = 0.03f, GLOW_BASE = 0.45f;   // v0.20.116: vuelve a 0.45 (brillo suave en todas las silabas; en la 114/115 era 0 = solo notas largas y casi no se notaba)
    private static final float[] GX = {1f, 0.7071f, 0f, -0.7071f, -1f, -0.7071f, 0f, 0.7071f};
    private static final float[] GY = {0f, 0.7071f, 1f, 0.7071f, 0f, -0.7071f, -1f, -0.7071f};
    /** v0.20.116: brillo con shader (LyricsGlowShader). Fuerza del halo: 1.6 como Mochy (BloomStrength). */
    private static boolean glowShaderOn = true;
    private static final float GLOW_SHADER_STRENGTH = 2.2f;
    private static boolean glowOff;
    private static boolean glowOn;
    /** v0.20.110: parche "Letras: colas de letras completas": los renglones con otro renglon debajo/arriba no cortan las colas (g, y, p, q, j). */
    private static boolean tailsOn;
    private static final float TAIL_MARGIN = 0.09f;   // v0.20.113: antes 0.15; la punta de la tilde (mi) quedaba dentro del recorte largo del renglon de arriba
    /** v0.20.111: Eclipse recorta CADA renglon a su caja (tn1.E0, clipRect antes de dibujar); el parche pide aqui cuanto alargar ese recorte hacia abajo. */
    private static float clipBotAdd;

    /** v0.20.96: segundos antes del final de la silaba en que empieza a bajar / en que ya debe estar chica. */
    private static final float REL_START = 0.50f, REL_END = 0.12f;
    /** Segundos por letra: por debajo de FAST no crece nada; por encima de SLOW crece completo. */
    private static final float FAST_SPC = 0.10f, SLOW_SPC = 0.34f;
    /** Crece rapido al empezar la silaba (primer 20%) y baja en el ultimo 12%. */
    private static final float ATTACK = 0.50f, RELEASE = 0.30f;
    /** Segundos para suavizar la medida de velocidad del relleno cuando frena (nota larga) y cuando acelera. */
    private static final float SPEED_SMOOTH = 0.15f, SPEED_UP = 0.10f;
    /** Velocidad del relleno (tamanos de letra por segundo) por debajo de la cual se cuenta como pausa, no como nota larga. */
    private static final float MIN_SPEED = 0.05f;
    /** v0.20.105: la velocidad del relleno se mide cada SPEED_WIN segundos como minimo (el tiempo entre cuadros tiembla y movia las letras 1 px). */
    private static final float SPEED_WIN = 0.04f;
    /** v0.20.105: una silaba no se mueve de lado hasta que el cambio pase de DX_DEAD pixeles. */
    private static final float DX_DEAD = 1.0f;

    /** v0.20.106: la tilde de la "i" sobresale a la derecha de su cuadro; el recorte de su silaba se ensancha ACC_BAND_W (solo arriba, hasta ACC_BAND_H del alto de la fila) y ACC_EDGE_W (todo el alto, borde fino). */
    private static final float ACC_BAND_W = 0.10f, ACC_EDGE_W = 0.012f, ACC_BAND_H = 0.26f;
    private static final android.graphics.Path clipPath = new android.graphics.Path();
    /**
     * v0.20.109: subida por LETRA copiada de Mochy (LyricsGlowLine.kt): cada letra sube con una mezcla de la subida de su PALABRA
     * (se completa al RISE_DONE_AT de la palabra) y de la subida propia de la letra (LETTER_SHARE de la mezcla); la subida propia
     * empieza LETTER_LEAD letras antes de que llegue el relleno y termina LETTER_SPAN letras despues (pendiente ancha = ola suave).
     */
    private static final float RISE_DONE_AT = 0.85f, LETTER_SHARE = 0.55f, LETTER_LEAD = 0.5f, LETTER_SPAN = 2.5f;

    /** v0.20.110: margen de abajo (la cola baja un poco mas que la caja del renglon). */
    private static float tailBot(Row r, float bot, float font) {
        return (tailsOn && r.hasNext) ? bot + font * TAIL_MARGIN : bot;
    }

    private static boolean isAccI(char ch) {
        return ch == '\u00ED' || ch == '\u00CD';
    }

    /** Recorte de un grupo de silabas [bl,br]; extR/cutL ensanchan/recortan el borde para que la tilde de una "i" no se parta. */
    private static void clipGroup(Canvas c, float bl, float top, float br, float bot, boolean extR, boolean cutL, float font) {
        if (!extR && !cutL) {
            c.clipRect(bl, top, br, bot);
            return;
        }
        float m = ACC_BAND_W * font, e = ACC_EDGE_W * font;
        float yb = top + ACC_BAND_H * (bot - top);
        float rTop = br + (extR ? m : 0f), rLow = br + (extR ? e : 0f);
        float lTop = bl + (cutL ? m : 0f), lLow = bl + (cutL ? e : 0f);
        clipPath.reset();
        clipPath.moveTo(lTop, top);
        clipPath.lineTo(rTop, top);
        clipPath.lineTo(rTop, yb);
        clipPath.lineTo(rLow, yb);
        clipPath.lineTo(rLow, bot);
        clipPath.lineTo(lLow, bot);
        clipPath.lineTo(lLow, yb);
        clipPath.lineTo(lTop, yb);
        clipPath.close();
        c.clipPath(clipPath);
    }

    /** Una fila de la linea: cajas de sus silabas y estado de la animacion entre cuadros. */
    private static final class Row {
        Object tl;
        int n;
        float[] x0, x1, top, bot;
        boolean hasPrev, hasNext;   // v0.20.110: hay otro renglon encima / debajo en el mismo texto
        int[] lc;
        float[] rise, riseV, swell, swellV, glow, glowV;
        long lastNs;
        float prevEdge = Float.NaN, spd, stall;
        /** v0.20.105: muestreo de la velocidad del relleno (cada ~40 ms, no cada cuadro) y desplazamiento lateral sostenido (zona muerta). */
        long spdNs;
        float spdEdge;
        float[] dxHold;
        /** v0.20.106: la silaba termina en "i" con tilde (la tilde sobresale a la derecha de su cuadro). */
        boolean[] acc;
        /** v0.20.109: cajas por letra, caja de su palabra (wx0/wx1), primera letra de cada silaba y subida por letra (lrise: 1 = en su sitio); rlo/rhi = la letra mas baja/alta de cada silaba. */
        float[] lx0, lx1, wx0, wx1, lrise, lriseV, rlo, rhi;
        int nl;
        int[] lf;
        boolean[] lacc;
    }

    private static final java.util.HashMap<String, Row> rows = new java.util.HashMap<String, Row>();

    private static Row rowFor(Object tl, int line) throws Exception {
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        if (text == null || line < 0 || line >= lines) return null;
        String key = line + "#" + text;
        Row old = rows.get(key);
        if (old != null && old.tl == tl) return old;
        if (tl != langTl) {
            langEs = Syllables.looksSpanish(text);
            langTl = tl;
        }
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(1, le - ls);
        float[] x0 = new float[cap], x1 = new float[cap], tp = new float[cap], bt = new float[cap];
        int[] lc = new int[cap];
        boolean[] acc = new boolean[cap];
        float[] lx0 = new float[cap], lx1 = new float[cap];
        boolean[] lacc = new boolean[cap];
        float[] wx0 = new float[cap], wx1 = new float[cap];
        int[] lf = new int[cap];
        int nl = 0;
        int n = 0;
        int i = ls;
        while (i < le) {
            if (Character.isWhitespace(text.charAt(i))) { i++; continue; }
            int j = i;
            while (j < le && !Character.isWhitespace(text.charAt(j))) j++;
            int nl0 = nl;
            boolean[] brk = Syllables.breaks(text.substring(i, j), langEs);
            for (int k = i; k < j; k++) {
                Object r = mBox.invoke(tl, k);
                float l = rl.getFloat(r), rg = rr.getFloat(r);
                float a = Math.min(l, rg), b = Math.max(l, rg);
                float t = rt.getFloat(r), d = rb.getFloat(r);
                if (k == i || brk[k - i] || n == 0) {
                    x0[n] = a; x1[n] = b; tp[n] = t; bt[n] = d; lc[n] = 1;
                    acc[n] = isAccI(text.charAt(k));
                    lf[n] = nl;
                    n++;
                } else {
                    int u = n - 1;
                    if (a < x0[u]) x0[u] = a;
                    if (b > x1[u]) x1[u] = b;
                    if (t < tp[u]) tp[u] = t;
                    if (d > bt[u]) bt[u] = d;
                    lc[u]++;
                    acc[u] = isAccI(text.charAt(k));
                }
                lx0[nl] = a; lx1[nl] = b; lacc[nl] = isAccI(text.charAt(k));
                nl++;
            }
            float wa = Float.MAX_VALUE, wb = -Float.MAX_VALUE;
            for (int q = nl0; q < nl; q++) { if (lx0[q] < wa) wa = lx0[q]; if (lx1[q] > wb) wb = lx1[q]; }
            for (int q = nl0; q < nl; q++) { wx0[q] = wa; wx1[q] = wb; }
            i = j;
        }
        if (rows.size() > 24) rows.clear();
        Row r = (old != null && old.n == n) ? old : new Row();
        boolean fresh = r != old;
        r.tl = tl;
        r.n = n;
        r.hasPrev = line > 0;
        r.hasNext = line + 1 < lines;
        r.x0 = x0; r.x1 = x1; r.top = tp; r.bot = bt; r.lc = lc; r.acc = acc;
        r.lx0 = lx0; r.lx1 = lx1; r.lacc = lacc; r.lf = lf;
        r.wx0 = wx0; r.wx1 = wx1; r.nl = nl;
        if (fresh) {
            r.rise = new float[n]; r.riseV = new float[n];
            r.swell = new float[n]; r.swellV = new float[n];
            r.glow = new float[n]; r.glowV = new float[n];
            r.lastNs = 0L;
            r.dxHold = new float[n];
            r.lrise = new float[cap]; r.lriseV = new float[cap];
            r.rlo = new float[n]; r.rhi = new float[n];
        }
        rows.put(key, r);
        return r;
    }

    /** Resorte amortiguado (critico): x sigue a target en unos "follow" segundos, sin saltos ni rebote. */
    private static void damp(float[] x, float[] v, int i, float target, float follow, float dt) {
        if (dt <= 0f) return;
        float omega = 2f / Math.max(0.0001f, follow);
        float k = omega * dt;
        float e = 1f / (1f + k + 0.48f * k * k + 0.235f * k * k * k);
        float change = x[i] - target;
        float temp = (v[i] + omega * change) * dt;
        v[i] = (v[i] - omega * temp) * e;
        x[i] = target + (change + temp) * e;
        if (x[i] < 0f) { x[i] = 0f; v[i] = 0f; } else if (x[i] > 1f) { x[i] = 1f; v[i] = 0f; }
    }

    /** 0 = ya subida y quieta, 1 = esperando abajo y quieta, -1 = en movimiento (se dibuja sola). */
    private static int classOf(Row r, int i) {
        if (r.swell[i] >= 0.004f || r.glow[i] >= GLOW_MIN) return -1;
        if (r.rlo[i] >= 0.996f) return 0;
        if (r.rhi[i] <= 0.004f) return 1;
        return -1;
    }

    /** v0.20.109: posicion del relleno en LETRAS (0 = al empezar la primera letra, 1 = al final de la primera...), como el "next" de Mochy. */
    private static float edgeLetters(Row r, float edge) {
        int nl = r.nl;
        if (nl <= 0) return 0f;
        float w0 = Math.max(1f, r.lx1[0] - r.lx0[0]);
        if (edge < r.lx0[0]) return (edge - r.lx0[0]) / w0;
        for (int l = 0; l < nl; l++) {
            if (edge < r.lx1[l]) {
                if (edge <= r.lx0[l]) return l;
                return l + (edge - r.lx0[l]) / Math.max(1f, r.lx1[l] - r.lx0[l]);
            }
        }
        return nl + (edge - r.lx1[nl - 1]) / Math.max(1f, r.lx1[nl - 1] - r.lx0[nl - 1]);
    }

    /** v0.20.109: objetivo de subida de la letra l (receta de Mochy: palabra + letra mezcladas). */
    private static float riseTarget(Row r, int l, float edge, float pos) {
        float wa = r.wx0[l], wb = r.wx1[l];
        if (edge >= wb) return 1f;                                   // la palabra ya paso: todas arriba
        float through = (edge - wa) / Math.max(1f, wb - wa);
        float wordRise = smooth(through / RISE_DONE_AT);
        float letterRise = smooth((pos - l + LETTER_LEAD) / LETTER_SPAN);
        return wordRise + (letterRise - wordRise) * LETTER_SHARE;
    }

    private static boolean drawFlow(Canvas c, Object ad4, Object brush, Object tl) throws Throwable {
        Row r = rowFor(tl, curLine);
        if (r == null || r.n == 0) return false;
        final float font = curFont;
        if (!(font > 1f)) return false;
        final float edge = curEdge;
        final int n = r.n;
        long now = System.nanoTime();
        boolean snap = r.lastNs == 0L || now - r.lastNs > 500000000L
                || (!Float.isNaN(r.prevEdge) && edge < r.prevEdge - font * 0.5f);
        float dt = snap ? 0f : Math.min((now - r.lastNs) / 1.0e9f, 0.1f);
        if (snap) {
            r.stall = 0f;
            r.spd = -1f;                                // todavia sin medir: no crece nada hasta tener una medida
            r.spdNs = now;
            r.spdEdge = edge;
        } else {
            float dtS = (now - r.spdNs) / 1.0e9f;
            if (dtS >= SPEED_WIN) {                     // v0.20.105: se mide sobre una ventana, no cuadro a cuadro
                dtS = Math.min(dtS, 0.1f);
                float inst = Math.max(0f, (edge - r.spdEdge) / dtS);
                if (inst < MIN_SPEED * font) r.stall += dtS; else r.stall = 0f;
                if (r.stall > 0.05f) {
                    r.spd = 0f;                         // el relleno esta quieto (pausa): no es una nota larga
                } else if (r.spd < 0f || inst > r.spd) {
                    r.spd = (r.spd < 0f) ? inst : r.spd + (inst - r.spd) * Math.min(1f, dtS / SPEED_UP);   // acelera: se nota rapido
                } else {
                    r.spd += (inst - r.spd) * Math.min(1f, dtS / SPEED_SMOOTH);                            // frena: se suaviza
                }
                r.spdNs = now;
                r.spdEdge = edge;
            }
        }
        if (snap || dt > 0.002f) {
            r.lastNs = now;
            r.prevEdge = edge;
        }
        final float pos = edgeLetters(r, edge);
        for (int i = 0; i < n; i++) {
            float w = r.x1[i] - r.x0[i];
            float ts = 0f;                              // objetivo del crecimiento (solo notas largas)
            if (edge >= r.x0[i] && edge < r.x1[i] - 0.02f * font && w > 1f && r.spd > MIN_SPEED * font) {
                float spc = (w / Math.max(1, r.lc[i])) / r.spd;      // segundos por letra
                float hold = smooth((spc - FAST_SPC) / (SLOW_SPC - FAST_SPC));
                float pw = (edge - r.x0[i]) / w;
                // v0.20.96: la bajada se mide en SEGUNDOS que faltan para que el relleno salga de la silaba (no en ancho):
                // empieza REL_START antes del final y llega a 0 en REL_END, asi al terminar la silaba (y la linea) ya esta chica
                float remain = (r.x1[i] - edge) / Math.max(1f, r.spd);
                ts = hold * smooth(pw / ATTACK) * smooth((remain - REL_END) / (REL_START - REL_END));
            }
            if (snap) {
                // v0.20.97: al empezar (fila nueva o linea nueva) todo parte en su lugar normal (como lo dibujaba Eclipse
                // antes) y las que faltan BAJAN suave a su espera, en vez de saltar de golpe hacia abajo
                r.rise[i] = 1f; r.riseV[i] = 0f; r.rlo[i] = 1f; r.rhi[i] = 1f;
                r.swell[i] = 0f; r.swellV[i] = 0f;
                r.glow[i] = 0f; r.glowV[i] = 0f;
                for (int l = r.lf[i]; l < r.lf[i] + r.lc[i]; l++) { r.lrise[l] = 1f; r.lriseV[l] = 0f; }
            } else {
                // v0.20.109: la subida es por letra (receta de Mochy); la de la silaba es el promedio (para el brillo) y rlo/rhi la letra mas baja/alta
                float rs = 0f, rlow = 1f, rhigh = 0f;
                for (int l = r.lf[i]; l < r.lf[i] + r.lc[i]; l++) {
                    float lt = riseTarget(r, l, edge, pos);
                    damp(r.lrise, r.lriseV, l, lt, lt < r.lrise[l] ? RISE_SINK : RISE_FOLLOW, dt);
                    float v = r.lrise[l];
                    rs += v;
                    if (v < rlow) rlow = v;
                    if (v > rhigh) rhigh = v;
                }
                r.rise[i] = rs / Math.max(1, r.lc[i]);
                r.rlo[i] = rlow;
                r.rhi[i] = rhigh;
                damp(r.swell, r.swellV, i, ts, ts < r.swell[i] ? SWELL_FALL : SWELL_FOLLOW, dt);
                // v0.20.100: brillo de la silaba por la que va el relleno (sube rapido, baja mas lento, y se apaga hacia el final de la silaba)
                float tg = 0f;
                if (edge >= r.x0[i] && edge < r.x1[i]) {
                    float remainG = (r.x1[i] - edge) / Math.max(1f, r.spd);
                    tg = (GLOW_BASE + (1f - GLOW_BASE) * ts) * smooth((remainG - 0.04f) / 0.26f);
                }
                damp(r.glow, r.glowV, i, tg, tg > r.glow[i] ? 0.12f : 0.40f, dt);
            }
        }
        // Tamano, altura y desplazamiento lateral de cada silaba (las vecinas se apartan para dar lugar).
        float[] sc = new float[n], dy = new float[n], dx = new float[n], delta = new float[n];
        float total = 0f;
        boolean idle = true;
        for (int i = 0; i < n; i++) {
            float sw = r.swell[i];
            sc[i] = 1f + (HELD_SCALE - 1f) * sw;
            delta[i] = (sc[i] - 1f) * (r.x1[i] - r.x0[i]);
            total += delta[i];
            int cls = classOf(r, i);
            if (cls == 0) dy[i] = 0f;
            else if (cls == 1) dy[i] = font * DROP;
            else dy[i] = -sw * font * HELD_LIFT;               // v0.20.109: la subida va por letra (se suma al dibujar)
            if (cls != 0) idle = false;
        }
        float before = 0f;
        for (int i = 0; i < n; i++) {
            float after = total - before - delta[i];
            dx[i] = 0.5f * (before - after);
            before += delta[i];
            if (Math.abs(dx[i]) > 0.01f) idle = false;
        }
        if (idle) {
            for (int q = 0; q < n; q++) r.dxHold[q] = 0f;
            return false;                               // todo en su lugar: que lo dibuje Eclipse como siempre
        }
        // v0.20.105: zona muerta: la silaba solo se mueve de lado cuando el cambio pasa de DX_DEAD px (Android pega las letras a pixeles enteros y un cambio diminuto la hacia saltar 1 px)
        for (int q = 0; q < n; q++) {
            if (snap || Math.abs(dx[q] - r.dxHold[q]) >= DX_DEAD) r.dxHold[q] = dx[q];
            dx[q] = r.dxHold[q];
        }

        int i = 0;
        while (i < n) {
            int cls = classOf(r, i);
            int j = i;
            if (cls >= 0) {
                while (j + 1 < n && classOf(r, j + 1) == cls && Math.abs(dx[j + 1] - dx[i]) < 0.01f) j++;
            }
            float bl = (i == 0) ? -100000f : (r.x1[i - 1] + r.x0[i]) * 0.5f;
            float br = (j == n - 1) ? 100000f : (r.x1[j] + r.x0[j + 1]) * 0.5f;
            float s = (cls < 0) ? sc[i] : 1f;
            final boolean extR = j < n - 1 && r.acc != null && r.acc[j];   // v0.20.106
            final boolean cutL = i > 0 && r.acc != null && r.acc[i - 1];
            // v0.20.100: brillo (halo) detras de la silaba activa
            if (glowOn && !glowOff && cls < 0 && r.glow[i] > GLOW_MIN) {
                try {
                    float gt = r.top[i], gb = r.bot[i];
                    for (int g = i + 1; g <= j; g++) { if (r.top[g] < gt) gt = r.top[g]; if (r.bot[g] > gb) gb = r.bot[g]; }
                    float gcx = (r.x0[i] + r.x1[i]) * 0.5f, gcy = (r.top[i] + r.bot[i]) * 0.5f;
                    float lv = Math.min(1f, r.glow[i]);
                    int alpha = Math.round(255f * GLOW_LAYER_ALPHA * lv);
                    // v0.20.116: primero el brillo con shader (una sola capa, como Mochy); si no se puede, el halo de copias de abajo
                    boolean shaded = false;
                    if (glowShaderOn) {
                        final Object fAd4 = ad4, fTl = tl, fBrush = brush;
                        int sv = c.save();
                        try {
                            c.translate(dx[i], dy[i] + font * DROP * (1f - r.rise[i]));
                            c.translate(gcx, gcy);
                            c.scale(s, s);
                            c.translate(-gcx, -gcy);
                            clipGroup(c, bl, gt + font * 0.01f, br, tailBot(r, gb, font), extR, cutL, font);
                            float gm = font * 0.25f;
                            shaded = LyricsGlowShader.draw(c, r.x0[i] - gm, gt - gm, r.x1[j] + gm, tailBot(r, gb, font) + gm,
                                    GLOW_RADIUS * font, GLOW_SHADER_STRENGTH * lv, new LyricsGlowShader.Content() {
                                        public void run() throws Exception {
                                            try {
                                                mDraw.invoke(null, fAd4, fTl, fBrush);
                                            } catch (java.lang.reflect.InvocationTargetException ite) {
                                                throw ite;
                                            }
                                        }
                                    });
                        } catch (Throwable t) {
                            System.out.println("LyricsPop: brillo con shader desactivado por error: " + t);
                            LyricsGlowShader.say("poperr", "Brillo: error en LyricsPop, usa 8 copias. " + t);
                            glowShaderOn = false;
                            shaded = false;
                        } finally {
                            c.restoreToCount(sv);
                        }
                    }
                    if (!shaded) LyricsGlowShader.say("copies", "Brillo: usando halo de 8 copias (respaldo)");
                    for (int ring = GLOW_RINGS; !shaded && ring >= 1 && alpha >= 2; ring--) {
                        float rad = GLOW_RADIUS * font * ring / GLOW_RINGS;
                        float rot = ((ring & 1) == 0) ? 0.3927f : 0f;   // anillos pares girados 22.5 grados: tapan los huecos entre copias
                        float cr = (float) Math.cos(rot), sr = (float) Math.sin(rot);
                        int saved = c.save();
                        try {
                            c.translate(dx[i], dy[i] + font * DROP * (1f - r.rise[i]));
                            c.translate(gcx, gcy);
                            c.scale(s, s);
                            c.translate(-gcx, -gcy);
                            clipGroup(c, bl, gt + font * 0.01f, br, tailBot(r, gb, font), extR, cutL, font);
                            c.saveLayerAlpha(-100000f, -100000f, 100000f, 100000f, alpha);
                            for (int a = 0; a < 8; a++) {
                                c.save();
                                try {
                                    c.translate((GX[a] * cr - GY[a] * sr) * rad, (GX[a] * sr + GY[a] * cr) * rad);
                                    mDraw.invoke(null, ad4, tl, brush);
                                } finally {
                                    c.restore();
                                }
                            }
                        } finally {
                            c.restoreToCount(saved);
                        }
                    }
                } catch (Throwable t) {
                    System.out.println("LyricsPop: brillo desactivado por error: " + t);
                    glowOff = true;
                }
            }
            // v0.20.109: silaba en movimiento: cada letra con su propia altura (receta de Mochy), por tandas de letras con la misma altura
            boolean waved = false;
            float flatDy = 0f;
            float[] dyl = null;
            int lf0 = r.lf[i], lf1 = r.lf[i] + r.lc[i];
            if (cls < 0) {
                dyl = new float[lf1 - lf0];
                float lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
                for (int l = lf0; l < lf1; l++) {
                    float v = font * DROP * (1f - r.lrise[l]);
                    dyl[l - lf0] = v;
                    if (v < lo) lo = v;
                    if (v > hi) hi = v;
                }
                waved = (hi - lo) >= 0.35f;
                flatDy = (lo + hi) * 0.5f;
            }
            float gTop = r.top[i], gBot = r.bot[i];
            for (int g = i + 1; g <= j; g++) { if (r.top[g] < gTop) gTop = r.top[g]; if (r.bot[g] > gBot) gBot = r.bot[g]; }
            int l0 = lf0;
            while (l0 < lf1) {
                int l1 = l0;
                float runDy = 0f;
                if (waved) {
                    runDy = dyl[l0 - lf0];
                    while (l1 + 1 < lf1 && Math.abs(dyl[l1 + 1 - lf0] - runDy) < 0.35f) l1++;
                } else {
                    l1 = lf1 - 1;
                    runDy = flatDy;
                }
                float rbl = (l0 == lf0) ? bl : (r.lx1[l0 - 1] + r.lx0[l0]) * 0.5f;
                float rbr = (l1 == lf1 - 1) ? br : (r.lx1[l1] + r.lx0[l1 + 1]) * 0.5f;
                boolean rExt = (l1 == lf1 - 1) ? extR : r.lacc[l1];
                boolean rCut = (l0 == lf0) ? cutL : r.lacc[l0 - 1];
                c.save();
                try {
                    c.translate(dx[i], dy[i] + runDy);
                    if (s > 1.0005f) {
                        float cx = (r.x0[i] + r.x1[i]) * 0.5f, cyy = (r.top[i] + r.bot[i]) * 0.5f;
                        c.translate(cx, cyy);
                        c.scale(s, s);
                        c.translate(-cx, -cyy);
                    }
                    clipGroup(c, rbl, gTop + font * 0.01f, rbr, tailBot(r, gBot, font), rExt, rCut, font);   // v0.20.93: solo la fila de la silaba, sin margen (el margen dejaba pasar rayitas de la fila vecina)
                    mDraw.invoke(null, ad4, tl, brush);
                } catch (Throwable t) {
                    broken = true;
                    System.out.println("LyricsPop: desactivado por error: " + t);
                    return i > 0;                            // si ya dibujo algo, no dejar que Eclipse dibuje encima
                } finally {
                    c.restore();
                }
                l0 = l1 + 1;
            }
            i = j + 1;
        }
        return true;
    }
}
