package app.eclipse.extension.player;

import android.graphics.Canvas;
import android.graphics.Region;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.75 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 *
 * Eclipse dibuja la linea activa (tn1.E0) con UN solo texto (vy8 = TextLayoutResult) y un degradado blanco/gris.
 * Aqui se busca la PALABRA donde esta el borde del relleno y el parche dibuja esa palabra mas grande:
 *  1) prep(): con el texto de la linea y las cajas de las letras (vy8.g = inicio de linea, vy8.b = caja de una letra)
 *     calcula la caja de la palabra activa y cuanto crece (sube suave al entrar el relleno y baja suave al salir).
 *  2) hide()/end(): la linea normal se dibuja SIN esa palabra (recorte que la excluye).
 *  3) big()/end(): la linea se dibuja otra vez, mas grande alrededor del centro de la palabra y recortada a ella.
 * Las demas palabras no se tocan; el texto de abajo y el acomodo de las lineas largas tampoco.
 * Todo con reflexion y a prueba de fallos: si algo no coincide, prep() devuelve false y se ve como en Eclipse.
 * Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** Cuanto crece la palabra activa (1.10 = 10% mas grande). */
    private static final float MAX_SCALE = 1.10f;
    /** Parte de la palabra (0..0.5) que se usa para subir/bajar el tamano sin saltos. */
    private static final float RAMP = 0.20f;

    // Estado de la palabra activa (se llena en prep, se usa en hide/big en el mismo cuadro).
    private static float bx0, bx1, cx, cy, scale, pad;

    private static boolean broken;
    private static Class<?> cls;
    private static Field fInput, fText, fPara, fLines;
    private static Field fAnn;
    private static Method mLineStart, mBox;
    private static Field rl, rt, rr, rb;

    private static void init(Object tl) throws Exception {
        Class<?> c = tl.getClass();
        if (c == cls) return;
        Field input = c.getDeclaredField("a");   // vy8.a = uy8 (entrada del texto)
        Field para = c.getDeclaredField("b");    // vy8.b = cl5 (parrafo)
        input.setAccessible(true);
        para.setAccessible(true);
        Class<?> ic = input.getType();
        Field ann = ic.getDeclaredField("a");    // uy8.a = ct (AnnotatedString)
        ann.setAccessible(true);
        Field txt = ann.getType().getDeclaredField("r"); // ct.r = String
        txt.setAccessible(true);
        Field lines = para.getType().getDeclaredField("f"); // cl5.f = numero de lineas
        lines.setAccessible(true);
        Method ls = c.getDeclaredMethod("g", int.class);   // vy8.g(linea) = inicio de la linea
        Method box = c.getDeclaredMethod("b", int.class);  // vy8.b(letra) = caja (g47)
        ls.setAccessible(true);
        box.setAccessible(true);
        Class<?> rc = box.getReturnType();
        Field a = rc.getDeclaredField("a");
        Field b = rc.getDeclaredField("b");
        Field cc = rc.getDeclaredField("c");
        Field d = rc.getDeclaredField("d");
        a.setAccessible(true);
        b.setAccessible(true);
        cc.setAccessible(true);
        d.setAccessible(true);
        fInput = input; fPara = para; fAnn = ann; fText = txt; fLines = lines;
        mLineStart = ls; mBox = box;
        rl = a; rt = b; rr = cc; rb = d;
        cls = c;
    }

    /** Caja de una letra: {izq, arriba, der, abajo}. */
    private static float[] box(Object tl, int offset) throws Exception {
        Object r = mBox.invoke(tl, offset);
        return new float[] { rl.getFloat(r), rt.getFloat(r), rr.getFloat(r), rb.getFloat(r) };
    }

    /**
     * @param tl     vy8 (texto de la linea completa)
     * @param line   indice de la linea visual (igual al indice de la fila xt4)
     * @param edge   x del borde del relleno en esta linea
     * @return true si el borde cae dentro de una palabra y esta debe verse mas grande
     */
    public static boolean prep(Object tl, int line, float edge) {
        scale = 0f;
        if (broken || tl == null) return false;
        try {
            init(tl);
            String text = (String) fText.get(fAnn.get(fInput.get(tl)));
            int lines = fLines.getInt(fPara.get(tl));
            if (text == null || line < 0 || line >= lines) return false;
            int ls = (Integer) mLineStart.invoke(tl, line);
            int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
            if (le > text.length()) le = text.length();
            if (ls < 0) ls = 0;
            int i = ls;
            while (i < le) {
                while (i < le && Character.isWhitespace(text.charAt(i))) i++;
                int ws = i;
                while (i < le && !Character.isWhitespace(text.charAt(i))) i++;
                int we = i;
                if (we <= ws) break;
                float[] f = box(tl, ws);
                float[] l = (we - 1 == ws) ? f : box(tl, we - 1);
                float x0 = Math.min(Math.min(f[0], f[2]), Math.min(l[0], l[2]));
                float x1 = Math.max(Math.max(f[0], f[2]), Math.max(l[0], l[2]));
                if (edge < x0 || edge > x1) continue;
                float w = x1 - x0;
                if (w <= 1f) return false;
                float t = (edge - x0) / w;
                float k = Math.min(t, 1f - t) / RAMP;
                if (k > 1f) k = 1f;
                if (k <= 0f) return false;
                float ease = k * k * (3f - 2f * k);
                float s = 1f + (MAX_SCALE - 1f) * ease;
                if (s < 1.001f) return false;
                bx0 = x0;
                bx1 = x1;
                cx = (x0 + x1) * 0.5f;
                cy = (f[1] + f[3]) * 0.5f;
                pad = 0.05f * Math.max(1f, f[3] - f[1]);
                scale = s;
                return true;
            }
        } catch (Throwable t) {
            broken = true;
            System.out.println("LyricsPop: desactivado por error: " + t);
        }
        scale = 0f;
        return false;
    }

    /** Guarda el lienzo y lo recorta dejando FUERA la palabra activa (para dibujar el resto de la linea normal). */
    public static void hide(Canvas c) {
        c.save();
        try {
            try {
                c.clipOutRect(bx0, -100000f, bx1, 100000f);
            } catch (NoSuchMethodError e) {
                c.clipRect(bx0, -100000f, bx1, 100000f, Region.Op.DIFFERENCE);
            }
        } catch (Throwable t) {
            broken = true;
        }
    }

    /** Guarda el lienzo, lo recorta a la palabra (ya agrandada) y lo escala alrededor de su centro. */
    public static void big(Canvas c) {
        c.save();
        try {
            float hw = (bx1 - bx0) * 0.5f * scale + pad;
            c.clipRect(cx - hw, -100000f, cx + hw, 100000f);
            c.translate(cx, cy);
            c.scale(scale, scale);
            c.translate(-cx, -cy);
        } catch (Throwable t) {
            broken = true;
        }
    }

    public static void end(Canvas c) {
        c.restore();
    }
}
