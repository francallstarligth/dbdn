package app.eclipse.extension.player;

import android.graphics.Canvas;
import android.graphics.Region;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * v0.20.77 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 *
 * Eclipse dibuja la linea activa (tn1.E0) con UN solo texto (vy8 = TextLayoutResult) y un degradado blanco/gris cuyo
 * borde sigue los tiempos del proveedor de letras. Aqui se hace el efecto SILABA POR SILABA (como Apple Music): la
 * silaba por la que va pasando el relleno se agranda y se levanta entera; las ya cantadas bajan de tamano suave hacia
 * la izquierda; la que viene justo delante empieza a subir un poco. El ritmo es el del relleno (o sea, el del
 * proveedor); lo unico que pone este codigo es DONDE se corta cada silaba (Syllables.java: reglas de espanol e ingles).
 *  1) begin(): guarda vy8, la fila, el borde del relleno y el tamano de letra.
 *  2) draw(): con las cajas de las letras (vy8.g = inicio de linea, vy8.b = caja de una letra) arma las silabas de la
 *     fila, calcula la escala de cada una; dibuja la linea normal SIN las silabas afectadas (recorte que las excluye)
 *     y luego dibuja la linea otra vez por cada silaba afectada, mas grande alrededor de su centro y recortada a su
 *     caja (cy7.C por reflexion).
 * Las demas silabas no se tocan; el texto de abajo y el acomodo de las lineas largas tampoco.
 * Todo con reflexion y a prueba de fallos: si algo no coincide, draw() devuelve false y se ve como en Eclipse.
 * Si SYLLABLES = false, cada letra es su propia unidad (el efecto letra por letra de la v0.20.76).
 * Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** true = por silabas; false = letra por letra (v0.20.76). */
    private static final boolean SYLLABLES = true;
    /** Cuanto crece la silaba del borde (1.15 = 15% mas grande). */
    private static final float MAX_SCALE = 1.15f;
    /** Cuanto sube la silaba del borde, en tamanos de letra (0.06 = 6%). */
    private static final float LIFT = 0.06f;
    /** Ya cantada: en tamanos de letra, a que distancia del final de la silaba vuelve al tamano normal. */
    private static final float BACK = 1.5f;
    /** Por cantar: en tamanos de letra, desde que distancia del inicio de la silaba empieza a subir. */
    private static final float AHEAD = 0.35f;

    // Entrada de este cuadro (la llena begin()).
    private static Object curTl;
    private static int curLine;
    private static float curEdge, curFont;

    // Silabas (unidades) de la linea: caja de cada una (cache por vy8 + fila).
    private static Object cacheTl;
    private static int cacheLine = -1;
    private static int n;
    private static float[] lx0 = new float[0], lx1 = new float[0], lt = new float[0], lb = new float[0];

    // Idioma del texto entero (cache por vy8).
    private static Object langTl;
    private static boolean langEs = true;

    private static boolean broken;
    private static Class<?> cls;
    private static Field fInput, fText, fPara, fLines, fAnn;
    private static Method mLineStart, mBox, mDraw;
    private static Field rl, rt, rr, rb;

    private static void init(Object tl) throws Exception {
        Class<?> c = tl.getClass();
        if (c == cls) return;
        Field input = c.getDeclaredField("a");   // vy8.a = uy8 (entrada del texto)
        Field para = c.getDeclaredField("b");    // vy8.b = cl5 (parrafo)
        input.setAccessible(true);
        para.setAccessible(true);
        Field ann = input.getType().getDeclaredField("a");    // uy8.a = ct (AnnotatedString)
        ann.setAccessible(true);
        Field txt = ann.getType().getDeclaredField("r");      // ct.r = String
        txt.setAccessible(true);
        Field lines = para.getType().getDeclaredField("f");   // cl5.f = numero de lineas
        lines.setAccessible(true);
        Method ls = c.getDeclaredMethod("g", int.class);      // vy8.g(linea) = inicio de la linea
        Method box = c.getDeclaredMethod("b", int.class);     // vy8.b(letra) = caja (g47)
        ls.setAccessible(true);
        box.setAccessible(true);
        Class<?> rc = box.getReturnType();
        Field a = rc.getDeclaredField("a");
        Field b = rc.getDeclaredField("b");
        Field cc = rc.getDeclaredField("c");
        Field d = rc.getDeclaredField("d");
        a.setAccessible(true);
        b.setAccessible(true);
        cc.setAccessible(true);
        d.setAccessible(true);
        // cy7.C(ad4, vy8, km4): dibuja el texto con degradado (estatico).
        Class<?> cy = c.getClassLoader().loadClass("cy7");
        Method draw = null;
        for (Method m : cy.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (m.getName().equals("C") && p.length == 3 && p[1] == c
                    && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                draw = m;
            }
        }
        if (draw == null) throw new NoSuchMethodException("cy7.C(ad4, vy8, km4)");
        draw.setAccessible(true);
        fInput = input; fPara = para; fAnn = ann; fText = txt; fLines = lines;
        mLineStart = ls; mBox = box; mDraw = draw;
        rl = a; rt = b; rr = cc; rb = d;
        cacheTl = null;
        cacheLine = -1;
        langTl = null;
        cls = c;
    }

    /** Guarda los datos del cuadro: vy8, indice de fila (= linea del texto), x del borde del relleno y tamano de letra (px). */
    public static void begin(Object tl, int line, float edge, float fontPx) {
        curTl = tl;
        curLine = line;
        curEdge = edge;
        curFont = fontPx;
    }

    /** Llena las cajas de las silabas de la linea (letras si SYLLABLES = false); usa cache si es la misma linea. */
    private static boolean load(Object tl, int line) throws Exception {
        if (tl == cacheTl && line == cacheLine) return n > 0;
        String text = (String) fText.get(fAnn.get(fInput.get(tl)));
        int lines = fLines.getInt(fPara.get(tl));
        cacheTl = tl;
        cacheLine = line;
        n = 0;
        if (text == null || line < 0 || line >= lines) return false;
        if (tl != langTl) {
            langEs = Syllables.looksSpanish(text);
            langTl = tl;
        }
        int ls = (Integer) mLineStart.invoke(tl, line);
        int le = (line + 1 < lines) ? (Integer) mLineStart.invoke(tl, line + 1) : text.length();
        if (le > text.length()) le = text.length();
        if (ls < 0) ls = 0;
        int cap = Math.max(0, le - ls);
        if (lx0.length < cap) {
            lx0 = new float[cap]; lx1 = new float[cap]; lt = new float[cap]; lb = new float[cap];
        }
        int i = ls;
        while (i < le) {
            if (Character.isWhitespace(text.charAt(i))) { i++; continue; }
            int j = i;
            while (j < le && !Character.isWhitespace(text.charAt(j))) j++;
            // Palabra [i, j): se corta en silabas (o cada letra es una unidad).
            boolean[] brk = SYLLABLES ? Syllables.breaks(text.substring(i, j), langEs) : null;
            for (int k = i; k < j; k++) {
                Object r = mBox.invoke(tl, k);
                float l = rl.getFloat(r), rg = rr.getFloat(r);
                float x0 = Math.min(l, rg), x1 = Math.max(l, rg);
                float tp = rt.getFloat(r), bt = rb.getFloat(r);
                boolean fresh = (k == i) || !SYLLABLES || brk[k - i];
                if (fresh || n == 0) {
                    lx0[n] = x0; lx1[n] = x1; lt[n] = tp; lb[n] = bt;
                    n++;
                } else {
                    int u = n - 1;
                    if (x0 < lx0[u]) lx0[u] = x0;
                    if (x1 > lx1[u]) lx1[u] = x1;
                    if (tp < lt[u]) lt[u] = tp;
                    if (bt > lb[u]) lb[u] = bt;
                }
            }
            i = j;
        }
        return n > 0;
    }

    private static float smooth(float x) {
        if (x <= 0f) return 0f;
        if (x >= 1f) return 1f;
        return x * x * (3f - 2f * x);
    }

    /**
     * Dibuja la fila con el efecto silaba por silaba.
     * @return true si ya dibujo todo (el parche salta la llamada original); false si no hay nada que agrandar o
     *         algo fallo antes de dibujar (el parche deja la llamada original, como Eclipse).
     */
    public static boolean draw(Canvas c, Object ad4, Object brush) {
        if (broken || curTl == null || c == null) return false;
        Object tl = curTl;
        try {
            init(tl);
            if (!load(tl, curLine)) return false;
            float font = curFont;
            if (!(font > 1f)) return false;
            float edge = curEdge;
            // Escala de cada silaba segun donde esta el borde del relleno.
            float[] sc = new float[n];
            int cnt = 0;
            float hideL = Float.MAX_VALUE, hideR = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                float f;
                if (edge < lx0[i]) f = smooth(1f - ((lx0[i] - edge) / font) / AHEAD);   // por cantar
                else if (edge <= lx1[i]) f = 1f;                                        // el relleno va por esta silaba
                else f = 1f - smooth(((edge - lx1[i]) / font) / BACK);                  // ya cantada
                float s = 1f + (MAX_SCALE - 1f) * f;
                if (s < 1.004f) { sc[i] = 0f; continue; }
                sc[i] = s;
                cnt++;
                if (lx0[i] < hideL) hideL = lx0[i];
                if (lx1[i] > hideR) hideR = lx1[i];
            }
            if (cnt == 0) return false;

            // 1) La linea normal SIN las silabas afectadas.
            c.save();
            try {
                try {
                    c.clipOutRect(hideL, -100000f, hideR, 100000f);
                } catch (NoSuchMethodError e) {
                    c.clipRect(hideL, -100000f, hideR, 100000f, Region.Op.DIFFERENCE);
                }
                mDraw.invoke(null, ad4, tl, brush);
            } catch (Throwable t) {
                broken = true;
                System.out.println("LyricsPop: desactivado por error: " + t);
                return false;
            } finally {
                c.restore();
            }

            // 2) Cada silaba afectada, mas grande (la mas grande al final, encima de las demas).
            boolean[] done = new boolean[n];
            for (int k = 0; k < cnt; k++) {
                int best = -1;
                for (int i = 0; i < n; i++) {
                    if (sc[i] > 0f && !done[i] && (best < 0 || sc[i] < sc[best])) best = i;
                }
                if (best < 0) break;
                done[best] = true;
                float s = sc[best];
                float cx = (lx0[best] + lx1[best]) * 0.5f;
                float cy = (lt[best] + lb[best]) * 0.5f;
                float hw = (lx1[best] - lx0[best]) * 0.5f * s;
                float lift = font * LIFT * ((s - 1f) / (MAX_SCALE - 1f));
                c.save();
                try {
                    c.clipRect(cx - hw, -100000f, cx + hw, 100000f);
                    c.translate(cx, cy - lift);
                    c.scale(s, s);
                    c.translate(-cx, -cy);
                    mDraw.invoke(null, ad4, tl, brush);
                } catch (Throwable t) {
                    broken = true;
                    System.out.println("LyricsPop: desactivado por error: " + t);
                    break;
                } finally {
                    c.restore();
                }
            }
            return true;
        } catch (Throwable t) {
            broken = true;
            System.out.println("LyricsPop: desactivado por error: " + t);
            return false;
        }
    }
}
