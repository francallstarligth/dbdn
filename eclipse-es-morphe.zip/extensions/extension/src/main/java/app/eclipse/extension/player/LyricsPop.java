package app.eclipse.extension.player;

import android.graphics.Canvas;

/**
 * v0.20.72 (SIN COMPILAR / SIN PROBAR). Ayudante del parche "Letras: letras grandes junto al relleno".
 * Eclipse dibuja la linea activa (tn1.E0) con un degradado: blanco a la izquierda del borde del relleno y gris a la
 * derecha. Antes de ese dibujo el parche dibuja DOS copias blancas del texto, un poco mas grandes, recortadas a una
 * ventana que termina justo en el borde del relleno: las letras ya cantadas mas cercanas al borde se ven mas grandes
 * (ventana chica = mas grande, ventana larga = apenas grande) y las demas quedan igual. No toca el texto de abajo,
 * por eso las lineas largas no se rompen. Ajustes: las constantes de abajo.
 */
public final class LyricsPop {
    private LyricsPop() {}

    /** Ventana larga (en tamanos de letra) y su escala: crecimiento suave que baja hacia la izquierda. */
    private static final float OUTER_WINDOW = 2.2f;
    private static final float OUTER_SCALE = 1.035f;
    /** Ventana corta (justo detras del borde) y su escala: la letra que se esta cantando. */
    private static final float INNER_WINDOW = 1.0f;
    private static final float INNER_SCALE = 1.075f;

    public static void begin1(Canvas c, float edge, float top, float bottom, float fontPx) {
        begin(c, edge, top, bottom, fontPx, OUTER_WINDOW, OUTER_SCALE);
    }

    public static void begin2(Canvas c, float edge, float top, float bottom, float fontPx) {
        begin(c, edge, top, bottom, fontPx, INNER_WINDOW, INNER_SCALE);
    }

    private static void begin(Canvas c, float edge, float top, float bottom, float fontPx, float window, float scale) {
        c.save();
        float w = window * fontPx;
        if (w < 0f) w = 0f;
        c.clipRect(edge - w, top, edge, bottom);
        float cy = (top + bottom) * 0.5f;
        c.translate(edge, cy);
        c.scale(scale, scale);
        c.translate(-edge, -cy);
    }

    public static void end(Canvas c) {
        c.restore();
    }
}
