package app.eclipse.extension.player;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.UUID;

/**
 * v0.20.29 (SIN COMPILAR / SIN PROBAR). Convierte el JSON de Bitchord (diseno plano) en uno "Full Bleed" para que
 * la pestana Letra se vea como Apple Music V2, sin tocar como se ve la pestana Artwork.
 *
 * Idea: las capas originales se quedan donde estan y solo se ocultan en Letra/Cola (states). Para Letra/Cola se
 * agregan COPIAS de esas capas dentro de contenedores: cabecera (portada chica + titulo + estrella + tres puntos),
 * "dock" (barra, tiempo, calidad, botones, salida, volumen e iconos: se esconde a los 3 s o al deslizar) y "bottomRow" (pastilla con
 * iconos, queda siempre visible). Las copias se ocultan en Artwork. Si algo falla, BitchordTemplate usa el diseno viejo.
 */
final class BitchordLyrics {
    private BitchordLyrics() {}

    /** Piezas copiadas de la plantilla "Apple Music V2" del APK (contenedores, presentacion, letra, cola, cabecera). */
    private static final String FRAG =
        "{\"containers\":[{\"edges\":{\"leading\":28,\"top\":12,\"trailing\":28},\"height\":\"content\",\"id\":\"header" +
        "\",\"name\":\"Compact Song Header\",\"reference\":\"safeArea\"},{\"alignment\":\"fill\",\"arrangement\":\"colu" +
        "mn\",\"edges\":{\"bottom\":0,\"leading\":0,\"trailing\":0},\"height\":\"content\",\"id\":\"dock\",\"name\":\"P" +
        "layback Controls\",\"padding\":{\"bottom\":8,\"top\":8},\"reference\":\"safeArea\",\"spacing\":20},{\"height\"" +
        ":\"content\",\"id\":\"progress\",\"name\":\"Progress and Time\",\"padding\":{\"leading\":32,\"trailing\":32},\"" +
        "parent\":\"dock\",\"width\":{\"fraction\":1}},{\"height\":{\"units\":64},\"id\":\"transport\",\"name\":\"Trans" +
        "port\",\"padding\":{\"leading\":56,\"trailing\":56},\"parent\":\"dock\",\"width\":{\"fraction\":1}},{\"arrange" +
        "ment\":\"column\",\"height\":\"content\",\"id\":\"route\",\"name\":\"Output Label\",\"parent\":\"dock\",\"widt" +
        "h\":{\"fraction\":1}},{\"height\":{\"units\":24},\"id\":\"volume\",\"name\":\"Volume\",\"padding\":{\"leading\"" +
        ":32,\"trailing\":32},\"parent\":\"dock\",\"width\":{\"fraction\":1}},{\"fillBetween\":{\"above\":\"header\",\"" +
        "below\":\"dock\"},\"id\":\"paneArea\",\"name\":\"Lyrics / Queue\",\"reference\":\"safeArea\"},{\"height\":{\"u" +
        "nits\":44},\"id\":\"bottomRow\",\"name\":\"Lyrics, Output and Queue\",\"padding\":{\"leading\":0,\"trailing\":" +
        "0},\"parent\":\"dock\",\"width\":{\"fraction\":1}}],\"header\":[{\"appearance\":{\"backgroundBlur\":0,\"blendM" +
        "ode\":\"normal\",\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"opacity\":1,\"tint\":{\"alp" +
        "ha\":1,\"brightness\":1,\"hue\":0,\"saturation\":0}},\"kind\":\"songTitle\",\"layout\":{\"container\":\"header" +
        "\",\"size\":{\"height\":\"content\"}},\"locked\":false,\"masksLayerBelow\":false,\"name\":\"Song Title\",\"sta" +
        "tes\":{\"artwork\":{\"visible\":false}},\"text\":{\"alignment\":\"leading\",\"allowsOverflow\":false,\"content" +
        "\":\"Song Title\",\"design\":\"default\",\"fontSize\":18,\"letterSpacing\":0,\"uppercase\":false,\"weight\":\"" +
        "bold\"},\"transform\":{\"aspectRatio\":{\"free\":{}},\"height\":0.4,\"rotationDegrees\":0,\"width\":0.47,\"x\"" +
        ":0.51,\"y\":0.32},\"visible\":true},{\"accessibilityLabel\":\"Artist Name\",\"appearance\":{\"backgroundBlur\"" +
        ":0,\"blendMode\":\"normal\",\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"opacity\":0.6,\"" +
        "tint\":{\"alpha\":1,\"brightness\":1,\"hue\":0,\"saturation\":0}},\"hitTarget\":{\"minHeight\":44,\"minWidth\"" +
        ":44},\"kind\":\"artistName\",\"layout\":{\"container\":\"header\",\"size\":{\"height\":\"content\"}},\"locked\"" +
        ":false,\"masksLayerBelow\":false,\"name\":\"Artist Name\",\"states\":{\"artwork\":{\"visible\":false}},\"text\"" +
        ":{\"alignment\":\"leading\",\"allowsOverflow\":false,\"content\":\"Artist Name\",\"design\":\"default\",\"font" +
        "Size\":15,\"letterSpacing\":0,\"uppercase\":false,\"weight\":\"medium\"},\"transform\":{\"aspectRatio\":{\"fre" +
        "e\":{}},\"height\":0.35,\"rotationDegrees\":0,\"width\":0.47,\"x\":0.51,\"y\":0.71},\"visible\":true},{\"acces" +
        "sibilityLabel\":\"Favorite\",\"appearance\":{\"backgroundBlur\":0,\"blendMode\":\"normal\",\"cornerRadius\":{\"" +
        "uniform\":{\"_0\":0}},\"innerShadow\":false,\"opacity\":1,\"tint\":{\"alpha\":1,\"brightness\":1,\"hue\":0,\"s" +
        "aturation\":0}},\"hitTarget\":{\"minHeight\":44,\"minWidth\":44},\"kind\":\"favorite\",\"layout\":{\"container" +
        "\":\"header\"},\"locked\":false,\"masksLayerBelow\":false,\"name\":\"Favorite\",\"states\":{\"artwork\":{\"vis" +
        "ible\":false}},\"symbolOverride\":\"favorite.star\",\"transform\":{\"aspectRatio\":{\"free\":{}},\"height\":0." +
        "34,\"rotationDegrees\":0,\"width\":0.067,\"x\":0.84,\"y\":0.5},\"visible\":true},{\"accessibilityLabel\":\"Men" +
        "u\",\"appearance\":{\"backgroundBlur\":0,\"blendMode\":\"normal\",\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"" +
        "innerShadow\":false,\"opacity\":1,\"tint\":{\"alpha\":1,\"brightness\":1,\"hue\":0,\"saturation\":0}},\"hitTar" +
        "get\":{\"minHeight\":44,\"minWidth\":44},\"kind\":\"threeDotMenu\",\"layout\":{\"container\":\"header\"},\"loc" +
        "ked\":false,\"masksLayerBelow\":false,\"name\":\"Menu\",\"states\":{\"artwork\":{\"visible\":false}},\"transfo" +
        "rm\":{\"aspectRatio\":{\"free\":{}},\"height\":0.34,\"rotationDegrees\":0,\"width\":0.067,\"x\":0.965,\"y\":0." +
        "5},\"visible\":true},{\"appearance\":{\"backgroundBlur\":0,\"blendMode\":\"normal\",\"cornerRadius\":{\"unifor" +
        "m\":{\"_0\":8}},\"innerShadow\":false,\"opacity\":1,\"tint\":{\"alpha\":1,\"brightness\":1,\"hue\":0,\"saturat" +
        "ion\":0}},\"artwork\":{\"fit\":\"fill\"},\"kind\":\"artwork\",\"layout\":{\"container\":\"header\",\"size\":{\"" +
        "height\":{\"units\":64},\"width\":{\"units\":64}}},\"locked\":false,\"masksLayerBelow\":false,\"name\":\"Artwo" +
        "rk\",\"states\":{\"artwork\":{\"visible\":false}},\"swipeToSkip\":false,\"transform\":{\"aspectRatio\":{\"rati" +
        "o\":{\"h\":1,\"w\":1}},\"height\":0.76,\"rotationDegrees\":0,\"width\":0.19,\"x\":0.095,\"y\":0.5},\"visible\"" +
        ":true}],\"lyrics\":{\"activeGlow\":0,\"activeScale\":1.08,\"easing\":\"spring\",\"fillSoftness\":0.65,\"lineTr" +
        "ansition\":\"crossfade\",\"lookAheadMs\":0,\"pastBlur\":0,\"pastDim\":0.45,\"style\":\"apple\",\"sungOpacity\"" +
        ":1,\"translation\":\"below\",\"unsungOpacity\":0.4,\"wordFill\":\"continuousLine\"},\"presentation\":{\"dock\"" +
        ":{\"container\":\"dock\",\"dragDeadzone\":8,\"durationMs\":320,\"easing\":\"easeInOut\",\"hideOnScroll\":true," +
        "\"idleHideMs\":3000,\"releaseHeight\":true},\"initial\":\"artwork\",\"panes\":[{\"clip\":true,\"container\":\"" +
        "paneArea\",\"contents\":[\"lyrics\",\"queue\"],\"id\":\"main\"}],\"states\":[\"artwork\",\"lyrics\",\"queue\"]" +
        ",\"transition\":{\"durationMs\":250,\"easing\":\"easeOut\"}},\"queue\":{\"nowPlayingRow\":\"bars\",\"pane\":{\"" +
        "reorder\":true,\"sections\":true,\"showAll\":true,\"swipeToRemove\":true,\"toolbar\":[\"shuffle\",\"repeat\",\"" +
        "autoplay\",\"automix\"]},\"reorderAnimation\":\"lift\",\"rowStyle\":\"artwork\",\"showAddedBy\":true},\"requir" +
        "edCapabilities\":{\"anchoredContainers\":1,\"artworkSwipePreviews\":1,\"continuousLyricFill\":1,\"heroMediaPol" +
        "icy\":1,\"immersiveArtworkFade\":1,\"inlinePanes\":1,\"interactiveQueuePane\":1,\"presentationStates\":1,\"rec" +
        "edingDock\":1,\"relativeScrubber\":1,\"statefulControls\":1}}";

    private static JSONObject copy(JSONObject o) throws Exception {
        return new JSONObject(o.toString());
    }

    private static String newId(String key) {
        return UUID.nameUUIDFromBytes(("bitchord-letras-" + key).getBytes()).toString().toUpperCase();
    }

    private static JSONObject find(JSONArray layers, String name) throws Exception {
        for (int i = 0; i < layers.length(); i++) {
            JSONObject l = layers.getJSONObject(i);
            if (name.equals(l.optString("name"))) return l;
        }
        return null;
    }

    private static JSONObject tf(double x, double y, double w, double h, boolean square) throws Exception {
        JSONObject t = new JSONObject();
        t.put("x", x);
        t.put("y", y);
        t.put("width", w);
        t.put("height", h);
        t.put("rotationDegrees", 0);
        JSONObject ar = new JSONObject();
        if (square) ar.put("ratio", new JSONObject("{\"w\":1,\"h\":1}"));
        else ar.put("free", new JSONObject());
        t.put("aspectRatio", ar);
        return t;
    }

    /** Copia de la capa `name` puesta dentro de `container` con la posicion dada (relativa al contenedor). */
    private static void add(JSONArray out, JSONArray src, String name, String container, JSONObject transform,
                            JSONObject size) throws Exception {
        JSONObject o = find(src, name);
        if (o == null) return;
        JSONObject c = copy(o);
        c.put("id", newId(name));
        JSONObject layout = new JSONObject();
        layout.put("container", container);
        if (size != null) layout.put("size", size);
        c.put("layout", layout);
        c.put("transform", transform);
        // v0.20.64: sin states: la copia se ve en Artwork, Letra y Cola (un solo juego de controles, como Apple Music V2).
        out.put(c);
    }

    /** v0.20.64: las 17 capas de controles que ahora existen UNA sola vez (la copia del dock). */
    private static final java.util.HashSet<String> DOCK_NAMES = new java.util.HashSet<String>(java.util.Arrays.asList(
        "Progress", "Elapsed", "Remaining", "Quality Badge", "Previous", "Play/Pause", "Next", "Volume min", "Volume",
        "Volume max", "Pill", "Pill divider", "Lyrics", "Connect", "Persona", "Queue", "Output"));

    /** v0.20.33: reordena y ajusta los contenedores del dock para igualar la distribucion de Artwork. */
    private static void fitDock(JSONArray cs) throws Exception {
        JSONObject noSide = new JSONObject("{\"leading\":0,\"trailing\":0}");
        JSONObject route = null;
        for (int i = 0; i < cs.length(); i++) {
            JSONObject c = cs.getJSONObject(i);
            String id = c.optString("id");
            if ("dock".equals(id)) c.put("padding", new JSONObject("{\"bottom\":23,\"top\":8}"));
            else if ("progress".equals(id)) { c.put("height", new JSONObject("{\"units\":60}")); c.put("padding", noSide); }
            else if ("transport".equals(id)) { c.put("height", new JSONObject("{\"units\":81}")); c.put("padding", noSide); }
            else if ("volume".equals(id)) c.put("padding", noSide);
            else if ("bottomRow".equals(id)) c.put("height", new JSONObject("{\"units\":43.29}")); // 44 - 0.71: el borde de arriba queda igual, solo sube el nombre del dispositivo
            else if ("route".equals(id)) {
                // v0.20.35: el x/y de la capa Output no se aplica dentro de "route": se ajusta el contenedor (sube 0.7 dp = 2 px, y 0.7 dp a la derecha mueve el texto 1 px a la izquierda)
                c.put("padding", new JSONObject("{\"bottom\":0.71,\"trailing\":0.7}"));
                route = c;
            }
        }
        if (route == null) return;
        // route al final de la lista (queda debajo de bottomRow)
        JSONArray out = new JSONArray();
        for (int i = 0; i < cs.length(); i++) {
            JSONObject c = cs.getJSONObject(i);
            if (c != route) out.put(c);
        }
        out.put(route);
        while (cs.length() > 0) cs.remove(cs.length() - 1);
        for (int i = 0; i < out.length(); i++) cs.put(out.get(i));
    }

    /**
     * v0.20.39 (SIN COMPILAR / SIN PROBAR). Marca con un id fijo las 5 capas ORIGINALES de Artwork (portada grande,
     * titulo, artista, estrella, tres puntos). Siguen ocultas en Letra/Cola como siempre (se desvanecen) y las copias
     * de la cabecera se quedan; LayerMorph las mueve hacia la cabecera mientras se desvanecen (y al reves).
     */
    private static JSONArray morph(JSONArray in) throws Exception {
        java.util.HashSet<String> done = new java.util.HashSet<String>();
        for (int i = 0; i < in.length(); i++) {
            JSONObject l = in.getJSONObject(i);
            String kind = l.optString("kind");
            if (!LayerMorph.isKind(kind)) continue;
            JSONObject lay = l.optJSONObject("layout");
            boolean free = lay == null || lay.optString("container").isEmpty();
            if (!free) continue; // copias de la cabecera
            if (done.add(kind)) {
                l.put("id", LayerMorph.idFor(kind));
                l.put("name", l.optString("name") + LayerMorph.MARK);
            }
        }
        if (!done.contains("artwork")) throw new IllegalStateException("morph: no hay capa Artwork grande");
        return in;
    }

    static JSONObject apply(JSONObject d) throws Exception {
        JSONObject frag = new JSONObject(FRAG);
        JSONArray src = d.getJSONArray("layers");
        JSONArray out = new JSONArray();

        // 1) Capas originales: igual que antes, pero ocultas en Letra y Cola.
        String hide = "{\"lyrics\":{\"visible\":false},\"queue\":{\"visible\":false}}";
        for (int i = 0; i < src.length(); i++) {
            JSONObject l = src.getJSONObject(i);
            // v0.20.64: los 17 controles originales no se agregan (su copia del dock los reemplaza en las 3 pestanas).
            if (DOCK_NAMES.contains(l.optString("name"))) continue;
            l.put("states", new JSONObject(hide));
            out.put(l);
        }

        // 2) Cabecera (copiada de Apple Music V2). Estrella y tres puntos con los iconos de Bitchord.
        JSONArray header = frag.getJSONArray("header");
        for (int i = 0; i < header.length(); i++) {
            JSONObject l = header.getJSONObject(i);
            String kind = l.optString("kind");
            l.put("id", newId("header-" + kind));
            if ("favorite".equals(kind)) l.put("symbolOverride", "favorite.star");
            if ("threeDotMenu".equals(kind)) l.put("symbolOverride", "menu.dots");
            // Tocar la portada chica vuelve a Artwork (accion "closePane" de Eclipse, la misma que usa el gesto de volver).
            if ("artwork".equals(kind)) l.put("functionOverride", "closePane");
            out.put(l);
        }
        // v0.20.33: capa transparente encima de la portada chica (misma caja) que vuelve a Artwork al tocarla.
        // Respaldo por si la capa de portada no atiende el toque por si sola.
        JSONObject tap = new JSONObject();
        tap.put("id", newId("header-cover-tap"));
        tap.put("kind", "shape");
        tap.put("name", "Cover tap");
        tap.put("transform", tf(0.095, 0.5, 0.19, 0.76, true));
        tap.put("appearance", new JSONObject("{\"backgroundBlur\":0,\"blendMode\":\"normal\",\"cornerRadius\":{\"uniform\":{\"_0\":8}},"
            + "\"innerShadow\":false,\"opacity\":0.01,\"tint\":{\"alpha\":1,\"brightness\":1,\"hue\":0,\"saturation\":0}}"));
        tap.put("shape", new JSONObject("{\"type\":\"roundedRect\"}"));
        tap.put("layout", new JSONObject("{\"container\":\"header\",\"size\":{\"height\":{\"units\":64},\"width\":{\"units\":64}}}"));
        tap.put("states", new JSONObject("{\"artwork\":{\"visible\":false}}"));
        tap.put("hitTarget", new JSONObject("{\"minHeight\":64,\"minWidth\":64}"));
        tap.put("functionOverride", "closePane");
        tap.put("visible", true);
        tap.put("locked", false);
        tap.put("masksLayerBelow", false);
        out.put(tap);

        // 3) Dock: lo que se esconde a los 3 s.
        // v0.20.33: mismas posiciones y tamanos que en Artwork (medidas calibradas con capturas: 1080x2400 px, ~2.8 px/dp).
        JSONObject hContent = new JSONObject("{\"height\":\"content\"}");
        JSONObject h24 = new JSONObject("{\"height\":{\"units\":24}}");
        JSONObject routeSize = new JSONObject("{\"height\":\"content\",\"width\":{\"fraction\":1}}");
        add(out, src, "Progress", "progress", tf(0.5, 0.23, 0.845, 0.4, false), h24);
        add(out, src, "Elapsed", "progress", tf(0.149, 0.52, 0.14, 0.3, false), hContent);
        add(out, src, "Remaining", "progress", tf(0.851, 0.52, 0.14, 0.3, false), hContent);
        add(out, src, "Quality Badge", "progress", tf(0.5, 0.52, 0.4, 0.4, false), null);
        add(out, src, "Previous", "transport", tf(0.202, 0.40, 0.163, 0, true), null);
        add(out, src, "Play/Pause", "transport", tf(0.5, 0.40, 0.1197, 0, true), null);
        add(out, src, "Next", "transport", tf(0.8, 0.40, 0.163, 0, true), null);
        add(out, src, "Volume min", "volume", tf(0.102, 0.405, 0.05, 0, true), null);
        add(out, src, "Volume", "volume", tf(0.5, 0.405, 0.689, 0.82, false), null);
        add(out, src, "Volume max", "volume", tf(0.896, 0.405, 0.05, 0, true), null);

        // 4) Fila de iconos (pastilla + iconos): dentro del dock, se esconde con el resto (como Apple Music V2).
        add(out, src, "Pill", "bottomRow", tf(0.5, 0.4412, 0.337, 1.0164, false), null);
        add(out, src, "Pill divider", "bottomRow", tf(0.5, 0.4412, 0.0016, 0.8638, false), null);
        add(out, src, "Lyrics", "bottomRow", tf(0.164, 0.4412, 0.09, 0, true), null);
        add(out, src, "Connect", "bottomRow", tf(0.417, 0.4412, 0.0766, 0, true), null);
        add(out, src, "Persona", "bottomRow", tf(0.583, 0.4412, 0.068, 0, true), null);
        add(out, src, "Queue", "bottomRow", tf(0.835, 0.4412, 0.0804, 0, true), null);

        // 5) Nombre del dispositivo: como en Artwork, ABAJO de la pastilla (ultimo hijo del dock).
        add(out, src, "Output", "route", tf(0.495, 0.445, 1, 1, false), routeSize);

        // 6) Contenedores del dock: mismo orden que en Artwork y alturas/margenes para que los centros coincidan.
        fitDock(frag.getJSONArray("containers"));

        // v0.20.37: la portada grande se encoge hasta el lugar de la portada chica (parche aparte, apagado por defecto).
        if (BitchordTemplate.morphMode) out = morph(out);

        d.put("layers", out);

        // 5) Zonas, presentacion (dock que se esconde, panes de Letra y Cola), letra y cola.
        JSONObject layout = new JSONObject();
        layout.put("containers", frag.getJSONArray("containers"));
        d.put("layout", layout);
        d.put("presentation", frag.getJSONObject("presentation"));
        d.put("lyrics", frag.getJSONObject("lyrics"));
        d.put("queue", frag.getJSONObject("queue"));

        JSONObject req = d.optJSONObject("requiredCapabilities");
        if (req == null) req = new JSONObject();
        JSONObject fr = frag.getJSONObject("requiredCapabilities");
        java.util.Iterator<String> it = fr.keys();
        while (it.hasNext()) {
            String k = it.next();
            req.put(k, fr.get(k));
        }
        d.put("requiredCapabilities", req);
        return d;
    }
}
