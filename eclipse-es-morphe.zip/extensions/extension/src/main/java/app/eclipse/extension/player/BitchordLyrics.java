package app.eclipse.extension.player;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Ajustes sobre el diseno Bitchord (BitchordDesign, que ya viene completo con cabecera, dock, panes de Letra y Cola).
 * Solo marca las capas que usa el parche "Bitchord: la portada chica crece" (LayerMorph).
 */
final class BitchordLyrics {
    private BitchordLyrics() {}

    /**
     * v0.20.39 (SIN COMPILAR / SIN PROBAR). Marca con un id fijo las 5 capas ORIGINALES de Artwork (portada grande,
     * titulo, artista, estrella, tres puntos). Siguen ocultas en Letra/Cola como siempre (se desvanecen) y las copias
     * de la cabecera se quedan; LayerMorph las mueve hacia la cabecera mientras se desvanecen (y al reves).
     */
    private static JSONArray morph(JSONArray in) throws Exception {
        java.util.HashSet<String> done = new java.util.HashSet<String>();
        for (int i = 0; i < in.length(); i++) {
            JSONObject l = in.getJSONObject(i);
            String kind = l.optString("kind");
            if (!LayerMorph.isKind(kind)) continue;
            JSONObject lay = l.optJSONObject("layout");
            boolean free = lay == null || lay.optString("container").isEmpty();
            if (!free) continue; // copias de la cabecera
            if (done.add(kind)) {
                l.put("id", LayerMorph.idFor(kind));
                l.put("name", l.optString("name") + LayerMorph.MARK);
            }
        }
        if (!done.contains("artwork")) throw new IllegalStateException("morph: no hay capa Artwork grande");
        return in;
    }

    /** Si el parche de la portada que crece esta activo, marca las 5 capas libres; si no, deja el diseno tal cual. */
    static JSONObject applyFinished(JSONObject d) throws Exception {
        if (BitchordTemplate.morphMode) d.put("layers", morph(d.getJSONArray("layers")));
        return d;
    }
}
