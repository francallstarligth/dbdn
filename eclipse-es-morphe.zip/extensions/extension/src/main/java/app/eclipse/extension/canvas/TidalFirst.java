package app.eclipse.extension.canvas;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;

/**
 * v1.51.0: da prioridad real al Canvas de Tidal.
 *
 * Eclipse (ww0.m -> k6a.b) averigua el album de Tidal y baja la URL del videoCover. Si otra tarea ya esta
 * descargando ese mismo album (conjunto k6a.d), k6a.b vuelve de inmediato sin esperar y ww0.m no encuentra
 * nada todavia: Eclipse declara "sin portada animada" y el gancho de Canvas rellenaba con Spotify. A la segunda vez,
 * ya descargado, salia el de Tidal.
 *
 * Aqui, antes de pasar a comunidad/Spotify, se espera (con tope) a que Tidal termine, mirando los mismos datos
 * que ww0.m (k6a.e, ks.g). Si Eclipse ya marco el album como "sin videoCover" (k6a.c) no se espera nada; v1.55.0: solo se espera mientras el
 * album siga en vuelo (k6a.d), con ids Integer.
 * Apple Music (0.6.57): la clase es ny (ny.n); la cancion se resuelve con ny.a(Song) y la espera de pista usa pva.c.
 * Por reflexion con los nombres de 0.6.70 (v0.20.250: p7a=tra, ht=rt, mz=e00, ux0=rz0, pva=rhb; en los comentarios de arriba siguen los de 0.6.57: k6a, ks, ny, ww0, pva). En 0.6.70 tra tiene un conjunto nuevo `b` (albumes ya listos); c/d/e siguen igual; si algo falla devuelve null y todo sigue como antes. Bloqueante.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
final class TidalFirst {
    private static final String TAG = "TidalFirst";
    private static final long POLL_MS = 120L;

    private TidalFirst() {}

    /** true si la cancion trae datos de Tidal (id de pista, de album o ISRC): vale la pena esperar a Tidal. */
    static boolean hasTidal(Object song) {
        try {
            if (song == null) return false;
            if (song.getClass().getMethod("getTidalAlbumId").invoke(song) != null) return true;
            if (song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song) != null) return true;
            Object isrc = song.getClass().getMethod("getIsrc").invoke(song);
            return isrc instanceof String && !((String) isrc).isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Marca interna: "todavia esta bajando, hay que seguir esperando". */
    private static final String WAIT = "\u0000wait";
    /** Tope de espera mientras un ALBUM se esta descargando (Tidal o Apple), contado desde que lo vimos por primera vez. */
    private static final long ALBUM_WAIT_MS = 5000L; // v0.20.261: antes 8000
    /** Tope mientras Apple todavia busca el album de la cancion (ese aviso de Eclipse a veces queda pegado, por eso es corto). */
    private static final long TRACK_WAIT_MS = 2500L;
    /** v0.20.70: tope mientras el album de Tidal de una cancion con ISRC todavia no aparece. */
    private static final long ISRC_WAIT_MS = 2500L; // v0.20.206: antes 3000; igual que TRACK_WAIT_MS de Apple
    private static final java.util.HashMap<String, Long> SEEN = new java.util.HashMap<String, Long>();

    /** true mientras no pase el tope desde la primera vez que se vio esta clave (evita esperar por avisos viejos que quedaron pegados). */
    private static boolean fresh(String id, long capMs) {
        long now = System.currentTimeMillis();
        synchronized (SEEN) {
            if (SEEN.size() > 400) SEEN.clear();
            Long t = SEEN.get(id);
            if (t == null) { SEEN.put(id, now); return true; }
            return now - t < capMs;
        }
    }

    /**
     * v0.20.57: espera a Tidal Y a Apple Music antes de dejar pasar a comunidad/Spotify.
     * @return URL/URI del video de Tidal o de Apple, o null si no hay (o no llego a tiempo).
     */
    static String await(Object song, long maxMs) {
        try {
            if (song == null) return null;
            long end = System.currentTimeMillis() + Math.max(maxMs, ALBUM_WAIT_MS + 500L);
            while (true) {
                String t = null, a = null;
                try { t = tidalStep(song); } catch (Throwable e) { Log.w(TAG, "tidal fallo: " + e); }
                if (t != null && t != WAIT) return t;
                try { a = appleStep(song); } catch (Throwable e) { Log.w(TAG, "apple fallo: " + e); }
                if (a != null && a != WAIT) return a;
                if (t != WAIT && a != WAIT) return null; // ninguno esta trabajando: nada que esperar
                if (System.currentTimeMillis() >= end) return null;
                try { Thread.sleep(POLL_MS); } catch (InterruptedException ie) { return null; }
            }
        } catch (Throwable t) {
            Log.w(TAG, "await fallo: " + t);
            return null;
        }
    }

    /** Tidal: URL si ya esta, WAIT si Eclipse la esta bajando, null si no hay nada que esperar. */
    private static String tidalStep(Object song) throws Throwable {
        if (!hasTidal(song)) return null;
        Class k6a = Class.forName("tra");
        Class nr = Class.forName("rt");
        Field fl = k6a.getDeclaredField("n"); fl.setAccessible(true);
        Object c = fl.get(null);
        Field fi = nr.getDeclaredField("k"); fi.setAccessible(true);
        Object n = fi.get(null);
        if (c == null || n == null) return null;
        Field trackToAlbum = field(k6a, "e");
        Field noCover = field(k6a, "c");
        Field inFlight = field(k6a, "d");
        Field nrUrls = field(nr, "g");
        Method nrFile = nr.getDeclaredMethod("g", String.class); nrFile.setAccessible(true);
        Method nrKey = nr.getDeclaredMethod("j", String.class); nrKey.setAccessible(true);

        Object album = song.getClass().getMethod("getTidalAlbumId").invoke(song);
        Object trackObj = song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song);
        if (album == null && trackObj != null) album = ((Map) trackToAlbum.get(c)).get(trackObj);
        // v0.20.57: canciones de la biblioteca (solo traen ISRC): Eclipse ya anoto su album en IsrcAlbum.
        Object isrcObj = null;
        if (album == null) {
            isrcObj = song.getClass().getMethod("getIsrc").invoke(song);
            if (isrcObj instanceof String) album = app.eclipse.extension.tidal.IsrcAlbum.get((String) isrcObj);
        }
        if (album == null) {
            // v0.20.70: la cancion trae ISRC (biblioteca) pero Eclipse todavia no anota su album de Tidal: se espera un poco
            // (solo la primera vez que se ve esa cancion) en vez de dejar pasar a Spotify de inmediato.
            if (isrcObj instanceof String && !((String) isrcObj).isEmpty() && fresh("i:" + isrcObj, ISRC_WAIT_MS)) return WAIT;
            return null;
        }
        String key = "tidal_album:" + album;

        String url = null;
        Object f = nrFile.invoke(n, key);
        if (f instanceof File) url = ((File) f).toURI().toString();
        if (url == null || url.isEmpty()) {
            Object u = ((Map) nrUrls.get(n)).get(nrKey.invoke(null, key));
            if (u instanceof String) url = (String) u;
        }
        if (url != null && !url.isEmpty()) return url;

        if (has((Set) noCover.get(c), album, key)) return null;      // Eclipse ya confirmo: ese album no tiene video
        if (!has((Set) inFlight.get(c), album, key)) return null;    // nadie lo esta bajando
        return fresh("t:" + album, ALBUM_WAIT_MS) ? WAIT : null;
    }

    private static final String ALBUM_PREFIX = "applemusic_album:";

    /** Apple Music (0.6.55): URL si ya esta, WAIT si Eclipse la esta buscando/bajando, null si no hay nada que esperar. */
    private static String appleStep(Object song) throws Throwable {
        Class fy = Class.forName("e00");
        Object g = field(fy, "n").get(null);          // ny.n = instancia unica
        if (g == null) return null;
        Class songC = song.getClass();

        // ny.a(Song): "applemusic_album:<id>" si ya se conoce el album de la cancion (cache de pistas incluida), si no null.
        Method keyOf = fy.getDeclaredMethod("a", songC); keyOf.setAccessible(true);
        Object keyObj = keyOf.invoke(g, song);
        if (keyObj == null) {
            // Espera de pista: Eclipse todavia esta buscando el album de esta cancion (pva.c = busquedas de pista en vuelo).
            try {
                Object lazy = field(fy, "k").get(g);                       // ny.k = lazy (xw9) de pva
                Object wra = lazy.getClass().getMethod("getValue").invoke(lazy);
                Method trackKey = wra.getClass().getDeclaredMethod("c", songC); trackKey.setAccessible(true);
                Object sra = trackKey.invoke(wra, song);                   // clave de pista (data class)
                Map running = (Map) field(wra.getClass(), "c").get(wra);   // pva.c = CHM<sra, Deferred>
                if (sra != null && running != null && running.containsKey(sra)
                        && fresh("at:" + sra, TRACK_WAIT_MS)) return WAIT;
            } catch (Throwable t) {
                Log.w(TAG, "espera de pista Apple fallo: " + t);
            }
            return null;
        }
        String key = keyObj.toString();
        if (!key.startsWith(ALBUM_PREFIX)) return null;
        String albumId = key.substring(ALBUM_PREFIX.length());
        if (albumId.isEmpty()) return null;

        // ny.c(String): ky(a = url cuadrada, b = url 3x4), leidas de la cache de disco o del mapa de urls.
        Method urlsOf = fy.getDeclaredMethod("c", String.class); urlsOf.setAccessible(true);
        Object cy = urlsOf.invoke(g, key);
        if (cy != null) {
            Object sq = field(cy.getClass(), "a").get(cy);
            Object tall = field(cy.getClass(), "b").get(cy);
            String u = sq instanceof String && !((String) sq).isEmpty() ? (String) sq : (tall instanceof String ? (String) tall : null);
            if (u != null && !u.isEmpty()) return u;
        }
        String suffix = "|" + albumId;
        // ny.d: clave "<sra.g>|<album>" -> vencimiento (Long). Con vencimiento futuro = confirmado sin video animado.
        Map noAnim = (Map) field(fy, "d").get(g);
        if (noAnim != null) {
            long now = System.currentTimeMillis();
            for (Object e : noAnim.entrySet()) {
                Map.Entry en = (Map.Entry) e;
                Object k = en.getKey();
                if (k instanceof String && (((String) k).endsWith(suffix) || k.equals(albumId))
                        && en.getValue() instanceof Long && ((Long) en.getValue()) > now) return null;
            }
        }
        // ny.c: claves en vuelo (album que se esta bajando ahora).
        Set inFlight = (Set) field(fy, "c").get(g);
        if (inFlight != null) {
            for (Object k : inFlight.toArray()) {
                if (k instanceof String && (((String) k).endsWith(suffix) || k.equals(albumId)))
                    return fresh("a:" + albumId, ALBUM_WAIT_MS) ? WAIT : null;
            }
        }
        return null;
    }

    /** Eclipse guarda el id del album como Integer; por si acaso tambien se mira la clave de texto. */
    private static boolean has(Set set, Object album, String key) {
        if (set == null) return false;
        try {
            synchronized (set) { return set.contains(album) || set.contains(key); }
        } catch (Throwable t) {
            return false;
        }
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }
}
