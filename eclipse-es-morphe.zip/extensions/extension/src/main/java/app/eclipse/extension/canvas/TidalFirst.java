package app.eclipse.extension.canvas;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;

/**
 * v1.51.0: da prioridad real al Canvas de Tidal.
 *
 * Eclipse (qf2.a -> c19.a) averigua el album de Tidal y baja la URL del videoCover. Si otra tarea ya esta
 * descargando ese mismo album (conjunto c19.d), c19.a vuelve de inmediato sin esperar y qf2.e no encuentra
 * nada todavia: Eclipse declara "sin portada animada" y el gancho de Canvas rellenaba con Spotify. A la segunda vez,
 * ya descargado, salia el de Tidal.
 *
 * Aqui, antes de pasar a comunidad/Spotify, se espera (con tope) a que Tidal termine, mirando los mismos datos
 * que qf2.e (c19.e, nr.e). Si Eclipse ya marco el album como "sin videoCover" (c19.c) no se espera nada.
 * Por reflexion con los nombres de 0.6.47; si algo falla devuelve null y todo sigue como antes. Bloqueante.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
final class TidalFirst {
    private static final String TAG = "TidalFirst";
    private static final long POLL_MS = 120L;

    private TidalFirst() {}

    /** true si la cancion trae datos de Tidal (id de pista, de album o ISRC): vale la pena esperar a Tidal. */
    static boolean hasTidal(Object song) {
        try {
            if (song == null) return false;
            if (song.getClass().getMethod("getTidalAlbumId").invoke(song) != null) return true;
            if (song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song) != null) return true;
            Object isrc = song.getClass().getMethod("getIsrc").invoke(song);
            return isrc instanceof String && !((String) isrc).isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    /** @return URL/URI del video de Tidal, o null si no hay (o no llego a tiempo). */
    static String await(Object song, long maxMs) {
        try {
            if (!hasTidal(song)) return null;
            Class c19 = Class.forName("c19");
            Class nr = Class.forName("nr");
            Field fl = c19.getDeclaredField("l"); fl.setAccessible(true);
            Object c = fl.get(null);
            Field fi = nr.getDeclaredField("i"); fi.setAccessible(true);
            Object n = fi.get(null);
            if (c == null || n == null) return null;
            Field trackToAlbum = field(c19, "e");
            Field noCover = field(c19, "c");
            Field nrUrls = field(nr, "e");
            Method nrFile = nr.getDeclaredMethod("e", String.class); nrFile.setAccessible(true);
            Method nrKey = nr.getDeclaredMethod("h", String.class); nrKey.setAccessible(true);

            Object albumObj = song.getClass().getMethod("getTidalAlbumId").invoke(song);
            Object trackObj = song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song);

            long end = System.currentTimeMillis() + maxMs;
            while (true) {
                Object album = albumObj;
                if (album == null && trackObj != null) {
                    album = ((Map) trackToAlbum.get(c)).get(trackObj);
                }
                if (album instanceof Integer) {
                    String key = "tidal_album:" + album;
                    if (((Set) noCover.get(c)).contains(key)) return null; // Eclipse ya confirmo: ese album no tiene video
                    String url = null;
                    Object f = nrFile.invoke(n, key);
                    if (f instanceof File) url = ((File) f).toURI().toString();
                    if (url == null || url.isEmpty()) {
                        Object u = ((Map) nrUrls.get(n)).get(nrKey.invoke(null, key));
                        if (u instanceof String) url = (String) u;
                    }
                    if (url != null && !url.isEmpty()) return url;
                }
                if (System.currentTimeMillis() >= end) return null;
                try { Thread.sleep(POLL_MS); } catch (InterruptedException ie) { return null; }
            }
        } catch (Throwable t) {
            Log.w(TAG, "await fallo: " + t);
            return null;
        }
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }
}
