package app.eclipse.extension.canvas;

import android.util.Log;

import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;

/**
 * v1.51.0: da prioridad real al Canvas de Tidal.
 *
 * Eclipse (qf2.a -> c19.a) averigua el album de Tidal y baja la URL del videoCover. Si otra tarea ya esta
 * descargando ese mismo album (conjunto c19.d), c19.a vuelve de inmediato sin esperar y qf2.e no encuentra
 * nada todavia: Eclipse declara "sin portada animada" y el gancho de Canvas rellenaba con Spotify. A la segunda vez,
 * ya descargado, salia el de Tidal.
 *
 * Aqui, antes de pasar a comunidad/Spotify, se espera (con tope) a que Tidal termine, mirando los mismos datos
 * que qf2.e (c19.e, nr.e). Si Eclipse ya marco el album como "sin videoCover" (c19.c) no se espera nada; v1.55.0: solo se espera mientras el
 * album siga en vuelo (c19.d), con ids Integer.
 * Por reflexion con los nombres de 0.6.47; si algo falla devuelve null y todo sigue como antes. Bloqueante.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
final class TidalFirst {
    private static final String TAG = "TidalFirst";
    private static final long POLL_MS = 120L;

    private TidalFirst() {}

    /** true si la cancion trae datos de Tidal (id de pista, de album o ISRC): vale la pena esperar a Tidal. */
    static boolean hasTidal(Object song) {
        try {
            if (song == null) return false;
            if (song.getClass().getMethod("getTidalAlbumId").invoke(song) != null) return true;
            if (song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song) != null) return true;
            Object isrc = song.getClass().getMethod("getIsrc").invoke(song);
            return isrc instanceof String && !((String) isrc).isEmpty();
        } catch (Throwable t) {
            return false;
        }
    }

    /** Marca interna: "todavia esta bajando, hay que seguir esperando". */
    private static final String WAIT = "\u0000wait";
    /** Tope de espera mientras un ALBUM se esta descargando (Tidal o Apple), contado desde que lo vimos por primera vez. */
    private static final long ALBUM_WAIT_MS = 8000L;
    /** Tope mientras Apple todavia busca el album de la cancion (ese aviso de Eclipse a veces queda pegado, por eso es corto). */
    private static final long TRACK_WAIT_MS = 2500L;
    private static final java.util.HashMap<String, Long> SEEN = new java.util.HashMap<String, Long>();

    /** true mientras no pase el tope desde la primera vez que se vio esta clave (evita esperar por avisos viejos que quedaron pegados). */
    private static boolean fresh(String id, long capMs) {
        long now = System.currentTimeMillis();
        synchronized (SEEN) {
            if (SEEN.size() > 400) SEEN.clear();
            Long t = SEEN.get(id);
            if (t == null) { SEEN.put(id, now); return true; }
            return now - t < capMs;
        }
    }

    /**
     * v0.20.57: espera a Tidal Y a Apple Music antes de dejar pasar a comunidad/Spotify.
     * @return URL/URI del video de Tidal o de Apple, o null si no hay (o no llego a tiempo).
     */
    static String await(Object song, long maxMs) {
        try {
            if (song == null) return null;
            long end = System.currentTimeMillis() + Math.max(maxMs, ALBUM_WAIT_MS + 500L);
            while (true) {
                String t = null, a = null;
                try { t = tidalStep(song); } catch (Throwable e) { Log.w(TAG, "tidal fallo: " + e); }
                if (t != null && t != WAIT) return t;
                try { a = appleStep(song); } catch (Throwable e) { Log.w(TAG, "apple fallo: " + e); }
                if (a != null && a != WAIT) return a;
                if (t != WAIT && a != WAIT) return null; // ninguno esta trabajando: nada que esperar
                if (System.currentTimeMillis() >= end) return null;
                try { Thread.sleep(POLL_MS); } catch (InterruptedException ie) { return null; }
            }
        } catch (Throwable t) {
            Log.w(TAG, "await fallo: " + t);
            return null;
        }
    }

    /** Tidal: URL si ya esta, WAIT si Eclipse la esta bajando, null si no hay nada que esperar. */
    private static String tidalStep(Object song) throws Throwable {
        if (!hasTidal(song)) return null;
        Class c19 = Class.forName("c19");
        Class nr = Class.forName("nr");
        Field fl = c19.getDeclaredField("l"); fl.setAccessible(true);
        Object c = fl.get(null);
        Field fi = nr.getDeclaredField("i"); fi.setAccessible(true);
        Object n = fi.get(null);
        if (c == null || n == null) return null;
        Field trackToAlbum = field(c19, "e");
        Field noCover = field(c19, "c");
        Field inFlight = field(c19, "d");
        Field nrUrls = field(nr, "e");
        Method nrFile = nr.getDeclaredMethod("e", String.class); nrFile.setAccessible(true);
        Method nrKey = nr.getDeclaredMethod("h", String.class); nrKey.setAccessible(true);

        Object album = song.getClass().getMethod("getTidalAlbumId").invoke(song);
        Object trackObj = song.getClass().getMethod("getEffectiveTidalTrackId").invoke(song);
        if (album == null && trackObj != null) album = ((Map) trackToAlbum.get(c)).get(trackObj);
        // v0.20.57: canciones de la biblioteca (solo traen ISRC): Eclipse ya anoto su album en IsrcAlbum.
        if (album == null) {
            Object isrc = song.getClass().getMethod("getIsrc").invoke(song);
            if (isrc instanceof String) album = app.eclipse.extension.tidal.IsrcAlbum.get((String) isrc);
        }
        if (album == null) return null;
        String key = "tidal_album:" + album;

        String url = null;
        Object f = nrFile.invoke(n, key);
        if (f instanceof File) url = ((File) f).toURI().toString();
        if (url == null || url.isEmpty()) {
            Object u = ((Map) nrUrls.get(n)).get(nrKey.invoke(null, key));
            if (u instanceof String) url = (String) u;
        }
        if (url != null && !url.isEmpty()) return url;

        if (has((Set) noCover.get(c), album, key)) return null;      // Eclipse ya confirmo: ese album no tiene video
        if (!has((Set) inFlight.get(c), album, key)) return null;    // nadie lo esta bajando
        return fresh("t:" + album, ALBUM_WAIT_MS) ? WAIT : null;
    }

    /** Apple Music: URL si ya esta, WAIT si Eclipse la esta buscando/bajando, null si no hay nada que esperar. */
    private static String appleStep(Object song) throws Throwable {
        Class ew = Class.forName("ew");
        Field fm = ew.getDeclaredField("m"); fm.setAccessible(true);
        Object e = fm.get(null);
        if (e == null) return null;
        Map urls = (Map) field(ew, "b").get(e);      // "applemusic_album:<id>" -> urls (cw)
        Set noAnim = (Set) field(ew, "c").get(e);    // albumes confirmados sin portada animada
        Set inFlight = (Set) field(ew, "d").get(e);  // albumes que se estan bajando
        Map trackToAlbum = (Map) field(ew, "e").get(e);
        Set searching = (Set) field(ew, "f").get(e); // canciones cuyo album se esta buscando

        Object album = song.getClass().getMethod("getAppleMusicAlbumId").invoke(song);
        Object track = song.getClass().getMethod("getEffectiveAppleMusicTrackId").invoke(song);
        if (track == null) track = song.getClass().getMethod("getId").invoke(song);
        if ((album == null || album.toString().isEmpty()) && track != null) album = trackToAlbum.get(track);
        if (album == null || album.toString().isEmpty()) {
            if (track != null && has(searching, track, String.valueOf(track)) && fresh("at:" + track, TRACK_WAIT_MS)) return WAIT;
            return null;
        }
        String key = "applemusic_album:" + album;
        Object cw = urls.get(key);
        if (cw != null) {
            Object sq = field(cw.getClass(), "a").get(cw);
            Object tall = field(cw.getClass(), "b").get(cw);
            String u = sq instanceof String && !((String) sq).isEmpty() ? (String) sq : (tall instanceof String ? (String) tall : null);
            if (u != null && !u.isEmpty()) return u;
        }
        if (has(noAnim, album, key)) return null;
        if (!has(inFlight, album, key)) return null;
        return fresh("a:" + album, ALBUM_WAIT_MS) ? WAIT : null;
    }

    /** Eclipse guarda el id del album como Integer; por si acaso tambien se mira la clave de texto. */
    private static boolean has(Set set, Object album, String key) {
        if (set == null) return false;
        try {
            synchronized (set) { return set.contains(album) || set.contains(key); }
        } catch (Throwable t) {
            return false;
        }
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }
}
