package app.eclipse.extension.umbra;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONObject;

/**
 * v0.20.390 (diagnostico): copia al portapapeles la respuesta CRUDA del servidor cuando Umbra / "AI Playlist" arma una
 * playlist (personal, provider, model, plan, tracks con su "strategy"). No muestra nada en pantalla. Si algo falla no hace nada.
 */
public final class UmbraDiag {
    private static final String TAG = "UmbraDiag";

    private UmbraDiag() {}

    /** Se llama al inicio de Lcc4.f(JSONObject) con el JSON de la playlist tal como llego. */
    public static void copiar(Object o) {
        try {
            if (!(o instanceof JSONObject)) return;
            final String texto = "UMBRA PLAYLIST (respuesta del servidor)\n" + ((JSONObject) o).toString(2);
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                        if (!(app instanceof Context)) return;
                        ClipboardManager cm = (ClipboardManager) ((Context) app).getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm == null) return;
                        cm.setPrimaryClip(ClipData.newPlainText("Umbra playlist", texto));
                    } catch (Throwable t) {
                        Log.w(TAG, "clip", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "copiar", t);
        }
    }
}
