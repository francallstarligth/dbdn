package app.eclipse.extension.umbra;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/**
 * v0.20.329 (Eclipse 0.6.75, SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL): chat de Umbra tambien en la skin Native.
 * La v0.20.329 agrega hideChrome: en la pagina "Umbra Chat" se esconden el mini player y la barra de abajo.
 *
 * Nombres de la 0.6.75 (verificados en el dex): navegador de Native = xs6 (j(xs6, gn6) empuja, h() quita la ultima
 * pagina), pagina por nombre = dn6(String) (se pinta en xv6.i(I, eu1, String)), tarjeta ancha de Umbra de Eclipse =
 * fy3.e(dk3 onClick, eu1, I), chat de Eclipse = gcb.o(dk3 atras, Z, tk3, tk3, eu1, I changed, I default),
 * LazyListScope.item = h15.y0(h15, String key, uk3 content, I mascara) (estatico), lambda sin argumentos = dk3.a(),
 * lambda de contenido de item = uk3.f(scope, composer, int).
 *
 * Todo por reflexion: si algo no existe, no hace nada (Inicio queda como siempre) y nunca lanza.
 */
public final class UmbraChatNative {
    private static final String PAGE = "Umbra Chat";
    private static final String KEY = "umbra_chat_card";

    /** El navegador de Native (xs6) visto la ultima vez que se compuso el Inicio. */
    private static volatile Object nav;
    private static Object cacheNav;
    private static Object cacheContent;
    private static Object cacheClick;
    private static Object cacheBack;

    private UmbraChatNative() {}

    /**
     * Gancho en Lkc.invoke (lista de Inicio de Native), justo despues del item "recently-played".
     * @param scope el LazyListScope (h15)
     * @param host  la lambda Lkc (this), que guarda el xs6 en uno de sus campos
     */
    public static void addCard(Object scope, Object host) {
        try {
            if (scope == null || host == null) return;
            Object n = findFieldOfType(host, "xs6");
            if (n == null) return;
            nav = n;
            ClassLoader cl = host.getClass().getClassLoader();
            Object content = contentFor(cl, n);
            Class<?> h15 = cl.loadClass("h15");
            Class<?> uk3 = cl.loadClass("uk3");
            Method y0 = h15.getDeclaredMethod("y0", h15, String.class, uk3, int.class);
            y0.setAccessible(true);
            y0.invoke(null, scope, KEY, content, 0);
        } catch (Throwable ignored) {
            // sin tarjeta; el Inicio sigue igual
        }
    }

    /**
     * Gancho al inicio de xv6.i(I, eu1, String) (pagina de Native por nombre).
     * @return true si era la pagina "Umbra Chat" y ya se pinto (el original debe salir sin hacer nada)
     */
    public static boolean page(Object composer, Object name) {
        if (!PAGE.equals(name)) return false;
        try {
            Object n = nav;
            if (n == null || composer == null) return false;
            ClassLoader cl = composer.getClass().getClassLoader();
            Class<?> dk3 = cl.loadClass("dk3");
            Class<?> tk3 = cl.loadClass("tk3");
            Class<?> eu1 = cl.loadClass("eu1");
            Class<?> gcb = cl.loadClass("gcb");
            Method o = gcb.getDeclaredMethod("o", dk3, boolean.class, tk3, tk3, eu1, int.class, int.class);
            o.setAccessible(true);
            Object back = backFor(cl, n);
            // default = 2|4|8: usa los valores por defecto de Z (false) y de las dos lambdas (no hacen nada)
            o.invoke(null, back, Boolean.FALSE, null, null, composer, 0, 14);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- mini player y barra de abajo

    private static Method navStack;   // xs6.g() -> gz9 (List de sp6)
    private static java.lang.reflect.Field pageField;   // sp6.a (gn6)
    private static java.lang.reflect.Field nameField;   // dn6.a (String)

    /**
     * Gancho en Lfm6.r, justo despues de `xs6.d()` (true = pantalla completa: la raiz NO dibuja el mini player
     * ni la barra de abajo). Devuelve true si el original ya decia true o si la pagina de arriba es "Umbra Chat".
     * No guarda estado: se lee la pila de paginas en cada composicion, asi que vale con cualquier forma de volver.
     */
    public static boolean hideChrome(Object n, boolean original) {
        if (original) return true;
        try {
            if (n == null) return false;
            if (navStack == null) {
                Method g = n.getClass().getDeclaredMethod("g");
                g.setAccessible(true);
                navStack = g;
            }
            Object st = navStack.invoke(n);
            if (!(st instanceof java.util.List)) return false;
            java.util.List<?> list = (java.util.List<?>) st;
            if (list.isEmpty()) return false;
            Object entry = list.get(list.size() - 1);
            if (entry == null) return false;
            if (pageField == null) {
                java.lang.reflect.Field f = entry.getClass().getDeclaredField("a");
                f.setAccessible(true);
                pageField = f;
            }
            Object page = pageField.get(entry);
            if (page == null || !"dn6".equals(page.getClass().getName())) return false;
            if (nameField == null) {
                java.lang.reflect.Field f = page.getClass().getDeclaredField("a");
                f.setAccessible(true);
                nameField = f;
            }
            return PAGE.equals(nameField.get(page));
        } catch (Throwable t) {
            return false;
        }
    }

    // ---------------------------------------------------------------- lambdas

    private static synchronized Object contentFor(final ClassLoader cl, Object n) throws Exception {
        refreshCache(n);
        if (cacheContent == null) {
            final Object click = clickFor(cl, n);
            Class<?> uk3 = cl.loadClass("uk3");
            cacheContent = Proxy.newProxyInstance(cl, new Class<?>[] {uk3}, new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    Object obj = objectMethod(proxy, m, args);
                    if (obj != OBJ_NONE) return obj;
                    if ("f".equals(m.getName()) && args != null && args.length == 3) {
                        try {
                            Class<?> dk3 = cl.loadClass("dk3");
                            Class<?> eu1 = cl.loadClass("eu1");
                            Method e = cl.loadClass("fy3").getDeclaredMethod("e", dk3, eu1, int.class);
                            e.setAccessible(true);
                            e.invoke(null, click, args[1], 1);
                        } catch (Throwable ignored) {
                            // sin tarjeta
                        }
                    }
                    return unit(cl);
                }
            });
        }
        return cacheContent;
    }

    private static synchronized Object clickFor(final ClassLoader cl, final Object n) throws Exception {
        refreshCache(n);
        if (cacheClick == null) {
            Class<?> dk3 = cl.loadClass("dk3");
            cacheClick = Proxy.newProxyInstance(cl, new Class<?>[] {dk3}, new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    Object obj = objectMethod(proxy, m, args);
                    if (obj != OBJ_NONE) return obj;
                    try {
                        Class<?> dn6 = cl.loadClass("dn6");
                        Class<?> gn6 = cl.loadClass("gn6");
                        Object page = dn6.getConstructor(String.class).newInstance(PAGE);
                        Method j = n.getClass().getDeclaredMethod("j", n.getClass(), gn6);
                        j.setAccessible(true);
                        j.invoke(null, n, page);
                    } catch (Throwable ignored) {
                        // no abre
                    }
                    return unit(cl);
                }
            });
        }
        return cacheClick;
    }

    private static synchronized Object backFor(final ClassLoader cl, final Object n) throws Exception {
        refreshCache(n);
        if (cacheBack == null) {
            Class<?> dk3 = cl.loadClass("dk3");
            cacheBack = Proxy.newProxyInstance(cl, new Class<?>[] {dk3}, new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    Object obj = objectMethod(proxy, m, args);
                    if (obj != OBJ_NONE) return obj;
                    try {
                        Method h = n.getClass().getDeclaredMethod("h");
                        h.setAccessible(true);
                        h.invoke(n);
                    } catch (Throwable ignored) {
                        // no vuelve
                    }
                    return unit(cl);
                }
            });
        }
        return cacheBack;
    }

    /** Si cambia el navegador, se vuelven a crear las lambdas (cada una guarda el suyo). */
    private static void refreshCache(Object n) {
        if (cacheNav != n) {
            cacheNav = n;
            cacheContent = null;
            cacheClick = null;
            cacheBack = null;
        }
    }

    // ---------------------------------------------------------------- utilidades

    private static final Object OBJ_NONE = new Object();

    /** equals/hashCode/toString del proxy; si no es de Object devuelve OBJ_NONE. */
    private static Object objectMethod(Object proxy, Method m, Object[] args) {
        if (m.getDeclaringClass() != Object.class) return OBJ_NONE;
        String name = m.getName();
        if ("equals".equals(name)) return proxy == (args == null ? null : args[0]);
        if ("hashCode".equals(name)) return System.identityHashCode(proxy);
        return "UmbraChatNative";
    }

    /** kotlin.Unit.INSTANCE si existe (las lambdas devuelven Unit); si no, null. */
    private static Object unit(ClassLoader cl) {
        try {
            return cl.loadClass("kotlin.Unit").getField("INSTANCE").get(null);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Object findFieldOfType(Object host, String simpleName) {
        try {
            for (java.lang.reflect.Field f : host.getClass().getDeclaredFields()) {
                f.setAccessible(true);
                Object v = f.get(host);
                if (v != null && simpleName.equals(v.getClass().getName())) return v;
            }
        } catch (Throwable ignored) {
            // nada
        }
        return null;
    }
}
