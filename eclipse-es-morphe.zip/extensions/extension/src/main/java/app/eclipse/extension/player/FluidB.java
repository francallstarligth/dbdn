package app.eclipse.extension.player;

/**
 * v0.20.377 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). "Crece desde el mini": al ABRIR el reproductor grande la hoja sale chiquita
 * de donde esta el mini y crece. Solo vale mientras corre la animacion de apertura de PlayerEnter (growing); al arrastrar para cerrar
 * todo queda como el original.
 * - factor(): reemplaza la constante 0.6 de Lwka.a (escala = 1 - factor * valor/alto): 0.85 -> la hoja arranca al 15%.
 * - offset(v): en Lm10.invoke (caso 11, el desplazamiento Y de la hoja) multiplica el valor por 0.37 SOLO si el Animatable es el de la hoja
 *   (setSheet lo registra desde Lwka.a, mark lo compara): el centro de la hoja arranca en 0.87 del alto (donde esta el mini).
 */
@SuppressWarnings("unused")
public final class FluidB {
    private static final float OFFSET = 0.37f;
    private static final float SCALE = 0.85f;
    private static final float ORIGINAL = 0.6f;

    private static volatile Object sheet;
    private static boolean lastIsSheet;

    private FluidB() {}

    public static void enable() { PlayerEnter.enableGrow(); }

    public static void setSheet(Object anim) { sheet = anim; }

    public static void mark(Object anim) { lastIsSheet = anim != null && anim == sheet; }

    public static float offset(float v) { return (lastIsSheet && PlayerEnter.growing()) ? v * OFFSET : v; }

    public static float factor() { return PlayerEnter.growing() ? SCALE : ORIGINAL; }
}
