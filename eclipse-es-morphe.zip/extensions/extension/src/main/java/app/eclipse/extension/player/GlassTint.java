package app.eclipse.extension.player;

/**
 * Capa de color translucida y lisa para el vidrio (v1.96.4).
 * Mezcla la matriz de color 4x5 del vidrio (20 floats, filas R, G, B, A; columna 5 = desplazamiento 0..255) con un
 * color liso: salida = (1 - alpha) * (lo de atras) + alpha * color. No toca la fila alfa.
 */
public final class GlassTint {
    private GlassTint() {
    }

    public static void mix(float[] m, float alpha, int rgb) {
        try {
            if (m == null || m.length < 20 || !(alpha > 0f)) return;
            float a = alpha > 1f ? 1f : alpha;
            float k = 1f - a;
            float[] c = {((rgb >> 16) & 0xFF), ((rgb >> 8) & 0xFF), (rgb & 0xFF)};
            for (int row = 0; row < 3; row++) {
                int b = row * 5;
                m[b] *= k;
                m[b + 1] *= k;
                m[b + 2] *= k;
                m[b + 4] = m[b + 4] * k + a * c[row];
            }
        } catch (Throwable ignored) {
        }
    }
}
