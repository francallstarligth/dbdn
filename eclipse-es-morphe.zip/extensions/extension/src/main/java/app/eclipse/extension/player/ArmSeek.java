package app.eclipse.extension.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * v0.20.395 (SIN COMPILAR / SIN PROBAR). Brazo del tocadiscos: la capa llamada "Brazo" gira segun el avance de la cancion.
 *
 * Nombre de la capa: "Brazo" (barrido por defecto 14 grados), o "Brazo 20" (20 grados), o "Brazo -20" (al reves).
 * El angulo propio de la capa (rotationDegrees del editor) es la posicion al empezar (0:00); al final queda a ese angulo + el barrido.
 * Positivo = en sentido de las agujas del reloj = el brazo (que cuelga del pivote de arriba a la derecha) se inclina hacia el centro del disco.
 *
 * Como funciona (Eclipse 0.6.75):
 *  - {@link #rot} se llama desde la lambda de graphicsLayer `Lpr7;.invoke` (caso que hace `Loq3.e(mv4.e + ev4.a)`), con la capa (Lv51)
 *    y la rotacion que Eclipse iba a aplicar; devuelve esa rotacion + barrido * avance. Lee un estado de Compose propio (`Lxe7`, creado con
 *    `Lxf8;.w`), asi que la capa se vuelve a dibujar sola cuando cambia el avance.
 *  - {@link #fromState} se llama al final de `Lh61.<init>` (foto del estado del reproductor: c = posicion, d = duracion).
 *  - {@link #fromBar} se llama dentro de `Lzt7;.h` (la barra de progreso): trae la posicion "efectiva", o sea la del dedo mientras se arrastra.
 *    Mientras la barra manda (hace menos de 400 ms), `fromState` no pisa el valor.
 * Cualquier fallo deja el brazo como estaba (rotacion original).
 */
@SuppressWarnings("unused")
public final class ArmSeek {
    private ArmSeek() {}

    private static final float DEFAULT_SWEEP = 14f;
    private static final long BAR_MS = 400L;

    private static final ConcurrentHashMap<String, Float> SWEEP = new ConcurrentHashMap<String, Float>();
    private static Field nameField;
    private static Object state;
    private static Method getV, setV;
    private static boolean broken;
    private static volatile long barAt;
    private static float last = Float.NaN;

    /** Barrido segun el nombre de la capa; NaN si la capa no es el brazo. */
    private static float parse(String name) {
        String n = name.replace("​", "").replace("⁠", "").trim().toLowerCase();
        String rest;
        if (n.startsWith("brazo")) rest = n.substring(5).trim();
        else if (n.startsWith("tonearm")) rest = n.substring(7).trim();
        else return Float.NaN;
        if (rest.isEmpty()) return DEFAULT_SWEEP;
        try {
            return Float.parseFloat(rest.replace(',', '.'));
        } catch (NumberFormatException e) {
            return Float.NaN; // "Brazo algo": no es el brazo
        }
    }

    private static synchronized Object state() throws Exception {
        if (state == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            getV = g;
            setV = st;
            state = s;
        }
        return state;
    }

    private static void put(double pos, double dur) {
        try {
            if (broken) return;
            float pr = dur > 1e-6 ? (float) (pos / dur) : 0f;
            if (pr < 0f) pr = 0f;
            if (pr > 1f) pr = 1f;
            pr = Math.round(pr * 4000f) / 4000f; // evita escribir por cambios invisibles
            if (pr == last) return;
            Object s = state();
            last = pr;
            setV.invoke(s, Float.valueOf(pr));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lh61.<init>: foto del estado (c = posicion, d = duracion). */
    public static void fromState(Object h61) {
        try {
            if (broken || h61 == null) return;
            if (android.os.SystemClock.uptimeMillis() - barAt < BAR_MS) return;
            Class<?> c = h61.getClass();
            Field fc = c.getDeclaredField("c"), fd = c.getDeclaredField("d");
            fc.setAccessible(true);
            fd.setAccessible(true);
            put(fc.getDouble(h61), fd.getDouble(h61));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lzt7.h (barra de progreso): posicion efectiva (la del dedo si se arrastra) y duracion. */
    public static void fromBar(double pos, double dur) {
        barAt = android.os.SystemClock.uptimeMillis();
        put(pos, dur);
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  rotacion que Eclipse iba a aplicar (grados)
     */
    public static float rot(Object layer, float base) {
        try {
            if (broken || layer == null) return base;
            if (nameField == null) {
                Field f = layer.getClass().getDeclaredField("c");
                f.setAccessible(true);
                nameField = f;
            }
            Object nm = nameField.get(layer);
            if (!(nm instanceof String)) return base;
            String name = (String) nm;
            Float sw = SWEEP.get(name);
            if (sw == null) {
                sw = Float.valueOf(parse(name));
                SWEEP.put(name, sw);
            }
            if (Float.isNaN(sw.floatValue())) return base;
            Object s = state();
            Object v = getV.invoke(s); // lectura de estado de Compose: dentro del bloque de la capa, asi se redibuja sola
            float pr = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            return base + sw.floatValue() * pr;
        } catch (Throwable e) {
            broken = true;
            return base;
        }
    }
}
