package app.eclipse.extension.player;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/**
 * v0.20.398 (SIN COMPILAR / SIN PROBAR; sombra del brazo sobre la 0.20.395-397). Brazo del tocadiscos: la capa llamada "Brazo" gira segun el avance de la cancion.
 *
 * Nombre de la capa: "Brazo" (barrido por defecto 14 grados), o "Brazo 20" (20 grados), o "Brazo -20" (al reves).
 * El angulo propio de la capa (rotationDegrees del editor) es la posicion al empezar (0:00); al final queda a ese angulo + el barrido.
 * Positivo = en sentido de las agujas del reloj = el brazo (que cuelga del pivote de arriba a la derecha) se inclina hacia el centro del disco.
 *
 * Como funciona (Eclipse 0.6.75):
 *  - {@link #rot} se llama desde la lambda de graphicsLayer `Lpr7;.invoke` (caso que hace `Loq3.e(mv4.e + ev4.a)`), con la capa (Lv51)
 *    y la rotacion que Eclipse iba a aplicar; devuelve esa rotacion + barrido * avance. Lee un estado de Compose propio (`Lxe7`, creado con
 *    `Lxf8;.w`), asi que la capa se vuelve a dibujar sola cuando cambia el avance.
 *  - {@link #fromState} se llama al final de `Lh61.<init>` (foto del estado del reproductor: c = posicion, d = duracion).
 *  - {@link #fromBar} se llama dentro de `Lzt7;.h` (la barra de progreso): trae la posicion "efectiva", o sea la del dedo mientras se arrastra.
 *    Mientras la barra manda (hace menos de 400 ms), `fromState` no pisa el valor.
 * Barra-arco: las capas cuyo nombre empieza con "Arco" (una barra de progreso girada junto a la aguja, y si quieres sus tiempos) estan
 * ocultas y aparecen (fundido) mientras se arrastra la barra; se van solas a los {@link #IDLE_MS} ms de soltar. {@link #drag} se llama desde
 * la rama "arrastrando" de `Lzt7;.h` y {@link #alpha} desde la misma lambda de graphicsLayer (el ajuste `m` = transparencia).
 * Sombra del brazo (v0.20.398): la capa "Sombra brazo" (imagen de la silueta del brazo, misma caja que "Brazo") gira igual que el brazo y se
 * ve en reposo; la capa "Sombra brazo alta" (sombra mas lejana y suave) gira igual y aparece solo mientras se arrastra la barra (brazo
 * "levantado"). Las dos comparten el fundido de la barra-arco: al arrastrar, la de reposo se va y entra la alta; al soltar (IDLE_MS) vuelven.
 * Tambien acepta "Sombra brazo 20" / "Sombra brazo alta -20" (mismo barrido que el brazo).
 * Cualquier fallo deja el brazo como estaba (rotacion original), la barra-arco y la sombra de reposo visibles y la sombra alta escondida.
 */
@SuppressWarnings("unused")
public final class ArmSeek {
    private ArmSeek() {}

    private static final float DEFAULT_SWEEP = 14f;
    private static final long BAR_MS = 400L;
    /** Tiempo sin tocar la barra antes de que se esconda. */
    private static final long IDLE_MS = 2500L;
    private static final long FADE_IN_MS = 120L, FADE_OUT_MS = 350L;

    /** Por nombre de capa: {barrido (NaN si no gira), tipo}. Tipo: 0 = otra capa o el brazo, 1 = Arco, 2 = Sombra brazo, 3 = Sombra brazo alta. */
    private static final ConcurrentHashMap<String, float[]> INFO = new ConcurrentHashMap<String, float[]>();
    private static Field nameField;
    private static Object state;
    private static Method getV, setV;
    private static boolean broken;
    private static volatile long barAt;
    private static float last = Float.NaN;
    private static Object fadeState;
    private static Method fadeGet, fadeSet;
    private static float fadeNow = 0f;
    private static float fadeTarget = 0f;
    private static android.os.Handler main;
    private static float animFrom;
    private static long animT0, animDur;

    private static float sweepOf(String rest) {
        if (rest.isEmpty()) return DEFAULT_SWEEP;
        try {
            return Float.parseFloat(rest.replace(',', '.'));
        } catch (NumberFormatException e) {
            return Float.NaN; // "Brazo algo": no es el brazo
        }
    }

    /** {barrido, tipo} segun el nombre de la capa (ver INFO). */
    private static float[] parse(String name) {
        String n = name.replace("\u200B", "").replace("\u2060", "").trim().toLowerCase();
        if (n.startsWith("arco")) return new float[] {Float.NaN, 1f};
        if (n.startsWith("sombra brazo") || n.startsWith("sombra tonearm")) {
            String rest = n.substring(n.startsWith("sombra brazo") ? 12 : 14).trim();
            float kind = 2f;
            if (rest.startsWith("alta")) {
                kind = 3f;
                rest = rest.substring(4).trim();
            }
            return new float[] {sweepOf(rest), kind};
        }
        if (n.startsWith("brazo")) return new float[] {sweepOf(n.substring(5).trim()), 0f};
        if (n.startsWith("tonearm")) return new float[] {sweepOf(n.substring(7).trim()), 0f};
        return new float[] {Float.NaN, 0f};
    }

    /** Lee el nombre de la capa (Lv51.c) y devuelve su {barrido, tipo}; null si no se puede leer. */
    private static float[] infoOf(Object layer) {
        try {
            if (layer == null) return null;
            if (nameField == null) {
                Field f = layer.getClass().getDeclaredField("c");
                f.setAccessible(true);
                nameField = f;
            }
            Object nm = nameField.get(layer);
            if (!(nm instanceof String)) return null;
            String name = (String) nm;
            float[] in = INFO.get(name);
            if (in == null) {
                in = parse(name);
                INFO.put(name, in);
            }
            return in;
        } catch (Throwable e) {
            return null;
        }
    }

    private static synchronized Object state() throws Exception {
        if (state == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            getV = g;
            setV = st;
            state = s;
        }
        return state;
    }

    private static synchronized Object fade() throws Exception {
        if (fadeState == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            fadeGet = g;
            fadeSet = st;
            fadeState = s;
            main = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        return fadeState;
    }

    private static final Runnable STEP = new Runnable() {
        @Override public void run() {
            try {
                float t = animDur <= 0 ? 1f : (android.os.SystemClock.uptimeMillis() - animT0) / (float) animDur;
                if (t > 1f) t = 1f;
                fadeNow = animFrom + (fadeTarget - animFrom) * t;
                fadeSet.invoke(fadeState, Float.valueOf(fadeNow));
                if (t < 1f) main.postDelayed(this, 16L);
            } catch (Throwable e) {
                broken = true;
            }
        }
    };

    private static final Runnable HIDE = new Runnable() {
        @Override public void run() { animateTo(0f, FADE_OUT_MS); }
    };

    private static void animateTo(float target, long ms) {
        try {
            if (broken) return;
            fade();
            main.removeCallbacks(STEP);
            fadeTarget = target;
            animFrom = fadeNow;
            animT0 = android.os.SystemClock.uptimeMillis();
            animDur = ms;
            STEP.run();
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lzt7.h, rama "arrastrando": muestra la barra-arco y reinicia el reloj para esconderla. */
    public static void drag() {
        try {
            if (broken) return;
            fade();
            main.removeCallbacks(HIDE);
            if (fadeTarget != 1f) animateTo(1f, FADE_IN_MS);
            main.postDelayed(HIDE, IDLE_MS);
        } catch (Throwable e) {
            broken = true;
        }
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  transparencia que Eclipse iba a aplicar (0..1)
     */
    public static float alpha(Object layer, float base) {
        int kind = 0;
        try {
            float[] in = infoOf(layer);
            if (in == null) return base;
            kind = (int) in[1];
            if (kind == 0) return base;
            if (broken) return kind == 3 ? 0f : base;
            fade();
            Object v = fadeGet.invoke(fadeState); // lectura de estado de Compose: la capa se redibuja sola durante el fundido
            float f = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            if (kind == 2) return base * (1f - f); // sombra de reposo: se va al levantar el brazo
            return base * f;                       // barra-arco y sombra alta: aparecen al arrastrar
        } catch (Throwable e) {
            broken = true;
            return kind == 3 ? 0f : base;
        }
    }

    private static void put(double pos, double dur) {
        try {
            if (broken) return;
            float pr = dur > 1e-6 ? (float) (pos / dur) : 0f;
            if (pr < 0f) pr = 0f;
            if (pr > 1f) pr = 1f;
            pr = Math.round(pr * 4000f) / 4000f; // evita escribir por cambios invisibles
            if (pr == last) return;
            Object s = state();
            last = pr;
            setV.invoke(s, Float.valueOf(pr));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lh61.<init>: foto del estado (c = posicion, d = duracion). */
    public static void fromState(Object h61) {
        try {
            if (broken || h61 == null) return;
            if (android.os.SystemClock.uptimeMillis() - barAt < BAR_MS) return;
            Class<?> c = h61.getClass();
            Field fc = c.getDeclaredField("c"), fd = c.getDeclaredField("d");
            fc.setAccessible(true);
            fd.setAccessible(true);
            put(fc.getDouble(h61), fd.getDouble(h61));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lzt7.h (barra de progreso): posicion efectiva (la del dedo si se arrastra) y duracion. */
    public static void fromBar(double pos, double dur) {
        barAt = android.os.SystemClock.uptimeMillis();
        put(pos, dur);
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  rotacion que Eclipse iba a aplicar (grados)
     */
    public static float rot(Object layer, float base) {
        try {
            if (broken) return base;
            float[] in = infoOf(layer);
            if (in == null || Float.isNaN(in[0])) return base;
            Object s = state();
            Object v = getV.invoke(s); // lectura de estado de Compose: dentro del bloque de la capa, asi se redibuja sola
            float pr = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            return base + in[0] * pr;
        } catch (Throwable e) {
            broken = true;
            return base;
        }
    }
}
