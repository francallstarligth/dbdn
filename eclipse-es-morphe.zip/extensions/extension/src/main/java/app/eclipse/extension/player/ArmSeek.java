package app.eclipse.extension.player;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.HapticFeedbackConstants;
import android.view.View;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * v0.20.401 (SIN COMPILAR / SIN PROBAR; crecimiento medido: brazo 1,5% y sombra alta 3%, sobre la 0.20.400). Brazo del tocadiscos: la capa llamada "Brazo" gira segun el avance de la cancion.
 *
 * Nombre de la capa: "Brazo" (barrido por defecto 14 grados), o "Brazo 20" (20 grados), o "Brazo -20" (al reves).
 * El angulo propio de la capa (rotationDegrees del editor) es la posicion al empezar (0:00); al final queda a ese angulo + el barrido.
 * Positivo = en sentido de las agujas del reloj = el brazo (que cuelga del pivote de arriba a la derecha) se inclina hacia el centro del disco.
 *
 * Como funciona (Eclipse 0.6.75):
 *  - {@link #rot} se llama desde la lambda de graphicsLayer `Lpr7;.invoke` (caso que hace `Loq3.e(mv4.e + ev4.a)`), con la capa (Lv51)
 *    y la rotacion que Eclipse iba a aplicar; devuelve esa rotacion + barrido * avance. Lee un estado de Compose propio (`Lxe7`, creado con
 *    `Lxf8;.w`), asi que la capa se vuelve a dibujar sola cuando cambia el avance.
 *  - {@link #fromState} se llama al final de `Lh61.<init>` (foto del estado del reproductor: c = posicion, d = duracion).
 *  - {@link #fromBar} se llama dentro de `Lzt7;.h` (la barra de progreso): trae la posicion "efectiva", o sea la del dedo mientras se arrastra.
 *    Mientras la barra manda (hace menos de 400 ms), `fromState` no pisa el valor.
 * Barra-arco: las capas cuyo nombre empieza con "Arco" (una barra de progreso girada junto a la aguja, y si quieres sus tiempos) estan
 * ocultas y aparecen (fundido) mientras se arrastra la barra; se van solas a los {@link #IDLE_MS} ms de soltar. {@link #drag} se llama desde
 * la rama "arrastrando" de `Lzt7;.h` y {@link #alpha} desde la misma lambda de graphicsLayer (el ajuste `m` = transparencia).
 * Sombra del brazo (v0.20.398): la capa "Sombra brazo" (imagen de la silueta del brazo, misma caja que "Brazo") gira igual que el brazo y se
 * ve en reposo; la capa "Sombra brazo alta" (sombra mas lejana y suave) gira igual y aparece solo mientras se arrastra la barra (brazo
 * "levantado"). Las dos comparten el fundido de la barra-arco: al arrastrar, la de reposo se va y entra la alta; al soltar (IDLE_MS) vuelven.
 * Tambien acepta "Sombra brazo 20" / "Sombra brazo alta -20" (mismo barrido que el brazo).
 * Brazo "levantado" (v0.20.399): mientras se arrastra la barra, la capa "Brazo" crece un poco ({@link #LIFT}, 1,5%, medido en el video de referencia) con un movimiento suave
 * (sube en {@link #LIFT_UP_MS} ms) y vuelve a su tamano {@link #LIFT_HOLD_MS} ms despues del ultimo movimiento del dedo ({@link #LIFT_DOWN_MS} ms).
 * Al empezar a arrastrar (brazo abajo -> arriba) se da un toque de vibracion corto (HapticFeedback de la ventana; no pide permisos, pero
 * solo suena si el telefono tiene activada la vibracion al tocar). El crecimiento se aplica desde la misma lambda de graphicsLayer
 * (ajustes `p` y `i` = escala X e Y) a la capa "Brazo" (1,5%) y a "Sombra brazo alta" (3%, v0.20.401); la sombra de reposo no cambia de tamano.
 * Cualquier fallo deja el brazo como estaba (rotacion original), la barra-arco y la sombra de reposo visibles y la sombra alta escondida.
 */
@SuppressWarnings("unused")
public final class ArmSeek {
    private ArmSeek() {}

    private static final float DEFAULT_SWEEP = 14f;
    private static final long BAR_MS = 400L;
    /** Tiempo sin tocar la barra antes de que se esconda. */
    private static final long IDLE_MS = 2500L;
    private static final long FADE_IN_MS = 120L, FADE_OUT_MS = 350L;
    /** Cuanto crece el brazo al levantarse (0.05 = 5%). */
    private static final float LIFT = 0.015f;
    /** Cuanto crece la sombra alta al levantarse el brazo (mas que el brazo, para que se note que se aleja). */
    private static final float SHADOW_LIFT = 0.03f;
    private static final long LIFT_UP_MS = 140L, LIFT_DOWN_MS = 320L;
    /** Tiempo sin mover el dedo antes de bajar el brazo. */
    private static final long LIFT_HOLD_MS = 700L;

    /** Por nombre de capa: {barrido (NaN si no gira), tipo}. Tipo: 0 = otra capa o el brazo, 1 = Arco, 2 = Sombra brazo, 3 = Sombra brazo alta. */
    private static final ConcurrentHashMap<String, float[]> INFO = new ConcurrentHashMap<String, float[]>();
    private static Field nameField;
    private static Object state;
    private static Method getV, setV;
    private static boolean broken;
    private static volatile long barAt;
    private static float last = Float.NaN;
    private static Object fadeState;
    private static Method fadeGet, fadeSet;
    private static float fadeNow = 0f;
    private static float fadeTarget = 0f;
    private static android.os.Handler main;
    private static float animFrom;
    private static long animT0, animDur;
    // brazo levantado (v0.20.399)
    private static Object liftState;
    private static Method liftGet, liftSet;
    private static float liftNow = 0f, liftFrom = 0f, liftTarget = 0f;
    private static long liftT0, liftDur;
    private static boolean liftBroken;
    private static WeakReference<Activity> actual;
    private static boolean lifecycleTried;

    private static float sweepOf(String rest) {
        if (rest.isEmpty()) return DEFAULT_SWEEP;
        try {
            return Float.parseFloat(rest.replace(',', '.'));
        } catch (NumberFormatException e) {
            return Float.NaN; // "Brazo algo": no es el brazo
        }
    }

    /** {barrido, tipo} segun el nombre de la capa (ver INFO). */
    private static float[] parse(String name) {
        String n = name.replace("\u200B", "").replace("\u2060", "").trim().toLowerCase();
        if (n.startsWith("arco")) return new float[] {Float.NaN, 1f};
        if (n.startsWith("sombra brazo") || n.startsWith("sombra tonearm")) {
            String rest = n.substring(n.startsWith("sombra brazo") ? 12 : 14).trim();
            float kind = 2f;
            if (rest.startsWith("alta")) {
                kind = 3f;
                rest = rest.substring(4).trim();
            }
            return new float[] {sweepOf(rest), kind};
        }
        if (n.startsWith("brazo")) return new float[] {sweepOf(n.substring(5).trim()), 0f};
        if (n.startsWith("tonearm")) return new float[] {sweepOf(n.substring(7).trim()), 0f};
        return new float[] {Float.NaN, 0f};
    }

    /** Lee el nombre de la capa (Lv51.c) y devuelve su {barrido, tipo}; null si no se puede leer. */
    private static float[] infoOf(Object layer) {
        try {
            if (layer == null) return null;
            if (nameField == null) {
                Field f = layer.getClass().getDeclaredField("c");
                f.setAccessible(true);
                nameField = f;
            }
            Object nm = nameField.get(layer);
            if (!(nm instanceof String)) return null;
            String name = (String) nm;
            float[] in = INFO.get(name);
            if (in == null) {
                in = parse(name);
                INFO.put(name, in);
            }
            return in;
        } catch (Throwable e) {
            return null;
        }
    }

    private static synchronized Object state() throws Exception {
        if (state == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            getV = g;
            setV = st;
            state = s;
        }
        return state;
    }

    private static synchronized Object fade() throws Exception {
        if (fadeState == null) {
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            fadeGet = g;
            fadeSet = st;
            fadeState = s;
            main = new android.os.Handler(android.os.Looper.getMainLooper());
        }
        return fadeState;
    }

    private static final Runnable STEP = new Runnable() {
        @Override public void run() {
            try {
                float t = animDur <= 0 ? 1f : (android.os.SystemClock.uptimeMillis() - animT0) / (float) animDur;
                if (t > 1f) t = 1f;
                fadeNow = animFrom + (fadeTarget - animFrom) * t;
                fadeSet.invoke(fadeState, Float.valueOf(fadeNow));
                if (t < 1f) main.postDelayed(this, 16L);
            } catch (Throwable e) {
                broken = true;
            }
        }
    };

    private static final Runnable HIDE = new Runnable() {
        @Override public void run() { animateTo(0f, FADE_OUT_MS); }
    };

    private static void animateTo(float target, long ms) {
        try {
            if (broken) return;
            fade();
            main.removeCallbacks(STEP);
            fadeTarget = target;
            animFrom = fadeNow;
            animT0 = android.os.SystemClock.uptimeMillis();
            animDur = ms;
            STEP.run();
        } catch (Throwable e) {
            broken = true;
        }
    }

    private static synchronized Object lift() throws Exception {
        if (liftState == null) {
            fade(); // crea el Handler del hilo principal
            Method mk = Class.forName("xf8").getDeclaredMethod("w", Object.class);
            mk.setAccessible(true);
            Object s = mk.invoke(null, Float.valueOf(0f));
            Method g = s.getClass().getDeclaredMethod("getValue");
            Method st = s.getClass().getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            st.setAccessible(true);
            liftGet = g;
            liftSet = st;
            liftState = s;
        }
        return liftState;
    }

    private static final Runnable LIFT_STEP = new Runnable() {
        @Override public void run() {
            try {
                float t = liftDur <= 0 ? 1f : (android.os.SystemClock.uptimeMillis() - liftT0) / (float) liftDur;
                if (t > 1f) t = 1f;
                float e = t * t * (3f - 2f * t); // arranque y llegada suaves
                liftNow = liftFrom + (liftTarget - liftFrom) * e;
                liftSet.invoke(liftState, Float.valueOf(liftNow));
                if (t < 1f) main.postDelayed(this, 16L);
            } catch (Throwable e) {
                liftBroken = true;
            }
        }
    };

    private static final Runnable LIFT_DOWN = new Runnable() {
        @Override public void run() { liftTo(0f, LIFT_DOWN_MS); }
    };

    private static void liftTo(float target, long ms) {
        try {
            if (liftBroken) return;
            lift();
            main.removeCallbacks(LIFT_STEP);
            liftTarget = target;
            liftFrom = liftNow;
            liftT0 = android.os.SystemClock.uptimeMillis();
            liftDur = ms;
            LIFT_STEP.run();
        } catch (Throwable e) {
            liftBroken = true;
        }
    }

    /** Sigue cual es la actividad visible (para la vibracion). Mejor esfuerzo; si falla no hay vibracion y nada mas. */
    private static void trackActivity() {
        if (lifecycleTried) return;
        lifecycleTried = true;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Application) {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
            }
        } catch (Throwable e) {
            // sin seguimiento: se usa la busqueda directa
        }
    }

    @SuppressWarnings("unchecked")
    private static Activity findActivity() {
        Activity a = actual == null ? null : actual.get();
        if (a != null) return a;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return (Activity) act;
                }
            }
        } catch (Throwable e) {
            // sin actividad: no hay vibracion
        }
        return null;
    }

    /** Toque corto de vibracion al empezar a levantar el brazo. Nunca rompe nada: si algo falla, simplemente no vibra. */
    private static void tick() {
        try {
            trackActivity();
            Activity a = findActivity();
            if (a == null) return;
            View v = a.getWindow().getDecorView();
            boolean ok = v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
            if (!ok) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        } catch (Throwable e) {
            // sin vibracion
        }
    }

    /** Lzt7.h, rama "arrastrando": muestra la barra-arco y reinicia el reloj para esconderla. */
    public static void drag() {
        try {
            if (broken) return;
            fade();
            main.removeCallbacks(HIDE);
            if (fadeTarget != 1f) animateTo(1f, FADE_IN_MS);
            main.postDelayed(HIDE, IDLE_MS);
        } catch (Throwable e) {
            broken = true;
        }
        try {
            if (liftBroken) return;
            lift();
            main.removeCallbacks(LIFT_DOWN);
            if (liftTarget != 1f) {
                tick();
                liftTo(1f, LIFT_UP_MS);
            }
            main.postDelayed(LIFT_DOWN, LIFT_HOLD_MS);
        } catch (Throwable e) {
            liftBroken = true;
        }
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  transparencia que Eclipse iba a aplicar (0..1)
     */
    public static float alpha(Object layer, float base) {
        int kind = 0;
        try {
            float[] in = infoOf(layer);
            if (in == null) return base;
            kind = (int) in[1];
            if (kind == 0) return base;
            if (broken) return kind == 3 ? 0f : base;
            fade();
            Object v = fadeGet.invoke(fadeState); // lectura de estado de Compose: la capa se redibuja sola durante el fundido
            float f = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            if (kind == 2) return base * (1f - f); // sombra de reposo: se va al levantar el brazo
            return base * f;                       // barra-arco y sombra alta: aparecen al arrastrar
        } catch (Throwable e) {
            broken = true;
            return kind == 3 ? 0f : base;
        }
    }

    private static void put(double pos, double dur) {
        try {
            if (broken) return;
            float pr = dur > 1e-6 ? (float) (pos / dur) : 0f;
            if (pr < 0f) pr = 0f;
            if (pr > 1f) pr = 1f;
            pr = Math.round(pr * 4000f) / 4000f; // evita escribir por cambios invisibles
            if (pr == last) return;
            Object s = state();
            last = pr;
            setV.invoke(s, Float.valueOf(pr));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lh61.<init>: foto del estado (c = posicion, d = duracion). */
    public static void fromState(Object h61) {
        try {
            if (broken || h61 == null) return;
            if (android.os.SystemClock.uptimeMillis() - barAt < BAR_MS) return;
            Class<?> c = h61.getClass();
            Field fc = c.getDeclaredField("c"), fd = c.getDeclaredField("d");
            fc.setAccessible(true);
            fd.setAccessible(true);
            put(fc.getDouble(h61), fd.getDouble(h61));
        } catch (Throwable e) {
            broken = true;
        }
    }

    /** Lzt7.h (barra de progreso): posicion efectiva (la del dedo si se arrastra) y duracion. */
    public static void fromBar(double pos, double dur) {
        barAt = android.os.SystemClock.uptimeMillis();
        put(pos, dur);
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  escala que Eclipse iba a aplicar (se usa igual para X e Y). Solo cambia la capa Brazo (+1,5%) y Sombra brazo alta (+3%).
     */
    public static float scale(Object layer, float base) {
        try {
            if (liftBroken || broken) return base;
            float[] in = infoOf(layer);
            if (in == null || Float.isNaN(in[0])) return base;
            int kind = (int) in[1];
            float amount = kind == 0 ? LIFT : (kind == 3 ? SHADOW_LIFT : 0f); // "Brazo" y "Sombra brazo alta"; el resto no cambia
            if (amount == 0f) return base;
            Object s = lift();
            Object v = liftGet.invoke(s); // lectura de estado de Compose: la capa se redibuja sola mientras sube o baja
            float f = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            return base * (1f + amount * f);
        } catch (Throwable e) {
            liftBroken = true;
            return base;
        }
    }

    /**
     * @param layer Lv51 (la capa)
     * @param base  rotacion que Eclipse iba a aplicar (grados)
     */
    public static float rot(Object layer, float base) {
        try {
            if (broken) return base;
            float[] in = infoOf(layer);
            if (in == null || Float.isNaN(in[0])) return base;
            Object s = state();
            Object v = getV.invoke(s); // lectura de estado de Compose: dentro del bloque de la capa, asi se redibuja sola
            float pr = (v instanceof Float) ? ((Float) v).floatValue() : 0f;
            return base + in[0] * pr;
        } catch (Throwable e) {
            broken = true;
            return base;
        }
    }
}
