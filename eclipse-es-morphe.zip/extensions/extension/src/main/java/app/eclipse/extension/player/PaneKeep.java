package app.eclipse.extension.player;

import android.os.SystemClock;

/**
 * v0.20.65 (SIN COMPILAR / SIN PROBAR). Al cambiar de pestana (Artwork / Letra / Cola), Eclipse (hj6.b) solo arma el
 * panel de Letra o Cola si su peso (qw0.e) es mayor que 0.001; al cambiar, el peso pasa por 0 (la pestana nueva baja
 * de 1 a 0 y luego sube), asi que el panel se DESTRUYE y se arma otra vez vacio (lista vacia, portadas grises).
 * Ganchos (PaneKeepPatch): {@link #changed} al inicio de qw0.d (cambio de pestana) y {@link #w} sobre el peso leido
 * en hj6.b (dos sitios). Durante {@link #KEEP_MS} tras el cambio el peso nunca baja de {@link #FLOOR}: el panel sigue
 * armado (con opacidad casi 0, invisible). No guarda ni copia datos.
 */
public final class PaneKeep {
    private static final long KEEP_MS = 250;
    private static final float FLOOR = 0.002f;
    private static volatile long until;

    private PaneKeep() {}

    public static void changed() {
        try {
            until = SystemClock.uptimeMillis() + KEEP_MS;
        } catch (Throwable t) {
            until = 0;
        }
    }

    public static float w(float v) {
        try {
            if (v >= FLOOR) return v;
            if (SystemClock.uptimeMillis() < until) return FLOOR;
        } catch (Throwable ignored) {
        }
        return v;
    }
}
