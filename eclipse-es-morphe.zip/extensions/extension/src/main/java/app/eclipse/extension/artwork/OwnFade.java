package app.eclipse.extension.artwork;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.List;

/**
 * v1.100.12 (opcion B): el edge fade de Eclipse (jh2 en x40.i) se dibuja como una caja aparte encima de la portada y
 * ahi aparece la raya a la mitad. El parche "Custom: portada con fundido propio" hace que hj6.a NO dibuje esa caja
 * (igual que cuando el usuario quita el edge fade en el editor) y pasa la configuracion (jh2) a {@link #capture}.
 * La portada (PrevCover.FadeDrawable) hornea el mismo degradado en su propio dibujo con {@link #apply}.
 */
@SuppressWarnings("unused")
public final class OwnFade {
    private OwnFade() {}

    private static final float[] DEF_POS = {0f, 0.3f, 0.65f, 0.92f, 1f};
    private static final float[] DEF_ALPHA = {0f, 0.18f, 0.72f, 1f, 1f};

    private static volatile boolean active = false;
    private static volatile boolean top = false;
    private static volatile float fraction = 0f;
    private static volatile float[] pos = DEF_POS;
    private static volatile float[] alpha = DEF_ALPHA;
    private static Object last;

    /** Se llama desde hj6.a con x40.i (puede ser null). Siempre devuelve null: asi hj6.a salta la caja del fade. */
    public static Object capture(Object jh2) {
        try {
            if (jh2 == null) {
                last = null;
                active = false;
                return null;
            }
            if (jh2 == last) return null;
            last = jh2;
            String edge = null;
            double frac = -1;
            List<?> stops = null;
            for (Field f : jh2.getClass().getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                Class<?> t = f.getType();
                if (t == String.class) edge = (String) f.get(jh2);
                else if (t == double.class) frac = f.getDouble(jh2);
                else if (List.class.isAssignableFrom(t)) stops = (List<?>) f.get(jh2);
            }
            float[] p = DEF_POS, a = DEF_ALPHA;
            if (stops != null && stops.size() >= 2) {
                float[] pp = new float[stops.size()];
                float[] aa = new float[stops.size()];
                boolean ok = true;
                for (int i = 0; i < pp.length && ok; i++) {
                    Object pair = stops.get(i);
                    Number n1 = null, n2 = null;
                    for (Field f : pair.getClass().getDeclaredFields()) {
                        if (Modifier.isStatic(f.getModifiers())) continue;
                        f.setAccessible(true);
                        Object v = f.get(pair);
                        if (v instanceof Number) { if (n1 == null) n1 = (Number) v; else if (n2 == null) n2 = (Number) v; }
                    }
                    if (n1 == null || n2 == null) { ok = false; break; }
                    pp[i] = n1.floatValue();
                    aa[i] = Math.max(0f, Math.min(1f, n2.floatValue()));
                    if (i > 0 && pp[i] < pp[i - 1]) ok = false;
                }
                if (ok) { p = pp; a = aa; }
            }
            if (frac <= 0 || frac > 1) {
                active = false;
                return null;
            }
            top = "top".equals(edge);
            fraction = (float) frac;
            pos = p;
            alpha = a;
            active = true;
        } catch (Throwable t) {
            active = false;
        }
        return null;
    }

    public static boolean isActive() { return active; }

    /**
     * Borra (transparente, DstOut) la franja del borde de la portada con el degradado de Eclipse. Debe llamarse dentro
     * de una capa (saveLayer) que contenga la portada. (l,t,r,b) = area de la portada.
     */
    static void apply(android.graphics.Canvas c, float l, float t, float r, float b, Cache cache) {
        try {
            float h = b - t;
            if (h <= 0 || !active) return;
            float len = h * fraction;
            boolean tp = top;
            float y0 = tp ? t : b - len;
            float y1 = tp ? t + len : b;
            if (cache.shader == null || cache.y0 != y0 || cache.y1 != y1 || cache.top != tp) {
                int n = pos.length;
                int[] colors = new int[n];
                float[] ps = new float[n];
                for (int i = 0; i < n; i++) {
                    int k = tp ? n - 1 - i : i;               // arriba: el lado opaco queda en el borde superior
                    colors[i] = ((int) (alpha[k] * 255f + 0.5f) << 24);
                    ps[i] = tp ? 1f - pos[k] : pos[k];
                }
                cache.shader = new android.graphics.LinearGradient(0f, y0, 0f, y1, colors, ps,
                        android.graphics.Shader.TileMode.CLAMP);
                cache.paint = new android.graphics.Paint();
                cache.paint.setShader(cache.shader);
                cache.paint.setXfermode(new android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.DST_OUT));
                cache.y0 = y0;
                cache.y1 = y1;
                cache.top = tp;
            }
            c.drawRect(l, y0, r, y1, cache.paint);
        } catch (Throwable ignored) {
        }
    }

    static final class Cache {
        android.graphics.Shader shader;
        android.graphics.Paint paint;
        float y0, y1;
        boolean top;
    }
}
