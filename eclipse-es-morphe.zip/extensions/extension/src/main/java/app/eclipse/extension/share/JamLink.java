package app.eclipse.extension.share;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v0.20.356 (SIN COMPILAR NI PROBAR). Enlace propio para compartir un jam: en vez de https://eclipsemusic.app/s/XXXX
 * devuelve BASE?id=JAMID&s=XXXX&n=NOMBRE&a=URLFOTO. La pagina (Function de Cloudflare) pone nombre/foto en la vista previa.
 * Todo va en try/catch: si algo falla se devuelve el enlace original.
 */
public final class JamLink {
    private static final String TAG = "JamLink";
    private static final String PREFIX = "debridmusic://jam?id=";
    private static final Pattern SID = Pattern.compile("/s/([A-Za-z0-9_-]+)");

    private static volatile String base = "https://jamlink.pages.dev/";
    private static volatile String deep;
    private static volatile String host;
    private static volatile String avatar;

    private JamLink() {}

    /** Se llama al empezar a armar el mensaje de un jam: guarda el codigo del jam y busca nombre/foto de la cuenta. */
    public static void jam(String jamId) {
        try {
            avatar = null;
            host = null;
            deep = (jamId == null || jamId.length() == 0) ? null : PREFIX + jamId;
            account();
        } catch (Throwable t) {
            Log.w(TAG, "jam", t);
        }
    }

    /** Foto y nombre de la cuenta, por reflexion: fl0.m (singleton).o(contexto) -> h -> b/a -> getValue() -> User. */
    private static void account() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app == null) return;
            Class<?> k = Class.forName("fl0");
            Field fm = k.getDeclaredField("m");
            fm.setAccessible(true);
            Object holderObj = fm.get(null);
            if (holderObj == null) return;
            Method o = null;
            for (Method mm : holderObj.getClass().getDeclaredMethods()) {
                if (mm.getName().equals("o") && mm.getParameterTypes().length == 1
                        && mm.getParameterTypes()[0].getName().equals("android.content.Context")) { o = mm; break; }
            }
            if (o == null) return;
            o.setAccessible(true);
            Object acct = o.invoke(holderObj, app);
            if (acct == null) return;
            Object h = field(acct, "h");
            if (h == null) return;
            String[] names = {"b", "a"};
            for (String n : names) {
                Object flow = field(h, n);
                if (flow == null) continue;
                Object u = null;
                try { u = flow.getClass().getMethod("getValue").invoke(flow); } catch (Throwable ignored) {}
                if (u == null) continue;
                try {
                    Object a = u.getClass().getMethod("getAvatarURL").invoke(u);
                    Object nm = u.getClass().getMethod("getName").invoke(u);
                    if (nm instanceof String) host = (String) nm;
                    if (a instanceof String && ((String) a).length() > 0) { avatar = (String) a; return; }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            Log.w(TAG, "account", t);
        }
    }

    /** Recibe el enlace corto que creo Eclipse y devuelve el enlace propio (o el mismo si algo no cuadra). */
    public static String fix(String shareUrl) {
        try {
            String d = deep;
            String h = host;
            String a = avatar;
            deep = null; host = null; avatar = null;
            if (shareUrl == null || d == null || !d.startsWith(PREFIX)) return shareUrl;
            String id = d.substring(PREFIX.length());
            if (id.length() == 0) return shareUrl;
            StringBuilder sb = new StringBuilder(base);
            if (!base.endsWith("/")) sb.append('/');
            // enlace corto: ?i=CODIGO_DEL_JAM&a=FOTO (la foto va comprimida si es de api.eclipsemusic.app)
            sb.append("?i=").append(enc(id));
            if (a != null && a.length() > 0) {
                if (a.startsWith("/")) a = "https://api.eclipsemusic.app" + a;
                String c = shortAvatar(a);
                if (c != null) sb.append("&a=").append(c);
                else if (a.startsWith("https://")) sb.append("&a=").append(enc(a));
            }
            return sb.toString();
        } catch (Throwable t) {
            Log.w(TAG, "fix", t);
            return shareUrl;
        }
    }

    private static final Pattern AV = Pattern.compile(
        "^https://api\\.eclipsemusic\\.app/api/user/avatar/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$");

    /** UUID de la foto (36 letras) -> 22 letras (base64 sin relleno); null si la direccion no tiene ese formato. */
    private static String shortAvatar(String url) {
        try {
            Matcher m = AV.matcher(url);
            if (!m.find()) return null;
            String hex = m.group(1).replace("-", "");
            byte[] b = new byte[16];
            for (int i = 0; i < 16; i++) b[i] = (byte) Integer.parseInt(hex.substring(2 * i, 2 * i + 2), 16);
            return java.util.Base64.getUrlEncoder().withoutPadding().encodeToString(b);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * v0.20.360 (SIN COMPILAR NI PROBAR). Al abrir la app con un enlace de la pagina (https://jamlink.pages.dev/?i=CODIGO[&a=..]),
     * se cambia el dato del Intent por debridmusic://jam?id=CODIGO, que es lo que la app ya entiende. Si algo no cuadra no toca nada.
     */
    public static void rewrite(Intent it) {
        try {
            if (it == null) return;
            Uri u = it.getData();
            if (u == null) return;
            if (!"jamlink.pages.dev".equals(u.getHost())) return;
            String id = u.getQueryParameter("i");
            if (id == null || id.length() == 0) id = u.getQueryParameter("id");
            if (id == null || id.length() == 0) return;
            it.setData(Uri.parse(PREFIX + Uri.encode(id)));
        } catch (Throwable t) {
            Log.w(TAG, "rewrite", t);
        }
    }

    public static void rewriteActivity(Activity a) {
        try {
            if (a != null) rewrite(a.getIntent());
        } catch (Throwable t) {
            Log.w(TAG, "rewriteActivity", t);
        }
    }

    /**
     * v0.20.361 (SIN COMPILAR NI PROBAR). Reemplaza a Lhi9.g(url, "Jam with X", "Now playing: Y") solo en el mensaje del jam:
     * arma el mismo Intent SEND (text/plain) con el texto "Jam de X \u00b7 Sonando: Y" y el enlace abajo.
     */
    public static Intent intent(String url, String subject, String text) {
        String body;
        try {
            String name = subject == null ? "" : subject;
            if (name.startsWith("Jam with ")) name = name.substring(9);
            String song = text == null ? "" : text;
            if (song.startsWith("Now playing: ")) song = song.substring(13);
            body = "Jam de " + name + " \u00b7 Sonando: " + song + "\n" + url;
        } catch (Throwable t) {
            body = subject + " by " + text + "\n" + url;
        }
        Intent i = new Intent("android.intent.action.SEND");
        i.setType("text/plain");
        i.putExtra("android.intent.extra.TEXT", body);
        i.addFlags(0x10000000);
        return i;
    }

    private static Object field(Object o, String name) {
        try {
            Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Throwable t) {
            return s;
        }
    }
}
