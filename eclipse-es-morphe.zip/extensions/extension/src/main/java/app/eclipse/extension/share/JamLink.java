package app.eclipse.extension.share;

import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v0.20.356 (SIN COMPILAR NI PROBAR). Enlace propio para compartir un jam: en vez de https://eclipsemusic.app/s/XXXX
 * devuelve BASE?id=JAMID&s=XXXX&n=NOMBRE&a=URLFOTO. La pagina (Function de Cloudflare) pone nombre/foto en la vista previa.
 * Todo va en try/catch: si algo falla se devuelve el enlace original.
 */
public final class JamLink {
    private static final String TAG = "JamLink";
    private static final String PREFIX = "debridmusic://jam?id=";
    private static final Pattern SID = Pattern.compile("/s/([A-Za-z0-9_-]+)");

    private static volatile String base = "https://jamlink.pages.dev/";
    private static volatile String deep;
    private static volatile String host;
    private static volatile String avatar;

    private JamLink() {}

    /** Se llama al empezar a armar el mensaje de un jam: guarda el codigo del jam y busca nombre/foto de la cuenta. */
    public static void jam(String jamId) {
        try {
            avatar = null;
            host = null;
            deep = (jamId == null || jamId.length() == 0) ? null : PREFIX + jamId;
            account();
        } catch (Throwable t) {
            Log.w(TAG, "jam", t);
        }
    }

    /** Foto y nombre de la cuenta, por reflexion: fl0.m (singleton).o(contexto) -> h -> b/a -> getValue() -> User. */
    private static void account() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app == null) return;
            Class<?> k = Class.forName("fl0");
            Field fm = k.getDeclaredField("m");
            fm.setAccessible(true);
            Object holderObj = fm.get(null);
            if (holderObj == null) return;
            Method o = null;
            for (Method mm : holderObj.getClass().getDeclaredMethods()) {
                if (mm.getName().equals("o") && mm.getParameterTypes().length == 1
                        && mm.getParameterTypes()[0].getName().equals("android.content.Context")) { o = mm; break; }
            }
            if (o == null) return;
            o.setAccessible(true);
            Object acct = o.invoke(holderObj, app);
            if (acct == null) return;
            Object h = field(acct, "h");
            if (h == null) return;
            String[] names = {"b", "a"};
            for (String n : names) {
                Object flow = field(h, n);
                if (flow == null) continue;
                Object u = null;
                try { u = flow.getClass().getMethod("getValue").invoke(flow); } catch (Throwable ignored) {}
                if (u == null) continue;
                try {
                    Object a = u.getClass().getMethod("getAvatarURL").invoke(u);
                    Object nm = u.getClass().getMethod("getName").invoke(u);
                    if (nm instanceof String) host = (String) nm;
                    if (a instanceof String && ((String) a).length() > 0) { avatar = (String) a; return; }
                } catch (Throwable ignored) {}
            }
        } catch (Throwable t) {
            Log.w(TAG, "account", t);
        }
    }

    /** Recibe el enlace corto que creo Eclipse y devuelve el enlace propio (o el mismo si algo no cuadra). */
    public static String fix(String shareUrl) {
        try {
            String d = deep;
            String h = host;
            String a = avatar;
            deep = null; host = null; avatar = null;
            if (shareUrl == null || d == null || !d.startsWith(PREFIX)) return shareUrl;
            String id = d.substring(PREFIX.length());
            if (id.length() == 0) return shareUrl;
            StringBuilder sb = new StringBuilder(base);
            if (!base.endsWith("/")) sb.append('/');
            sb.append("?id=").append(enc(id));
            Matcher m = SID.matcher(shareUrl);
            if (m.find()) sb.append("&s=").append(enc(m.group(1)));
            if (h != null && h.length() > 0) sb.append("&n=").append(enc(h));
            if (a != null && a.length() > 0) {
                if (a.startsWith("/")) a = "https://api.eclipsemusic.app" + a;
                if (a.startsWith("https://")) sb.append("&a=").append(enc(a));
            }
            return sb.toString();
        } catch (Throwable t) {
            Log.w(TAG, "fix", t);
            return shareUrl;
        }
    }

    private static Object field(Object o, String name) {
        try {
            Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static String enc(String s) {
        try {
            return URLEncoder.encode(s, "UTF-8");
        } catch (Throwable t) {
            return s;
        }
    }
}
