package app.eclipse.extension.canvas;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/**
 * Ayuda del parche "Canvas: revisar el video guardado de Tidal" (v0.20.199).
 *
 * Eclipse 0.6.57 guarda los videos animados de Tidal como ARCHIVO (AnimatedArtworkCache) y, al buscarlos (ks.g), solo
 * comprueba que el archivo EXISTA. Si una descarga se corto a medias, el archivo incompleto se reutiliza: carga el primer
 * cuadro y no se reproduce. Aqui, justo despues de ks.g, se revisa el archivo; si es un mp4 incompleto se borra y se
 * devuelve null (Eclipse lo trata como "no existe" y lo vuelve a bajar). Ante cualquier duda devuelve el archivo tal cual.
 */
@SuppressWarnings("unused")
public final class TidalFileGuard {
    private static final String TAG = "TidalFileGuard";
    private static final int MAX_BOXES = 10000;

    private TidalFileGuard() {}

    public static File check(File f) {
        if (f == null) return null;
        try {
            if (isBroken(f)) {
                Log.w(TAG, "video de Tidal incompleto, se borra: " + f.getName() + " (" + f.length() + " bytes)");
                f.delete();
                return null;
            }
        } catch (Throwable t) {
            // ante la duda, el archivo se queda como estaba
        }
        return f;
    }

    /** true solo si es un mp4 (empieza con "ftyp") cuya cadena de cajas no llega exacta al final o no trae "moov", o si esta vacio. */
    static boolean isBroken(File f) throws IOException {
        if (!f.isFile()) return false;
        long len = f.length();
        if (len == 0L) return true;
        if (len < 16L) return false;
        RandomAccessFile r = new RandomAccessFile(f, "r");
        try {
            byte[] h = new byte[16];
            long pos = 0L;
            boolean first = true, sawMoov = false;
            int n = 0;
            while (pos < len) {
                if (++n > MAX_BOXES) return false;
                if (pos + 8L > len) return true;
                r.seek(pos);
                r.readFully(h, 0, 8);
                long size = ((h[0] & 0xFFL) << 24) | ((h[1] & 0xFFL) << 16) | ((h[2] & 0xFFL) << 8) | (h[3] & 0xFFL);
                boolean ftyp = h[4] == 'f' && h[5] == 't' && h[6] == 'y' && h[7] == 'p';
                boolean moov = h[4] == 'm' && h[5] == 'o' && h[6] == 'o' && h[7] == 'v';
                if (first) {
                    if (!ftyp) return false; // no es un mp4 normal: no se toca
                    first = false;
                }
                if (moov) sawMoov = true;
                if (size == 1L) {
                    if (pos + 16L > len) return true;
                    r.readFully(h, 8, 8);
                    size = 0L;
                    for (int i = 8; i < 16; i++) size = (size << 8) | (h[i] & 0xFFL);
                    if (size < 16L) return true;
                } else if (size == 0L) {
                    return !sawMoov; // la caja llega hasta el final del archivo
                } else if (size < 8L) {
                    return true;
                }
                pos += size;
                if (pos > len) return true; // caja cortada
            }
            return !sawMoov;
        } finally {
            try { r.close(); } catch (Throwable ignored) {}
        }
    }
}
