package app.eclipse.extension.artwork;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * v1.56.0: portada fija DEBAJO del Canvas mientras el video no tiene su primer cuadro.
 *
 * Eclipse dibuja el video EN LUGAR de la portada fija (rama excluyente), asi que al llegar el Canvas la portada se
 * quita de golpe y queda un hueco hasta el primer cuadro. Aqui se recuerda la portada de la cancion actual (gancho
 * {@link #seen}, en cada lectura de ow0.w) y se baja en segundo plano; {@link CoverFade} la pone como fondo de la
 * cortina (exo_shutter) del PlayerView y la desvanece cuando el video ya tiene imagen.
 * Todo por reflexion/try-catch: si algo falla no hace nada y queda el comportamiento anterior.
 */
@SuppressWarnings({"unused", "rawtypes"})
public final class CoverUnderlay {
    private static final String TAG = "CoverUnderlay";
    private static final int MAX_PX = 900;
    private static final int MAX_BYTES = 4 * 1024 * 1024;

    private static Field stSong;
    private static Method getCover;
    private static boolean reflectionTried;

    private static Object lastSong;
    private static volatile Object lastState;
    private static volatile String currentUrl;
    private static volatile int songSeq;          // v0.20.12: sube en cada cambio real de cancion
    private static String lastKey;
    private static volatile String prevUrl;        // v0.20.46: portada de la cancion anterior
    private static volatile boolean slideOn;       // v0.20.46: lo enciende el parche "Canvas: la portada que espera tambien se desliza"

    /** Gancho (smali): enciende el deslizamiento de la portada que espera al Canvas. */
    public static void enableSlide() { slideOn = true; }

    private static final LinkedHashMap<String, Bitmap> CACHE = new LinkedHashMap<String, Bitmap>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) { return size() > 4; }
    };
    private static final java.util.HashSet<String> LOADING = new java.util.HashSet<String>();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "CoverUnderlay");
            t.setDaemon(true);
            return t;
        }
    });

    private CoverUnderlay() {}

    /** Gancho (smali): justo despues de leer ow0.w. Barato: solo mira si cambio la cancion. */
    public static void seen(Object state) {
        try {
            if (state == null) return;
            lastState = state;
            if (!reflectionTried) {
                reflectionTried = true;
                try {
                    stSong = state.getClass().getDeclaredField("a");
                    stSong.setAccessible(true);
                } catch (Throwable t) { stSong = null; }
            }
            if (stSong == null) return;
            Object song = stSong.get(state);
            if (song == null || song == lastSong) return;
            lastSong = song;
            if (getCover == null) getCover = song.getClass().getMethod("getCoverURL");
            Object u = getCover.invoke(song);
            String url = (u instanceof String && ((String) u).startsWith("http")) ? (String) u : null;
            // v0.20.12: cambio REAL de cancion (no solo de objeto): clave = ISRC, o artista+duracion+portada.
            String key = songKey(song, url);
            if (key == null || !key.equals(lastKey)) {
                lastKey = key;
                prevUrl = currentUrl; // v0.20.46 (currentUrl aun es la de la cancion anterior)
                songSeq++;
            }
            currentUrl = url;
            if (url != null) prefetch(url);
        } catch (Throwable t) {
            Log.w(TAG, "seen fallo: " + t);
        }
    }

    private static Method androidView;   // r15.a(f43 factory, mh5 modifier, f43 update, ki1 composer, int) = AndroidView
    private static Class factoryType;
    private static boolean viewTried;
    private static boolean viewFailed;

    /**
     * v1.57.0: gancho (smali) en la rama "esperando primer cuadro" de xi6.h: dibuja la portada para que no haya hueco.
     * v1.58.0: primero como una vista Android (ImageView con el bitmap ya bajado), que sale en el MISMO cuadro; la carga
     * de imagen de Eclipse (by9.c) tardaba ~3 cuadros y dejaba un destello de fondo borroso. Sin bitmap listo: by9.c.
     */
    public static void drawHole(Object mod, Object composer) {
        try {
            if (mod != null && composer != null && !viewFailed) {
                final Bitmap b = cached(currentUrl);
                if (b != null && drawWithView(b, currentUrl, mod, composer)) return;
            }
        } catch (Throwable t) {
            viewFailed = true;
            Log.w(TAG, "portada en vista fallo: " + t);
        }
        try {
            app.eclipse.extension.canvas.BlurredCanvasBackground.drawHoleCover(lastState, mod, composer);
        } catch (Throwable ignored) {}
    }

    private static boolean ensureAndroidView() {
        if (!viewTried) {
            viewTried = true;
            try {
                Class f43 = Class.forName("f43");
                Class mh5 = Class.forName("mh5");
                Class ki1 = Class.forName("ki1");
                Method found = null;
                for (Method m : Class.forName("r15").getDeclaredMethods()) {
                    Class[] p = m.getParameterTypes();
                    if (m.getName().equals("a") && p.length == 5 && p[0] == f43 && p[1] == mh5 && p[2] == f43
                            && p[3] == ki1 && p[4] == int.class) { found = m; break; }
                }
                if (found != null) { found.setAccessible(true); androidView = found; factoryType = f43; }
            } catch (Throwable t) {
                Log.w(TAG, "sin AndroidView: " + t);
            }
        }
        return androidView != null;
    }

    /**
     * v0.20.10: capa negra con opacidad alpha (0..1) como vista Android; ocupa el modificador mod.
     * La llama BlurredCanvasBackground.draw al final de su grupo (debajo de la portada nitida y de textos/botones).
     * Devuelve false si no se pudo (no dibuja nada).
     */
    public static boolean drawDim(Object mod, Object composer, float alpha) {
        try {
            if (mod == null || composer == null || alpha <= 0f || !ensureAndroidView()) return false;
            final int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
            Object factory = java.lang.reflect.Proxy.newProxyInstance(factoryType.getClassLoader(),
                    new Class[]{factoryType}, new java.lang.reflect.InvocationHandler() {
                @Override public Object invoke(Object proxy, Method m, Object[] args) {
                    if (m.getName().equals("invoke") && args != null && args.length == 1
                            && args[0] instanceof android.content.Context) {
                        android.view.View v = new android.view.View((android.content.Context) args[0]);
                        v.setBackgroundColor(android.graphics.Color.argb(a, 0, 0, 0));
                        return v;
                    }
                    if (m.getName().equals("hashCode")) return System.identityHashCode(proxy);
                    if (m.getName().equals("equals")) return args != null && args.length == 1 && proxy == args[0];
                    if (m.getName().equals("toString")) return "CoverUnderlay.dimFactory";
                    return null;
                }
            });
            androidView.invoke(null, factory, mod, null, composer, 0x30);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "oscurecer fallo: " + t);
            return false;
        }
    }

    private static boolean drawWithView(final Bitmap b, final String url, Object mod, Object composer) throws Exception {
        if (!ensureAndroidView()) return false;
        Object factory = java.lang.reflect.Proxy.newProxyInstance(factoryType.getClassLoader(),
                new Class[]{factoryType}, new java.lang.reflect.InvocationHandler() {
            @Override public Object invoke(Object proxy, Method m, Object[] args) {
                if (m.getName().equals("invoke") && args != null && args.length == 1
                        && args[0] instanceof android.content.Context) {
                    android.widget.ImageView v = new android.widget.ImageView((android.content.Context) args[0]);
                    v.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
                    if (slideOn) v.setImageDrawable(new CoverDrawable(url)); // v0.20.46: con deslizamiento
                    else v.setImageBitmap(b);
                    return v;
                }
                if (m.getName().equals("hashCode")) return System.identityHashCode(proxy);
                if (m.getName().equals("equals")) return args != null && args.length == 1 && proxy == args[0];
                if (m.getName().equals("toString")) return "CoverUnderlay.factory";
                return null;
            }
        });
        androidView.invoke(null, factory, mod, null, composer, 0x30);
        return true;
    }

    /** URL de portada de la cancion actual, o null. */
    static String currentUrl() { return currentUrl; }

    /** v0.20.12: numero de cambios reales de cancion vistos. */
    static int songSeq() { return songSeq; }

    private static String songKey(Object song, String url) {
        try {
            Object isrc = song.getClass().getMethod("getIsrc").invoke(song);
            if (isrc instanceof String && !((String) isrc).isEmpty()) return "i:" + isrc;
        } catch (Throwable ignored) {}
        try {
            Object a = song.getClass().getMethod("getArtist").invoke(song);
            Object d = song.getClass().getMethod("getDuration").invoke(song);
            return "a:" + a + "|" + d + "|" + url;
        } catch (Throwable ignored) {}
        return null; // sin clave: cada objeto nuevo cuenta como cancion nueva
    }

    static Bitmap cached(String url) {
        if (url == null) return null;
        synchronized (CACHE) { return CACHE.get(url); }
    }

    private static void prefetch(final String url) {
        synchronized (CACHE) {
            if (CACHE.containsKey(url)) return;
        }
        synchronized (LOADING) {
            if (!LOADING.add(url)) return;
        }
        EXEC.execute(new Runnable() {
            @Override public void run() {
                try {
                    Bitmap b = download(url);
                    if (b != null) {
                        synchronized (CACHE) { CACHE.put(url, b); }
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "descarga fallo: " + t);
                } finally {
                    synchronized (LOADING) { LOADING.remove(url); }
                }
            }
        });
    }

    private static Bitmap download(String url) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > MAX_BYTES) return null;
                }
                byte[] data = out.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, o);
                int sample = 1;
                int big = Math.max(o.outWidth, o.outHeight);
                while (big / (sample * 2) >= MAX_PX) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
            } finally {
                in.close();
            }
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Drawable que dibuja la portada recortada al centro (como ZOOM); si aun no esta bajada, no dibuja nada y se redibuja al llegar. */
    static final class CoverDrawable extends Drawable {
        private final String url;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Matrix matrix = new Matrix();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private Bitmap bmp;
        private int polls;
        // v0.20.46: deslizamiento (la portada anterior sale, la nueva entra) con el reloj de PrevCover
        private boolean slide;
        private final int evt;
        private final Bitmap prevBmp;

        CoverDrawable(String url) {
            this.url = url;
            this.bmp = cached(url);
            boolean sl = false;
            int ev = 0;
            Bitmap pb = null;
            try {
                String pu = prevUrl;
                if (slideOn && pu != null && !pu.equals(url) && app.eclipse.extension.artwork.PrevCover.wantsSlide()) {
                    pb = cached(pu);
                    ev = app.eclipse.extension.artwork.PrevCover.curEvt();
                    sl = pb != null && ev != 0;
                }
            } catch (Throwable ignored) {}
            this.slide = sl;
            this.evt = ev;
            this.prevBmp = pb;
            if (bmp == null) waitForBitmap();
        }

        private void waitForBitmap() {
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        Bitmap b = cached(url);
                        if (b != null) { bmp = b; invalidateSelf(); return; }
                        if (++polls < 40) handler.postDelayed(this, 50L);
                    } catch (Throwable ignored) {}
                }
            }, 50L);
        }

        @Override public void draw(Canvas canvas) {
            Rect b = getBounds();
            if (slide) {
                try {
                    float e = app.eclipse.extension.artwork.PrevCover.slideProgress(evt, bmp != null);
                    if (e < 0f) {
                        slide = false;
                    } else if (bmp == null) { // la nueva aun no llego: la vieja queda quieta
                        drawCropped(canvas, prevBmp, b, paint, matrix);
                        invalidateSelf();
                        return;
                    } else {
                        int dir = app.eclipse.extension.artwork.PrevCover.slideDir();
                        float dist = android.content.res.Resources.getSystem().getDisplayMetrics().widthPixels;
                        if (dist <= 0f) dist = b.width();
                        float cx = (b.left + b.right) / 2f;
                        float seam = cx + dir * (dist / 2f - e * dist);
                        float lo = b.left - 4f * dist, hi = b.right + 4f * dist;
                        int sv = canvas.save();
                        if (dir > 0) canvas.clipRect(lo, b.top, seam, b.bottom); else canvas.clipRect(seam, b.top, hi, b.bottom);
                        canvas.translate(-dir * e * dist, 0f);
                        drawCropped(canvas, prevBmp, b, paint, matrix);
                        canvas.restoreToCount(sv);
                        sv = canvas.save();
                        if (dir > 0) canvas.clipRect(seam, b.top, hi, b.bottom); else canvas.clipRect(lo, b.top, seam, b.bottom);
                        canvas.translate(dir * (1f - e) * dist, 0f);
                        drawCropped(canvas, bmp, b, paint, matrix);
                        canvas.restoreToCount(sv);
                        invalidateSelf();
                        return;
                    }
                } catch (Throwable t) {
                    slide = false;
                }
            }
            drawCropped(canvas, bmp, b, paint, matrix);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Dibuja b recortada al centro (como ZOOM) dentro de r. */
    static void drawCropped(Canvas canvas, Bitmap b, Rect r, Paint paint, Matrix matrix) {
        if (b == null || r.width() <= 0 || r.height() <= 0) return;
        float s = Math.max(r.width() / (float) b.getWidth(), r.height() / (float) b.getHeight());
        float dx = r.left + (r.width() - b.getWidth() * s) / 2f;
        float dy = r.top + (r.height() - b.getHeight() * s) / 2f;
        matrix.reset();
        matrix.setScale(s, s);
        matrix.postTranslate(dx, dy);
        int save = canvas.save();
        canvas.clipRect(r);
        canvas.drawBitmap(b, matrix, paint);
        canvas.restoreToCount(save);
    }
}
