package app.eclipse.extension.artwork;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

/**
 * v1.56.0: portada fija DEBAJO del Canvas mientras el video no tiene su primer cuadro.
 *
 * Eclipse dibuja el video EN LUGAR de la portada fija (rama excluyente), asi que al llegar el Canvas la portada se
 * quita de golpe y queda un hueco hasta el primer cuadro. Aqui se recuerda la portada de la cancion actual (gancho
 * {@link #seen}, en cada lectura de ow0.w) y se baja en segundo plano; {@link CoverFade} la pone como fondo de la
 * cortina (exo_shutter) del PlayerView y la desvanece cuando el video ya tiene imagen.
 * Todo por reflexion/try-catch: si algo falla no hace nada y queda el comportamiento anterior.
 */
@SuppressWarnings({"unused", "rawtypes"})
public final class CoverUnderlay {
    private static final String TAG = "CoverUnderlay";
    private static final int MAX_PX = 900;
    private static final int MAX_BYTES = 4 * 1024 * 1024;

    private static Field stSong;
    private static Method getCover;
    private static boolean reflectionTried;

    private static Object lastSong;
    private static volatile String currentUrl;

    private static final LinkedHashMap<String, Bitmap> CACHE = new LinkedHashMap<String, Bitmap>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Bitmap> eldest) { return size() > 4; }
    };
    private static final java.util.HashSet<String> LOADING = new java.util.HashSet<String>();
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "CoverUnderlay");
            t.setDaemon(true);
            return t;
        }
    });

    private CoverUnderlay() {}

    /** Gancho (smali): justo despues de leer ow0.w. Barato: solo mira si cambio la cancion. */
    public static void seen(Object state) {
        try {
            if (state == null) return;
            if (!reflectionTried) {
                reflectionTried = true;
                try {
                    stSong = state.getClass().getDeclaredField("a");
                    stSong.setAccessible(true);
                } catch (Throwable t) { stSong = null; }
            }
            if (stSong == null) return;
            Object song = stSong.get(state);
            if (song == null || song == lastSong) return;
            lastSong = song;
            if (getCover == null) getCover = song.getClass().getMethod("getCoverURL");
            Object u = getCover.invoke(song);
            String url = (u instanceof String && ((String) u).startsWith("http")) ? (String) u : null;
            currentUrl = url;
            if (url != null) prefetch(url);
        } catch (Throwable t) {
            Log.w(TAG, "seen fallo: " + t);
        }
    }

    /** URL de portada de la cancion actual, o null. */
    static String currentUrl() { return currentUrl; }

    static Bitmap cached(String url) {
        if (url == null) return null;
        synchronized (CACHE) { return CACHE.get(url); }
    }

    private static void prefetch(final String url) {
        synchronized (CACHE) {
            if (CACHE.containsKey(url)) return;
        }
        synchronized (LOADING) {
            if (!LOADING.add(url)) return;
        }
        EXEC.execute(new Runnable() {
            @Override public void run() {
                try {
                    Bitmap b = download(url);
                    if (b != null) {
                        synchronized (CACHE) { CACHE.put(url, b); }
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "descarga fallo: " + t);
                } finally {
                    synchronized (LOADING) { LOADING.remove(url); }
                }
            }
        });
    }

    private static Bitmap download(String url) throws Exception {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > MAX_BYTES) return null;
                }
                byte[] data = out.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, o);
                int sample = 1;
                int big = Math.max(o.outWidth, o.outHeight);
                while (big / (sample * 2) >= MAX_PX) sample *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = sample;
                return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
            } finally {
                in.close();
            }
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Drawable que dibuja la portada recortada al centro (como ZOOM); si aun no esta bajada, no dibuja nada y se redibuja al llegar. */
    static final class CoverDrawable extends Drawable {
        private final String url;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private final Matrix matrix = new Matrix();
        private final Handler handler = new Handler(Looper.getMainLooper());
        private Bitmap bmp;
        private int polls;

        CoverDrawable(String url) {
            this.url = url;
            this.bmp = cached(url);
            if (bmp == null) waitForBitmap();
        }

        private void waitForBitmap() {
            handler.postDelayed(new Runnable() {
                @Override public void run() {
                    try {
                        Bitmap b = cached(url);
                        if (b != null) { bmp = b; invalidateSelf(); return; }
                        if (++polls < 40) handler.postDelayed(this, 50L);
                    } catch (Throwable ignored) {}
                }
            }, 50L);
        }

        @Override public void draw(Canvas canvas) {
            Bitmap b = bmp;
            if (b == null) return;
            Rect r = getBounds();
            if (r.width() <= 0 || r.height() <= 0) return;
            float s = Math.max(r.width() / (float) b.getWidth(), r.height() / (float) b.getHeight());
            float dx = r.left + (r.width() - b.getWidth() * s) / 2f;
            float dy = r.top + (r.height() - b.getHeight() * s) / 2f;
            matrix.reset();
            matrix.setScale(s, s);
            matrix.postTranslate(dx, dy);
            int save = canvas.save();
            canvas.clipRect(r);
            canvas.drawBitmap(b, matrix, paint);
            canvas.restoreToCount(save);
        }

        @Override public void setAlpha(int alpha) { paint.setAlpha(alpha); }
        @Override public void setColorFilter(ColorFilter colorFilter) { paint.setColorFilter(colorFilter); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
