package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * v0.20.231 DIAGNOSTICO TEMPORAL (parche "Diagnostico: registro de pestanas"). Anota con hora (ms desde el primer evento
 * del toque) cada llamada a s31.d (cambio de pestana, con quien la llamo), cada paso de la corrutina a0.b (snapTo / animateTo,
 * con el valor de d), cada vez que se llena la lista de Cola (t50.y) y cada vez que se dibuja el cartel "Nada a continuacion"
 * (t50.j). 1,2 s despues del ultimo evento copia TODO el registro al portapapeles. Una pausa de mas de 2,5 s empieza un
 * bloque nuevo. Todo con try/catch: si algo falla, no hace nada.
 */
public final class TabDiag {
    private static final String TAG = "TabDiag";
    private static final long GAP_MS = 2500L;
    private static final long COPY_DELAY_MS = 1200L;
    private static final int MAX_LINES = 90;

    private static final ArrayList<String> lines = new ArrayList<>();
    private static long t0 = 0L;
    private static long last = 0L;
    private static Handler handler;
    private static final Runnable COPY = new Runnable() {
        @Override public void run() { copiar(); }
    };

    private TabDiag() {}

    // ---- ganchos (los llama el parche) ----

    /** Inicio de s31.d(String): this, pestana pedida. */
    public static void d(Object s31, String tab) {
        try {
            ev("s31.d(\"" + tab + "\") actual=" + pestana(s31) + " d=" + valorD(s31) + " via " + quien());
        } catch (Throwable t) { Log.w(TAG, "d", t); }
    }

    /** Inicio de s31.c(): f=false, g++ . */
    public static void c(Object s31) {
        try {
            ev("s31.c() (f=false, g++) via " + quien());
        } catch (Throwable t) { Log.w(TAG, "c", t); }
    }

    /** Inicio de a0.b(Object): un paso de la corrutina del fundido (s=0 antes de snapTo, 1 antes de animateTo, 2 al terminar). */
    public static void a0(Object a0) {
        try {
            Object s31 = leer(a0, "u");
            ev("a0.b paso=" + leer(a0, "s") + " d=" + valorD(s31) + " pestana=" + pestana(s31));
        } catch (Throwable t) { Log.w(TAG, "a0", t); }
    }

    /** Inicio de t50.y: se vacia y se llena la lista de la Cola. */
    public static void llenar() {
        try { ev("t50.y: lista de Cola llenada"); } catch (Throwable t) { Log.w(TAG, "llenar", t); }
    }

    /** Inicio de t50.j: se dibuja el cartel "Nada a continuacion". */
    public static void nada() {
        try { ev("t50.j: CARTEL 'Nada a continuacion' dibujado"); } catch (Throwable t) { Log.w(TAG, "nada", t); }
    }

    // ---- interno ----

    private static synchronized void ev(String msg) {
        long now = SystemClock.uptimeMillis();
        if (lines.isEmpty() || now - last > GAP_MS) {
            if (!lines.isEmpty()) lines.add("-----");
            t0 = now;
        }
        last = now;
        String l = "+" + (now - t0) + " ms  [" + Thread.currentThread().getName() + "]  " + msg;
        lines.add(l);
        while (lines.size() > MAX_LINES) lines.remove(0);
        Log.w(TAG, l);
        if (handler == null) handler = new Handler(Looper.getMainLooper());
        handler.removeCallbacks(COPY);
        handler.postDelayed(COPY, COPY_DELAY_MS);
    }

    private static void copiar() {
        try {
            String texto;
            synchronized (TabDiag.class) {
                StringBuilder sb = new StringBuilder("TabDiag v0.20.231\n");
                for (String l : lines) sb.append(l).append('\n');
                texto = sb.toString();
            }
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app == null) return;
            ClipboardManager cm = (ClipboardManager) ((Context) app).getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("TabDiag", texto));
        } catch (Throwable t) { Log.w(TAG, "copiar", t); }
    }

    private static String quien() {
        StringBuilder sb = new StringBuilder();
        StackTraceElement[] st = new Throwable().getStackTrace();
        int n = 0;
        for (StackTraceElement e : st) {
            String c = e.getClassName();
            if (c.startsWith("app.eclipse.extension.player.TabDiag")) continue;
            if (c.equals("s31")) continue;
            if (n++ >= 5) break;
            if (n > 1) sb.append(" < ");
            sb.append(c).append('.').append(e.getMethodName()).append(':').append(e.getLineNumber());
        }
        return sb.toString();
    }

    private static Object leer(Object o, String campo) throws Exception {
        if (o == null) return null;
        Field f = o.getClass().getDeclaredField(campo);
        f.setAccessible(true);
        return f.get(o);
    }

    private static String pestana(Object s31) {
        try {
            Method m = s31.getClass().getDeclaredMethod("a");
            m.setAccessible(true);
            return String.valueOf(m.invoke(s31));
        } catch (Throwable t) { return "?"; }
    }

    private static String valorD(Object s31) {
        try {
            Object anim = leer(s31, "d");
            Method m = anim.getClass().getDeclaredMethod("d");
            m.setAccessible(true);
            return String.valueOf(m.invoke(anim));
        } catch (Throwable t) { return "?"; }
    }
}
