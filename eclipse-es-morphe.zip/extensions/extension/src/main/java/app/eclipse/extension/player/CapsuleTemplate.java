package app.eclipse.extension.player;

import org.json.JSONObject;

/** Tarjeta "Cápsule" (ordinal 8 del enum de Reproductores integrados). Se apoya en BitchordTemplate para el resto. */
public final class CapsuleTemplate {
    private CapsuleTemplate() {}

    /** Nombre del diseno interno de la tarjeta (se oculta de "Your Custom Players"). */
    static final String CARD_NAME = "Capsule 1 (integrado)";

    public static JSONObject json() {
        try {
            return new JSONObject(CapsuleDesign.json());
        } catch (Exception e) {
            throw new RuntimeException("Capsule: JSON invalido", e);
        }
    }

    public static JSONObject jsonCard() {
        JSONObject o = json();
        try {
            o.put("name", CARD_NAME);
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Id del diseno interno de la tarjeta Capsule entre los disenos del usuario, o null. */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                if (CARD_NAME.equals(BitchordTemplate.field(d, "b"))) {
                    Object id = BitchordTemplate.field(d, "a");
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
