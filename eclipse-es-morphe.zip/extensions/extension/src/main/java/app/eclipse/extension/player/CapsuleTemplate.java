package app.eclipse.extension.player;

import org.json.JSONObject;

/** Tarjeta "Cápsule" (ordinal 8 del enum de Reproductores integrados). Se apoya en BitchordTemplate para el resto. v0.20.412: se renueva sola (BitchordTemplate.refreshExtra). */
public final class CapsuleTemplate {
    private CapsuleTemplate() {}

    /** Nombre del diseno interno de la tarjeta (se oculta de "Your Custom Players"). */
    static final String CARD_NAME = "Capsule 1 (integrado)";
    /** v0.20.333: con el parche de la portada que crece activo se usa otro nombre (el diseno ya guardado no se renueva solo). */
    static final String CARD_NAME_MORPH = "Capsule 2 animada (integrado)";

    private static String cardName() {
        return BitchordTemplate.morphMode ? CARD_NAME_MORPH : CARD_NAME;
    }

    public static JSONObject json() {
        try {
            return BitchordLyrics.applyFinishedCapsule(new JSONObject(CapsuleDesign.json()));
        } catch (Exception e) {
            throw new RuntimeException("Capsule: JSON invalido", e);
        }
    }

    public static JSONObject jsonCard() {
        JSONObject o = json();
        try {
            o.put("name", cardName());
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Id del diseno interno de la tarjeta Capsule entre los disenos del usuario, o null. */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                if (cardName().equals(BitchordTemplate.field(d, "b"))) {
                    Object id = BitchordTemplate.field(d, "a");
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
