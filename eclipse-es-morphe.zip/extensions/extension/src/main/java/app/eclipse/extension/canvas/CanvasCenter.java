package app.eclipse.extension.canvas;

import android.util.Log;
import android.view.View;

/**
 * Centra los Canvas VERTICALES (Spotify, 9:16) en la parte VISIBLE de su caja.
 *
 * El PlayerView de la portada animada usa resizeMode ZOOM: el video se agranda hasta llenar la caja y se recorta
 * desde el centro DE LA CAJA. Pero en los players inmersivos la caja empieza por encima de la pantalla (y negativa),
 * asi que el centro de la caja queda mas arriba que el centro de lo que se ve, y el video sale corrido hacia arriba
 * y cortado. Aqui se mueve el marco del video (exo_content_frame) hacia abajo la mitad de lo que la caja se sale por
 * arriba, sin pasarse del sobrante que ZOOM ya tiene (para no dejar franjas vacias).
 *
 * v1.36.0: ademas inclina el recorte hacia arriba (TOP_BIAS) en TODOS los players. Solo actua si el video es vertical (ancho/alto del marco < 0.8) y la caja se sale por arriba. Los demas casos
 * (portadas cuadradas o horizontales, cajas dentro de la pantalla) quedan exactamente como estaban.
 * Si algo falla, no hace nada. Se llama desde CoverFade.prepare (sin ganchos nuevos).
 */
public final class CanvasCenter {
    private static final String TAG = "CanvasCenter";
    private static final float PORTRAIT_MAX = 0.8f;
    /**
     * v1.36.0: cuanto del sobrante de ZOOM se baja el video (0 = recorte centrado como antes, 1 = pegado arriba, sin
     * perder nada de la parte de arriba). Los Canvas de Spotify llevan lo importante en la parte alta, y el recorte
     * centrado se la comia. 0.5 sale de estimar la captura de Rumours en el player cuadrado (~120 de ~244 px).
     */
    private static final float TOP_BIAS = 0.5f;
    /**
     * v1.37.0: igual que TOP_BIAS pero para cajas ALTAS (alto > 1.2 x ancho, los players inmersivos). Comparando con el
     * Eclipse oficial (casco de Podemos a y=165 en el oficial vs y=130 aqui) el video debe bajar ~35 px: con un sobrante
     * de ~190 px eso es subir de 0.5 a ~0.7. Las cajas cuadradas se quedan en TOP_BIAS (le gustaba como estaba).
     */
    private static final float TOP_BIAS_TALL = 0.5f; // v1.40.0: vuelve a 0.5 (igual que v1.36.0); el usuario no pidio mover el video de arriba
    /**
     * v1.38.0: para la parte DIFUMINADA de abajo (el reflejo de BlurredCanvasBackground). Esa caja va VOLTEADA en
     * vertical, asi que mover el marco hacia abajo en la vista lo sube en pantalla: con 0.5/0.7 el video borroso
     * quedaba ~100 px mas arriba que en el Eclipse oficial. Con un valor menor baja en pantalla. Se reconoce porque
     * su caja se pasa del fondo de la pantalla (BlurredCanvasBackground la estira 100 dp mas alla).
     */
    private static final float REFLECT_BIAS = -0.8f;
    // v1.39.0: 0.2 bajo solo ~18 px (el sobrante de ZOOM del reflejo es chico, ~90 px). Negativo = el reflejo baja
    // todavia mas en pantalla (por ir volteado); -1 seria el tope sin dejar franja vacia. Mas alla de eso hay que
    // mover la caja (y se arriesga la costura del fundido).
    /** dp que la caja debe pasarse del fondo de la pantalla para contarla como el reflejo (la real se pasa 100). */
    private static final float REFLECT_PAST_DP = 50f;

    private CanvasCenter() {}

    public static void attach(final View playerView) {
        try {
            if (playerView == null) return;
            final Runnable run = new Runnable() {
                @Override public void run() { apply(playerView); }
            };
            View.OnLayoutChangeListener l = new View.OnLayoutChangeListener() {
                @Override public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                                     int oldL, int oldT, int oldR, int oldB) {
                    if (left != oldL || top != oldT || right != oldR || bottom != oldB) v.post(run);
                }
            };
            playerView.addOnLayoutChangeListener(l);
            View frame = frameOf(playerView);
            if (frame != null) frame.addOnLayoutChangeListener(l);
            playerView.post(run);
            playerView.postDelayed(run, 300L);
            playerView.postDelayed(run, 1200L);
        } catch (Throwable t) {
            Log.w(TAG, "attach fallo: " + t);
        }
    }

    private static View frameOf(View playerView) {
        int id = playerView.getResources().getIdentifier("exo_content_frame", "id",
                playerView.getContext().getPackageName());
        return id == 0 ? null : playerView.findViewById(id);
    }

    private static void apply(View playerView) {
        try {
            View frame = frameOf(playerView);
            if (frame == null) return;
            int vh = playerView.getHeight();
            int fw = frame.getWidth();
            int fh = frame.getHeight();
            if (vh <= 0 || fw <= 0 || fh <= 0) return;
            float aspect = (float) fw / (float) fh;
            float dy = 0f;
            if (aspect < PORTRAIT_MAX) {
                float room = (fh - vh) / 2f;   // sobrante de ZOOM por arriba y por abajo
                if (room < 0f) room = 0f;
                int[] loc = new int[2];
                playerView.getLocationOnScreen(loc);
                float top = loc[1];
                android.util.DisplayMetrics dm = playerView.getResources().getDisplayMetrics();
                boolean reflection = top + vh > dm.heightPixels + REFLECT_PAST_DP * dm.density;
                if (reflection) {
                    dy = room * REFLECT_BIAS;
                } else {
                    int vw = playerView.getWidth();
                    boolean tall = vw > 0 && vh > vw * 1.2f;
                    dy = room * (tall ? TOP_BIAS_TALL : TOP_BIAS);
                    // Si la caja se sale por arriba de la pantalla (players inmersivos), centrar en lo visible como minimo.
                    if (top < 0f && -top / 2f > dy) dy = -top / 2f;
                }
                if (dy > room) dy = room;
            }
            frame.setTranslationY(dy);
            Log.i(TAG, "aspect=" + aspect + " vh=" + vh + " fh=" + fh + " dy=" + dy);
        } catch (Throwable t) {
            Log.w(TAG, "apply fallo: " + t);
        }
    }
}
