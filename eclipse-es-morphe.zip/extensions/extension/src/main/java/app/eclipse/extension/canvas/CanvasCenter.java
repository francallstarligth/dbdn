package app.eclipse.extension.canvas;

import android.util.Log;
import android.view.View;

/**
 * Centra los Canvas VERTICALES (Spotify, 9:16) en la parte VISIBLE de su caja.
 *
 * El PlayerView de la portada animada usa resizeMode ZOOM: el video se agranda hasta llenar la caja y se recorta
 * desde el centro DE LA CAJA. Pero en los players inmersivos la caja empieza por encima de la pantalla (y negativa),
 * asi que el centro de la caja queda mas arriba que el centro de lo que se ve, y el video sale corrido hacia arriba
 * y cortado. Aqui se mueve el marco del video (exo_content_frame) hacia abajo la mitad de lo que la caja se sale por
 * arriba, sin pasarse del sobrante que ZOOM ya tiene (para no dejar franjas vacias).
 *
 * Solo actua si el video es vertical (ancho/alto del marco < 0.8) y la caja se sale por arriba. Los demas casos
 * (portadas cuadradas o horizontales, cajas dentro de la pantalla) quedan exactamente como estaban.
 * Si algo falla, no hace nada. Se llama desde CoverFade.prepare (sin ganchos nuevos).
 */
public final class CanvasCenter {
    private static final String TAG = "CanvasCenter";
    private static final float PORTRAIT_MAX = 0.8f;

    private CanvasCenter() {}

    public static void attach(final View playerView) {
        try {
            if (playerView == null) return;
            final Runnable run = new Runnable() {
                @Override public void run() { apply(playerView); }
            };
            View.OnLayoutChangeListener l = new View.OnLayoutChangeListener() {
                @Override public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                                     int oldL, int oldT, int oldR, int oldB) {
                    if (left != oldL || top != oldT || right != oldR || bottom != oldB) v.post(run);
                }
            };
            playerView.addOnLayoutChangeListener(l);
            View frame = frameOf(playerView);
            if (frame != null) frame.addOnLayoutChangeListener(l);
            playerView.post(run);
            playerView.postDelayed(run, 300L);
            playerView.postDelayed(run, 1200L);
        } catch (Throwable t) {
            Log.w(TAG, "attach fallo: " + t);
        }
    }

    private static View frameOf(View playerView) {
        int id = playerView.getResources().getIdentifier("exo_content_frame", "id",
                playerView.getContext().getPackageName());
        return id == 0 ? null : playerView.findViewById(id);
    }

    private static void apply(View playerView) {
        try {
            View frame = frameOf(playerView);
            if (frame == null) return;
            int vh = playerView.getHeight();
            int fw = frame.getWidth();
            int fh = frame.getHeight();
            if (vh <= 0 || fw <= 0 || fh <= 0) return;
            float aspect = (float) fw / (float) fh;
            float dy = 0f;
            if (aspect < PORTRAIT_MAX) {
                int[] loc = new int[2];
                playerView.getLocationOnScreen(loc);
                float top = loc[1];
                if (top < 0f) dy = -top / 2f;
                float room = (fh - vh) / 2f;   // sobrante de ZOOM por arriba y por abajo
                if (room < 0f) room = 0f;
                if (dy > room) dy = room;
            }
            frame.setTranslationY(dy);
            Log.i(TAG, "aspect=" + aspect + " vh=" + vh + " fh=" + fh + " dy=" + dy);
        } catch (Throwable t) {
            Log.w(TAG, "apply fallo: " + t);
        }
    }
}
