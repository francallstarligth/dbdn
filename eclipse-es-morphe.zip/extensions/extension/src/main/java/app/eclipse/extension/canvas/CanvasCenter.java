package app.eclipse.extension.canvas;

import android.util.Log;
import android.view.View;

/**
 * Centra los Canvas VERTICALES (Spotify, 9:16) en la parte VISIBLE de su caja.
 *
 * El PlayerView de la portada animada usa resizeMode ZOOM: el video se agranda hasta llenar la caja y se recorta
 * desde el centro DE LA CAJA. Pero en los players inmersivos la caja empieza por encima de la pantalla (y negativa),
 * asi que el centro de la caja queda mas arriba que el centro de lo que se ve, y el video sale corrido hacia arriba
 * y cortado. Aqui se mueve el marco del video (exo_content_frame) hacia abajo la mitad de lo que la caja se sale por
 * arriba, sin pasarse del sobrante que ZOOM ya tiene (para no dejar franjas vacias).
 *
 * v1.36.0: ademas inclina el recorte hacia arriba (TOP_BIAS) en TODOS los players. Solo actua si el video es vertical (ancho/alto del marco < 0.8) y la caja se sale por arriba. Los demas casos
 * (portadas cuadradas o horizontales, cajas dentro de la pantalla) quedan exactamente como estaban.
 * Si algo falla, no hace nada. Se llama desde CoverFade.prepare (sin ganchos nuevos).
 */
public final class CanvasCenter {
    private static final String TAG = "CanvasCenter";
    private static final float PORTRAIT_MAX = 0.8f;
    /**
     * v1.36.0: cuanto del sobrante de ZOOM se baja el video (0 = recorte centrado como antes, 1 = pegado arriba, sin
     * perder nada de la parte de arriba). Los Canvas de Spotify llevan lo importante en la parte alta, y el recorte
     * centrado se la comia. 0.5 sale de estimar la captura de Rumours en el player cuadrado (~120 de ~244 px).
     */
    private static final float TOP_BIAS = 0.5f;
    /**
     * v1.37.0: igual que TOP_BIAS pero para cajas ALTAS (alto > 1.2 x ancho, los players inmersivos). Comparando con el
     * Eclipse oficial (casco de Podemos a y=165 en el oficial vs y=130 aqui) el video debe bajar ~35 px: con un sobrante
     * de ~190 px eso es subir de 0.5 a ~0.7. Las cajas cuadradas se quedan en TOP_BIAS (le gustaba como estaba).
     */
    private static final float TOP_BIAS_TALL = 0.5f; // v1.40.0: vuelve a 0.5 (igual que v1.36.0); el usuario no pidio mover el video de arriba
    /**
     * v1.38.0: para la parte DIFUMINADA de abajo (el reflejo de BlurredCanvasBackground). Esa caja va VOLTEADA en
     * vertical, asi que mover el marco hacia abajo en la vista lo sube en pantalla: con 0.5/0.7 el video borroso
     * quedaba ~100 px mas arriba que en el Eclipse oficial. Con un valor menor baja en pantalla. Se reconoce porque
     * su caja se pasa del fondo de la pantalla (BlurredCanvasBackground la estira 100 dp mas alla).
     */
    private static final float REFLECT_BIAS = -0.8f;
    // v1.39.0: 0.2 bajo solo ~18 px (el sobrante de ZOOM del reflejo es chico, ~90 px). Negativo = el reflejo baja
    // todavia mas en pantalla (por ir volteado); -1 seria el tope sin dejar franja vacia. Mas alla de eso hay que
    // mover la caja (y se arriesga la costura del fundido).
    /** dp que la caja debe pasarse del fondo de la pantalla para contarla como el reflejo (la real se pasa 100). */
    private static final float REFLECT_PAST_DP = 50f;

    private CanvasCenter() {}

    // v0.20.339: DIAGNOSTICO TEMPORAL (QUITAR): vistas de video conocidas, para ver si siguen el tamano pedido
    private static final java.util.ArrayList<java.lang.ref.WeakReference<View>> VIEWS = new java.util.ArrayList<java.lang.ref.WeakReference<View>>();

    static synchronized String snapshot() {
        StringBuilder sb = new StringBuilder();
        try {
            for (int i = VIEWS.size() - 1; i >= 0; i--) {
                View v = VIEWS.get(i).get();
                if (v == null) { VIEWS.remove(i); continue; }
                if (!v.isAttachedToWindow()) continue;
                sb.append("video#").append(System.identityHashCode(v)).append(' ').append(v.getWidth()).append('x').append(v.getHeight())
                        .append(" a=").append(v.getAlpha()).append("; ");
            }
        } catch (Throwable ignored) {}
        return sb.length() == 0 ? "(ninguna)" : sb.toString();
    }

    public static void attach(final View playerView) {
        try {
            if (playerView == null) return;
            synchronized (CanvasCenter.class) { VIEWS.add(new java.lang.ref.WeakReference<View>(playerView)); while (VIEWS.size() > 8) VIEWS.remove(0); } // v0.20.339: diagnostico
            final Runnable run = new Runnable() {
                @Override public void run() { apply(playerView); }
            };
            final int vid = System.identityHashCode(playerView); // v0.20.334: DIAGNOSTICO TEMPORAL (QUITAR)
            try {
                ResizeDiag.log(null, "video#" + vid + " attach " + playerView.getWidth() + "x" + playerView.getHeight());
                playerView.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
                    @Override public void onViewAttachedToWindow(View v) { ResizeDiag.log(null, "video#" + vid + " ATTACHED " + v.getWidth() + "x" + v.getHeight()); }
                    @Override public void onViewDetachedFromWindow(View v) { ResizeDiag.log(null, "video#" + vid + " DETACHED"); }
                });
            } catch (Throwable ignored) {}
            View.OnLayoutChangeListener l = new View.OnLayoutChangeListener() {
                @Override public void onLayoutChange(View v, int left, int top, int right, int bottom,
                                                     int oldL, int oldT, int oldR, int oldB) {
                    try { // v0.20.334: DIAGNOSTICO TEMPORAL (QUITAR)
                        if (left != oldL || top != oldT || right != oldR || bottom != oldB) {
                            ResizeDiag.log(null, "video#" + vid + " layout " + (right - left) + "x" + (bottom - top) + " en (" + left + "," + top
                                    + ") antes " + (oldR - oldL) + "x" + (oldB - oldT) + " alpha=" + v.getAlpha() + " vis=" + v.getVisibility());
                        }
                    } catch (Throwable ignored) {}
                    if (left != oldL || top != oldT || right != oldR || bottom != oldB) v.post(run);
                }
            };
            playerView.addOnLayoutChangeListener(l);
            View frame = frameOf(playerView);
            if (frame != null) frame.addOnLayoutChangeListener(l);
            playerView.post(run);
            playerView.postDelayed(run, 300L);
            playerView.postDelayed(run, 1200L);
        } catch (Throwable t) {
            Log.w(TAG, "attach fallo: " + t);
        }
    }

    private static View frameOf(View playerView) {
        int id = playerView.getResources().getIdentifier("exo_content_frame", "id",
                playerView.getContext().getPackageName());
        return id == 0 ? null : playerView.findViewById(id);
    }

    private static void apply(View playerView) {
        try {
            View frame = frameOf(playerView);
            if (frame == null) return;
            int vh = playerView.getHeight();
            int fw = frame.getWidth();
            int fh = frame.getHeight();
            if (vh <= 0 || fw <= 0 || fh <= 0) return;
            float aspect = (float) fw / (float) fh;
            float dy = 0f;
            if (aspect < PORTRAIT_MAX) {
                float room = (fh - vh) / 2f;   // sobrante de ZOOM por arriba y por abajo
                if (room < 0f) room = 0f;
                int[] loc = new int[2];
                playerView.getLocationOnScreen(loc);
                float top = loc[1];
                android.util.DisplayMetrics dm = playerView.getResources().getDisplayMetrics();
                // v0.20.56: si la vista es la caja chica del reflejo liviano, mide 1/k de lo real
                float k = app.eclipse.extension.artwork.CoverFade.kFor(playerView.getWidth(), vh);
                // v0.20.56: con el reflejo liviano la vista es k veces mas chica y se estira desde su centro: se usa el tamano real.
                float vhReal = vh * k;
                float topReal = top + vh / 2f - vhReal / 2f;
                boolean reflection = topReal + vhReal > dm.heightPixels + REFLECT_PAST_DP * dm.density;
                if (reflection) {
                    dy = room * REFLECT_BIAS;
                } else {
                    int vw = playerView.getWidth();
                    boolean tall = vw > 0 && vh > vw * 1.2f;
                    dy = room * (tall ? TOP_BIAS_TALL : TOP_BIAS);
                    // Si la caja se sale por arriba de la pantalla (players inmersivos), centrar en lo visible como minimo.
                    if (top < 0f && -top / 2f > dy) dy = -top / 2f;
                }
                if (dy > room) dy = room;
            }
            frame.setTranslationY(dy);
            try { // v0.20.334: DIAGNOSTICO TEMPORAL (QUITAR)
                android.util.DisplayMetrics dmx = playerView.getResources().getDisplayMetrics();
                int[] lx = new int[2];
                playerView.getLocationOnScreen(lx);
                ResizeDiag.log(null, "video#" + System.identityHashCode(playerView) + " apply vista=" + playerView.getWidth() + "x" + vh
                        + " pantallaY=" + lx[1] + " marco=" + fw + "x" + fh + " dy=" + dy + " pantalla=" + dmx.widthPixels + "x" + dmx.heightPixels);
            } catch (Throwable ignored) {}
        } catch (Throwable t) {
            Log.w(TAG, "apply fallo: " + t);
        }
    }
}
