package app.eclipse.extension.ai;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * v0.20.235 (SIN COMPILAR NI PROBAR por el autor; solo javac). Parche "IA gratis: pedir llave al servidor puente".
 *
 * Eclipse 0.6.61 genera el texto de Umbra y del DJ en SU servidor (api.eclipsemusic.app), con la llave de IA del usuario
 * guardada en un "vault" (PUT /api/user/credentials {"aiKeys": {"groq": "..."}}). Si el usuario no puso ninguna llave, no
 * funciona. Este gancho corre al INICIO de oh3.invokeSuspend (hilo de fondo; toda peticion de Umbra/DJ pasa por ahi):
 *  1. Si el usuario ya tiene alguna llave propia (Gemini, Groq, Cerebras, OpenAI en el almacen seguro, o OpenRouter), no toca nada.
 *  2. Si no, pide una llave de Groq a nuestro Cloudflare Worker (GET /key), la sube al vault de Eclipse y SOLO si eso sale bien
 *     la guarda en el telefono (como si el usuario la hubiera puesto). Asi la peticion que sigue ya la encuentra.
 *  3. Si la llave local es la que pusimos nosotros y tiene mas de 12 h, la vuelve a pedir (por si se roto en el Worker).
 * Todo con try/catch: si algo falla (sin red, Worker caido, limite), no hace nada y Eclipse sigue como siempre.
 */
public final class FreeAi {
    private static final String TAG = "FreeAi";
    private static final String WORKER = "https://dj-puente.franc-all-starligth.workers.dev/key";
    private static final String VAULT = "https://api.eclipsemusic.app/api/user/credentials";
    private static final String PROVIDERS = "https://api.eclipsemusic.app/api/ai/providers";
    private static final String OURS = "freeai_prefs";
    private static final String K_GROQ = "groq_api_key";
    private static final long REFRESH_MS = 12L * 60L * 60L * 1000L;
    private static final long RETRY_MS = 60L * 1000L;

    private static volatile boolean done;
    private static volatile long lastFail;

    private FreeAi() {}

    /** @param sec almacen seguro de Eclipse (uk8.a, SharedPreferences cifradas): llaves de IA y auth_token. */
    public static void ensure(Context ctx, SharedPreferences sec) {
        try {
            if (done || ctx == null || sec == null) return;
            if (System.currentTimeMillis() - lastFail < RETRY_MS) return;
            synchronized (FreeAi.class) {
                if (done) return;
                if (System.currentTimeMillis() - lastFail < RETRY_MS) return;
                run(ctx.getApplicationContext() != null ? ctx.getApplicationContext() : ctx, sec);
            }
        } catch (Throwable t) {
            Log.w(TAG, "ensure fallo: " + t);
        }
    }

    private static void run(Context ctx, SharedPreferences sec) {
        SharedPreferences ours = ctx.getSharedPreferences(OURS, Context.MODE_PRIVATE);
        String ownKey = ours.getString("key", null);
        long ownTs = ours.getLong("ts", 0L);
        String cur = sec.getString(K_GROQ, null);
        boolean usingOurs = !isEmpty(ownKey) && ownKey.equals(cur);

        if (!usingOurs && hasAnyKey(ctx, sec)) { // el usuario tiene llave propia
            done = true;
            return;
        }
        if (usingOurs && System.currentTimeMillis() - ownTs < REFRESH_MS) {
            done = true;
            return;
        }

        String token = sec.getString("auth_token", null);
        if (isEmpty(token)) { // sin sesion: la app no deberia llegar aqui; reintenta luego
            lastFail = System.currentTimeMillis();
            return;
        }

        if (!usingOurs) {
            // Local vacio, pero el vault de Eclipse ya puede tener llaves (otro telefono): no pisarlas.
            int server = serverHasKey(token);
            if (server == 1) { // el servidor ya tiene alguna llave del usuario
                done = true;
                return;
            }
            if (server < 0) { // no se pudo saber: no instalar a ciegas
                lastFail = System.currentTimeMillis();
                return;
            }
        }

        String key = fetchKey();
        if (isEmpty(key)) {
            lastFail = System.currentTimeMillis();
            return;
        }
        if (usingOurs && key.equals(ownKey)) { // misma llave: solo renovar la hora
            ours.edit().putLong("ts", System.currentTimeMillis()).apply();
            done = true;
            return;
        }
        if (!pushVault(token, key)) {
            lastFail = System.currentTimeMillis();
            return;
        }
        sec.edit().putString(K_GROQ, key).apply();
        ours.edit().putString("key", key).putLong("ts", System.currentTimeMillis()).apply();
        done = true;
        Log.i(TAG, "llave gratis instalada");
    }

    private static boolean hasAnyKey(Context ctx, SharedPreferences sec) {
        if (!isEmpty(sec.getString(K_GROQ, null))) return true;
        if (!isEmpty(sec.getString("gemini_api_key", null))) return true;
        if (!isEmpty(sec.getString("cerebras_api_key", null))) return true;
        if (!isEmpty(sec.getString("openai_api_key", null))) return true;
        SharedPreferences ls = ctx.getSharedPreferences("lyrics_settings", Context.MODE_PRIVATE);
        return !isEmpty(ls.getString("openrouter_api_key", null));
    }

    /** GET /api/ai/providers (lo mismo que consulta la app): 1 = el servidor ya tiene alguna llave, 0 = ninguna, -1 = no se supo. */
    private static int serverHasKey(String token) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(PROVIDERS).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(5000);
            c.setRequestMethod("GET");
            c.setRequestProperty("Authorization", "Bearer " + token);
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "providers respondio " + code);
                return -1;
            }
            JSONObject o = new JSONObject(read(c.getInputStream()));
            JSONObject p = o.optJSONObject("providers");
            if (p == null) return 0;
            java.util.Iterator<String> it = p.keys();
            while (it.hasNext()) {
                if (p.optBoolean(it.next(), false)) return 1;
            }
            return 0;
        } catch (Throwable t) {
            Log.w(TAG, "serverHasKey: " + t);
            return -1;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String fetchKey() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(WORKER).openConnection();
            c.setConnectTimeout(5000);
            c.setReadTimeout(5000);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "Worker respondio " + code);
                return null;
            }
            JSONObject o = new JSONObject(read(c.getInputStream()));
            if (!"groq".equals(o.optString("provider", "groq"))) return null;
            String k = o.optString("key", "");
            return k.length() >= 8 ? k : null;
        } catch (Throwable t) {
            Log.w(TAG, "fetchKey: " + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static boolean pushVault(String token, String key) {
        HttpURLConnection c = null;
        try {
            JSONObject keys = new JSONObject().put("groq", key);
            byte[] body = new JSONObject().put("aiKeys", keys).toString().getBytes(StandardCharsets.UTF_8);
            c = (HttpURLConnection) new URL(VAULT).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(8000);
            c.setRequestMethod("PUT");
            c.setDoOutput(true);
            c.setRequestProperty("Authorization", "Bearer " + token);
            c.setRequestProperty("Content-Type", "application/json");
            c.setFixedLengthStreamingMode(body.length);
            try (OutputStream os = c.getOutputStream()) {
                os.write(body);
            }
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                Log.w(TAG, "vault respondio " + code);
                return false;
            }
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "pushVault: " + t);
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String read(InputStream in) throws Exception {
        try (InputStream is = in; ByteArrayOutputStream bo = new ByteArrayOutputStream()) {
            byte[] buf = new byte[2048];
            int n;
            while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
            return new String(bo.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    private static boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }
}
