package app.eclipse.extension.player;

import org.json.JSONObject;

/**
 * Diseno de reproductor "Bitchord" (archivo .eclipseplayer del usuario) para agregarlo a los
 * "Reproductores integrados" de Eclipse. Lo llama el parche "Reproductor integrado: Bitchord".
 */
public final class BitchordTemplate {
    private static final String JSON =
        "{\"id\":\"cbcaa695-c933-41ca-ae99-9020eabbec2c\",\"name\":\"Bitchord\",\"schemaVersion\":4,\"background\":{\"type\":\"blurred" +
        "Artwork\",\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1},\"gradient\":{\"start\":{\"hue\":0.56,\"saturation" +
        "\":0.6,\"brightness\":0.95,\"alpha\":1},\"end\":{\"hue\":0.75,\"saturation\":0.6,\"brightness\":0.7,\"alpha\":1},\"angleDegree" +
        "s\":135},\"blur\":0.5,\"dim\":0.3,\"opacity\":1},\"layers\":[{\"id\":\"c6de9387-a12f-41e9-b9a1-03f1a5713e90\",\"kind\":\"artwo" +
        "rk\",\"name\":\"Artwork\",\"transform\":{\"x\":0.5,\"y\":0.28,\"width\":1,\"height\":0.56,\"rotationDegrees\":0,\"aspectRatio\":{" +
        "\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alph" +
        "a\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":fals" +
        "e,\"masksLayerBelow\":false,\"artwork\":{\"preferAnimated\":true,\"edgeFade\":{\"edge\":\"bottom\",\"fraction\":0.35,\"stops\"" +
        ":[[0,0],[0.3,0.18],[0.65,0.72],[0.92,1],[1,1]],\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1,\"role\"" +
        ":\"immersive\"}}}},{\"id\":\"ea307c2d-5ea9-4426-adb7-c24d23e3323e\",\"kind\":\"songTitle\",\"name\":\"Song Title\",\"transfor" +
        "m\":{\"x\":0.374,\"y\":0.526,\"width\":0.6031219363212585,\"height\":0.03556248685712678,\"rotationDegrees\":0,\"aspectRat" +
        "io\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1," +
        "\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"T\u00edtu" +
        "lo de la canci\u00f3n\",\"fontSize\":20.49510955810547,\"weight\":\"bold\",\"design\":\"default\",\"alignment\":\"leading\",\"allow" +
        "sOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{" +
        "\"id\":\"5f6246d3-2919-43fc-a3e5-827110de16ed\",\"kind\":\"artistName\",\"name\":\"Artist Name\",\"transform\":{\"x\":0.409000" +
        "00000000003,\"y\":0.554,\"width\":0.66,\"height\":0.03,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{" +
        "\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"u" +
        "niform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"Nombre del artista\",\"fontSize\":18" +
        ".247268676757812,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpac" +
        "ing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"40486d50-046d-4c45-87e" +
        "a-b8e8736914e4\",\"kind\":\"shape\",\"name\":\"Menu disc\",\"transform\":{\"x\":0.879,\"y\":0.54,\"width\":0.088,\"height\":0,\"ro" +
        "tationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint" +
        "\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"b" +
        "ackgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"dcc0" +
        "e76c-e091-434f-91ae-7be558711371\",\"kind\":\"threeDotMenu\",\"name\":\"Menu\",\"transform\":{\"x\":0.879,\"y\":0.54,\"width\":" +
        "0.07230528444051743,\"height\":0.02265349814219462,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"a" +
        "ppearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerR" +
        "adius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerB" +
        "elow\":false,\"symbolOverride\":\"menu.dots\"},{\"id\":\"9cc2a4c4-b5f9-4f6c-8c70-ef0db0c27f8f\",\"kind\":\"progressBar\",\"n" +
        "ame\":\"Progress\",\"transform\":{\"x\":0.5,\"y\":0.634,\"width\":0.845,\"height\":0.030219625681638718,\"rotationDegrees\":0" +
        ",\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"bri" +
        "ghtness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":tr" +
        "ue,\"locked\":false,\"masksLayerBelow\":false,\"seekBarStyle\":\"classic\"},{\"id\":\"8779396d-1967-41de-87af-9b964e0fe50" +
        "2\",\"kind\":\"elapsed\",\"name\":\"Elapsed\",\"transform\":{\"x\":0.14900000000000002,\"y\":0.654,\"width\":0.14,\"height\":0.02" +
        ",\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\"" +
        ":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroun" +
        "dBlur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"leading\",\"a" +
        "llowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":fals" +
        "e},{\"id\":\"2a6bf2e9-37d1-42e2-b593-ec8fa643da43\",\"kind\":\"remaining\",\"name\":\"Remaining\",\"transform\":{\"x\":0.851,\"" +
        "y\":0.654,\"width\":0.14,\"height\":0.02,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6" +
        ",\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\"" +
        ":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"3:42\",\"fontSize\":13,\"weight\":\"medium\",\"design\"" +
        ":\"default\",\"alignment\":\"trailing\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"" +
        "locked\":false,\"masksLayerBelow\":false,\"remaining\":{\"prefix\":\"-\"}},{\"id\":\"756667d2-ef63-4eeb-978c-1ed75c3f1884\"" +
        ",\"kind\":\"previous\",\"name\":\"Previous\",\"transform\":{\"x\":0.202,\"y\":0.749,\"width\":0.163,\"height\":0,\"rotationDegree" +
        "s\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"sa" +
        "turation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\"" +
        ":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"previous.double\"},{\"id\":\"7e185f2b-" +
        "e0c9-44f6-bbfb-4a1d7c744448\",\"kind\":\"playPause\",\"name\":\"Play\\/Pause\",\"transform\":{\"x\":0.5,\"y\":0.749,\"width\":0." +
        "11972156167030334,\"height\":0.010721312630457187,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"ap" +
        "pearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRa" +
        "dius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBe" +
        "low\":false,\"symbolOverride\":\"play.thick\"},{\"id\":\"50a41290-470e-48d6-84da-9af1875b32b8\",\"kind\":\"next\",\"name\":\"N" +
        "ext\",\"transform\":{\"x\":0.8,\"y\":0.749,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1" +
        ",\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\"" +
        ":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false," +
        "\"masksLayerBelow\":false,\"symbolOverride\":\"next.double\"},{\"id\":\"0e27f773-1967-45e6-9492-43582a0f0469\",\"kind\":\"i" +
        "mage\",\"name\":\"Volume min\",\"transform\":{\"x\":0.102,\"y\":0.831,\"width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspect" +
        "Ratio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":" +
        "0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"image" +
        "Data\":\"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAQeUlEQVR4Ae3BC\\/CldX0f4OenZLMSZl0J67KBVXbpElkqpFwUXeUomO" +
        "DCOBJTkjWTNmAnyKhLUNvRdlJbTTMaM426atXYeBnsIFMVqQ0XE7kU+UNDrUgULwejaOOBqWOpg4bRlk8zbaaTWi+Ae959f+f9Pk9LopQyTS2J" +
        "Uso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS" +
        "2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQy" +
        "TS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKeRjW4QR8FvcpXW" +
        "pJlPIQbMTP42U4FX+Kt+CP8A2lKy2JUh6EDXgp\\/h6O9v\\/7Mt6DP8BC6UJLopQfYQc+jJ1+tDleg\\/cpo9eSKOWHeB4uxToPzZ\\/gBfiqMlot" +
        "iVJ+gDfiNz1838TzcaUySi2JUr7HYbgaJ9k\\/\\/gHepYxOS6KUv+GJ+CgOt\\/\\/8JU7GHcqotCRK+Wtn4w+x2f53O56M+5XRaEmU8lcuwpss1y" +
        "vwemU0WhJl8t6CF1u+z+E5uFMZhZZEmaz1+DDONIwFzsYnlVFoSZRJOgx\\/im2GdTquU0ahJVEmZxs+iUcb3h5cpoxCS6JMypNxI37CgfEivE0" +
        "ZhZZEmYy\\/i8vwCAfOBXinMgotiTIJr8DrHHh7cJkyCi2JsvL+EC8wDrtxtTIKLYmysh6Bt+M3jMfpuE4ZhZZEWVmX4NeMxz14Dm5VRqElUVbS" +
        "J3CicbkbZ+AOZRRaEmXl3IxTjc9tOBd3KqPQkigr5UrsNk4LPAt3KKPQkigr44N4nnF7Em5VRqElUVbCJfg143c6rlNGoSVRuvcGXKwP5+AKZR" +
        "RaEqVrr8Ur9eM8vFcZhZZE6dY\\/xWv05UV4mzIKLYnSpRfhrfrzErxVGYWWROnOeXi3Pl2ENyuj0JIoXfkVvF+\\/LsA7lVFoSZRuPBtX6dsFeK" +
        "cyCi2J0oVn4lr9Ow\\/vVUahJVFG76m4yWo4D+9VRqElUUbteNyGZjXswWXKKLQkymg9AZ\\/BI6yOPbjMsLbhcbgV31b+r5ZEGaWj8Xk80mo5B1" +
        "cYzmn4AzyAb+F6\\/BnehwdMXEuijM4WfBnrrJ5zcIVhPBcf9v39W\\/yyiWtJlFHZhK9gvdW0G1cbxlV4th9sDWfgfhPVkiijsR2fwXqrazeutn" +
        "yH4RYc7Yf7In4O95mglkQZhTNxCTZZbbtxteU7EZ\\/w4NyN4\\/ANE9OSKAfUevwLvNw0nI7rLN8JuApbPDj34G\\/hPhPSkigHzA5cgWNNx+m4z" +
        "vLtwA3Y4sGb42R800S0JMrgNuEUfBDrTcsurFm+rbgJWz0038FRWJiAlkRZusNwJJ6On8dx2G6admHN8m3CLdjuofsuHo+FFdeSKA\\/bOhyEg3" +
        "AQfhLr8Sisx9NwBo7D\\/TjOtN2D5+BWy7cRazjWw\\/NdPB4LK6wlsaLWYT1+Co\\/FTyIevAdwMA7FRmzAY\\/AYPBqPxqNxCB6F9ViHn8Ajcbjy" +
        "ve7Bc3Cr5TsE1+MkD9938XgsrKiWxIr4WZyMn8ZOPA5HYgO+hZ3KgXYPzsSnLN96XIPT\\/Hi+hKfha1ZQS6JzG\\/GPcC52KGN2D87EpyzfOlyO" +
        "s\\/z43oPzraCWRMeOxx\\/hSKUHd+MM3GEYl2KP\\/ePp+LgV05Lo1Mm4VenJ3TgDdxjG23Ch\\/WOOE3GfFdKS6NBGfAqPU3qywAxzw3gtXmn\\/e" +
        "RV+2wppSXTopfh9pTcLzDA3jBfjLfafb+FEfMGKaEl05lB8FCcpvbkN5+JOw\\/iH+D3714dwLh6wAloSnTka1+NIpTcL7ManDONVeLX967\\/hG" +
        "bjdCmhJdOYEXIPNSo9Ox3WG8Sq82v73JlxsBbQkOvNsXKX0ag8uM4zX4pX2vwX+Du7RuZZEZ34d71F6dRHebBhvwMWW4wK8U+daEp15FV6t9Op" +
        "1+MeG8QZcbDluxy7cp2Mtic68HS9UevVuvMAw3oYLLc8zcIOOtSQ6sg4fxm6lV1fiF\\/Edy\\/cunG95\\/h2eq2MtiY6sxwdwttKrq\\/FL+Lble" +
        "xfOtzx34Lm4U6daEh05BNfiFKVXf4Kz8R3Ldyn2WK6X4\\/d1qiXRkUNwPU5SevV+PN8wLsUey3Ubno77dKgl0ZFDcD1OUnr1RrzUMD6I51m+p+" +
        "AWHWpJdGQDbsTxSq9egddbvnW4HGdZvn+FF+tQS6IjG3Ajjld6dR7ea\\/nW4XKcZfm+gpPwdZ1pSXRkA27E8UqvduNqy7cOV+IMwzgXH9CZlkR" +
        "HNmINxyo9ugfPwa2Wbz2uwWmGcSXO1pmWREc2Yg3HKj26DefiTsu3HtfgNMP4NJ6LP9eRlkRHNmINxyo9+gs8E3PLdzCuxZMN52xcqSMtiY5sx" +
        "BqOVXq0wAxzy7ceH8DZhvNK\\/K6OtCQ6cihuxjFKjxaYYW751uMqPMNwrsA5OtKS6MihuBnHKD1aYIa55VuHy3GW4Xwau\\/BNnWhJdORQ3Ixjl" +
        "B4tMMPcMC7FHsO5GzN8QSdaEh3ZhFuwXenRAjPMDeNdON+wzsaVOtGS6Mgm3ILtSo8WmGFuGG\\/AxYb1avxznWhJdGQTbsF2pUcLzDA3jFfh1Y" +
        "b1Pvw6HtCBlkRHtmANRyk9WmCGuWG8GG8xrJvxLHxbB1oSHdmCNRyl9GiBGeaG8WK8xbA+i6fiXh1oSXRkC9ZwlNKjBWaYG8Ze7DOsu\\/AULHS" +
        "gJdGRLVjDUUqPFphhbhh7sc+w7sZpmOtAS6IjW3ETtio9WmCGuWHsxT7DexJu1YGWREe24iZsVXq0wAxzw9iLfYa3C2s60JLoyFbchK1KjxaYY" +
        "W4Ye7HP8HZhTQdaEh3ZhhtxhNKjBWaYG8Ze7DO8XVjTgZZER7bhRhyh9GiBGeaGsRf7DG8X1nSgJdGRbbgRRyg9WmCGuWHsxT7D24U1HWhJdGQ" +
        "HbsAWpUcLzDA3jL3YZ3i7sKYDLYmO7MAN2KL0aIEZ5oaxF\\/sM7ym4RQdaEh3ZgRuwRenRAjPMDWMv9hnWXXgKFjrQkujIDtyALUqPFphhbhh7" +
        "sc+wPo4z8W0daEl0ZCc+hsOVHi0ww9ww9mKfYb0JF+tES6IjO\\/ExHK70aIEZ5oaxF\\/sM61x8QCdaEh3ZiY\\/hcKVHC8wwN4y92Gc4d+FkfF0" +
        "nWhIdOQHXYLPSowVmmBvGXuwznDfipTrSkujICbgGm5UeLTDD3DD2Yp9h3Itn4RM60pLoyAm4BpuVHi0ww9ww9mKfYazhmfiOjrQkOnIKPoLNS" +
        "o8WmGFuGHuxzzB+A\\/9aZ1oSHTkFH8FmpUcLzDA3jL3YZ\\/m+hhNxj860JDpyCj6CzUqPFphhbhgvxNst33twvg61JDpyIj6h9GqBGeaG8Tv4J" +
        "5brXuzGLTrUkujITvwxfkbp0QIzzA3jXTjfct2OXbhPh1oSHdmGG3GE0qMFZphbvnW4HGdZrovwZp1qSXRkE27BdqVHC8wwt3wH41o82fL8V5y" +
        "Cu3SqJdGRjVjDsUqPFphhbvk2Yg3HWp7LsEfHWhIdORgfwplKjxaYYW75tmANR1meX8Af61hLojP\\/Br+q9GiBGeaWbwduwBbL8Vk8CffpWEui" +
        "M6\\/A65QeLTDD3PKdiE9Ynt\\/C7+hcS6Iz5+BypUcLzDC3fCfhI9hi\\/\\/sMTsb9OteS6MxOXIvNSm8WmGFu+U7ANdhs\\/\\/pLPBFftAJaEp05" +
        "DNfgRKU3C8wwt3w78TEcbv+6EO+wIloSHXoZ\\/qXSmwVmmFu+HbgBW+w\\/V2O3FdKS6NBG\\/BmOVHqywAxzy7cDN2CL\\/eMb+Fl83QppSXRqFz" +
        "6u9GSBGeaWbxtuxBH2jzPxUSumJdGxp+E6HKT0YIEZ5pZvK27CVj++t+IlVlBLonMn4EPYrozdAjPMLd8WrOEoP545TsR9VlBLYgU8Fi\\/Dr+A" +
        "oZawWmGFu+TbhFmz38P0FTsI9VlRLYoUcirNxEU5WxmaBGeaWbxNuwXYPzwP4GdxjhbUkVtDB+Ns4A2fiCNyPTfaPe\\/E\\/8dN+sM3K91pghrn" +
        "lOxQ34xgPXXA8Pm3FtSRW3Dpsxjb8D\\/tH\\/B\\/ND\\/YAtmIbtuNx2IzH4CBsNT0LzDC3fBuxhmM9NA\\/gOHzOBLQkyiDWYR0ehQ3YiQ9gnelY" +
        "YIa55duAG3G8B+9uPA1fNBEtiXLA7MS12GwaFphhbvkOwfU4yYPzNZyKr5qQlkQ5oDbgKjzV6ltghrnlOxhX4Fl+tM\\/jVNxrYloSZRT+Pc622" +
        "haYYW4Ye7HPD3cNzsH9JqglUUbjg3ie1bXADHPDeCyuxXG+v9fjFSasJVFG5UrstpoWmGFuOE\\/AZ\\/2\\/vokX4v0mriVRRudaPNPqWWCGuWEd" +
        "jbdhB27HhVgoWhJllG7GqVbLAjPMHRjPwG24V\\/nfWhJltD6Jn7M6FphhroxCS6KM2h041mpYYIa5MgotiTJq63EHtunfAjPMlVFoSZTRW485j" +
        "tS3BWaYK6PQkihdOAR3YrN+LTDDXBmFlkTpxgZ8CYfq0wIzzJVRaEmUrmzEXdigPwvMMFdGoSVRunMY7sLB+rLADHNlFFoSpUub8BWs148FZpg" +
        "ro9CSKN3agi9jnT7chnNxpzIKLYnSta34cxxk\\/BbYjU8po9CSKN07Gp\\/HI43fLqwpo9CSKCvhCfgMHmHcduNqZRRaEmVlHIH\\/hMON1x5cpo" +
        "xCS6KslE34L1hnnC7AO5VRaEmUlbMDd+Ag4\\/PP8BplFFoSZSVtxZ1YZ1zeiJcqo9CSKCtrC+7Ewcbj3XiBMgotibLSDsMXscE4fAi\\/pIxCS6" +
        "KsvI34HDY78D6Gs\\/Ad5YBrSZRJOAS3Y5sD66P4RXxbOeBaEmUy1uM\\/41gHzjtwoTIKLYkyOTfjVAfG8\\/F+ZRRaEmWSrsRuw7oHp+ELyii0J" +
        "MpkfRDPM5zb8HTcp4xCS6JM2jtwgWG8GRcpo9GSKJP3Blxsue7FkzBXRqMlUcpf+S38tuV5K16ijEpLopS\\/9nz8Ho6wf\\/13PBFfVUalJVHK3" +
        "3AoXo7fxE\\/ZP\\/4+LlFGpyVRyvdxDN6MX\\/Dj+VVcqoxSS6KUH+JsvANHeGgewHm4RBmtlkQpP8KheDn2YLsf7bt4Fv6DMmotiVIepGNwIfZg" +
        "i+9vjjPxJWX0WhKlPESb8cs4H4\\/CI\\/EfcTsuwd1KF1oSpTxMG7ATn8O9SndaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmm" +
        "lkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSp" +
        "mmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVR" +
        "SpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUafpfIpO0TMleHq8AAAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"m" +
        "asksLayerBelow\":false},{\"id\":\"bce1c6dc-a0c2-4f3b-959f-92539b6db141\",\"kind\":\"image\",\"name\":\"Volume max\",\"transf" +
        "orm\":{\"x\":0.896,\"y\":0.831,\"width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"" +
        "appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"corn" +
        "erRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"imageData\":\"iVBORw0KGgoAAAANSUhEUgAAAQ" +
        "AAAAEACAYAAABccqhmAAAYDklEQVR4Ae3BDdjedV0o8M9v0Fo0ce2wxnh6ZA9rOEkHCpMxBG7AADV5M99fUisxFV96UbJOluVR03NELBM7Kh6t" +
        "g5IJgmdACo6HjfFy6yAdMGQTEXFCQPMvjgl8u07nujpXV6aM3b\\/\\/\\/b+f+\\/v5lIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxl" +
        "OJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWI" +
        "kFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipDREP4\\/9c" +
        "RO2YYfUmhIRUhqC+XguXofdMBu34Gpcja\\/in3C\\/VE2JCCm1aHe8AO\\/EL\\/jP3Yx78A+4EmuwQxqoEhFSatHf4oV23lX4A6zFDmkgSkRIqSU" +
        "b8QS7Zi3ejHXSLisRIaUW3ITHG4wGV+CPca30qJWIkFJlF+FZBq\\/BpXg7rpd2WokIKVW0F9ZhqXq+hwvwNmyWHrESEVKqaAWu0Y5v4PdxrvSI" +
        "lIiQUkVvxPu061N4FbZJP1aJCClVdAFO1L47cRKulf5TJSKkVMl8XITDDMcP8Ra8T\\/qRSkRIqZI5uARHGq4r8Dxslf6dEhFSquhDOM3wbcPzc" +
        "bH0b0pESKmi1+P9uuM9eLP0r0pESKmio3GZblmDE7DdmCsRIaWK9sJa7K9bbsMhuNsYKxEhpcoW4puYrVu+h1\\/C7cZUiQgpteBAXI6f0y07sB" +
        "JfMYZKREipJYfgKuyuWx7GybjQmCkRIaUWHYB\\/xCzdcxSuMEZKREipZRNYi311z3H4B2OiRIQ00mbh6bgXBfdiK7bptgV4K56PRbrl5fi4MVA" +
        "iQhpZc\\/FBvNT\\/twk7cCuuwjfxeWzTTQvxPPwGluuOF+BTZrgSEdJI2her8QQ\\/2bV4GW7SXXNxMF6DJ2Op4TsZF5jBSkRII2cS12KhR2473o" +
        "izdd8U\\/hQvNnzPwMVmqBIR0kiZxBbs5tH5FF6GHbrvuTgbP2e4jsHlZqASEdLImMQW7GbXXIyTsEP3LcCHcKrhOhzrzDAlIqSRMIkt2M1gPA\\" +
        "/nGR3Pxkexl+EIHIQbzCAlIqTOm8QW7GZwNuJQNEbHXjgTLzYcD+OXcJMZokSE1GmT2ILdDN4L8Cmj5zj8DfbSvofweNxqBigRIXXWJLZgN3Vc" +
        "hpPQGD174Uy8WPsexH643YgrESF10iS2YDf1bMThuM\\/oOg5n4gnatQOLcacRViJC6pwluBm7qesbWIU7jbZ5OB9Hadd2PA53GVElIqROWYJNm" +
        "KW+O3AEtpgZbsLjtet+7Iu7jaASEVJnLMEmzNKOrTge15s5bsLjtesGHIFtRkyJCKkTlmATZmnXMbjczHI9lmvXu\\/D7RkyJCGnolmATZmnfSf" +
        "icmed6LNee7ViFrxghJSKkoVqCTZhlOI7HpWamq\\/FU7bkRh+B+I6JEhDQ0S7AJswzPMbjczHU1nqo9b8GfGxElIqShWIJNmGW4Dsc6M9vVeKp" +
        "23I8nY5MRUCJCat0yfA2zDNdWPBvXmvm+hKO041ocie06rkSE1Kpl2Ihi+L6DY7HReFiPQ7Xj9fiAjisRIbVmGTai6IY7cRRuMR7mYjMWqG8bn" +
        "ojbdViJCKkVy7ARRXfcgSOwxfhYin\\/ET6vvC\\/hlHVYiQqpuGTai6JbbcThuN15Oxme146X4pI4qESFVtQwbUXTPZqzEXcbP+\\/BG9X0Vx+K7" +
        "OqhEhFTNMmxE0U2bcBjuMZ6uwQr1vR4f0EElIqQqlmEjiu66Eatwn\\/G0F27BPHXdjEPQ6JgSEdLALccGFN12A47ANuNrBdZhd3WdjAt0TIkIa" +
        "aCWYwOK7rsUz0FjvL0U\\/0tda3AcduiQEhHSwCzHBhSj4TocjcZ4m4PLcJh6tuF4rNchJSKkgViODShGRx89NOp7EvbA1brpibgae6jnPDxPh5" +
        "SIkHbZcmxAMVr66KFR11H4azyIK\\/AhbNA978Mb1XMvDsUtOqJEhLRLlmMDitHTRw+Nek7FZ\\/x738ZLcLlumY8bMKGed+MMHVEiQnrUlmMDit" +
        "HURw+NOuahj\\/38aCfjAt3yLFyknjtwEO7WASUipEflibgBxejqo4dGHSfiAj\\/eC\\/Ap3XIJjlPPG3CWDigRIe205ehjd6Otjx4adZyCv\\/eT" +
        "vRYf1B1L8BU8Rh034xA0hqxEhLRTnoWPYYHR10cPjTpOwvkemT\\/Cn+qO38V71HMyLjBkJSKkR+wteJeZo48eGnWchPM9cr+Oj+qGufgylqpjD" +
        "Y7DDkNUIkJ6RD6CV5pZ+uihUcdJON\\/OeRk+oRuehkvxMwZvG47HekNUIkL6sRbhvXiRmaePHhp1nITz7ZwH8XSs0Q0fwOvUcR6eZ4hKROioud" +
        "gbj8V38c\\/Yjh1+stmYjdn4aczFY\\/EA7sb3sR07\\/GiT6OH5WIJlZqY+emjUcQJW23n3Yn\\/cbfgOxf\\/BfIN3Lw7FLYakRISOmIUT8Tgcjv3" +
        "xWHwf83AvvoWbsQU34AE8DntiERZhHhZgHh6D2fhp\\/BP2wG7Yhu\\/idmzFFtyMn8Vr8IvY38zXRw+NOk7Aao\\/OpTje8M3FWixXx7txhiEpEa" +
        "EDFuFcHCm1qY8eGnWcgNUevd\\/G+wzf7+I96ujjBNxtCEpEGLKT8Ak8RmpbHz006jgBqz16O7ACNxiufXEtFhi8rTge1xuCEhGGZBb+BH8oDUs" +
        "fPTTqOAGr7Zpv4knYZrg+i5PV8XJ83BCUiDAkH8RvScPURw+NOk7AarvuHLzCcD0bn1PHh3GaISgRYQhOwGpp2ProoVHH0bjMYLwQ5xqe+ehjs" +
        "cG7Fj3cr2UlIrRsD1yF5dKw9dFDo46jcZnBuB8H4DbD8w681eDdgcNwu5aViNCyU\\/EZqQv66KFRx9G4zODcgEOx3XAsx5fwcwbvGFyuZSUitO" +
        "yTeLHUBX300KjjaFxmsM7Auw3HbFyOVQbvDLxby0pEaNE8XItflLqgjx4adRyNywzWV3EYGsPxEnzC4F2Ak7WsRIQWHYzrpK7oo4dGHUfjMoPX" +
        "wxrDsRBfxj4G62asxH1aVCJCiw7GdVJX9NFDo45VWGvwzsErDM\\/H8HKD9V0ci69qUYkILVqBa6Su6KOHRh2rsNbgfQeH4A7D8VRcbfBegE9pU" +
        "YkILVqBa6Su6KOHRh2rsFYdv4n\\/aTgOwD9gH4P1frxRi0pEaNEKXCN1RR89NOpYhbXqWIejsUP7JrEWkwbrShyP+7WkRIQWrcA1Ulf00UOjjl" +
        "VYq4778HT0tW8+rsL+BuubWIk7taREhBatwDVSV\\/TRQ6OOFbgQC9VxJt6kfXPxJRxs8I7AlVpSIkKLVuAaqSv66KFRxwpciIXq+AYOxj3aNQe" +
        "X4EiD9wacpSUlIrRoBa6RuqKPHhp1rMCFWKie5+LvtO8zONXgfRrP15ISEVq0AtdIXdFHD406VuBCLFTPajxT+\\/4KrzZ4X8Xh2KYFJSK0aAWu" +
        "kbqijx4adazAhVionn\\/CobhVu\\/4If2Lwrsep2KwFJSK06CnoS13RRw+NOlbgQixU1xtwlnb9Jj6sjkPQ14ISEVp0Es6XuqKPHhp1HIhLsFBd" +
        "Z+JN2vV8nKuOU3C+FpSI0KLX4\\/1SV\\/TRQ6OOA3EJFqrrfJyiXUfjMnW8AWdpQYkILXof3ih1RR89NOo4EJdgobqmcRy2a8+BuAQLDd6ZeJMW" +
        "lIjQos\\/iZKkr+uihUceBuAQL1XUjVuE+7ZnCNCYM3vk4RQtKRGjJHrgMh0pd0UcPjToOxCVYqK5vYRVu154FWI\\/9DN7VOAb3q6xEhJbMx3os" +
        "lbqijx4adRyIS7BQXVtxDDZqzzyswxMM3jqchLtVViJCSxbjM3iK1BV99NCo4wB8EXur7xhcrj174DIcavC+jlW4S2UlIrRkClfgF6Su6KOHRh" +
        "0H4IvYW30vx8e1ZzY+i2cavM1YibtUViJCS6YwjQmpK\\/rooVHHAfgi9lbfW\\/Dn2vVRvMLgbcZK3KWyEhFaMoVpTEhd0UcPjToOwBext\\/rOx" +
        "qu16504w+BtxkrcpbISEVoyhWlMSF3RRw+NOg7AF7G3+j6Bl+Nh7Xkt\\/sLgbcZK3KWyEhFaMoVpTEhd0UcPjTqWYg0Wqe+v8Brtei3+wuBtxk" +
        "rcpbISEVoyhWlMSF3RRw+NOpZiDRap7214u3adjrMM3tX4FdytshIRWjKFaUxIXdFHD406lmINFqnv1Thbu07HWQavjx4alZWI0JIpTGNC6oo+" +
        "emjUsRRrsEh9p+B87TodZxm81TgZO1RWIkJLpjCNCakr+uihUcdSrMEi9R2Oddp1Os4yeOfgFVpQIkJLpjCNCakr+uihUcdSrMEidW3FMdioXa" +
        "fjLIP3NrxdC0pEaMkUpjEhdUUfPTTqmMI0JtT1LazC7dp1Os4yeK\\/G2VpQIkJLpjCNCakr+uihUccUpjGhrluwEvdo1+k4y+A9AxdrQYkILZn" +
        "CNCakruijh0YdU5jGhLq+gFPQaNdp+JDB2orjcb0WlIjQkilMY0Lqij56aNQxhWlMqOtsvFr7\\/jdeYLC+jadhixaUiNCSKUxjQuqKPnpo1DGF" +
        "aUyo64U4V7vmYhoHGaxbsBL3aEGJCC2ZwjQmpK7oo4dGHVOYxoR6tuJIbNKuSVyFCYP1ZRyFRgtKRGjJFKYxIXVFHz006pjEWkyqZwOOQKNdT8" +
        "O0wVuNk7FDC0pEaMkUpjEhdUUfPTTqmMRaTKrnwzhN+07DhwzeOXiFlpSI0JIpTGNC6oo+emjUMYm1mFTPC3Gu9p2NVxm8t+HtWlIiQksW4zN4" +
        "itQVl+I5aNQxibWYVMdWHIlN2rUHvoQVBu\\/l+LiWlIjQkklMY1+pK67HkdimjkmsxaQ6NuAINNq1COvxOIP3DFysJSUitGQB1mM\\/qSs24TDc" +
        "o45FWIfF6vgwTtO+Ffg8FhisrTge12tJiQgtmYd1eILUFZuxEnepYxHWYbE6nou\\/075fwzkG79t4GrZoSYkILZmLL+FgqStux+G4XR2LsA6LD" +
        "d5tOAR3a9+ZeIPBuwUrcY+WlIjQkjm4BEdKXXEHjsAWdSzCOiw2eGfiTdo3GxfjaIP3BZyCRktKRGjJLHwCL5K64js4FhvVsQjrsNhg3YsebtC" +
        "+vXARDjV478GbtahEhBa9Eh+RumIrno1r1bEI67DYYF2E52CH9p2Kz6jjKFyhRSUitGhfrMfeUlccjnXqWID12M\\/gNDgItxqOz+OZBu\\/rWIH" +
        "7tKhEhJZdhGdJXfEMXKyOBViP\\/QzOq\\/DXhmMJ1mMvg\\/dJvFTLSkRo2a\\/iPKkrTsLn1LEA67GfwViHww3P7+C96ngO\\/l7LSkRo2R5Yi4Ok" +
        "Ljgel6pjAdZjP7uuwRNxm+GYi2kcZPDuwArcqWUlIgzBM\\/F5qQsOxzp1LMB67GfX\\/QY+YnhW4ip1\\/B1eiAe1rESEIdgdq\\/F0aZi24nhcr4" +
        "75uAiH2TV\\/jVcZrr\\/Ea9TxYvytISgRYUjmYCOmpGG5E0fhFnUswlpMefTW4zDDtRcuxsEG7w4cjK2GoESEIZqDG7FYGobbcThuV8ck1mLSo\\" +
        "/MdPB7bDNfpOEsdH8MrDUmJCEO2O87DyVLbNmMl7lLHUqzBIjtvO34RdxiuubgOj1fHUbjCkJSI0AGzcSL+K5ZLbbkRq3CfOg7AF7G3nfMwVuF" +
        "qw3cSzlfHJhyK+wxJiQgdMhcH4FgcjwlsxwIEAg\\/iITyMB\\/EQ7seDeAA\\/xAPYhh\\/gAWzHvdiOH2A7duA+PIAH8D08BS\\/C3ngI\\/wX3Ypm" +
        "Z6VI8B406VuBCLLRzXopPGr7ZWIOV6ngH\\/tAQlYjQUbOxEJP4Pn6IH2I7HsSDeAgP40E8jIfxsP9nh0dnNhZjAg\\/g+3gTfs3Mcx2ORqOOVVh" +
        "r55yGD+uGlbgEexq8e3A0bjBEJSKkR+QjeKWZpY8eGnWcgNUeuRfiXN3xaTxXHVfiWOwwRCUipEfsLXiXmaOPHhp1PAsX+ckexsvxCd2xDFdhn" +
        "jpeh780ZCUipJ3yLHwMC4y+Pnpo1LEKa\\/14D+AoXK1b3o\\/Xq2MrDsVthqxEhLTTlqOP3Y22Pnpo1LEUa7HAj7YVB+MO3bIQG7C3Ov4ez9EBJ" +
        "SKkR+WJuAHF6Oqjh0Yde+BiHOE\\/ugLPxjbd82a8Wz0n4kIdUCJCetSW4WuYZTT10UOjnnk4A6fiIXwNX8KH8KDumYfrsEQdm7EC9+iAEhHSLl" +
        "mCm7Gb0dNHD436lmN3fFm3\\/SrOU88H8VodUSJC2mWTuBU\\/ZbT00UMj\\/V9LcD1+Vh334plYryNKREgDsQjfwGyjo48eGmkO+jhAPRtwBBodU" +
        "SJCGpgF+BZmGw199NBIb8U71PW7+O86pESENFALcBt+Rvf10UNjvJ2Mz6rrFpyIm3RIiQhp4PbCddhXt\\/XRQ2N8HYAN+Cl1\\/Tf8gY4pESFVM" +
        "Q\\/X43G6q48eGuNpHjZhgbq+gQOxTceUiJCq2RO3YZ5u6qOHxnhai1Xq+xV8XgeViJCq2hO3YZ7u6aOHxvh5J85Q34U4UUeViJCq2xO3YZ5u6a" +
        "OHxng5FZ9R3\\/fwZNyqo0pESK3YE7dhnu7oo4fG+DgAG\\/BT6vs9vFeHlYiQWrMnvo4FuqGPHhrjYR42YYH6bsFT0OiwEhFSq+ZiMxYYvj56aI" +
        "yH67FcfT\\/AcbhSx5WIkFo3F5uxwHD10UNjZtsTF6CnHefgFUZAiQhpKOZiMxYYnj56aMxc+2Id9tGOb+BJaIyAEhHS0MzFZiwwHH300JiZeli" +
        "NOdrxAyzFHUZEiQhpqObiZuyjfX300Jh53ox3a89D6OFKI6REhDR0c3Ar9tGuPnpozBxz8Dc4Vbteh780YkpESJ0wB7diH+3po4fGzLAAV2GJd" +
        "n0SLzWCSkRInTEHt2If7eijh8boOxBXYq52fQ2HYLsRVCJC6pQ5uBX7qK+PHhqj7SU4B7tp1\\/exBFuNqBIRUufMwY1YrK4v4BQ0RtcH8Drtew" +
        "iH4VojrESE1ElzcCMWq+dsvNpomosL0TMcv46PGnElIqTOmoMbsVgdL8S5Rs8ULsb+huPDOM0MUCJC6rQ5uBGLDdbX8WzcZHRM4gw8A1OGo49D" +
        "zBAlIqTOm4OrsdzgvBpnGw3z8dv4Lcw3PPdgKe4xQ5SIkEbCHJyD59t1n8NJum9PvAR\\/gH0M17dxCO40g5SIkEbKC\\/AxzPHo3Ill2Ka79sCJ" +
        "+DMsMXw\\/wL64ywxTIkIaOUtxAZ5g53wTT8VW3XUs\\/geW64Z78STcYQYqESGNpDn4M\\/yOR+YeLMNdumkF3o2jdcdtOAj3maFKREgj7Wl4EY7" +
        "F\\/n60a\\/As3K17DsA78Mv4Wd1xJX4Z281gJSKkGWEenoI\\/xs+j4Bpcjk+j0S2TOAMvw1zdcg5eYQyUiJBmlNl4CjbhHt0zH6\\/DGzBf97wV7" +
        "zQmSkRIqSUH4tPYX\\/cEno\\/zjJESEVJqwSG4Vjc9hGOxxpgpESGlyvbAFThY99yPJ2OTMVQiQkqVHYdLdM+3cRDuMqZKREipsvPwq7rlWhyDx" +
        "hgrESGlil6Ev9EtF+JESYkIKVUyH5fiYN3xXvye9K9KREipkr0wjWWG7\\/v4DZwr\\/ZsSEVKqZD6uwv6GawNOxm3Sv1MiQkqVzMdV2N9w7MC78" +
        "E5sl\\/6DEhFSqmQ+LsQq7fs2TkRf+k+ViJBSJbNxPp6hXefiNGyTfqwSEVKq6PV4v3Z8D7+JT0mPSIkIKVW0P67EAnWtx6m4U3rESkRIqaJZuA" +
        "jPUMc38GG8U9ppJSKkVNkcbMKkwbkXF+L9+LL0qJSIkFIL5uLrWGjX3IFP4iO4RdolJSKk1JI9sQXz7byb8UH8Le6WBqJEhJRaNAdfwOEemXU4" +
        "E6vRSANVIkJKLZuLp+EEHIzH4Z\\/xGNyFr+DL+Edchx1SFSUipDREe+Cx+AV8C\\/+M+6VWlIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8l" +
        "IqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQk" +
        "ppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPP0LABjOaloe7ZYA" +
        "AAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"75a55874-8d1e-4818-821d-14e10a" +
        "fd36e6\",\"kind\":\"volumeSlider\",\"name\":\"Volume\",\"transform\":{\"x\":0.5,\"y\":0.831,\"width\":0.689,\"height\":0.03008730" +
        "337023735,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\"" +
        ":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"ba" +
        "ckgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"d6239099-f0b1-4664-99e6-6a731be" +
        "9357d\",\"kind\":\"shape\",\"name\":\"Pill\",\"transform\":{\"x\":0.5,\"y\":0.889,\"width\":0.336893230676651,\"height\":0.051908" +
        "02043658369,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"t" +
        "int\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false" +
        ",\"backgroundBlur\":0},\"shape\":{\"type\":\"capsule\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"" +
        "aafe8d61-35b7-4435-80f8-7449f96d29a1\",\"kind\":\"shape\",\"name\":\"Pill divider\",\"transform\":{\"x\":0.5,\"y\":0.889,\"wid" +
        "th\":0.0016,\"height\":0.044,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.35,\"blendMo" +
        "de\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"inn" +
        "erShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"rectangle\"},\"visible\":true,\"locked\":false,\"masksLayerBelo" +
        "w\":false},{\"id\":\"0c1b0186-89e6-4073-bf01-9c3794988dbc\",\"kind\":\"lyrics\",\"name\":\"Lyrics\",\"transform\":{\"x\":0.164," +
        "\"y\":0.889,\"width\":0.08991199731826782,\"height\":0.01,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}}" +
        ",\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"co" +
        "rnerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksL" +
        "ayerBelow\":false,\"symbolOverride\":\"lyrics.apple\"},{\"id\":\"9d326727-b7d7-4b78-9812-8b357d3fef92\",\"kind\":\"connect" +
        "\",\"name\":\"Connect\",\"transform\":{\"x\":0.417,\"y\":0.889,\"width\":0.0765811949968338,\"height\":0.014227520366003252,\"" +
        "rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"ti" +
        "nt\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false," +
        "\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"connect.apple\"},{\"" +
        "id\":\"212c2ff4-9a94-4ce1-a63f-5902c9c6bbda\",\"kind\":\"share\",\"name\":\"Persona\",\"transform\":{\"x\":0.583,\"y\":0.889,\"w" +
        "idth\":0.06802937388420105,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{" +
        "\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"u" +
        "niform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":fals" +
        "e,\"symbolOverride\":\"person.apple\"},{\"id\":\"9fb80647-7ed7-4da7-9dbd-af66de33edf2\",\"kind\":\"queue\",\"name\":\"Queue\"," +
        "\"transform\":{\"x\":0.835,\"y\":0.889,\"width\":0.08035406470298767,\"height\":0.014655064936159071,\"rotationDegrees\":0" +
        ",\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"satu" +
        "ration\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0" +
        "},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"queue.list\"},{\"id\":\"a737246d-24bf-4d" +
        "10-9456-d8f66cbbc857\",\"kind\":\"outputName\",\"name\":\"Output\",\"transform\":{\"x\":0.5,\"y\":0.949,\"width\":0.56576865911" +
        "48376,\"height\":0.020744850834210717,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6" +
        ",\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\"" +
        ":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13.540205955505371,\"weight\":\"" +
        "medium\",\"design\":\"default\",\"alignment\":\"center\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"v" +
        "isible\":true,\"locked\":false,\"masksLayerBelow\":false,\"outputName\":{\"prefix\":\"\",\"showIcon\":false,\"useAccessoryNa" +
        "me\":true}},{\"id\":\"5c799064-b220-4be0-a8d9-8e540dc6057f\",\"kind\":\"qualityBadge\",\"name\":\"Quality Badge\",\"transfor" +
        "m\":{\"x\":0.5,\"y\":0.6549999999999999,\"width\":0.6522871255874634,\"height\":0.035,\"rotationDegrees\":0,\"aspectRatio\"" +
        ":{\"free\":{}}},\"appearance\":{\"opacity\":0.7032073736190796,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"" +
        "brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\"" +
        ":true,\"locked\":false,\"masksLayerBelow\":false,\"badge\":{\"showsBackground\":false,\"shape\":\"capsule\",\"backgroundOpa" +
        "city\":0.12,\"fontSize\":12.69775390625,\"bold\":false,\"uppercase\":false,\"horizontalPadding\":8,\"compact\":false,\"mod" +
        "e\":\"tier\",\"animated\":\"shimmer\",\"icon\":\"auto\"}},{\"id\":\"f82b3f89-7831-4855-8196-9971bd9a38fa\",\"kind\":\"favorite\"," +
        "\"name\":\"Favorite\",\"transform\":{\"x\":0.7647921594975924,\"y\":0.5401221602056466,\"width\":0.07079613208770752,\"heig" +
        "ht\":0.042477679252624495,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":" +
        "\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerSh" +
        "adow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"favori" +
        "te.star\"},{\"id\":\"f8c3c3c9-9e73-4ecb-b8e0-24e186f2133a\",\"kind\":\"shape\",\"name\":\"Menu disc Copy\",\"transform\":{\"x\"" +
        ":0.7639999999999999,\"y\":0.54,\"width\":0.088,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}" +
        "}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"" +
        "cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visible\"" +
        ":true,\"locked\":false,\"masksLayerBelow\":false}],\"createdAt\":8.14566495325E8,\"updatedAt\":8.145666913299999E8,\"re" +
        "quiredCapabilities\":{\"immersiveArtworkFade\":1,\"statefulControls\":1}}";

    private BitchordTemplate() {}

    /** JSON del diseno, con el mismo formato que lee Eclipse al importar un .eclipseplayer. */
    public static JSONObject json() {
        try {
            return new JSONObject(JSON);
        } catch (Exception e) {
            throw new RuntimeException("Bitchord: JSON invalido", e);
        }
    }

    /**
     * Busca entre los disenos del usuario (lista de ib6) uno llamado "Bitchord" y devuelve su id, o null.
     * Se usa reflexion sobre los campos publicos de ib6: a = id, b = nombre. Cualquier fallo devuelve null.
     */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                Object name = d.getClass().getField("b").get(d);
                if ("Bitchord".equals(name)) {
                    Object id = d.getClass().getField("a").get(d);
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * BITCHORD (ordinal 7 del enum de reproductores integrados) se trata como CUSTOM (ordinal 6) donde la app
     * decide como dibujar el reproductor. Cualquier otro valor (o null) se devuelve igual.
     */
    public static Object norm(Object value) {
        try {
            if (value instanceof Enum) {
                Enum<?> e = (Enum<?>) value;
                if (e.ordinal() == 7) {
                    Object[] all = e.getDeclaringClass().getEnumConstants();
                    if (all != null && all.length > 6) return all[6];
                }
            }
        } catch (Throwable ignored) {
        }
        return value;
    }

    private static volatile Object currentCard;
    private static int previewResId = -1;

    /** Lo llama i92.o al entrar: anota que tarjeta (valor del enum) se esta dibujando. */
    public static void card(Object fl6) {
        currentCard = fl6;
    }

    /**
     * Lo llama i92.o justo antes de painterResource con el id original. Si la tarjeta actual es BITCHORD
     * (ordinal 7) devuelve el id del recurso "player_preview_bitchord"; si no existe, el original.
     */
    public static int previewId(int original) {
        try {
            Object c = currentCard;
            if (c instanceof Enum && ((Enum<?>) c).ordinal() == 7) {
                if (previewResId == -1) {
                    int id = 0;
                    Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                    if (app instanceof android.content.Context) {
                        android.content.Context ctx = (android.content.Context) app;
                        id = ctx.getResources().getIdentifier("player_preview_bitchord", "drawable", ctx.getPackageName());
                    }
                    previewResId = id;
                }
                if (previewResId != 0) return previewResId;
            }
        } catch (Throwable ignored) {
        }
        return original;
    }

    /** Posicion de la tarjeta Bitchord en la lista (0 = primera, arriba a la izquierda; 1 = segunda; etc.). */
    private static final int CARD_POSITION = 0;

    /** Lo llama kd.invoke con la lista de tarjetas: mueve BITCHORD (ordinal 7) a CARD_POSITION. */
    public static void reorder(java.util.List<Object> list) {
        try {
            int from = -1;
            for (int i = 0; i < list.size(); i++) {
                Object o = list.get(i);
                if (o instanceof Enum && ((Enum<?>) o).ordinal() == 7) {
                    from = i;
                    break;
                }
            }
            if (from < 0) return;
            Object card = list.remove(from);
            int to = Math.max(0, Math.min(CARD_POSITION, list.size()));
            list.add(to, card);
        } catch (Throwable ignored) {
        }
    }
}
