package app.eclipse.extension.player;

import org.json.JSONObject;

/**
 * Diseno de reproductor "Bitchord" (archivo .eclipseplayer del usuario) para agregarlo a los
 * "Reproductores integrados" de Eclipse. Lo llama el parche "Reproductor integrado: Bitchord".
 */
public final class BitchordTemplate {
    private BitchordTemplate() {}

    /** JSON del diseno, con el mismo formato que lee Eclipse al importar un .eclipseplayer. */
    public static JSONObject json() {
        try {
            try {
                return BitchordLyrics.applyFinished(new JSONObject(BitchordDesign.JSON));
            } catch (Throwable t) {
                // Si el marcado de la portada que crece falla, se usa el diseno sin marcar.
            }
            return new JSONObject(BitchordDesign.JSON);
        } catch (Exception e) {
            throw new RuntimeException("Bitchord: JSON invalido", e);
        }
    }

    /** true = el parche "Bitchord: Letras estilo Apple Music" esta activo (lo marca enableLyrics). */
    private static volatile boolean lyricsMode;

    /** true = el parche "Bitchord: la portada chica crece" esta activo (lo marca enableMorph). Solo vale con lyricsMode. */
    static volatile boolean morphMode;

    /** Gancho del parche de la portada que crece: se llama junto a enableLyrics. */
    public static void enableMorph() {
        morphMode = true;
    }

    // ---- v0.20.53: la tarjeta Bitchord se renueva sola ----
    private static volatile boolean refreshed;
    private static volatile boolean refreshScheduled;
    private static int refreshTries;

    /**
     * Gancho (di6.q, se llama cada vez que se dibuja el reproductor Custom): con el parche de Letras activo renueva UNA vez
     * por sesion el diseno interno de la tarjeta Bitchord (el guardado en el telefono) con el JSON de esta version,
     * conservando su id, asi no hace falta tocar la tarjeta ni crear otro player cuando se actualizan los parches.
     */
    public static void onPlayerOpen() {
        lyricsMode = true;
        scheduleRefresh(1200L);
    }

    private static void scheduleRefresh(long delayMs) {
        if (refreshed || refreshScheduled || refreshTries >= 6) return;
        refreshScheduled = true;
        new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() {
                refreshScheduled = false;
                refreshTries++;
                boolean ok = false;
                try {
                    ok = refreshCard();
                } catch (Throwable t) {
                    refreshTries = 99; // algo no coincide: no reintentar
                }
                if (ok) refreshed = true; else scheduleRefresh(1500L);
            }
        }, delayMs);
    }

    /** Campo de la tarjeta de diseno (w17): se lee con getDeclaredField + setAccessible (no se verifico que sea publico). */
    private static Object fieldOf(Object d, String name) throws Exception {
        java.lang.reflect.Field f = d.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(d);
    }

    private static java.lang.reflect.Method findMethod(Class<?> c, String name, Class<?>... params) {
        for (Class<?> k = c; k != null; k = k.getSuperclass()) {
            try {
                java.lang.reflect.Method m = k.getDeclaredMethod(name, params);
                m.setAccessible(true);
                return m;
            } catch (NoSuchMethodException ignored) {
            }
        }
        return null;
    }

    /** true = renovado. false = todavia no (la lista de disenos aun no cargo o no existe el diseno de la tarjeta). */
    private static boolean refreshCard() throws Exception {
        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        if (!(app instanceof android.content.Context)) return false;
        Class<?> sj6 = Class.forName("mt7");
        java.lang.reflect.Field tf = sj6.getDeclaredField("u");
        tf.setAccessible(true);
        Object g96 = tf.get(null);
        if (g96 == null) return false;
        java.lang.reflect.Method im = null;
        // 0.6.70: el companion wh6 tiene q(Context) -> gs7; se busca por tipos (no por nombre).
        for (java.lang.reflect.Method cand : g96.getClass().getDeclaredMethods()) {
            Class<?>[] pt = cand.getParameterTypes();
            if (pt.length == 1 && pt[0] == android.content.Context.class && cand.getReturnType() == sj6) {
                cand.setAccessible(true);
                im = cand;
                break;
            }
        }
        if (im == null) return false;
        Object inst = im.invoke(g96, app);
        if (inst == null) return false;
        java.lang.reflect.Field df = sj6.getDeclaredField("d");
        df.setAccessible(true);
        Object flow = df.get(inst);
        if (flow == null) return false;
        java.lang.reflect.Method gv = findMethod(flow.getClass(), "getValue");
        if (gv == null) return false;
        Object list = gv.invoke(flow);
        String id = existingId(list);
        if (id == null) return false;
        JSONObject o = jsonCard();
        o.put("id", id);
        // Solo se reescribe si el diseno de esta version es distinto al ya renovado (asi no parpadea en cada apertura).
        android.content.SharedPreferences sp = ((android.content.Context) app).getSharedPreferences("eclipse_es_bitchord", 0);
        String stamp = Integer.toHexString(o.toString().hashCode()) + ":" + id;
        if (stamp.equals(sp.getString("card", null))) return true;
        Object design = Class.forName("pp7").getMethod("a", JSONObject.class).invoke(null, o);
        java.lang.reflect.Method up = findMethod(sj6, "u", Class.forName("al7"));
        if (design == null || up == null) return false;
        up.invoke(inst, design);
        sp.edit().putString("card", stamp).apply();
        return true;
    }

    /** Gancho del parche de Letras: se llama al inicio de st7.c (elegir tarjeta) y de pq7.a (plantilla Nuevo reproductor). */
    public static void enableLyrics() {
        lyricsMode = true;
    }

    /**
     * Busca entre los disenos del usuario (lista de ib6) uno llamado "Bitchord (integrado)" y devuelve su id, o null.
     * Se usa reflexion sobre los campos publicos de ib6: a = id, b = nombre. Cualquier fallo devuelve null.
     */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                Object name = fieldOf(d, "b");
                if (cardName().equals(name)) {
                    Object id = fieldOf(d, "a");
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * BITCHORD (ordinal 7 del enum de reproductores integrados) se trata como CUSTOM (ordinal 6) donde la app
     * decide como dibujar el reproductor. Cualquier otro valor (o null) se devuelve igual.
     */
    public static Object norm(Object value) {
        try {
            if (value instanceof Enum) {
                Enum<?> e = (Enum<?>) value;
                if (e.ordinal() == 7) {
                    Object[] all = e.getDeclaringClass().getEnumConstants();
                    if (all != null && all.length > 6) return all[6];
                }
            }
        } catch (Throwable ignored) {
        }
        return value;
    }

    /**
     * Valor de "playerStyle" que llega del servidor (zx7.b). Si el estilo guardado en el telefono es BITCHORD
     * devuelve null para que la app ignore ese ajuste y no cambie la seleccion. Cualquier otro caso: se devuelve igual.
     */
    public static String serverStyle(android.content.Context ctx, String server) {
        try {
            if (server != null && ctx != null) {
                String local = ctx.getSharedPreferences("eclipse_settings", 0).getString("player_style", null);
                if ("BITCHORD".equals(local)) return null;
            }
        } catch (Throwable ignored) {
        }
        return server;
    }

    private static volatile Object currentCard;
    private static int previewResId = -1;

    /** Lo llama i92.o al entrar: anota que tarjeta (valor del enum) se esta dibujando. */
    public static void card(Object fl6) {
        currentCard = fl6;
    }

    /**
     * Lo llama i92.o justo antes de painterResource con el id original. Si la tarjeta actual es BITCHORD
     * (ordinal 7) devuelve el id del recurso "player_preview_bitchord"; si no existe, el original.
     */
    public static int previewId(int original) {
        try {
            Object c = currentCard;
            if (c instanceof Enum && ((Enum<?>) c).ordinal() == 7) {
                if (previewResId == -1) {
                    int id = 0;
                    Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                    if (app instanceof android.content.Context) {
                        android.content.Context ctx = (android.content.Context) app;
                        id = ctx.getResources().getIdentifier("player_preview_bitchord", "drawable", ctx.getPackageName());
                    }
                    previewResId = id;
                }
                if (previewResId != 0) return previewResId;
            }
        } catch (Throwable ignored) {
        }
        return original;
    }

    /** Posicion de la tarjeta Bitchord en la lista (0 = primera, arriba a la izquierda; 1 = segunda; etc.). */
    private static final int CARD_POSITION = 0;

    /** Lo llama kd.invoke con la lista de tarjetas: mueve BITCHORD (ordinal 7) a CARD_POSITION. */
    public static void reorder(java.util.List<Object> list) {
        try {
            int from = -1;
            for (int i = 0; i < list.size(); i++) {
                Object o = list.get(i);
                if (o instanceof Enum && ((Enum<?>) o).ordinal() == 7) {
                    from = i;
                    break;
                }
            }
            if (from < 0) return;
            Object card = list.remove(from);
            int to = Math.max(0, Math.min(CARD_POSITION, list.size()));
            list.add(to, card);
        } catch (Throwable ignored) {
        }
    }

    /** Nombre del diseno interno que crea la tarjeta Bitchord (se oculta de "Your Custom Players"). */
    // v0.20.37: nombres nuevos para que la tarjeta cree un diseno con el Bitchord actualizado (uno ya guardado no se actualiza).
    // Los nombres viejos se siguen ocultando de "Your Custom Players".
    private static final String CARD_NAME = "Bitchord 2 (integrado)";
    private static final String CARD_NAME_LYRICS = "Bitchord Letras 2 (integrado)";
    private static final String CARD_NAME_MORPH = "Bitchord Letras animada (integrado)";
    private static final String CARD_NAME_V2 = "Bitchord V2 (integrado)";
    private static final String CARD_NAME_OLD = "Bitchord (integrado)";
    private static final String CARD_NAME_LYRICS_OLD = "Bitchord Letras (integrado)";

    /** Con el parche de Letras la tarjeta usa un diseno interno nuevo (el viejo ya guardado no tiene las zonas). */
    private static String cardName() {
        if (lyricsMode && morphMode) return CARD_NAME_MORPH;
        return lyricsMode ? CARD_NAME_LYRICS : CARD_NAME;
    }

    /** Igual que json() pero con el nombre interno: es el diseno que usa la tarjeta (fijo, no se muestra en Custom). */
    public static JSONObject jsonCard() {
        JSONObject o = json();
        try {
            o.put("name", cardName());
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Lo llama kd.invoke con la lista de disenos de Custom: devuelve una copia sin el diseno interno de la tarjeta. */
    public static java.util.List<Object> visible(java.util.List<Object> designs) {
        try {
            if (designs == null) return designs;
            java.util.ArrayList<Object> out = new java.util.ArrayList<>(designs.size());
            for (Object d : designs) {
                if (d != null) {
                    Object n = fieldOf(d, "b");
                    if (CARD_NAME.equals(n) || CARD_NAME_LYRICS.equals(n) || CARD_NAME_MORPH.equals(n) || CARD_NAME_V2.equals(n)
                            || CARD_NAME_OLD.equals(n) || CARD_NAME_LYRICS_OLD.equals(n)) continue;
                }
                out.add(d);
            }
            return out;
        } catch (Throwable t) {
            return designs;
        }
    }
}
