package app.eclipse.extension.player;

import org.json.JSONObject;

/**
 * Diseno de reproductor "Bitchord" (archivo .eclipseplayer del usuario) para agregarlo a los
 * "Reproductores integrados" de Eclipse. Lo llama el parche "Reproductor integrado: Bitchord".
 */
public final class BitchordTemplate {
    private static final String JSON =
        "{\"id\":\"179c3f38-2106-4a88-9278-a4703b68a49e\",\"name\":\"Bitchord\",\"schemaVersion\":4,\"background\":{\"t" +
        "ype\":\"blurredArtwork\",\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1},\"gradient\":{\"s" +
        "tart\":{\"hue\":0.56,\"saturation\":0.6,\"brightness\":0.95,\"alpha\":1},\"end\":{\"hue\":0.75,\"saturation\":" +
        "0.6,\"brightness\":0.7,\"alpha\":1},\"angleDegrees\":135},\"blur\":0.5,\"dim\":0.3,\"opacity\":1},\"layers\":[" +
        "{\"id\":\"7b5f7d59-e0cd-42fc-8ec0-7296dcb47106\",\"kind\":\"artwork\",\"name\":\"Artwork\",\"transform\":{\"x\"" +
        ":0.5,\"y\":0.28,\"width\":1,\"height\":0.56,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\"" +
        ":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"" +
        "cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\"" +
        ":false,\"masksLayerBelow\":false,\"artwork\":{\"preferAnimated\":true,\"edgeFade\":{\"edge\":\"bottom\",\"frac" +
        "tion\":0.35,\"stops\":[[0,0],[0.3,0.18],[0.65,0.72],[0.92,1],[1,1]],\"color\":{\"hue\":0,\"saturation\":0,\"br" +
        "ightness\":0,\"alpha\":1,\"role\":\"immersive\"}}}},{\"id\":\"1a942757-b03b-489e-9509-f096be7a0e7d\",\"kind\":" +
        "\"songTitle\",\"name\":\"Song Title\",\"transform\":{\"x\":0.40900000000000003,\"y\":0.526,\"width\":0.66,\"he" +
        "ight\":0.036,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":" +
        "\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"" +
        "_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"T\u00edtulo de la canci\u00f3n\"," +
        "\"fontSize\":20.49510955810547,\"weight\":\"bold\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOv" +
        "erflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":" +
        "false},{\"id\":\"066c0aae-1ca8-4f69-a48d-dcee93475957\",\"kind\":\"artistName\",\"name\":\"Artist Name\",\"tra" +
        "nsform\":{\"x\":0.40900000000000003,\"y\":0.554,\"width\":0.66,\"height\":0.03,\"rotationDegrees\":0,\"aspectR" +
        "atio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturatio" +
        "n\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgrou" +
        "ndBlur\":0},\"text\":{\"content\":\"Nombre del artista\",\"fontSize\":18.247268676757812,\"weight\":\"medium\"" +
        ",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":f" +
        "alse},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"40a08d0e-cc4a-4ed9-aaa3-bd8c57afb" +
        "cb8\",\"kind\":\"shape\",\"name\":\"Menu disc\",\"transform\":{\"x\":0.879,\"y\":0.54,\"width\":0.088,\"height" +
        "\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"bl" +
        "endMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"un" +
        "iform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visible\":tr" +
        "ue,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"da12b82d-b17f-4a34-a5f6-ad58f7104ee0\",\"kind\":\"thr" +
        "eeDotMenu\",\"name\":\"Menu\",\"transform\":{\"x\":0.879,\"y\":0.54,\"width\":0.07230528444051743,\"height\":0" +
        ".02265349814219462,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opac" +
        "ity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRa" +
        "dius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false," +
        "\"masksLayerBelow\":false,\"symbolOverride\":\"menu.dots\"},{\"id\":\"199d8ff7-0bc3-4745-81d1-7c41182dc64f\",\"" +
        "kind\":\"progressBar\",\"name\":\"Progress\",\"transform\":{\"x\":0.5,\"y\":0.634,\"width\":0.845,\"height\":0" +
        ".030219625681638718,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blend" +
        "Mode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"unifo" +
        "rm\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBel" +
        "ow\":false,\"seekBarStyle\":\"classic\"},{\"id\":\"1543b853-5a76-4d5a-9da2-f62c8a98df11\",\"kind\":\"elapsed\"" +
        ",\"name\":\"Elapsed\",\"transform\":{\"x\":0.14900000000000002,\"y\":0.654,\"width\":0.14,\"height\":0.02,\"ro" +
        "tationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"ti" +
        "nt\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"inn" +
        "erShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13,\"weight\":\"medium\",\"" +
        "design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":fals" +
        "e},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"929e624d-01c6-44c4-a735-109f2a83922b" +
        "\",\"kind\":\"remaining\",\"name\":\"Remaining\",\"transform\":{\"x\":0.851,\"y\":0.654,\"width\":0.14,\"heigh" +
        "t\":0.02,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"" +
        "normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_" +
        "0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"3:42\",\"fontSize\":13,\"weight\":" +
        "\"medium\",\"design\":\"default\",\"alignment\":\"trailing\",\"allowsOverflow\":false,\"letterSpacing\":0,\"up" +
        "percase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"remaining\":{\"prefix\":\"-\"}}" +
        ",{\"id\":\"1dca8eea-9c1c-4829-a7fa-3e5a18f7ce32\",\"kind\":\"previous\",\"name\":\"Previous\",\"transform\":{\"" +
        "x\":0.202,\"y\":0.749,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"" +
        "h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightn" +
        "ess\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"v" +
        "isible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"previous.double\"},{\"id\":\"eae" +
        "1845f-5015-4c27-acf9-2093fe8d9306\",\"kind\":\"playPause\",\"name\":\"Play\\/Pause\",\"transform\":{\"x\":0.5," +
        "\"y\":0.749,\"width\":0.11972156167030334,\"height\":0.010721312630457187,\"rotationDegrees\":0,\"aspectRatio\"" +
        ":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"s" +
        "aturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"" +
        "backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"play.thic" +
        "k\"},{\"id\":\"139922bb-1e33-4b4c-b400-9913466e32f8\",\"kind\":\"next\",\"name\":\"Next\",\"transform\":{\"x\"" +
        ":0.8,\"y\":0.749,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":" +
        "1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\"" +
        ":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visibl" +
        "e\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"next.double\"},{\"id\":\"40b6ed56-eb1" +
        "f-4eea-8786-1021a9125aff\",\"kind\":\"image\",\"name\":\"Volume min\",\"transform\":{\"x\":0.102,\"y\":0.831,\"" +
        "width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":" +
        "{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"" +
        "cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"imageData\":\"iVBORw0KGg" +
        "oAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAQeUlEQVR4Ae3BC\\/CldX0f4OenZLMSZl0J67KBVXbpElkqpFwUXeUomODCOBJTkjWTNmAnyK" +
        "hLUNvRdlJbTTMaM426atXYeBnsIFMVqQ0XE7kU+UNDrUgULwejaOOBqWOpg4bRlk8zbaaTWi+Ae959f+f9Pk9LopQyTS2JUso0tSRKKdPUkiil" +
        "TFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUki" +
        "ilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPU" +
        "kiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKeRjW4QR8FvcpXWpJlPIQbMTP42U4FX" +
        "+Kt+CP8A2lKy2JUh6EDXgp\\/h6O9v\\/7Mt6DP8BC6UJLopQfYQc+jJ1+tDleg\\/cpo9eSKOWHeB4uxToPzZ\\/gBfiqMlotiVJ+gDfiNz18" +
        "38TzcaUySi2JUr7HYbgaJ9k\\/\\/gHepYxOS6KUv+GJ+CgOt\\/\\/8JU7GHcqotCRK+Wtn4w+x2f53O56M+5XRaEmU8lcuwpss1yvwemU0Wh" +
        "Jl8t6CF1u+z+E5uFMZhZZEmaz1+DDONIwFzsYnlVFoSZRJOgx\\/im2GdTquU0ahJVEmZxs+iUcb3h5cpoxCS6JMypNxI37CgfEivE0ZhZZEmY" +
        "y\\/i8vwCAfOBXinMgotiTIJr8DrHHh7cJkyCi2JsvL+EC8wDrtxtTIKLYmysh6Bt+M3jMfpuE4ZhZZEWVmX4NeMxz14Dm5VRqElUVbSJ3Cicb" +
        "kbZ+AOZRRaEmXl3IxTjc9tOBd3KqPQkigr5UrsNk4LPAt3KKPQkigr44N4nnF7Em5VRqElUVbCJfg143c6rlNGoSVRuvcGXKwP5+AKZRRaEqVr" +
        "r8Ur9eM8vFcZhZZE6dY\\/xWv05UV4mzIKLYnSpRfhrfrzErxVGYWWROnOeXi3Pl2ENyuj0JIoXfkVvF+\\/LsA7lVFoSZRuPBtX6dsFeKcyCi" +
        "2J0oVn4lr9Ow\\/vVUahJVFG76m4yWo4D+9VRqElUUbteNyGZjXswWXKKLQkymg9AZ\\/BI6yOPbjMsLbhcbgV31b+r5ZEGaWj8Xk80mo5B1cY" +
        "zmn4AzyAb+F6\\/BnehwdMXEuijM4WfBnrrJ5zcIVhPBcf9v39W\\/yyiWtJlFHZhK9gvdW0G1cbxlV4th9sDWfgfhPVkiijsR2fwXqrazeutn" +
        "yH4RYc7Yf7In4O95mglkQZhTNxCTZZbbtxteU7EZ\\/w4NyN4\\/ANE9OSKAfUevwLvNw0nI7rLN8JuApbPDj34G\\/hPhPSkigHzA5cgWNNx+" +
        "m4zvLtwA3Y4sGb42R800S0JMrgNuEUfBDrTcsurFm+rbgJWz0038FRWJiAlkRZusNwJJ6On8dx2G6admHN8m3CLdjuofsuHo+FFdeSKA\\/bOh" +
        "yEg3AQfhLr8Sisx9NwBo7D\\/TjOtN2D5+BWy7cRazjWw\\/NdPB4LK6wlsaLWYT1+Co\\/FTyIevAdwMA7FRmzAY\\/AYPBqPxqNxCB6F9ViH" +
        "n8Ajcbjyve7Bc3Cr5TsE1+MkD9938XgsrKiWxIr4WZyMn8ZOPA5HYgO+hZ3KgXYPzsSnLN96XIPT\\/Hi+hKfha1ZQS6JzG\\/GPcC52KGN2D8" +
        "7EpyzfOlyOs\\/z43oPzraCWRMeOxx\\/hSKUHd+MM3GEYl2KP\\/ePp+LgV05Lo1Mm4VenJ3TgDdxjG23Ch\\/WOOE3GfFdKS6NBGfAqPU3qy" +
        "wAxzw3gtXmn\\/eRV+2wppSXTopfh9pTcLzDA3jBfjLfafb+FEfMGKaEl05lB8FCcpvbkN5+JOw\\/iH+D3714dwLh6wAloSnTka1+NIpTcL7M" +
        "anDONVeLX967\\/hGbjdCmhJdOYEXIPNSo9Ox3WG8Sq82v73JlxsBbQkOvNsXKX0ag8uM4zX4pX2vwX+Du7RuZZEZ34d71F6dRHebBhvwMWW4w" +
        "K8U+daEp15FV6t9Op1+MeG8QZcbDluxy7cp2Mtic68HS9UevVuvMAw3oYLLc8zcIOOtSQ6sg4fxm6lV1fiF\\/Edy\\/cunG95\\/h2eq2MtiY" +
        "6sxwdwttKrq\\/FL+LblexfOtzx34Lm4U6daEh05BNfiFKVXf4Kz8R3Ldyn2WK6X4\\/d1qiXRkUNwPU5SevV+PN8wLsUey3Ubno77dKgl0ZFD" +
        "cD1OUnr1RrzUMD6I51m+p+AWHWpJdGQDbsTxSq9egddbvnW4HGdZvn+FF+tQS6IjG3Ajjld6dR7ea\\/nW4XKcZfm+gpPwdZ1pSXRkA27E8Uqv" +
        "duNqy7cOV+IMwzgXH9CZlkRHNmINxyo9ugfPwa2Wbz2uwWmGcSXO1pmWREc2Yg3HKj26DefiTsu3HtfgNMP4NJ6LP9eRlkRHNmINxyo9+gs8E3" +
        "PLdzCuxZMN52xcqSMtiY5sxBqOVXq0wAxzy7ceH8DZhvNK\\/K6OtCQ6cihuxjFKjxaYYW751uMqPMNwrsA5OtKS6MihuBnHKD1aYIa55VuHy3" +
        "GW4Xwau\\/BNnWhJdORQ3IxjlB4tMMPcMC7FHsO5GzN8QSdaEh3ZhFuwXenRAjPMDeNdON+wzsaVOtGS6Mgm3ILtSo8WmGFuGG\\/AxYb1avxz" +
        "nWhJdGQTbsF2pUcLzDA3jFfh1Yb1Pvw6HtCBlkRHtmANRyk9WmCGuWG8GG8xrJvxLHxbB1oSHdmCNRyl9GiBGeaG8WK8xbA+i6fiXh1oSXRkC9" +
        "ZwlNKjBWaYG8Ze7DOsu\\/AULHSgJdGRLVjDUUqPFphhbhh7sc+w7sZpmOtAS6IjW3ETtio9WmCGuWHsxT7DexJu1YGWREe24iZsVXq0wAxzw9" +
        "iLfYa3C2s60JLoyFbchK1KjxaYYW4Ye7HP8HZhTQdaEh3ZhhtxhNKjBWaYG8Ze7DO8XVjTgZZER7bhRhyh9GiBGeaGsRf7DG8X1nSgJdGRbbgR" +
        "Ryg9WmCGuWHsxT7D24U1HWhJdGQHbsAWpUcLzDA3jL3YZ3i7sKYDLYmO7MAN2KL0aIEZ5oaxF\\/sM7ym4RQdaEh3ZgRuwRenRAjPMDWMv9hnW" +
        "XXgKFjrQkujIDtyALUqPFphhbhh7sc+wPo4z8W0daEl0ZCc+hsOVHi0ww9ww9mKfYb0JF+tES6IjO\\/ExHK70aIEZ5oaxF\\/sM61x8QCdaEh" +
        "3ZiY\\/hcKVHC8wwN4y92Gc4d+FkfF0nWhIdOQHXYLPSowVmmBvGXuwznDfipTrSkujICbgGm5UeLTDD3DD2Yp9h3Itn4RM60pLoyAm4BpuVHi" +
        "0ww9ww9mKfYazhmfiOjrQkOnIKPoLNSo8WmGFuGHuxzzB+A\\/9aZ1oSHTkFH8FmpUcLzDA3jL3YZ\\/m+hhNxj860JDpyCj6CzUqPFphhbhgv" +
        "xNst33twvg61JDpyIj6h9GqBGeaG8Tv4J5brXuzGLTrUkujITvwxfkbp0QIzzA3jXTjfct2OXbhPh1oSHdmGG3GE0qMFZphbvnW4HGdZrovwZp" +
        "1qSXRkE27BdqVHC8wwt3wH41o82fL8V5yCu3SqJdGRjVjDsUqPFphhbvk2Yg3HWp7LsEfHWhIdORgfwplKjxaYYW75tmANR1meX8Af61hLojP\\" +
        "/Br+q9GiBGeaWbwduwBbL8Vk8CffpWEuiM6\\/A65QeLTDD3PKdiE9Ynt\\/C7+hcS6Iz5+BypUcLzDC3fCfhI9hi\\/\\/sMTsb9OteS6MxOX" +
        "IvNSm8WmGFu+U7ANdhs\\/\\/pLPBFftAJaEp05DNfgRKU3C8wwt3w78TEcbv+6EO+wIloSHXoZ\\/qXSmwVmmFu+HbgBW+w\\/V2O3FdKS6NB" +
        "G\\/BmOVHqywAxzy7cDN2CL\\/eMb+Fl83QppSXRqFz6u9GSBGeaWbxtuxBH2jzPxUSumJdGxp+E6HKT0YIEZ5pZvK27CVj++t+IlVlBLonMn4" +
        "EPYrozdAjPMLd8WrOEoP545TsR9VlBLYgU8Fi\\/Dr+AoZawWmGFu+TbhFmz38P0FTsI9VlRLYoUcirNxEU5WxmaBGeaWbxNuwXYPzwP4Gdxjh" +
        "bUkVtDB+Ns4A2fiCNyPTfaPe\\/E\\/8dN+sM3K91pghrnlOxQ34xgPXXA8Pm3FtSRW3Dpsxjb8D\\/tH\\/B\\/ND\\/YAtmIbtuNx2IzH4CB" +
        "sNT0LzDC3fBuxhmM9NA\\/gOHzOBLQkyiDWYR0ehQ3YiQ9gnelYYIa55duAG3G8B+9uPA1fNBEtiXLA7MS12GwaFphhbvkOwfU4yYPzNZyKr5q" +
        "QlkQ5oDbgKjzV6ltghrnlOxhX4Fl+tM\\/jVNxrYloSZRT+Pc622haYYW4Ye7HPD3cNzsH9JqglUUbjg3ie1bXADHPDeCyuxXG+v9fjFSasJVF" +
        "G5UrstpoWmGFuOE\\/AZ\\/2\\/vokX4v0mriVRRudaPNPqWWCGuWEdjbdhB27HhVgoWhJllG7GqVbLAjPMHRjPwG24V\\/nfWhJltD6Jn7M6F" +
        "phhroxCS6KM2h041mpYYIa5MgotiTJq63EHtunfAjPMlVFoSZTRW485jtS3BWaYK6PQkihdOAR3YrN+LTDDXBmFlkTpxgZ8CYfq0wIzzJVRaEm" +
        "UrmzEXdigPwvMMFdGoSVRunMY7sLB+rLADHNlFFoSpUub8BWs148FZpgro9CSKN3agi9jnT7chnNxpzIKLYnSta34cxxk\\/BbYjU8po9CSKN0" +
        "7Gp\\/HI43fLqwpo9CSKCvhCfgMHmHcduNqZRRaEmVlHIH\\/hMON1x5cpoxCS6KslE34L1hnnC7AO5VRaEmUlbMDd+Ag4\\/PP8BplFFoSZSV" +
        "txZ1YZ1zeiJcqo9CSKCtrC+7Ewcbj3XiBMgotibLSDsMXscE4fAi\\/pIxCS6KsvI34HDY78D6Gs\\/Ad5YBrSZRJOAS3Y5sD66P4RXxbOeBaE" +
        "mUy1uM\\/41gHzjtwoTIKLYkyOTfjVAfG8\\/F+ZRRaEmWSrsRuw7oHp+ELyii0JMpkfRDPM5zb8HTcp4xCS6JM2jtwgWG8GRcpo9GSKJP3Blx" +
        "sue7FkzBXRqMlUcpf+S38tuV5K16ijEpLopS\\/9nz8Ho6wf\\/13PBFfVUalJVHK33AoXo7fxE\\/ZP\\/4+LlFGpyVRyvdxDN6MX\\/Dj+VV" +
        "cqoxSS6KUH+JsvANHeGgewHm4RBmtlkQpP8KheDn2YLsf7bt4Fv6DMmotiVIepGNwIfZgi+9vjjPxJWX0WhKlPESb8cs4H4\\/CI\\/EfcTsuw" +
        "d1KF1oSpTxMG7ATn8O9SndaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqW" +
        "UaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaE" +
        "qWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZp" +
        "aEqWUafpfIpO0TMleHq8AAAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"" +
        "f14f7c97-f9f0-40a0-a226-4c48b8e00576\",\"kind\":\"image\",\"name\":\"Volume max\",\"transform\":{\"x\":0.896,\"" +
        "y\":0.831,\"width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"a" +
        "ppearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"" +
        "alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"imageData\"" +
        ":\"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAYDklEQVR4Ae3BDdjedV0o8M9v0Fo0ce2wxnh6ZA9rOEkHCpMxBG7AADV5M99" +
        "fUisxFV96UbJOluVR03NELBM7Kh6tg5IJgmdACo6HjfFy6yAdMGQTEXFCQPMvjgl8u07nujpXV6aM3b\\/\\/\\/b+f+\\/v5lIiQUhpPJSKkl" +
        "MZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTy" +
        "ViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJC" +
        "Cml8VQiQkppPJWIkFIaTyUipDREP4\\/9cRO2YYfUmhIRUhqC+XguXofdMBu34Gpcja\\/in3C\\/VE2JCCm1aHe8AO\\/EL\\/jP3Yx78A+4E" +
        "muwQxqoEhFSatHf4oV23lX4A6zFDmkgSkRIqSUb8QS7Zi3ejHXSLisRIaUW3ITHG4wGV+CPca30qJWIkFJlF+FZBq\\/BpXg7rpd2WokIKVW0F" +
        "9ZhqXq+hwvwNmyWHrESEVKqaAWu0Y5v4PdxrvSIlIiQUkVvxPu061N4FbZJP1aJCClVdAFO1L47cRKulf5TJSKkVMl8XITDDMcP8Ra8T\\/qRS" +
        "kRIqZI5uARHGq4r8Dxslf6dEhFSquhDOM3wbcPzcbH0b0pESKmi1+P9uuM9eLP0r0pESKmio3GZblmDE7DdmCsRIaWK9sJa7K9bbsMhuNsYKxE" +
        "hpcoW4puYrVu+h1\\/C7cZUiQgpteBAXI6f0y07sBJfMYZKREipJYfgKuyuWx7GybjQmCkRIaUWHYB\\/xCzdcxSuMEZKREipZRNYi311z3H4B" +
        "2OiRIQ00mbh6bgXBfdiK7bptgV4K56PRbrl5fi4MVAiQhpZc\\/FBvNT\\/twk7cCuuwjfxeWzTTQvxPPwGluuOF+BTZrgSEdJI2her8QQ\\/2" +
        "bV4GW7SXXNxMF6DJ2Op4TsZF5jBSkRII2cS12KhR2473oizdd8U\\/hQvNnzPwMVmqBIR0kiZxBbs5tH5FF6GHbrvuTgbP2e4jsHlZqASEdLIm" +
        "MQW7GbXXIyTsEP3LcCHcKrhOhzrzDAlIqSRMIkt2M1gPA\\/nGR3Pxkexl+EIHIQbzCAlIqTOm8QW7GZwNuJQNEbHXjgTLzYcD+OXcJMZokSE1" +
        "GmT2ILdDN4L8Cmj5zj8DfbSvofweNxqBigRIXXWJLZgN3VchpPQGD174Uy8WPsexH643YgrESF10iS2YDf1bMThuM\\/oOg5n4gnatQOLcacRV" +
        "iJC6pwluBm7qesbWIU7jbZ5OB9Hadd2PA53GVElIqROWYJNmKW+O3AEtpgZbsLjtet+7Iu7jaASEVJnLMEmzNKOrTge15s5bsLjtesGHIFtRky" +
        "JCKkTlmATZmnXMbjczHI9lmvXu\\/D7RkyJCGnolmATZmnfSficmed6LNee7ViFrxghJSKkoVqCTZhlOI7HpWamq\\/FU7bkRh+B+I6JEhDQ0S" +
        "7AJswzPMbjczHU1nqo9b8GfGxElIqShWIJNmGW4Dsc6M9vVeKp23I8nY5MRUCJCat0yfA2zDNdWPBvXmvm+hKO041ocie06rkSE1Kpl2Ihi+L6" +
        "DY7HReFiPQ7Xj9fiAjisRIbVmGTai6IY7cRRuMR7mYjMWqG8bnojbdViJCKkVy7ARRXfcgSOwxfhYin\\/ET6vvC\\/hlHVYiQqpuGTai6Jbbc" +
        "ThuN15Oxme146X4pI4qESFVtQwbUXTPZqzEXcbP+\\/BG9X0Vx+K7OqhEhFTNMmxE0U2bcBjuMZ6uwQr1vR4f0EElIqQqlmEjiu66Eatwn\\/G" +
        "0F27BPHXdjEPQ6JgSEdLALccGFN12A47ANuNrBdZhd3WdjAt0TIkIaaCWYwOK7rsUz0FjvL0U\\/0tda3AcduiQEhHSwCzHBhSj4TocjcZ4m4P" +
        "LcJh6tuF4rNchJSKkgViODShGRx89NOp7EvbA1brpibgae6jnPDxPh5SIkHbZcmxAMVr66KFR11H4azyIK\\/AhbNA978Mb1XMvDsUtOqJEhLR" +
        "LlmMDitHTRw+Nek7FZ\\/x738ZLcLlumY8bMKGed+MMHVEiQnrUlmMDitHURw+NOuahj\\/38aCfjAt3yLFyknjtwEO7WASUipEflibgBxejqo" +
        "4dGHSfiAj\\/eC\\/Ap3XIJjlPPG3CWDigRIe205ehjd6Otjx4adZyCv\\/eTvRYf1B1L8BU8Rh034xA0hqxEhLRTnoWPYYHR10cPjTpOwvkem" +
        "T\\/Cn+qO38V71HMyLjBkJSKkR+wteJeZo48eGnWchPM9cr+Oj+qGufgylqpjDY7DDkNUIkJ6RD6CV5pZ+uihUcdJON\\/OeRk+oRuehkvxMwZ" +
        "vG47HekNUIkL6sRbhvXiRmaePHhp1nITz7ZwH8XSs0Q0fwOvUcR6eZ4hKROioudgbj8V38c\\/Yjh1+stmYjdn4aczFY\\/EA7sb3sR07\\/Gi" +
        "T6OH5WIJlZqY+emjUcQJW23n3Yn\\/cbfgOxf\\/BfIN3Lw7FLYakRISOmIUT8Tgcjv3xWHwf83AvvoWbsQU34AE8DntiERZhHhZgHh6D2fhp\\" +
        "/BP2wG7Yhu\\/idmzFFtyMn8Vr8IvY38zXRw+NOk7Aao\\/OpTje8M3FWixXx7txhiEpEaEDFuFcHCm1qY8eGnWcgNUevd\\/G+wzf7+I96ujj" +
        "BNxtCEpEGLKT8Ak8RmpbHz006jgBqz16O7ACNxiufXEtFhi8rTge1xuCEhGGZBb+BH8oDUsfPTTqOAGr7Zpv4knYZrg+i5PV8XJ83BCUiDAkH8" +
        "RvScPURw+NOk7AarvuHLzCcD0bn1PHh3GaISgRYQhOwGpp2ProoVHH0bjMYLwQ5xqe+ehjscG7Fj3cr2UlIrRsD1yF5dKw9dFDo46jcZnBuB8H" +
        "4DbD8w681eDdgcNwu5aViNCyU\\/EZqQv66KFRx9G4zODcgEOx3XAsx5fwcwbvGFyuZSUitOyTeLHUBX300KjjaFxmsM7Auw3HbFyOVQbvDLxb" +
        "y0pEaNE8XItflLqgjx4adRyNywzWV3EYGsPxEnzC4F2Ak7WsRIQWHYzrpK7oo4dGHUfjMoPXwxrDsRBfxj4G62asxH1aVCJCiw7GdVJX9NFDo4" +
        "5VWGvwzsErDM\\/H8HKD9V0ci69qUYkILVqBa6Su6KOHRh2rsNbgfQeH4A7D8VRcbfBegE9pUYkILVqBa6Su6KOHRh2rsFYdv4n\\/aTgOwD9g" +
        "H4P1frxRi0pEaNEKXCN1RR89NOpYhbXqWIejsUP7JrEWkwbrShyP+7WkRIQWrcA1Ulf00UOjjlVYq4778HT0tW8+rsL+BuubWIk7taREhBatwD" +
        "VSV\\/TRQ6OOFbgQC9VxJt6kfXPxJRxs8I7AlVpSIkKLVuAaqSv66KFRxwpciIXq+AYOxj3aNQeX4EiD9wacpSUlIrRoBa6RuqKPHhp1rMCFWK" +
        "ie5+LvtO8zONXgfRrP15ISEVq0AtdIXdFHD406VuBCLFTPajxT+\\/4KrzZ4X8Xh2KYFJSK0aAWukbqijx4adazAhVionn\\/CobhVu\\/4If2" +
        "Lwrsep2KwFJSK06CnoS13RRw+NOlbgQixU1xtwlnb9Jj6sjkPQ14ISEVp0Es6XuqKPHhp1HIhLsFBdZ+JN2vV8nKuOU3C+FpSI0KLX4\\/1SV\\" +
        "/TRQ6OOA3EJFqrrfJyiXUfjMnW8AWdpQYkILXof3ih1RR89NOo4EJdgobqmcRy2a8+BuAQLDd6ZeJMWlIjQos\\/iZKkr+uihUceBuAQL1XUjV" +
        "uE+7ZnCNCYM3vk4RQtKRGjJHrgMh0pd0UcPjToOxCVYqK5vYRVu154FWI\\/9DN7VOAb3q6xEhJbMx3oslbqijx4adRyIS7BQXVtxDDZqzzysw" +
        "xMM3jqchLtVViJCSxbjM3iK1BV99NCo4wB8EXur7xhcrj174DIcavC+jlW4S2UlIrRkClfgF6Su6KOHRh0H4IvYW30vx8e1ZzY+i2cavM1Yibt" +
        "UViJCS6YwjQmpK\\/rooVHHAfgi9lbfW\\/Dn2vVRvMLgbcZK3KWyEhFaMoVpTEhd0UcPjToOwBext\\/rOxqu16504w+BtxkrcpbISEVoyhWl" +
        "MSF3RRw+NOg7AF7G3+j6Bl+Nh7Xkt\\/sLgbcZK3KWyEhFaMoVpTEhd0UcPjTqWYg0Wqe+v8Brtei3+wuBtxkrcpbISEVoyhWlMSF3RRw+NOpZ" +
        "iDRap7214u3adjrMM3tX4FdytshIRWjKFaUxIXdFHD406lmINFqnv1Thbu07HWQavjx4alZWI0JIpTGNC6oo+emjUsRRrsEh9p+B87TodZxm81" +
        "TgZO1RWIkJLpjCNCakr+uihUcdSrMEi9R2Oddp1Os4yeOfgFVpQIkJLpjCNCakr+uihUcdSrMEidW3FMdioXafjLIP3NrxdC0pEaMkUpjEhdUU" +
        "fPTTqmMI0JtT1LazC7dp1Os4yeK\\/G2VpQIkJLpjCNCakr+uihUccUpjGhrluwEvdo1+k4y+A9AxdrQYkILZnCNCakruijh0YdU5jGhLq+gFP" +
        "QaNdp+JDB2orjcb0WlIjQkilMY0Lqij56aNQxhWlMqOtsvFr7\\/jdeYLC+jadhixaUiNCSKUxjQuqKPnpo1DGFaUyo64U4V7vmYhoHGaxbsBL" +
        "3aEGJCC2ZwjQmpK7oo4dGHVOYxoR6tuJIbNKuSVyFCYP1ZRyFRgtKRGjJFKYxIXVFHz006pjEWkyqZwOOQKNdT8O0wVuNk7FDC0pEaMkUpjEhd" +
        "UUfPTTqmMRaTKrnwzhN+07DhwzeOXiFlpSI0JIpTGNC6oo+emjUMYm1mFTPC3Gu9p2NVxm8t+HtWlIiQksW4zN4itQVl+I5aNQxibWYVMdWHIl" +
        "N2rUHvoQVBu\\/l+LiWlIjQkklMY1+pK67HkdimjkmsxaQ6NuAINNq1COvxOIP3DFysJSUitGQB1mM\\/qSs24TDco45FWIfF6vgwTtO+Ffg8F" +
        "hisrTge12tJiQgtmYd1eILUFZuxEnepYxHWYbE6nou\\/075fwzkG79t4GrZoSYkILZmLL+FgqStux+G4XR2LsA6LDd5tOAR3a9+ZeIPBuwUrc" +
        "Y+WlIjQkjm4BEdKXXEHjsAWdSzCOiw2eGfiTdo3GxfjaIP3BZyCRktKRGjJLHwCL5K64js4FhvVsQjrsNhg3YsebtC+vXARDjV478GbtahEhBa" +
        "9Eh+RumIrno1r1bEI67DYYF2E52CH9p2Kz6jjKFyhRSUitGhfrMfeUlccjnXqWID12M\\/gNDgItxqOz+OZBu\\/rWIH7tKhEhJZdhGdJXfEMX" +
        "KyOBViP\\/QzOq\\/DXhmMJ1mMvg\\/dJvFTLSkRo2a\\/iPKkrTsLn1LEA67GfwViHww3P7+C96ngO\\/l7LSkRo2R5Yi4OkLjgel6pjAdZjP" +
        "7uuwRNxm+GYi2kcZPDuwArcqWUlIgzBM\\/F5qQsOxzp1LMB67GfX\\/QY+YnhW4ip1\\/B1eiAe1rESEIdgdq\\/F0aZi24nhcr475uAiH2TV" +
        "\\/jVcZrr\\/Ea9TxYvytISgRYUjmYCOmpGG5E0fhFnUswlpMefTW4zDDtRcuxsEG7w4cjK2GoESEIZqDG7FYGobbcThuV8ck1mLSo\\/MdPB7" +
        "bDNfpOEsdH8MrDUmJCEO2O87DyVLbNmMl7lLHUqzBIjtvO34RdxiuubgOj1fHUbjCkJSI0AGzcSL+K5ZLbbkRq3CfOg7AF7G3nfMwVuFqw3cSz" +
        "lfHJhyK+wxJiQgdMhcH4FgcjwlsxwIEAg\\/iITyMB\\/EQ7seDeAA\\/xAPYhh\\/gAWzHvdiOH2A7duA+PIAH8D08BS\\/C3ngI\\/wX3Ypm" +
        "Z6VI8B406VuBCLLRzXopPGr7ZWIOV6ngH\\/tAQlYjQUbOxEJP4Pn6IH2I7HsSDeAgP40E8jIfxsP9nh0dnNhZjAg\\/g+3gTfs3Mcx2ORqOOV" +
        "Vhr55yGD+uGlbgEexq8e3A0bjBEJSKkR+QjeKWZpY8eGnWcgNUeuRfiXN3xaTxXHVfiWOwwRCUipEfsLXiXmaOPHhp1PAsX+ckexsvxCd2xDFd" +
        "hnjpeh780ZCUipJ3yLHwMC4y+Pnpo1LEKa\\/14D+AoXK1b3o\\/Xq2MrDsVthqxEhLTTlqOP3Y22Pnpo1LEUa7HAj7YVB+MO3bIQG7C3Ov4ez" +
        "9EBJSKkR+WJuAHF6Oqjh0Yde+BiHOE\\/ugLPxjbd82a8Wz0n4kIdUCJCetSW4WuYZTT10UOjnnk4A6fiIXwNX8KH8KDumYfrsEQdm7EC9+iAE" +
        "hHSLlmCm7Gb0dNHD436lmN3fFm3\\/SrOU88H8VodUSJC2mWTuBU\\/ZbT00UMj\\/V9LcD1+Vh334plYryNKREgDsQjfwGyjo48eGmkO+jhAP" +
        "RtwBBodUSJCGpgF+BZmGw199NBIb8U71PW7+O86pESENFALcBt+Rvf10UNjvJ2Mz6rrFpyIm3RIiQhp4PbCddhXt\\/XRQ2N8HYAN+Cl1\\/Tf" +
        "8gY4pESFVMQ\\/X43G6q48eGuNpHjZhgbq+gQOxTceUiJCq2RO3YZ5u6qOHxnhai1Xq+xV8XgeViJCq2hO3YZ7u6aOHxvh5J85Q34U4UUeViJC" +
        "q2xO3YZ5u6aOHxng5FZ9R3\\/fwZNyqo0pESK3YE7dhnu7oo4fG+DgAG\\/BT6vs9vFeHlYiQWrMnvo4FuqGPHhrjYR42YYH6bsFT0OiwEhFSq" +
        "+ZiMxYYvj56aIyH67FcfT\\/AcbhSx5WIkFo3F5uxwHD10UNjZtsTF6CnHefgFUZAiQhpKOZiMxYYnj56aMxc+2Id9tGOb+BJaIyAEhHS0MzFZ" +
        "iwwHH300JiZeliNOdrxAyzFHUZEiQhpqObiZuyjfX300Jh53ox3a89D6OFKI6REhDR0c3Ar9tGuPnpozBxz8Dc4Vbteh780YkpESJ0wB7diH+3" +
        "po4fGzLAAV2GJdn0SLzWCSkRInTEHt2If7eijh8boOxBXYq52fQ2HYLsRVCJC6pQ5uBX7qK+PHhqj7SU4B7tp1\\/exBFuNqBIRUufMwY1YrK4" +
        "v4BQ0RtcH8DrtewiH4VojrESE1ElzcCMWq+dsvNpomosL0TMcv46PGnElIqTOmoMbsVgdL8S5Rs8ULsb+huPDOM0MUCJC6rQ5uBGLDdbX8WzcZ" +
        "HRM4gw8A1OGo49DzBAlIqTOm4OrsdzgvBpnGw3z8dv4Lcw3PPdgKe4xQ5SIkEbCHJyD59t1n8NJum9PvAR\\/gH0M17dxCO40g5SIkEbKC\\/A" +
        "xzPHo3Ill2Ka79sCJ+DMsMXw\\/wL64ywxTIkIaOUtxAZ5g53wTT8VW3XUs\\/geW64Z78STcYQYqESGNpDn4M\\/yOR+YeLMNdumkF3o2jdcd" +
        "tOAj3maFKREgj7Wl4EY7F\\/n60a\\/As3K17DsA78Mv4Wd1xJX4Z281gJSKkGWEenoI\\/xs+j4Bpcjk+j0S2TOAMvw1zdcg5eYQyUiJBmlNl" +
        "4CjbhHt0zH6\\/DGzBf97wV7zQmSkRIqSUH4tPYX\\/cEno\\/zjJESEVJqwSG4Vjc9hGOxxpgpESGlyvbAFThY99yPJ2OTMVQiQkqVHYdLdM+" +
        "3cRDuMqZKREipsvPwq7rlWhyDxhgrESGlil6Ev9EtF+JESYkIKVUyH5fiYN3xXvye9K9KREipkr0wjWWG7\\/v4DZwr\\/ZsSEVKqZD6uwv6Ga" +
        "wNOxm3Sv1MiQkqVzMdV2N9w7MC78E5sl\\/6DEhFSqmQ+LsQq7fs2TkRf+k+ViJBSJbNxPp6hXefiNGyTfqwSEVKq6PV4v3Z8D7+JT0mPSIkIK" +
        "VW0P67EAnWtx6m4U3rESkRIqaJZuAjPUMc38GG8U9ppJSKkVNkcbMKkwbkXF+L9+LL0qJSIkFIL5uLrWGjX3IFP4iO4RdolJSKk1JI9sQXz7by" +
        "b8UH8Le6WBqJEhJRaNAdfwOEemXU4E6vRSANVIkJKLZuLp+EEHIzH4Z\\/xGNyFr+DL+Edchx1SFSUipDREe+Cx+AV8C\\/+M+6VWlIiQUhpPJ" +
        "SKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJ" +
        "KaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUx" +
        "lOJCCml8VQiQkppPP0LABjOaloe7ZYAAAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false}" +
        ",{\"id\":\"410b48b8-2098-4a60-b8d7-f090bbf94ffe\",\"kind\":\"volumeSlider\",\"name\":\"Volume\",\"transform\":" +
        "{\"x\":0.5,\"y\":0.831,\"width\":0.689,\"height\":0.03008730337023735,\"rotationDegrees\":0,\"aspectRatio\":{\"" +
        "free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brig" +
        "htness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0}," +
        "\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"b2ff67b3-3530-46c7-94dd-c035895f6d3c\"," +
        "\"kind\":\"shape\",\"name\":\"Pill\",\"transform\":{\"x\":0.5,\"y\":0.889,\"width\":0.336893230676651,\"height" +
        "\":0.05190802043658369,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.2,\"" +
        "blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"" +
        "uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"capsule\"},\"visible\"" +
        ":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"e7189c44-97e1-441d-a4e1-761134329afb\",\"kind\":\"" +
        "shape\",\"name\":\"Pill divider\",\"transform\":{\"x\":0.5,\"y\":0.889,\"width\":0.0016,\"height\":0.044,\"rot" +
        "ationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.35,\"blendMode\":\"normal\",\"ti" +
        "nt\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"inn" +
        "erShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"rectangle\"},\"visible\":true,\"locked\":false,\"" +
        "masksLayerBelow\":false},{\"id\":\"b61cb274-e3e9-4658-96f9-442cb5c586af\",\"kind\":\"lyrics\",\"name\":\"Lyric" +
        "s\",\"transform\":{\"x\":0.164,\"y\":0.889,\"width\":0.08991199731826782,\"height\":0.01,\"rotationDegrees\":0" +
        ",\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tin" +
        "t\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"inne" +
        "rShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOver" +
        "ride\":\"lyrics.apple\"},{\"id\":\"a98ae70c-fb89-43df-a12d-ec2aa603557e\",\"kind\":\"connect\",\"name\":\"Conn" +
        "ect\",\"transform\":{\"x\":0.417,\"y\":0.889,\"width\":0.0765811949968338,\"height\":0.014227520366003252,\"ro" +
        "tationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\"" +
        ":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{" +
        "\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":f" +
        "alse,\"symbolOverride\":\"connect.apple\"},{\"id\":\"63522f9f-99be-4da2-a0df-8f9b3ff1f392\",\"kind\":\"share\"" +
        ",\"name\":\"Persona\",\"transform\":{\"x\":0.583,\"y\":0.889,\"width\":0.06802937388420105,\"height\":0,\"rota" +
        "tionDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"" +
        "normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_" +
        "0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":fals" +
        "e,\"symbolOverride\":\"person.apple\"},{\"id\":\"15755ea9-75d8-45ad-a3d6-31f4a3e5ec7d\",\"kind\":\"queue\",\"n" +
        "ame\":\"Queue\",\"transform\":{\"x\":0.835,\"y\":0.889,\"width\":0.08035406470298767,\"height\":0.014655064936" +
        "159071,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"" +
        "blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"" +
        "uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLay" +
        "erBelow\":false,\"symbolOverride\":\"queue.list\"},{\"id\":\"44c92ff0-182c-46d5-a6dc-d0ef5cd2f024\",\"kind\":\"" +
        "outputName\",\"name\":\"Output\",\"transform\":{\"x\":0.5,\"y\":0.949,\"width\":0.5657686591148376,\"height\":" +
        "0.020744850834210717,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"bl" +
        "endMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"un" +
        "iform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13" +
        ".540205955505371,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"center\",\"allowsOverflow\":fals" +
        "e,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"outpu" +
        "tName\":{\"prefix\":\"\",\"showIcon\":false,\"useAccessoryName\":true}},{\"id\":\"ef3f9ed1-a083-46fd-b83b-5e21" +
        "de4a92e2\",\"kind\":\"qualityBadge\",\"name\":\"Quality Badge\",\"transform\":{\"x\":0.5,\"y\":0.6549999999999" +
        "999,\"width\":0.6522871255874634,\"height\":0.035,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appea" +
        "rance\":{\"opacity\":0.7032073736190796,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"bright" +
        "ness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"" +
        "visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"badge\":{\"showsBackground\":false,\"shape\":\"cap" +
        "sule\",\"backgroundOpacity\":0.12,\"fontSize\":12.69775390625,\"bold\":false,\"uppercase\":false,\"horizontalP" +
        "adding\":8,\"compact\":false,\"mode\":\"tier\",\"animated\":\"shimmer\",\"icon\":\"auto\"}},{\"id\":\"fb2595e5" +
        "-abb1-4a5e-9c9b-d943aa0dd1bd\",\"kind\":\"favorite\",\"name\":\"Favorite\",\"transform\":{\"x\":0.764792159497" +
        "5924,\"y\":0.5401221602056466,\"width\":0.07079613208770752,\"height\":0.042477679252624495,\"rotationDegrees\"" +
        ":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"" +
        "saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"" +
        "backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"favorite." +
        "star\"},{\"id\":\"ed0dfa18-f4f5-4963-a253-8dfebd68982c\",\"kind\":\"shape\",\"name\":\"Menu disc Copy\",\"tran" +
        "sform\":{\"x\":0.7639999999999999,\"y\":0.54,\"width\":0.088,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\"" +
        ":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"" +
        "saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"" +
        "backgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":fals" +
        "e}],\"createdAt\":8.145491185910001E8,\"updatedAt\":8.14562678435E8,\"requiredCapabilities\":{\"immersiveArtwo" +
        "rkFade\":1,\"statefulControls\":1}}";

    private BitchordTemplate() {}

    /** JSON del diseno, con el mismo formato que lee Eclipse al importar un .eclipseplayer. */
    public static JSONObject json() {
        try {
            return new JSONObject(JSON);
        } catch (Exception e) {
            throw new RuntimeException("Bitchord: JSON invalido", e);
        }
    }

    /**
     * Busca entre los disenos del usuario (lista de ib6) uno llamado "Bitchord" y devuelve su id, o null.
     * Se usa reflexion sobre los campos publicos de ib6: a = id, b = nombre. Cualquier fallo devuelve null.
     */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                Object name = d.getClass().getField("b").get(d);
                if ("Bitchord".equals(name)) {
                    Object id = d.getClass().getField("a").get(d);
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * BITCHORD (ordinal 7 del enum de reproductores integrados) se trata como CUSTOM (ordinal 6) donde la app
     * decide como dibujar el reproductor. Cualquier otro valor (o null) se devuelve igual.
     */
    public static Object norm(Object value) {
        try {
            if (value instanceof Enum) {
                Enum<?> e = (Enum<?>) value;
                if (e.ordinal() == 7) {
                    Object[] all = e.getDeclaringClass().getEnumConstants();
                    if (all != null && all.length > 6) return all[6];
                }
            }
        } catch (Throwable ignored) {
        }
        return value;
    }
}
