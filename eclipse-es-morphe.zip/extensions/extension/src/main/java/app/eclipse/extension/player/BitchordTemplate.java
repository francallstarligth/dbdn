package app.eclipse.extension.player;

import org.json.JSONObject;

/**
 * Diseno de reproductor "Bitchord" (archivo .eclipseplayer del usuario) para agregarlo a los
 * "Reproductores integrados" de Eclipse. Lo llama el parche "Reproductor integrado: Bitchord".
 */
public final class BitchordTemplate {
    private static final String JSON =
        "{\"id\":\"cd9bc2de-eeef-4de5-a3e4-e3a426d0555b\",\"name\":\"Bitchord\",\"schemaVersion\":4,\"background\":{\"type" +
        "\":\"blurredArtwork\",\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1},\"gradient\":{\"start\":{\"h" +
        "ue\":0.56,\"saturation\":0.6,\"brightness\":0.95,\"alpha\":1},\"end\":{\"hue\":0.75,\"saturation\":0.6,\"brightnes" +
        "s\":0.7,\"alpha\":1},\"angleDegrees\":135},\"blur\":0.5,\"dim\":0.3,\"opacity\":1},\"layers\":[{\"id\":\"a68d4210-5f" +
        "1f-4730-a052-5071d214aeee\",\"kind\":\"artwork\",\"name\":\"Artwork\",\"transform\":{\"x\":0.5,\"y\":0.28,\"width\":1" +
        ",\"height\":0.56,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":" +
        "\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}" +
        "},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"art" +
        "work\":{\"preferAnimated\":true,\"edgeFade\":{\"edge\":\"bottom\",\"fraction\":0.35,\"stops\":[[0,0],[0.3,0.18],[" +
        "0.65,0.72],[0.92,1],[1,1]],\"color\":{\"hue\":0,\"saturation\":0,\"brightness\":0,\"alpha\":1,\"role\":\"immersiv" +
        "e\"}}}},{\"id\":\"82beeee6-5b54-411b-b181-5ad5dcdf4174\",\"kind\":\"songTitle\",\"name\":\"Song Title\",\"transfor" +
        "m\":{\"x\":0.374,\"y\":0.526,\"width\":0.6031219363212585,\"height\":0.03556248685712678,\"rotationDegrees\":0," +
        "\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturatio" +
        "n\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBl" +
        "ur\":0},\"text\":{\"content\":\"T\u00edtulo de la canci\u00f3n\",\"fontSize\":20.49510955810547,\"weight\":\"bold\",\"design" +
        "\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false,\"marque" +
        "e\":{\"enabled\":true,\"speed\":40,\"gap\":48,\"startDelayMs\":1200}},\"visible\":true,\"locked\":false,\"masksLay" +
        "erBelow\":false},{\"id\":\"c56a7aa7-f759-4495-8a50-475a93705c10\",\"kind\":\"artistName\",\"name\":\"Artist Name" +
        "\",\"transform\":{\"x\":0.40900000000000003,\"y\":0.554,\"width\":0.66,\"height\":0.03,\"rotationDegrees\":0,\"asp" +
        "ectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\"" +
        ":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur" +
        "\":0},\"text\":{\"content\":\"Nombre del artista\",\"fontSize\":18.247268676757812,\"weight\":\"medium\",\"design\"" +
        ":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visibl" +
        "e\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"22dd74ee-ff43-4d93-b312-2f9c11da6a8b\",\"kind\":" +
        "\"shape\",\"name\":\"Menu disc\",\"transform\":{\"x\":0.879,\"y\":0.54,\"width\":0.088,\"height\":0,\"rotationDegrees" +
        "\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{" +
        "\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":f" +
        "alse,\"backgroundBlur\":0},\"shape\":{\"type\":\"circle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":f" +
        "alse},{\"id\":\"a460d4e8-cfb6-4de2-afad-ad056633ef22\",\"kind\":\"threeDotMenu\",\"name\":\"Menu\",\"transform\":{" +
        "\"x\":0.879,\"y\":0.54,\"width\":0.07230528444051743,\"height\":0.02265349814219462,\"rotationDegrees\":0,\"asp" +
        "ectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"s" +
        "aturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"back" +
        "groundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"menu.dots\"},{" +
        "\"id\":\"3792834b-1597-481a-a1fb-c51451c609ef\",\"kind\":\"progressBar\",\"name\":\"Progress\",\"transform\":{\"x\":" +
        "0.5,\"y\":0.634,\"width\":0.845,\"height\":0.030219625681638718,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":" +
        "{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"a" +
        "lpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true," +
        "\"locked\":false,\"masksLayerBelow\":false,\"seekBarStyle\":\"classic\"},{\"id\":\"888e1669-1214-4c0e-98a1-ff60" +
        "511a0e22\",\"kind\":\"elapsed\",\"name\":\"Elapsed\",\"transform\":{\"x\":0.14900000000000002,\"y\":0.654,\"width\":0" +
        ".14,\"height\":0.02,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendM" +
        "ode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_" +
        "0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"0:00\",\"fontSize\":13,\"weight\":\"medi" +
        "um\",\"design\":\"default\",\"alignment\":\"leading\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":fa" +
        "lse},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"e621874a-415c-4aa7-8447-e13d71945" +
        "bd4\",\"kind\":\"remaining\",\"name\":\"Remaining\",\"transform\":{\"x\":0.851,\"y\":0.654,\"width\":0.14,\"height\":0." +
        "02,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"" +
        "tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerSh" +
        "adow\":false,\"backgroundBlur\":0},\"text\":{\"content\":\"3:42\",\"fontSize\":13,\"weight\":\"medium\",\"design\":\"d" +
        "efault\",\"alignment\":\"trailing\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\"" +
        ":true,\"locked\":false,\"masksLayerBelow\":false,\"remaining\":{\"prefix\":\"-\"}},{\"id\":\"e612a752-6df7-4a1c-b" +
        "409-f667d33e5ca9\",\"kind\":\"previous\",\"name\":\"Previous\",\"transform\":{\"x\":0.202,\"y\":0.749,\"width\":0.163" +
        ",\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"bl" +
        "endMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\"" +
        ":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":f" +
        "alse,\"symbolOverride\":\"previous.double\"},{\"id\":\"fa426f11-7f09-4956-b944-b6fc8829774e\",\"kind\":\"playPa" +
        "use\",\"name\":\"Play\\/Pause\",\"transform\":{\"x\":0.5,\"y\":0.749,\"width\":0.11972156167030334,\"height\":0.0107" +
        "21312630457187,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1," +
        "\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"unifo" +
        "rm\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow" +
        "\":false,\"symbolOverride\":\"play.thick\"},{\"id\":\"2505061b-18fc-4271-814a-4cdca7f40daa\",\"kind\":\"next\",\"n" +
        "ame\":\"Next\",\"transform\":{\"x\":0.8,\"y\":0.749,\"width\":0.163,\"height\":0,\"rotationDegrees\":0,\"aspectRatio" +
        "\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturatio" +
        "n\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBl" +
        "ur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"next.double\"},{\"id\":\"" +
        "e270cb54-9509-4de3-9640-f36cae15ae8b\",\"kind\":\"image\",\"name\":\"Volume min\",\"transform\":{\"x\":0.102,\"y\":" +
        "0.841,\"width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance" +
        "\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"corn" +
        "erRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"imageData\":\"iVBORw0KGgoAAAAN" +
        "SUhEUgAAAQAAAAEACAYAAABccqhmAAAQeUlEQVR4Ae3BC\\/CldX0f4OenZLMSZl0J67KBVXbpElkqpFwUXeUomODCOBJTkjWTNmA" +
        "nyKhLUNvRdlJbTTMaM426atXYeBnsIFMVqQ0XE7kU+UNDrUgULwejaOOBqWOpg4bRlk8zbaaTWi+Ae959f+f9Pk9LopQyTS2JUso" +
        "0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFN" +
        "LopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSR" +
        "KKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQyTS2JUso0tSRKKdPUkiilTFNLopQ" +
        "yTS2JUso0tSRKeRjW4QR8FvcpXWpJlPIQbMTP42U4FX+Kt+CP8A2lKy2JUh6EDXgp\\/h6O9v\\/7Mt6DP8BC6UJLopQfYQc+jJ1+t" +
        "Dleg\\/cpo9eSKOWHeB4uxToPzZ\\/gBfiqMlotiVJ+gDfiNz1838TzcaUySi2JUr7HYbgaJ9k\\/\\/gHepYxOS6KUv+GJ+CgOt\\/\\/" +
        "8JU7GHcqotCRK+Wtn4w+x2f53O56M+5XRaEmU8lcuwpss1yvwemU0WhJl8t6CF1u+z+E5uFMZhZZEmaz1+DDONIwFzsYnlVFoSZR" +
        "JOgx\\/im2GdTquU0ahJVEmZxs+iUcb3h5cpoxCS6JMypNxI37CgfEivE0ZhZZEmYy\\/i8vwCAfOBXinMgotiTIJr8DrHHh7cJkyC" +
        "i2JsvL+EC8wDrtxtTIKLYmysh6Bt+M3jMfpuE4ZhZZEWVmX4NeMxz14Dm5VRqElUVbSJ3CicbkbZ+AOZRRaEmXl3IxTjc9tOBd3K" +
        "qPQkigr5UrsNk4LPAt3KKPQkigr44N4nnF7Em5VRqElUVbCJfg143c6rlNGoSVRuvcGXKwP5+AKZRRaEqVrr8Ur9eM8vFcZhZZE6" +
        "dY\\/xWv05UV4mzIKLYnSpRfhrfrzErxVGYWWROnOeXi3Pl2ENyuj0JIoXfkVvF+\\/LsA7lVFoSZRuPBtX6dsFeKcyCi2J0oVn4lr" +
        "9Ow\\/vVUahJVFG76m4yWo4D+9VRqElUUbteNyGZjXswWXKKLQkymg9AZ\\/BI6yOPbjMsLbhcbgV31b+r5ZEGaWj8Xk80mo5B1cYz" +
        "mn4AzyAb+F6\\/BnehwdMXEuijM4WfBnrrJ5zcIVhPBcf9v39W\\/yyiWtJlFHZhK9gvdW0G1cbxlV4th9sDWfgfhPVkiijsR2fwXq" +
        "razeutnyH4RYc7Yf7In4O95mglkQZhTNxCTZZbbtxteU7EZ\\/w4NyN4\\/ANE9OSKAfUevwLvNw0nI7rLN8JuApbPDj34G\\/hPhPS" +
        "kigHzA5cgWNNx+m4zvLtwA3Y4sGb42R800S0JMrgNuEUfBDrTcsurFm+rbgJWz0038FRWJiAlkRZusNwJJ6On8dx2G6admHN8m3C" +
        "LdjuofsuHo+FFdeSKA\\/bOhyEg3AQfhLr8Sisx9NwBo7D\\/TjOtN2D5+BWy7cRazjWw\\/NdPB4LK6wlsaLWYT1+Co\\/FTyIevAdw" +
        "MA7FRmzAY\\/AYPBqPxqNxCB6F9ViHn8Ajcbjyve7Bc3Cr5TsE1+MkD9938XgsrKiWxIr4WZyMn8ZOPA5HYgO+hZ3KgXYPzsSnLN9" +
        "6XIPT\\/Hi+hKfha1ZQS6JzG\\/GPcC52KGN2D87EpyzfOlyOs\\/z43oPzraCWRMeOxx\\/hSKUHd+MM3GEYl2KP\\/ePp+LgV05Lo1M" +
        "m4VenJ3TgDdxjG23Ch\\/WOOE3GfFdKS6NBGfAqPU3qywAxzw3gtXmn\\/eRV+2wppSXTopfh9pTcLzDA3jBfjLfafb+FEfMGKaEl0" +
        "5lB8FCcpvbkN5+JOw\\/iH+D3714dwLh6wAloSnTka1+NIpTcL7ManDONVeLX967\\/hGbjdCmhJdOYEXIPNSo9Ox3WG8Sq82v73Jl" +
        "xsBbQkOvNsXKX0ag8uM4zX4pX2vwX+Du7RuZZEZ34d71F6dRHebBhvwMWW4wK8U+daEp15FV6t9Op1+MeG8QZcbDluxy7cp2Mtic" +
        "68HS9UevVuvMAw3oYLLc8zcIOOtSQ6sg4fxm6lV1fiF\\/Edy\\/cunG95\\/h2eq2MtiY6sxwdwttKrq\\/FL+LblexfOtzx34Lm4U6" +
        "daEh05BNfiFKVXf4Kz8R3Ldyn2WK6X4\\/d1qiXRkUNwPU5SevV+PN8wLsUey3Ubno77dKgl0ZFDcD1OUnr1RrzUMD6I51m+p+AWH" +
        "WpJdGQDbsTxSq9egddbvnW4HGdZvn+FF+tQS6IjG3Ajjld6dR7ea\\/nW4XKcZfm+gpPwdZ1pSXRkA27E8UqvduNqy7cOV+IMwzgX" +
        "H9CZlkRHNmINxyo9ugfPwa2Wbz2uwWmGcSXO1pmWREc2Yg3HKj26DefiTsu3HtfgNMP4NJ6LP9eRlkRHNmINxyo9+gs8E3PLdzCu" +
        "xZMN52xcqSMtiY5sxBqOVXq0wAxzy7ceH8DZhvNK\\/K6OtCQ6cihuxjFKjxaYYW751uMqPMNwrsA5OtKS6MihuBnHKD1aYIa55Vu" +
        "Hy3GW4Xwau\\/BNnWhJdORQ3IxjlB4tMMPcMC7FHsO5GzN8QSdaEh3ZhFuwXenRAjPMDeNdON+wzsaVOtGS6Mgm3ILtSo8WmGFuGG" +
        "\\/AxYb1avxznWhJdGQTbsF2pUcLzDA3jFfh1Yb1Pvw6HtCBlkRHtmANRyk9WmCGuWG8GG8xrJvxLHxbB1oSHdmCNRyl9GiBGeaG8" +
        "WK8xbA+i6fiXh1oSXRkC9ZwlNKjBWaYG8Ze7DOsu\\/AULHSgJdGRLVjDUUqPFphhbhh7sc+w7sZpmOtAS6IjW3ETtio9WmCGuWHs" +
        "xT7DexJu1YGWREe24iZsVXq0wAxzw9iLfYa3C2s60JLoyFbchK1KjxaYYW4Ye7HP8HZhTQdaEh3ZhhtxhNKjBWaYG8Ze7DO8XVjT" +
        "gZZER7bhRhyh9GiBGeaGsRf7DG8X1nSgJdGRbbgRRyg9WmCGuWHsxT7D24U1HWhJdGQHbsAWpUcLzDA3jL3YZ3i7sKYDLYmO7MAN" +
        "2KL0aIEZ5oaxF\\/sM7ym4RQdaEh3ZgRuwRenRAjPMDWMv9hnWXXgKFjrQkujIDtyALUqPFphhbhh7sc+wPo4z8W0daEl0ZCc+hsO" +
        "VHi0ww9ww9mKfYb0JF+tES6IjO\\/ExHK70aIEZ5oaxF\\/sM61x8QCdaEh3ZiY\\/hcKVHC8wwN4y92Gc4d+FkfF0nWhIdOQHXYLPS" +
        "owVmmBvGXuwznDfipTrSkujICbgGm5UeLTDD3DD2Yp9h3Itn4RM60pLoyAm4BpuVHi0ww9ww9mKfYazhmfiOjrQkOnIKPoLNSo8W" +
        "mGFuGHuxzzB+A\\/9aZ1oSHTkFH8FmpUcLzDA3jL3YZ\\/m+hhNxj860JDpyCj6CzUqPFphhbhgvxNst33twvg61JDpyIj6h9GqBGe" +
        "aG8Tv4J5brXuzGLTrUkujITvwxfkbp0QIzzA3jXTjfct2OXbhPh1oSHdmGG3GE0qMFZphbvnW4HGdZrovwZp1qSXRkE27BdqVHC8" +
        "wwt3wH41o82fL8V5yCu3SqJdGRjVjDsUqPFphhbvk2Yg3HWp7LsEfHWhIdORgfwplKjxaYYW75tmANR1meX8Af61hLojP\\/Br+q9" +
        "GiBGeaWbwduwBbL8Vk8CffpWEuiM6\\/A65QeLTDD3PKdiE9Ynt\\/C7+hcS6Iz5+BypUcLzDC3fCfhI9hi\\/\\/sMTsb9OteS6MxOX" +
        "IvNSm8WmGFu+U7ANdhs\\/\\/pLPBFftAJaEp05DNfgRKU3C8wwt3w78TEcbv+6EO+wIloSHXoZ\\/qXSmwVmmFu+HbgBW+w\\/V2O3F" +
        "dKS6NBG\\/BmOVHqywAxzy7cDN2CL\\/eMb+Fl83QppSXRqFz6u9GSBGeaWbxtuxBH2jzPxUSumJdGxp+E6HKT0YIEZ5pZvK27CVj+" +
        "+t+IlVlBLonMn4EPYrozdAjPMLd8WrOEoP545TsR9VlBLYgU8Fi\\/Dr+AoZawWmGFu+TbhFmz38P0FTsI9VlRLYoUcirNxEU5Wxm" +
        "aBGeaWbxNuwXYPzwP4GdxjhbUkVtDB+Ns4A2fiCNyPTfaPe\\/E\\/8dN+sM3K91pghrnlOxQ34xgPXXA8Pm3FtSRW3Dpsxjb8D\\/t" +
        "H\\/B\\/ND\\/YAtmIbtuNx2IzH4CBsNT0LzDC3fBuxhmM9NA\\/gOHzOBLQkyiDWYR0ehQ3YiQ9gnelYYIa55duAG3G8B+9uPA1fNBE" +
        "tiXLA7MS12GwaFphhbvkOwfU4yYPzNZyKr5qQlkQ5oDbgKjzV6ltghrnlOxhX4Fl+tM\\/jVNxrYloSZRT+Pc622haYYW4Ye7HPD3" +
        "cNzsH9JqglUUbjg3ie1bXADHPDeCyuxXG+v9fjFSasJVFG5UrstpoWmGFuOE\\/AZ\\/2\\/vokX4v0mriVRRudaPNPqWWCGuWEdjbd" +
        "hB27HhVgoWhJllG7GqVbLAjPMHRjPwG24V\\/nfWhJltD6Jn7M6FphhroxCS6KM2h041mpYYIa5MgotiTJq63EHtunfAjPMlVFoSZ" +
        "TRW485jtS3BWaYK6PQkihdOAR3YrN+LTDDXBmFlkTpxgZ8CYfq0wIzzJVRaEmUrmzEXdigPwvMMFdGoSVRunMY7sLB+rLADHNlFF" +
        "oSpUub8BWs148FZpgro9CSKN3agi9jnT7chnNxpzIKLYnSta34cxxk\\/BbYjU8po9CSKN07Gp\\/HI43fLqwpo9CSKCvhCfgMHmHc" +
        "duNqZRRaEmVlHIH\\/hMON1x5cpoxCS6KslE34L1hnnC7AO5VRaEmUlbMDd+Ag4\\/PP8BplFFoSZSVtxZ1YZ1zeiJcqo9CSKCtrC+" +
        "7Ewcbj3XiBMgotibLSDsMXscE4fAi\\/pIxCS6KsvI34HDY78D6Gs\\/Ad5YBrSZRJOAS3Y5sD66P4RXxbOeBaEmUy1uM\\/41gHzjt" +
        "woTIKLYkyOTfjVAfG8\\/F+ZRRaEmWSrsRuw7oHp+ELyii0JMpkfRDPM5zb8HTcp4xCS6JM2jtwgWG8GRcpo9GSKJP3Blxsue7Fkz" +
        "BXRqMlUcpf+S38tuV5K16ijEpLopS\\/9nz8Ho6wf\\/13PBFfVUalJVHK33AoXo7fxE\\/ZP\\/4+LlFGpyVRyvdxDN6MX\\/Dj+VVcq" +
        "oxSS6KUH+JsvANHeGgewHm4RBmtlkQpP8KheDn2YLsf7bt4Fv6DMmotiVIepGNwIfZgi+9vjjPxJWX0WhKlPESb8cs4H4\\/CI\\/E" +
        "fcTsuwd1KF1oSpTxMG7ATn8O9SndaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSV" +
        "RSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqW" +
        "UaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUaWpJlFKmqSVRSpm" +
        "mlkQpZZpaEqWUaWpJlFKmqSVRSpmmlkQpZZpaEqWUafpfIpO0TMleHq8AAAAASUVORK5CYII=\",\"visible\":true,\"locked\":f" +
        "alse,\"masksLayerBelow\":false},{\"id\":\"90971688-00ff-4e43-89a2-81d3b99bbfef\",\"kind\":\"image\",\"name\":\"Vo" +
        "lume max\",\"transform\":{\"x\":0.896,\"y\":0.841,\"width\":0.05,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\"" +
        ":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturati" +
        "on\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundB" +
        "lur\":0},\"imageData\":\"iVBORw0KGgoAAAANSUhEUgAAAQAAAAEACAYAAABccqhmAAAYDklEQVR4Ae3BDdjedV0o8M9v0Fo0ce2" +
        "wxnh6ZA9rOEkHCpMxBG7AADV5M99fUisxFV96UbJOluVR03NELBM7Kh6tg5IJgmdACo6HjfFy6yAdMGQTEXFCQPMvjgl8u07nujp" +
        "XV6aM3b\\/\\/\\/b+f+\\/v5lIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4k" +
        "IKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJ" +
        "CSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPJWIkFIaTyUipDREP4\\/9cRO2YYfUmhIRUh" +
        "qC+XguXofdMBu34Gpcja\\/in3C\\/VE2JCCm1aHe8AO\\/EL\\/jP3Yx78A+4EmuwQxqoEhFSatHf4oV23lX4A6zFDmkgSkRIqSUb8Q" +
        "S7Zi3ejHXSLisRIaUW3ITHG4wGV+CPca30qJWIkFJlF+FZBq\\/BpXg7rpd2WokIKVW0F9ZhqXq+hwvwNmyWHrESEVKqaAWu0Y5v4" +
        "PdxrvSIlIiQUkVvxPu061N4FbZJP1aJCClVdAFO1L47cRKulf5TJSKkVMl8XITDDMcP8Ra8T\\/qRSkRIqZI5uARHGq4r8Dxslf6d" +
        "EhFSquhDOM3wbcPzcbH0b0pESKmi1+P9uuM9eLP0r0pESKmio3GZblmDE7DdmCsRIaWK9sJa7K9bbsMhuNsYKxEhpcoW4puYrVu+" +
        "h1\\/C7cZUiQgpteBAXI6f0y07sBJfMYZKREipJYfgKuyuWx7GybjQmCkRIaUWHYB\\/xCzdcxSuMEZKREipZRNYi311z3H4B2OiRI" +
        "Q00mbh6bgXBfdiK7bptgV4K56PRbrl5fi4MVAiQhpZc\\/FBvNT\\/twk7cCuuwjfxeWzTTQvxPPwGluuOF+BTZrgSEdJI2her8QQ\\" +
        "/2bV4GW7SXXNxMF6DJ2Op4TsZF5jBSkRII2cS12KhR2473oizdd8U\\/hQvNnzPwMVmqBIR0kiZxBbs5tH5FF6GHbrvuTgbP2e4js" +
        "HlZqASEdLImMQW7GbXXIyTsEP3LcCHcKrhOhzrzDAlIqSRMIkt2M1gPA\\/nGR3Pxkexl+EIHIQbzCAlIqTOm8QW7GZwNuJQNEbHX" +
        "jgTLzYcD+OXcJMZokSE1GmT2ILdDN4L8Cmj5zj8DfbSvofweNxqBigRIXXWJLZgN3VchpPQGD174Uy8WPsexH643YgrESF10iS2Y" +
        "Df1bMThuM\\/oOg5n4gnatQOLcacRViJC6pwluBm7qesbWIU7jbZ5OB9Hadd2PA53GVElIqROWYJNmKW+O3AEtpgZbsLjtet+7Iu7" +
        "jaASEVJnLMEmzNKOrTge15s5bsLjtesGHIFtRkyJCKkTlmATZmnXMbjczHI9lmvXu\\/D7RkyJCGnolmATZmnfSficmed6LNee7Vi" +
        "FrxghJSKkoVqCTZhlOI7HpWamq\\/FU7bkRh+B+I6JEhDQ0S7AJswzPMbjczHU1nqo9b8GfGxElIqShWIJNmGW4Dsc6M9vVeKp23I" +
        "8nY5MRUCJCat0yfA2zDNdWPBvXmvm+hKO041ocie06rkSE1Kpl2Ihi+L6DY7HReFiPQ7Xj9fiAjisRIbVmGTai6IY7cRRuMR7mYj" +
        "MWqG8bnojbdViJCKkVy7ARRXfcgSOwxfhYin\\/ET6vvC\\/hlHVYiQqpuGTai6JbbcThuN15Oxme146X4pI4qESFVtQwbUXTPZqzE" +
        "XcbP+\\/BG9X0Vx+K7OqhEhFTNMmxE0U2bcBjuMZ6uwQr1vR4f0EElIqQqlmEjiu66Eatwn\\/G0F27BPHXdjEPQ6JgSEdLALccGFN" +
        "12A47ANuNrBdZhd3WdjAt0TIkIaaCWYwOK7rsUz0FjvL0U\\/0tda3AcduiQEhHSwCzHBhSj4TocjcZ4m4PLcJh6tuF4rNchJSKkg" +
        "ViODShGRx89NOp7EvbA1brpibgae6jnPDxPh5SIkHbZcmxAMVr66KFR11H4azyIK\\/AhbNA978Mb1XMvDsUtOqJEhLRLlmMDitHT" +
        "Rw+Nek7FZ\\/x738ZLcLlumY8bMKGed+MMHVEiQnrUlmMDitHURw+NOuahj\\/38aCfjAt3yLFyknjtwEO7WASUipEflibgBxejqo4" +
        "dGHSfiAj\\/eC\\/Ap3XIJjlPPG3CWDigRIe205ehjd6Otjx4adZyCv\\/eTvRYf1B1L8BU8Rh034xA0hqxEhLRTnoWPYYHR10cPjTp" +
        "OwvkemT\\/Cn+qO38V71HMyLjBkJSKkR+wteJeZo48eGnWchPM9cr+Oj+qGufgylqpjDY7DDkNUIkJ6RD6CV5pZ+uihUcdJON\\/Oe" +
        "Rk+oRuehkvxMwZvG47HekNUIkL6sRbhvXiRmaePHhp1nITz7ZwH8XSs0Q0fwOvUcR6eZ4hKROioudgbj8V38c\\/Yjh1+stmYjdn4" +
        "aczFY\\/EA7sb3sR07\\/GiT6OH5WIJlZqY+emjUcQJW23n3Yn\\/cbfgOxf\\/BfIN3Lw7FLYakRISOmIUT8Tgcjv3xWHwf83AvvoWb" +
        "sQU34AE8DntiERZhHhZgHh6D2fhp\\/BP2wG7Yhu\\/idmzFFtyMn8Vr8IvY38zXRw+NOk7Aao\\/OpTje8M3FWixXx7txhiEpEaEDF" +
        "uFcHCm1qY8eGnWcgNUevd\\/G+wzf7+I96ujjBNxtCEpEGLKT8Ak8RmpbHz006jgBqz16O7ACNxiufXEtFhi8rTge1xuCEhGGZBb+" +
        "BH8oDUsfPTTqOAGr7Zpv4knYZrg+i5PV8XJ83BCUiDAkH8RvScPURw+NOk7AarvuHLzCcD0bn1PHh3GaISgRYQhOwGpp2ProoVHH" +
        "0bjMYLwQ5xqe+ehjscG7Fj3cr2UlIrRsD1yF5dKw9dFDo46jcZnBuB8H4DbD8w681eDdgcNwu5aViNCyU\\/EZqQv66KFRx9G4zOD" +
        "cgEOx3XAsx5fwcwbvGFyuZSUitOyTeLHUBX300KjjaFxmsM7Auw3HbFyOVQbvDLxby0pEaNE8XItflLqgjx4adRyNywzWV3EYGsP" +
        "xEnzC4F2Ak7WsRIQWHYzrpK7oo4dGHUfjMoPXwxrDsRBfxj4G62asxH1aVCJCiw7GdVJX9NFDo45VWGvwzsErDM\\/H8HKD9V0ci6" +
        "9qUYkILVqBa6Su6KOHRh2rsNbgfQeH4A7D8VRcbfBegE9pUYkILVqBa6Su6KOHRh2rsFYdv4n\\/aTgOwD9gH4P1frxRi0pEaNEKX" +
        "CN1RR89NOpYhbXqWIejsUP7JrEWkwbrShyP+7WkRIQWrcA1Ulf00UOjjlVYq4778HT0tW8+rsL+BuubWIk7taREhBatwDVSV\\/TR" +
        "Q6OOFbgQC9VxJt6kfXPxJRxs8I7AlVpSIkKLVuAaqSv66KFRxwpciIXq+AYOxj3aNQeX4EiD9wacpSUlIrRoBa6RuqKPHhp1rMCF" +
        "WKie5+LvtO8zONXgfRrP15ISEVq0AtdIXdFHD406VuBCLFTPajxT+\\/4KrzZ4X8Xh2KYFJSK0aAWukbqijx4adazAhVionn\\/Cob" +
        "hVu\\/4If2Lwrsep2KwFJSK06CnoS13RRw+NOlbgQixU1xtwlnb9Jj6sjkPQ14ISEVp0Es6XuqKPHhp1HIhLsFBdZ+JN2vV8nKuOU" +
        "3C+FpSI0KLX4\\/1SV\\/TRQ6OOA3EJFqrrfJyiXUfjMnW8AWdpQYkILXof3ih1RR89NOo4EJdgobqmcRy2a8+BuAQLDd6ZeJMWlIj" +
        "Qos\\/iZKkr+uihUceBuAQL1XUjVuE+7ZnCNCYM3vk4RQtKRGjJHrgMh0pd0UcPjToOxCVYqK5vYRVu154FWI\\/9DN7VOAb3q6xEh" +
        "JbMx3oslbqijx4adRyIS7BQXVtxDDZqzzyswxMM3jqchLtVViJCSxbjM3iK1BV99NCo4wB8EXur7xhcrj174DIcavC+jlW4S2UlI" +
        "rRkClfgF6Su6KOHRh0H4IvYW30vx8e1ZzY+i2cavM1YibtUViJCS6YwjQmpK\\/rooVHHAfgi9lbfW\\/Dn2vVRvMLgbcZK3KWyEhF" +
        "aMoVpTEhd0UcPjToOwBext\\/rOxqu16504w+BtxkrcpbISEVoyhWlMSF3RRw+NOg7AF7G3+j6Bl+Nh7Xkt\\/sLgbcZK3KWyEhFaM" +
        "oVpTEhd0UcPjTqWYg0Wqe+v8Brtei3+wuBtxkrcpbISEVoyhWlMSF3RRw+NOpZiDRap7214u3adjrMM3tX4FdytshIRWjKFaUxIX" +
        "dFHD406lmINFqnv1Thbu07HWQavjx4alZWI0JIpTGNC6oo+emjUsRRrsEh9p+B87TodZxm81TgZO1RWIkJLpjCNCakr+uihUcdSr" +
        "MEi9R2Oddp1Os4yeOfgFVpQIkJLpjCNCakr+uihUcdSrMEidW3FMdioXafjLIP3NrxdC0pEaMkUpjEhdUUfPTTqmMI0JtT1LazC7" +
        "dp1Os4yeK\\/G2VpQIkJLpjCNCakr+uihUccUpjGhrluwEvdo1+k4y+A9AxdrQYkILZnCNCakruijh0YdU5jGhLq+gFPQaNdp+JDB" +
        "2orjcb0WlIjQkilMY0Lqij56aNQxhWlMqOtsvFr7\\/jdeYLC+jadhixaUiNCSKUxjQuqKPnpo1DGFaUyo64U4V7vmYhoHGaxbsBL" +
        "3aEGJCC2ZwjQmpK7oo4dGHVOYxoR6tuJIbNKuSVyFCYP1ZRyFRgtKRGjJFKYxIXVFHz006pjEWkyqZwOOQKNdT8O0wVuNk7FDC0p" +
        "EaMkUpjEhdUUfPTTqmMRaTKrnwzhN+07DhwzeOXiFlpSI0JIpTGNC6oo+emjUMYm1mFTPC3Gu9p2NVxm8t+HtWlIiQksW4zN4itQ" +
        "Vl+I5aNQxibWYVMdWHIlN2rUHvoQVBu\\/l+LiWlIjQkklMY1+pK67HkdimjkmsxaQ6NuAINNq1COvxOIP3DFysJSUitGQB1mM\\/q" +
        "Ss24TDco45FWIfF6vgwTtO+Ffg8FhisrTge12tJiQgtmYd1eILUFZuxEnepYxHWYbE6nou\\/075fwzkG79t4GrZoSYkILZmLL+Fg" +
        "qStux+G4XR2LsA6LDd5tOAR3a9+ZeIPBuwUrcY+WlIjQkjm4BEdKXXEHjsAWdSzCOiw2eGfiTdo3GxfjaIP3BZyCRktKRGjJLHwC" +
        "L5K64js4FhvVsQjrsNhg3YsebtC+vXARDjV478GbtahEhBa9Eh+RumIrno1r1bEI67DYYF2E52CH9p2Kz6jjKFyhRSUitGhfrMfe" +
        "UlccjnXqWID12M\\/gNDgItxqOz+OZBu\\/rWIH7tKhEhJZdhGdJXfEMXKyOBViP\\/QzOq\\/DXhmMJ1mMvg\\/dJvFTLSkRo2a\\/iPK" +
        "krTsLn1LEA67GfwViHww3P7+C96ngO\\/l7LSkRo2R5Yi4OkLjgel6pjAdZjP7uuwRNxm+GYi2kcZPDuwArcqWUlIgzBM\\/F5qQsO" +
        "xzp1LMB67GfX\\/QY+YnhW4ip1\\/B1eiAe1rESEIdgdq\\/F0aZi24nhcr475uAiH2TV\\/jVcZrr\\/Ea9TxYvytISgRYUjmYCOmpGG" +
        "5E0fhFnUswlpMefTW4zDDtRcuxsEG7w4cjK2GoESEIZqDG7FYGobbcThuV8ck1mLSo\\/MdPB7bDNfpOEsdH8MrDUmJCEO2O87DyV" +
        "LbNmMl7lLHUqzBIjtvO34RdxiuubgOj1fHUbjCkJSI0AGzcSL+K5ZLbbkRq3CfOg7AF7G3nfMwVuFqw3cSzlfHJhyK+wxJiQgdMh" +
        "cH4FgcjwlsxwIEAg\\/iITyMB\\/EQ7seDeAA\\/xAPYhh\\/gAWzHvdiOH2A7duA+PIAH8D08BS\\/C3ngI\\/wX3YpmZ6VI8B406VuBC" +
        "LLRzXopPGr7ZWIOV6ngH\\/tAQlYjQUbOxEJP4Pn6IH2I7HsSDeAgP40E8jIfxsP9nh0dnNhZjAg\\/g+3gTfs3Mcx2ORqOOVVhr55" +
        "yGD+uGlbgEexq8e3A0bjBEJSKkR+QjeKWZpY8eGnWcgNUeuRfiXN3xaTxXHVfiWOwwRCUipEfsLXiXmaOPHhp1PAsX+ckexsvxCd" +
        "2xDFdhnjpeh780ZCUipJ3yLHwMC4y+Pnpo1LEKa\\/14D+AoXK1b3o\\/Xq2MrDsVthqxEhLTTlqOP3Y22Pnpo1LEUa7HAj7YVB+MO" +
        "3bIQG7C3Ov4ez9EBJSKkR+WJuAHF6Oqjh0Yde+BiHOE\\/ugLPxjbd82a8Wz0n4kIdUCJCetSW4WuYZTT10UOjnnk4A6fiIXwNX8K" +
        "H8KDumYfrsEQdm7EC9+iAEhHSLlmCm7Gb0dNHD436lmN3fFm3\\/SrOU88H8VodUSJC2mWTuBU\\/ZbT00UMj\\/V9LcD1+Vh334plY" +
        "ryNKREgDsQjfwGyjo48eGmkO+jhAPRtwBBodUSJCGpgF+BZmGw199NBIb8U71PW7+O86pESENFALcBt+Rvf10UNjvJ2Mz6rrFpyI" +
        "m3RIiQhp4PbCddhXt\\/XRQ2N8HYAN+Cl1\\/Tf8gY4pESFVMQ\\/X43G6q48eGuNpHjZhgbq+gQOxTceUiJCq2RO3YZ5u6qOHxnhai" +
        "1Xq+xV8XgeViJCq2hO3YZ7u6aOHxvh5J85Q34U4UUeViJCq2xO3YZ5u6aOHxng5FZ9R3\\/fwZNyqo0pESK3YE7dhnu7oo4fG+DgA" +
        "G\\/BT6vs9vFeHlYiQWrMnvo4FuqGPHhrjYR42YYH6bsFT0OiwEhFSq+ZiMxYYvj56aIyH67FcfT\\/AcbhSx5WIkFo3F5uxwHD10U" +
        "NjZtsTF6CnHefgFUZAiQhpKOZiMxYYnj56aMxc+2Id9tGOb+BJaIyAEhHS0MzFZiwwHH300JiZeliNOdrxAyzFHUZEiQhpqObiZu" +
        "yjfX300Jh53ox3a89D6OFKI6REhDR0c3Ar9tGuPnpozBxz8Dc4Vbteh780YkpESJ0wB7diH+3po4fGzLAAV2GJdn0SLzWCSkRInT" +
        "EHt2If7eijh8boOxBXYq52fQ2HYLsRVCJC6pQ5uBX7qK+PHhqj7SU4B7tp1\\/exBFuNqBIRUufMwY1YrK4v4BQ0RtcH8DrtewiH4" +
        "VojrESE1ElzcCMWq+dsvNpomosL0TMcv46PGnElIqTOmoMbsVgdL8S5Rs8ULsb+huPDOM0MUCJC6rQ5uBGLDdbX8WzcZHRM4gw8A" +
        "1OGo49DzBAlIqTOm4OrsdzgvBpnGw3z8dv4Lcw3PPdgKe4xQ5SIkEbCHJyD59t1n8NJum9PvAR\\/gH0M17dxCO40g5SIkEbKC\\/A" +
        "xzPHo3Ill2Ka79sCJ+DMsMXw\\/wL64ywxTIkIaOUtxAZ5g53wTT8VW3XUs\\/geW64Z78STcYQYqESGNpDn4M\\/yOR+YeLMNdumkF" +
        "3o2jdcdtOAj3maFKREgj7Wl4EY7F\\/n60a\\/As3K17DsA78Mv4Wd1xJX4Z281gJSKkGWEenoI\\/xs+j4Bpcjk+j0S2TOAMvw1zdc" +
        "g5eYQyUiJBmlNl4CjbhHt0zH6\\/DGzBf97wV7zQmSkRIqSUH4tPYX\\/cEno\\/zjJESEVJqwSG4Vjc9hGOxxpgpESGlyvbAFThY99" +
        "yPJ2OTMVQiQkqVHYdLdM+3cRDuMqZKREipsvPwq7rlWhyDxhgrESGlil6Ev9EtF+JESYkIKVUyH5fiYN3xXvye9K9KREipkr0wjW" +
        "WG7\\/v4DZwr\\/ZsSEVKqZD6uwv6GawNOxm3Sv1MiQkqVzMdV2N9w7MC78E5sl\\/6DEhFSqmQ+LsQq7fs2TkRf+k+ViJBSJbNxPp6" +
        "hXefiNGyTfqwSEVKq6PV4v3Z8D7+JT0mPSIkIKVW0P67EAnWtx6m4U3rESkRIqaJZuAjPUMc38GG8U9ppJSKkVNkcbMKkwbkXF+L" +
        "9+LL0qJSIkFIL5uLrWGjX3IFP4iO4RdolJSKk1JI9sQXz7byb8UH8Le6WBqJEhJRaNAdfwOEemXU4E6vRSANVIkJKLZuLp+EEHIz" +
        "H4Z\\/xGNyFr+DL+Edchx1SFSUipDREe+Cx+AV8C\\/+M+6VWlIiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8" +
        "VQiQkppPJWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppP" +
        "JWIkFIaTyUipJTGU4kIKaXxVCJCSmk8lYiQUhpPJSKklMZTiQgppfFUIkJKaTyViJBSGk8lIqSUxlOJCCml8VQiQkppPP0LABjOa" +
        "loe7ZYAAAAASUVORK5CYII=\",\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"54076b2f-c143" +
        "-43e6-89d1-4aa1f05f152d\",\"kind\":\"volumeSlider\",\"name\":\"Volume\",\"transform\":{\"x\":0.5,\"y\":0.841,\"width" +
        "\":0.689,\"height\":0.02313544973731041,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"o" +
        "pacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadiu" +
        "s\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masks" +
        "LayerBelow\":false},{\"id\":\"97a2c893-b81d-4ecf-a7ca-c7b843bb642a\",\"kind\":\"shape\",\"name\":\"Pill\",\"transf" +
        "orm\":{\"x\":0.5,\"y\":0.904,\"width\":0.336893230676651,\"height\":0.05190802043658369,\"rotationDegrees\":0,\"" +
        "aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturati" +
        "on\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundB" +
        "lur\":0},\"shape\":{\"type\":\"capsule\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"7bd" +
        "4d979-7c9a-47f1-ab94-6b9538a681e2\",\"kind\":\"shape\",\"name\":\"Pill divider\",\"transform\":{\"x\":0.5,\"y\":0.9" +
        "04,\"width\":0.0016,\"height\":0.044,\"rotationDegrees\":0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opaci" +
        "ty\":0.35,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius" +
        "\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":{\"type\":\"rectangle\"},\"visible" +
        "\":true,\"locked\":false,\"masksLayerBelow\":false},{\"id\":\"f585b549-68f3-49c0-bcc0-3892b9dca4f9\",\"kind\":\"" +
        "lyrics\",\"name\":\"Lyrics\",\"transform\":{\"x\":0.164,\"y\":0.904,\"width\":0.08991199731826782,\"height\":0.01,\"" +
        "rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"n" +
        "ormal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}}," +
        "\"innerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbo" +
        "lOverride\":\"lyrics.apple\"},{\"id\":\"cea6ac31-33ba-47fb-be9a-0df1991998c1\",\"kind\":\"connect\",\"name\":\"Con" +
        "nect\",\"transform\":{\"x\":0.417,\"y\":0.904,\"width\":0.0765811949968338,\"height\":0.014227520366003252,\"rot" +
        "ationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"norm" +
        "al\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"in" +
        "nerShadow\":false,\"backgroundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOv" +
        "erride\":\"connect.apple\"},{\"id\":\"fba20bc4-8aba-4d1a-9501-e106d597307c\",\"kind\":\"share\",\"name\":\"Persona" +
        "\",\"transform\":{\"x\":0.583,\"y\":0.904,\"width\":0.06802937388420105,\"height\":0,\"rotationDegrees\":0,\"aspec" +
        "tRatio\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"s" +
        "aturation\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"back" +
        "groundBlur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"person.apple\"" +
        "},{\"id\":\"070dcaad-39c5-4897-9303-ed53722311d7\",\"kind\":\"queue\",\"name\":\"Queue\",\"transform\":{\"x\":0.835," +
        "\"y\":0.904,\"width\":0.08035406470298767,\"height\":0.014655064936159071,\"rotationDegrees\":0,\"aspectRatio" +
        "\":{\"ratio\":{\"w\":1,\"h\":1}}},\"appearance\":{\"opacity\":0.7,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturat" +
        "ion\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"background" +
        "Blur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"queue.list\"},{\"id\":" +
        "\"faa60037-a8d7-49f7-96d9-d9dbe1fa7e46\",\"kind\":\"outputName\",\"name\":\"Output\",\"transform\":{\"x\":0.5,\"y\":" +
        "0.964,\"width\":0.5657686591148376,\"height\":0.020744850834210717,\"rotationDegrees\":0,\"aspectRatio\":{\"f" +
        "ree\":{}}},\"appearance\":{\"opacity\":0.6,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightnes" +
        "s\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"text\":{" +
        "\"content\":\"0:00\",\"fontSize\":11.824885368347168,\"weight\":\"medium\",\"design\":\"default\",\"alignment\":\"cen" +
        "ter\",\"allowsOverflow\":false,\"letterSpacing\":0,\"uppercase\":false},\"visible\":true,\"locked\":false,\"mask" +
        "sLayerBelow\":false,\"outputName\":{\"prefix\":\"\",\"showIcon\":false,\"useAccessoryName\":true}},{\"id\":\"1d85f" +
        "fb5-f3d8-4629-8c5c-bb57cf2c1e07\",\"kind\":\"qualityBadge\",\"name\":\"Quality Badge\",\"transform\":{\"x\":0.5,\"" +
        "y\":0.6549999999999999,\"width\":0.6522871255874634,\"height\":0.035,\"rotationDegrees\":0,\"aspectRatio\":{\"" +
        "free\":{}}},\"appearance\":{\"opacity\":0.7032073736190796,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturati" +
        "on\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundB" +
        "lur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"badge\":{\"showsBackground\":false,\"shap" +
        "e\":\"capsule\",\"backgroundOpacity\":0.12,\"fontSize\":12.69775390625,\"bold\":false,\"uppercase\":false,\"hori" +
        "zontalPadding\":8,\"compact\":false,\"mode\":\"tier\",\"animated\":\"shimmer\",\"icon\":\"auto\"}},{\"id\":\"1f9aedf7-" +
        "3e9a-4bfa-b1ff-3b78a6f6cb24\",\"kind\":\"favorite\",\"name\":\"Favorite\",\"transform\":{\"x\":0.7647921594975924" +
        ",\"y\":0.5401221602056466,\"width\":0.07079613208770752,\"height\":0.042477679252624495,\"rotationDegrees\":" +
        "0,\"aspectRatio\":{\"free\":{}}},\"appearance\":{\"opacity\":1,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturat" +
        "ion\":0,\"brightness\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"background" +
        "Blur\":0},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false,\"symbolOverride\":\"favorite.star\"},{\"i" +
        "d\":\"b2331062-74ec-4b5e-aa68-3b015eb65ba4\",\"kind\":\"shape\",\"name\":\"Menu disc Copy\",\"transform\":{\"x\":0." +
        "7639999999999999,\"y\":0.54,\"width\":0.088,\"height\":0,\"rotationDegrees\":0,\"aspectRatio\":{\"ratio\":{\"w\":1" +
        ",\"h\":1}}},\"appearance\":{\"opacity\":0.2,\"blendMode\":\"normal\",\"tint\":{\"hue\":0,\"saturation\":0,\"brightnes" +
        "s\":1,\"alpha\":1},\"cornerRadius\":{\"uniform\":{\"_0\":0}},\"innerShadow\":false,\"backgroundBlur\":0},\"shape\":" +
        "{\"type\":\"circle\"},\"visible\":true,\"locked\":false,\"masksLayerBelow\":false}],\"createdAt\":8.14644904188E" +
        "8,\"updatedAt\":8.14645682362E8,\"requiredCapabilities\":{\"immersiveArtworkFade\":1,\"statefulControls\":1}" +
        "}";

    private BitchordTemplate() {}

    /** JSON del diseno, con el mismo formato que lee Eclipse al importar un .eclipseplayer. */
    public static JSONObject json() {
        try {
            return new JSONObject(JSON);
        } catch (Exception e) {
            throw new RuntimeException("Bitchord: JSON invalido", e);
        }
    }

    /**
     * Busca entre los disenos del usuario (lista de ib6) uno llamado "Bitchord (integrado)" y devuelve su id, o null.
     * Se usa reflexion sobre los campos publicos de ib6: a = id, b = nombre. Cualquier fallo devuelve null.
     */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                Object name = d.getClass().getField("b").get(d);
                if (CARD_NAME.equals(name)) {
                    Object id = d.getClass().getField("a").get(d);
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /**
     * BITCHORD (ordinal 7 del enum de reproductores integrados) se trata como CUSTOM (ordinal 6) donde la app
     * decide como dibujar el reproductor. Cualquier otro valor (o null) se devuelve igual.
     */
    public static Object norm(Object value) {
        try {
            if (value instanceof Enum) {
                Enum<?> e = (Enum<?>) value;
                if (e.ordinal() == 7) {
                    Object[] all = e.getDeclaringClass().getEnumConstants();
                    if (all != null && all.length > 6) return all[6];
                }
            }
        } catch (Throwable ignored) {
        }
        return value;
    }

    /**
     * Valor de "playerStyle" que llega del servidor (zx7.b). Si el estilo guardado en el telefono es BITCHORD
     * devuelve null para que la app ignore ese ajuste y no cambie la seleccion. Cualquier otro caso: se devuelve igual.
     */
    public static String serverStyle(android.content.Context ctx, String server) {
        try {
            if (server != null && ctx != null) {
                String local = ctx.getSharedPreferences("eclipse_settings", 0).getString("player_style", null);
                if ("BITCHORD".equals(local)) return null;
            }
        } catch (Throwable ignored) {
        }
        return server;
    }

    private static volatile Object currentCard;
    private static int previewResId = -1;

    /** Lo llama i92.o al entrar: anota que tarjeta (valor del enum) se esta dibujando. */
    public static void card(Object fl6) {
        currentCard = fl6;
    }

    /**
     * Lo llama i92.o justo antes de painterResource con el id original. Si la tarjeta actual es BITCHORD
     * (ordinal 7) devuelve el id del recurso "player_preview_bitchord"; si no existe, el original.
     */
    public static int previewId(int original) {
        try {
            Object c = currentCard;
            if (c instanceof Enum && ((Enum<?>) c).ordinal() == 7) {
                if (previewResId == -1) {
                    int id = 0;
                    Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                    if (app instanceof android.content.Context) {
                        android.content.Context ctx = (android.content.Context) app;
                        id = ctx.getResources().getIdentifier("player_preview_bitchord", "drawable", ctx.getPackageName());
                    }
                    previewResId = id;
                }
                if (previewResId != 0) return previewResId;
            }
        } catch (Throwable ignored) {
        }
        return original;
    }

    /** Posicion de la tarjeta Bitchord en la lista (0 = primera, arriba a la izquierda; 1 = segunda; etc.). */
    private static final int CARD_POSITION = 0;

    /** Lo llama kd.invoke con la lista de tarjetas: mueve BITCHORD (ordinal 7) a CARD_POSITION. */
    public static void reorder(java.util.List<Object> list) {
        try {
            int from = -1;
            for (int i = 0; i < list.size(); i++) {
                Object o = list.get(i);
                if (o instanceof Enum && ((Enum<?>) o).ordinal() == 7) {
                    from = i;
                    break;
                }
            }
            if (from < 0) return;
            Object card = list.remove(from);
            int to = Math.max(0, Math.min(CARD_POSITION, list.size()));
            list.add(to, card);
        } catch (Throwable ignored) {
        }
    }

    /** Nombre del diseno interno que crea la tarjeta Bitchord (se oculta de "Your Custom Players"). */
    private static final String CARD_NAME = "Bitchord (integrado)";

    /** Igual que json() pero con el nombre interno: es el diseno que usa la tarjeta (fijo, no se muestra en Custom). */
    public static JSONObject jsonCard() {
        JSONObject o = json();
        try {
            o.put("name", CARD_NAME);
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Lo llama kd.invoke con la lista de disenos de Custom: devuelve una copia sin el diseno interno de la tarjeta. */
    public static java.util.List<Object> visible(java.util.List<Object> designs) {
        try {
            if (designs == null) return designs;
            java.util.ArrayList<Object> out = new java.util.ArrayList<>(designs.size());
            for (Object d : designs) {
                if (d != null && CARD_NAME.equals(d.getClass().getField("b").get(d))) continue;
                out.add(d);
            }
            return out;
        } catch (Throwable t) {
            return designs;
        }
    }
}
