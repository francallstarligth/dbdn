package app.eclipse.extension.diag;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * Diagnostico temporal: al buscar la portada animada de una cancion muestra un aviso con los datos
 * que Tidal y Apple Music necesitan (ID de album de Apple, ID de album de Tidal, ISRC, nombre del album).
 * Sirve para saber si las canciones de una playlist llegan sin esos datos. Nunca lanza excepciones.
 */
@SuppressWarnings("unused")
public final class ArtworkDiag {
    private static final String TAG = "ArtworkDiag";
    private static volatile String lastKey = "";

    private ArtworkDiag() {}

    /** @param song objeto com.eclipse.android.data.models.Song (se lee por reflexion). */
    public static void show(Object song) {
        try {
            if (song == null) return;
            String title = str(song, "getTitle");
            String artist = str(song, "getArtist");
            String key = title + "|" + artist;
            synchronized (ArtworkDiag.class) {
                if (key.equals(lastKey)) return; // la busqueda se reanuda varias veces por cancion
                lastKey = key;
            }
            String msg = (title.isEmpty() ? "?" : title)
                    + "\nApple album: " + show(str(song, "getAppleMusicAlbumId"))
                    + "\nTidal album: " + show(str(song, "getTidalAlbumId"))
                    + "\nISRC: " + show(str(song, "getIsrc"))
                    + "\nAlbum: " + show(str(song, "getAlbum"));
            toast(msg);
        } catch (Throwable t) {
            Log.w(TAG, "show fallo: " + t);
        }
    }

    private static String show(String v) {
        if (v.isEmpty()) return "NO";
        return v.length() > 22 ? v.substring(0, 22) + "~" : v;
    }

    private static String str(Object o, String getter) {
        try {
            Object r = o.getClass().getMethod(getter).invoke(o);
            return r == null ? "" : String.valueOf(r).trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static void toast(final String msg) {
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
