package app.eclipse.extension.diag;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * Diagnostico temporal: al buscar la portada animada de una cancion muestra un aviso con los datos
 * que Tidal y Apple Music necesitan (ID de album de Apple, ID de album de Tidal, ISRC, nombre del album).
 * Sirve para saber si las canciones de una playlist llegan sin esos datos. Nunca lanza excepciones.
 */
@SuppressWarnings("unused")
public final class ArtworkDiag {
    private static final String TAG = "ArtworkDiag";
    private static volatile String lastKey = "";

    private ArtworkDiag() {}

    /** @param song objeto com.eclipse.android.data.models.Song (se lee por reflexion). */
    public static void show(Object song) {
        try {
            if (song == null) return;
            String title = str(song, "getTitle");
            String artist = str(song, "getArtist");
            String key = title + "|" + artist;
            synchronized (ArtworkDiag.class) {
                if (key.equals(lastKey)) return; // la busqueda se reanuda varias veces por cancion
                lastKey = key;
            }
            // Android corta el aviso a 2 lineas cortas: solo banderas SI/NO.
            String msg = "AM:" + flag(str(song, "getAppleMusicAlbumId"))
                    + " TD:" + flag(str(song, "getTidalAlbumId")) + "\n"
                    + "ISRC:" + flag(str(song, "getIsrc"))
                    + " ALB:" + flag(str(song, "getAlbum"));
            toast(msg);
            // Segundo aviso: IDs de pista que usa Eclipse ("efectivos") y el inicio del id de la cancion.
            String id = str(song, "getId");
            toast("AMT:" + flag(str(song, "getEffectiveAppleMusicTrackId"))
                    + " TDT:" + flag(str(song, "getEffectiveTidalTrackId")) + "\n"
                    + "id:" + (id.isEmpty() ? "NO" : (id.length() > 10 ? id.substring(0, 10) : id)));
        } catch (Throwable t) {
            Log.w(TAG, "show fallo: " + t);
        }
    }

    private static String flag(String v) {
        return v.isEmpty() ? "NO" : "SI";
    }

    private static String str(Object o, String getter) {
        try {
            Object r = o.getClass().getMethod(getter).invoke(o);
            return r == null ? "" : String.valueOf(r).trim();
        } catch (Throwable t) {
            return "";
        }
    }

    private static void toast(final String msg) {
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
