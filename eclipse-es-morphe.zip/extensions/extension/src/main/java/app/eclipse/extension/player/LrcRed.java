package app.eclipse.extension.player;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;
import java.util.Locale;

/**
 * v0.20.285 (SIN COMPILAR / SIN PROBAR; lrc.red NO se pudo probar desde el contenedor, sin acceso a ese sitio).
 * Lo usa el parche "Letras: lrc.red en lugar de Musixmatch".
 *
 * Formato de lrc.red tomado del codigo abierto de am-lyrics (AmLyrics.ts):
 *   1) GET https://lrc.red/match.json?track=..&artist=..&duration=<seg>  ->  {"hits":[{"isrc":"..."}, ...]}
 *   2) GET https://lrc.red/s/<ISRC>.song.json  ->  {"lyrics":{"sync":"word"|..., "lines":[{"begin","end"(seg),
 *      "text","voice":"a"|"b","words":[[{"text","begin","end"}, ...silabas de una palabra], ...]}]},"byModel":bool}
 *
 * fetch() devuelve el resultado de letras de Eclipse (clase qo5, con fuente MUSIXMATCH) o null. Con null, el smali
 * sigue con el pedido original a Musixmatch (respaldo), asi que nunca queda peor que antes.
 * Para armar el resultado se reusa lo que ya hace LyricsPlusMochy: LyricsPlusWords.convert + po5.m (por palabra) o
 * po5.l (LRC por linea) + el constructor de qo5.
 */
public final class LrcRed {
    private LrcRed() {}

    private static final String TAG = "LrcRed";
    private static final String BASE = "https://lrc.red";
    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 6000;
    private static final int TOTAL_MS = 9000;

    private static volatile boolean broken = false;

    public static Object fetch(String title, String artist, int durationS) {
        if (broken) return null;
        try {
            String t = title == null ? "" : title.trim();
            String a = artist == null ? "" : artist.trim();
            if (t.length() == 0 || a.length() == 0) return null;
            long deadline = System.currentTimeMillis() + TOTAL_MS;

            String isrc = match(t, a, durationS);
            if (isrc == null && System.currentTimeMillis() < deadline) {
                // artista principal solo (lo de antes de "," "&" o "feat")
                String first = a.split("\\s*(,|&|\\bfeat\\.?\\b|\\bft\\.?\\b)\\s*", 2)[0].trim();
                if (first.length() > 0 && !first.equals(a)) isrc = match(t, first, durationS);
            }
            if (isrc == null) { Log.i(TAG, "sin coincidencia en lrc.red"); return null; }
            if (System.currentTimeMillis() >= deadline) return null;

            String body = get(BASE + "/s/" + URLEncoder.encode(isrc, "UTF-8") + ".song.json");
            if (body == null) return null;
            Object r = build(new JSONObject(body));
            if (r != null) Log.i(TAG, "letra OK (" + isrc + ")");
            return r;
        } catch (Throwable e) {
            if (e instanceof ReflectiveOperationException || e instanceof LinkageError) broken = true;
            try { Log.w(TAG, "fallo: " + e); } catch (Throwable ignored) { }
            return null;
        }
    }

    private static String match(String title, String artist, int durationS) throws Exception {
        StringBuilder u = new StringBuilder(BASE).append("/match.json?track=").append(URLEncoder.encode(title, "UTF-8"))
                .append("&artist=").append(URLEncoder.encode(artist, "UTF-8"));
        if (durationS > 0) u.append("&duration=").append(durationS);
        String body = get(u.toString());
        if (body == null) return null;
        JSONArray hits = new JSONObject(body).optJSONArray("hits");
        if (hits == null || hits.length() == 0) return null;
        // v0.20.286: no tomar a ciegas el primero (puede ser un remix). Se elige el primero cuyo titulo coincide
        // (sin parentesis/corchetes, sin mayusculas) y, si hay duracion, que difiera <= 3 s. Si ninguno cumple, null
        // (Eclipse sigue con Musixmatch).
        String want = norm(title);
        for (int i = 0; i < hits.length(); i++) {
            JSONObject h = hits.optJSONObject(i);
            if (h == null) continue;
            String isrc = h.optString("isrc", "").trim();
            if (isrc.length() == 0 || "null".equals(isrc)) continue;
            if (!norm(h.optString("title", "")).equals(want)) continue;
            double d = h.optDouble("duration", Double.NaN);
            if (durationS > 0 && !Double.isNaN(d) && Math.abs(d - durationS) > 3.0) continue;
            return isrc;
        }
        return null;
    }

    private static String norm(String s) {
        if (s == null) return "";
        return s.replaceAll("\\s*[\\(\\[].*?[\\)\\]]", "").trim().toLowerCase(Locale.ROOT);
    }

    private static String get(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setRequestProperty("User-Agent", "EclipseAndroid/1.0");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) { Log.i(TAG, "HTTP " + code); return null; }
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            return out.toString("UTF-8");
        } catch (Throwable e) {
            try { Log.i(TAG, "error de red: " + e); } catch (Throwable ignored) { }
            return null;
        } finally {
            if (c != null) { try { c.disconnect(); } catch (Throwable ignored) { } }
        }
    }

    private static Object build(JSONObject song) throws Exception {
        // v0.20.287: byModel NO se descarta (en la prueba del usuario, Shape of You trae byModel=true con tiempos por palabra buenos)
        JSONObject lyr = song.optJSONObject("lyrics");
        if (lyr == null) return null;
        JSONArray lines = lyr.optJSONArray("lines");
        if (lines == null || lines.length() == 0) return null;
        boolean wordSync = "word".equals(lyr.optString("sync", "")) || "word".equals(song.optString("level", ""));
        if (!wordSync) {
            JSONObject l0 = lines.optJSONObject(0);
            JSONArray w0 = l0 == null ? null : l0.optJSONArray("words");
            wordSync = w0 != null && w0.length() > 0;
        }

        Class<?> po5 = Class.forName("po5");
        List<?> list = null;

        if (wordSync) {
            // se arma la misma forma que YouLyPlus ({lyrics:[{text,time,duration,syllabus,element}]}) y se reusa su conversor
            JSONArray out = new JSONArray();
            for (int i = 0; i < lines.length(); i++) {
                JSONObject ln = lines.optJSONObject(i);
                if (ln == null) continue;
                String text = ln.optString("text", "");
                if (text.trim().length() == 0 || "null".equals(text)) continue;
                double b = ln.optDouble("begin", Double.NaN);
                if (Double.isNaN(b)) continue;
                double e = ln.optDouble("end", Double.NaN);
                JSONObject o = new JSONObject();
                o.put("text", text);
                o.put("time", b * 1000.0);
                if (!Double.isNaN(e) && e > b) o.put("duration", (e - b) * 1000.0);
                JSONObject el = new JSONObject();
                el.put("singer", "b".equals(ln.optString("voice", "")) ? "v2" : "v1");
                o.put("element", el);
                JSONArray words = ln.optJSONArray("words");
                if (words != null && words.length() > 0) {
                    JSONArray sy = new JSONArray();
                    for (int w = 0; w < words.length(); w++) {
                        JSONArray word = words.optJSONArray(w);
                        if (word == null) continue;
                        for (int s = 0; s < word.length(); s++) {
                            JSONObject y = word.optJSONObject(s);
                            if (y == null) continue;
                            double sb = y.optDouble("begin", Double.NaN);
                            if (Double.isNaN(sb)) continue;
                            double se = y.optDouble("end", Double.NaN);
                            String st = y.optString("text", "");
                            if ("null".equals(st)) st = "";
                            // el espacio entre palabras va pegado a la ultima silaba de cada palabra (como am-lyrics)
                            if (s == word.length() - 1 && w < words.length() - 1) st = st + " ";
                            JSONObject so = new JSONObject();
                            so.put("text", st);
                            so.put("time", sb * 1000.0);
                            if (!Double.isNaN(se) && se > sb) so.put("duration", (se - sb) * 1000.0);
                            so.put("isBackground", false);
                            sy.put(so);
                        }
                    }
                    if (sy.length() > 0) o.put("syllabus", sy);
                }
                out.put(o);
            }
            JSONObject wrap = new JSONObject();
            wrap.put("lyrics", out);
            JSONArray conv = LyricsPlusWords.convert(wrap);
            if (conv != null) {
                Method m = po5.getMethod("m", JSONArray.class);
                Object r = m.invoke(null, conv);
                if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
            }
        }

        if (list == null) {
            // letra por linea: se arma un LRC y se usa el lector LRC de Eclipse
            StringBuilder lrc = new StringBuilder();
            for (int i = 0; i < lines.length(); i++) {
                JSONObject ln = lines.optJSONObject(i);
                if (ln == null) continue;
                String text = ln.optString("text", "");
                if (text.trim().length() == 0 || "null".equals(text)) continue;
                double b = ln.optDouble("begin", Double.NaN);
                if (Double.isNaN(b) || b < 0) continue;
                int cs = (int) Math.round(b * 100.0);
                lrc.append(String.format(Locale.US, "[%02d:%02d.%02d]", cs / 6000, (cs / 100) % 60, cs % 100))
                        .append(text.trim()).append('\n');
            }
            if (lrc.length() == 0) return null;
            Method k = po5.getMethod("l", String.class);
            Object r = k.invoke(null, lrc.toString());
            if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
        }
        if (list == null) return null;

        Class<?> ko5 = Class.forName("ko5");
        Object src = null;
        for (Object c : ko5.getEnumConstants()) {
            if ("MUSIXMATCH".equals(((Enum<?>) c).name())) src = c;
        }
        if (src == null) return null;
        Class<?> qo5 = Class.forName("qo5");
        Constructor<?> ctor = qo5.getConstructor(List.class, String.class, ko5, Float.class, boolean.class, String.class);
        return ctor.newInstance(list, null, src, null, Boolean.FALSE, null);
    }
}
