package app.eclipse.extension.canvas;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Fuente Spotify (opcional, necesita la cookie sp_dc del propio usuario). Metodo tomado de SpotifyScraper:
 *  1) cookie sp_dc -> token del reproductor web (open.spotify.com/api/token, con un codigo TOTP);
 *  2) busqueda del tema (pathfinder searchDesktop; si falla, api.spotify.com/v1/search);
 *  3) pathfinder "canvas" con el id del tema -> URL mp4 (canvaz.scdn.co).
 *
 * Spotify cambia a veces las claves del TOTP y los hashes de pathfinder. Las claves se vuelven a leer solas
 * del bundle del reproductor web si todas las conocidas fallan; los hashes no (son constantes aqui abajo).
 *
 * Es bloqueante (red): solo se llama desde el hilo de fondo de CanvasLookup. Nunca lanza excepciones.
 * La cookie y el token NUNCA se escriben en el log ni en los avisos.
 */
final class SpotifyCanvas {
    private static final String TAG = "SpotifyCanvas";

    /** Resultado: url (o null), si la respuesta fue definitiva (se puede guardar "sin canvas") y una nota corta. */
    static final class Result {
        final String url;
        final boolean definitive;
        final String note;
        Result(String url, boolean definitive, String note) {
            this.url = url; this.definitive = definitive; this.note = note;
        }
    }

    // ---- constantes que Spotify puede rotar (no son secretos del usuario) ----
    /** No son final a proposito: las pruebas las cambian. */
    static String serverTimeUrl = "https://open.spotify.com/api/server-time";
    static String tokenUrl = "https://open.spotify.com/api/token";
    static String homeUrl = "https://open.spotify.com/";
    static String pathfinderUrl = "https://api-partner.spotify.com/pathfinder/v1/query";
    static String v1SearchUrl = "https://api.spotify.com/v1/search";
    static String bundlePrefix = "https://open.spotifycdn.com/cdn/build/web-player/web-player.";

    private static final String SEARCH_OP = "searchDesktop";
    private static final String SEARCH_HASH = "eff59fa0a3d026b88b56fddbcf4bdfa16a186b8175a5c1a358c072e053c2e5b0";
    private static final String CANVAS_OP = "canvas";
    private static final String CANVAS_HASH = "575138ab27cd5c1b3e54da54d0a7cc8d85485402de26340c2145f0f6bb5e7a9f";

    /** (version, secreto) de SpotifyScraper (junio 2026), la mas nueva primero. */
    private static final String[][] KNOWN_SECRETS = {
        {"61", ",7/*F(\"rLJ2oxaKL^f+E1xvP@N"},
        {"60", "OmE{ZA.J^\":0FG\\\\Uz?[@WW"},
        {"59", "{iOFn;4}<1PFYKPV?5{%u14]M>/V0hDH"},
    };

    /** v0.20.203: antes 8000 para todo; un pedido que se queda esperando hacia que cada Canvas de Spotify tardara 8 a 9 s. */
    private static final int CONNECT_TIMEOUT_MS = 3000;
    private static final int READ_TIMEOUT_MS = 4000;
    private static final int MAX_BYTES = 25 * 1024 * 1024;
    private static final long EXPIRY_SKEW_MS = 60_000L;
    /** Tras un fallo de token no se insiste durante este tiempo (cuida la cuenta). */
    private static final long AUTH_BACKOFF_MS = 10L * 60L * 1000L;
    private static final String UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";

    private static volatile String cookie = "";
    private static String token = null;
    private static long tokenExpiresMs = 0L;
    private static long authBackoffUntilMs = 0L;
    private static String lastAuthNote = "";
    /** Claves leidas del bundle web (se prueban despues de las conocidas). */
    private static List<String[]> bundleSecrets = new ArrayList<String[]>();
    private static long bundleTriedMs = 0L;
    /** v1.50.0: version de la clave TOTP que funciono la ultima vez (se prueba primero: 1 peticion en vez de hasta 3). */
    private static volatile String goodVersion = null;

    private SpotifyCanvas() {}

    static void setCookie(String value) {
        String v = value == null ? "" : value.trim();
        if (v.startsWith("sp_dc=")) v = v.substring(6);
        int semi = v.indexOf(';');
        if (semi >= 0) v = v.substring(0, semi);
        v = v.replaceAll("[^A-Za-z0-9_%.=~+/\\-]", "");
        if (!v.equals(cookie)) {
            synchronized (SpotifyCanvas.class) {
                cookie = v;
                token = null;
                tokenExpiresMs = 0L;
                authBackoffUntilMs = 0L;
            }
        }
    }

    static boolean enabled() { return !cookie.isEmpty(); }

    /** v1.50.0: saca el token en segundo plano (si no hay uno vigente) para que, si la comunidad no tiene la cancion, Spotify no empiece de cero. */
    static void warmUp() {
        try { if (enabled()) accessToken(); } catch (Throwable ignored) {}
    }

    // ---------------------------------------------------------------- API

    /** @return Result (nunca null). v0.20.203: la nota lleva el tiempo de cada paso (token, busqueda, canvas) para los avisos de depuracion. */
    static Result lookup(String title, String artist, int durationSec) {
        long t0 = System.currentTimeMillis();
        long tTok = 0L, tSearch = 0L, tCanvas = 0L;
        try {
            if (!enabled()) return new Result(null, false, "sin cookie");
            String tok = accessToken();
            tTok = System.currentTimeMillis() - t0;
            if (tok == null) return new Result(null, false, lastAuthNote + timing(tTok, tSearch, tCanvas));

            long t1 = System.currentTimeMillis();
            String id = search(tok, title, artist, durationSec);
            tSearch = System.currentTimeMillis() - t1;
            if (id == null || id.startsWith("!")) {
                if (id != null && id.startsWith("!401")) { invalidate(); }
                if (id == null) return new Result(null, true, "no esta en Spotify" + timing(tTok, tSearch, tCanvas));
                return new Result(null, false, "busqueda " + id.substring(1) + timing(tTok, tSearch, tCanvas));
            }

            long t2 = System.currentTimeMillis();
            String[] c = canvasOf(tok, id);
            tCanvas = System.currentTimeMillis() - t2;
            if (c[0] != null) return new Result(c[0], true, "OK" + timing(tTok, tSearch, tCanvas));
            if (c[1] != null) {
                if (c[1].equals("401")) invalidate();
                return new Result(null, false, "canvas " + c[1] + timing(tTok, tSearch, tCanvas));
            }
            return new Result(null, true, "el tema no tiene canvas" + timing(tTok, tSearch, tCanvas));
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            return new Result(null, false, "error " + t.getClass().getSimpleName() + timing(tTok, tSearch, tCanvas));
        }
    }

    private static String timing(long tok, long search, long canvas) {
        return " [token " + tok + " ms, busqueda " + search + " ms, canvas " + canvas + " ms]";
    }

    // ---------------------------------------------------------------- token

    private static synchronized void invalidate() { token = null; tokenExpiresMs = 0L; }

    private static synchronized String accessToken() {
        long now = System.currentTimeMillis();
        if (token != null && now < tokenExpiresMs - EXPIRY_SKEW_MS) return token;
        if (now < authBackoffUntilMs) return null; // lastAuthNote ya dice por que
        String t = exchange();
        if (t == null) authBackoffUntilMs = System.currentTimeMillis() + AUTH_BACKOFF_MS;
        return t;
    }

    /** cookie -> token. Pone lastAuthNote si falla. */
    private static String exchange() {
        try {
            Resp st = httpGet(serverTimeUrl, cookieHeaders(null));
            long serverSec = -1;
            if (st.code == 200 && st.body != null) {
                try { serverSec = new JSONObject(st.body).optLong("serverTime", -1); } catch (Throwable ignored) {}
            }
            if (serverSec <= 0) { lastAuthNote = "token: sin hora de Spotify (HTTP " + st.code + ")"; return null; }
            long nowSec = System.currentTimeMillis() / 1000L;

            // 1 = listo, 2 = version vencida, 3 = respuesta anonima (cookie mala O clave que ya no sirve), 0 = fallo duro
            boolean retry = false, anon = false;
            String gv = goodVersion;
            java.util.ArrayList<String[]> order = new java.util.ArrayList<String[]>();
            for (String[] s : KNOWN_SECRETS) if (gv != null && s[0].equals(gv)) order.add(s);
            for (String[] s : KNOWN_SECRETS) if (gv == null || !s[0].equals(gv)) order.add(s);
            for (String[] s : order) {
                int r = tryToken(s[0], s[1], nowSec, serverSec);
                if (r == 1) { goodVersion = s[0]; return token; }
                if (r == 0) return null;
                if (r == 3) anon = true;
                retry = true;
            }
            // Ninguna conocida sirvio: leer las claves nuevas del bundle web y probar las primeras.
            if (retry) {
                int tried = 0;
                for (String[] s : loadBundleSecrets()) {
                    if (tried++ >= 6) break;
                    int r = tryToken(s[0], s[1], nowSec, serverSec);
                    if (r == 1) return token;
                    if (r == 0) return null;
                    if (r == 3) anon = true;
                }
                // Si alguna respuesta fue "anonima", lo mas probable es la cookie; si todas dijeron "vencida", las claves.
                lastAuthNote = anon ? "token: cookie rechazada (vencida o mala) o claves cambiadas"
                        : "token: Spotify cambio sus claves (TOTP)";
            }
            return null;
        } catch (Throwable t) {
            lastAuthNote = "token: error " + t.getClass().getSimpleName();
            return null;
        }
    }

    /** 1 = token obtenido (queda en `token`), 2 = version de TOTP vencida, 0 = fallo (nota puesta). */
    private static int tryToken(String version, String secret, long nowSec, long serverSec) {
        try {
            String url = tokenUrl + "?reason=init&productType=web-player"
                    + "&totp=" + totp(secret, nowSec)
                    + "&totpServer=" + totp(secret, serverSec)
                    + "&totpVer=" + version;
            Resp r = httpGet(url, cookieHeaders(null));
            JSONObject b = null;
            if (r.body != null) { try { b = new JSONObject(r.body); } catch (Throwable ignored) {} }
            if (b == null) { lastAuthNote = "token: respuesta rara (HTTP " + r.code + ")"; return 0; }
            if ("totpVerExpired".equals(b.optString("error", "")) || b.optBoolean("totpVerExpired", false)) {
                lastAuthNote = "token: Spotify cambio sus claves (TOTP)";
                return 2;
            }
            if (b.optBoolean("isAnonymous", true)) { lastAuthNote = "token: cookie rechazada (vencida o mala) o claves cambiadas"; return 3; }
            String tk = b.optString("accessToken", "");
            long exp = b.optLong("accessTokenExpirationTimestampMs", 0L);
            if (tk.isEmpty() || exp <= 0) { lastAuthNote = "token: respuesta sin token"; return 0; }
            token = tk;
            tokenExpiresMs = exp;
            return 1;
        } catch (Throwable t) {
            lastAuthNote = "token: error " + t.getClass().getSimpleName();
            return 0;
        }
    }

    /** Lee las claves del bundle del reproductor web. Cada pocas horas como mucho. */
    private static List<String[]> loadBundleSecrets() {
        long now = System.currentTimeMillis();
        if (!bundleSecrets.isEmpty() || now - bundleTriedMs < 60L * 60L * 1000L) return bundleSecrets;
        bundleTriedMs = now;
        ArrayList<String[]> out = new ArrayList<String[]>();
        try {
            Resp home = httpGet(homeUrl, null);
            if (home.body == null) return out;
            java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile(java.util.regex.Pattern.quote(bundlePrefix) + "[a-f0-9]+\\.js")
                    .matcher(home.body);
            if (!m.find()) return out;
            Resp js = httpGet(m.group(), null);
            if (js.body == null) return out;
            java.util.regex.Matcher s = java.util.regex.Pattern
                    .compile("secret:(['\"])(.*?)\\1,version:(\\d+)").matcher(js.body);
            ArrayList<String[]> found = new ArrayList<String[]>();
            while (s.find()) found.add(new String[]{s.group(3), s.group(2)});
            // La version mas alta primero; cada una en texto crudo y des-escapado (si difieren).
            java.util.Collections.sort(found, new java.util.Comparator<String[]>() {
                @Override public int compare(String[] a, String[] b) {
                    return Integer.parseInt(b[0]) - Integer.parseInt(a[0]);
                }
            });
            for (String[] f : found) {
                out.add(f);
                String un = jsUnescape(f[1]);
                if (!un.equals(f[1])) out.add(new String[]{f[0], un});
            }
        } catch (Throwable t) {
            Log.d(TAG, "bundle: " + t);
        }
        bundleSecrets = out;
        return out;
    }

    static String jsUnescape(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                if (n == 'n') sb.append('\n');
                else if (n == 't') sb.append('\t');
                else sb.append(n); // \\ \" \' \/ ...
            } else sb.append(c);
        }
        return sb.toString();
    }

    /** TOTP de Spotify: clave = decimales de (codigo ^ (indice % 33 + 9)), HMAC-SHA1, 30 s, 6 digitos. */
    static String totp(String secret, long timestampSec) throws Exception {
        StringBuilder k = new StringBuilder();
        for (int i = 0; i < secret.length(); i++) k.append(secret.charAt(i) ^ (i % 33 + 9));
        byte[] key = k.toString().getBytes(Charset.forName("UTF-8"));
        byte[] msg = ByteBuffer.allocate(8).putLong(timestampSec / 30L).array();
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(key, "HmacSHA1"));
        byte[] d = mac.doFinal(msg);
        int off = d[d.length - 1] & 0x0F;
        int code = ((d[off] & 0x7F) << 24) | ((d[off + 1] & 0xFF) << 16) | ((d[off + 2] & 0xFF) << 8) | (d[off + 3] & 0xFF);
        String s = Integer.toString(code % 1000000);
        while (s.length() < 6) s = "0" + s;
        return s;
    }

    // ---------------------------------------------------------------- busqueda

    /** @return id del tema, null si no esta, o "!motivo" si fallo la consulta. */
    private static String search(String tok, String title, String artist, int durationSec) {
        String q = (title + " " + (artist == null ? "" : artist)).trim();
        int dur = durationSec > 10000 ? durationSec / 1000 : durationSec;

        String why;
        // 1) pathfinder (como SpotifyScraper)
        try {
            JSONObject vars = new JSONObject();
            vars.put("searchTerm", q);
            vars.put("offset", 0);
            vars.put("limit", 10);
            vars.put("numberOfTopResults", 5);
            vars.put("includeAudiobooks", true);
            vars.put("includePreReleases", true);
            vars.put("includeAlbumPreReleases", false);
            vars.put("includeAuthors", false);
            vars.put("includeEpisodeContentRatingsV2", false);
            Resp r = httpGet(pathfinderQuery(SEARCH_OP, SEARCH_HASH, vars), bearer(tok));
            if (r.code == 401) return "!401";
            JSONObject b = r.body == null ? null : new JSONObject(r.body);
            JSONObject data = b == null ? null : b.optJSONObject("data");
            JSONObject sv2 = data == null ? null : data.optJSONObject("searchV2");
            JSONObject t2 = sv2 == null ? null : sv2.optJSONObject("tracksV2");
            JSONArray items = t2 == null ? null : t2.optJSONArray("items");
            if (items != null) {
                ArrayList<String[]> cands = new ArrayList<String[]>(); // id, nombre, artistas ("|"), duracion s
                for (int i = 0; i < items.length(); i++) {
                    JSONObject it = items.optJSONObject(i);
                    JSONObject d = it == null ? null : (it.optJSONObject("item") == null ? null : it.optJSONObject("item").optJSONObject("data"));
                    if (d == null) continue;
                    String uri = d.optString("uri", "");
                    String name = d.optString("name", "");
                    if (!uri.startsWith("spotify:track:") || name.isEmpty()) continue;
                    StringBuilder ar = new StringBuilder();
                    JSONObject ao = d.optJSONObject("artists");
                    JSONArray ai = ao == null ? null : ao.optJSONArray("items");
                    if (ai != null) for (int j = 0; j < ai.length(); j++) {
                        JSONObject a = ai.optJSONObject(j);
                        JSONObject p = a == null ? null : a.optJSONObject("profile");
                        if (p != null) ar.append(p.optString("name", "")).append('|');
                    }
                    JSONObject du = d.optJSONObject("duration");
                    long ms = du == null ? 0 : du.optLong("totalMilliseconds", 0);
                    cands.add(new String[]{uri.substring(14), name, ar.toString(), Long.toString(ms / 1000)});
                }
                String best = pick(cands, title, artist, dur);
                if (best != null) return best;
                if (!cands.isEmpty() || (t2 != null)) return null; // busqueda valida, sin coincidencia
            }
            why = (b != null && b.has("errors")) ? "pathfinder: hash cambiado?" : "pathfinder: HTTP " + r.code;
        } catch (Throwable t) {
            why = "pathfinder: " + t.getClass().getSimpleName();
        }
        Log.d(TAG, "busqueda pathfinder fallo (" + why + "), pruebo v1/search");

        // 2) API publica v1
        try {
            String url = v1SearchUrl + "?q=" + URLEncoder.encode(q, "UTF-8") + "&type=track&limit=10";
            Resp r = httpGet(url, bearer(tok));
            if (r.code == 401) return "!401";
            if (r.code != 200 || r.body == null) return "!" + why + " / v1: HTTP " + r.code;
            JSONObject tr = new JSONObject(r.body).optJSONObject("tracks");
            JSONArray items = tr == null ? null : tr.optJSONArray("items");
            if (items == null) return "!" + why + " / v1: formato";
            ArrayList<String[]> cands = new ArrayList<String[]>();
            for (int i = 0; i < items.length(); i++) {
                JSONObject d = items.optJSONObject(i);
                if (d == null) continue;
                String id = d.optString("id", "");
                String name = d.optString("name", "");
                if (id.isEmpty() || name.isEmpty()) continue;
                StringBuilder ar = new StringBuilder();
                JSONArray ai = d.optJSONArray("artists");
                if (ai != null) for (int j = 0; j < ai.length(); j++) {
                    JSONObject a = ai.optJSONObject(j);
                    if (a != null) ar.append(a.optString("name", "")).append('|');
                }
                cands.add(new String[]{id, name, ar.toString(), Long.toString(d.optLong("duration_ms", 0) / 1000)});
            }
            return pick(cands, title, artist, dur); // null = no esta
        } catch (Throwable t) {
            return "!" + why + " / v1: " + t.getClass().getSimpleName();
        }
    }

    /** Mejor candidato: titulo igual (o parecido) + artista que coincida; la duracion desempata. */
    static String pick(List<String[]> cands, String title, String artist, int durSec) {
        String wantT = CommunityCanvas.norm(title);
        String wantA = CommunityCanvas.norm(artist);
        if (wantT.isEmpty()) return null;
        String bestId = null;
        int bestScore = 0;
        for (String[] c : cands) {
            String t = CommunityCanvas.norm(c[1]);
            int score;
            if (t.equals(wantT)) score = 100;
            else if (Math.min(t.length(), wantT.length()) >= 6 && (t.contains(wantT) || wantT.contains(t))) score = 50;
            else continue;
            boolean artistOk = wantA.isEmpty();
            for (String a : c[2].split("\\|")) {
                String na = CommunityCanvas.norm(a);
                if (na.length() < 2) continue;
                if (wantA.equals(na) || (Math.min(wantA.length(), na.length()) >= 3 && (wantA.contains(na) || na.contains(wantA)))) {
                    artistOk = true;
                    break;
                }
            }
            if (!artistOk) continue;
            try {
                long d = Long.parseLong(c[3]);
                if (durSec > 0 && d > 0) {
                    long diff = Math.abs(d - durSec);
                    if (diff <= 3) score += 20; else if (diff <= 10) score += 5;
                }
            } catch (NumberFormatException ignored) {}
            if (score > bestScore) { bestScore = score; bestId = c[0]; }
        }
        return bestId;
    }

    // ---------------------------------------------------------------- canvas

    /** v0.20.21: campos que Spotify mando en "canvas" (solo para el aviso de calidad). */
    static volatile String lastFields = "";

    /** @return {url, null} si hay; {null, null} si el tema no tiene; {null, motivo} si fallo. */
    private static String[] canvasOf(String tok, String trackId) {
        try {
            JSONObject vars = new JSONObject();
            vars.put("trackUri", "spotify:track:" + trackId);
            Resp r = httpGet(pathfinderQuery(CANVAS_OP, CANVAS_HASH, vars), bearer(tok));
            if (r.code == 401) return new String[]{null, "401"};
            JSONObject b = r.body == null ? null : new JSONObject(r.body);
            if (b == null) return new String[]{null, "HTTP " + r.code};
            JSONArray errs = b.optJSONArray("errors");
            if (errs != null && errs.length() > 0) {
                String m = errs.optJSONObject(0) == null ? "" : errs.optJSONObject(0).optString("message", "");
                return new String[]{null, m.equals("PersistedQueryNotFound") ? "hash cambiado" : "error de Spotify"};
            }
            JSONObject data = b.optJSONObject("data");
            JSONObject tu = data == null ? null : data.optJSONObject("trackUnion");
            if (tu == null) return new String[]{null, "formato"};
            JSONObject cv = tu.optJSONObject("canvas");
            String url = cv == null ? "" : cv.optString("url", "");
            if (cv != null) {
                try {
                    StringBuilder sb = new StringBuilder();
                    java.util.Iterator<String> it = cv.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        if (sb.length() > 0) sb.append(',');
                        if ("url".equals(k)) { sb.append(k); continue; }
                        String v = String.valueOf(cv.opt(k));
                        if (v.length() > 24) v = v.substring(0, 24) + "~";
                        sb.append(k).append('=').append(v);
                    }
                    lastFields = sb.toString();
                } catch (Throwable ignored) {}
            }
            if (url.startsWith("https://")) return new String[]{url, null};
            return new String[]{null, null};
        } catch (Throwable t) {
            return new String[]{null, t.getClass().getSimpleName()};
        }
    }

    // ---------------------------------------------------------------- HTTP

    private static String pathfinderQuery(String op, String hash, JSONObject vars) throws Exception {
        JSONObject ext = new JSONObject();
        JSONObject pq = new JSONObject();
        pq.put("version", 1);
        pq.put("sha256Hash", hash);
        ext.put("persistedQuery", pq);
        return pathfinderUrl + "?operationName=" + URLEncoder.encode(op, "UTF-8")
                + "&variables=" + URLEncoder.encode(vars.toString(), "UTF-8")
                + "&extensions=" + URLEncoder.encode(ext.toString(), "UTF-8");
    }

    private static String[] bearer(String tok) {
        return new String[]{"Authorization", "Bearer " + tok, "app-platform", "WebPlayer"};
    }

    private static String[] cookieHeaders(String unused) {
        return new String[]{"Cookie", "sp_dc=" + cookie, "app-platform", "WebPlayer"};
    }

    private static final class Resp {
        final int code;
        final String body;
        Resp(int code, String body) { this.code = code; this.body = body; }
    }

    /** headers: pares nombre, valor. Nunca lanza; code -1 si no hubo conexion. */
    private static Resp httpGet(String url, String[] headers) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(CONNECT_TIMEOUT_MS);
            c.setReadTimeout(READ_TIMEOUT_MS);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept", "application/json, text/html, */*");
            c.setRequestProperty("Accept-Language", "en");
            if (headers != null) for (int i = 0; i + 1 < headers.length; i += 2) c.setRequestProperty(headers[i], headers[i + 1]);
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) return new Resp(code, null);
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n, total = 0;
                while ((n = in.read(buf)) > 0) {
                    total += n;
                    if (total > MAX_BYTES) return new Resp(code, null);
                    out.write(buf, 0, n);
                }
                return new Resp(code, new String(out.toByteArray(), Charset.forName("UTF-8")));
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            Log.d(TAG, "GET error: " + t.getClass().getSimpleName());
            return new Resp(-1, null);
        }
    }
}
