package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Estilo "grueso" para los botones Play/Pause, Previous y Next del reproductor de Eclipse 0.6.47.
 *
 * (v0.20.218: portado a 0.6.61: bw0=c31, mapas e,f,g = b,c,d; co3=dz3, f43=ef3, w56=ky6, ob4=xn4. Abajo siguen los nombres de 0.6.47.)
 * Eclipse guarda los estilos en la clase bw0: e = Map(ob4 -> lista de nombres de estilo), f = Map(nombre -> icono)
 * y g = Map(nombre de Play -> icono de Pause). El gancho (al final de bw0.&lt;clinit&gt;) pasa cada mapa por
 * {@link #apply(int, Map)} y guarda el resultado. Los iconos se dibujan con las mismas funciones de bw0
 * (bw0.h = relleno, bw0.n = contorno), llamadas por reflexion con los nombres ofuscados de 0.6.47.
 * Si algo no coincide, se devuelve el mapa original sin cambios (la app queda como estaba).
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class ButtonStyles {
    public static final String PLAY = "play.thick";
    public static final String PREVIOUS = "previous.thick";
    public static final String NEXT = "next.thick";
    /** v1.59.0: doble triangulo (estilo Apple Music) para Previous y Next. */
    public static final String PREVIOUS_DOUBLE = "previous.double";
    public static final String NEXT_DOUBLE = "next.double";
    /** v1.60.0: iconos estilo Apple Music (segun la captura de referencia del usuario). */
    public static final String LYRICS_APPLE = "lyrics.apple";
    public static final String QUEUE_APPLE = "queue.apple";
    public static final String CONNECT_APPLE = "connect.apple";
    public static final String MENU_APPLE = "menu.apple";
    /** v1.61.0: persona (pastilla de Jam / SharePlay). */
    public static final String PERSON_APPLE = "person.apple";
    /** v1.91.0: icono de Connect que cambia solo segun la salida (telefono / cast / otro dispositivo / Jam). */
    public static final String CONNECT_AUTO = "connect.auto";
    public static final String CONNECT_PHONE = "connect.phone.apple";

    /** Escala de las medidas del dibujo aprobado (lienzo ~60x68) al lienzo de 24x24 de Eclipse. */
    static final float S = 0.30f;
    static final float C = 12f;
    /** Grosor del borde redondeado (6 en el dibujo). */
    static final float BORDER = 6f * S;

    private static boolean built;
    private static Object playIcon, pauseIcon, previousIcon, nextIcon, previousDoubleIcon, nextDoubleIcon;
    private static Object keyPlayPause, keyPrevious, keyNext;
    private static Object keyLyrics, keyQueue, keyConnect, keyMenu, keyJam;
    private static Object lyricsAppleIcon, queueAppleIcon, connectAppleIcon, menuAppleIcon, personAppleIcon, phoneIcon;

    private ButtonStyles() {}

    /** which: 0 = bw0.e (estilos por boton), 1 = bw0.f (nombre -> icono), 2 = bw0.g (nombre de Play -> icono Pause). */
    public static Map apply(int which, Map base) {
        try {
            if (base == null) return base;
            synchronized (ButtonStyles.class) {
                if (!built) {
                    build();
                    built = true;
                }
            }
            if (playIcon == null) return base;
            Map out = new LinkedHashMap(base);
            if (which == 0) {
                // el doble triangulo va despues del grueso (el grueso queda de primero)
                if (previousDoubleIcon != null && nextDoubleIcon != null) {
                    addFirst(out, keyPrevious, PREVIOUS_DOUBLE);
                    addFirst(out, keyNext, NEXT_DOUBLE);
                }
                addFirst(out, keyPlayPause, PLAY);
                addFirst(out, keyPrevious, PREVIOUS);
                addFirst(out, keyNext, NEXT);
                // v1.60.0: cada uno por separado; si falla uno no se pierden los demas
                addSafe(out, keyLyrics, LYRICS_APPLE, lyricsAppleIcon);
                addSafe(out, keyQueue, QUEUE_APPLE, queueAppleIcon);
                addSafe(out, keyConnect, CONNECT_APPLE, connectAppleIcon);
                addSafe(out, keyMenu, MENU_APPLE, menuAppleIcon);
                addSafe(out, keyJam, PERSON_APPLE, personAppleIcon);
                // v1.91.0: Connect dinamico (el automatico queda de primero en la lista de Connect)
                addSafe(out, keyConnect, PERSON_APPLE, personAppleIcon);
                addSafe(out, keyConnect, CONNECT_PHONE, phoneIcon);
                addSafe(out, keyConnect, CONNECT_AUTO, phoneIcon);
            } else if (which == 1) {
                out.put(PLAY, playIcon);
                out.put(PREVIOUS, previousIcon);
                out.put(NEXT, nextIcon);
                if (previousDoubleIcon != null && nextDoubleIcon != null) {
                    out.put(PREVIOUS_DOUBLE, previousDoubleIcon);
                    out.put(NEXT_DOUBLE, nextDoubleIcon);
                }
                if (lyricsAppleIcon != null) out.put(LYRICS_APPLE, lyricsAppleIcon);
                if (queueAppleIcon != null) out.put(QUEUE_APPLE, queueAppleIcon);
                if (connectAppleIcon != null) out.put(CONNECT_APPLE, connectAppleIcon);
                if (menuAppleIcon != null) out.put(MENU_APPLE, menuAppleIcon);
                if (personAppleIcon != null) out.put(PERSON_APPLE, personAppleIcon);
                if (phoneIcon != null) {
                    out.put(CONNECT_PHONE, phoneIcon);
                    out.put(CONNECT_AUTO, phoneIcon);
                }
            } else if (which == 2) {
                out.put(PLAY, pauseIcon);
            } else {
                return base;
            }
            return out;
        } catch (Throwable t) {
            return base;
        }
    }

    private static java.lang.reflect.Field fJam, fRemote, fCast;

    private static boolean flag(java.lang.reflect.Field f, Object st) throws Exception {
        return f.getBoolean(st);
    }

    /**
     * v1.91.0: lo llama di6.A justo despues de leer el nombre del icono de la capa (dw0.r). Si es "connect.auto"
     * devuelve el nombre del icono segun el estado del reproductor (ow0: o = inJam, q = connectRemote, r = isCasting);
     * cualquier otro nombre (o cualquier fallo) se devuelve igual.
     */
    public static String autoSymbol(String sym, Object st) {
        try {
            if (!CONNECT_AUTO.equals(sym) || st == null) return sym;
            if (fCast == null) {
                Class<?> c = st.getClass();
                java.lang.reflect.Field a = c.getDeclaredField("o");
                java.lang.reflect.Field b = c.getDeclaredField("q");
                java.lang.reflect.Field d = c.getDeclaredField("r");
                a.setAccessible(true);
                b.setAccessible(true);
                d.setAccessible(true);
                fJam = a;
                fRemote = b;
                fCast = d;
            }
            if (flag(fCast, st)) return "connect.speaker.tv";
            if (flag(fRemote, st)) return "connect.speaker";
            if (flag(fJam, st)) return personAppleIcon != null ? PERSON_APPLE : "connect.people";
            // v0.20.9: si el usuario forzo la bocina del telefono (hoja de Connect), se queda el icono del telefono
            if (headphones() && !HeadphoneRoute.speakerForced()) return connectAppleIcon != null ? CONNECT_APPLE : CONNECT_PHONE;
            return CONNECT_PHONE;
        } catch (Throwable t) {
            return sym;
        }
    }

    private static long hpTime;
    private static boolean hpValue;

    /**
     * v1.91.4: true si hay audifonos (Bluetooth A2DP/SCO/BLE, con cable, USB o auxiliares) como salida de audio.
     * Usa AudioManager.getDevices(GET_DEVICES_OUTPUTS) por reflexion; cualquier fallo = false (queda el telefono).
     * Se guarda el resultado 0,5 s para no consultar en cada redibujado.
     */
    private static boolean headphones() {
        long now = System.currentTimeMillis();
        if (now - hpTime < 500) return hpValue;
        boolean r = false;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app != null) {
                Object am = app.getClass().getMethod("getSystemService", String.class).invoke(app, "audio");
                if (am != null) {
                    Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
                    for (Object d : devs) {
                        int t = (Integer) d.getClass().getMethod("getType").invoke(d);
                        if (t == 3 || t == 4 || t == 7 || t == 8 || t == 22 || t == 23 || t == 26) {
                            r = true;
                            break;
                        }
                    }
                }
            }
        } catch (Throwable ignored) {
            r = false;
        }
        hpTime = now;
        hpValue = r;
        return r;
    }

    private static void addSafe(Map out, Object key, String name, Object icon) {
        try {
            if (key == null || icon == null) return;
            addFirst(out, key, name);
        } catch (Throwable ignored) {}
    }

    private static void addFirst(Map out, Object key, String name) {
        Object old = out.get(key);
        if (!(old instanceof List)) throw new IllegalStateException("lista de estilos no encontrada");
        List list = new ArrayList((List) old);
        if (!list.contains(name)) list.add(0, name);
        out.put(key, list);
    }

    // ---- dibujo ----

    private interface Shapes {
        void draw(Painter p) throws Exception;
    }

    private static final class Painter {
        final Object co3;
        final Method fill, stroke;
        final Class<?> f43;
        final Method moveTo, lineTo, close;
        final Class<?> w56;

        Painter(Object co3, Method fill, Method stroke, Class<?> f43, Class<?> w56) throws Exception {
            this.co3 = co3;
            this.fill = fill;
            this.stroke = stroke;
            this.f43 = f43;
            this.w56 = w56;
            this.moveTo = w56.getMethod("i", float.class, float.class);
            this.lineTo = w56.getMethod("g", float.class, float.class);
            this.close = w56.getMethod("b");
        }

        /** Poligono cerrado; pts en unidades del dibujo, relativas al centro (x0,y0,x1,y1...). */
        void polygon(boolean filled, float width, float... pts) throws Exception {
            final float[] xy = new float[pts.length];
            for (int i = 0; i < pts.length; i++) xy[i] = C + pts[i] * S;
            InvocationHandler h = new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    if (m.getName().equals("invoke") && args != null && args.length == 1) {
                        Object path = args[0];
                        moveTo.invoke(path, xy[0], xy[1]);
                        for (int i = 2; i < xy.length; i += 2) lineTo.invoke(path, xy[i], xy[i + 1]);
                        close.invoke(path);
                        return null;
                    }
                    if (m.getName().equals("hashCode")) return System.identityHashCode(proxy);
                    if (m.getName().equals("equals")) return proxy == (args == null ? null : args[0]);
                    if (m.getName().equals("toString")) return "ButtonStylesPath";
                    return null;
                }
            };
            Object fn = Proxy.newProxyInstance(f43.getClassLoader(), new Class<?>[] {f43}, h);
            if (filled) fill.invoke(null, co3, 0, fn);
            else strokePath(co3, width, fn, w56, f43);
        }

        /** v1.61.0: forma trazada (varios contornos en un solo trazado; huecos con giro opuesto). */
        void shape(final float[][] contours) throws Exception {
            InvocationHandler h = new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    if (m.getName().equals("invoke") && args != null && args.length == 1) {
                        Object path = args[0];
                        for (float[] c : contours) {
                            moveTo.invoke(path, C + c[0] * S, C + c[1] * S);
                            for (int i = 2; i < c.length; i += 2) lineTo.invoke(path, C + c[i] * S, C + c[i + 1] * S);
                            close.invoke(path);
                        }
                        return null;
                    }
                    if (m.getName().equals("hashCode")) return System.identityHashCode(proxy);
                    if (m.getName().equals("equals")) return proxy == (args == null ? null : args[0]);
                    if (m.getName().equals("toString")) return "ButtonStylesShape";
                    return null;
                }
            };
            Object fn = Proxy.newProxyInstance(f43.getClassLoader(), new Class<?>[] {f43}, h);
            fill.invoke(null, co3, 0, fn);
        }

        /** Triangulo relleno con borde del mismo color y union redondeada. */
        void triangle(float... pts) throws Exception {
            polygon(true, 0f, pts);
            polygon(false, BORDER, pts);
        }

        /** v1.60.0: poligono regular de n lados (aprox. circulo) como lista de puntos relativos al centro. */
        float[] ngon(float cx, float cy, float r, int n) {
            float[] o = new float[n * 2];
            for (int i = 0; i < n; i++) {
                double a = 2 * Math.PI * i / n;
                o[i * 2] = cx + (float) (r * Math.cos(a));
                o[i * 2 + 1] = cy + (float) (r * Math.sin(a));
            }
            return o;
        }

        /** v1.91.1: rectangulo de esquinas redondeadas (semiancho hw, semialto hh, radio r) como lista de puntos. */
        float[] roundedRect(float hw, float hh, float r, int seg) {
            float[] o = new float[4 * (seg + 1) * 2];
            float[][] corners = {{hw - r, -hh + r, -90}, {hw - r, hh - r, 0}, {-hw + r, hh - r, 90}, {-hw + r, -hh + r, 180}};
            int k = 0;
            for (float[] c : corners) {
                for (int i = 0; i <= seg; i++) {
                    double a = Math.toRadians(c[2] + 90.0 * i / seg);
                    o[k++] = c[0] + (float) (r * Math.cos(a));
                    o[k++] = c[1] + (float) (r * Math.sin(a));
                }
            }
            return o;
        }

        /** Disco relleno (con borde del mismo color para redondear). */
        void disc(float cx, float cy, float r) throws Exception {
            float[] pts = ngon(cx, cy, r, 20);
            polygon(true, 0f, pts);
            polygon(false, BORDER, pts);
        }

        /** Rectangulo de esquinas redondeadas (radio r): rectangulo interior + borde de 2r con union redondeada. */
        void roundRect(float x0, float y0, float x1, float y1, float r) throws Exception {
            float[] in = {x0 + r, y0 + r, x1 - r, y0 + r, x1 - r, y1 - r, x0 + r, y1 - r};
            polygon(true, 0f, in);
            polygon(false, 2f * r * S, in);
        }
    }

    private static Method addPathM;
    private static Object strokeBrush;
    private static java.lang.reflect.Field nodesF;

    /** Trazo con ancho propio (ver build): lo mismo que hace c31.n, pero con el ancho como parametro. */
    private static void strokePath(Object co3, float width, Object fn, Class<?> w56, Class<?> f43) throws Exception {
        java.lang.reflect.Constructor<?> pc = w56.getDeclaredConstructor();
        pc.setAccessible(true);
        Object path = pc.newInstance();
        f43.getMethod("invoke", Object.class).invoke(fn, path);
        addPathM.invoke(null, co3, nodesF.get(path), 0, null, strokeBrush, width, 1, 1, 4f, 14336);
    }

    private static Object icon(Class<?> co3, Constructor<?> ctor, Method fill, Method stroke, Method done,
                               Class<?> f43, Class<?> w56, String name, Shapes shapes) throws Exception {
        Object b = ctor.newInstance("canvas." + name, 24f, 24f, 24f, 24f, 0L, 0, false, 224);
        shapes.draw(new Painter(b, fill, stroke, f43, w56));
        Object icon = done.invoke(b);
        if (icon == null) throw new IllegalStateException("icono nulo");
        return icon;
    }

    private static void build() {
        try {
            Class<?> bw0 = Class.forName("t51");
            final Class<?> co3 = Class.forName("e54");
            Class<?> f43 = Class.forName("fk3");
            Class<?> w56 = Class.forName("sf7");
            Class<?> ob4 = Class.forName("cv4");

            Constructor<?> ctor = co3.getConstructor(String.class, float.class, float.class, float.class,
                    float.class, long.class, int.class, boolean.class, int.class);
            Method fill = bw0.getMethod("h", co3, int.class, f43);
            // v0.20.218: en 0.6.61 c31.n (antes g21.n) ya no recibe el ancho (fijo en 1.4f). Se arma el mismo trazo que hace
            // c31.n, pero llamando directo a dz3.b (addPath) con el ancho que queramos: ky6 nuevo -> fn.invoke(ky6) -> dz3.b(
            // builder, ky6.a, 0, null, c31.a, ancho, 1, 1, 4f, 14336).
            Class<?> brushC = Class.forName("dz0");
            addPathM = co3.getDeclaredMethod("b", co3, List.class, int.class, brushC, brushC, float.class,
                    int.class, int.class, float.class, int.class);
            addPathM.setAccessible(true);
            java.lang.reflect.Field bf = bw0.getDeclaredField("a");
            bf.setAccessible(true);
            strokeBrush = bf.get(null);
            nodesF = w56.getDeclaredField("a");
            nodesF.setAccessible(true);
            Method stroke = addPathM;
            Method done = co3.getMethod("c");

            for (Object k : ob4.getEnumConstants()) {
                String n = ((Enum) k).name();
                if (n.equals("PLAY_PAUSE")) keyPlayPause = k;
                else if (n.equals("PREVIOUS")) keyPrevious = k;
                else if (n.equals("NEXT")) keyNext = k;
                else if (n.equals("LYRICS")) keyLyrics = k;
                else if (n.equals("QUEUE")) keyQueue = k;
                else if (n.equals("CONNECT")) keyConnect = k;
                else if (n.equals("THREE_DOT_MENU")) keyMenu = k;
                else if (n.equals("JAM_PILL")) keyJam = k;
            }
            if (keyPlayPause == null || keyPrevious == null || keyNext == null) return;

            Object play = icon(co3, ctor, fill, stroke, done, f43, w56, PLAY, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(-20, -30, 26, 0, -20, 30);
                }
            });
            Object pause = icon(co3, ctor, fill, stroke, done, f43, w56, "pause.thick", new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.roundRect(-26, -34, -5, 34, 3);
                    p.roundRect(5, -34, 26, 34, 3);
                }
            });
            Object next = icon(co3, ctor, fill, stroke, done, f43, w56, NEXT, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(-16, -18, 11, 0, -16, 18);
                    p.roundRect(9, -22, 19, 22, 3);
                }
            });
            Object previous = icon(co3, ctor, fill, stroke, done, f43, w56, PREVIOUS, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(16, -18, -11, 0, 16, 18);
                    p.roundRect(-19, -22, -9, 22, 3);
                }
            });
            // v1.59.0: doble triangulo (como el de Apple Music). Si falla, solo se omite este estilo.
            try {
                previousDoubleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, PREVIOUS_DOUBLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.PREV); }
                });
                nextDoubleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, NEXT_DOUBLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.NEXT); }
                });
            } catch (Throwable t) {
                previousDoubleIcon = null;
                nextDoubleIcon = null;
            }
            // v1.60.0: iconos estilo Apple Music (cada uno opcional: si falla, solo se omite)
            try {
                lyricsAppleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, LYRICS_APPLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.LYRICS); }
                });
            } catch (Throwable t) { lyricsAppleIcon = null; }
            try {
                queueAppleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, QUEUE_APPLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.QUEUE); }
                });
            } catch (Throwable t) { queueAppleIcon = null; }
            try {
                connectAppleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, CONNECT_APPLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.AIRPODS); }
                });
            } catch (Throwable t) { connectAppleIcon = null; }
            try {
                menuAppleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, MENU_APPLE, new Shapes() {
                    public void draw(Painter p) throws Exception {
                        // circulo (contorno) con tres puntos
                        p.polygon(false, 7f * S, p.ngon(0, 0, 33, 24));
                        p.disc(-17, 0, 2);
                        p.disc(0, 0, 2);
                        p.disc(17, 0, 2);
                    }
                });
            } catch (Throwable t) { menuAppleIcon = null; }
            try {
                personAppleIcon = icon(co3, ctor, fill, stroke, done, f43, w56, PERSON_APPLE, new Shapes() {
                    public void draw(Painter p) throws Exception { p.shape(AppleIcons.PERSON); }
                });
            } catch (Throwable t) { personAppleIcon = null; }
            // v1.91.0: telefono (contorno) para Connect cuando suena en este telefono
            try {
                phoneIcon = icon(co3, ctor, fill, stroke, done, f43, w56, CONNECT_PHONE, new Shapes() {
                    public void draw(Painter p) throws Exception {
                        p.shape(AppleIcons.PHONE);
                    }
                });
            } catch (Throwable t) { phoneIcon = null; }
            playIcon = play;
            pauseIcon = pause;
            nextIcon = next;
            previousIcon = previous;
        } catch (Throwable t) {
            playIcon = null;
        }
    }
}
