package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Estilo "grueso" para los botones Play/Pause, Previous y Next del reproductor de Eclipse 0.6.47.
 *
 * Eclipse guarda los estilos en la clase bw0: e = Map(ob4 -> lista de nombres de estilo), f = Map(nombre -> icono)
 * y g = Map(nombre de Play -> icono de Pause). El gancho (al final de bw0.&lt;clinit&gt;) pasa cada mapa por
 * {@link #apply(int, Map)} y guarda el resultado. Los iconos se dibujan con las mismas funciones de bw0
 * (bw0.h = relleno, bw0.n = contorno), llamadas por reflexion con los nombres ofuscados de 0.6.47.
 * Si algo no coincide, se devuelve el mapa original sin cambios (la app queda como estaba).
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class ButtonStyles {
    public static final String PLAY = "play.thick";
    public static final String PREVIOUS = "previous.thick";
    public static final String NEXT = "next.thick";

    /** Escala de las medidas del dibujo aprobado (lienzo ~60x68) al lienzo de 24x24 de Eclipse. */
    static final float S = 0.30f;
    static final float C = 12f;
    /** Grosor del borde redondeado (6 en el dibujo). */
    static final float BORDER = 6f * S;

    private static boolean built;
    private static Object playIcon, pauseIcon, previousIcon, nextIcon;
    private static Object keyPlayPause, keyPrevious, keyNext;

    private ButtonStyles() {}

    /** which: 0 = bw0.e (estilos por boton), 1 = bw0.f (nombre -> icono), 2 = bw0.g (nombre de Play -> icono Pause). */
    public static Map apply(int which, Map base) {
        try {
            if (base == null) return base;
            synchronized (ButtonStyles.class) {
                if (!built) {
                    build();
                    built = true;
                }
            }
            if (playIcon == null) return base;
            Map out = new LinkedHashMap(base);
            if (which == 0) {
                addFirst(out, keyPlayPause, PLAY);
                addFirst(out, keyPrevious, PREVIOUS);
                addFirst(out, keyNext, NEXT);
            } else if (which == 1) {
                out.put(PLAY, playIcon);
                out.put(PREVIOUS, previousIcon);
                out.put(NEXT, nextIcon);
            } else if (which == 2) {
                out.put(PLAY, pauseIcon);
            } else {
                return base;
            }
            return out;
        } catch (Throwable t) {
            return base;
        }
    }

    private static void addFirst(Map out, Object key, String name) {
        Object old = out.get(key);
        if (!(old instanceof List)) throw new IllegalStateException("lista de estilos no encontrada");
        List list = new ArrayList((List) old);
        if (!list.contains(name)) list.add(0, name);
        out.put(key, list);
    }

    // ---- dibujo ----

    private interface Shapes {
        void draw(Painter p) throws Exception;
    }

    private static final class Painter {
        final Object co3;
        final Method fill, stroke;
        final Class<?> f43;
        final Method moveTo, lineTo, close;
        final Class<?> w56;

        Painter(Object co3, Method fill, Method stroke, Class<?> f43, Class<?> w56) throws Exception {
            this.co3 = co3;
            this.fill = fill;
            this.stroke = stroke;
            this.f43 = f43;
            this.w56 = w56;
            this.moveTo = w56.getMethod("j", float.class, float.class);
            this.lineTo = w56.getMethod("h", float.class, float.class);
            this.close = w56.getMethod("c");
        }

        /** Poligono cerrado; pts en unidades del dibujo, relativas al centro (x0,y0,x1,y1...). */
        void polygon(boolean filled, float width, float... pts) throws Exception {
            final float[] xy = new float[pts.length];
            for (int i = 0; i < pts.length; i++) xy[i] = C + pts[i] * S;
            InvocationHandler h = new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    if (m.getName().equals("invoke") && args != null && args.length == 1) {
                        Object path = args[0];
                        moveTo.invoke(path, xy[0], xy[1]);
                        for (int i = 2; i < xy.length; i += 2) lineTo.invoke(path, xy[i], xy[i + 1]);
                        close.invoke(path);
                        return null;
                    }
                    if (m.getName().equals("hashCode")) return System.identityHashCode(proxy);
                    if (m.getName().equals("equals")) return proxy == (args == null ? null : args[0]);
                    if (m.getName().equals("toString")) return "ButtonStylesPath";
                    return null;
                }
            };
            Object fn = Proxy.newProxyInstance(f43.getClassLoader(), new Class<?>[] {f43}, h);
            if (filled) fill.invoke(null, co3, 0, fn);
            else stroke.invoke(null, co3, width, fn);
        }

        /** Triangulo relleno con borde del mismo color y union redondeada. */
        void triangle(float... pts) throws Exception {
            polygon(true, 0f, pts);
            polygon(false, BORDER, pts);
        }

        /** Rectangulo de esquinas redondeadas (radio r): rectangulo interior + borde de 2r con union redondeada. */
        void roundRect(float x0, float y0, float x1, float y1, float r) throws Exception {
            float[] in = {x0 + r, y0 + r, x1 - r, y0 + r, x1 - r, y1 - r, x0 + r, y1 - r};
            polygon(true, 0f, in);
            polygon(false, 2f * r * S, in);
        }
    }

    private static Object icon(Class<?> co3, Constructor<?> ctor, Method fill, Method stroke, Method done,
                               Class<?> f43, Class<?> w56, String name, Shapes shapes) throws Exception {
        Object b = ctor.newInstance("canvas." + name, 24f, 24f, 24f, 24f, 0L, 0, false, 224);
        shapes.draw(new Painter(b, fill, stroke, f43, w56));
        Object icon = done.invoke(b);
        if (icon == null) throw new IllegalStateException("icono nulo");
        return icon;
    }

    private static void build() {
        try {
            Class<?> bw0 = Class.forName("bw0");
            final Class<?> co3 = Class.forName("co3");
            Class<?> f43 = Class.forName("f43");
            Class<?> w56 = Class.forName("w56");
            Class<?> ob4 = Class.forName("ob4");

            Constructor<?> ctor = co3.getConstructor(String.class, float.class, float.class, float.class,
                    float.class, long.class, int.class, boolean.class, int.class);
            Method fill = bw0.getMethod("h", co3, int.class, f43);
            Method stroke = bw0.getMethod("n", co3, float.class, f43);
            Method done = co3.getMethod("c");

            for (Object k : ob4.getEnumConstants()) {
                String n = ((Enum) k).name();
                if (n.equals("PLAY_PAUSE")) keyPlayPause = k;
                else if (n.equals("PREVIOUS")) keyPrevious = k;
                else if (n.equals("NEXT")) keyNext = k;
            }
            if (keyPlayPause == null || keyPrevious == null || keyNext == null) return;

            Object play = icon(co3, ctor, fill, stroke, done, f43, w56, PLAY, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(-20, -30, 26, 0, -20, 30);
                }
            });
            Object pause = icon(co3, ctor, fill, stroke, done, f43, w56, "pause.thick", new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.roundRect(-26, -34, -5, 34, 3);
                    p.roundRect(5, -34, 26, 34, 3);
                }
            });
            Object next = icon(co3, ctor, fill, stroke, done, f43, w56, NEXT, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(-16, -18, 11, 0, -16, 18);
                    p.roundRect(9, -22, 19, 22, 3);
                }
            });
            Object previous = icon(co3, ctor, fill, stroke, done, f43, w56, PREVIOUS, new Shapes() {
                public void draw(Painter p) throws Exception {
                    p.triangle(16, -18, -11, 0, 16, 18);
                    p.roundRect(-19, -22, -9, 22, 3);
                }
            });
            playIcon = play;
            pauseIcon = pause;
            nextIcon = next;
            previousIcon = previous;
        } catch (Throwable t) {
            playIcon = null;
        }
    }
}
