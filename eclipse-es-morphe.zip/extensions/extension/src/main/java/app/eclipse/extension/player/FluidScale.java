package app.eclipse.extension.player;

/**
 * v0.20.364 (SIN COMPILAR NI PROBAR). Valores de escala del parche "Animaciones fluidas".
 * pressed: escala al presionar botones/tarjetas (el original manda 1.0 = no se achica). Solo cambia el 1.0.
 * grow: escala de la caratula mientras suena (en pausa queda 1.0). Ignora el valor del skin.
 */
@SuppressWarnings("unused")
public final class FluidScale {
    private static final float PRESSED = 0.94f;
    private static final float PLAYING = 1.04f;

    private FluidScale() {}

    public static float pressed(float original) {
        return original == 1.0f ? PRESSED : original;
    }

    public static float grow(float skinShrink) {
        return PLAYING;
    }
}
