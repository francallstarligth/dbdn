package app.eclipse.extension.player;

/**
 * v0.20.364 (SIN COMPILAR NI PROBAR). Valores de escala del parche "Animaciones fluidas".
 * grow: escala de la caratula mientras suena (en pausa queda 1.0). Ignora el valor del skin.
 */
@SuppressWarnings("unused")
public final class FluidScale {
    private static final float PLAYING = 1.04f;

    private FluidScale() {}

    public static float grow(float skinShrink) {
        return PLAYING;
    }
}
