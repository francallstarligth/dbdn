package app.eclipse.extension.automix;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Automix con respaldo local para Eclipse 0.6.47.
 *
 * Por defecto Eclipse sigue pidiendo su plan al servidor. El plan local entra cuando:
 *  1) la cancion no tiene ISRC (se le inventa uno ZZ...): el servidor no la conoce;
 *  2) el servidor no da plan (sin red, error HTTP, excepcion);
 *  3) la opcion "Plan local primero" esta activada (plan local en todas; el servidor solo si el local no puede);
 *  4) la opcion "Solo Automix local" esta activada (el servidor NO se usa nunca).
 *
 * El plan local usa los datos del analizador de Eclipse en el telefono (BPM, beats, downbeats, inicio del final) y,
 * si no hay, el BPM de Deezer (por ISRC o buscando por artista y titulo); sin BPM usa valores fijos.
 * Con la opcion "Beatmatch" y los downbeats de las dos canciones, la entrante se acelera/frena (sin cambiar el tono)
 * hasta el tempo de la que sale y su primer downbeat cae en el downbeat donde empieza el fundido.
 */
public final class AutomixBackup {
    private AutomixBackup() {}

    // ===================== OPCIONES (las pone el parche al inicio de wf0.invokeSuspend) =====================
    // Antes de la primera llamada estan apagadas: Eclipse se comporta como el original.
    private static volatile boolean optBeatmatch = false;
    private static volatile boolean optLocalFirst = false;
    private static volatile boolean optLocalOnly = false;
    private static volatile boolean optDebug = false;

    /** Opcion del parche "Beatmatch": la entrante cambia de velocidad hasta el tempo de la que sale. */
    public static void setBeatmatch(boolean on) { optBeatmatch = on; }

    /** Opcion del parche "Plan local primero": plan local para todas las canciones (servidor solo si falla el local). */
    public static void setLocalFirst(boolean on) { optLocalFirst = on; }

    /** Opcion del parche "Solo Automix local": el servidor de Eclipse no se usa NUNCA (el plan local siempre responde). */
    public static void setLocalOnly(boolean on) { optLocalOnly = on; }

    /** Opcion del parche "Avisos de depuracion": Toast cortos con lo que decide el plan local. */
    public static void setDebug(boolean on) { optDebug = on; }

    // ===================== Avisos de depuracion =====================
    private static final String TAG = "AutomixBackup";
    private static String lastMsg = "";
    private static long lastMsgAt = 0L;

    static void dbg(String msg) {
        if (!optDebug) return;
        try {
            long now = System.currentTimeMillis();
            synchronized (AutomixBackup.class) {
                if (msg.equals(lastMsg) && now - lastMsgAt < 8000L) return;
                lastMsg = msg;
                lastMsgAt = now;
            }
            Log.d(TAG, msg.replace('\n', ' '));
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            final String m = msg;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, m, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    private static String shortId(String id) {
        if (id == null) return "?";
        return id.length() > 6 ? id.substring(id.length() - 6) : id;
    }

    /** "124F" = BPM de la ficha de Eclipse, "124D" = de Deezer, "124S" = de SongBPM, "124T" = de Tunebat. */
    private static String bpmTag(String id, Double bpm) {
        if (bpm == null) return "--";
        CardInfo ci = id == null ? null : infoFor(id);
        String web = id == null ? null : webSrc.get(id);
        String src = (ci != null && ci.hasBpm()) ? "F" : (web != null ? web : "D");
        return String.format(Locale.ROOT, "%.0f%s", bpm.doubleValue(), src);
    }

    private static void dbgPlan(String origin, String outId, String inId, Decision d) {
        if (!optDebug) return;
        try {
            String kind = "beatmatched".equals(d.tier) ? "BEATMATCH" : ("dj_blend".equals(d.style) ? "blend" : "filtro");
            StringBuilder b = new StringBuilder();
            b.append(origin).append(' ').append(kind).append('\n');
            b.append(bpmTag(outId, d.outBpm)).append('>').append(bpmTag(inId, d.inBpm));
            b.append(String.format(Locale.ROOT, " f%.1f", d.fade));
            if (d.start > 0) b.append(String.format(Locale.ROOT, " ini%.0f", d.start));
            if (d.cue > 0) b.append(String.format(Locale.ROOT, " cue%.1f", d.cue));
            if ("beatmatched".equals(d.tier)) b.append(String.format(Locale.ROOT, " v%.3f", d.rate));
            else if (d.why != null) b.append('\n').append(d.why);
            dbg(b.toString());
        } catch (Throwable ignored) {}
    }

    // ===================== AJUSTES (se tocan aqui) =====================
    /** Beatmatch solo si hay downbeats de las dos canciones (fase alineada); sin fase, igualar tempo suena peor que no hacerlo. */
    static final boolean BEATMATCH_NEEDS_PHASE = true;
    /** Empezar el fundido en un downbeat de la que sale (cerca de donde empieza su final). */
    static final boolean SMART_START = true;
    /** Como mucho cuantos segundos antes del inicio por defecto puede adelantarse el fundido. */
    static final double MAX_EARLY_START = 15.0;
    /** Como mucho cuantos segundos se salta del inicio de la entrante para que su primer downbeat caiga al empezar el fundido. */
    static final double MAX_CUE = 4.0;
    /** Beatmatch solo si la distancia de tempo (|1 - bpmSale/bpmEntra|) es menor o igual a esto (Harmoni usa 0,04; antes 0,06). */
    static final double BEATMATCH_MAX_DIST = 0.04;
    /** Beatmatch solo si la confianza de beat de las DOS fichas es al menos esto (Harmoni usa 0,55). Si la ficha no trae el dato, se deja pasar. */
    static final double MIN_BEATMATCH_CONFIDENCE = 0.55;
    /** true: si Deezer no da el BPM, se prueba SongBPM y luego Tunebat (paginas web). Ese BPM solo afecta al filtro y al largo del fundido, nunca al beatmatch. */
    static final boolean EXTRA_BPM_SOURCES = true;
    /** Distancia de tempo hasta la que se considera "parecido" (dj_blend). */
    static final double CLOSE_TEMPO = 0.08;
    /** Fichas de Eclipse con confianza de beat menor a esto se ignoran. */
    static final double MIN_BEAT_CONFIDENCE = 0.2;

    static final double SWEEP_START_HZ = 20000.0;
    static final double SWEEP_END_NEAR_HZ = 3000.0;
    static final double SWEEP_END_FAR_HZ = 900.0;
    static final double SWEEP_FAR_DIST = 0.25;
    static final double SWEEP_END_UNKNOWN_HZ = 2200.0;
    static final boolean BASS_SWAP = true;
    static final double BASS_SWAP_FRACTION = 0.5;
    static final double MIN_FADE_SECONDS = 1.0;
    static final double MAX_FADE_SECONDS = 12.0;
    static final double MIN_BAR_FADE_SECONDS = 4.0;
    static final double BPM_MIN = 40.0, BPM_MAX = 220.0;

    /** true: si falta la ficha local de una cancion, el plan pide a Eclipse analizarla antes (estado "needs"). */
    static final boolean ANALYZE_ON_NEEDS = true;
    /** Un ISRC sin ficha solo se vuelve a pedir pasado este tiempo. */
    static final long ASK_RETRY_MS = 120000L;
    /** Maximo de pedidos de analisis por ISRC y sesion. */
    static final int ASK_MAX = 3;

    private static final String PREFS = "eclipse_automix_backup";
    private static final long NEGATIVE_TTL_MS = 30L * 60L * 1000L;
    private static final long WAIT_MS = 4500L;
    private static final Pattern ISRC = Pattern.compile("^[A-Z]{2}[A-Z0-9]{3}[0-9]{7}$");

    // ===================== ISRC y datos de la cancion =====================
    /** ISRC como lo normaliza Eclipse (yf0.e): sin guiones, sin espacios en los bordes, mayusculas. */
    static String normalize(String isrc) {
        return isrc.replace("-", "").trim().toUpperCase(Locale.ROOT);
    }

    static boolean isFake(String isrc) {
        return isrc != null && isrc.length() == 12 && isrc.startsWith("ZZ");
    }

    /** ISRC estable e inventado a partir del id: ZZ + 3 alfanumericos + 7 digitos (cumple el formato). */
    static String fakeIsrc(String id) {
        long h = 0xcbf29ce484222325L;
        for (int i = 0; i < id.length(); i++) {
            h ^= id.charAt(i);
            h *= 0x100000001b3L;
        }
        long v = h >>> 1;
        int letters = (int) (v % 46656L);
        v /= 46656L;
        long digits = v % 10000000L;
        String l = Integer.toString(letters, 36).toUpperCase(Locale.ROOT);
        while (l.length() < 3) l = "0" + l;
        String d = Long.toString(digits);
        while (d.length() < 7) d = "0" + d;
        return "ZZ" + l + d;
    }

    /** ISRC -> {artista, titulo}, para buscar en Deezer cuando no hay ISRC o Deezer no lo conoce. */
    private static final ConcurrentHashMap<String, String[]> meta = new ConcurrentHashMap<String, String[]>();

    private static String str(Object song, String method) {
        try {
            Object r = song.getClass().getMethod(method).invoke(song);
            if (r instanceof String) return (String) r;
        } catch (Throwable ignored) {}
        return null;
    }

    /**
     * Gancho de los Song.getIsrc() de Automix (ig0.a x1, ig0.d x2): devuelve el ISRC real y, si es null o vacio, uno
     * inventado a partir del id. De paso guarda artista y titulo. Nunca lanza; ante fallo devuelve el ISRC original.
     */
    public static String isrcFor(Object song) {
        String real = null;
        try {
            real = str(song, "getIsrc");
        } catch (Throwable ignored) {}
        String result = real;
        try {
            if (real != null && normalize(real).length() > 0) {
                result = real;
            } else {
                String id = str(song, "getId");
                if (id != null && id.length() > 0) result = fakeIsrc(id);
            }
            if (result != null) {
                String artist = str(song, "getArtist");
                if (artist == null || artist.trim().length() == 0) artist = str(song, "getDisplayArtist");
                String title = str(song, "getTitle");
                if (title != null && title.trim().length() > 0) {
                    meta.put(normalize(result), new String[]{artist == null ? "" : artist, title});
                }
            }
        } catch (Throwable ignored) {}
        return result;
    }

    // ===================== Cache de BPM =====================
    private static final ConcurrentHashMap<String, Double> found = new ConcurrentHashMap<String, Double>();
    private static final ConcurrentHashMap<String, Long> missed = new ConcurrentHashMap<String, Long>();

    private static SharedPreferences prefs() {
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Context) return ((Context) app).getSharedPreferences(PREFS, 0);
        } catch (Throwable ignored) {}
        return null;
    }

    static Double cached(String id) {
        Double d = found.get(id);
        if (d != null) return d;
        SharedPreferences p = prefs();
        if (p != null) {
            float f = p.getFloat("bpm:" + id, 0f);
            if (f > 0f) {
                d = Double.valueOf(f);
                found.put(id, d);
                return d;
            }
        }
        return null;
    }

    private static void store(String id, double bpm) {
        store(id, bpm, null, null);
    }

    private static void store(String id, double bpm, Double conf, String key) {
        found.put(id, Double.valueOf(bpm));
        missed.remove(id);
        try {
            SharedPreferences p = prefs();
            if (p != null) {
                SharedPreferences.Editor e = p.edit().putFloat("bpm:" + id, (float) bpm);
                if (conf != null) e.putFloat("conf:" + id, (float) conf.doubleValue());
                if (key != null) e.putString("key:" + id, key);
                e.apply();
            }
        } catch (Throwable ignored) {}
    }

    private static boolean recentlyMissed(String id) {
        Long t = missed.get(id);
        return t != null && System.currentTimeMillis() - t.longValue() < NEGATIVE_TTL_MS;
    }

    // ===================== Ficha del analizador de Eclipse (tf0.a) =====================
    private static Pattern numKey(String name) {
        return Pattern.compile("\"" + name + "\"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?(?:[eE][-+]?[0-9]+)?)");
    }
    private static final Pattern CARD_BPM = numKey("bpm");
    private static final Pattern CARD_ABPM = numKey("analyzedBpm");
    private static final Pattern CARD_INTERVAL = numKey("beatInterval");
    private static final Pattern CARD_CONF = numKey("beatConfidence");
    private static final Pattern CARD_DURATION = numKey("duration");
    private static final Pattern CARD_OUTRO = numKey("outroStartTime");
    private static final Pattern CARD_KEY = Pattern.compile("\"key\"\\s*:\\s*\"([^\"]{1,16})\"");
    private static final Pattern FAKE_CARD = Pattern.compile("\"isrc\"\\s*:\\s*\"(ZZ[A-Z0-9]{10})\"");

    private static Double firstNumber(Pattern p, String s) {
        Matcher m = p.matcher(s);
        if (!m.find()) return null;
        try {
            double v = Double.parseDouble(m.group(1));
            return (Double.isNaN(v) || Double.isInfinite(v)) ? null : Double.valueOf(v);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    /** BPM de la ficha: "bpm", si no "analyzedBpm", si no 60 / beatInterval (segundos o milisegundos). */
    static Double bpmFromCard(String card) {
        Double a = firstNumber(CARD_BPM, card);
        if (validBpm(a)) return a;
        Double b = firstNumber(CARD_ABPM, card);
        if (validBpm(b)) return b;
        Double iv = firstNumber(CARD_INTERVAL, card);
        if (iv != null && iv.doubleValue() > 0) {
            double sec = iv.doubleValue() > 20.0 ? iv.doubleValue() / 1000.0 : iv.doubleValue();
            Double c = Double.valueOf(60.0 / sec);
            if (validBpm(c)) return c;
        }
        return null;
    }

    /** Lo que se guarda de la ficha para colocar el fundido y alinear compases. Tiempos en segundos. */
    static final class CardInfo {
        double duration = -1;      // duracion de la cancion segun la ficha
        double outro = -1;         // inicio del final (outroStartTime)
        double firstDownbeat = -1; // primer downbeat
        double[] downbeats;        // primeros 4 + ultimos 60 downbeats (ascendente)
        Double beatBpm;            // BPM calculado de los intervalos de beats[]
        double bpm = -1;           // BPM final de la ficha (beats + campo bpm); -1 = sin dato
        double conf = -1;          // beatConfidence de la ficha; -1 = la ficha no lo trae

        boolean hasDownbeats() { return downbeats != null && downbeats.length > 0; }
        /** false solo si la ficha trae la confianza de beat y es menor que la exigida para el beatmatch. */
        boolean rhythmSure() { return conf < 0 || conf >= MIN_BEATMATCH_CONFIDENCE; }
        boolean hasBpm() { return validBpm(Double.valueOf(bpm)); }
    }

    private static double[] numArray(String card, String name) {
        Matcher m = Pattern.compile("\"" + name + "\"\\s*:\\s*\\[([^\\]\\[{]*)\\]").matcher(card);
        if (!m.find()) return null;
        String[] parts = m.group(1).split(",");
        double[] tmp = new double[parts.length];
        int n = 0;
        for (String p : parts) {
            String t = p.trim();
            if (t.length() == 0) continue;
            try {
                double v = Double.parseDouble(t);
                if (!Double.isNaN(v) && !Double.isInfinite(v) && v >= 0) tmp[n++] = v;
            } catch (NumberFormatException ignored) {}
        }
        if (n == 0) return null;
        double[] out = new double[n];
        System.arraycopy(tmp, 0, out, 0, n);
        Arrays.sort(out);
        return out;
    }

    private static double maxOf(double[] a) {
        double m = 0;
        if (a != null) for (double v : a) if (v > m) m = v;
        return m;
    }

    private static double[] scaled(double[] a, double k) {
        if (a == null || k == 1.0) return a;
        double[] o = new double[a.length];
        for (int i = 0; i < a.length; i++) o[i] = a[i] * k;
        return o;
    }

    /** BPM por la mediana de los intervalos entre beats (mas fino que el campo bpm). null si no hay datos fiables. */
    static Double bpmFromBeats(double[] beats) {
        if (beats == null || beats.length < 8) return null;
        double[] d = new double[beats.length - 1];
        int n = 0;
        for (int i = 1; i < beats.length; i++) {
            double x = beats[i] - beats[i - 1];
            if (x >= 0.15 && x <= 2.0) d[n++] = x;
        }
        if (n < 6) return null;
        double[] c = new double[n];
        System.arraycopy(d, 0, c, 0, n);
        Arrays.sort(c);
        double med = (n % 2 == 1) ? c[n / 2] : (c[n / 2 - 1] + c[n / 2]) / 2.0;
        double bpm = 60.0 / med;
        for (int i = 0; i < 2 && bpm < BPM_MIN; i++) bpm *= 2.0;
        for (int i = 0; i < 2 && bpm > BPM_MAX; i++) bpm /= 2.0;
        return (bpm >= BPM_MIN && bpm <= BPM_MAX) ? Double.valueOf(bpm) : null;
    }

    /** Junta el BPM del campo de la ficha con el de los intervalos de beats: si coinciden (o van a octava) manda el de beats. */
    static Double reconcileBpm(Double card, Double beats) {
        if (!validBpm(beats)) return validBpm(card) ? card : null;
        if (!validBpm(card)) return beats;
        double b = beats.doubleValue(), c = card.doubleValue();
        double best = b;
        double[] cands = {b, b * 2.0, b / 2.0};
        double bd = Math.abs(b / c - 1.0);
        for (double x : cands) {
            if (x < BPM_MIN || x > BPM_MAX) continue;
            double dd = Math.abs(x / c - 1.0);
            if (dd < bd) { bd = dd; best = x; }
        }
        return bd <= 0.08 ? Double.valueOf(best) : card;
    }

    static CardInfo parseInfo(String card) {
        CardInfo ci = new CardInfo();
        Double dur = firstNumber(CARD_DURATION, card);
        if (dur != null && dur.doubleValue() > 0) {
            double dv = dur.doubleValue();
            ci.duration = dv > 20000.0 ? dv / 1000.0 : dv;
        }
        Double outro = firstNumber(CARD_OUTRO, card);
        double[] db = numArray(card, "downbeats");
        double[] beats = numArray(card, "beats");
        // Unidades: si hay tiempos mayores que la duracion pero entran en milisegundos, se pasan a segundos.
        double k = 1.0;
        if (ci.duration > 0) {
            double mx = Math.max(maxOf(db), Math.max(maxOf(beats), outro == null ? 0 : outro.doubleValue()));
            if (mx > ci.duration * 1.5 && mx / 1000.0 <= ci.duration * 1.05) k = 0.001;
        }
        db = scaled(db, k);
        beats = scaled(beats, k);
        if (outro != null && outro.doubleValue() > 0) ci.outro = outro.doubleValue() * k;
        ci.beatBpm = bpmFromBeats(beats);
        ci.bpm = -1;
        Double merged = reconcileBpm(bpmFromCard(card), ci.beatBpm);
        if (merged != null) ci.bpm = merged.doubleValue();
        if (db != null) {
            if (db.length > 64) {
                double[] keep = new double[64];
                System.arraycopy(db, 0, keep, 0, 4);
                System.arraycopy(db, db.length - 60, keep, 4, 60);
                db = keep;
            }
            ci.downbeats = db;
            ci.firstDownbeat = db[0];
        }
        Double cf = firstNumber(CARD_CONF, card);
        if (cf != null && cf.doubleValue() >= 0) ci.conf = cf.doubleValue();
        boolean any = ci.duration > 0 || ci.outro > 0 || ci.hasDownbeats();
        return any ? ci : null;
    }

    private static final ConcurrentHashMap<String, CardInfo> infos = new ConcurrentHashMap<String, CardInfo>();

    private static String serialize(CardInfo ci) {
        StringBuilder b = new StringBuilder(256);
        b.append(String.format(Locale.ROOT, "%.3f|%.3f|%.3f|", ci.duration, ci.outro, ci.firstDownbeat));
        if (ci.downbeats != null) {
            for (int i = 0; i < ci.downbeats.length; i++) {
                if (i > 0) b.append(',');
                b.append(String.format(Locale.ROOT, "%.3f", ci.downbeats[i]));
            }
        }
        b.append('|').append(String.format(Locale.ROOT, "%.4f", ci.bpm));
        b.append('|').append(String.format(Locale.ROOT, "%.3f", ci.conf));
        return b.toString();
    }

    private static CardInfo deserialize(String s) {
        try {
            String[] p = s.split("\\|", -1);
            if (p.length < 4) return null;
            CardInfo ci = new CardInfo();
            ci.duration = Double.parseDouble(p[0]);
            ci.outro = Double.parseDouble(p[1]);
            ci.firstDownbeat = Double.parseDouble(p[2]);
            if (p[3].length() > 0) {
                String[] q = p[3].split(",");
                double[] a = new double[q.length];
                for (int i = 0; i < q.length; i++) a[i] = Double.parseDouble(q[i]);
                ci.downbeats = a;
            }
            if (p.length >= 5 && p[4].length() > 0) ci.bpm = Double.parseDouble(p[4]);
            if (p.length >= 6 && p[5].length() > 0) ci.conf = Double.parseDouble(p[5]);
            return ci;
        } catch (Throwable t) {
            return null;
        }
    }

    private static void storeInfo(String id, CardInfo ci) {
        infos.put(id, ci);
        try {
            SharedPreferences p = prefs();
            if (p != null) p.edit().putString("info:" + id, serialize(ci)).apply();
        } catch (Throwable ignored) {}
    }

    static CardInfo infoFor(String isrc) {
        try {
            if (isrc == null) return null;
            String id = normalize(isrc);
            CardInfo ci = infos.get(id);
            if (ci != null) return ci;
            SharedPreferences p = prefs();
            if (p == null) return null;
            String s = p.getString("info:" + id, null);
            if (s == null) return null;
            ci = deserialize(s);
            if (ci != null) infos.put(id, ci);
            return ci;
        } catch (Throwable t) {
            return null;
        }
    }

    private static final ConcurrentHashMap<String, Boolean> carded = new ConcurrentHashMap<String, Boolean>();

    private static void markCard(String id) {
        carded.put(id, Boolean.TRUE);
        try {
            SharedPreferences p = prefs();
            if (p != null) p.edit().putBoolean("card:" + id, true).apply();
        } catch (Throwable ignored) {}
    }

    /** true si la ficha de ESTA cancion ya paso por onCard (aunque su BPM fuera invalido o de poca confianza). */
    static boolean hasCard(String id) {
        if (carded.containsKey(id)) return true;
        try {
            SharedPreferences p = prefs();
            if (p != null && p.getBoolean("card:" + id, false)) {
                carded.put(id, Boolean.TRUE);
                return true;
            }
        } catch (Throwable ignored) {}
        return false;
    }

    /**
     * Gancho de tf0.a: recibe el ISRC y la ficha que Eclipse acaba de calcular en el telefono (antes de subirla).
     * Guarda BPM, beats, downbeats e inicio del final. Nunca lanza ni bloquea.
     */
    public static void onCard(String isrc, String card) {
        try {
            if (isrc == null || card == null) return;
            String id = normalize(isrc);
            if (!ISRC.matcher(id).matches()) return;
            markCard(id);
            Double conf = firstNumber(CARD_CONF, card);
            if (conf != null && conf.doubleValue() < MIN_BEAT_CONFIDENCE) {
                dbg("ANALISIS " + shortId(id) + "\nconfianza baja, se ignora");
                return;
            }
            CardInfo ci = parseInfo(card);
            Double bpm = ci != null && ci.hasBpm() ? Double.valueOf(ci.bpm) : reconcileBpm(bpmFromCard(card), null);
            if (ci != null) storeInfo(id, ci);
            if (optDebug) {
                int nd = ci != null && ci.downbeats != null ? ci.downbeats.length : 0;
                dbg("ANALISIS " + shortId(id) + (isFake(id) ? " (sin ISRC)" : "") + "\nbpm "
                    + (bpm == null ? "--" : String.format(Locale.ROOT, "%.1f", bpm.doubleValue()))
                    + (nd > 0 ? " compases ok" : " SIN compases")
                    + (ci != null && ci.duration > 0 ? String.format(Locale.ROOT, " %.0fs", ci.duration) : ""));
            }
            if (bpm == null) return;
            Matcher km = CARD_KEY.matcher(card);
            store(id, bpm.doubleValue(), conf, km.find() ? km.group(1) : null);
        } catch (Throwable ignored) {}
    }

    // ===================== Analisis a pedido (estado "needs") y subida de fichas =====================
    /** Pedidos de analisis por ISRC: {hora del ultimo pedido (ms), numero de pedidos}. */
    private static final ConcurrentHashMap<String, long[]> asked = new ConcurrentHashMap<String, long[]>();

    private static boolean mayAsk(String id, long now) {
        synchronized (asked) {
            long[] a = asked.get(id);
            if (a == null) {
                asked.put(id, new long[]{now, 1L});
                return true;
            }
            if (a[1] >= ASK_MAX) return false;
            if (now - a[0] < ASK_RETRY_MS) return false;
            a[0] = now;
            a[1]++;
            return true;
        }
    }

    /** true si queremos la ficha local de esta cancion: plan local primero, o ISRC inventado; y aun no la tenemos. */
    static boolean wantCard(String id) {
        if (!ANALYZE_ON_NEEDS || id == null) return false;
        if (!optLocalFirst && !optLocalOnly && !isFake(id)) return false;
        return !hasCard(id);
    }

    /**
     * Gancho de dg0.D (el "ya analizada/subida" de Eclipse): true = forzar el analisis (dg0.D devuelve false).
     * Solo si queremos la ficha de esta cancion y no la tenemos; si no, Eclipse decide como siempre.
     */
    public static boolean forceAnalyze(String isrc) {
        try {
            if (isrc == null) return false;
            return wantCard(normalize(isrc));
        } catch (Throwable t) {
            return false;
        }
    }

    /** Gancho de la subida de la ficha (xf0, caso 0): true = NO subir (la ficha lleva un ISRC inventado). */
    public static boolean blockUpload(String card) {
        try {
            boolean b = card != null && FAKE_CARD.matcher(card).find();
            if (b) dbg("NO SUBE ficha\n(ISRC propio)");
            return b;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void addNeed(List<String> out, String isrc) {
        if (isrc == null) return;
        String id = normalize(isrc);
        if (!ISRC.matcher(id).matches()) return;
        if (!wantCard(id)) return;
        if (!mayAsk(id, System.currentTimeMillis())) return;
        if (!out.contains(id)) out.add(id);
    }

    /**
     * Si a alguna de las dos canciones le falta la ficha local y aun no se la hemos pedido a Eclipse, devuelve el JSON
     * {"status":"needs","needs":[...]}: ig0.d analiza esas canciones con su analizador y vuelve a pedir el plan
     * (segunda llamada: ya no hay pendientes y sale el plan normal). Sin pendientes devuelve null.
     */
    static String needsJson(String outIsrc, String inIsrc) {
        List<String> need = new ArrayList<String>();
        addNeed(need, outIsrc);
        addNeed(need, inIsrc);
        if (need.isEmpty()) return null;
        dbg("PIDE ANALISIS\n" + need.size() + " cancion(es)");
        StringBuilder b = new StringBuilder(96);
        b.append("{\"status\":\"needs\",\"needs\":[");
        for (int i = 0; i < need.size(); i++) {
            if (i > 0) b.append(',');
            b.append('"').append(need.get(i)).append('"');
        }
        return b.append("]}").toString();
    }

    // ===================== Deezer =====================
    static volatile String deezerBase = "https://api.deezer.com/";
    private static final Pattern BPM = Pattern.compile("\"bpm\"\\s*:\\s*([0-9]+(?:\\.[0-9]+)?)");
    private static final Pattern HIT = Pattern.compile(
            "\"id\"\\s*:\\s*([0-9]+)\\s*,\\s*\"readable\"\\s*:\\s*(?:true|false)\\s*,\\s*\"title\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\""
                    + ".*?\"artist\"\\s*:\\s*\\{\\s*\"id\"\\s*:\\s*[0-9]+\\s*,\\s*\"name\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"",
            Pattern.DOTALL);

    static String httpGet(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(2500);
            c.setReadTimeout(2500);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 400000) break;
                }
                return out.toString("UTF-8");
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    static Double bpmOf(String json) {
        if (json == null) return null;
        Matcher m = BPM.matcher(json);
        if (!m.find()) return null;
        try {
            double v = Double.parseDouble(m.group(1));
            return v > 0 ? Double.valueOf(v) : null;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    static String unescape(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch != '\\' || i + 1 >= s.length()) { b.append(ch); continue; }
            char n = s.charAt(++i);
            if (n == 'u' && i + 4 < s.length()) {
                try { b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; continue; }
                catch (NumberFormatException ignored) {}
            }
            if (n == 'n' || n == 't' || n == 'r') b.append(' ');
            else b.append(n);
        }
        return b.toString();
    }

    /** Minusculas, sin acentos, sin lo que va entre parentesis/corchetes, sin "feat ...", solo letras y digitos. */
    static String norm(String s) {
        if (s == null) return "";
        String t = s.replaceAll("\\([^)]*\\)|\\[[^\\]]*\\]", " ");
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        t = t.toLowerCase(Locale.ROOT);
        t = t.replaceAll("\\b(feat|ft|featuring|con)\\b.*$", " ");
        t = t.replaceAll("[^a-z0-9]+", "");
        return t;
    }

    /** Primer artista de una lista tipo "A, B & C" o "A feat. B". */
    static String firstArtist(String a) {
        if (a == null) return "";
        String[] parts = a.split("(?i)\\s*(,|&|;|/|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bx\\b|\\by\\b)\\s*", 2);
        return parts.length > 0 ? parts[0] : a;
    }

    static boolean sameTitle(String want, String got) {
        String a = norm(want), b = norm(got);
        if (a.length() == 0 || b.length() == 0) return false;
        return a.equals(b) || (a.length() >= 4 && b.startsWith(a)) || (b.length() >= 4 && a.startsWith(b));
    }

    static boolean sameArtist(String want, String got) {
        String a = norm(firstArtist(want)), b = norm(got);
        if (a.length() == 0) return true; // sin artista conocido: se confia en el titulo
        if (b.length() == 0) return false;
        return a.equals(b) || (a.length() >= 3 && b.contains(a)) || (b.length() >= 3 && a.contains(b));
    }

    /** Id de la primera pista de la respuesta de busqueda cuyo titulo y artista coinciden. */
    static String pickTrackId(String searchJson, String artist, String title) {
        if (searchJson == null) return null;
        Matcher m = HIT.matcher(searchJson);
        int seen = 0;
        while (m.find() && seen++ < 10) {
            String t = unescape(m.group(2));
            String a = unescape(m.group(3));
            if (sameTitle(title, t) && sameArtist(artist, a)) return m.group(1);
        }
        return null;
    }

    static Double deezerByIsrc(String isrc) {
        return bpmOf(httpGet(deezerBase + "track/isrc:" + isrc));
    }

    static Double deezerBySearch(String artist, String title) {
        try {
            String a = firstArtist(artist).replace("\"", " ").trim();
            String t = title.replace("\"", " ").trim();
            String q1 = a.length() > 0 ? "artist:\"" + a + "\" track:\"" + t + "\"" : "track:\"" + t + "\"";
            String id = pickTrackId(httpGet(deezerBase + "search?limit=8&q=" + URLEncoder.encode(q1, "UTF-8")), artist, title);
            if (id == null) {
                String q2 = (a + " " + t).trim();
                id = pickTrackId(httpGet(deezerBase + "search?limit=8&q=" + URLEncoder.encode(q2, "UTF-8")), artist, title);
            }
            if (id == null) return null;
            return bpmOf(httpGet(deezerBase + "track/" + id));
        } catch (Throwable t) {
            return null;
        }
    }

    // ===================== Otras fuentes de BPM: SongBPM y Tunebat (como Harmoni, pero comprobando la cancion) =====================
    /** Bases de SongBPM y Tunebat (cambiables para las pruebas). */
    static volatile String songBpmBase = "https://songbpm.com/";
    static volatile String tunebatBase = "https://tunebat.com/";
    private static final String BROWSER_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final Pattern WEB_BPM = Pattern.compile("(\\d{2,3}(?:\\.\\d+)?)\\s*(?:BPM|bpm)");
    private static final Pattern JSON_BPM = Pattern.compile("\"bpm\"\\s*:\\s*\"?(\\d{2,3}(?:\\.\\d+)?)");
    private static final Pattern NEXT_DATA = Pattern.compile("<script id=\"__NEXT_DATA__\"[^>]*>(.*?)</script>", Pattern.DOTALL);
    private static final int WEB_WINDOW = 300;

    /** De donde salio el BPM de una cancion que no vino de la ficha: "D" Deezer, "S" SongBPM, "T" Tunebat (solo en memoria; es para el aviso). */
    private static final ConcurrentHashMap<String, String> webSrc = new ConcurrentHashMap<String, String>();

    static String httpGetHtml(String url) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(3000);
            c.setReadTimeout(3000);
            c.setRequestProperty("User-Agent", BROWSER_UA);
            c.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) {
                    out.write(buf, 0, n);
                    if (out.size() > 1500000) break;
                }
                return out.toString("UTF-8");
            } finally {
                in.close();
            }
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    /** Termino de busqueda limpio (sin "(feat. ...)", "[...]" ni simbolos), como hace Harmoni. */
    static String cleanQuery(String s) {
        if (s == null) return "";
        String t = s.replaceAll("(?i)\\((feat\\.|ft\\.|with|official|video|audio|remix|edit|deluxe|version)[^)]*\\)", " ");
        t = t.replaceAll("\\[[^\\]]*\\]", " ");
        t = t.replaceAll("[^\\p{L}\\p{N}\\s\\-]", " ");
        return t.replaceAll("\\s+", " ").trim();
    }

    private static String htmlDecode(String s) {
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#x27;", "'").replace("&#39;", "'")
                .replace("&apos;", "'").replace("&nbsp;", " ");
    }

    /** Texto plano de una pagina HTML (sin etiquetas). */
    static String htmlText(String html) {
        return htmlDecode(html.replaceAll("<[^>]*>", " "));
    }

    /** Palabras en minusculas, sin acentos, sin lo que va entre parentesis/corchetes ni "feat ...", separadas por un espacio. */
    static String foldWords(String s) {
        if (s == null) return "";
        String t = s.replaceAll("\\([^)]*\\)|\\[[^\\]]*\\]", " ");
        t = Normalizer.normalize(t, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        t = t.toLowerCase(Locale.ROOT);
        t = t.replaceAll("\\b(feat|ft|featuring|con)\\b.*$", " ");
        return t.replaceAll("[^a-z0-9]+", " ").trim();
    }

    /** Palabras en minusculas y sin acentos, separadas por un espacio (sin quitar parentesis ni "feat"): para texto de paginas. */
    static String foldPlain(String s) {
        String t = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return t.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim();
    }

    /**
     * BPM ("NNN BPM", patron pat, grupo 1) que pertenece a la cancion. Se miran los numeros que llevan el titulo (y, si
     * se conoce, el primer artista) como palabras enteras a menos de WEB_WINDOW caracteres: primero con el titulo ANTES
     * del numero (como en las paginas que miro Harmoni: "titulo ... 128 BPM") y, si no hay, con el titulo DESPUES.
     * Gana el mas cercano al titulo; si otro con distinto BPM esta casi igual de cerca, no hay dato. Harmoni toma el
     * primer numero que ve sin comprobar la cancion; aqui, si no se puede comprobar, se usan los valores fijos en vez
     * de un BPM de otra cancion.
     */
    static Double bpmNear(String text, Pattern pat, String artist, String title) {
        if (text == null) return null;
        String t = foldWords(title);
        if (t.length() < 2) return null;
        String a = foldWords(firstArtist(artist));
        double r = bpmNearSide(text, pat, t, a, true);
        if (Double.isNaN(r)) return null;
        if (r < 0) {
            r = bpmNearSide(text, pat, t, a, false);
            if (Double.isNaN(r) || r < 0) return null;
        }
        return Double.valueOf(r);
    }

    /**
     * -1 = ningun candidato, NaN = ambiguo, si no el BPM. before=true: el titulo esta antes del numero. La ventana de
     * cada numero se corta en el numero vecino, para que un titulo solo se empareje con su BPM y no con el de la tarjeta
     * de al lado.
     */
    private static double bpmNearSide(String text, Pattern pat, String t, String a, boolean before) {
        String tk = " " + t + " ";
        String ak = " " + a + " ";
        List<int[]> ms = new ArrayList<int[]>();        // {inicio, fin} de cada "NNN BPM"
        List<Double> vals = new ArrayList<Double>();
        Matcher m = pat.matcher(text);
        while (m.find() && ms.size() < 60) {
            double v;
            try { v = Double.parseDouble(m.group(1)); } catch (NumberFormatException e) { continue; }
            if (v < BPM_MIN || v > BPM_MAX) continue;
            ms.add(new int[]{m.start(), m.end()});
            vals.add(Double.valueOf(v));
        }
        List<double[]> cands = new ArrayList<double[]>(); // {bpm, distancia al titulo}
        for (int k = 0; k < ms.size(); k++) {
            int st = ms.get(k)[0], en = ms.get(k)[1];
            String w;
            if (before) {
                int from = Math.max(k > 0 ? ms.get(k - 1)[1] : 0, st - WEB_WINDOW);
                w = text.substring(from, st);
            } else {
                int to = Math.min(k + 1 < ms.size() ? ms.get(k + 1)[0] : text.length(), en + WEB_WINDOW);
                w = text.substring(en, to);
            }
            w = " " + foldPlain(unescape(w)) + " ";
            int d;
            if (before) {
                int i = w.lastIndexOf(tk);
                if (i < 0) continue;
                d = w.length() - (i + tk.length());
            } else {
                d = w.indexOf(tk);
                if (d < 0) continue;
            }
            if (a.length() > 0 && !w.contains(ak)) continue;
            cands.add(new double[]{vals.get(k).doubleValue(), d});
        }
        if (cands.isEmpty()) return -1.0;
        double[] best = cands.get(0);
        for (double[] c : cands) if (c[1] < best[1]) best = c;
        for (double[] c : cands) {
            if (Math.abs(c[0] - best[0]) >= 0.5 && c[1] < 2.0 * best[1] + 20.0) return Double.NaN;
        }
        return best[0];
    }

    static Double songBpmSearch(String artist, String title) {
        try {
            String q = cleanQuery(firstArtist(artist) + " " + title);
            if (q.length() == 0) return null;
            String html = httpGetHtml(songBpmBase + "searches?q=" + URLEncoder.encode(q, "UTF-8"));
            if (html == null) return null;
            return bpmNear(htmlText(html), WEB_BPM, artist, title);
        } catch (Throwable t) {
            return null;
        }
    }

    static Double tunebatSearch(String artist, String title) {
        try {
            String q = cleanQuery(firstArtist(artist) + " " + title);
            if (q.length() == 0) return null;
            String html = httpGetHtml(tunebatBase + "Search?q=" + URLEncoder.encode(q, "UTF-8"));
            if (html == null) return null;
            Matcher nd = NEXT_DATA.matcher(html);
            if (nd.find()) {
                Double v = bpmNear(nd.group(1), JSON_BPM, artist, title);
                if (v != null) return v;
            }
            return bpmNear(htmlText(html), WEB_BPM, artist, title);
        } catch (Throwable t) {
            return null;
        }
    }

    static Double lookup(String id) {
        Double d = null;
        try {
            if (!isFake(id)) d = deezerByIsrc(id);
        } catch (Throwable ignored) {}
        if (!validBpm(d)) {
            d = null;
            String[] m = meta.get(id);
            if (m != null) {
                try { d = deezerBySearch(m[0], m[1]); } catch (Throwable ignored) {}
            }
        }
        if (validBpm(d)) {
            webSrc.put(id, "D");
        } else if (EXTRA_BPM_SOURCES) {
            d = null;
            String[] m = meta.get(id);
            if (m != null && m[1] != null && m[1].trim().length() > 0) {
                try { d = songBpmSearch(m[0], m[1]); } catch (Throwable ignored) { d = null; }
                if (validBpm(d)) {
                    webSrc.put(id, "S");
                } else {
                    try { d = tunebatSearch(m[0], m[1]); } catch (Throwable ignored) { d = null; }
                    if (validBpm(d)) webSrc.put(id, "T");
                }
            }
        }
        if (validBpm(d)) {
            store(id, d.doubleValue());
            return d;
        }
        missed.put(id, Long.valueOf(System.currentTimeMillis()));
        return null;
    }

    /** BPM de las dos canciones (ficha local primero, luego Deezer); consulta en paralelo y espera como mucho WAIT_MS. */
    private static Double[] bpms(String outId, String inId) {
        final String[] ids = {outId, inId};
        final Double[] res = new Double[2];
        List<Thread> threads = new ArrayList<Thread>();
        for (int i = 0; i < 2; i++) {
            final int k = i;
            String id = ids[k];
            if (id == null || !ISRC.matcher(id).matches()) continue;
            res[k] = cached(id);
            if (res[k] != null || recentlyMissed(id)) continue;
            Thread t = new Thread(new Runnable() {
                @Override public void run() { res[k] = lookup(ids[k]); }
            }, "AutomixBackup-bpm");
            t.setDaemon(true);
            t.start();
            threads.add(t);
        }
        long deadline = System.currentTimeMillis() + WAIT_MS;
        for (Thread t : threads) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            try { t.join(left); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
        }
        return new Double[]{res[0], res[1]};
    }

    // ===================== Reglas =====================
    static boolean validBpm(Double b) {
        return b != null && b.doubleValue() >= BPM_MIN && b.doubleValue() <= BPM_MAX;
    }

    /** Pliega el BPM de la entrante por octavas (x2, /2) para que quede lo mas cerca posible del de la que sale. */
    static double alignOctave(double out, double in) {
        double best = in;
        double bestDist = Math.abs(out / in - 1.0);
        double[] cands = {in * 2.0, in / 2.0};
        for (double c : cands) {
            if (c < BPM_MIN || c > BPM_MAX) continue;
            double d = Math.abs(out / c - 1.0);
            if (d < bestDist) { bestDist = d; best = c; }
        }
        return best;
    }

    /** Barrido final del filtro segun la distancia de tempo: casi igual = NEAR, lejos = FAR, en medio interpola (escala log). */
    static double sweepEnd(double dist) {
        double t = Math.max(0.0, Math.min(1.0, dist / SWEEP_FAR_DIST));
        return Math.exp(Math.log(SWEEP_END_NEAR_HZ) * (1.0 - t) + Math.log(SWEEP_END_FAR_HZ) * t);
    }

    /** Resultado de decidir; separado del JSON para poder probarlo. */
    static final class Decision {
        String style;
        String tier = "local";
        double fade;
        double rate = 1.0;
        double start;   // transitionStart (s absolutos en la que sale); 0 = el de Eclipse
        double cue;     // incomingCueTime (s); 0 = desde el principio
        double sweepEndHz;
        Double outBpm;
        Double inBpm;
        String reason;
        String why;     // por que no hubo beatmatch (solo para los avisos)
    }

    /**
     * Coloca el inicio del fundido en un downbeat de la que sale, entre (fin - fundido - MAX_EARLY_START) y
     * (fin - fundido), lo mas cerca posible de donde empieza su final. Si ademas la entrante tiene downbeats,
     * pide un cue para que su primer downbeat caiga al empezar. Devuelve true si la fase quedo alineada.
     */
    static boolean placeStart(Decision d, CardInfo oi, CardInfo ii) {
        if (oi == null || oi.duration < 45.0 || oi.duration > 3600.0) return false;
        double def = oi.duration - d.fade;
        double lo = def - MAX_EARLY_START;
        if (lo < 1.0) return false;
        double target = def;
        if (oi.outro > 0 && oi.outro < oi.duration) target = Math.min(def, Math.max(lo, oi.outro));
        boolean snapped = false;
        if (oi.hasDownbeats()) {
            double best = -1, bestDist = Double.MAX_VALUE;
            for (double db : oi.downbeats) {
                if (db < lo - 0.01 || db > def + 0.01) continue;
                double dist = Math.abs(db - target);
                if (dist < bestDist) { bestDist = dist; best = db; }
            }
            if (best > 0) { target = best; snapped = true; }
        }
        if (snapped || target < def - 0.5) d.start = target;
        if (!snapped || ii == null || !ii.hasDownbeats()) return false;
        double f = ii.firstDownbeat;
        if (f > MAX_CUE) return false;
        if (f > 0.05) d.cue = f;
        return true;
    }

    static Decision decide(Double outBpm, Double inBpm, double requestedFade) {
        return decide(outBpm, inBpm, requestedFade, null, null);
    }

    static Decision decide(Double outBpm, Double inBpm, double requestedFade, CardInfo oi, CardInfo ii) {
        Decision d = new Decision();
        double fade = requestedFade >= MIN_FADE_SECONDS ? requestedFade : MIN_FADE_SECONDS;
        if (fade > MAX_FADE_SECONDS) fade = MAX_FADE_SECONDS;
        d.fade = fade;
        if (validBpm(outBpm) && validBpm(inBpm)) {
            double o = outBpm.doubleValue();
            double in = alignOctave(o, inBpm.doubleValue());
            double dist = Math.abs(o / in - 1.0);
            d.outBpm = outBpm;
            d.inBpm = Double.valueOf(in);
            // Fundido en compases de 4 tiempos (a lo sumo el que pidio el usuario).
            double bar = 4.0 * 60.0 / o;
            double bars = Math.floor(fade / bar);
            if (bars >= 1.0 && bars * bar >= MIN_BAR_FADE_SECONDS) d.fade = bars * bar;
            d.sweepEndHz = sweepEnd(dist);
            if (dist <= CLOSE_TEMPO) { d.style = "dj_blend"; d.reason = "backup-tempo-close"; }
            else { d.style = "dj_filter"; d.reason = "backup-tempo-far"; }

            boolean aligned = false;
            if (SMART_START) {
                try { aligned = placeStart(d, oi, ii); } catch (Throwable t) { d.start = 0; d.cue = 0; aligned = false; }
            }
            // Beatmatch: solo con el BPM de la ficha de las DOS (la rejilla de downbeats es de la ficha) y fase alineada.
            if (!optBeatmatch) d.why = "beatmatch apagado";
            else if (oi == null || ii == null) d.why = oi == null && ii == null ? "sin ficha de las 2" : (oi == null ? "sin ficha: sale" : "sin ficha: entra");
            else if (!oi.hasBpm() || !ii.hasBpm()) d.why = "ficha sin BPM";
            else if (!oi.rhythmSure() || !ii.rhythmSure())
                d.why = String.format(Locale.ROOT, "ritmo poco seguro %.2f/%.2f", oi.conf, ii.conf);
            else if (!aligned && BEATMATCH_NEEDS_PHASE) d.why = "sin compas alineado";
            if (optBeatmatch && oi != null && ii != null && oi.hasBpm() && ii.hasBpm()
                    && oi.rhythmSure() && ii.rhythmSure()
                    && (aligned || !BEATMATCH_NEEDS_PHASE)) {
                double ob = oi.bpm;
                double ib = alignOctave(ob, ii.bpm);
                double bdist = Math.abs(ob / ib - 1.0);
                if (bdist <= BEATMATCH_MAX_DIST) {
                    d.tier = "beatmatched";
                    d.rate = ob / ib;
                    d.reason = "backup-beatmatch";
                    d.why = null;
                } else {
                    d.why = String.format(Locale.ROOT, "tempo lejos %.1f%%", bdist * 100.0);
                }
            }
            if (aligned && !"backup-beatmatch".equals(d.reason)) d.reason = d.reason + "-aligned";
        } else {
            d.style = "dj_filter";
            d.sweepEndHz = SWEEP_END_UNKNOWN_HZ;
            d.reason = "backup-no-bpm";
            d.why = (outBpm == null && inBpm == null) ? "sin BPM de las 2" : (outBpm == null ? "sin BPM: sale" : (inBpm == null ? "sin BPM: entra" : "BPM fuera de rango"));
        }
        return d;
    }

    private static String num(double v) {
        return String.format(Locale.ROOT, "%.4f", v);
    }

    static String toJson(Decision d) {
        StringBuilder b = new StringBuilder(512);
        b.append("{\"status\":\"ready\",\"plan\":{");
        b.append("\"shouldStart\":true,\"markerVisible\":true,\"blocked\":false,");
        b.append("\"reason\":\"").append(d.reason).append("\",");
        b.append("\"tier\":\"").append(d.tier).append("\",");
        b.append("\"transitionStyle\":\"").append(d.style).append("\",");
        b.append("\"transitionStart\":").append(num(d.start)).append(",\"transitionEnd\":0,");
        b.append("\"fadeSeconds\":").append(num(d.fade)).append(',');
        b.append("\"incomingCueTime\":").append(num(d.cue)).append(",\"incomingHandoffTime\":0,");
        b.append("\"incomingPlaybackRate\":").append(num(d.rate)).append(',');
        b.append("\"handoffFraction\":0.5,");
        b.append("\"bassSwap\":").append(BASS_SWAP ? "true" : "false").append(',');
        b.append("\"bassSwapFraction\":").append(num(BASS_SWAP_FRACTION)).append(',');
        b.append("\"filterSweep\":{\"outgoing\":\"lowpass\",\"incoming\":\"highpass\",\"startHz\":")
                .append(num(SWEEP_START_HZ)).append(",\"endHz\":").append(num(d.sweepEndHz)).append("},");
        b.append("\"vocalOverlap\":0");
        if (d.outBpm != null) b.append(",\"outgoingBpm\":").append(num(d.outBpm.doubleValue()));
        if (d.inBpm != null) b.append(",\"incomingBpm\":").append(num(d.inBpm.doubleValue()));
        b.append(",\"policyReasons\":[\"").append(d.reason).append("\"]");
        b.append("}}");
        return b.toString();
    }

    /** Plan local completo para dos ISRC ya normalizados y el fundido (segundos). Nunca lanza ni devuelve null. */
    static String plan(String outId, String inId, double fadeSeconds) {
        return plan(outId, inId, fadeSeconds, "LOCAL");
    }

    static String plan(String outId, String inId, double fadeSeconds, String origin) {
        Double[] b = {null, null};
        try {
            b = bpms(outId, inId);
        } catch (Throwable ignored) {}
        Decision d;
        try {
            d = decide(b[0], b[1], fadeSeconds, infoFor(outId), infoFor(inId));
        } catch (Throwable t) {
            d = decide(null, null, fadeSeconds);
        }
        dbgPlan(origin, outId, inId, d);
        return toJson(d);
    }

    // ===================== Ganchos de wf0 =====================
    /**
     * Gancho 1 (inicio de wf0.invokeSuspend): plan local si alguna de las dos canciones tiene ISRC inventado (el
     * servidor no la conoce) o si la opcion "Plan local primero" esta activa. Antes pide a Eclipse la ficha local de
     * las que falten (estado "needs"). En otro caso devuelve null y Eclipse pregunta al servidor como siempre.
     */
    public static String localFirst(String outIsrc, String inIsrc, int fadeSeconds) {
        try {
            boolean fake = isFake(outIsrc) || isFake(inIsrc);
            if (!optLocalOnly && !optLocalFirst && !fake) {
                dbg("SERVIDOR\n(plan de Eclipse)");
                return null;
            }
            String n = needsJson(outIsrc, inIsrc);
            if (n != null) return n;
            return plan(outIsrc, inIsrc, fadeSeconds, optLocalOnly ? "SOLO-LOCAL" : (fake ? "SIN-ISRC" : "LOCAL"));
        } catch (Throwable ignored) {
            // Solo local: nunca se pasa al servidor; plan con valores fijos.
            if (optLocalOnly) {
                try { return toJson(decide(null, null, fadeSeconds)); } catch (Throwable ignored2) {}
            }
            return null;
        }
    }

    private static Object field(Object o, String name) {
        try {
            Field f = o.getClass().getDeclaredField(name);
            f.setAccessible(true);
            return f.get(o);
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Gancho 2 (los 3 retornos null de wf0.invokeSuspend: sin cliente HTTP, error HTTP, excepcion): recibe el propio
     * objeto wf0 (r = ISRC que sale, s = ISRC que entra, t = fundido) y devuelve el plan local; null si no puede.
     */
    public static String fallback(Object wf0) {
        try {
            Object o = field(wf0, "r");
            Object i = field(wf0, "s");
            Object t = field(wf0, "t");
            if (!(o instanceof String) || !(i instanceof String) || !(t instanceof Double)) return null;
            double fade = Math.round(((Double) t).doubleValue());
            if (fade < 1.0) fade = 1.0;
            if (fade > 12.0) fade = 12.0;
            return plan(normalize((String) o), normalize((String) i), fade, "RESPALDO");
        } catch (Throwable ignored) {
            return null;
        }
    }
}
