package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR en el telefono). Lo usa el parche "Letras: YouLyPlus como Mochy".
 *
 * Eclipse pide a YouLyPlus con un POST que solo lleva titulo y artista. Mochy Music pide con un GET que ademas lleva
 * la duracion (y el artista con coma). El usuario comprobo en su navegador (29-oct-2026) que "Te Estoy Correteando"
 * (LATIN MAFIA, Fred again..) SI devuelve letra por silabas con
 *   https://lyricsplus.binimum.org/v2/lyrics/get?title=Te+Estoy+Correteando&artist=LATIN+MAFIA,+Fred+again..&duration=194
 * mientras que con el pedido de Eclipse no sale. Aqui se hace ese pedido (GET: title, artist, duration).
 *
 * fetch() devuelve un objeto pv4 (el resultado de letras de Eclipse, con fuente LYRICS_PLUS) o null. Con null, el
 * smali sigue con el pedido original de Eclipse (ov4.e), asi que nunca queda peor que antes. Para armar el pv4 se
 * usan por reflexion las clases de Eclipse 0.6.47: ov4.l(JSONArray) (lector por palabra), ov4.k(String) (lector LRC),
 * jv4.LYRICS_PLUS y el constructor publico de pv4 (List, String, jv4, Float, boolean, String).
 */
public final class LyricsPlusMochy {
    private LyricsPlusMochy() {}

    private static final String TAG = "LyricsPlusMochy";

    /** Servidor que responde hoy (los otros espejos de Eclipse y de Mochy estan caidos). Cambia solo en las pruebas. */
    static String baseUrl = "https://lyricsplus.binimum.org";

    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 9000;

    private static volatile boolean broken = false;

    /** Resultado de un pedido: cuerpo de la respuesta (o null), codigo HTTP (0 = no hubo respuesta), error y tiempo. */
    private static final class Reply {
        volatile String body;
        volatile int code;
        volatile String err;
        volatile String errBody;
        volatile String retryAfter;
        volatile long ms;
        volatile boolean done;
    }

    /** Un intento: artista + duracion (0 = sin duracion). */
    private static final class Attempt {
        final String label;
        final String artist;
        final int dur;
        final Reply reply = new Reply();
        Attempt(String label, String artist, int dur) {
            this.label = label;
            this.artist = artist;
            this.dur = dur;
        }
    }

    private static final int TOTAL_WAIT_MS = 15000;

    // v0.20.124: pedidos de uno en uno, separados, y pausa tras un 429
    private static final long MIN_GAP_MS = 350L;
    private static final long DEFAULT_COOLDOWN_MS = 4000L;
    private static final long MAX_COOLDOWN_MS = 15000L;
    private static final long MAX_WAIT_IN_FETCH_MS = 6000L;

    private static final Object gate = new Object();
    private static long nextAllowed = 0L;
    private static volatile long blockedUntil = 0L;
    private static final ThreadLocal<Boolean> SKIP = new ThreadLocal<Boolean>();

    /** Milisegundos que faltan para que termine la pausa por 429 (0 = no hay pausa). */
    public static long cooldownLeft() {
        long d = blockedUntil - System.currentTimeMillis();
        return d > 0 ? d : 0L;
    }

    /**
     * El parche lo llama justo despues de fetch() cuando devolvio null: true = hubo 429 (o pausa activa) y NO hay que
     * dejar que Eclipse haga su pedido original (mandaria hasta 3 pedidos mas al mismo servidor). Se lee una sola vez.
     */
    public static boolean skipOriginal() {
        Boolean b = SKIP.get();
        SKIP.remove();
        return b != null && b.booleanValue();
    }

    private static void startCooldown(String retryAfter) {
        long ms = DEFAULT_COOLDOWN_MS;
        try {
            if (retryAfter != null) {
                long sec = Long.parseLong(retryAfter.trim());
                if (sec >= 0) ms = sec * 1000L;
            }
        } catch (Throwable ignored) { }
        if (ms > MAX_COOLDOWN_MS) ms = MAX_COOLDOWN_MS;
        long until = System.currentTimeMillis() + ms;
        synchronized (gate) {
            if (until > blockedUntil) blockedUntil = until;
            if (blockedUntil > nextAllowed) nextAllowed = blockedUntil;
        }
    }

    /** Reserva un turno global: separa los pedidos MIN_GAP_MS entre si (de todas las canciones) y respeta la pausa. */
    private static void awaitSlot() throws InterruptedException {
        long wait;
        synchronized (gate) {
            long now = System.currentTimeMillis();
            long slot = Math.max(now, nextAllowed);
            if (blockedUntil > slot) slot = blockedUntil;
            nextAllowed = slot + MIN_GAP_MS;
            wait = slot - now;
        }
        if (wait > 0) Thread.sleep(wait);
    }

    public static Object fetch(String title, String artist, int durationS) {
        try { toastNow("LyricsPlus: pidiendo letra\n" + title + " - " + artist + " (" + durationS + " s)"); } catch (Throwable ignored) { }
        if (broken) {
            report("LyricsPlus v0.20.124\nRESULTADO: desactivado por un error anterior (reinicia Eclipse)\n");
            LyricsDiag.toast("LyricsPlus: desactivado por un error anterior (reinicia Eclipse)");
            return null;
        }
        StringBuilder rep = new StringBuilder();
        Object result = null;
        try {
            String t = title == null ? "" : title.trim();
            String a = artist == null ? "" : artist.trim();
            if (t.length() == 0 || a.length() == 0) {
                report("LyricsPlus v0.20.124\nRESULTADO: titulo o artista vacio (titulo=" + title + ", artista=" + artist + ")\n");
                LyricsDiag.toast("LyricsPlus: titulo o artista vacio (" + title + " / " + artist + ")");
                return null;
            }

            rep.append("LyricsPlus v0.20.124\n");
            rep.append("titulo: ").append(t).append('\n');
            rep.append("artista: ").append(a).append('\n');
            rep.append("duracion: ").append(durationS).append(" s\n");

            // Mochy une los artistas con coma. v0.20.124: las formas se prueban DE UNA EN UNA (en la v0.20.123 salian 4-5
            // pedidos a la vez y el servidor contestaba HTTP 429). Se para en cuanto una trae letra o llega un 429.
            String comma = a.replace(" & ", ", ");
            List<Attempt> list = new ArrayList<Attempt>();
            if (durationS > 0) list.add(new Attempt("coma+" + durationS, comma, durationS));
            list.add(new Attempt("coma sin duracion", comma, 0));
            if (durationS > 1) list.add(new Attempt("coma+" + (durationS - 1), comma, durationS - 1));
            if (durationS > 0) list.add(new Attempt("coma+" + (durationS + 1), comma, durationS + 1));
            if (!comma.equals(a)) list.add(new Attempt("original+" + durationS, a, durationS));

            SKIP.remove();
            Attempt winner = null;
            boolean blocked = false;
            if (cooldownLeft() > MAX_WAIT_IN_FETCH_MS) {
                // pausa larga activa: no se pide nada; el reintento de la 122 espera y vuelve a llamar
                blocked = true;
                rep.append("pausa por 429 activa (faltan ").append(cooldownLeft()).append(" ms): no se pidio nada\n");
            } else {
                long deadline = System.currentTimeMillis() + TOTAL_WAIT_MS;
                for (Attempt at : list) {
                    if (System.currentTimeMillis() > deadline) break;
                    get(t, at.artist, at.dur, at.reply);
                    if (at.reply.body != null) {
                        winner = at;
                        break;
                    }
                    if (at.reply.code == 429) {
                        blocked = true;
                        startCooldown(at.reply.retryAfter);
                        break;
                    }
                }
            }
            if (blocked && winner == null) SKIP.set(Boolean.TRUE);

            int n = 1;
            for (Attempt at : list) {
                Reply r = at.reply;
                rep.append(n++).append(") ").append(at.label).append(": ");
                if (!r.done) rep.append(winner != null ? "no hizo falta" : (blocked ? "no se probo (429)" : "no se probo"));
                else if (r.body != null) rep.append("OK ").append(r.body.length()).append(" bytes");
                else if (r.code == 404) rep.append("404 no la tiene");
                else if (r.code > 0) rep.append("HTTP ").append(r.code).append(r.retryAfter != null ? " (Retry-After " + r.retryAfter + ")" : "");
                else rep.append("error ").append(r.err);
                if (r.done) rep.append(" (").append(r.ms).append(" ms)");
                rep.append('\n');
            }
            if (winner == null) {
                Reply first = list.get(0).reply;
                if (first.done && first.errBody != null && first.errBody.length() > 0) {
                    rep.append("servidor: ").append(first.errBody).append('\n');
                }
                rep.append("RESULTADO: sin letra\n");
                java.util.LinkedHashSet<String> why = new java.util.LinkedHashSet<String>();
                for (Attempt at : list) {
                    Reply r = at.reply;
                    if (!r.done) continue;
                    else if (r.body != null) why.add("respuesta sin letra usable");
                    else if (r.code == 404) why.add("404 no la tiene");
                    else if (r.code > 0) why.add("HTTP " + r.code + (r.retryAfter != null ? " (espera " + r.retryAfter + " s)" : ""));
                    else {
                        String e = r.err == null ? "?" : r.err;
                        why.add("error " + (e.length() > 50 ? e.substring(0, 50) : e));
                    }
                }
                if (why.isEmpty()) why.add(blocked ? "en pausa por HTTP 429" : "sin respuesta a tiempo");
                StringBuilder w = new StringBuilder();
                for (String x : why) { if (w.length() > 0) w.append(" / "); w.append(x); }
                LyricsDiag.toast("LyricsPlus sin letra: " + w + "\n" + t);
            } else {
                String body = winner.reply.body;
                result = build(body);
                if (result != null) {
                    rep.append("RESULTADO: letra OK (").append(winner.label).append(")\n");
                } else {
                    JSONObject o = new JSONObject(body);
                    LyricsDiag.toast("LyricsPlus: respuesta sin letra usable\n" + t);
                    rep.append("RESULTADO: respuesta sin letra usable (lyrics=")
                        .append(o.has("lyrics") ? "si" : "no").append(", syncedLyrics=")
                        .append(o.has("syncedLyrics") ? "si" : "no").append(")\n");
                }
            }
        } catch (Throwable e) {
            // Si fallo la reflexion (otra version de Eclipse), no se vuelve a intentar
            if (e instanceof ReflectiveOperationException || e instanceof LinkageError) broken = true;
            rep.append("FALLO: ").append(e).append('\n');
            LyricsDiag.toast("LyricsPlus FALLO: " + String.valueOf(e));
            try { Log.w(TAG, "fallo: " + e); } catch (Throwable ignored) { }
            result = null;
        }
        report(rep.toString());
        return result;
    }

    private static void get(String title, String artist, int durationS, Reply reply) {
        long t0 = System.currentTimeMillis();
        HttpURLConnection c = null;
        try {
            awaitSlot();
            t0 = System.currentTimeMillis();
            StringBuilder u = new StringBuilder(baseUrl);
            u.append("/v2/lyrics/get?title=").append(URLEncoder.encode(title, "UTF-8"));
            u.append("&artist=").append(URLEncoder.encode(artist, "UTF-8"));
            if (durationS > 0) u.append("&duration=").append(durationS);
            c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setRequestProperty("User-Agent", "EclipseAndroid/1.0");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            reply.code = code;
            if (code < 200 || code >= 300) {
                try { reply.retryAfter = c.getHeaderField("Retry-After"); } catch (Throwable ignored) { }
                InputStream es = c.getErrorStream();
                if (es != null) {
                    String eb = readAll(es);
                    eb = eb.replace('\n', ' ');
                    reply.errBody = eb.length() > 220 ? eb.substring(0, 220) : eb;
                }
                return;
            }
            reply.body = readAll(c.getInputStream());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            reply.err = "interrumpido";
        } catch (Throwable e) {
            reply.err = String.valueOf(e);
        } finally {
            reply.ms = System.currentTimeMillis() - t0;
            reply.done = true;
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    /** v0.20.91: ya sin avisos en pantalla; solo se deja una linea en el log. */
    private static void toastNow(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    private static void report(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    /** Arma el pv4 con la letra de la respuesta: por palabra si viene "lyrics"; si no, "syncedLyrics" como LRC. */
    private static Object build(String body) throws Exception {
        JSONObject resp = new JSONObject(body);

        Class<?> ov4 = Class.forName("ov4");
        List<?> list = null;

        // 1) letra con tiempos por silaba/palabra (campo "lyrics"), como la lee Mochy
        JSONObject copy = new JSONObject(body);
        copy.remove("syncedLyrics");
        JSONArray words = LyricsPlusWords.convert(copy);
        if (words != null) {
            Method l = ov4.getMethod("l", JSONArray.class);
            Object r = l.invoke(null, words);
            if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
        }

        // 2) letra sincronizada por linea
        if (list == null) {
            Object s = resp.opt("syncedLyrics");
            if (s instanceof String) {
                String lrc = ((String) s).trim();
                if (lrc.length() > 0 && !"null".equals(lrc)) {
                    Method k = ov4.getMethod("k", String.class);
                    Object r = k.invoke(null, lrc);
                    if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
                }
            }
        }
        if (list == null) return null;

        Class<?> jv4 = Class.forName("jv4");
        Object plus = null;
        for (Object c : jv4.getEnumConstants()) {
            if ("LYRICS_PLUS".equals(((Enum<?>) c).name())) plus = c;
        }
        if (plus == null) return null;
        Class<?> pv4 = Class.forName("pv4");
        Constructor<?> ctor = pv4.getConstructor(List.class, String.class, jv4, Float.class, boolean.class, String.class);
        return ctor.newInstance(list, null, plus, null, Boolean.FALSE, null);
    }
}
