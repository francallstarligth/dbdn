package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR en el telefono). Lo usa el parche "Letras: YouLyPlus como Mochy".
 *
 * Eclipse pide a YouLyPlus con un POST que solo lleva titulo y artista. Mochy Music pide con un GET que ademas lleva
 * la duracion (y el artista con coma). El usuario comprobo en su navegador (29-oct-2026) que "Te Estoy Correteando"
 * (LATIN MAFIA, Fred again..) SI devuelve letra por silabas con
 *   https://lyricsplus.binimum.org/v2/lyrics/get?title=Te+Estoy+Correteando&artist=LATIN+MAFIA,+Fred+again..&duration=194
 * mientras que con el pedido de Eclipse no sale. Aqui se hace ese pedido (GET: title, artist, duration).
 *
 * fetch() devuelve un objeto pv4 (el resultado de letras de Eclipse, con fuente LYRICS_PLUS) o null. Con null, el
 * smali sigue con el pedido original de Eclipse (ov4.e), asi que nunca queda peor que antes. Para armar el pv4 se
 * usan por reflexion las clases de Eclipse 0.6.55: s65.m(JSONArray) (lector por palabra), s65.l(String) (lector LRC),
 * n65.LYRICS_PLUS y el constructor publico de t65 (List, String, n65, Float, boolean, String).
 */
public final class LyricsPlusMochy {
    private LyricsPlusMochy() {}

    private static final String TAG = "LyricsPlusMochy";

    /** Servidor que responde hoy (los otros espejos de Eclipse y de Mochy estan caidos). Cambia solo en las pruebas. */
    static String baseUrl = "https://lyricsplus.binimum.org";

    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 9000;

    private static volatile boolean broken = false;

    /** Resultado de un pedido: cuerpo de la respuesta (o null), codigo HTTP (0 = no hubo respuesta), error y tiempo. */
    private static final class Reply {
        volatile String body;
        volatile int code;
        volatile String err;
        volatile String errBody;
        volatile long ms;
        volatile boolean done;
    }

    /** Un intento: artista + duracion (0 = sin duracion). */
    private static final class Attempt {
        final String label;
        final String artist;
        final int dur;
        Attempt(String label, String artist, int dur) {
            this.label = label;
            this.artist = artist;
            this.dur = dur;
        }
    }

    /** Despues de este tiempo no se empieza otra variante (un pedido ya empezado puede terminar despues). */
    private static final int TOTAL_WAIT_MS = 13000;
    /** Espera antes de reintentar UNA vez cuando el servidor contesta 429 (demasiados pedidos). */
    private static final int RETRY_429_MS = 1500;

    /**
     * v0.20.149: los pedidos ya NO van en paralelo (5 a la vez al mismo servidor eran la causa probable del HTTP 429).
     * Se prueban las variantes UNA POR UNA, en el mismo orden de siempre (coma+duracion primero, que es la que sirve en
     * la mayoria); solo se pasa a la siguiente si la anterior dio 404 o una respuesta sin letra usable. Con 429 se espera
     * 1,5 s y se reintenta esa misma variante una vez; si vuelve el 429, o hay error de red/5xx, se devuelve null y
     * Eclipse sigue con los demas proveedores. Sin avisos en pantalla.
     */
    public static Object fetch(String title, String artist, int durationS) {
        if (broken) return null;
        Object result = null;
        try {
            String t = title == null ? "" : title.trim();
            String a = artist == null ? "" : artist.trim();
            if (t.length() == 0 || a.length() == 0) return null;

            // Mochy une los artistas con coma.
            String comma = a.replace(" & ", ", ");
            List<Attempt> list = new ArrayList<Attempt>();
            if (durationS > 0) list.add(new Attempt("coma+" + durationS, comma, durationS));
            list.add(new Attempt("coma sin duracion", comma, 0));
            if (durationS > 1) list.add(new Attempt("coma+" + (durationS - 1), comma, durationS - 1));
            if (durationS > 0) list.add(new Attempt("coma+" + (durationS + 1), comma, durationS + 1));

            long deadline = System.currentTimeMillis() + TOTAL_WAIT_MS;
            for (Attempt at : list) {
                if (System.currentTimeMillis() >= deadline) break;
                Reply r = new Reply();
                get(t, at.artist, at.dur, r);
                if (r.code == 429) {
                    try { Thread.sleep(RETRY_429_MS); } catch (InterruptedException e) { break; }
                    r = new Reply();
                    get(t, at.artist, at.dur, r);
                    if (r.code == 429) { Log.i(TAG, "429 dos veces, se deja a los demas proveedores"); break; }
                }
                if (r.body != null) {
                    result = build(r.body);
                    if (result != null) { Log.i(TAG, "letra OK (" + at.label + ")"); break; }
                    continue; // respuesta sin letra usable: probar la siguiente variante
                }
                if (r.code == 404 || r.code == 400) continue; // no la tiene con esta forma: siguiente variante
                break; // error de red, tiempo agotado o 5xx: no insistir
            }
        } catch (Throwable e) {
            // Si fallo la reflexion (otra version de Eclipse), no se vuelve a intentar
            if (e instanceof ReflectiveOperationException || e instanceof LinkageError) broken = true;
            try { Log.w(TAG, "fallo: " + e); } catch (Throwable ignored) { }
            result = null;
        }
        return result;
    }

    private static void get(String title, String artist, int durationS, Reply reply) {
        long t0 = System.currentTimeMillis();
        HttpURLConnection c = null;
        try {
            StringBuilder u = new StringBuilder(baseUrl);
            u.append("/v2/lyrics/get?title=").append(URLEncoder.encode(title, "UTF-8"));
            u.append("&artist=").append(URLEncoder.encode(artist, "UTF-8"));
            if (durationS > 0) u.append("&duration=").append(durationS);
            c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setRequestProperty("User-Agent", "EclipseAndroid/1.0");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            reply.code = code;
            if (code < 200 || code >= 300) {
                InputStream es = c.getErrorStream();
                if (es != null) {
                    String eb = readAll(es);
                    eb = eb.replace('\n', ' ');
                    reply.errBody = eb.length() > 220 ? eb.substring(0, 220) : eb;
                }
                return;
            }
            reply.body = readAll(c.getInputStream());
        } catch (Throwable e) {
            reply.err = String.valueOf(e);
        } finally {
            reply.ms = System.currentTimeMillis() - t0;
            reply.done = true;
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    /** v0.20.91: ya sin avisos en pantalla; solo se deja una linea en el log. */
    private static void toastNow(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    private static void report(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    /** Arma el pv4 con la letra de la respuesta: por palabra si viene "lyrics"; si no, "syncedLyrics" como LRC. */
    private static Object build(String body) throws Exception {
        JSONObject resp = new JSONObject(body);

        Class<?> ov4 = Class.forName("hn5");
        List<?> list = null;

        // 1) letra con tiempos por silaba/palabra (campo "lyrics"), como la lee Mochy
        JSONObject copy = new JSONObject(body);
        copy.remove("syncedLyrics");
        JSONArray words = LyricsPlusWords.convert(copy);
        if (words != null) {
            Method l = ov4.getMethod("m", JSONArray.class);
            Object r = l.invoke(null, words);
            if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
        }

        // 2) letra sincronizada por linea
        if (list == null) {
            Object s = resp.opt("syncedLyrics");
            if (s instanceof String) {
                String lrc = ((String) s).trim();
                if (lrc.length() > 0 && !"null".equals(lrc)) {
                    Method k = ov4.getMethod("l", String.class);
                    Object r = k.invoke(null, lrc);
                    if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
                }
            }
        }
        if (list == null) return null;

        Class<?> jv4 = Class.forName("cn5");
        Object plus = null;
        for (Object c : jv4.getEnumConstants()) {
            if ("LYRICS_PLUS".equals(((Enum<?>) c).name())) plus = c;
        }
        if (plus == null) return null;
        Class<?> pv4 = Class.forName("in5");
        Constructor<?> ctor = pv4.getConstructor(List.class, String.class, jv4, Float.class, boolean.class, String.class);
        return ctor.newInstance(list, null, plus, null, Boolean.FALSE, null);
    }
}
