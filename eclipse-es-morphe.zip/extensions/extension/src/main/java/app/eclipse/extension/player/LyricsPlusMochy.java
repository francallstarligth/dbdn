package app.eclipse.extension.player;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.List;

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR en el telefono). Lo usa el parche "Letras: YouLyPlus como Mochy".
 *
 * Eclipse pide a YouLyPlus con un POST que solo lleva titulo y artista. Mochy Music pide con un GET que ademas lleva
 * la duracion (y el artista con coma). El usuario comprobo en su navegador (29-oct-2026) que "Te Estoy Correteando"
 * (LATIN MAFIA, Fred again..) SI devuelve letra por silabas con
 *   https://lyricsplus.binimum.org/v2/lyrics/get?title=Te+Estoy+Correteando&artist=LATIN+MAFIA,+Fred+again..&duration=194
 * mientras que con el pedido de Eclipse no sale. Aqui se hace ese pedido (GET: title, artist, duration).
 *
 * fetch() devuelve un objeto pv4 (el resultado de letras de Eclipse, con fuente LYRICS_PLUS) o null. Con null, el
 * smali sigue con el pedido original de Eclipse (ov4.e), asi que nunca queda peor que antes. Para armar el pv4 se
 * usan por reflexion las clases de Eclipse 0.6.47: ov4.l(JSONArray) (lector por palabra), ov4.k(String) (lector LRC),
 * jv4.LYRICS_PLUS y el constructor publico de pv4 (List, String, jv4, Float, boolean, String).
 */
public final class LyricsPlusMochy {
    private LyricsPlusMochy() {}

    private static final String TAG = "LyricsPlusMochy";

    /** Servidor que responde hoy (los otros espejos de Eclipse y de Mochy estan caidos). Cambia solo en las pruebas. */
    static String baseUrl = "https://lyricsplus.binimum.org";

    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 9000;

    private static volatile boolean broken = false;

    /** Resultado de un pedido: cuerpo de la respuesta, o null; y si vale la pena reintentar (404 = no la encontro). */
    private static final class Reply {
        String body;
        boolean notFound;
    }

    public static Object fetch(String title, String artist, int durationS) {
        if (broken) return null;
        try {
            if (title == null || artist == null) return null;
            String t = title.trim();
            String a = artist.trim();
            if (t.length() == 0 || a.length() == 0) return null;

            Reply r = get(t, a, durationS);
            if (r != null && r.body == null && r.notFound && a.contains(" & ")) {
                // Mochy une los artistas con coma: se prueba tambien asi
                r = get(t, a.replace(" & ", ", "), durationS);
            }
            if (r == null || r.body == null) return null;
            return build(r.body);
        } catch (Throwable e) {
            // Si fallo la reflexion (otra version de Eclipse), no se vuelve a intentar
            if (e instanceof ReflectiveOperationException || e instanceof LinkageError) broken = true;
            try { Log.w(TAG, "fallo: " + e); } catch (Throwable ignored) { }
            return null;
        }
    }

    private static Reply get(String title, String artist, int durationS) {
        Reply reply = new Reply();
        HttpURLConnection c = null;
        try {
            StringBuilder u = new StringBuilder(baseUrl);
            u.append("/v2/lyrics/get?title=").append(URLEncoder.encode(title, "UTF-8"));
            u.append("&artist=").append(URLEncoder.encode(artist, "UTF-8"));
            if (durationS > 0) u.append("&duration=").append(durationS);
            c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setRequestProperty("User-Agent", "EclipseAndroid/1.0");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            if (code == 404) {
                reply.notFound = true;
                return reply;
            }
            if (code < 200 || code >= 300) return reply;
            InputStream in = c.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            in.close();
            reply.body = out.toString("UTF-8");
            return reply;
        } catch (Throwable e) {
            return reply;
        } finally {
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    /** Arma el pv4 con la letra de la respuesta: por palabra si viene "lyrics"; si no, "syncedLyrics" como LRC. */
    private static Object build(String body) throws Exception {
        JSONObject resp = new JSONObject(body);

        Class<?> ov4 = Class.forName("ov4");
        List<?> list = null;

        // 1) letra con tiempos por silaba/palabra (campo "lyrics"), como la lee Mochy
        JSONObject copy = new JSONObject(body);
        copy.remove("syncedLyrics");
        JSONArray words = LyricsPlusWords.convert(copy);
        if (words != null) {
            Method l = ov4.getMethod("l", JSONArray.class);
            Object r = l.invoke(null, words);
            if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
        }

        // 2) letra sincronizada por linea
        if (list == null) {
            Object s = resp.opt("syncedLyrics");
            if (s instanceof String) {
                String lrc = ((String) s).trim();
                if (lrc.length() > 0 && !"null".equals(lrc)) {
                    Method k = ov4.getMethod("k", String.class);
                    Object r = k.invoke(null, lrc);
                    if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
                }
            }
        }
        if (list == null) return null;

        Class<?> jv4 = Class.forName("jv4");
        Object plus = null;
        for (Object c : jv4.getEnumConstants()) {
            if ("LYRICS_PLUS".equals(((Enum<?>) c).name())) plus = c;
        }
        if (plus == null) return null;
        Class<?> pv4 = Class.forName("pv4");
        Constructor<?> ctor = pv4.getConstructor(List.class, String.class, jv4, Float.class, boolean.class, String.class);
        return ctor.newInstance(list, null, plus, null, Boolean.FALSE, null);
    }
}
