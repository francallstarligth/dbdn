package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * v0.20.81 (SIN COMPILAR / SIN PROBAR en el telefono). Lo usa el parche "Letras: YouLyPlus como Mochy".
 *
 * Eclipse pide a YouLyPlus con un POST que solo lleva titulo y artista. Mochy Music pide con un GET que ademas lleva
 * la duracion (y el artista con coma). El usuario comprobo en su navegador (29-oct-2026) que "Te Estoy Correteando"
 * (LATIN MAFIA, Fred again..) SI devuelve letra por silabas con
 *   https://lyricsplus.binimum.org/v2/lyrics/get?title=Te+Estoy+Correteando&artist=LATIN+MAFIA,+Fred+again..&duration=194
 * mientras que con el pedido de Eclipse no sale. Aqui se hace ese pedido (GET: title, artist, duration).
 *
 * fetch() devuelve un objeto pv4 (el resultado de letras de Eclipse, con fuente LYRICS_PLUS) o null. Con null, el
 * smali sigue con el pedido original de Eclipse (ov4.e), asi que nunca queda peor que antes. Para armar el pv4 se
 * usan por reflexion las clases de Eclipse 0.6.47: ov4.l(JSONArray) (lector por palabra), ov4.k(String) (lector LRC),
 * jv4.LYRICS_PLUS y el constructor publico de pv4 (List, String, jv4, Float, boolean, String).
 */
public final class LyricsPlusMochy {
    private LyricsPlusMochy() {}

    private static final String TAG = "LyricsPlusMochy";

    /** Servidor que responde hoy (los otros espejos de Eclipse y de Mochy estan caidos). Cambia solo en las pruebas. */
    static String baseUrl = "https://lyricsplus.binimum.org";

    private static final int CONNECT_MS = 3000;
    private static final int READ_MS = 9000;

    private static volatile boolean broken = false;

    /** Resultado de un pedido: cuerpo de la respuesta (o null), codigo HTTP (0 = no hubo respuesta), error y tiempo. */
    private static final class Reply {
        volatile String body;
        volatile int code;
        volatile String err;
        volatile String errBody;
        volatile long ms;
        volatile boolean done;
    }

    /** Un intento: artista + duracion (0 = sin duracion). */
    private static final class Attempt {
        final String label;
        final String artist;
        final int dur;
        final Reply reply = new Reply();
        Attempt(String label, String artist, int dur) {
            this.label = label;
            this.artist = artist;
            this.dur = dur;
        }
    }

    private static final int TOTAL_WAIT_MS = 13000;

    public static Object fetch(String title, String artist, int durationS) {
        try { toastNow("LyricsPlus: pidiendo letra\n" + title + " - " + artist + " (" + durationS + " s)"); } catch (Throwable ignored) { }
        if (broken) {
            report("LyricsPlus v0.20.84\nRESULTADO: desactivado por un error anterior (reinicia Eclipse)\n");
            return null;
        }
        StringBuilder rep = new StringBuilder();
        Object result = null;
        try {
            String t = title == null ? "" : title.trim();
            String a = artist == null ? "" : artist.trim();
            if (t.length() == 0 || a.length() == 0) {
                report("LyricsPlus v0.20.84\nRESULTADO: titulo o artista vacio (titulo=" + title + ", artista=" + artist + ")\n");
                return null;
            }

            rep.append("LyricsPlus v0.20.84\n");
            rep.append("titulo: ").append(t).append('\n');
            rep.append("artista: ").append(a).append('\n');
            rep.append("duracion: ").append(durationS).append(" s\n");

            // Mochy une los artistas con coma. Se prueban varias formas EN PARALELO (mas rapido que una por una).
            String comma = a.replace(" & ", ", ");
            List<Attempt> list = new ArrayList<Attempt>();
            if (durationS > 0) list.add(new Attempt("coma+" + durationS, comma, durationS));
            list.add(new Attempt("coma sin duracion", comma, 0));
            if (durationS > 1) list.add(new Attempt("coma+" + (durationS - 1), comma, durationS - 1));
            if (durationS > 0) list.add(new Attempt("coma+" + (durationS + 1), comma, durationS + 1));
            if (!comma.equals(a)) list.add(new Attempt("original+" + durationS, a, durationS));

            final String ft = t;
            for (final Attempt at : list) {
                Thread th = new Thread(new Runnable() {
                    @Override public void run() {
                        get(ft, at.artist, at.dur, at.reply);
                    }
                });
                th.setDaemon(true);
                th.start();
            }

            // Se espera por orden de prioridad: se usa el primero que trae letra cuando los anteriores ya terminaron
            long deadline = System.currentTimeMillis() + TOTAL_WAIT_MS;
            Attempt winner = null;
            while (System.currentTimeMillis() < deadline) {
                boolean allDone = true;
                boolean decided = false;
                for (Attempt at : list) {
                    if (!at.reply.done) {
                        allDone = false;
                        break; // uno de mayor prioridad sigue pidiendo: esperar
                    }
                    if (at.reply.body != null) {
                        winner = at;
                        decided = true;
                        break;
                    }
                }
                if (decided || allDone) break;
                try { Thread.sleep(40); } catch (InterruptedException e) { break; }
            }

            int n = 1;
            for (Attempt at : list) {
                Reply r = at.reply;
                rep.append(n++).append(") ").append(at.label).append(": ");
                if (!r.done) rep.append(winner != null ? "no hizo falta esperar" : "sin respuesta a tiempo");
                else if (r.body != null) rep.append("OK ").append(r.body.length()).append(" bytes");
                else if (r.code == 404) rep.append("404 no la tiene");
                else if (r.code > 0) rep.append("HTTP ").append(r.code);
                else rep.append("error ").append(r.err);
                if (r.done) rep.append(" (").append(r.ms).append(" ms)");
                rep.append('\n');
            }
            if (winner == null) {
                Reply first = list.get(0).reply;
                if (first.done && first.errBody != null && first.errBody.length() > 0) {
                    rep.append("servidor: ").append(first.errBody).append('\n');
                }
                rep.append("RESULTADO: sin letra\n");
            } else {
                String body = winner.reply.body;
                result = build(body);
                if (result != null) {
                    rep.append("RESULTADO: letra OK (").append(winner.label).append(")\n");
                } else {
                    JSONObject o = new JSONObject(body);
                    rep.append("RESULTADO: respuesta sin letra usable (lyrics=")
                        .append(o.has("lyrics") ? "si" : "no").append(", syncedLyrics=")
                        .append(o.has("syncedLyrics") ? "si" : "no").append(")\n");
                }
            }
        } catch (Throwable e) {
            // Si fallo la reflexion (otra version de Eclipse), no se vuelve a intentar
            if (e instanceof ReflectiveOperationException || e instanceof LinkageError) broken = true;
            rep.append("FALLO: ").append(e).append('\n');
            try { Log.w(TAG, "fallo: " + e); } catch (Throwable ignored) { }
            result = null;
        }
        report(rep.toString());
        return result;
    }

    private static void get(String title, String artist, int durationS, Reply reply) {
        long t0 = System.currentTimeMillis();
        HttpURLConnection c = null;
        try {
            StringBuilder u = new StringBuilder(baseUrl);
            u.append("/v2/lyrics/get?title=").append(URLEncoder.encode(title, "UTF-8"));
            u.append("&artist=").append(URLEncoder.encode(artist, "UTF-8"));
            if (durationS > 0) u.append("&duration=").append(durationS);
            c = (HttpURLConnection) new URL(u.toString()).openConnection();
            c.setRequestMethod("GET");
            c.setConnectTimeout(CONNECT_MS);
            c.setReadTimeout(READ_MS);
            c.setRequestProperty("User-Agent", "EclipseAndroid/1.0");
            c.setRequestProperty("Accept", "application/json");
            int code = c.getResponseCode();
            reply.code = code;
            if (code < 200 || code >= 300) {
                InputStream es = c.getErrorStream();
                if (es != null) {
                    String eb = readAll(es);
                    eb = eb.replace('\n', ' ');
                    reply.errBody = eb.length() > 220 ? eb.substring(0, 220) : eb;
                }
                return;
            }
            reply.body = readAll(c.getInputStream());
        } catch (Throwable e) {
            reply.err = String.valueOf(e);
        } finally {
            reply.ms = System.currentTimeMillis() - t0;
            reply.done = true;
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) { }
            }
        }
    }

    private static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        in.close();
        return out.toString("UTF-8");
    }

    /** v0.20.91: ya sin avisos en pantalla; solo se deja una linea en el log. */
    private static void toastNow(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    private static void report(final String text) {
        try { Log.i(TAG, text); } catch (Throwable ignored) { }
    }

    /** Arma el pv4 con la letra de la respuesta: por palabra si viene "lyrics"; si no, "syncedLyrics" como LRC. */
    private static Object build(String body) throws Exception {
        JSONObject resp = new JSONObject(body);

        Class<?> ov4 = Class.forName("ov4");
        List<?> list = null;

        // 1) letra con tiempos por silaba/palabra (campo "lyrics"), como la lee Mochy
        JSONObject copy = new JSONObject(body);
        copy.remove("syncedLyrics");
        JSONArray words = LyricsPlusWords.convert(copy);
        if (words != null) {
            Method l = ov4.getMethod("l", JSONArray.class);
            Object r = l.invoke(null, words);
            if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
        }

        // 2) letra sincronizada por linea
        if (list == null) {
            Object s = resp.opt("syncedLyrics");
            if (s instanceof String) {
                String lrc = ((String) s).trim();
                if (lrc.length() > 0 && !"null".equals(lrc)) {
                    Method k = ov4.getMethod("k", String.class);
                    Object r = k.invoke(null, lrc);
                    if (r instanceof List && !((List<?>) r).isEmpty()) list = (List<?>) r;
                }
            }
        }
        if (list == null) return null;

        Class<?> jv4 = Class.forName("jv4");
        Object plus = null;
        for (Object c : jv4.getEnumConstants()) {
            if ("LYRICS_PLUS".equals(((Enum<?>) c).name())) plus = c;
        }
        if (plus == null) return null;
        Class<?> pv4 = Class.forName("pv4");
        Constructor<?> ctor = pv4.getConstructor(List.class, String.class, jv4, Float.class, boolean.class, String.class);
        return ctor.newInstance(list, null, plus, null, Boolean.FALSE, null);
    }
}
