package app.eclipse.extension.player;

/**
 * v0.20.77 (SIN COMPILAR / SIN PROBAR en el telefono). Corta palabras en silabas con reglas simples (espanol e ingles).
 * Java puro, sin Android. Lo usa LyricsPop para agrandar la silaba entera donde va el relleno.
 *
 * breaks(palabra, esEspanol): devuelve un arreglo del largo de la palabra; true en la posicion i = "aqui empieza una
 * silaba nueva". La posicion 0 siempre es false. Los signos (comas, ?, !, apostrofes) se quedan pegados a la silaba
 * de al lado; el guion ("Uh-uh-uh") siempre corta: el guion se queda con la silaba de antes.
 * Son reglas, no un diccionario: en espanol aciertan casi siempre; en ingles a veces se equivocan.
 */
final class Syllables {
    private Syllables() {}

    // ---- idioma de la letra ----
    private static final String[] ES = {
        "que", "de", "el", "la", "en", "y", "te", "tu", "mi", "por", "con", "un", "una", "los", "las", "se", "lo", "es",
        "ya", "sin", "del", "al", "si", "yo", "para", "pero", "como", "ti", "van", "dale", "ven", "muy", "mas", "hay",
        "ay", "nada", "todo", "amor", "vida", "corazon", "quiero", "estoy", "eres", "soy", "cuando", "donde"
    };
    private static final String[] EN = {
        "the", "you", "and", "i", "to", "of", "in", "it", "is", "my", "your", "we", "be", "on", "that", "this", "for",
        "with", "all", "are", "but", "not", "just", "like", "when", "what", "know", "baby", "oh", "got", "can", "dont",
        "im", "so", "her", "his", "she", "he", "they", "love", "yeah", "cause", "when", "gonna", "wanna"
    };

    /** true = espanol (o empate), false = ingles. Mira acentos/enies y palabras comunes de toda la letra. */
    static boolean looksSpanish(String text) {
        if (text == null) return true;
        String t = text.toLowerCase();
        for (int i = 0; i < t.length(); i++) {
            char c = t.charAt(i);
            if (c == 'ñ' || c == 'á' || c == 'é' || c == 'í' || c == 'ó' || c == 'ú'
                    || c == 'ü' || c == '¿' || c == '¡') return true;
        }
        int es = 0, en = 0;
        int i = 0, n = t.length();
        while (i < n) {
            while (i < n && !Character.isLetter(t.charAt(i))) i++;
            int j = i;
            StringBuilder sb = new StringBuilder();
            while (j < n && (Character.isLetter(t.charAt(j)) || t.charAt(j) == '\'')) {
                if (t.charAt(j) != '\'') sb.append(t.charAt(j));
                j++;
            }
            if (sb.length() > 0) {
                String w = sb.toString();
                for (String s : ES) if (s.equals(w)) { es++; break; }
                for (String s : EN) if (s.equals(w)) { en++; break; }
            }
            i = Math.max(j, i + 1);
        }
        return es >= en;
    }

    // ---- API ----
    static boolean[] breaks(String w, boolean spanish) {
        int n = w.length();
        boolean[] br = new boolean[n];
        int segStart = 0;
        for (int i = 0; i <= n; i++) {
            if (i == n || isDash(w.charAt(i))) {
                if (i > segStart) segment(w, segStart, i, spanish, br);
                if (i < n && i + 1 < n) br[i + 1] = true;   // despues del guion empieza otra silaba
                segStart = i + 1;
            }
        }
        return br;
    }

    private static boolean isDash(char c) {
        return c == '-' || c == '‐' || c == '‑' || c == '–' || c == '—';
    }

    private static void segment(String w, int from, int to, boolean spanish, boolean[] br) {
        // Solo las letras (minusculas); pos[k] = posicion de la letra k dentro de w.
        int cnt = 0;
        for (int i = from; i < to; i++) if (Character.isLetter(w.charAt(i))) cnt++;
        if (cnt < 2) return;
        char[] L = new char[cnt];
        int[] pos = new int[cnt];
        int k = 0;
        for (int i = from; i < to; i++) {
            char c = w.charAt(i);
            if (Character.isLetter(c)) { L[k] = Character.toLowerCase(c); pos[k] = i; k++; }
        }
        boolean[] v = new boolean[cnt];
        if (spanish) markVowelsEs(L, v); else markVowelsEn(L, v);
        // Nucleos (grupos de vocales).
        int[] ns = new int[cnt], ne = new int[cnt];
        int nn = 0;
        int i = 0;
        while (i < cnt) {
            if (!v[i]) { i++; continue; }
            int j = i;
            while (j + 1 < cnt && v[j + 1] && (spanish ? !hiatus(L[j], L[j + 1]) : true)) j++;
            ns[nn] = i; ne[nn] = j; nn++;
            i = j + 1;
        }
        if (nn < 2) return;
        for (int q = 0; q + 1 < nn; q++) {
            int e = ne[q], s = ns[q + 1];
            int b = spanish ? boundaryEs(L, v, e + 1, s) : boundaryEn(L, e + 1, s);
            if (b > 0 && b < cnt) br[pos[b]] = true;
        }
    }

    // ---- espanol ----
    private static boolean strong(char c) {
        return c == 'a' || c == 'e' || c == 'o' || c == 'á' || c == 'é' || c == 'ó';
    }

    private static boolean accWeak(char c) {
        return c == 'í' || c == 'ú';
    }

    private static boolean hiatus(char a, char b) {
        return (strong(a) && strong(b)) || (accWeak(a) && (strong(b) || accWeak(b))) || (strong(a) && accWeak(b));
    }

    private static boolean isVowelCharEs(char c) {
        switch (c) {
            case 'a': case 'e': case 'i': case 'o': case 'u':
            case 'á': case 'é': case 'í': case 'ó': case 'ú': case 'ü':
                return true;
            default:
                return false;
        }
    }

    private static void markVowelsEs(char[] L, boolean[] v) {
        int n = L.length;
        for (int i = 0; i < n; i++) {
            char c = L[i];
            boolean vow = isVowelCharEs(c);
            if (c == 'y') vow = (i == n - 1);                       // "y" suelta o al final ("hoy", "muy")
            if (c == 'u' && i > 0 && L[i - 1] == 'q') vow = false;  // que, qui
            if (c == 'u' && i > 0 && L[i - 1] == 'g' && i + 1 < n
                    && (L[i + 1] == 'e' || L[i + 1] == 'i' || L[i + 1] == 'é' || L[i + 1] == 'í')) vow = false; // gue, gui
            v[i] = vow;
        }
    }

    /** Unidades de consonante entre dos nucleos: [from, to) -> inicio de cada unidad. Devuelve cuantas. */
    private static int unitsEs(char[] L, int from, int to, int[] starts) {
        int u = 0;
        int i = from;
        while (i < to) {
            starts[u++] = i;
            if (i + 1 < to && ((L[i] == 'c' && L[i + 1] == 'h') || (L[i] == 'l' && L[i + 1] == 'l')
                    || (L[i] == 'r' && L[i + 1] == 'r') || (L[i] == 'q' && L[i + 1] == 'u')
                    || (L[i] == 'g' && L[i + 1] == 'u'))) i += 2;
            else i += 1;
        }
        return u;
    }

    private static boolean liquidClusterEs(char[] L, int[] st, int u, int to) {
        if (u < 2) return false;
        int a = st[u - 2], b = st[u - 1];
        if (b + 1 != to) return false;          // la ultima unidad debe ser una sola letra
        if (a + 1 != b) return false;           // la anterior tambien
        char x = L[a], y = L[b];
        if (y == 'r') return x == 'p' || x == 'b' || x == 'f' || x == 'c' || x == 'g' || x == 't' || x == 'd' || x == 'k';
        if (y == 'l') return x == 'p' || x == 'b' || x == 'f' || x == 'c' || x == 'g' || x == 't' || x == 'k';
        return false;
    }

    private static int boundaryEs(char[] L, boolean[] v, int from, int to) {
        if (from >= to) return to;              // vocales pegadas con hiato: la silaba nueva empieza en la segunda
        int[] st = new int[to - from];
        int u = unitsEs(L, from, to, st);
        if (u == 1) return st[0];
        if (liquidClusterEs(L, st, u, to)) return st[u - 2];
        return st[u - 1];
    }

    // ---- ingles ----
    private static boolean isVowelCharEn(char c) {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }

    private static void markVowelsEn(char[] L, boolean[] v) {
        int n = L.length;
        for (int i = 0; i < n; i++) {
            char c = L[i];
            boolean vow = isVowelCharEn(c);
            if (c == 'y') vow = i > 0;
            v[i] = vow;
        }
        // e final muda ("love", "time"): no cuenta si antes hay otra vocal; "table" (consonante + le) si cuenta.
        if (n >= 3 && L[n - 1] == 'e' && !isVowelCharEn(L[n - 2]) && hasVowelBefore(v, n - 1)) {
            boolean cLe = L[n - 2] == 'l' && n >= 3 && !isVowelCharEn(L[n - 3]) && L[n - 3] != 'l';
            if (!cLe) v[n - 1] = false;
        }
        // "ed" final despues de consonante que no sea t/d ("loved", "called"): la e es muda.
        if (n >= 4 && L[n - 2] == 'e' && L[n - 1] == 'd' && !isVowelCharEn(L[n - 3]) && L[n - 3] != 't'
                && L[n - 3] != 'd' && hasVowelBefore(v, n - 2)) {
            v[n - 2] = false;
        }
    }

    private static boolean hasVowelBefore(boolean[] v, int idx) {
        for (int i = 0; i < idx; i++) if (v[i]) return true;
        return false;
    }

    private static boolean pair(char[] L, int i, char a, char b) {
        return i + 1 < L.length && L[i] == a && L[i + 1] == b;
    }

    private static boolean onsetClusterEn(char x, char y) {
        if (y == 'r') return x == 'b' || x == 'c' || x == 'd' || x == 'f' || x == 'g' || x == 'p' || x == 't';
        if (y == 'l') return x == 'b' || x == 'c' || x == 'd' || x == 'f' || x == 'g' || x == 'p' || x == 't';
        return false;
    }

    private static boolean digraphEn(char a, char b) {
        return (a == 't' && b == 'h') || (a == 's' && b == 'h') || (a == 'c' && b == 'h')
                || (a == 'p' && b == 'h') || (a == 'w' && b == 'h');
    }

    private static int boundaryEn(char[] L, int from, int to) {
        if (from >= to) return to;
        int m = to - from;
        // "ck" / "ng" se quedan con la silaba de antes ("pock-et", "sing-er").
        if (pair(L, from, 'c', 'k') || pair(L, from, 'n', 'g')) {
            return Math.min(from + 2, to);
        }
        if (m == 1) return from;
        char y = L[to - 1], x = L[to - 2];
        if (m >= 2 && digraphEn(x, y)) return to - 2;           // "ba-ther" / "wa-shing"
        if (onsetClusterEn(x, y)) return to - 2;                // "a-bro", "ex-tra"
        return to - 1;                                          // lo demas: se parte antes de la ultima consonante
    }
}
