package app.eclipse.extension.spotify;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Busca el Canvas (video vertical en bucle) de Spotify para una cancion.
 * Uso personal: necesita la cookie sp_dc de la cuenta del usuario.
 *
 * El hook de Eclipse la llama en el HILO PRINCIPAL (Android prohibe la red ahi), asi que la busqueda
 * real se hace en un hilo de fondo; el hilo principal espera como maximo MAIN_WAIT_MS y, si no llega,
 * sigue sin Canvas y la busqueda termina sola dejando el resultado en la cache.
 * Nunca lanza excepciones: si algo falla devuelve null y Eclipse sigue como siempre.
 */
@SuppressWarnings("unused")
public final class SpotifyCanvas {
    private static final String TAG = "SpotifyCanvas";

    /** Version de diagnostico: muestra avisos (Toast) con el paso donde se queda. Poner en false para silenciarlo. */
    private static final boolean DEBUG = true;
    private static volatile String lastHttp = "";

    private static final String UA_WEB =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final String UA_CANVAS = "Spotify/9.0.34.593 iOS/18.4 (iPhone15,3)";

    private static final String SECRETS_URL =
            "https://raw.githubusercontent.com/xyloflake/spot-secrets-go/refs/heads/main/secrets/secretDict.json";
    private static final String SERVER_TIME_URL = "https://open.spotify.com/api/server-time";
    private static final String TOKEN_URL = "https://open.spotify.com/api/token";
    private static final String CLIENT_TOKEN_URL = "https://clienttoken.spotify.com/v1/clienttoken";
    private static final String SEARCH_URL = "https://api.spotify.com/v1/search";
    private static final String CANVAS_URL = "https://spclient.wg.spotify.com/canvaz-cache/v0/canvases";

    private static final int TIMEOUT_MS = 8000;
    private static final long GRACE_MS = 60_000L;

    private static final Object LOCK = new Object();
    private static String personalToken;
    private static long personalExpiresMs;
    private static String clientToken;
    private static long clientExpiresMs;

    /** Cache en memoria: clave -> url (cadena vacia = "no tiene canvas"). */
    private static final HashMap<String, String> CACHE = new HashMap<String, String>();

    /** Espera maxima en el hilo principal. Mas alto = mas chance de verlo a la primera, pero mas riesgo de tirones/ANR. */
    private static final long MAIN_WAIT_MS = 2000L;

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(2, new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "SpotifyCanvas");
            t.setDaemon(true);
            return t;
        }
    });
    /** Busquedas en curso (para no repetirlas si Eclipse vuelve a llamar por la misma cancion). */
    private static final HashMap<String, Future<String>> RUNNING = new HashMap<String, Future<String>>();

    private SpotifyCanvas() {}

    /**
     * @param title       titulo de la cancion
     * @param artist      artista
     * @param durationSec duracion en segundos (0 si no se sabe)
     * @param spdc        cookie sp_dc (vacia = funcion desactivada)
     * @return URL mp4 del canvas, o null
     */
    public static String lookup(final String title, final String artist, final int durationSec, final String spdc) {
        try {
            if (!isMainThread()) return lookupBlocking(title, artist, durationSec, spdc);

            // Hilo principal: no se puede usar la red aqui. Se hace en segundo plano y se espera poco.
            final int dur = durationSec > 10000 ? durationSec / 1000 : durationSec;
            final String key = title + "|" + artist + "|" + dur;
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) return hit.isEmpty() ? null : hit;
            }
            Future<String> f;
            synchronized (RUNNING) {
                f = RUNNING.get(key);
                if (f == null) {
                    FutureTask<String> task = new FutureTask<String>(new Callable<String>() {
                        @Override public String call() {
                            try {
                                return lookupBlocking(title, artist, durationSec, spdc);
                            } finally {
                                synchronized (RUNNING) { RUNNING.remove(key); }
                            }
                        }
                    });
                    RUNNING.put(key, task);
                    EXEC.execute(task);
                    f = task;
                }
            }
            try {
                return f.get(MAIN_WAIT_MS, TimeUnit.MILLISECONDS);
            } catch (TimeoutException te) {
                toast("Canvas: tardando, sigo en segundo plano");
                return null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "lookup (principal) fallo: " + t);
            return null;
        }
    }

    private static boolean isMainThread() {
        try { return Looper.myLooper() == Looper.getMainLooper(); } catch (Throwable t) { return false; }
    }

    private static String lookupBlocking(String title, String artist, int durationSec, String spdc) {
        try {
            if (spdc == null) { toast("Canvas: cookie vacia"); return null; }
            spdc = spdc.trim();
            if (spdc.startsWith("sp_dc=")) spdc = spdc.substring(6);
            if (spdc.length() < 20) { toast("Canvas: cookie demasiado corta"); return null; }
            if (title == null || title.trim().isEmpty()) { toast("Canvas: cancion sin titulo"); return null; }
            toast("Canvas: buscando '" + title + "'...");
            lastHttp = "";

            if (durationSec > 10000) durationSec /= 1000;
            String key = title + "|" + artist + "|" + durationSec;
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) { toast("Canvas: (cache) " + (hit.isEmpty() ? "sin canvas" : "OK")); return hit.isEmpty() ? null : hit; }
            }

            String result = null;
            synchronized (LOCK) {
                String pt = getPersonalToken(spdc);
                String ct = getClientToken();
                if (pt != null) {
                    String id = searchTrack(pt, title, artist == null ? "" : artist, durationSec);
                    if (id != null) result = fetchCanvas(pt, ct, id);
                    Log.d(TAG, "'" + title + "' -> " + (result != null ? "canvas" : "sin canvas"));
                    if (result != null) toast("Canvas: OK");
                    else if (id == null) toast("Canvas: no encontre la cancion en Spotify. " + lastHttp);
                    else toast("Canvas: sin Canvas para esta cancion. " + lastHttp);
                } else {
                    toast("Canvas sin token: " + lastHttp);
                }
            }
            // Solo se cachea el resultado si hubo token (un fallo de red no se guarda como "sin canvas").
            if (result != null || personalToken != null) {
                synchronized (CACHE) {
                    if (CACHE.size() > 300) CACHE.clear();
                    CACHE.put(key, result == null ? "" : result);
                }
            }
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            toast("Canvas: error " + t);
            return null;
        }
    }

    // ---------------------------------------------------------------- auth

    private static String getPersonalToken(String spdc) throws Exception {
        long now = System.currentTimeMillis();
        if (personalToken != null && now < personalExpiresMs - GRACE_MS) return personalToken;

        String dict = httpGet(SECRETS_URL, null, null);
        if (dict == null) return null;
        JSONObject secrets = new JSONObject(dict);
        int latest = -1;
        Iterator<String> it = secrets.keys();
        while (it.hasNext()) {
            String k = it.next();
            try { latest = Math.max(latest, Integer.parseInt(k)); } catch (NumberFormatException ignored) {}
        }
        if (latest < 0) return null;
        JSONArray cipher = secrets.getJSONArray(String.valueOf(latest));

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cipher.length(); i++) {
            sb.append(cipher.getInt(i) ^ ((i % 33) + 9));
        }
        byte[] secret = sb.toString().getBytes(Charset.forName("US-ASCII"));

        Map<String, String> cookie = new HashMap<String, String>();
        cookie.put("Cookie", "sp_dc=" + spdc);

        long serverSec = System.currentTimeMillis() / 1000L;
        String st = httpGet(SERVER_TIME_URL, cookie, null);
        if (st != null) {
            try { serverSec = new JSONObject(st).getLong("serverTime"); } catch (Throwable ignored) {}
        }

        String otp = totp(secret, serverSec / 30L);
        String url = TOKEN_URL + "?reason=init&productType=mobile-web-player&totp=" + otp
                + "&totpServer=" + otp + "&totpVer=" + latest;
        String body = httpGet(url, cookie, "application/json");
        if (body == null) return null;
        JSONObject o = new JSONObject(body);
        String token = o.optString("accessToken", "");
        if (token.isEmpty()) return null;
        personalToken = token;
        personalExpiresMs = o.optLong("accessTokenExpirationTimestampMs", System.currentTimeMillis() + 3600_000L);
        return token;
    }

    private static String totp(byte[] secret, long counter) throws Exception {
        byte[] msg = ByteBuffer.allocate(8).putLong(counter).array();
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(secret, "HmacSHA1"));
        byte[] h = mac.doFinal(msg);
        int off = h[h.length - 1] & 0x0F;
        int bin = ((h[off] & 0x7F) << 24) | ((h[off + 1] & 0xFF) << 16)
                | ((h[off + 2] & 0xFF) << 8) | (h[off + 3] & 0xFF);
        String s = String.valueOf(bin % 1000000);
        while (s.length() < 6) s = "0" + s;
        return s;
    }

    private static String getClientToken() {
        try {
            long now = System.currentTimeMillis();
            if (clientToken != null && now < clientExpiresMs - GRACE_MS) return clientToken;
            String json = "{\"client_data\":{\"client_version\":\"1.3.7.1345.gcff6cec98b6e\","
                    + "\"client_id\":\"d8a5ed958d274c2e8ee717e6a4b0971d\",\"js_sdk_data\":{"
                    + "\"device_brand\":\"unknown\",\"device_model\":\"unknown\",\"os\":\"windows\","
                    + "\"os_version\":\"10.0.0\"}}}";
            Map<String, String> h = new HashMap<String, String>();
            h.put("Content-Type", "application/json");
            byte[] resp = httpPost(CLIENT_TOKEN_URL, json.getBytes(Charset.forName("UTF-8")), h, "application/json", UA_WEB);
            if (resp == null) return clientToken;
            JSONObject g = new JSONObject(new String(resp, Charset.forName("UTF-8"))).optJSONObject("granted_token");
            if (g == null) return clientToken;
            String t = g.optString("token", "");
            if (t.isEmpty()) return clientToken;
            clientToken = t;
            clientExpiresMs = now + g.optLong("expires_after_seconds", 7200L) * 1000L;
            return t;
        } catch (Throwable t) {
            return clientToken;
        }
    }

    // ---------------------------------------------------------------- search

    private static String searchTrack(String token, String title, String artist, int durationSec) throws Exception {
        String q = (title + " " + artist).trim();
        String url = SEARCH_URL + "?type=track&limit=5&q=" + URLEncoder.encode(q, "UTF-8");
        Map<String, String> h = new HashMap<String, String>();
        h.put("Authorization", "Bearer " + token);
        String body = httpGet(url, h, "application/json");
        if (body == null) return null;
        JSONObject tracks = new JSONObject(body).optJSONObject("tracks");
        if (tracks == null) return null;
        JSONArray items = tracks.optJSONArray("items");
        if (items == null || items.length() == 0) return null;

        String best = null;
        long bestDiff = Long.MAX_VALUE;
        String wantTitle = norm(title);
        for (int i = 0; i < items.length(); i++) {
            JSONObject t = items.getJSONObject(i);
            String id = t.optString("id", "");
            if (id.isEmpty()) continue;
            String name = norm(t.optString("name", ""));
            // El titulo tiene que coincidir (evita mostrar el canvas de otra cancion).
            if (!name.equals(wantTitle) && !name.contains(wantTitle) && !wantTitle.contains(name)) continue;
            long diff = 0;
            if (durationSec > 0) {
                diff = Math.abs(t.optLong("duration_ms", 0L) / 1000L - durationSec);
                if (diff > 5) continue; // misma cancion = misma duracion (+-5 s)
            }
            if (diff < bestDiff) { bestDiff = diff; best = id; }
        }
        return best;
    }

    private static String norm(String s) {
        if (s == null) return "";
        String n = java.text.Normalizer.normalize(s, java.text.Normalizer.Form.NFD)
                .replaceAll("\\p{InCombiningDiacriticalMarks}+", "")
                .toLowerCase(java.util.Locale.ROOT)
                .replaceAll("[^a-z0-9\\s]", " ")
                .replaceAll("\\s+", " ")
                .trim();
        return n;
    }

    // ---------------------------------------------------------------- canvas (protobuf a mano)

    private static String fetchCanvas(String token, String clientTok, String trackId) throws Exception {
        byte[] uri = ("spotify:track:" + trackId).getBytes(Charset.forName("UTF-8"));
        // CanvasRequest { tracks(1) = TrackRequest { trackUri(1) = uri } }
        ByteArrayOutputStream inner = new ByteArrayOutputStream();
        inner.write(0x0A);
        writeVarint(inner, uri.length);
        inner.write(uri);
        byte[] innerBytes = inner.toByteArray();
        ByteArrayOutputStream outer = new ByteArrayOutputStream();
        outer.write(0x0A);
        writeVarint(outer, innerBytes.length);
        outer.write(innerBytes);

        Map<String, String> h = new HashMap<String, String>();
        h.put("Authorization", "Bearer " + token);
        if (clientTok != null) h.put("Client-Token", clientTok);
        h.put("Content-Type", "application/protobuf");
        byte[] resp = httpPost(CANVAS_URL, outer.toByteArray(), h, "application/protobuf", UA_CANVAS);
        if (resp == null) return null;
        return parseCanvasUrl(resp);
    }

    /** CanvasResponse { canvases(1) = CanvasItem { id(1), canvasUrl(2), ... } } */
    private static String parseCanvasUrl(byte[] data) {
        int[] pos = {0};
        while (pos[0] < data.length) {
            long tag = readVarint(data, pos);
            int field = (int) (tag >>> 3);
            int wire = (int) (tag & 7);
            if (wire == 2) {
                int len = (int) readVarint(data, pos);
                if (len < 0 || pos[0] + len > data.length) return null;
                if (field == 1) {
                    String url = parseCanvasItem(data, pos[0], pos[0] + len);
                    if (url != null) return url;
                }
                pos[0] += len;
            } else if (!skip(data, pos, wire)) {
                return null;
            }
        }
        return null;
    }

    private static String parseCanvasItem(byte[] d, int start, int end) {
        int[] pos = {start};
        while (pos[0] < end) {
            long tag = readVarint(d, pos);
            int field = (int) (tag >>> 3);
            int wire = (int) (tag & 7);
            if (wire == 2) {
                int len = (int) readVarint(d, pos);
                if (len < 0 || pos[0] + len > end) return null;
                if (field == 2) {
                    String s = new String(d, pos[0], len, Charset.forName("UTF-8"));
                    if (s.startsWith("http")) return s;
                }
                pos[0] += len;
            } else if (!skip(d, pos, wire)) {
                return null;
            }
        }
        return null;
    }

    private static boolean skip(byte[] d, int[] pos, int wire) {
        switch (wire) {
            case 0: readVarint(d, pos); return true;
            case 1: pos[0] += 8; return pos[0] <= d.length;
            case 5: pos[0] += 4; return pos[0] <= d.length;
            default: return false;
        }
    }

    private static void writeVarint(ByteArrayOutputStream out, int value) {
        while ((value & ~0x7F) != 0) {
            out.write((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        out.write(value);
    }

    private static long readVarint(byte[] d, int[] pos) {
        long r = 0;
        int shift = 0;
        while (pos[0] < d.length) {
            byte b = d[pos[0]++];
            r |= (long) (b & 0x7F) << shift;
            if ((b & 0x80) == 0) return r;
            shift += 7;
            if (shift > 63) break;
        }
        return -1;
    }

    // ---------------------------------------------------------------- diagnostico

    private static String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (Throwable t) { return "?"; }
    }

    private static String hostLabel(String url) {
        String h = hostOf(url);
        int i = h.indexOf('.');
        return i > 0 ? h.substring(0, i) : h;
    }

    private static String shortErr(Throwable t) {
        String n = t.getClass().getSimpleName();
        return n.length() > 20 ? n.substring(0, 20) + "~" : n;
    }

    private static void toast(final String msg) {
        if (!DEBUG) return;
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    // ---------------------------------------------------------------- http

    private static String httpGet(String url, Map<String, String> headers, String accept) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestProperty("User-Agent", UA_WEB);
            if (accept != null) c.setRequestProperty("Accept", accept);
            if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                lastHttp = "GET " + code + " " + hostLabel(url);
                Log.d(TAG, "GET " + code + " " + url.substring(0, Math.min(60, url.length())));
                return null;
            }
            return new String(readAll(c.getInputStream()), Charset.forName("UTF-8"));
        } catch (Throwable t) {
            lastHttp = "GET " + shortErr(t) + " " + hostLabel(url);
            Log.d(TAG, "GET error: " + t);
            return null;
        }
    }

    private static byte[] httpPost(String url, byte[] body, Map<String, String> headers, String accept, String ua) {
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("User-Agent", ua);
            if (accept != null) c.setRequestProperty("Accept", accept);
            if (headers != null) for (Map.Entry<String, String> e : headers.entrySet()) c.setRequestProperty(e.getKey(), e.getValue());
            OutputStream os = c.getOutputStream();
            os.write(body);
            os.close();
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) {
                lastHttp = "POST " + code + " " + hostLabel(url);
                Log.d(TAG, "POST " + code + " " + url.substring(0, Math.min(60, url.length())));
                return null;
            }
            return readAll(c.getInputStream());
        } catch (Throwable t) {
            lastHttp = "POST " + shortErr(t) + " " + hostLabel(url);
            Log.d(TAG, "POST error: " + t);
            return null;
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }
}
