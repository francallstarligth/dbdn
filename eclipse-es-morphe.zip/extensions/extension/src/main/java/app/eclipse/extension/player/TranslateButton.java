package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * v0.20.187 (Eclipse 0.6.57, SIN COMPILAR NI PROBAR). Boton redondo de traducir en el panel de letras.
 * Reemplaza el texto "Translate" / "Hide translation" que dibuja `mb.b` por un circulo translucido con el icono
 * 文A (dibujado con trazos redondeados). Sin traducir: circulo tenue; traducido: un poco mas claro. El circulito de
 * carga y el click (los maneja el contenedor) no se tocan.
 *
 * Todo se arma por reflexion con las piezas de Compose de Eclipse 0.6.57 (verificadas en el dex): ImageVector.Builder
 * `hy3`, PathBuilder `rx6` (`c52.f` = moveTo inicial; `j` moveTo, `h` lineTo), SolidColor `yc9(J)`, Icon `qw3.a`,
 * size `kz8.p`, padding `kc4.y`, background `tpb.i`, RoundedCornerShape `mb8` + porcentaje `wy6`, color `gh1`
 * (e = blanco, c(J,F) = cambia alfa), Modifier vacio `lu5.q`. Si algo no existe, draw() devuelve false y Eclipse
 * dibuja el texto de siempre (el gancho solo salta el texto cuando draw() devuelve true).
 */
public final class TranslateButton {
    private static boolean ready;
    private static boolean failed;

    private static Object icon;        // a44
    private static Object modBase;     // da6.q
    private static Object circle;      // du8 con esquinas 50 %
    private static long white;         // hk1.e
    private static Method iconFn;      // f24.a(a44, String, ga6, J, nt1, I, I)
    private static Method sizeFn;      // ni9.p(ga6, F)
    private static Method padFn;       // kc4.O(ga6, F)
    private static Method bgFn;        // tpb.n(ga6, J, md9)
    private static Method alphaFn;     // hk1.c(J, F)
    private static Method getValue;    // raa.getValue()

    private static Method find(Class<?> c, String name, int n, Class<?>... must) throws Exception {
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals(name)) continue;
            Class<?>[] p = m.getParameterTypes();
            if (p.length != n) continue;
            boolean ok = true;
            for (int i = 0; i < must.length; i++) {
                if (must[i] != null && p[i] != must[i]) {
                    ok = false;
                    break;
                }
            }
            if (!ok) continue;
            m.setAccessible(true);
            return m;
        }
        throw new NoSuchMethodException(c.getName() + "." + name + "/" + n);
    }

    private static boolean init() {
        if (ready) return true;
        if (failed) return false;
        try {
            Class<?> ou5 = Class.forName("ga6");
            Class<?> cq1 = Class.forName("nt1");
            Class<?> sv0 = Class.forName("my0");
            Class<?> ku8 = Class.forName("md9");
            Class<?> rw1 = Class.forName("g02");
            Class<?> gh1 = Class.forName("hk1");
            Class<?> iy3 = Class.forName("a44");

            // ---- Compose: funciones sueltas ----
            iconFn = find(Class.forName("f24"), "a", 7, iy3, String.class, ou5, long.class, cq1, int.class, int.class);
            sizeFn = find(Class.forName("ni9"), "p", 2, ou5, float.class);
            padFn = find(Class.forName("kc4"), "O", 2, ou5, float.class);
            bgFn = find(Class.forName("tpb"), "n", 3, ou5, long.class, ku8);
            alphaFn = find(gh1, "c", 2, long.class, float.class);
            Field fw = gh1.getDeclaredField("e");
            fw.setAccessible(true);
            white = fw.getLong(null);
            Field fm = Class.forName("da6").getDeclaredField("q");
            fm.setAccessible(true);
            modBase = fm.get(null);
            getValue = Class.forName("raa").getMethod("getValue");

            // ---- circulo: RoundedCornerShape con esquinas de 50 % ----
            Constructor<?> pc = Class.forName("mf7").getDeclaredConstructor(float.class);
            pc.setAccessible(true);
            Object corner = pc.newInstance(50f);
            Constructor<?> rc = Class.forName("du8").getDeclaredConstructor(rw1, rw1, rw1, rw1);
            rc.setAccessible(true);
            circle = rc.newInstance(corner, corner, corner, corner);

            // ---- icono 文A: ImageVector de 24x24 con trazos redondeados ----
            Class<?> hy3 = Class.forName("z34");
            Constructor<?> bc = hy3.getDeclaredConstructor(String.class, float.class, float.class, float.class,
                float.class, long.class, int.class, boolean.class, int.class);
            bc.setAccessible(true);
            Object builder = bc.newInstance("Filled.Translate", 24f, 24f, 24f, 24f, 0L, 0, false, 96);

            Class<?> rx6 = Class.forName("ge7");
            Method start = find(Class.forName("vz1"), "g", 2, float.class, float.class);
            Method moveTo = find(rx6, "i", 2, float.class, float.class);
            Method lineTo = find(rx6, "g", 2, float.class, float.class);
            Field nodesF = rx6.getDeclaredField("a");
            nodesF.setAccessible(true);

            float[][][] strokes = {
                {{3.2f, 6.2f}, {16.4f, 6.2f}},                       // barra de arriba de 文
                {{9.8f, 4.2f}, {9.8f, 6.2f}},                        // palito
                {{13.1f, 7.4f}, {5.3f, 17.2f}},                      // trazo largo
                {{8.3f, 8.8f}, {12.2f, 14.6f}},                      // trazo corto
                {{13.2f, 19.6f}, {16.5f, 10.8f}, {19.8f, 19.6f}},    // A
                {{14.5f, 16.4f}, {18.5f, 16.4f}},                    // travesano de la A
            };
            Object pb = null;
            for (float[][] s : strokes) {
                if (pb == null) {
                    pb = start.invoke(null, s[0][0], s[0][1]);
                } else {
                    moveTo.invoke(pb, s[0][0], s[0][1]);
                }
                for (int i = 1; i < s.length; i++) lineTo.invoke(pb, s[i][0], s[i][1]);
            }
            Object nodes = nodesF.get(pb);

            Constructor<?> sc = Class.forName("aw9").getDeclaredConstructor(long.class);
            sc.setAccessible(true);
            Object solid = sc.newInstance(white);

            // z34.b(builder, nodos, fillType, fill, stroke, strokeWidth, cap, join, miter, mascara)
            Method addPath = null;
            for (Method m : hy3.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (m.getName().equals("b") && p.length == 10 && p[0] == hy3 && p[1] == List.class && p[2] == int.class
                    && p[3] == sv0 && p[4] == sv0 && p[5] == float.class) {
                    addPath = m;
                    break;
                }
            }
            if (addPath == null) throw new NoSuchMethodException("hy3.b");
            addPath.setAccessible(true);
            // cap = 1 (redondo), join = 1 (redondo)
            addPath.invoke(null, builder, nodes, 0, null, solid, 1.7f, 1, 1, 4.0f, 0);

            Method build = hy3.getDeclaredMethod("c");
            build.setAccessible(true);
            icon = build.invoke(builder);
            if (icon == null) throw new IllegalStateException("icono null");

            ready = true;
            return true;
        } catch (Throwable t) {
            failed = true;
            return false;
        }
    }

    /**
     * Lo llama el gancho smali de mb.b justo despues de abrir el grupo del texto. composer = iq1, state = estado
     * "ya traducido" (yp9). true = dibujado (el gancho salta el texto); false = que Eclipse dibuje el texto de siempre.
     */
    public static boolean draw(Object composer, Object state) {
        boolean started = false;
        try {
            if (composer == null || !init()) return false;
            boolean on = false;
            try {
                Object v = getValue.invoke(state);
                on = (v instanceof Boolean) && ((Boolean) v);
            } catch (Throwable ignored) {
            }
            long bg = (Long) alphaFn.invoke(null, white, on ? 0.30f : 0.16f);
            long tint = (Long) alphaFn.invoke(null, white, on ? 0.95f : 0.62f);
            Object m = sizeFn.invoke(null, modBase, 36f);
            m = bgFn.invoke(null, m, bg, circle);
            m = padFn.invoke(null, m, 6f);
            started = true;
            iconFn.invoke(null, icon, null, m, tint, composer, 0, 0);
            return true;
        } catch (Throwable t) {
            return started;
        }
    }
}
