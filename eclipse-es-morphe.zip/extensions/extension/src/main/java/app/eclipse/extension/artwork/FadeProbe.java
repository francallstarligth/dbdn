package app.eclipse.extension.artwork;

/**
 * v1.100.11 DIAGNOSTICO (no cambia nada visible): se llama justo antes de que el edge fade dibuje su degradado
 * (bd6.invoke -> hd2.S0 = drawRect). Anota en el diagnostico del portapapeles el pincel (colores y posiciones),
 * el origen y el tamano del rectangulo. Solo anota si el diagnostico de PrevCover ya esta activo (hay imagenes
 * llegando) y solo cuando algo cambia.
 */
@SuppressWarnings("unused")
public final class FadeProbe {
    private FadeProbe() {}

    private static Object lastBrush;
    private static long lastTop, lastSize;

    public static void probe(Object brush, long topLeft, long size) {
        try {
            if (!PrevCover.diagOn()) return;
            if (brush == lastBrush && topLeft == lastTop && size == lastSize) return;
            lastBrush = brush;
            lastTop = topLeft;
            lastSize = size;
            String msg = "FADE rect x=" + f(topLeft >>> 32) + " y=" + f(topLeft) + " ancho=" + f(size >>> 32)
                    + " alto=" + f(size) + " pincel=" + dump(brush, 0);
            PrevCover.diagStyle(msg, msg);
        } catch (Throwable ignored) {
        }
    }

    private static String f(long bits) {
        return String.valueOf(Float.intBitsToFloat((int) bits));
    }

    private static String color(long v) {
        // Color de Compose (sRGB) empaquetado: alfa/rojo/verde/azul en los 4 bytes altos.
        int a = (int) ((v >>> 56) & 0xFF), r = (int) ((v >>> 48) & 0xFF), g = (int) ((v >>> 40) & 0xFF), b = (int) ((v >>> 32) & 0xFF);
        return "(a" + a + " r" + r + " g" + g + " b" + b + ")";
    }

    private static String dump(Object o, int depth) {
        if (o == null) return "null";
        try {
            if (o instanceof Long) return "L" + Long.toHexString((Long) o) + color((Long) o);
            if (o instanceof Number || o instanceof Boolean || o instanceof String) return String.valueOf(o);
            if (o instanceof Object[]) {
                StringBuilder sb = new StringBuilder("[");
                for (Object x : (Object[]) o) sb.append(dump(x, depth + 1)).append(' ');
                return sb.append(']').toString();
            }
            if (o instanceof long[]) {
                StringBuilder sb = new StringBuilder("[");
                for (long x : (long[]) o) sb.append(Long.toHexString(x)).append(color(x)).append(' ');
                return sb.append(']').toString();
            }
            if (o instanceof float[]) return java.util.Arrays.toString((float[]) o);
            if (o instanceof java.util.List) {
                StringBuilder sb = new StringBuilder("[");
                for (Object x : (java.util.List<?>) o) sb.append(dump(x, depth + 1)).append(' ');
                return sb.append(']').toString();
            }
            String s = String.valueOf(o);
            if (s.indexOf('@') < 0 && depth > 0) return s;
            if (depth > 2) return s;
            StringBuilder sb = new StringBuilder(o.getClass().getName()).append('{');
            for (Class<?> c = o.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
                for (java.lang.reflect.Field fl : c.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(fl.getModifiers())) continue;
                    fl.setAccessible(true);
                    sb.append(fl.getName()).append('=').append(dump(fl.get(o), depth + 1)).append("; ");
                }
            }
            return sb.append('}').toString();
        } catch (Throwable t) {
            return String.valueOf(o);
        }
    }
}
