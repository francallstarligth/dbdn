package app.eclipse.extension.player;

import java.util.ArrayList;
import java.util.List;

/**
 * v0.20.232 (parche "Cola: no arrancar vacia"). Recuerda el contenido de la ultima lista de Cola ya llenada (t50.y) y lo
 * copia a la lista nueva (sd9) cuando el panel se recrea (t50.m), para que no se dibuje el cartel "Nada a continuacion"
 * mientras t50.y vuelve a llenarla. Si la cola de verdad esta vacia, lo recordado tambien lo esta. Todo con try/catch.
 */
public final class QueueKeep {
    private static final ArrayList<Object> ultima = new ArrayList<>();

    private QueueKeep() {}

    /** Final de t50.y: sd9 ya llenada. Guarda una copia. */
    public static void guardar(Object lista) {
        try {
            List<?> l = (List<?>) lista;
            ArrayList<Object> copia = new ArrayList<>(l);
            ultima.clear();
            ultima.addAll(copia);
        } catch (Throwable ignored) {
        }
    }

    /** Tras `new sd9()` en t50.m: copia lo ultimo guardado a la lista nueva. */
    @SuppressWarnings("unchecked")
    public static void precargar(Object lista) {
        try {
            if (ultima.isEmpty()) return;
            ((List<Object>) lista).addAll(ultima);
        } catch (Throwable ignored) {
        }
    }
}
