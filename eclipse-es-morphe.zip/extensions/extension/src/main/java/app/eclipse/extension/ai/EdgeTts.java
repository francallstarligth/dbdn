package app.eclipse.extension.ai;

import android.util.Log;

/**
 * v0.20.416: tampoco Cloudflare. v0.20.415: ya NO hay voz Edge (se quito el servicio de Microsoft por completo; la voz local Phonon la reemplaza).
 * Se queda el nombre de la clase porque el gancho del parche "Voz local" llama a EdgeTts.speak(texto, voz, gradium).
 * Cadena: Phonon (local) -> Gradium (solo si la llave trae LLAVE@IDVOZ) -> null (Eclipse sigue con su camino normal).
 */
public final class EdgeTts {
    private static final String TAG = "EdgeTts";

    private EdgeTts() {}

    /** La cadena siempre corre. */
    static boolean chainEnabled(String gradiumVoice) {
        return true;
    }

    /** @return audio o null si no se pudo. Nunca lanza. */
    public static byte[] speak(String text, String voice) {
        return speak(text, voice, null);
    }

    /**
     * @param voice ya no se usa (era la voz de Edge)
     * @return audio (WAV o MP3) o null si no se pudo. Nunca lanza.
     */
    public static byte[] speak(String text, String voice, String gradiumVoice) {
        try {
            byte[] p = PhononTts.speak(text);
            if (p != null && p.length > 0) return p;
        } catch (Throwable t) {
            Log.w(TAG, "Phonon fallo: " + t);
        }
        if (chainEnabled(gradiumVoice)) {
            try {
                byte[] g = GradiumTts.speak(text, gradiumVoice);
                if (g != null && g.length > 0) return g;
            } catch (Throwable t) {
                Log.w(TAG, "Gradium fallo: " + t);
            }
        }
        return null;
    }

    static String clean(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            // se quitan caracteres de control (salvo \t \n \r)
            if ((c < 9) || (c > 13 && c < 32) || c == 11 || c == 12) c = ' ';
            b.append(c);
        }
        String r = b.toString().replaceAll("[*_#`~]+", "").trim();
        return r;
    }
}
