package app.eclipse.extension.ai;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.UUID;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * v0.20.237 (SIN COMPILAR NI PROBAR contra Microsoft; solo javac + servidor falso). Voz del DJ con Edge TTS.
 *
 * Eclipse 0.6.61 pide la voz del DJ a su servidor (POST api.eclipsemusic.app/api/tts) en Lsb.invokeSuspend (caso TTSApiClient,
 * hilo de fondo IO). Este gancho llama antes a speak(texto, voz): habla DIRECTO con el servicio de voz de Microsoft Edge
 * (WebSocket, mismo protocolo que la libreria edge-tts 7.2.3) y devuelve un MP3. Si algo falla devuelve null y Eclipse sigue
 * con su camino normal (servidor y luego voz del telefono). Sin dependencias: WebSocket minimo sobre SSLSocket.
 * Servicio NO oficial de Microsoft: puede cambiar o bloquearse sin aviso.
 */
public final class EdgeTts {
    private static final String TAG = "EdgeTts";
    private static final String TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
    private static final String VERSION = "1-140.0.3485.14";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
        + "Chrome/140.0.0.0 Safari/537.36 Edg/140.0.0.0";
    private static final long WIN_EPOCH = 11644473600L;
    private static final int MAX_CHARS = 1500;

    // Servidor nuevo y, si falla, el viejo.
    private static final String[][] ENDPOINTS = {
        {"api.msedgeservices.com", "/tts/cognitiveservices/websocket/v1?Ocp-Apim-Subscription-Key=" + TOKEN},
        {"speech.platform.bing.com", "/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=" + TOKEN},
    };

    /** Para pruebas: reemplaza los servidores (host, puerto, sin TLS). */
    static String testHost;
    static int testPort;
    static volatile long skewMs;

    private static final SecureRandom RNG = new SecureRandom();

    private EdgeTts() {}

    static boolean chainEnabled(String gradiumVoice) {
        if (gradiumVoice == null) return false;
        String g = gradiumVoice.trim();
        return !g.isEmpty() && !g.equalsIgnoreCase("x");
    }

    /** @return MP3 o null si no se pudo. Nunca lanza. */
    public static byte[] speak(String text, String voice) {
        return speak(text, voice, null);
    }

    /**
     * v0.20.241: cadena Gradium (con la llave que la persona puso en la app) -> Cloudflare (voz celeste) -> Edge.
     * gradiumVoice vacio o "x" = solo Edge. v0.20.239: si gradiumVoice no esta vacia, primero intenta Gradium (WAV).
     * @return audio (WAV o MP3) o null si no se pudo. Nunca lanza.
     */
    public static byte[] speak(String text, String voice, String gradiumVoice) {
        if (chainEnabled(gradiumVoice)) {
            try {
                byte[] g = GradiumTts.speak(text, gradiumVoice);
                if (g != null && g.length > 0) return g;
            } catch (Throwable t) {
                Log.w(TAG, "Gradium fallo: " + t);
            }
            try {
                byte[] c = CloudflareTts.speak(text);
                if (c != null && c.length > 0) return c;
            } catch (Throwable t) {
                Log.w(TAG, "Cloudflare fallo: " + t);
            }
            Log.w(TAG, "Ni Gradium ni Cloudflare dieron audio; se usa Edge");
        }
        try {
            if (text == null) return null;
            text = clean(text);
            if (text.isEmpty()) return null;
            if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS);
            if (voice == null || voice.isEmpty()) voice = "es-MX-DaliaNeural";
            for (int pass = 0; pass < 2; pass++) {
                for (String[] ep : ENDPOINTS) {
                    try {
                        byte[] a = once(ep[0], ep[1], text, voice);
                        if (a != null && a.length > 0) return a;
                    } catch (ClockSkew e) {
                        break; // reintenta con el reloj corregido
                    } catch (Throwable t) {
                        Log.w(TAG, ep[0] + ": " + t);
                    }
                }
                if (pass == 0 && skewMs == 0) break;
            }
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
        }
        return null;
    }

    private static final class ClockSkew extends RuntimeException {}

    static String clean(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            // Edge rechaza caracteres de control (salvo \t \n \r)
            if ((c < 9) || (c > 13 && c < 32) || c == 11 || c == 12) c = ' ';
            b.append(c);
        }
        String r = b.toString().replaceAll("[*_#`~]+", "").trim();
        return r;
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    static String gec(long nowMs) {
        long t = nowMs / 1000L + WIN_EPOCH;
        t -= t % 300L;
        String ticks = Long.toString(t) + "0000000"; // t * 1e7
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] h = md.digest((ticks + TOKEN).getBytes(StandardCharsets.US_ASCII));
            StringBuilder sb = new StringBuilder();
            for (byte x : h) sb.append(String.format(Locale.ROOT, "%02X", x & 0xff));
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static String stamp() {
        SimpleDateFormat f = new SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(System.currentTimeMillis() + skewMs)) + " GMT+0000 (Coordinated Universal Time)";
    }

    private static byte[] once(String host, String path, String text, String voice) throws Exception {
        long now = System.currentTimeMillis() + skewMs;
        String full = path + "&ConnectionId=" + UUID.randomUUID().toString().replace("-", "")
            + "&Sec-MS-GEC=" + gec(now) + "&Sec-MS-GEC-Version=" + VERSION;
        Socket s;
        if (testHost != null) {
            s = new Socket();
            s.connect(new InetSocketAddress(testHost, testPort), 8000);
        } else {
            Socket raw = new Socket();
            raw.connect(new InetSocketAddress(host, 443), 8000);
            SSLSocket ssl = (SSLSocket) ((SSLSocketFactory) SSLSocketFactory.getDefault()).createSocket(raw, host, 443, true);
            ssl.startHandshake();
            s = ssl;
        }
        try {
            s.setSoTimeout(15000);
            InputStream in = s.getInputStream();
            OutputStream out = s.getOutputStream();

            byte[] kb = new byte[16];
            RNG.nextBytes(kb);
            String key = java.util.Base64.getEncoder().encodeToString(kb);
            String req = "GET " + full + " HTTP/1.1\r\n"
                + "Host: " + host + "\r\n"
                + "Connection: Upgrade\r\nUpgrade: websocket\r\n"
                + "Sec-WebSocket-Key: " + key + "\r\n"
                + "Sec-WebSocket-Version: 13\r\n"
                + "Sec-WebSocket-Protocol: synthesize\r\n"
                + "Pragma: no-cache\r\nCache-Control: no-cache\r\n"
                + "Origin: chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold\r\n"
                + "User-Agent: " + UA + "\r\n"
                + "Accept-Language: en-US,en;q=0.9\r\n\r\n";
            out.write(req.getBytes(StandardCharsets.US_ASCII));
            out.flush();

            String head = readHead(in);
            if (!head.startsWith("HTTP/1.1 101") && !head.startsWith("HTTP/1.0 101")) {
                String status = head.length() > 40 ? head.substring(0, 40) : head;
                // 403 + cabecera Date: corregir el reloj y reintentar
                if (head.contains(" 403")) {
                    long d = parseDate(head);
                    if (d > 0 && Math.abs(d - System.currentTimeMillis()) > 60_000L) {
                        skewMs = d - System.currentTimeMillis();
                        throw new ClockSkew();
                    }
                }
                throw new Exception("handshake: " + status.replace("\r", " ").replace("\n", " "));
            }

            String cfg = "X-Timestamp:" + stamp() + "\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n"
                + "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\","
                + "\"wordBoundaryEnabled\":\"false\"},\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n";
            writeFrame(out, 1, cfg.getBytes(StandardCharsets.UTF_8));

            String ssml = "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='es-MX'>"
                + "<voice name='" + esc(voice) + "'><prosody pitch='+0Hz' rate='+0%' volume='+0%'>" + esc(text)
                + "</prosody></voice></speak>";
            String sm = "X-RequestId:" + UUID.randomUUID().toString().replace("-", "") + "\r\nContent-Type:application/ssml+xml\r\n"
                + "X-Timestamp:" + stamp() + "Z\r\nPath:ssml\r\n\r\n" + ssml;
            writeFrame(out, 1, sm.getBytes(StandardCharsets.UTF_8));

            ByteArrayOutputStream audio = new ByteArrayOutputStream();
            ByteArrayOutputStream msg = new ByteArrayOutputStream();
            int msgOp = 0;
            while (true) {
                int b0 = in.read();
                int b1 = in.read();
                if (b0 < 0 || b1 < 0) break;
                boolean fin = (b0 & 0x80) != 0;
                int op = b0 & 0x0f;
                long len = b1 & 0x7f;
                if (len == 126) len = (in.read() << 8) | in.read();
                else if (len == 127) { len = 0; for (int i = 0; i < 8; i++) len = (len << 8) | in.read(); }
                if (len > 8_000_000L) throw new Exception("trama enorme");
                boolean masked = (b1 & 0x80) != 0;
                byte[] mask = new byte[4];
                if (masked) readFully(in, mask, 4);
                byte[] p = new byte[(int) len];
                readFully(in, p, p.length);
                if (masked) for (int i = 0; i < p.length; i++) p[i] ^= mask[i & 3];

                if (op == 9) { writeFrame(out, 10, p); continue; }      // ping -> pong
                if (op == 8) break;                                     // close
                if (op == 10) continue;
                if (op != 0) { msg.reset(); msgOp = op; }
                msg.write(p);
                if (!fin) continue;
                byte[] m = msg.toByteArray();
                msg.reset();
                if (msgOp == 1) {
                    String t = new String(m, StandardCharsets.UTF_8);
                    if (t.contains("Path:turn.end")) break;
                } else if (msgOp == 2) {
                    if (m.length < 2) continue;
                    int hl = ((m[0] & 0xff) << 8) | (m[1] & 0xff);
                    if (hl + 2 > m.length) throw new Exception("cabecera binaria rara");
                    String h = new String(m, 2, hl, StandardCharsets.UTF_8);
                    if (h.contains("Path:audio") && m.length > hl + 2) audio.write(m, hl + 2, m.length - hl - 2);
                }
            }
            byte[] r = audio.toByteArray();
            if (r.length == 0) throw new Exception("sin audio");
            Log.i(TAG, "ok " + r.length + " bytes, voz " + voice);
            return r;
        } finally {
            try { s.close(); } catch (Throwable ignore) {}
        }
    }

    private static long parseDate(String head) {
        try {
            for (String line : head.split("\r\n")) {
                if (line.regionMatches(true, 0, "Date:", 0, 5)) {
                    SimpleDateFormat f = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
                    return f.parse(line.substring(5).trim()).getTime();
                }
            }
        } catch (Throwable ignore) {}
        return -1;
    }

    private static String readHead(InputStream in) throws Exception {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int state = 0;
        while (state < 4 && b.size() < 16384) {
            int c = in.read();
            if (c < 0) throw new Exception("conexion cerrada");
            b.write(c);
            if ((state == 0 || state == 2) && c == '\r') state++;
            else if ((state == 1 || state == 3) && c == '\n') state++;
            else state = (c == '\r') ? 1 : 0;
        }
        return new String(b.toByteArray(), StandardCharsets.ISO_8859_1);
    }

    private static void readFully(InputStream in, byte[] b, int n) throws Exception {
        int o = 0;
        while (o < n) {
            int r = in.read(b, o, n - o);
            if (r < 0) throw new Exception("conexion cerrada");
            o += r;
        }
    }

    private static void writeFrame(OutputStream out, int op, byte[] p) throws Exception {
        ByteArrayOutputStream f = new ByteArrayOutputStream();
        f.write(0x80 | op);
        if (p.length < 126) f.write(0x80 | p.length);
        else if (p.length < 65536) { f.write(0x80 | 126); f.write(p.length >> 8); f.write(p.length & 0xff); }
        else { f.write(0x80 | 127); for (int i = 7; i >= 0; i--) f.write((int) (((long) p.length >> (8 * i)) & 0xff)); }
        byte[] mk = new byte[4];
        RNG.nextBytes(mk);
        f.write(mk);
        for (int i = 0; i < p.length; i++) f.write(p[i] ^ mk[i & 3]);
        out.write(f.toByteArray());
        out.flush();
    }
}
