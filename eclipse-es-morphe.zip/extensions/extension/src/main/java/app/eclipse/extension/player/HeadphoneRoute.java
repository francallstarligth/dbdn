package app.eclipse.extension.player;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;

/**
 * v1.92.0: fila "Audifonos" en la hoja "Conectar a un dispositivo" de Eclipse.
 * La fila solo se dibuja cuando hay audifonos conectados (lo decide {@link #present()}).
 * v1.92.1: al tocarla se cambia la salida con AudioTrack.setPreferredDevice, llamando a setPreferredDevice de los
 * AudioSink de Eclipse (kd3 / vw1, que se registran en su constructor). Si no hay sink o falla, se abre el
 * selector de salida del sistema (MediaRouter2.showSystemOutputSwitcher).
 * Todo por reflexion y con try/catch: si algo falla la app queda como estaba.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class HeadphoneRoute {
    private static final int BUILTIN_SPEAKER = 2;
    private static Object clickProxy;

    private HeadphoneRoute() {}

    private static Object app() throws Exception {
        return Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
    }

    private static boolean isHeadphoneType(int t) {
        return t == 3 || t == 4 || t == 7 || t == 8 || t == 22 || t == 23 || t == 26;
    }

    private static Object audio() throws Exception {
        Object a = app();
        return a == null ? null : a.getClass().getMethod("getSystemService", String.class).invoke(a, "audio");
    }

    /** Primer dispositivo de salida de audifonos conectado (AudioDeviceInfo) o null. */
    private static Object headphoneDevice() {
        try {
            Object am = audio();
            if (am == null) return null;
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                int t = (Integer) d.getClass().getMethod("getType").invoke(d);
                if (isHeadphoneType(t)) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Lo llama el gancho smali: true = dibujar la fila. */
    public static boolean present() {
        return headphoneDevice() != null;
    }

    /** Titulo de la fila: nombre del producto (p. ej. "Soundpeats C30") o "Audifonos". */
    public static String title() {
        try {
            Object d = headphoneDevice();
            if (d != null) {
                Object n = d.getClass().getMethod("getProductName").invoke(d);
                if (n != null && n.toString().trim().length() > 0) return n.toString();
            }
        } catch (Throwable ignored) {
        }
        return "Audífonos";
    }

    /** true si la salida de audio de musica va ahora a unos audifonos (Android 13+; si falla, false). */
    private static boolean activeOnHeadphones() {
        try {
            if (forcedSpeaker != null) {
                if (headphoneDevice() != null) return false;
                forcedSpeaker = null;
            }
            Object am = audio();
            Class<?> ab = Class.forName("android.media.AudioAttributes$Builder");
            Object b = ab.getConstructor().newInstance();
            ab.getMethod("setUsage", int.class).invoke(b, 1);
            Object attrs = ab.getMethod("build").invoke(b);
            java.util.List l = (java.util.List) am.getClass()
                .getMethod("getAudioDevicesForAttributes", Class.forName("android.media.AudioAttributes"))
                .invoke(am, attrs);
            if (l == null || l.isEmpty()) return false;
            Object d = l.get(0);
            return isHeadphoneType((Integer) d.getClass().getMethod("getType").invoke(d));
        } catch (Throwable t) {
            return false;
        }
    }

    public static String subtitle() {
        return activeOnHeadphones() ? "Reproduciendo ahora" : "Toca para reproducir aquí";
    }

    /** Devuelve un d43 (interfaz con a()Object) que cambia la salida. Se crea una sola vez. */
    public static Object click() {
        try {
            synchronized (HeadphoneRoute.class) {
                if (clickProxy == null) {
                    Class<?> f = Class.forName("d43");
                    clickProxy = Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                            String n = m.getName();
                            if (n.equals("a") && (args == null || args.length == 0)) {
                                try {
                                    setRoute(false);
                                } catch (Throwable ignored) {
                                }
                                bump();
                                diag("audifonos");
                                return null;
                            }
                            if (n.equals("hashCode")) return System.identityHashCode(proxy);
                            if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                            if (n.equals("toString")) return "HeadphoneRouteClick";
                            return null;
                        }
                    });
                }
                return clickProxy;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    // ---- v1.92.1: cambio directo con setPreferredDevice de los AudioSink ----

    private static final java.util.List<java.lang.ref.WeakReference<Object>> SINKS =
        new java.util.ArrayList<java.lang.ref.WeakReference<Object>>();
    /** Dispositivo preferido que pusimos (la bocina del telefono) o null si seguimos al sistema. */
    private static Object forcedSpeaker;

    /** Lo llama el gancho smali al final del constructor de cada AudioSink de Eclipse. */
    public static void register(Object sink) {
        try {
            synchronized (SINKS) {
                SINKS.add(new java.lang.ref.WeakReference<Object>(sink));
            }
            if (forcedSpeaker != null) applyTo(sink, forcedSpeaker);
        } catch (Throwable ignored) {
        }
    }

    private static boolean applyTo(Object sink, Object device) {
        try {
            Method m = sink.getClass().getMethod("setPreferredDevice", Class.forName("android.media.AudioDeviceInfo"));
            m.invoke(sink, device);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static Object builtinSpeaker() {
        try {
            Object am = audio();
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                if ((Integer) d.getClass().getMethod("getType").invoke(d) == BUILTIN_SPEAKER) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** true si hay que mostrar el telefono como NO activo (Eclipse dice "reproduciendo aqui" pero suena en audifonos). */
    public static boolean phoneInactive(Object trailingIcon) {
        return trailingIcon != null && activeOnHeadphones();
    }

    public static String tapText() {
        return "Toca para reproducir aquí";
    }

    public static boolean active() {
        return activeOnHeadphones();
    }

    /** toSpeaker=true: forzar la bocina del telefono; false: audifonos (seguir al sistema). Idempotente. */
    private static void setRoute(boolean toSpeaker) throws Exception {
        Object device = null;
        if (toSpeaker) {
            if (headphoneDevice() == null) return; // sin audifonos ya suena en el telefono
            device = builtinSpeaker();
            if (device == null) {
                openSwitcher();
                return;
            }
        }
        int ok = 0;
        java.util.List<Object> live = new java.util.ArrayList<Object>();
        synchronized (SINKS) {
            java.util.Iterator<java.lang.ref.WeakReference<Object>> it = SINKS.iterator();
            while (it.hasNext()) {
                Object o = it.next().get();
                if (o == null) it.remove();
                else live.add(o);
            }
        }
        for (Object o : live) if (applyTo(o, device)) ok++;
        if (ok == 0) {
            openSwitcher();
            return;
        }
        forcedSpeaker = device;
    }

    /** v1.92.2: envuelve el click de "Este dispositivo": primero fuerza la bocina, luego corre el click original. */
    public static Object wrapPhone(final Object original) {
        try {
            Class<?> f = Class.forName("d43");
            return Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    String n = m.getName();
                    if (n.equals("a") && (args == null || args.length == 0)) {
                        try {
                            setRoute(true);
                        } catch (Throwable ignored) {
                        }
                        bump();
                        diag("bocina");
                        return original == null ? null : original.getClass().getMethod("a").invoke(original);
                    }
                    if (n.equals("hashCode")) return System.identityHashCode(proxy);
                    if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                    if (n.equals("toString")) return "PhoneRowClick";
                    return null;
                }
            });
        } catch (Throwable t) {
            return original;
        }
    }

    // ---- v1.92.4: la hoja se redibuja sola al cambiar la salida ----
    // Eclipse (Compose) solo redibuja cuando cambia un "estado" que se leyo al dibujar. z46 es su estado entero
    // (ParcelableSnapshotMutableIntState: <init>(I), g()I = leer, h(I)V = escribir). Leer tick() al dibujar la hoja la
    // suscribe; bump() lo cambia al tocar una fila y fuerza el redibujado. Todo por reflexion; si falla, queda como antes.
    private static Object tickState;
    private static java.lang.reflect.Method tickGet;
    private static java.lang.reflect.Method tickSet;
    private static boolean tickFailed;

    private static boolean tickInit() {
        if (tickState != null) return true;
        if (tickFailed) return false;
        try {
            Class<?> c = Class.forName("z46");
            Object st = c.getConstructor(int.class).newInstance(0);
            Method get = null;
            Method set = null;
            for (Method m : c.getDeclaredMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (pt.length == 0 && m.getReturnType() == int.class && !m.getName().equals("describeContents")
                    && !m.getName().equals("hashCode")) get = m;
                if (pt.length == 1 && pt[0] == int.class && m.getReturnType() == void.class) set = m;
            }
            if (get == null || set == null) {
                tickFailed = true;
                return false;
            }
            get.setAccessible(true);
            set.setAccessible(true);
            tickGet = get;
            tickSet = set;
            tickState = st;
            return true;
        } catch (Throwable t) {
            tickFailed = true;
            return false;
        }
    }

    /** Lo llama el gancho smali al dibujar la hoja: leer el estado la suscribe a sus cambios. */
    public static int tick() {
        try {
            if (!tickInit()) return 0;
            return (Integer) tickGet.invoke(tickState);
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Cambia el estado: Compose redibuja la hoja y vuelve a leer los textos. */
    private static void bump() {
        try {
            if (!tickInit()) return;
            int v = (Integer) tickGet.invoke(tickState);
            tickSet.invoke(tickState, v + 1);
        } catch (Throwable ignored) {
        }
    }

    // ---- v1.92.5: DIAGNOSTICO (mensajitos con lo que ve Android de nuestra pista) ----

    private static String typeName(int t) {
        if (t == BUILTIN_SPEAKER) return "bocina";
        if (t == 8) return "a2dp";
        if (t == 7) return "sco";
        if (isHeadphoneType(t)) return "aud(" + t + ")";
        return "t" + t;
    }

    /** Ruta general del sistema para musica (getAudioDevicesForAttributes). */
    private static String systemRoute() {
        try {
            Object am = audio();
            Class<?> ab = Class.forName("android.media.AudioAttributes$Builder");
            Object bld = ab.getConstructor().newInstance();
            ab.getMethod("setUsage", int.class).invoke(bld, 1);
            Object attrs = ab.getMethod("build").invoke(bld);
            java.util.List l = (java.util.List) am.getClass()
                .getMethod("getAudioDevicesForAttributes", Class.forName("android.media.AudioAttributes"))
                .invoke(am, attrs);
            if (l == null || l.isEmpty()) return "nada";
            return typeName((Integer) l.get(0).getClass().getMethod("getType").invoke(l.get(0)));
        } catch (Throwable t) {
            return "err";
        }
    }

    /** Dispositivo de cada reproduccion activa (AudioPlaybackConfiguration.getAudioDeviceInfo). */
    private static String playbackDevices() {
        try {
            Object am = audio();
            java.util.List l = (java.util.List) am.getClass().getMethod("getActivePlaybackConfigurations").invoke(am);
            if (l == null || l.isEmpty()) return "sin pistas";
            StringBuilder sb = new StringBuilder();
            for (Object c : l) {
                Object d = null;
                try {
                    d = c.getClass().getMethod("getAudioDeviceInfo").invoke(c);
                } catch (Throwable ignored) {
                }
                if (sb.length() > 0) sb.append(",");
                sb.append(d == null ? "?" : typeName((Integer) d.getClass().getMethod("getType").invoke(d)));
            }
            return sb.toString();
        } catch (Throwable t) {
            return "err";
        }
    }

    /** getRoutedDevice() del AudioTrack de cada sink vivo (busca el AudioTrack un nivel adentro del sink). */
    private static String sinkRoutes() {
        StringBuilder sb = new StringBuilder();
        try {
            java.util.List<Object> live = new java.util.ArrayList<Object>();
            synchronized (SINKS) {
                for (java.lang.ref.WeakReference<Object> w : SINKS) {
                    Object o = w.get();
                    if (o != null) live.add(o);
                }
            }
            Class<?> atc = Class.forName("android.media.AudioTrack");
            for (Object sink : live) {
                String r = null;
                for (java.lang.reflect.Field f : sink.getClass().getDeclaredFields()) {
                    f.setAccessible(true);
                    Object v = f.get(sink);
                    if (v == null) continue;
                    for (java.lang.reflect.Field g : v.getClass().getDeclaredFields()) {
                        if (g.getType() == atc) {
                            g.setAccessible(true);
                            Object track = g.get(v);
                            if (track != null) {
                                Object d = atc.getMethod("getRoutedDevice").invoke(track);
                                r = d == null ? "null" : typeName((Integer) d.getClass().getMethod("getType").invoke(d));
                            }
                        }
                    }
                }
                if (r != null) {
                    if (sb.length() > 0) sb.append(",");
                    sb.append(r);
                }
            }
        } catch (Throwable t) {
            sb.append("err");
        }
        return sb.length() == 0 ? "sin track" : sb.toString();
    }

    private static void toast(String text) {
        try {
            Object ctx = app();
            Class<?> tc = Class.forName("android.widget.Toast");
            Object t = tc.getMethod("makeText", Class.forName("android.content.Context"), CharSequence.class, int.class)
                .invoke(null, ctx, text, 0);
            tc.getMethod("show").invoke(t);
        } catch (Throwable ignored) {
        }
    }

    /** Despues de tocar una fila: mensajitos a los 0, 2 y 5 s. */
    private static void diag(final String asked) {
        try {
            if (headphoneDevice() == null) return;
            Class<?> lc = Class.forName("android.os.Looper");
            Object main = lc.getMethod("getMainLooper").invoke(null);
            Class<?> hc = Class.forName("android.os.Handler");
            final Object h = hc.getConstructor(lc).newInstance(main);
            final Method post = hc.getMethod("postDelayed", Runnable.class, long.class);
            final long[] times = {0L, 2000L, 5000L};
            for (final long t : times) {
                post.invoke(h, new Runnable() {
                    @Override
                    public void run() {
                        toast(t / 1000 + "s pedi:" + asked + " ruta:" + systemRoute() + " pistas:" + playbackDevices()
                            + " sink:" + sinkRoutes());
                    }
                }, t);
            }
        } catch (Throwable ignored) {
        }
    }

    private static void openSwitcher() {
        try {
            Object ctx = app();
            Class<?> mr2c = Class.forName("android.media.MediaRouter2");
            Object mr2 = mr2c.getMethod("getInstance", Class.forName("android.content.Context")).invoke(null, ctx);
            mr2c.getMethod("showSystemOutputSwitcher").invoke(mr2);
        } catch (Throwable ignored) {
        }
    }
}
