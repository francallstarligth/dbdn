package app.eclipse.extension.player;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;

/**
 * v1.92.0: fila "Audifonos" en la hoja "Conectar a un dispositivo" de Eclipse.
 * La fila solo se dibuja cuando hay audifonos conectados (lo decide {@link #present()}).
 * v1.92.1: al tocarla se cambia la salida con AudioTrack.setPreferredDevice, llamando a setPreferredDevice de los
 * AudioSink de Eclipse (kd3 / vw1, que se registran en su constructor). Si no hay sink o falla, se abre el
 * selector de salida del sistema (MediaRouter2.showSystemOutputSwitcher).
 * Todo por reflexion y con try/catch: si algo falla la app queda como estaba.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class HeadphoneRoute {
    private static final int BUILTIN_SPEAKER = 2;
    private static Object clickProxy;

    private HeadphoneRoute() {}

    private static Object app() throws Exception {
        return Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
    }

    private static boolean isHeadphoneType(int t) {
        return t == 3 || t == 4 || t == 7 || t == 8 || t == 22 || t == 23 || t == 26;
    }

    private static Object audio() throws Exception {
        Object a = app();
        return a == null ? null : a.getClass().getMethod("getSystemService", String.class).invoke(a, "audio");
    }

    /** Primer dispositivo de salida de audifonos conectado (AudioDeviceInfo) o null. */
    private static Object headphoneDevice() {
        try {
            Object am = audio();
            if (am == null) return null;
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                int t = (Integer) d.getClass().getMethod("getType").invoke(d);
                if (isHeadphoneType(t)) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Lo llama el gancho smali: true = dibujar la fila. */
    public static boolean present() {
        return headphoneDevice() != null;
    }

    /** Titulo de la fila: nombre del producto (p. ej. "Soundpeats C30") o "Audifonos". */
    public static String title() {
        try {
            Object d = headphoneDevice();
            if (d != null) {
                Object n = d.getClass().getMethod("getProductName").invoke(d);
                if (n != null && n.toString().trim().length() > 0) return n.toString();
            }
        } catch (Throwable ignored) {
        }
        return "Audífonos";
    }

    /** true si la salida de audio de musica va ahora a unos audifonos (Android 13+; si falla, false). */
    private static boolean activeOnHeadphones() {
        try {
            if (forcedSpeaker != null) {
                if (headphoneDevice() != null) return false;
                forcedSpeaker = null;
            }
            if (forcedHeadphone != null) {
                if (headphoneDevice() != null) return true;
                forcedHeadphone = null;
            }
            Object am = audio();
            Class<?> ab = Class.forName("android.media.AudioAttributes$Builder");
            Object b = ab.getConstructor().newInstance();
            ab.getMethod("setUsage", int.class).invoke(b, 1);
            Object attrs = ab.getMethod("build").invoke(b);
            java.util.List l = (java.util.List) am.getClass()
                .getMethod("getAudioDevicesForAttributes", Class.forName("android.media.AudioAttributes"))
                .invoke(am, attrs);
            if (l == null || l.isEmpty()) return false;
            Object d = l.get(0);
            return isHeadphoneType((Integer) d.getClass().getMethod("getType").invoke(d));
        } catch (Throwable t) {
            return false;
        }
    }

    public static String subtitle() {
        return activeOnHeadphones() ? "Reproduciendo ahora" : "Toca para reproducir aquí";
    }

    /** Devuelve un d43 (interfaz con a()Object) que cambia la salida (0.6.61: cf3; antes he3). Se crea una sola vez. */
    public static Object click() {
        try {
            synchronized (HeadphoneRoute.class) {
                if (clickProxy == null) {
                    Class<?> f = Class.forName("bk3");
                    clickProxy = Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                            String n = m.getName();
                            if (n.equals("a") && (args == null || args.length == 0)) {
                                try {
                                    setRoute(false);
                                } catch (Throwable ignored) {
                                }
                                bump();
                                return null;
                            }
                            if (n.equals("hashCode")) return System.identityHashCode(proxy);
                            if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                            if (n.equals("toString")) return "HeadphoneRouteClick";
                            return null;
                        }
                    });
                }
                return clickProxy;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    // ---- v0.20.168 (0.6.55): la fila se dibuja por reflexion (el gancho smali solo llama a row) ----
    // es1.g llama a row(composer, color) justo despues de "Este dispositivo" y del separador. Como Compose exige que lo
    // condicional vaya en un grupo, se abre un grupo de reemplazo (iq1.d0(key)) y se cierra con iq1.q(false), igual que
    // hace el compilador con un `if`: clave 0x2a1b0c01 con la fila, 0x2a1b0c02 sin ella. Todo lo que puede fallar se
    // resuelve ANTES de abrir el grupo (si falla, no se emite nada, siempre igual); dentro del grupo el cierre va en finally.
    private static boolean rowReady;
    private static boolean rowFailed;
    private static Method rowFn;      // hs1.e(icono, titulo, subtitulo, J, J, icono, J, Z, Z, click, composer, I, I)
    private static Method grpStart;   // fr1.d0(I) (0.6.57: iq1)
    private static Method grpEnd;     // fr1.q(Z) (0.6.57: iq1)
    private static Method iconPhones; // py1.P() = icono de audifonos (0.6.57: rx1.N)
    private static Method iconSpeaker; // wr7.O() = icono "activo" (bocina) (0.6.57: vn7.P)

    private static boolean rowInit() {
        if (rowReady) return true;
        if (rowFailed) return false;
        try {
            Class<?> hs1 = Class.forName("jw1");
            Method e = null;
            for (Method m : hs1.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (m.getName().equals("e") && p.length == 13 && p[1] == String.class && p[2] == String.class
                    && p[3] == long.class && p[4] == long.class && p[6] == long.class && p[7] == boolean.class
                    && p[8] == boolean.class && p[11] == int.class && p[12] == int.class) {
                    e = m;
                    break;
                }
            }
            Class<?> iq1 = Class.forName("ju1");
            Method gs = iq1.getDeclaredMethod("d0", int.class);
            Method ge = iq1.getDeclaredMethod("q", boolean.class);
            Method ip = Class.forName("j72").getDeclaredMethod("A");
            Method is = Class.forName("fb8").getDeclaredMethod("t");
            if (e == null) throw new IllegalStateException("dt1.e");
            e.setAccessible(true);
            gs.setAccessible(true);
            ge.setAccessible(true);
            ip.setAccessible(true);
            is.setAccessible(true);
            rowFn = e;
            grpStart = gs;
            grpEnd = ge;
            iconPhones = ip;
            iconSpeaker = is;
            rowReady = true;
            return true;
        } catch (Throwable t) {
            rowFailed = true;
            return false;
        }
    }

    /** Lo llama el gancho smali de es1.g: dibuja la fila de audifonos (o un grupo vacio si no hay audifonos). */
    public static void row(Object composer, long color) {
        try {
            if (composer == null) return;
            tick(); // suscribe la hoja a bump(): se redibuja al tocar una fila
            if (!rowInit()) return;
            if (!present()) {
                grpStart.invoke(composer, 0x2a1b0c02);
                grpEnd.invoke(composer, false);
                return;
            }
            boolean act = activeOnHeadphones();
            Object icon = iconPhones.invoke(null);
            // v0.20.186: el parametro `act` de hs1.e NO es "esta activo": dibuja la tarjeta de dispositivo remoto (titulo de 30 sp).
            // "Este dispositivo" manda siempre false; aqui igual. La marca de activo es el icono de audifonos a la derecha.
            Object trailing = act ? iconPhones.invoke(null) : null;
            Object clk = click();
            String ttl = title();
            String sub = subtitle();
            grpStart.invoke(composer, 0x2a1b0c01);
            try {
                rowFn.invoke(null, icon, ttl, sub, 0L, color, trailing, color, false, false, clk, composer, 48, 264);
            } finally {
                grpEnd.invoke(composer, false);
            }
        } catch (Throwable t) {
            // la app queda como estaba si algo falla
        }
    }

    // ---- v1.92.1: cambio directo con setPreferredDevice de los AudioSink ----

    private static final java.util.List<java.lang.ref.WeakReference<Object>> SINKS =
        new java.util.ArrayList<java.lang.ref.WeakReference<Object>>();
    /** Dispositivo preferido que pusimos (la bocina del telefono) o null si seguimos al sistema. */
    private static Object forcedSpeaker;
    /** v1.92.6: audifono exacto (A2DP primero) que pusimos como preferido, o null si seguimos al sistema. */
    private static Object forcedHeadphone;

    /** Lo llama el gancho smali al final del constructor de cada AudioSink de Eclipse. */
    public static void register(Object sink) {
        try {
            synchronized (SINKS) {
                SINKS.add(new java.lang.ref.WeakReference<Object>(sink));
            }
            if (forcedSpeaker != null) applyTo(sink, forcedSpeaker);
            else if (forcedHeadphone != null) applyTo(sink, forcedHeadphone);
        } catch (Throwable ignored) {
        }
    }

    private static boolean applyTo(Object sink, Object device) {
        try {
            Method m = sink.getClass().getMethod("setPreferredDevice", Class.forName("android.media.AudioDeviceInfo"));
            m.invoke(sink, device);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static Object builtinSpeaker() {
        try {
            Object am = audio();
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                if ((Integer) d.getClass().getMethod("getType").invoke(d) == BUILTIN_SPEAKER) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Audifono exacto para setPreferredDevice: A2DP primero, luego LE, cable, USB. SCO NO (suena en la bocina). null si no hay. */
    private static Object preferredHeadphone() {
        try {
            Object am = audio();
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            int[] order = {8, 26, 3, 4, 22, 23};
            for (int want : order) {
                for (Object d : devs) {
                    if ((Integer) d.getClass().getMethod("getType").invoke(d) == want) return d;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** true si hay que mostrar el telefono como NO activo (Eclipse dice "reproduciendo aqui" pero suena en audifonos). */
    public static boolean phoneInactive(Object trailingIcon) {
        return trailingIcon != null && activeOnHeadphones();
    }

    public static String tapText() {
        return "Toca para reproducir aquí";
    }

    public static boolean active() {
        return activeOnHeadphones();
    }

    /** v0.20.9: true si el usuario forzo la bocina del telefono y siguen conectados los audifonos (suena en el telefono). */
    public static boolean speakerForced() {
        try {
            return forcedSpeaker != null && headphoneDevice() != null;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * v0.20.9: lo llama el gancho de ow0.<init> con el nombre de salida que calculo Eclipse (el texto de abajo, p. ej.
     * "SOUNDPEATS C30"). Si el usuario fuerza la bocina con la hoja de Connect se muestra "Este dispositivo"; si fuerza
     * los audifonos, el nombre del audifono; en cualquier otro caso se deja el texto de Eclipse. Barato: sin ruta forzada
     * no consulta nada.
     */
    public static String outputName(String original) {
        try {
            if (forcedSpeaker == null && forcedHeadphone == null) return original;
            if (headphoneDevice() == null) return original;
            if (forcedSpeaker != null) return "Este dispositivo";
            return title();
        } catch (Throwable t) {
            return original;
        }
    }

    /** toSpeaker=true: forzar la bocina del telefono; false: audifonos (seguir al sistema). Idempotente. */
    private static void setRoute(boolean toSpeaker) throws Exception {
        Object device = null;
        if (!toSpeaker) device = preferredHeadphone();
        if (toSpeaker) {
            if (headphoneDevice() == null) return; // sin audifonos ya suena en el telefono
            device = builtinSpeaker();
            if (device == null) {
                openSwitcher();
                return;
            }
        }
        int ok = 0;
        java.util.List<Object> live = new java.util.ArrayList<Object>();
        synchronized (SINKS) {
            java.util.Iterator<java.lang.ref.WeakReference<Object>> it = SINKS.iterator();
            while (it.hasNext()) {
                Object o = it.next().get();
                if (o == null) it.remove();
                else live.add(o);
            }
        }
        for (Object o : live) if (applyTo(o, device)) ok++;
        if (ok == 0) {
            openSwitcher();
            return;
        }
        if (toSpeaker) {
            forcedSpeaker = device;
            forcedHeadphone = null;
        } else {
            forcedSpeaker = null;
            forcedHeadphone = device;
        }
    }

    /** v1.92.2: envuelve el click de "Este dispositivo": primero fuerza la bocina, luego corre el click original. */
    public static Object wrapPhone(final Object original) {
        try {
            Class<?> f = Class.forName("bk3");
            return Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                @Override
                public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                    String n = m.getName();
                    if (n.equals("a") && (args == null || args.length == 0)) {
                        try {
                            setRoute(true);
                        } catch (Throwable ignored) {
                        }
                        bump();
                        return original == null ? null : original.getClass().getMethod("a").invoke(original);
                    }
                    if (n.equals("hashCode")) return System.identityHashCode(proxy);
                    if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                    if (n.equals("toString")) return "PhoneRowClick";
                    return null;
                }
            });
        } catch (Throwable t) {
            return original;
        }
    }

    // ---- v1.92.4: la hoja se redibuja sola al cambiar la salida ----
    // Eclipse (Compose) solo redibuja cuando cambia un "estado" que se leyo al dibujar. z46 es su estado entero
    // (ParcelableSnapshotMutableIntState: <init>(I), g()I = leer, h(I)V = escribir). Leer tick() al dibujar la hoja la
    // suscribe; bump() lo cambia al tocar una fila y fuerza el redibujado. Todo por reflexion; si falla, queda como antes.
    private static Object tickState;
    private static java.lang.reflect.Method tickGet;
    private static java.lang.reflect.Method tickSet;
    private static boolean tickFailed;

    private static boolean tickInit() {
        if (tickState != null) return true;
        if (tickFailed) return false;
        try {
            Class<?> c = Class.forName("me7");
            Object st = c.getConstructor(int.class).newInstance(0);
            Method get = null;
            Method set = null;
            for (Method m : c.getDeclaredMethods()) {
                Class<?>[] pt = m.getParameterTypes();
                if (pt.length == 0 && m.getReturnType() == int.class && !m.getName().equals("describeContents")
                    && !m.getName().equals("hashCode")) get = m;
                if (pt.length == 1 && pt[0] == int.class && m.getReturnType() == void.class) set = m;
            }
            if (get == null || set == null) {
                tickFailed = true;
                return false;
            }
            get.setAccessible(true);
            set.setAccessible(true);
            tickGet = get;
            tickSet = set;
            tickState = st;
            return true;
        } catch (Throwable t) {
            tickFailed = true;
            return false;
        }
    }

    /** Lo llama el gancho smali al dibujar la hoja: leer el estado la suscribe a sus cambios. */
    public static int tick() {
        try {
            if (!tickInit()) return 0;
            return (Integer) tickGet.invoke(tickState);
        } catch (Throwable t) {
            return 0;
        }
    }

    /** Cambia el estado: Compose redibuja la hoja y vuelve a leer los textos. */
    private static void bump() {
        try {
            if (!tickInit()) return;
            int v = (Integer) tickGet.invoke(tickState);
            tickSet.invoke(tickState, v + 1);
        } catch (Throwable ignored) {
        }
    }

    private static void openSwitcher() {
        try {
            Object ctx = app();
            Class<?> mr2c = Class.forName("android.media.MediaRouter2");
            Object mr2 = mr2c.getMethod("getInstance", Class.forName("android.content.Context")).invoke(null, ctx);
            mr2c.getMethod("showSystemOutputSwitcher").invoke(mr2);
        } catch (Throwable ignored) {
        }
    }
}
