package app.eclipse.extension.player;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;

/**
 * v1.92.0: fila "Audifonos" en la hoja "Conectar a un dispositivo" de Eclipse.
 * La fila solo se dibuja cuando hay audifonos conectados (lo decide {@link #present()}).
 * Al tocarla se intenta cambiar la salida de audio con MediaRouter2 (transferTo); si el sistema no lo
 * permite, a los ~0,8 s se abre el selector de salida del sistema (showSystemOutputSwitcher).
 * Todo por reflexion y con try/catch: si algo falla la app queda como estaba.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class HeadphoneRoute {
    private static final int BUILTIN_SPEAKER = 2;
    private static Object clickProxy;

    private HeadphoneRoute() {}

    private static Object app() throws Exception {
        return Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
    }

    private static boolean isHeadphoneType(int t) {
        return t == 3 || t == 4 || t == 7 || t == 8 || t == 22 || t == 23 || t == 26;
    }

    private static Object audio() throws Exception {
        Object a = app();
        return a == null ? null : a.getClass().getMethod("getSystemService", String.class).invoke(a, "audio");
    }

    /** Primer dispositivo de salida de audifonos conectado (AudioDeviceInfo) o null. */
    private static Object headphoneDevice() {
        try {
            Object am = audio();
            if (am == null) return null;
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                int t = (Integer) d.getClass().getMethod("getType").invoke(d);
                if (isHeadphoneType(t)) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Lo llama el gancho smali: true = dibujar la fila. */
    public static boolean present() {
        return headphoneDevice() != null;
    }

    /** Titulo de la fila: nombre del producto (p. ej. "Soundpeats C30") o "Audifonos". */
    public static String title() {
        try {
            Object d = headphoneDevice();
            if (d != null) {
                Object n = d.getClass().getMethod("getProductName").invoke(d);
                if (n != null && n.toString().trim().length() > 0) return n.toString();
            }
        } catch (Throwable ignored) {
        }
        return "Audífonos";
    }

    /** true si la salida de audio de musica va ahora a unos audifonos (Android 13+; si falla, false). */
    private static boolean activeOnHeadphones() {
        try {
            Object am = audio();
            Class<?> ab = Class.forName("android.media.AudioAttributes$Builder");
            Object b = ab.getConstructor().newInstance();
            ab.getMethod("setUsage", int.class).invoke(b, 1);
            Object attrs = ab.getMethod("build").invoke(b);
            java.util.List l = (java.util.List) am.getClass()
                .getMethod("getAudioDevicesForAttributes", Class.forName("android.media.AudioAttributes"))
                .invoke(am, attrs);
            if (l == null || l.isEmpty()) return false;
            Object d = l.get(0);
            return isHeadphoneType((Integer) d.getClass().getMethod("getType").invoke(d));
        } catch (Throwable t) {
            return false;
        }
    }

    public static String subtitle() {
        return activeOnHeadphones() ? "Reproduciendo ahora" : "Toca para reproducir aquí";
    }

    /** Devuelve un d43 (interfaz con a()Object) que cambia la salida. Se crea una sola vez. */
    public static Object click() {
        try {
            synchronized (HeadphoneRoute.class) {
                if (clickProxy == null) {
                    Class<?> f = Class.forName("d43");
                    clickProxy = Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                            String n = m.getName();
                            if (n.equals("a") && (args == null || args.length == 0)) {
                                try {
                                    switchRoute();
                                } catch (Throwable ignored) {
                                }
                                return null;
                            }
                            if (n.equals("hashCode")) return System.identityHashCode(proxy);
                            if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                            if (n.equals("toString")) return "HeadphoneRouteClick";
                            return null;
                        }
                    });
                }
                return clickProxy;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    private static void switchRoute() throws Exception {
        final Object ctx = app();
        if (ctx == null) return;
        Class<?> mr2c = Class.forName("android.media.MediaRouter2");
        final Object mr2 = mr2c.getMethod("getInstance", Class.forName("android.content.Context")).invoke(null, ctx);
        final boolean toSpeaker = activeOnHeadphones();
        Object target = null;
        try {
            Collection routes = (Collection) mr2c.getMethod("getRoutes").invoke(mr2);
            for (Object r : routes) {
                int t = (Integer) r.getClass().getMethod("getType").invoke(r);
                if (toSpeaker ? t == BUILTIN_SPEAKER : isHeadphoneType(t)) {
                    target = r;
                    break;
                }
            }
            if (target != null) mr2c.getMethod("transferTo", Class.forName("android.media.MediaRoute2Info")).invoke(mr2, target);
        } catch (Throwable ignored) {
        }
        // Si el sistema no cambio la salida, abrir el selector del sistema.
        Class<?> hc = Class.forName("android.os.Handler");
        Class<?> lc = Class.forName("android.os.Looper");
        Object h = hc.getConstructor(lc).newInstance(lc.getMethod("getMainLooper").invoke(null));
        Runnable check = new Runnable() {
            @Override
            public void run() {
                try {
                    if (activeOnHeadphones() == toSpeaker) {
                        Class.forName("android.media.MediaRouter2").getMethod("showSystemOutputSwitcher").invoke(mr2);
                    }
                } catch (Throwable ignored) {
                }
            }
        };
        hc.getMethod("postDelayed", Runnable.class, long.class).invoke(h, check, 800L);
    }
}
