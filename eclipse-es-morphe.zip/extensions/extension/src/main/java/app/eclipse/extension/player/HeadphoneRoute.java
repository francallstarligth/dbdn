package app.eclipse.extension.player;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Collection;

/**
 * v1.92.0: fila "Audifonos" en la hoja "Conectar a un dispositivo" de Eclipse.
 * La fila solo se dibuja cuando hay audifonos conectados (lo decide {@link #present()}).
 * v1.92.1: al tocarla se cambia la salida con AudioTrack.setPreferredDevice, llamando a setPreferredDevice de los
 * AudioSink de Eclipse (kd3 / vw1, que se registran en su constructor). Si no hay sink o falla, se abre el
 * selector de salida del sistema (MediaRouter2.showSystemOutputSwitcher).
 * Todo por reflexion y con try/catch: si algo falla la app queda como estaba.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class HeadphoneRoute {
    private static final int BUILTIN_SPEAKER = 2;
    private static Object clickProxy;

    private HeadphoneRoute() {}

    private static Object app() throws Exception {
        return Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
    }

    private static boolean isHeadphoneType(int t) {
        return t == 3 || t == 4 || t == 7 || t == 8 || t == 22 || t == 23 || t == 26;
    }

    private static Object audio() throws Exception {
        Object a = app();
        return a == null ? null : a.getClass().getMethod("getSystemService", String.class).invoke(a, "audio");
    }

    /** Primer dispositivo de salida de audifonos conectado (AudioDeviceInfo) o null. */
    private static Object headphoneDevice() {
        try {
            Object am = audio();
            if (am == null) return null;
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                int t = (Integer) d.getClass().getMethod("getType").invoke(d);
                if (isHeadphoneType(t)) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** Lo llama el gancho smali: true = dibujar la fila. */
    public static boolean present() {
        return headphoneDevice() != null;
    }

    /** Titulo de la fila: nombre del producto (p. ej. "Soundpeats C30") o "Audifonos". */
    public static String title() {
        try {
            Object d = headphoneDevice();
            if (d != null) {
                Object n = d.getClass().getMethod("getProductName").invoke(d);
                if (n != null && n.toString().trim().length() > 0) return n.toString();
            }
        } catch (Throwable ignored) {
        }
        return "Audífonos";
    }

    /** true si la salida de audio de musica va ahora a unos audifonos (Android 13+; si falla, false). */
    private static boolean activeOnHeadphones() {
        try {
            if (forcedSpeaker != null) {
                if (headphoneDevice() != null) return false;
                forcedSpeaker = null;
            }
            Object am = audio();
            Class<?> ab = Class.forName("android.media.AudioAttributes$Builder");
            Object b = ab.getConstructor().newInstance();
            ab.getMethod("setUsage", int.class).invoke(b, 1);
            Object attrs = ab.getMethod("build").invoke(b);
            java.util.List l = (java.util.List) am.getClass()
                .getMethod("getAudioDevicesForAttributes", Class.forName("android.media.AudioAttributes"))
                .invoke(am, attrs);
            if (l == null || l.isEmpty()) return false;
            Object d = l.get(0);
            return isHeadphoneType((Integer) d.getClass().getMethod("getType").invoke(d));
        } catch (Throwable t) {
            return false;
        }
    }

    public static String subtitle() {
        return activeOnHeadphones() ? "Reproduciendo ahora" : "Toca para reproducir aquí";
    }

    /** Devuelve un d43 (interfaz con a()Object) que cambia la salida. Se crea una sola vez. */
    public static Object click() {
        try {
            synchronized (HeadphoneRoute.class) {
                if (clickProxy == null) {
                    Class<?> f = Class.forName("d43");
                    clickProxy = Proxy.newProxyInstance(f.getClassLoader(), new Class<?>[] {f}, new InvocationHandler() {
                        @Override
                        public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
                            String n = m.getName();
                            if (n.equals("a") && (args == null || args.length == 0)) {
                                try {
                                    switchRoute();
                                } catch (Throwable ignored) {
                                }
                                return null;
                            }
                            if (n.equals("hashCode")) return System.identityHashCode(proxy);
                            if (n.equals("equals")) return proxy == (args == null ? null : args[0]);
                            if (n.equals("toString")) return "HeadphoneRouteClick";
                            return null;
                        }
                    });
                }
                return clickProxy;
            }
        } catch (Throwable t) {
            return null;
        }
    }

    // ---- v1.92.1: cambio directo con setPreferredDevice de los AudioSink ----

    private static final java.util.List<java.lang.ref.WeakReference<Object>> SINKS =
        new java.util.ArrayList<java.lang.ref.WeakReference<Object>>();
    /** Dispositivo preferido que pusimos (la bocina del telefono) o null si seguimos al sistema. */
    private static Object forcedSpeaker;

    /** Lo llama el gancho smali al final del constructor de cada AudioSink de Eclipse. */
    public static void register(Object sink) {
        try {
            synchronized (SINKS) {
                SINKS.add(new java.lang.ref.WeakReference<Object>(sink));
            }
            if (forcedSpeaker != null) applyTo(sink, forcedSpeaker);
        } catch (Throwable ignored) {
        }
    }

    private static boolean applyTo(Object sink, Object device) {
        try {
            Method m = sink.getClass().getMethod("setPreferredDevice", Class.forName("android.media.AudioDeviceInfo"));
            m.invoke(sink, device);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private static Object builtinSpeaker() {
        try {
            Object am = audio();
            Object[] devs = (Object[]) am.getClass().getMethod("getDevices", int.class).invoke(am, 2);
            for (Object d : devs) {
                if ((Integer) d.getClass().getMethod("getType").invoke(d) == BUILTIN_SPEAKER) return d;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

    /** true si hay que mostrar el telefono como NO activo (Eclipse dice "reproduciendo aqui" pero suena en audifonos). */
    public static boolean phoneInactive(Object trailingIcon) {
        return trailingIcon != null && activeOnHeadphones();
    }

    public static String tapText() {
        return "Toca para reproducir aquí";
    }

    public static boolean active() {
        return activeOnHeadphones();
    }

    private static void switchRoute() throws Exception {
        boolean toSpeaker = activeOnHeadphones();
        Object device = toSpeaker ? builtinSpeaker() : null;
        if (toSpeaker && device == null) {
            openSwitcher();
            return;
        }
        int ok = 0;
        java.util.List<Object> live = new java.util.ArrayList<Object>();
        synchronized (SINKS) {
            java.util.Iterator<java.lang.ref.WeakReference<Object>> it = SINKS.iterator();
            while (it.hasNext()) {
                Object o = it.next().get();
                if (o == null) it.remove();
                else live.add(o);
            }
        }
        for (Object o : live) if (applyTo(o, device)) ok++;
        if (ok == 0) {
            openSwitcher();
            return;
        }
        forcedSpeaker = device;
    }

    private static void openSwitcher() {
        try {
            Object ctx = app();
            Class<?> mr2c = Class.forName("android.media.MediaRouter2");
            Object mr2 = mr2c.getMethod("getInstance", Class.forName("android.content.Context")).invoke(null, ctx);
            mr2c.getMethod("showSystemOutputSwitcher").invoke(mr2);
        } catch (Throwable ignored) {
        }
    }
}
