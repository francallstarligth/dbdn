package app.eclipse.extension.canvas;

import android.os.SystemClock;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;

/**
 * Ayuda de la opcion "Sincronizar inicio" del parche "Custom: Canvas detras del fondo Blurred Cover".
 *
 * Eclipse 0.6.47: cada llamada a xi6.h(url, playing, modifier, composer, int) crea su PROPIO ExoPlayer y solo dibuja
 * el video cuando su indicador "primer cuadro listo" (un estado de Compose, en5) pasa a true. La portada nitida y el
 * fondo borroso son dos llamadas distintas, asi que cada una aparece cuando le toca (a veces una antes que la otra).
 *
 * Gancho (smali, 1 sitio en xi6.h): justo despues de leer ese indicador se llama gate(player, estado, url, listo) y
 * se usa el resultado en vez del indicador. gate devuelve false mientras la pareja (la otra llamada con la misma URL:
 * el fondo borroso espera a la portada y la portada espera al fondo) todavia no tiene su primer cuadro. Con false,
 * Eclipse (y el parche "Portadas animadas sin parpadeo") dibujan la portada quieta, como mientras carga. Al leer el
 * estado de la pareja dentro de gate, Compose vuelve a dibujar esta llamada cuando la pareja pasa a listo, asi que
 * las dos aparecen en el mismo momento.
 *
 * Roles: el fondo borroso es el que llama BlurredCanvasBackground.draw (pone bgCall = true durante la llamada); todo
 * lo demas es "portada". Una portada NO espera a otra portada (asi el minireproductor no se acopla con el
 * reproductor grande). Solo se emparejan llamadas creadas a menos de PAIR_MS una de otra.
 *
 * Fase del bucle: cuando los dos estan listos (y antes de mostrarlos) se hace seekTo(0) a los dos una sola vez, asi
 * empiezan y siguen alineados (los dos videos son el mismo y se repiten con el mismo periodo).
 *
 * Limites conocidos: si el video de la pareja falla y nunca llega a listo, esta llamada se queda en la portada quieta
 * (no hay tiempo limite, porque sin un cambio de estado Compose no vuelve a dibujar). Si algo falla aqui dentro,
 * devuelve el indicador original sin tocarlo.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasSync {
    private static final String TAG = "CanvasSync";
    /** Dos llamadas se consideran pareja si se crearon con menos de esto entre ellas. */
    private static final long PAIR_MS = 2500;
    private static final int MAX_ENTRIES = 16;
    private static final long MAX_AGE_MS = 10 * 60 * 1000;

    /** La pone BlurredCanvasBackground.draw alrededor de su llamada a xi6.h (mismo hilo, mientras compone). */
    public static volatile boolean bgCall;

    private static final class Entry {
        final WeakReference<Object> player;
        final Object state;   // en5 (estado "primer cuadro listo")
        final String url;
        final boolean bg;
        final long born;
        /** true cuando ya se reinicio este video junto con su pareja (se hace una sola vez). */
        volatile boolean synced;

        Entry(Object player, Object state, String url, boolean bg, long born) {
            this.player = new WeakReference<>(player);
            this.state = state;
            this.url = url;
            this.bg = bg;
            this.born = born;
        }
    }

    private static final ArrayList<Entry> LIST = new ArrayList<>();
    private static Method getValue;
    private static boolean tried;
    private static Method seekTo;       // u7a.Y(J)V = Player.seekTo(long) en 0.6.47 (BasePlayer: L2(J, 5))
    private static boolean seekTried;

    private CanvasSync() {}

    private static synchronized Method valueMethod(Object state) {
        if (!tried) {
            tried = true;
            try {
                getValue = Class.forName("zk8").getMethod("getValue");
            } catch (Throwable t) {
                Log.w(TAG, "sin zk8.getValue: " + t);
                getValue = null;
            }
        }
        if (getValue != null) return getValue;
        try {
            Method m = state.getClass().getMethod("getValue");
            m.setAccessible(true);
            return m;
        } catch (Throwable t) {
            return null;
        }
    }


    /** Lleva el video de este reproductor al inicio (u7a.Y(J)V). Si no se puede, no hace nada. */
    private static void rewind(Object player) {
        try {
            synchronized (CanvasSync.class) {
                if (!seekTried) {
                    seekTried = true;
                    try {
                        seekTo = Class.forName("u7a").getMethod("Y", long.class);
                    } catch (Throwable t) {
                        Log.w(TAG, "sin u7a.Y (no se sincroniza la fase): " + t);
                        seekTo = null;
                    }
                }
            }
            if (seekTo != null && player != null) seekTo.invoke(player, 0L);
        } catch (Throwable t) {
            Log.w(TAG, "rewind fallo: " + t);
        }
    }

    /**
     * @param player ExoPlayer de esta llamada de xi6.h
     * @param state  en5: indicador "primer cuadro listo" de esta llamada
     * @param url    URL del Canvas
     * @param ready  valor original del indicador
     * @return lo que Eclipse debe usar como "listo": ready y, si hay pareja, que la pareja tambien este lista
     */
    public static boolean gate(Object player, Object state, String url, boolean ready) {
        try {
            if (player == null || state == null || url == null) return ready;
            long now = SystemClock.uptimeMillis();
            Entry me = null;
            Entry[] snapshot;
            synchronized (LIST) {
                for (int i = LIST.size() - 1; i >= 0; i--) {
                    Entry e = LIST.get(i);
                    Object p = e.player.get();
                    if (p == null || now - e.born > MAX_AGE_MS) {
                        LIST.remove(i);
                        continue;
                    }
                    if (p == player) me = e;
                }
                if (me == null) {
                    me = new Entry(player, state, url, bgCall, now);
                    LIST.add(me);
                    while (LIST.size() > MAX_ENTRIES) LIST.remove(0);
                }
                snapshot = LIST.toArray(new Entry[0]);
            }
            if (!ready) return false;

            Method read = valueMethod(state);
            if (read == null) return ready;
            boolean blocked = false;
            ArrayList<Entry> paired = new ArrayList<>();
            for (Entry o : snapshot) {
                if (o == me || o.bg == me.bg || !o.url.equals(me.url)) continue;
                // Una portada solo espera al fondo; el fondo solo espera a portadas.
                if (Math.abs(o.born - me.born) > PAIR_MS) continue;
                if (o.player.get() == null) continue;
                paired.add(o);
                // Leer el estado de la pareja dentro de la composicion: Compose vuelve a dibujar esta llamada
                // cuando cambie.
                Object v = read.invoke(o.state);
                if (!Boolean.TRUE.equals(v)) blocked = true;
            }
            if (blocked) return false;
            // Los dos estan listos: se llevan los dos videos al inicio a la vez (una sola vez por pareja), asi
            // aparecen juntos Y siguen alineados en el bucle. Todavia no se ve ninguno, asi que el salto no se nota.
            if (!paired.isEmpty() && !me.synced) {
                me.synced = true;
                rewind(player);
                for (Entry o : paired) {
                    if (!o.synced) {
                        o.synced = true;
                        rewind(o.player.get());
                    }
                }
            }
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "gate fallo: " + t);
            return ready;
        }
    }
}
