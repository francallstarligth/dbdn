package app.eclipse.extension.player;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.graphics.Insets;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimationControlListener;
import android.view.WindowInsetsAnimationController;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.57: `oc7` guarda banderas estaticas (MutableStateFlow<Boolean>); `oc7.f()` pone `wu7.a` en true (abrir el
 * reproductor) y `wu7.a()` / `oc7.b()` las ponen todas en false. Gancho unico: inicio de `oc7.f()` llama a start().
 * start() arranca (una vez) un reloj en el hilo principal que cada 700 ms lee `wu7.a` por reflexion y pone o quita
 * FLAG_KEEP_SCREEN_ON en la ventana de la actividad visible. Asi tambien se apaga al cerrar el reproductor por
 * cualquier camino. Todo con try/catch: si algo falla, no hace nada y la pantalla se comporta como siempre.
 */
public final class KeepAwake {
    private static final String TAG = "KeepAwake";
    private static final long PERIODO_MS = 700L;

    private static boolean arrancado;
    private static boolean lifecycleOk;
    private static WeakReference<Activity> actual;
    private static WeakReference<Activity> conFlag;
    private static Handler handler;
    private static Object flujoAbierto; // wu7.a (cq9 = MutableStateFlow<Boolean>)
    private static Method getValor;
    private static boolean falloFlujo;

    // v0.20.383 (SIN COMPILAR NI PROBAR): ocultar la barra de estado mientras el reproductor grande esta abierto.
    private static volatile boolean hideBar;
    private static WeakReference<Activity> barOculta;
    private static long abiertoDesdeMs;   // v0.20.385: desde cuando esta abierto el reproductor (0 = cerrado)
    private static long arribaDesdeMs;   // v0.20.386: desde cuando la hoja esta arriba del todo (0 = no)
    private static long cerradoMs;        // v0.20.385: desde cuando se cerro (0 = abierto)
    private static long rapidoHasta;      // v0.20.385: hasta cuando se revisa cada 100 ms
    private static final long PERIODO_RAPIDO_MS = 40L;

    private KeepAwake() {}

    /** Gancho del parche "Reproductor: ocultar la barra de estado" (inicio de ex7.e(), abrir el reproductor). */
    public static void startHideBar() {
        try {
            hideBar = true;
            rapidoHasta = SystemClock.uptimeMillis() + 3000L;
            start();
            if (handler != null) {
                handler.post(new Runnable() {
                    @Override public void run() { revisar(); }
                });
            }
        } catch (Throwable t) {
            Log.w(TAG, "startHideBar fallo", t);
        }
    }


    // ---- v0.20.387: desvanecido de la barra (la barra NO se desliza: se queda en su sitio y cambia su transparencia) ----
    private static final long OCULTAR_MS = 350L;
    private static final long MOSTRAR_MS = 200L;
    private static WindowInsetsAnimationController ctl;
    private static Insets insetsMostrado;
    private static ValueAnimator anim;
    private static float alphaAhora = 1f;
    private static boolean pidiendo;
    private static boolean destinoOcultar;
    private static WeakReference<Activity> actAnim;

    private static void ocultarBarra(Activity a) { animarBarra(a, true); }

    private static void mostrarBarra(Activity a) { animarBarra(a, false); }

    private static void animarBarra(Activity a, boolean ocultar) {
        if (Build.VERSION.SDK_INT < 30) {
            if (ocultar) ocultarDirecto(a); else mostrarDirecto(a);
            return;
        }
        try {
            actAnim = new WeakReference<Activity>(a);
            if (ctl != null) { empujar(ocultar); return; }
            destinoOcultar = ocultar;
            if (pidiendo) return;
            Window w = a.getWindow();
            WindowInsetsController c = w == null ? null : w.getInsetsController();
            if (c == null) { if (ocultar) ocultarDirecto(a); else mostrarDirecto(a); return; }
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            pidiendo = true;
            alphaAhora = ocultar ? 1f : 0f;
            c.controlWindowInsetsAnimation(WindowInsets.Type.statusBars(), -1L, null, new CancellationSignal(),
                    new BarraListener());
        } catch (Throwable t) {
            pidiendo = false;
            Log.w(TAG, "animarBarra fallo", t);
            if (ocultar) ocultarDirecto(a); else mostrarDirecto(a);
        }
    }

    /** Mueve la transparencia de alphaAhora al destino; al final deja la barra en su estado real. */
    private static void empujar(final boolean ocultar) {
        try {
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
            final WindowInsetsAnimationController c = ctl;
            if (c == null || insetsMostrado == null) return;
            final float destino = ocultar ? 0f : 1f;
            final float desde = alphaAhora;
            long dur = (long) ((ocultar ? OCULTAR_MS : MOSTRAR_MS) * Math.abs(destino - desde));
            if (dur < 1L) { terminar(c, ocultar); return; }
            ValueAnimator va = ValueAnimator.ofFloat(desde, destino);
            va.setDuration(dur);
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator v) {
                    try {
                        float x = ((Float) v.getAnimatedValue()).floatValue();
                        alphaAhora = x;
                        c.setInsetsAndAlpha(insetsMostrado, x, x);
                    } catch (Throwable ignored) { }
                }
            });
            va.addListener(new AnimatorListenerAdapter() {
                private boolean cancelado;
                @Override public void onAnimationCancel(Animator a) { cancelado = true; }
                @Override public void onAnimationEnd(Animator a) {
                    if (cancelado) return;
                    terminar(c, ocultar);
                }
            });
            anim = va;
            va.start();
        } catch (Throwable t) {
            Log.w(TAG, "empujar fallo", t);
        }
    }

    private static void terminar(WindowInsetsAnimationController c, boolean ocultar) {
        try {
            alphaAhora = ocultar ? 0f : 1f;
            ctl = null;
            anim = null;
            c.finish(!ocultar);
        } catch (Throwable t) {
            Log.w(TAG, "terminar fallo", t);
        }
    }

    private static final class BarraListener implements WindowInsetsAnimationControlListener {
        @Override public void onReady(WindowInsetsAnimationController controller, int types) {
            try {
                pidiendo = false;
                ctl = controller;
                insetsMostrado = controller.getShownStateInsets();
                controller.setInsetsAndAlpha(insetsMostrado, alphaAhora, alphaAhora);
                empujar(destinoOcultar);
            } catch (Throwable t) {
                Log.w(TAG, "onReady fallo", t);
            }
        }
        @Override public void onFinished(WindowInsetsAnimationController controller) { }
        @Override public void onCancelled(WindowInsetsAnimationController controller) {
            // el sistema no dejo controlar la transparencia: se hace como antes (directo)
            try {
                pidiendo = false;
                ctl = null;
                if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
                Activity a = actAnim == null ? null : actAnim.get();
                if (a != null) { if (destinoOcultar) ocultarDirecto(a); else mostrarDirecto(a); }
            } catch (Throwable t) {
                Log.w(TAG, "onCancelled fallo", t);
            }
        }
    }

    private static void ocultarDirecto(Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.statusBars());
            }
        } else {
            View d = w.getDecorView();
            d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    private static void mostrarDirecto(Activity a) {
        try {
            Window w = a.getWindow();
            if (w == null) return;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = w.getInsetsController();
                if (c != null) c.show(WindowInsets.Type.statusBars());
            } else {
                View d = w.getDecorView();
                d.setSystemUiVisibility(d.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_FULLSCREEN);
            }
        } catch (Throwable ignored) { }
    }

    /** Gancho al inicio de oc7.f() (abrir el reproductor). Cualquier hilo. */
    public static void start() {
        try {
            synchronized (KeepAwake.class) {
                if (arrancado) return;
                arrancado = true;
            }
            Looper main = Looper.getMainLooper();
            handler = new Handler(main);
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        iniciar();
                    } catch (Throwable t) {
                        Log.w(TAG, "iniciar fallo", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }

    private static void iniciar() throws Exception {
        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        if (app instanceof Application) {
            try {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
                lifecycleOk = true;
            } catch (Throwable t) {
                Log.w(TAG, "lifecycle fallo", t);
            }
        }
        if (actual == null) semilla();
        tick();
    }

    /** La actividad ya esta visible cuando se abre el reproductor: se busca en ActivityThread (mejor esfuerzo). */
    @SuppressWarnings("unchecked")
    private static void semilla() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "semilla fallo (se esperara al siguiente resume)", t);
        }
    }

    private static boolean reproductorAbierto() {
        if (falloFlujo) return false;
        try {
            if (flujoAbierto == null) {
                Field f = Class.forName("ex7").getDeclaredField("a");
                f.setAccessible(true);
                flujoAbierto = f.get(null);
                getValor = flujoAbierto.getClass().getMethod("getValue");
            }
            return Boolean.TRUE.equals(getValor.invoke(flujoAbierto));
        } catch (Throwable t) {
            falloFlujo = true;
            Log.w(TAG, "no se pudo leer wu7.a", t);
            return false;
        }
    }

    private static void tick() {
        revisar();
        if (!falloFlujo && handler != null) {
            boolean rapido = hideBar && (barOculta != null || ctl != null || pidiendo || SystemClock.uptimeMillis() < rapidoHasta);
            handler.postDelayed(new Runnable() {
                @Override public void run() { tick(); }
            }, rapido ? PERIODO_RAPIDO_MS : PERIODO_MS);
        }
    }

    private static void revisar() {
        try {
            boolean abierto = reproductorAbierto();
            Activity a = actual == null ? null : actual.get();
            Activity prev = conFlag == null ? null : conFlag.get();
            if (prev != null && (!abierto || prev != a)) {
                quitar(prev);
                conFlag = null;
                prev = null;
            }
            if (abierto && a != null && prev == null) {
                Window w = a.getWindow();
                if (w != null) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    conFlag = new WeakReference<Activity>(a);
                }
            } else if (abierto && a == null && !lifecycleOk) {
                semilla();
            }
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        try { // v0.20.383: barra de estado (v0.20.385: sigue el movimiento de la hoja)
            boolean abierto2 = reproductorAbierto();
            Activity a2 = actual == null ? null : actual.get();
            Activity b = barOculta == null ? null : barOculta.get();
            long ahora = SystemClock.uptimeMillis();
            if (abierto2) {
                cerradoMs = 0;
                if (abiertoDesdeMs == 0) abiertoDesdeMs = ahora;
            } else {
                abiertoDesdeMs = 0;
                if (cerradoMs == 0) cerradoMs = ahora;
            }
            boolean conEstado = PlayerEnter.tieneEstado();
            float prog = conEstado ? PlayerEnter.progreso() : 1f;
            // se oculta cuando la hoja ya llego arriba (o, por si no se puede leer, a los 1.5 s de abrir)
            // v0.20.386 (como el video): se oculta ~250 ms DESPUES de que la hoja llego arriba del todo
            if (abierto2 && conEstado && prog >= 0.98f) {
                if (arribaDesdeMs == 0) arribaDesdeMs = ahora;
            } else {
                arribaDesdeMs = 0;
            }
            boolean subida = (arribaDesdeMs != 0 && ahora - arribaDesdeMs >= 250L)
                    || (!conEstado && abiertoDesdeMs != 0 && ahora - abiertoDesdeMs > 1500L)
                    || (abiertoDesdeMs != 0 && ahora - abiertoDesdeMs > 2500L);
            // vuelve cuando la hoja ya bajo del todo (o, por si no se puede leer, 0.6 s despues de cerrar)
            // v0.20.387: vuelve 80 ms despues de que empieza a cerrarse (en tu video la barra volvia a ~0.7 s con el respaldo de 600 ms: la medida de la hoja no llegaba a 0.5)
            boolean bajada = (cerradoMs != 0 && ahora - cerradoMs >= 80L) || (conEstado && prog <= 0.5f);
            if (b != null && ((!abierto2 && bajada) || b != a2)) {
                if (b != a2) mostrarDirecto(b); else mostrarBarra(b);
                barOculta = null;
                b = null;
            }
            if (hideBar && abierto2 && subida && a2 != null && b == null) {
                ocultarBarra(a2);
                barOculta = new WeakReference<Activity>(a2);
            }
        } catch (Throwable t) {
            Log.w(TAG, "barra fallo", t);
        }
    }

    private static void quitar(Activity a) {
        try {
            Window w = a.getWindow();
            if (w != null) w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
    }
}
