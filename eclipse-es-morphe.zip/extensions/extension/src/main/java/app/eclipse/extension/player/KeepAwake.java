package app.eclipse.extension.player;

import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.57: `oc7` guarda banderas estaticas (MutableStateFlow<Boolean>); `oc7.f()` pone `wu7.a` en true (abrir el
 * reproductor) y `wu7.a()` / `oc7.b()` las ponen todas en false. Gancho unico: inicio de `oc7.f()` llama a start().
 * start() arranca (una vez) un reloj en el hilo principal que cada 700 ms lee `wu7.a` por reflexion y pone o quita
 * FLAG_KEEP_SCREEN_ON en la ventana de la actividad visible. Asi tambien se apaga al cerrar el reproductor por
 * cualquier camino. Todo con try/catch: si algo falla, no hace nada y la pantalla se comporta como siempre.
 */
public final class KeepAwake {
    private static final String TAG = "KeepAwake";
    private static final long PERIODO_MS = 700L;

    private static boolean arrancado;
    private static boolean lifecycleOk;
    private static WeakReference<Activity> actual;
    private static WeakReference<Activity> conFlag;
    private static Handler handler;
    private static Object flujoAbierto; // wu7.a (cq9 = MutableStateFlow<Boolean>)
    private static Method getValor;
    private static boolean falloFlujo;

    // v0.20.383 (SIN COMPILAR NI PROBAR): ocultar la barra de estado mientras el reproductor grande esta abierto.
    private static volatile boolean hideBar;
    private static WeakReference<Activity> barOculta;

    private KeepAwake() {}

    /** Gancho del parche "Reproductor: ocultar la barra de estado" (inicio de ex7.e(), abrir el reproductor). */
    public static void startHideBar() {
        try {
            hideBar = true;
            start();
            if (handler != null) {
                handler.post(new Runnable() {
                    @Override public void run() { revisar(); }
                });
            }
        } catch (Throwable t) {
            Log.w(TAG, "startHideBar fallo", t);
        }
    }

    private static void ocultarBarra(Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsets.Type.statusBars());
            }
        } else {
            View d = w.getDecorView();
            d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    private static void mostrarBarra(Activity a) {
        try {
            Window w = a.getWindow();
            if (w == null) return;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = w.getInsetsController();
                if (c != null) c.show(WindowInsets.Type.statusBars());
            } else {
                View d = w.getDecorView();
                d.setSystemUiVisibility(d.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_FULLSCREEN);
            }
        } catch (Throwable ignored) { }
    }

    /** Gancho al inicio de oc7.f() (abrir el reproductor). Cualquier hilo. */
    public static void start() {
        try {
            synchronized (KeepAwake.class) {
                if (arrancado) return;
                arrancado = true;
            }
            Looper main = Looper.getMainLooper();
            handler = new Handler(main);
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        iniciar();
                    } catch (Throwable t) {
                        Log.w(TAG, "iniciar fallo", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }

    private static void iniciar() throws Exception {
        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        if (app instanceof Application) {
            try {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
                lifecycleOk = true;
            } catch (Throwable t) {
                Log.w(TAG, "lifecycle fallo", t);
            }
        }
        if (actual == null) semilla();
        tick();
    }

    /** La actividad ya esta visible cuando se abre el reproductor: se busca en ActivityThread (mejor esfuerzo). */
    @SuppressWarnings("unchecked")
    private static void semilla() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "semilla fallo (se esperara al siguiente resume)", t);
        }
    }

    private static boolean reproductorAbierto() {
        if (falloFlujo) return false;
        try {
            if (flujoAbierto == null) {
                Field f = Class.forName("ex7").getDeclaredField("a");
                f.setAccessible(true);
                flujoAbierto = f.get(null);
                getValor = flujoAbierto.getClass().getMethod("getValue");
            }
            return Boolean.TRUE.equals(getValor.invoke(flujoAbierto));
        } catch (Throwable t) {
            falloFlujo = true;
            Log.w(TAG, "no se pudo leer wu7.a", t);
            return false;
        }
    }

    private static void tick() {
        revisar();
        if (!falloFlujo && handler != null) {
            handler.postDelayed(new Runnable() {
                @Override public void run() { tick(); }
            }, PERIODO_MS);
        }
    }

    private static void revisar() {
        try {
            boolean abierto = reproductorAbierto();
            Activity a = actual == null ? null : actual.get();
            Activity prev = conFlag == null ? null : conFlag.get();
            if (prev != null && (!abierto || prev != a)) {
                quitar(prev);
                conFlag = null;
                prev = null;
            }
            if (abierto && a != null && prev == null) {
                Window w = a.getWindow();
                if (w != null) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    conFlag = new WeakReference<Activity>(a);
                }
            } else if (abierto && a == null && !lifecycleOk) {
                semilla();
            }
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        try { // v0.20.383: barra de estado
            boolean abierto2 = reproductorAbierto();
            Activity a2 = actual == null ? null : actual.get();
            Activity b = barOculta == null ? null : barOculta.get();
            if (b != null && (!abierto2 || b != a2)) {
                mostrarBarra(b);
                barOculta = null;
                b = null;
            }
            if (hideBar && abierto2 && a2 != null && b == null) {
                ocultarBarra(a2);
                barOculta = new WeakReference<Activity>(a2);
            }
        } catch (Throwable t) {
            Log.w(TAG, "barra fallo", t);
        }
    }

    private static void quitar(Activity a) {
        try {
            Window w = a.getWindow();
            if (w != null) w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
    }
}
