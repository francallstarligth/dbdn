package app.eclipse.extension.player;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.57: `oc7` guarda banderas estaticas (MutableStateFlow<Boolean>); `oc7.f()` pone `oc7.a` en true (abrir el
 * reproductor) y `oc7.a()` / `oc7.b()` las ponen todas en false. Gancho unico: inicio de `oc7.f()` llama a start().
 * start() arranca (una vez) un reloj en el hilo principal que cada 700 ms lee `oc7.a` por reflexion y pone o quita
 * FLAG_KEEP_SCREEN_ON en la ventana de la actividad visible. Asi tambien se apaga al cerrar el reproductor por
 * cualquier camino. Todo con try/catch: si algo falla, no hace nada y la pantalla se comporta como siempre.
 */
public final class KeepAwake {
    private static final String TAG = "KeepAwake";
    private static final long PERIODO_MS = 700L;

    private static boolean arrancado;
    private static boolean lifecycleOk;
    private static WeakReference<Activity> actual;
    private static WeakReference<Activity> conFlag;
    private static Handler handler;
    private static Object flujoAbierto; // oc7.a (cq9 = MutableStateFlow<Boolean>)
    private static Method getValor;
    private static boolean falloFlujo;

    private KeepAwake() {}

    /** Gancho al inicio de oc7.f() (abrir el reproductor). Cualquier hilo. */
    public static void start() {
        try {
            synchronized (KeepAwake.class) {
                if (arrancado) return;
                arrancado = true;
            }
            Looper main = Looper.getMainLooper();
            handler = new Handler(main);
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        iniciar();
                    } catch (Throwable t) {
                        Log.w(TAG, "iniciar fallo", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }

    private static void iniciar() throws Exception {
        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        if (app instanceof Application) {
            try {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
                lifecycleOk = true;
            } catch (Throwable t) {
                Log.w(TAG, "lifecycle fallo", t);
            }
        }
        if (actual == null) semilla();
        tick();
    }

    /** La actividad ya esta visible cuando se abre el reproductor: se busca en ActivityThread (mejor esfuerzo). */
    @SuppressWarnings("unchecked")
    private static void semilla() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "semilla fallo (se esperara al siguiente resume)", t);
        }
    }

    private static boolean reproductorAbierto() {
        if (falloFlujo) return false;
        try {
            if (flujoAbierto == null) {
                Field f = Class.forName("oc7").getDeclaredField("a");
                f.setAccessible(true);
                flujoAbierto = f.get(null);
                getValor = flujoAbierto.getClass().getMethod("getValue");
            }
            return Boolean.TRUE.equals(getValor.invoke(flujoAbierto));
        } catch (Throwable t) {
            falloFlujo = true;
            Log.w(TAG, "no se pudo leer oc7.a", t);
            return false;
        }
    }

    private static void tick() {
        try {
            boolean abierto = reproductorAbierto();
            Activity a = actual == null ? null : actual.get();
            Activity prev = conFlag == null ? null : conFlag.get();
            if (prev != null && (!abierto || prev != a)) {
                quitar(prev);
                conFlag = null;
                prev = null;
            }
            if (abierto && a != null && prev == null) {
                Window w = a.getWindow();
                if (w != null) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    conFlag = new WeakReference<Activity>(a);
                }
            } else if (abierto && a == null && !lifecycleOk) {
                semilla();
            }
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        if (!falloFlujo && handler != null) {
            handler.postDelayed(new Runnable() {
                @Override public void run() { tick(); }
            }, PERIODO_MS);
        }
    }

    private static void quitar(Activity a) {
        try {
            Window w = a.getWindow();
            if (w != null) w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
    }
}
