package app.eclipse.extension.player;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Application;
import android.os.Build;
import android.graphics.Insets;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.SystemClock;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimationControlListener;
import android.view.WindowInsetsAnimationController;
import android.view.WindowInsetsController;
import android.view.WindowManager;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.188 (SIN COMPILAR NI PROBAR). Pantalla encendida mientras el reproductor grande (y sus letras) esta abierto.
 * Eclipse 0.6.57: `oc7` guarda banderas estaticas (MutableStateFlow<Boolean>); `oc7.f()` pone `wu7.a` en true (abrir el
 * reproductor) y `wu7.a()` / `oc7.b()` las ponen todas en false. Gancho unico: inicio de `oc7.f()` llama a start().
 * start() arranca (una vez) un reloj en el hilo principal que cada 700 ms lee `wu7.a` por reflexion y pone o quita
 * FLAG_KEEP_SCREEN_ON en la ventana de la actividad visible. Asi tambien se apaga al cerrar el reproductor por
 * cualquier camino. Todo con try/catch: si algo falla, no hace nada y la pantalla se comporta como siempre.
 */
public final class KeepAwake {
    private static final String TAG = "KeepAwake";
    private static final long PERIODO_MS = 700L;

    private static boolean arrancado;
    private static boolean lifecycleOk;
    private static WeakReference<Activity> actual;
    private static WeakReference<Activity> conFlag;
    private static Handler handler;
    private static Object flujoAbierto; // wu7.a (cq9 = MutableStateFlow<Boolean>)
    private static Method getValor;
    private static int fallosFlujo;       // v0.20.411: fallos seguidos al leer el flujo (antes un solo fallo apagaba todo para siempre)
    private static long ultimoTickMs;     // v0.20.411: para saber si el reloj sigue vivo
    private static int genReloj;          // v0.20.411: generacion del reloj (si se reinicia, el viejo se detiene)
    private static long pidiendoDesdeMs;  // v0.20.411: vigilante de la peticion de control de la barra
    private static long ultimaSemillaMs;  // v0.20.411: reintento de buscar la actividad visible

    // v0.20.383 (SIN COMPILAR NI PROBAR): ocultar la barra de estado mientras el reproductor grande esta abierto.
    private static volatile boolean hideBar;
    private static WeakReference<Activity> barOculta;
    private static long abiertoDesdeMs;   // v0.20.385: desde cuando esta abierto el reproductor (0 = cerrado)
    private static long arribaDesdeMs;   // v0.20.386: desde cuando la hoja esta arriba del todo (0 = no)
    private static long cerradoMs;        // v0.20.385: desde cuando se cerro (0 = abierto)
    private static long rapidoHasta;      // v0.20.385: hasta cuando se revisa cada 100 ms
    private static final long PERIODO_RAPIDO_MS = 40L;

    private KeepAwake() {}

    // v0.20.417: tambien los botones de navegacion (cuadrado, circulo, triangulo) se esconden con el mismo desvanecido.
    private static volatile boolean navTambien;

    /** v0.20.417: igual que startHideBar() pero esconde tambien los botones de navegacion. */
    public static void startHideBarNav() {
        navTambien = true;
        startHideBar();
    }

    /** Tipos de barra que se esconden (solo Android 11+; se llama dentro de ramas con SDK >= 30). */
    private static int tipos() {
        return navTambien
            ? (WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars())
            : WindowInsets.Type.statusBars();
    }

    /** Gancho del parche "Reproductor: ocultar la barra de estado" (inicio de ex7.e(), abrir el reproductor). */
    public static void startHideBar() {
        try {
            hideBar = true;
            rapidoHasta = SystemClock.uptimeMillis() + 3000L;
            start();
            if (handler != null) {
                // v0.20.411: si el reloj se paro (o nunca arranco), se vuelve a arrancar al abrir el reproductor
                if (ultimoTickMs != 0L && SystemClock.uptimeMillis() - ultimoTickMs > 6000L) {
                    final int g = ++genReloj;
                    handler.post(new Runnable() {
                        @Override public void run() { tick(g); }
                    });
                } else {
                    handler.post(new Runnable() {
                        @Override public void run() { revisar(); }
                    });
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "startHideBar fallo", t);
        }
    }


    // ---- v0.20.387: desvanecido de la barra (la barra NO se desliza: se queda en su sitio y cambia su transparencia) ----
    private static final long OCULTAR_MS = 550L;
    private static final long MOSTRAR_MS = 400L;
    private static WindowInsetsAnimationController ctl;
    private static Insets insetsMostrado;
    private static ValueAnimator anim;
    private static float alphaAhora = 1f;
    private static boolean pidiendo;
    private static boolean destinoOcultar;
    private static WeakReference<Activity> actAnim;

    private static void ocultarBarra(Activity a) { animarBarra(a, true); }

    private static void mostrarBarra(Activity a) {
        // v0.20.388: si no tenemos el control (el sistema lo quito), la barra ya esta como antes: solo asegurar que se vea
        if (ctl == null && !pidiendo) { mostrarDirecto(a); return; }
        animarBarra(a, false);
    }

    private static void animarBarra(Activity a, boolean ocultar) {
        if (Build.VERSION.SDK_INT < 30) {
            if (ocultar) ocultarDirecto(a); else mostrarDirecto(a);
            return;
        }
        try {
            actAnim = new WeakReference<Activity>(a);
            if (ctl != null) { empujar(ocultar); return; }
            destinoOcultar = ocultar;
            if (pidiendo) return;
            Window w = a.getWindow();
            WindowInsetsController c = w == null ? null : w.getInsetsController();
            if (c == null) { if (ocultar) ocultarDirecto(a); else mostrarDirecto(a); return; }
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            pidiendo = true;
            pidiendoDesdeMs = SystemClock.uptimeMillis();
            alphaAhora = ocultar ? 1f : 0f;
            c.controlWindowInsetsAnimation(tipos(), -1L, null, new CancellationSignal(),
                    new BarraListener());
        } catch (Throwable t) {
            pidiendo = false;
            Log.w(TAG, "animarBarra fallo", t);
            if (ocultar) ocultarDirecto(a); else mostrarDirecto(a);
        }
    }

    /** Mueve la transparencia de alphaAhora al destino; al final deja la barra en su estado real. */
    private static void empujar(final boolean ocultar) {
        try {
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
            final WindowInsetsAnimationController c = ctl;
            if (c == null || insetsMostrado == null) return;
            final float destino = ocultar ? 0f : 1f;
            final float desde = alphaAhora;
            long dur = (long) ((ocultar ? OCULTAR_MS : MOSTRAR_MS) * Math.abs(destino - desde));
            if (dur < 1L) { if (ocultar) retener(); else terminar(c, false); return; }
            ValueAnimator va = ValueAnimator.ofFloat(desde, destino);
            va.setDuration(dur);
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator v) {
                    try {
                        float x = ((Float) v.getAnimatedValue()).floatValue();
                        alphaAhora = x;
                        c.setInsetsAndAlpha(insetsMostrado, x, x);
                    } catch (Throwable t) {
                        // v0.20.411: el control ya no sirve (el sistema lo termino): se suelta y se reintenta en la siguiente revision
                        Log.w(TAG, "control invalido", t);
                        soltarControl();
                    }
                }
            });
            va.addListener(new AnimatorListenerAdapter() {
                private boolean cancelado;
                @Override public void onAnimationCancel(Animator a) { cancelado = true; }
                @Override public void onAnimationEnd(Animator a) {
                    if (cancelado) return;
                    // v0.20.388: al ocultar NO se suelta el control: la barra queda transparente pero el sistema
                    // sigue contando su espacio, asi el contenido de la app no sube ni baja.
                    if (ocultar) retener(); else terminar(c, false);
                }
            });
            anim = va;
            va.start();
        } catch (Throwable t) {
            Log.w(TAG, "empujar fallo", t);
        }
    }

    /** v0.20.411: el controlador de la barra ya no sirve: se olvida y se marca la barra como no oculta para volver a pedirla. */
    private static void soltarControl() {
        try {
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); }
        } catch (Throwable ignored) { }
        anim = null;
        ctl = null;
        pidiendo = false;
        alphaAhora = 1f;
        barOculta = null;
    }

    private static void retener() {
        alphaAhora = 0f;
        anim = null;
    }

    private static void terminar(WindowInsetsAnimationController c, boolean ocultar) {
        try {
            alphaAhora = ocultar ? 0f : 1f;
            ctl = null;
            anim = null;
            c.finish(!ocultar);
        } catch (Throwable t) {
            Log.w(TAG, "terminar fallo", t);
        }
    }

    private static final class BarraListener implements WindowInsetsAnimationControlListener {
        @Override public void onReady(WindowInsetsAnimationController controller, int types) {
            try {
                pidiendo = false;
                ctl = controller;
                insetsMostrado = controller.getShownStateInsets();
                controller.setInsetsAndAlpha(insetsMostrado, alphaAhora, alphaAhora);
                empujar(destinoOcultar);
            } catch (Throwable t) {
                Log.w(TAG, "onReady fallo", t);
            }
        }
        @Override public void onFinished(WindowInsetsAnimationController controller) { }
        @Override public void onCancelled(WindowInsetsAnimationController controller) {
            // el sistema no dejo controlar la transparencia: se hace como antes (directo)
            try {
                boolean teniaControl = ctl != null;
                boolean noLlegoAListo = pidiendo;
                pidiendo = false;
                ctl = null;
                if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
                Activity a = actAnim == null ? null : actAnim.get();
                // v0.20.388: se perdio el control con la barra retenida (ej. se bajo la barra de notificaciones):
                // el sistema ya la devuelve; se marca como no oculta para volver a ocultarla cuando se pueda.
                if (teniaControl && !noLlegoAListo) { barOculta = null; return; }
                if (a != null) {
                    if (destinoOcultar) {
                        if (a.hasWindowFocus()) ocultarDirecto(a); else barOculta = null;
                    } else mostrarDirecto(a);
                }
            } catch (Throwable t) {
                Log.w(TAG, "onCancelled fallo", t);
            }
        }
    }

    private static void ocultarDirecto(Activity a) {
        Window w = a.getWindow();
        if (w == null) return;
        if (Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(tipos());
            }
        } else {
            View d = w.getDecorView();
            d.setSystemUiVisibility(d.getSystemUiVisibility() | View.SYSTEM_UI_FLAG_FULLSCREEN
                | (navTambien ? View.SYSTEM_UI_FLAG_HIDE_NAVIGATION : 0));
        }
    }

    private static void mostrarDirecto(Activity a) {
        try {
            Window w = a.getWindow();
            if (w == null) return;
            if (Build.VERSION.SDK_INT >= 30) {
                WindowInsetsController c = w.getInsetsController();
                if (c != null) c.show(tipos());
            } else {
                View d = w.getDecorView();
                d.setSystemUiVisibility(d.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_FULLSCREEN
                    & ~(navTambien ? View.SYSTEM_UI_FLAG_HIDE_NAVIGATION : 0));
            }
        } catch (Throwable ignored) { }
    }

    /** Gancho al inicio de oc7.f() (abrir el reproductor). Cualquier hilo. */
    public static void start() {
        try {
            synchronized (KeepAwake.class) {
                if (arrancado) return;
                arrancado = true;
            }
            Looper main = Looper.getMainLooper();
            handler = new Handler(main);
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        iniciar();
                    } catch (Throwable t) {
                        Log.w(TAG, "iniciar fallo", t);
                        synchronized (KeepAwake.class) { arrancado = false; } // v0.20.411: se reintenta al abrir otra vez
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }

    private static void iniciar() throws Exception {
        Object app = null;
        try {
            app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            Log.w(TAG, "currentApplication fallo", t);
        }
        if (app instanceof Application && !lifecycleOk) {
            try {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
                lifecycleOk = true;
            } catch (Throwable t) {
                Log.w(TAG, "lifecycle fallo", t);
            }
        }
        if (actual == null) semilla();
        tick(++genReloj);
    }

    /** La actividad ya esta visible cuando se abre el reproductor: se busca en ActivityThread (mejor esfuerzo). */
    @SuppressWarnings("unchecked")
    private static void semilla() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "semilla fallo (se esperara al siguiente resume)", t);
        }
    }

    private static Method buscarGetValue(Class<?> k) throws Exception {
        try {
            return k.getMethod("getValue");
        } catch (NoSuchMethodException ignored) { }
        for (Class<?> c = k; c != null; c = c.getSuperclass()) {
            try {
                return c.getDeclaredMethod("getValue");
            } catch (NoSuchMethodException ignored) { }
        }
        throw new NoSuchMethodException("getValue");
    }

    /** v0.20.411: un fallo ya no apaga la funcion para siempre: se olvida lo guardado y se vuelve a intentar en la siguiente revision. */
    /** v0.20.411: si todavia no se sabe cual es la actividad visible, se vuelve a buscar (como mucho cada 500 ms). */
    private static void reintentarSemilla() {
        long ahora = SystemClock.uptimeMillis();
        if (ahora - ultimaSemillaMs < 500L) return;
        ultimaSemillaMs = ahora;
        semilla();
    }

    private static boolean reproductorAbierto() {
        try {
            if (flujoAbierto == null || getValor == null) {
                Field f = Class.forName("ex7").getDeclaredField("a");
                f.setAccessible(true);
                Object flujo = f.get(null);
                Method m = buscarGetValue(flujo.getClass());
                m.setAccessible(true);
                flujoAbierto = flujo;
                getValor = m;
            }
            boolean v = Boolean.TRUE.equals(getValor.invoke(flujoAbierto));
            fallosFlujo = 0;
            return v;
        } catch (Throwable t) {
            flujoAbierto = null;
            getValor = null;
            if (fallosFlujo++ < 3) Log.w(TAG, "no se pudo leer ex7.a", t);
            return false;
        }
    }

    private static void tick(final int gen) {
        if (gen != genReloj) return; // un reloj mas nuevo tomo el relevo
        ultimoTickMs = SystemClock.uptimeMillis();
        try {
            revisar();
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        if (handler != null && gen == genReloj) {
            boolean rapido = hideBar && fallosFlujo == 0 && (barOculta != null || ctl != null || pidiendo || SystemClock.uptimeMillis() < rapidoHasta);
            long periodo = fallosFlujo >= 10 ? 3000L : (rapido ? PERIODO_RAPIDO_MS : PERIODO_MS);
            handler.postDelayed(new Runnable() {
                @Override public void run() { tick(gen); }
            }, periodo);
        }
    }

    private static void revisar() {
        try {
            boolean abierto = reproductorAbierto();
            Activity a = actual == null ? null : actual.get();
            Activity prev = conFlag == null ? null : conFlag.get();
            if (prev != null && (!abierto || prev != a)) {
                quitar(prev);
                conFlag = null;
                prev = null;
            }
            if (abierto && a != null && prev == null) {
                Window w = a.getWindow();
                if (w != null) {
                    w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                    conFlag = new WeakReference<Activity>(a);
                }
            } else if (abierto && a == null) {
                reintentarSemilla();
            }
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        try { // v0.20.383: barra de estado (v0.20.385: sigue el movimiento de la hoja)
            boolean abierto2 = reproductorAbierto();
            long ahora = SystemClock.uptimeMillis();
            // v0.20.411: vigilantes para que ningun estado se quede pegado
            if (pidiendo && ahora - pidiendoDesdeMs > 1500L) { // el sistema nunca contesto la peticion de control
                pidiendo = false;
                Activity pa = actAnim == null ? null : actAnim.get();
                if (pa != null) { if (destinoOcultar && pa.hasWindowFocus()) ocultarDirecto(pa); else if (!destinoOcultar) mostrarDirecto(pa); }
                if (!destinoOcultar) barOculta = null;
            }
            if (ctl != null) { // el sistema termino o cancelo el control sin avisar
                boolean muerto = false;
                try { muerto = ctl.isFinished() || ctl.isCancelled(); } catch (Throwable t) { muerto = true; }
                if (muerto) soltarControl();
            }
            Activity a2 = actual == null ? null : actual.get();
            if (a2 == null && abierto2) { reintentarSemilla(); a2 = actual == null ? null : actual.get(); }
            Activity b = barOculta == null ? null : barOculta.get();
            if (abierto2) {
                cerradoMs = 0;
                if (abiertoDesdeMs == 0) abiertoDesdeMs = ahora;
            } else {
                abiertoDesdeMs = 0;
                if (cerradoMs == 0) cerradoMs = ahora;
            }
            boolean conEstado = PlayerEnter.tieneEstado();
            float prog = conEstado ? PlayerEnter.progreso() : 1f;
            // se oculta cuando la hoja ya llego arriba (o, por si no se puede leer, a los 1.5 s de abrir)
            // v0.20.386 (como el video): se oculta ~250 ms DESPUES de que la hoja llego arriba del todo
            if (abierto2 && conEstado && prog >= 0.98f) {
                if (arribaDesdeMs == 0) arribaDesdeMs = ahora;
            } else {
                arribaDesdeMs = 0;
            }
            boolean subida = (arribaDesdeMs != 0 && ahora - arribaDesdeMs >= 250L)
                    || (!conEstado && abiertoDesdeMs != 0 && ahora - abiertoDesdeMs > 1500L)
                    || (abiertoDesdeMs != 0 && ahora - abiertoDesdeMs > 2500L);
            // vuelve cuando la hoja ya bajo del todo (o, por si no se puede leer, 0.6 s despues de cerrar)
            // v0.20.387: vuelve 80 ms despues de que empieza a cerrarse (en tu video la barra volvia a ~0.7 s con el respaldo de 600 ms: la medida de la hoja no llegaba a 0.5)
            boolean bajada = (cerradoMs != 0) || (conEstado && prog <= 0.5f);
            if (b != null && ((!abierto2 && bajada) || b != a2)) {
                if (b != a2) mostrarDirecto(b); else mostrarBarra(b);
                barOculta = null;
                b = null;
            }
            if (hideBar && abierto2 && subida && a2 != null && b == null && a2.hasWindowFocus()) {
                ocultarBarra(a2);
                barOculta = new WeakReference<Activity>(a2);
            }
        } catch (Throwable t) {
            Log.w(TAG, "barra fallo", t);
        }
    }

    private static void quitar(Activity a) {
        try {
            Window w = a.getWindow();
            if (w != null) w.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } catch (Throwable ignored) { }
    }
}
