package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.UUID;

/**
 * v0.20.39 (SIN COMPILAR / SIN PROBAR). Movimiento Artwork <-> Letra/Cola: la portada grande, el titulo, el artista, la
 * estrella y los tres puntos "viajan" hasta la cabecera mientras se desvanecen (y al reves).
 *
 * Eclipse dibuja cada capa en di6.d y calcula su posicion/tamano a partir de su transform (zb4: x, y, ancho, alto como
 * fraccion de la pantalla). El parche "Bitchord: la portada chica crece (Letra)" llama a {@link #tf} en esos dos sitios:
 * si la capa es una de las 5 marcadas (por su id), devuelve un transform mezclado entre el de Artwork (el original) y el
 * de la cabecera, segun qw0.e("artwork") (1 = Artwork, 0 = Letra/Cola; Eclipse lo anima en 250 ms). Cualquier fallo
 * devuelve el transform original.
 */
@SuppressWarnings("unused")
public final class LayerMorph {
    private LayerMorph() {}

    private static final String[] KINDS = {"artwork", "songTitle", "artistName", "favorite", "threeDotMenu"};
    // Desplazamiento (fraccion de pantalla 1080x2400) desde Artwork hasta la cabecera, medido en capturas del usuario.
    // Indices 0-4: Bitchord. Indices 5-8: Capsule (artwork, songTitle, artistName, addToLibrary), v0.20.333: calculados (no medidos)
    // con las posiciones de las capas libres de CapsuleDesign y el MISMO destino que Bitchord (la cabecera es identica).
    private static final double[] DX = {0, 254 / 1080.0, 256 / 1080.0, 27.5 / 1080.0, 19.5 / 1080.0,
            0, 267.4 / 1080.0, 267.0 / 1080.0, -121.9 / 1080.0};
    private static final double[] DY = {0, -1042 / 2400.0, -1017 / 2400.0, -1033.5 / 2400.0, -1032.5 / 2400.0,
            0, -1210.0 / 2400.0, -1194.6 / 2400.0, -1208.5 / 2400.0};
    // Portada: destino absoluto = lugar de la portada chica (180x180 px con la esquina en (76, 172)).
    private static final double COVER_X = 0.1537, COVER_Y = 0.10917, COVER_W = 0.16667, COVER_H = 0.075;

    private static final HashMap<String, Integer> IDS = new HashMap<String, Integer>();
    /** v0.20.139: capas marcadas ya reconocidas (id -> tipo). Evita repetir ~8 lecturas por reflexion en cada cuadro. Solo positivas. */
    private static final java.util.concurrent.ConcurrentHashMap<String, Integer> FOUND =
            new java.util.concurrent.ConcurrentHashMap<String, Integer>();

    /** v0.20.40: marca invisible al final del nombre de las 5 capas originales (Eclipse cambia los ids al guardar, el nombre se conserva). */
    static final String MARK = "\u200B\u200B";
    /** v0.20.333: marca de Capsule (otro caracter, para que no se confunda con MARK: tres \u200B tambien terminan en dos). */
    static final String MARK_CAP = "\u2060\u2060";
    private static final String[] CAP_KINDS = {"artwork", "songTitle", "artistName", "addToLibrary"};

    private static int capKindIndex(String name) {
        if (name == null) return -1;
        String n = name.replace("_", "");
        for (int i = 0; i < CAP_KINDS.length; i++) if (CAP_KINDS[i].equalsIgnoreCase(n)) return 5 + i;
        return -1;
    }

    static boolean isCapKind(String kind) {
        for (String k : CAP_KINDS) if (k.equals(kind)) return true;
        return false;
    }

    static String idForCap(String kind) {
        return UUID.nameUUIDFromBytes(("capsule-letras-morph-" + kind).getBytes()).toString().toUpperCase();
    }

    private static int kindIndex(String name) {
        for (int i = 0; i < KINDS.length; i++) {
            if (KINDS[i].equalsIgnoreCase(name) || (i == 1 && "SONG_TITLE".equals(name)) || (i == 2 && "ARTIST_NAME".equals(name))
                    || (i == 4 && "THREE_DOT_MENU".equals(name))) return i;
        }
        return -1;
    }

    static {
        for (int i = 0; i < KINDS.length; i++) IDS.put(idFor(KINDS[i]), i);
        for (int i = 0; i < CAP_KINDS.length; i++) IDS.put(idForCap(CAP_KINDS[i]), 5 + i);
    }

    /** Id fijo de la capa (para reconocerla despues de guardada). */
    static String idFor(String kind) {
        return UUID.nameUUIDFromBytes(("bitchord-letras-morph-" + kind).getBytes()).toString().toUpperCase();
    }

    static boolean isKind(String kind) {
        for (String k : KINDS) if (k.equals(kind)) return true;
        return false;
    }

    /** v0.20.374: "Crece desde el mini" (lo enciende un gancho en Lex7.e, abrir el reproductor). */
    private static volatile boolean openOn;
    public static void enableOpen() { openOn = true; }
    // Portada del mini (pantalla 1080x2400, medida en captura del usuario): centro y tamano como fraccion de pantalla.
    private static final double MINI_X = 0.1051, MINI_Y = 0.8715, MINI_W = 0.1046, MINI_H = 0.0471;

    private static volatile Object tab;       // qw0
    private static Method weightMethod;
    private static Field idField, kindField, nameField, layoutField, containerField;
    private static Field fa, fb, fc, fd, fe, ff;
    private static Constructor<?> ctor;
    private static boolean broken;

    /** v0.20.293: ultimo resultado de tf por tipo de capa (0..4). Se lee la referencia una sola vez, asi que no se mezclan campos. */
    private static final class Ent {
        final Object tr; final float w; final Object out;
        Ent(Object tr, float w, Object out) { this.tr = tr; this.w = w; this.out = out; }
    }
    private static final Ent[] CACHE = new Ent[9];

    /** Lo llama BlurredCanvasBackground.setPane con el qw0 (estado de pestana). */
    public static void setTab(Object qw0) {
        if (qw0 != null) tab = qw0;
    }

    /**
     * @param layer dw0 (la capa)
     * @param tr    zb4 (su transform original)
     * @return un zb4 (Object) mezclado, o el mismo `tr`
     */
    public static Object tf(Object layer, Object tr) {
        try {
            if (broken) return tr;
            Object t = tab;
            if (t == null || layer == null || tr == null) return tr;
            if (idField == null) {
                idField = layer.getClass().getDeclaredField("a");
                idField.setAccessible(true);
            }
            Object idObj = idField.get(layer);
            Integer idx = (idObj instanceof String) ? IDS.get((String) idObj) : null;
            if (idx == null && idObj instanceof String) idx = FOUND.get((String) idObj);
            if (idx == null) {
                // v0.20.40: Eclipse puede cambiar el id al guardar el diseno: se reconoce por tipo + marca en el nombre + sin contenedor.
                if (kindField == null) {
                    kindField = layer.getClass().getDeclaredField("b"); kindField.setAccessible(true);
                    nameField = layer.getClass().getDeclaredField("c"); nameField.setAccessible(true);
                    layoutField = layer.getClass().getDeclaredField("P"); layoutField.setAccessible(true);
                }
                Object nm = nameField.get(layer);
                if (!(nm instanceof String)) return tr;
                boolean cap = ((String) nm).endsWith(MARK_CAP);
                if (!cap && !((String) nm).endsWith(MARK)) return tr;
                Object kd = kindField.get(layer);
                if (!(kd instanceof Enum)) return tr;
                int ki = cap ? capKindIndex(((Enum<?>) kd).name()) : kindIndex(((Enum<?>) kd).name());
                if (ki < 0) return tr;
                Object lay = layoutField.get(layer);
                if (lay != null) {
                    if (containerField == null) {
                        containerField = lay.getClass().getDeclaredField("a"); containerField.setAccessible(true);
                    }
                    Object c = containerField.get(lay);
                    if (c instanceof String && !((String) c).isEmpty()) return tr;
                }
                idx = ki;
                if (idObj instanceof String) FOUND.put((String) idObj, ki);
            }
            if (weightMethod == null) {
                weightMethod = t.getClass().getDeclaredMethod("e", String.class);
                weightMethod.setAccessible(true);
            }
            // Lectura de estado de Compose: dentro de la composicion de la capa, asi que se redibuja en cada cuadro.
            float w = ((Number) weightMethod.invoke(t, "artwork")).floatValue();
            double k = 1.0 - w;
            // v0.20.374: avance de apertura (solo la portada lo usa). 1 = abierta del todo = sin cambio.
            float po = openOn ? PlayerEnter.progreso() : 1f;
            boolean opening = po < 0.999f && (idx == 0 || idx == 5);
            if (k <= 0.001 && !opening) return tr;
            if (k < 0.0) k = 0.0;
            if (k > 1.0) k = 1.0;
            // v0.20.293: tf se llama 2 veces por capa y cuadro (qr7.d y xp7.invoke) con el mismo transform y el mismo peso:
            // se guarda el ultimo resultado por tipo de capa y se reutiliza (y tambien cuando nada cambia, p. ej. cancion pausada).
            Ent hit = CACHE[idx];
            if (!opening && hit != null && hit.tr == tr && hit.w == w) return hit.out;
            if (fa == null) {
                Class<?> c = tr.getClass();
                fa = c.getDeclaredField("a"); fb = c.getDeclaredField("b"); fc = c.getDeclaredField("c");
                fd = c.getDeclaredField("d"); fe = c.getDeclaredField("e"); ff = c.getDeclaredField("f");
                fa.setAccessible(true); fb.setAccessible(true); fc.setAccessible(true);
                fd.setAccessible(true); fe.setAccessible(true); ff.setAccessible(true);
                for (Constructor<?> k0 : c.getDeclaredConstructors()) {
                    Class<?>[] p = k0.getParameterTypes();
                    if (p.length == 6 && p[0] == double.class && p[4] == double.class) {
                        k0.setAccessible(true);
                        ctor = k0;
                    }
                }
                if (ctor == null) throw new IllegalStateException("zb4: sin constructor");
            }
            double x = fa.getDouble(tr), y = fb.getDouble(tr), wd = fc.getDouble(tr), ht = fd.getDouble(tr);
            double rot = fe.getDouble(tr);
            Object asp = ff.get(tr);
            int i = idx;
            if (i == 0 || i == 5) { // portada: del tamano de Artwork al de la portada chica
                x += (COVER_X - x) * k;
                y += (COVER_Y - y) * k;
                wd += (COVER_W - wd) * k;
                ht += (COVER_H - ht) * k;
            } else {      // textos y botones: solo se desplazan
                x += DX[i] * k;
                y += DY[i] * k;
            }
            if (opening) {
                // La hoja se mueve con offset(y = valor) y escala s = 1 - 0.6 * (valor / alto) (ver Lwka.a). Se calcula donde
                // queda la portada en pantalla (mezcla entre la portada del mini y su lugar natural) y se devuelve a
                // coordenadas de la hoja, para que "salga" del mini y se vaya agrandando hasta su sitio.
                double s = 0.4 + 0.6 * po;
                double m = po;
                double xn = 0.5 + (x - 0.5) * s, yn = 0.5 + (1.0 - po) + (y - 0.5) * s;
                double wn = wd * s, hn = ht * s;
                double xt = MINI_X + (xn - MINI_X) * m, yt = MINI_Y + (yn - MINI_Y) * m;
                double wt = MINI_W + (wn - MINI_W) * m, ht2 = MINI_H + (hn - MINI_H) * m;
                x = 0.5 + (xt - 0.5) / s;
                y = 0.5 + (yt - 0.5 - (1.0 - po)) / s;
                wd = wt / s;
                ht = ht2 / s;
                return ctor.newInstance(x, y, wd, ht, rot, asp);
            }
            Object res = ctor.newInstance(x, y, wd, ht, rot, asp);
            CACHE[i] = new Ent(tr, w, res);
            return res;
        } catch (Throwable e) {
            broken = true; // si algo no cuadra, se apaga el movimiento y todo queda como antes
            return tr;
        }
    }
}
