package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.UUID;

/**
 * v0.20.39 (SIN COMPILAR / SIN PROBAR). Movimiento Artwork <-> Letra/Cola: la portada grande, el titulo, el artista, la
 * estrella y los tres puntos "viajan" hasta la cabecera mientras se desvanecen (y al reves).
 *
 * Eclipse dibuja cada capa en di6.d y calcula su posicion/tamano a partir de su transform (zb4: x, y, ancho, alto como
 * fraccion de la pantalla). El parche "Bitchord: la portada chica crece (Letra)" llama a {@link #tf} en esos dos sitios:
 * si la capa es una de las 5 marcadas (por su id), devuelve un transform mezclado entre el de Artwork (el original) y el
 * de la cabecera, segun qw0.e("artwork") (1 = Artwork, 0 = Letra/Cola; Eclipse lo anima en 250 ms). Cualquier fallo
 * devuelve el transform original.
 */
@SuppressWarnings("unused")
public final class LayerMorph {
    private LayerMorph() {}

    private static final String[] KINDS = {"artwork", "songTitle", "artistName", "favorite", "threeDotMenu"};
    // Desplazamiento (fraccion de pantalla 1080x2400) desde Artwork hasta la cabecera, medido en capturas del usuario.
    private static final double[] DX = {0, 254 / 1080.0, 256 / 1080.0, 27.5 / 1080.0, 19.5 / 1080.0};
    private static final double[] DY = {0, -1042 / 2400.0, -1017 / 2400.0, -1033.5 / 2400.0, -1032.5 / 2400.0};
    // Portada: destino absoluto = lugar de la portada chica (180x180 px con la esquina en (76, 172)).
    private static final double COVER_X = 0.1537, COVER_Y = 0.10917, COVER_W = 0.16667, COVER_H = 0.075;

    private static final HashMap<String, Integer> IDS = new HashMap<String, Integer>();
    /** v0.20.139: capas marcadas ya reconocidas (id -> tipo). Evita repetir ~8 lecturas por reflexion en cada cuadro. Solo positivas. */
    private static final java.util.concurrent.ConcurrentHashMap<String, Integer> FOUND =
            new java.util.concurrent.ConcurrentHashMap<String, Integer>();

    /** v0.20.40: marca invisible al final del nombre de las 5 capas originales (Eclipse cambia los ids al guardar, el nombre se conserva). */
    static final String MARK = "\u200B\u200B";

    private static int kindIndex(String name) {
        for (int i = 0; i < KINDS.length; i++) {
            if (KINDS[i].equalsIgnoreCase(name) || (i == 1 && "SONG_TITLE".equals(name)) || (i == 2 && "ARTIST_NAME".equals(name))
                    || (i == 4 && "THREE_DOT_MENU".equals(name))) return i;
        }
        return -1;
    }

    static {
        for (int i = 0; i < KINDS.length; i++) IDS.put(idFor(KINDS[i]), i);
    }

    /** Id fijo de la capa (para reconocerla despues de guardada). */
    static String idFor(String kind) {
        return UUID.nameUUIDFromBytes(("bitchord-letras-morph-" + kind).getBytes()).toString().toUpperCase();
    }

    static boolean isKind(String kind) {
        for (String k : KINDS) if (k.equals(kind)) return true;
        return false;
    }

    private static volatile Object tab;       // qw0
    private static Method weightMethod;
    private static Field idField, kindField, nameField, layoutField, containerField;
    private static Field fa, fb, fc, fd, fe, ff;
    private static Constructor<?> ctor;
    private static boolean broken;

    /** Lo llama BlurredCanvasBackground.setPane con el qw0 (estado de pestana). */
    public static void setTab(Object qw0) {
        if (qw0 != null) tab = qw0;
    }

    /**
     * @param layer dw0 (la capa)
     * @param tr    zb4 (su transform original)
     * @return un zb4 (Object) mezclado, o el mismo `tr`
     */
    public static Object tf(Object layer, Object tr) {
        try {
            if (broken) return tr;
            Object t = tab;
            if (t == null || layer == null || tr == null) return tr;
            if (idField == null) {
                idField = layer.getClass().getDeclaredField("a");
                idField.setAccessible(true);
            }
            Object idObj = idField.get(layer);
            Integer idx = (idObj instanceof String) ? IDS.get((String) idObj) : null;
            if (idx == null && idObj instanceof String) idx = FOUND.get((String) idObj);
            if (idx == null) {
                // v0.20.40: Eclipse puede cambiar el id al guardar el diseno: se reconoce por tipo + marca en el nombre + sin contenedor.
                if (kindField == null) {
                    kindField = layer.getClass().getDeclaredField("b"); kindField.setAccessible(true);
                    nameField = layer.getClass().getDeclaredField("c"); nameField.setAccessible(true);
                    layoutField = layer.getClass().getDeclaredField("P"); layoutField.setAccessible(true);
                }
                Object nm = nameField.get(layer);
                if (!(nm instanceof String) || !((String) nm).endsWith(MARK)) return tr;
                Object kd = kindField.get(layer);
                if (!(kd instanceof Enum)) return tr;
                int ki = kindIndex(((Enum<?>) kd).name());
                if (ki < 0) return tr;
                Object lay = layoutField.get(layer);
                if (lay != null) {
                    if (containerField == null) {
                        containerField = lay.getClass().getDeclaredField("a"); containerField.setAccessible(true);
                    }
                    Object c = containerField.get(lay);
                    if (c instanceof String && !((String) c).isEmpty()) return tr;
                }
                idx = ki;
                if (idObj instanceof String) FOUND.put((String) idObj, ki);
            }
            if (weightMethod == null) {
                weightMethod = t.getClass().getDeclaredMethod("e", String.class);
                weightMethod.setAccessible(true);
            }
            // Lectura de estado de Compose: dentro de la composicion de la capa, asi que se redibuja en cada cuadro.
            float w = ((Number) weightMethod.invoke(t, "artwork")).floatValue();
            double k = 1.0 - w;
            if (k <= 0.001) return tr;
            if (k > 1.0) k = 1.0;
            if (fa == null) {
                Class<?> c = tr.getClass();
                fa = c.getDeclaredField("a"); fb = c.getDeclaredField("b"); fc = c.getDeclaredField("c");
                fd = c.getDeclaredField("d"); fe = c.getDeclaredField("e"); ff = c.getDeclaredField("f");
                fa.setAccessible(true); fb.setAccessible(true); fc.setAccessible(true);
                fd.setAccessible(true); fe.setAccessible(true); ff.setAccessible(true);
                for (Constructor<?> k0 : c.getDeclaredConstructors()) {
                    Class<?>[] p = k0.getParameterTypes();
                    if (p.length == 6 && p[0] == double.class && p[4] == double.class) {
                        k0.setAccessible(true);
                        ctor = k0;
                    }
                }
                if (ctor == null) throw new IllegalStateException("zb4: sin constructor");
            }
            double x = fa.getDouble(tr), y = fb.getDouble(tr), wd = fc.getDouble(tr), ht = fd.getDouble(tr);
            double rot = fe.getDouble(tr);
            Object asp = ff.get(tr);
            int i = idx;
            if (i == 0) { // portada: del tamano de Artwork al de la portada chica
                x += (COVER_X - x) * k;
                y += (COVER_Y - y) * k;
                wd += (COVER_W - wd) * k;
                ht += (COVER_H - ht) * k;
            } else {      // textos y botones: solo se desplazan
                x += DX[i] * k;
                y += DY[i] * k;
            }
            return ctor.newInstance(x, y, wd, ht, rot, asp);
        } catch (Throwable e) {
            broken = true; // si algo no cuadra, se apaga el movimiento y todo queda como antes
            return tr;
        }
    }

    // ======== v0.20.290 (SIN COMPILAR / SIN PROBAR): portada fluida (parche "Bitchord: portada chica crece fluida") ========
    // En vez de cambiar el TAMANO de la capa de la portada en cada cuadro (Compose vuelve a medir y a dibujar todo),
    // la portada se mide siempre en tamano Artwork y se achica con un graphicsLayer (escala). La posicion se sigue
    // mezclando en la lambda de colocacion (xp7), y el desplazamiento vertical se suma alli mismo (place + addDy).
    // Si algo falla (glBroken), tfComp vuelve a mezclar el tamano como antes.
    private static volatile boolean fluid;
    private static float screenW, screenH;
    private static float pendingDy;
    private static final int GL_MASK = (520187 | 4) & ~3; // igual que PlayerBack: scaleX y scaleY dados, el resto por defecto
    private static Method glMethod;
    private static boolean glBroken;

    /** Gancho de qr7.q: activa el modo fluido. */
    public static void enableFluid() { fluid = true; }

    /** Gancho de qr7.d, justo antes de qr7.M: ancho y alto (px) que Eclipse usa para convertir las fracciones. */
    public static void setWH(float w, float h) { screenW = w; screenH = h; }

    private static boolean glReady() {
        if (glMethod != null) return true;
        if (glBroken) return false;
        try {
            Class<?> je7 = Class.forName("je7");
            Class<?> mb6 = Class.forName("mb6");
            Class<?> ue9 = Class.forName("ue9");
            Class<?> cv0 = Class.forName("cv0");
            Method m = je7.getDeclaredMethod("E", mb6, float.class, float.class, float.class, float.class, ue9, cv0, int.class);
            m.setAccessible(true);
            glMethod = m;
            return true;
        } catch (Throwable t) {
            glBroken = true;
            return false;
        }
    }

    /** Indice del tipo de la capa (0 = portada) o -1. Misma regla que tf, sin mezclar nada. */
    private static int idxOf(Object layer) {
        try {
            if (layer == null) return -1;
            if (idField == null) {
                idField = layer.getClass().getDeclaredField("a");
                idField.setAccessible(true);
            }
            Object idObj = idField.get(layer);
            Integer idx = (idObj instanceof String) ? IDS.get((String) idObj) : null;
            if (idx == null && idObj instanceof String) idx = FOUND.get((String) idObj);
            if (idx != null) return idx;
            if (kindField == null) {
                kindField = layer.getClass().getDeclaredField("b"); kindField.setAccessible(true);
                nameField = layer.getClass().getDeclaredField("c"); nameField.setAccessible(true);
                layoutField = layer.getClass().getDeclaredField("P"); layoutField.setAccessible(true);
            }
            Object nm = nameField.get(layer);
            if (!(nm instanceof String) || !((String) nm).endsWith(MARK)) return -1;
            Object kd = kindField.get(layer);
            if (!(kd instanceof Enum)) return -1;
            int ki = kindIndex(((Enum<?>) kd).name());
            if (ki < 0) return -1;
            Object lay = layoutField.get(layer);
            if (lay != null) {
                if (containerField == null) {
                    containerField = lay.getClass().getDeclaredField("a"); containerField.setAccessible(true);
                }
                Object c = containerField.get(lay);
                if (c instanceof String && !((String) c).isEmpty()) return -1;
            }
            if (idObj instanceof String) FOUND.put((String) idObj, ki);
            return ki;
        } catch (Throwable e) {
            return -1;
        }
    }

    /** Peso de la pestana Artwork (1 = Artwork, 0 = Letra/Cola) o -1 si no se pudo leer. */
    private static float artworkWeight() {
        try {
            Object t = tab;
            if (t == null) return -1f;
            if (weightMethod == null) {
                weightMethod = t.getClass().getDeclaredMethod("e", String.class);
                weightMethod.setAccessible(true);
            }
            return ((Number) weightMethod.invoke(t, "artwork")).floatValue();
        } catch (Throwable e) {
            return -1f;
        }
    }

    private static boolean ivFields(Object iv) {
        try {
            if (fa == null) {
                Class<?> c = iv.getClass();
                fa = c.getDeclaredField("a"); fb = c.getDeclaredField("b"); fc = c.getDeclaredField("c");
                fd = c.getDeclaredField("d"); fe = c.getDeclaredField("e"); ff = c.getDeclaredField("f");
                fa.setAccessible(true); fb.setAccessible(true); fc.setAccessible(true);
                fd.setAccessible(true); fe.setAccessible(true); ff.setAccessible(true);
            }
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    /** Lo llama qr7.d (composicion) en lugar de tf: la portada conserva el tamano y la posicion de Artwork. */
    public static Object tfComp(Object layer, Object tr) {
        try {
            if (fluid && !broken && !glBroken && glReady() && idxOf(layer) == 0) return tr;
        } catch (Throwable ignored) { }
        return tf(layer, tr);
    }

    /** Lo llama xp7.invoke (colocacion) en lugar de tf: mezcla la posicion y guarda el desplazamiento vertical de la portada. */
    public static Object place(Object layer, Object tr) {
        pendingDy = 0f;
        Object m = tf(layer, tr);
        try {
            if (fluid && !broken && !glBroken && m != tr && screenH > 0f && idxOf(layer) == 0 && ivFields(tr)) {
                pendingDy = (float) ((fb.getDouble(m) - fb.getDouble(tr)) * screenH);
            }
        } catch (Throwable e) {
            pendingDy = 0f;
        }
        return m;
    }

    /** xp7.invoke, justo antes de redondear la Y: suma el desplazamiento vertical de la portada. */
    public static float addDy(float y) {
        float d = pendingDy;
        pendingDy = 0f;
        return y + d;
    }

    /** qr7.d, tras el modificador de tamano: escala la portada (graphicsLayer) de Artwork al lugar de la portada chica. */
    public static Object gl(Object mod, Object layer) {
        try {
            if (!fluid || broken || glBroken || mod == null || idxOf(layer) != 0 || !glReady()) return mod;
            float w = artworkWeight();
            if (w < 0f) return mod;
            double k = 1.0 - w;
            if (k <= 0.001) return mod;
            if (k > 1.0) k = 1.0;
            Field dF = layer.getClass().getDeclaredField("d");
            dF.setAccessible(true);
            Object orig = dF.get(layer);
            if (orig == null || !ivFields(orig)) return mod;
            double wd = fc.getDouble(orig), ht = fd.getDouble(orig);
            if (wd <= 0.0 || ht <= 0.0) return mod;
            float sx = (float) ((wd + (COVER_W - wd) * k) / wd);
            float sy = (float) ((ht + (COVER_H - ht) * k) / ht);
            Object out = glMethod.invoke(null, mod, Float.valueOf(sx), Float.valueOf(sy), Float.valueOf(1f), Float.valueOf(0f),
                    null, null, Integer.valueOf(GL_MASK));
            return out == null ? mod : out;
        } catch (Throwable e) {
            glBroken = true; // tfComp vuelve a mezclar el tamano como antes
            return mod;
        }
    }
}
