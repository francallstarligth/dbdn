package app.eclipse.extension.player;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.UUID;

/**
 * v0.20.39 (SIN COMPILAR / SIN PROBAR). Movimiento Artwork <-> Letra/Cola: la portada grande, el titulo, el artista, la
 * estrella y los tres puntos "viajan" hasta la cabecera mientras se desvanecen (y al reves).
 *
 * Eclipse dibuja cada capa en di6.d y calcula su posicion/tamano a partir de su transform (zb4: x, y, ancho, alto como
 * fraccion de la pantalla). El parche "Bitchord: la portada chica crece (Letra)" llama a {@link #tf} en esos dos sitios:
 * si la capa es una de las 5 marcadas (por su id), devuelve un transform mezclado entre el de Artwork (el original) y el
 * de la cabecera, segun qw0.e("artwork") (1 = Artwork, 0 = Letra/Cola; Eclipse lo anima en 250 ms). Cualquier fallo
 * devuelve el transform original.
 */
@SuppressWarnings("unused")
public final class LayerMorph {
    private LayerMorph() {}

    private static final String[] KINDS = {"artwork", "songTitle", "artistName", "favorite", "threeDotMenu"};
    // Desplazamiento (fraccion de pantalla 1080x2400) desde Artwork hasta la cabecera, medido en capturas del usuario.
    private static final double[] DX = {0, 254 / 1080.0, 256 / 1080.0, 27.5 / 1080.0, 19.5 / 1080.0};
    private static final double[] DY = {0, -1042 / 2400.0, -1017 / 2400.0, -1033.5 / 2400.0, -1032.5 / 2400.0};
    // Portada: destino absoluto = lugar de la portada chica (180x180 px con la esquina en (76, 172)).
    private static final double COVER_X = 0.1537, COVER_Y = 0.10917, COVER_W = 0.16667, COVER_H = 0.075;

    private static final HashMap<String, Integer> IDS = new HashMap<String, Integer>();

    /** v0.20.40: marca invisible al final del nombre de las 5 capas originales (Eclipse cambia los ids al guardar, el nombre se conserva). */
    static final String MARK = "\u200B\u200B";

    private static int kindIndex(String name) {
        for (int i = 0; i < KINDS.length; i++) {
            if (KINDS[i].equalsIgnoreCase(name) || (i == 1 && "SONG_TITLE".equals(name)) || (i == 2 && "ARTIST_NAME".equals(name))
                    || (i == 4 && "THREE_DOT_MENU".equals(name))) return i;
        }
        return -1;
    }

    static {
        for (int i = 0; i < KINDS.length; i++) IDS.put(idFor(KINDS[i]), i);
    }

    /** Id fijo de la capa (para reconocerla despues de guardada). */
    static String idFor(String kind) {
        return UUID.nameUUIDFromBytes(("bitchord-letras-morph-" + kind).getBytes()).toString().toUpperCase();
    }

    static boolean isKind(String kind) {
        for (String k : KINDS) if (k.equals(kind)) return true;
        return false;
    }

    private static volatile Object tab;       // qw0
    private static Method weightMethod;
    private static Field idField, kindField, nameField, layoutField, containerField;
    private static Field fa, fb, fc, fd, fe, ff;
    private static Constructor<?> ctor;
    private static boolean broken;

    /** Lo llama BlurredCanvasBackground.setPane con el qw0 (estado de pestana). */
    public static void setTab(Object qw0) {
        if (qw0 != null) tab = qw0;
    }

    /**
     * @param layer dw0 (la capa)
     * @param tr    zb4 (su transform original)
     * @return un zb4 (Object) mezclado, o el mismo `tr`
     */
    public static Object tf(Object layer, Object tr) {
        try {
            if (broken) return tr;
            Object t = tab;
            if (t == null || layer == null || tr == null) return tr;
            if (idField == null) {
                idField = layer.getClass().getDeclaredField("a");
                idField.setAccessible(true);
            }
            Object idObj = idField.get(layer);
            Integer idx = (idObj instanceof String) ? IDS.get((String) idObj) : null;
            if (idx == null) {
                // v0.20.40: Eclipse puede cambiar el id al guardar el diseno: se reconoce por tipo + marca en el nombre + sin contenedor.
                if (kindField == null) {
                    kindField = layer.getClass().getDeclaredField("b"); kindField.setAccessible(true);
                    nameField = layer.getClass().getDeclaredField("c"); nameField.setAccessible(true);
                    layoutField = layer.getClass().getDeclaredField("P"); layoutField.setAccessible(true);
                }
                Object nm = nameField.get(layer);
                if (!(nm instanceof String) || !((String) nm).endsWith(MARK)) return tr;
                Object kd = kindField.get(layer);
                if (!(kd instanceof Enum)) return tr;
                int ki = kindIndex(((Enum<?>) kd).name());
                if (ki < 0) return tr;
                Object lay = layoutField.get(layer);
                if (lay != null) {
                    if (containerField == null) {
                        containerField = lay.getClass().getDeclaredField("a"); containerField.setAccessible(true);
                    }
                    Object c = containerField.get(lay);
                    if (c instanceof String && !((String) c).isEmpty()) return tr;
                }
                idx = ki;
            }
            if (weightMethod == null) {
                weightMethod = t.getClass().getDeclaredMethod("e", String.class);
                weightMethod.setAccessible(true);
            }
            // Lectura de estado de Compose: dentro de la composicion de la capa, asi que se redibuja en cada cuadro.
            float w = ((Number) weightMethod.invoke(t, "artwork")).floatValue();
            double k = 1.0 - w;
            if (k <= 0.001) return tr;
            if (k > 1.0) k = 1.0;
            if (fa == null) {
                Class<?> c = tr.getClass();
                fa = c.getDeclaredField("a"); fb = c.getDeclaredField("b"); fc = c.getDeclaredField("c");
                fd = c.getDeclaredField("d"); fe = c.getDeclaredField("e"); ff = c.getDeclaredField("f");
                fa.setAccessible(true); fb.setAccessible(true); fc.setAccessible(true);
                fd.setAccessible(true); fe.setAccessible(true); ff.setAccessible(true);
                for (Constructor<?> k0 : c.getDeclaredConstructors()) {
                    Class<?>[] p = k0.getParameterTypes();
                    if (p.length == 6 && p[0] == double.class && p[4] == double.class) {
                        k0.setAccessible(true);
                        ctor = k0;
                    }
                }
                if (ctor == null) throw new IllegalStateException("zb4: sin constructor");
            }
            double x = fa.getDouble(tr), y = fb.getDouble(tr), wd = fc.getDouble(tr), ht = fd.getDouble(tr);
            double rot = fe.getDouble(tr);
            Object asp = ff.get(tr);
            int i = idx;
            if (i == 0) { // portada: del tamano de Artwork al de la portada chica
                x += (COVER_X - x) * k;
                y += (COVER_Y - y) * k;
                wd += (COVER_W - wd) * k;
                ht += (COVER_H - ht) * k;
            } else {      // textos y botones: solo se desplazan
                x += DX[i] * k;
                y += DY[i] * k;
            }
            return ctor.newInstance(x, y, wd, ht, rot, asp);
        } catch (Throwable e) {
            broken = true; // si algo no cuadra, se apaga el movimiento y todo queda como antes
            return tr;
        }
    }
}
