package app.eclipse.extension.player;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.util.DisplayMetrics;

import java.lang.reflect.Method;

/**
 * v0.20.393 (SIN COMPILAR / SIN PROBAR). Letra CURVA alrededor del disco (diseno "Tocadiscos").
 *
 * Eclipse dibuja cada linea de letra en nv1.G0 (xz1.I0 en el APK 0.6.75) con dos llamadas: yd8.q (color liso: lineas por
 * cantar y ya cantadas) y yd8.p (degradado: la linea que suena, una vez por renglon, dentro de LyricsPop.draw). Aqui:
 *  - enter()/leave(): el parche marca el inicio y el final de xz1.I0 y asi sabemos que el texto que se dibuja es de letra.
 *  - enter() decide si hay curva: solo en una zona de letra CHICA (la tarjeta de la vista del disco, menos de 35% del
 *    alto de pantalla). La vista de Letra grande no se toca.
 *  - clipOff(): el parche cambia el recorte de cada renglon (una banda recta) por uno enorme cuando hay curva, porque
 *    las silabas ya no estan en su banda.
 *  - drawColor() (gancho al inicio de yd8.q) y drawUnits() (lo llama LyricsPop.draw para yd8.p): dibujan la linea por
 *    pedacitos (una silaba cada uno): cada pedacito se mueve y se gira para quedar sobre un arco con centro en el
 *    centro del disco. Se vuelve a llamar al dibujo original de Eclipse, recortado a ese pedacito, asi el degradado
 *    del relleno sigue funcionando.
 * Todo a prueba de fallos: si algo no coincide, devuelve false y la letra se ve recta como siempre.
 * Ajustes: las constantes de abajo.
 */
public final class CurveText {
    private CurveText() {}

    // ---- Ajustes ----
    /** Centro del disco en la pantalla (fraccion de ancho / alto). Medido en la captura 1080x2400: (180, 760). */
    private static final float DISC_X = 180f / 1080f;
    private static final float DISC_Y = 760f / 2400f;
    /** Cuanto se curva: 1 = el arco del disco; 0.5 = la mitad. */
    private static final float GAIN = 1.0f;
    /** Solo hay curva si el renglon mide menos de esta fraccion del alto de pantalla (la tarjeta chica del disco; la Letra grande es mas alta). */
    private static final float CARD_MAX_ROW_H = 0.035f;
    /** Respaldo si no se puede saber donde esta la zona en la pantalla: eje y distancia al centro (px de una pantalla de 1080 de ancho / fraccion de alto). */
    private static final float FALLBACK_AXIS_X = 100f;
    private static final float FALLBACK_R0_H = 0.345f;
    private static final float MIN_RHO = 200f;

    public interface Painter {
        void paint() throws Exception;
    }

    private static boolean node;
    private static boolean armed;
    private static boolean inside;
    private static Canvas cv;
    private static float cxN, cyN, screenH;

    private static Class<?> qCls, qLayout;
    private static Method qMeth;

    /** Lo llama el parche al empezar xz1.I0 con el Canvas de Compose (o null). */
    public static void enter(Canvas c) {
        node = true;
        armed = false;
        cv = null;
        try {
            if (c == null) return;
            Rect b = new Rect();
            if (!c.getClipBounds(b)) return;
            DisplayMetrics dm = Resources.getSystem().getDisplayMetrics();
            float w = dm.widthPixels, h = dm.heightPixels;
            float vh = b.height(), vw = b.width();
            if (vw <= 0f || vh <= 0f || vw > w * 1.05f) return;
            screenH = h;
            Matrix m = new Matrix();
            c.getMatrix(m);
            float[] v = new float[9];
            m.getValues(v);
            if (Math.abs(v[Matrix.MSCALE_X] - 1f) > 0.02f || Math.abs(v[Matrix.MSCALE_Y] - 1f) > 0.02f
                    || Math.abs(v[Matrix.MSKEW_X]) > 0.001f || Math.abs(v[Matrix.MSKEW_Y]) > 0.001f) return;
            float tx = v[Matrix.MTRANS_X], ty = v[Matrix.MTRANS_Y];
            // Posicion de la zona en la pantalla (si el Canvas trabaja en coordenadas de pantalla). Si queda pegada a la
            // esquina (0,0) es que el Canvas es de una capa propia: no se sabe donde esta, se usan las constantes de respaldo.
            float devL = tx + b.left, devT = ty + b.top;
            boolean screen = devT > 0.10f * h || devL > 0.05f * w;
            if (screen) {
                cxN = DISC_X * w - tx;
                cyN = DISC_Y * h - ty;
            } else {
                cxN = b.left + FALLBACK_AXIS_X * (w / 1080f);
                cyN = b.top - FALLBACK_R0_H * h;
            }
            cv = c;
            armed = true;
        } catch (Throwable t) {
            armed = false;
            cv = null;
        }
    }

    /** Lo llama el parche justo antes de dibujar el contenido al final de xz1.I0. */
    public static void leave() {
        node = false;
        armed = false;
        cv = null;
    }

    public static boolean isArmed() {
        return armed && !inside;
    }

    /** El parche lo llama antes del recorte de cada renglon (fontPx = tamano de letra): true = usar un recorte enorme. */
    public static boolean clipOff(float fontPx) {
        return armed && fontPx * 1.2f < CARD_MAX_ROW_H * screenH;
    }

    /** Gancho al inicio de yd8.q(nw4, vy8, color). true = ya se dibujo (curvo) y hay que saltar el original. */
    public static boolean drawColor(final Object scope, final Object layout, final long color) {
        if (!armed || inside || scope == null || layout == null || cv == null) return false;
        try {
            final Method q = findQ(scope, layout);
            if (q == null) return false;
            int lines = LyricsPop.lineCount(layout);
            if (lines <= 0) return false;
            Painter p = new Painter() {
                public void paint() throws Exception {
                    q.invoke(null, scope, layout, Long.valueOf(color));
                }
            };
            boolean any = false;
            inside = true;
            try {
                for (int row = 0; row < lines; row++) {
                    if (drawUnits(cv, layout, row, p)) any = true;
                }
            } finally {
                inside = false;
            }
            return any;
        } catch (Throwable t) {
            inside = false;
            armed = false;
            System.out.println("CurveText: desactivado por error: " + t);
            return false;
        }
    }

    private static Method findQ(Object scope, Object layout) throws Exception {
        Class<?> lc = layout.getClass();
        if (qMeth != null && qLayout == lc) return qMeth;
        Class<?> y = lc.getClassLoader().loadClass("yd8");
        for (Method m : y.getDeclaredMethods()) {
            Class<?>[] p = m.getParameterTypes();
            if (m.getName().equals("q") && p.length == 3 && p[1] == lc && p[2] == long.class
                    && p[0].isAssignableFrom(scope.getClass())
                    && java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                m.setAccessible(true);
                qMeth = m;
                qLayout = lc;
                qCls = y;
                return m;
            }
        }
        return null;
    }

    /**
     * Dibuja UN renglon (row) del texto por pedacitos sobre el arco. painter vuelve a dibujar todo el texto con el
     * dibujo original de Eclipse (el recorte deja ver solo el pedacito). Devuelve false si no se pudo (nada se dibujo).
     */
    public static boolean drawUnits(Canvas c, Object layout, int row, Painter painter) {
        if (!armed || c == null) return false;
        try {
            float[][] u = LyricsPop.unitBoxes(layout, row);
            if (u == null) return false;
            int n = (int) u[4][0];
            if (n <= 0) return false;
            if (u[3][0] - u[2][0] >= CARD_MAX_ROW_H * screenH) return false;   // letra grande: recta
            for (int i = 0; i < n; i++) {
                float x0 = u[0][i], x1 = u[1][i], top = u[2][i], bot = u[3][i];
                float h = Math.max(1f, bot - top);
                float bl = (i == 0) ? -100000f : (u[1][i - 1] + x0) * 0.5f;
                float br = (i == n - 1) ? 100000f : (x1 + u[0][i + 1]) * 0.5f;
                float cx = (x0 + x1) * 0.5f, cy = (top + bot) * 0.5f;
                float rho = Math.max(MIN_RHO, cy - cyN);
                float phi = GAIN * (cx - cxN) / rho;
                float px = cxN + rho * (float) Math.sin(phi);
                float py = cyN + rho * (float) Math.cos(phi);
                int sv = c.save();
                try {
                    c.translate(px, py);
                    c.rotate((float) Math.toDegrees(-phi));
                    c.translate(-cx, -cy);
                    c.clipRect(bl, top - 0.12f * h, br, bot + 0.18f * h);
                    painter.paint();
                } finally {
                    c.restoreToCount(sv);
                }
            }
            return true;
        } catch (Throwable t) {
            armed = false;
            System.out.println("CurveText: desactivado por error: " + t);
            return false;
        }
    }
}
