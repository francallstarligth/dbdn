package app.eclipse.extension.player;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Application;
import android.graphics.Insets;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimationControlListener;
import android.view.WindowInsetsAnimationController;
import android.view.WindowInsetsController;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.420 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL). Esconde los botones de navegacion (cuadrado, circulo, triangulo)
 * mientras el reproductor grande esta abierto. Es TOTALMENTE INDEPENDIENTE de la barra de estado: no usa KeepAwake, tiene
 * su propio reloj, su propia busqueda de la actividad y su propio control de barra (solo navigationBars). El gancho (inicio
 * de ex7.e(), abrir el reproductor) solo llama a {@link #start()}.
 * A diferencia de la 0.20.419 la barra se esconde DE VERDAD (desvanecido y luego finish(false)), no se queda transparente
 * ocupando su espacio: asi el reproductor se acomoda igual que con gestos (sin que los controles suban sobre el titulo).
 * Al cerrar el reproductor se muestra con c.show(). Con navegacion por gestos el sistema no da el control: no hace nada.
 * El reloj se detiene solo cuando el reproductor esta cerrado y la barra ya volvio.
 */
public final class NavHide {
    private static final String TAG = "NavHide";
    private static final long OCULTAR_MS = 450L;
    private static final long PERIODO_MS = 250L;
    private static final long ESPERA_ABRIR_MS = 700L; // tras abrir, se espera a que la hoja suba

    private static Handler handler;
    private static boolean corriendo;
    private static boolean lifecycleOk;
    private static WeakReference<Activity> actual;
    private static Object flujo;
    private static Method getValor;
    private static long abiertoDesdeMs;
    private static long ultimaSemillaMs;

    private static WeakReference<Activity> escondida; // actividad cuya barra esta escondida
    private static WindowInsetsAnimationController ctl;
    private static Insets mostrado;
    private static ValueAnimator anim;
    private static boolean pidiendo;
    private static long pidiendoDesdeMs;
    private static long sinControlHasta; // si el sistema nego el control (gestos), no se insiste hasta que se cierre el reproductor

    private NavHide() {}

    /** Gancho del parche (inicio de ex7.e()). Cualquier hilo. */
    public static void start() {
        try {
            if (Build.VERSION.SDK_INT < 30) return;
            synchronized (NavHide.class) {
                if (corriendo) return;
                corriendo = true;
            }
            Looper main = Looper.getMainLooper();
            if (handler == null) handler = new Handler(main);
            handler.post(new Runnable() {
                @Override public void run() {
                    try {
                        iniciar();
                        tick();
                    } catch (Throwable t) {
                        Log.w(TAG, "start fallo", t);
                        synchronized (NavHide.class) { corriendo = false; }
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }

    private static void iniciar() {
        if (!lifecycleOk) {
            try {
                Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
                if (app instanceof Application) {
                    ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                        @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                        @Override public void onActivityPaused(Activity a) {
                            Activity c = actual == null ? null : actual.get();
                            if (c == a) actual = null;
                        }
                        @Override public void onActivityCreated(Activity a, android.os.Bundle b) { }
                        @Override public void onActivityStarted(Activity a) { }
                        @Override public void onActivityStopped(Activity a) { }
                        @Override public void onActivitySaveInstanceState(Activity a, android.os.Bundle b) { }
                        @Override public void onActivityDestroyed(Activity a) { }
                    });
                    lifecycleOk = true;
                }
            } catch (Throwable t) {
                Log.w(TAG, "lifecycle fallo", t);
            }
        }
        if (actual == null) semilla();
    }

    /** La actividad ya esta visible cuando se abre el reproductor: se busca en ActivityThread (mejor esfuerzo). */
    @SuppressWarnings("unchecked")
    private static void semilla() {
        long ahora = SystemClock.uptimeMillis();
        if (ahora - ultimaSemillaMs < 500L) return;
        ultimaSemillaMs = ahora;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "semilla fallo", t);
        }
    }

    private static boolean reproductorAbierto() {
        try {
            if (flujo == null || getValor == null) {
                Field f = Class.forName("ex7").getDeclaredField("a");
                f.setAccessible(true);
                Object fl = f.get(null);
                Method m = null;
                try {
                    m = fl.getClass().getMethod("getValue");
                } catch (NoSuchMethodException e) {
                    for (Class<?> c = fl.getClass(); c != null && m == null; c = c.getSuperclass()) {
                        try { m = c.getDeclaredMethod("getValue"); } catch (NoSuchMethodException ignored) { }
                    }
                }
                if (m == null) return false;
                m.setAccessible(true);
                flujo = fl;
                getValor = m;
            }
            return Boolean.TRUE.equals(getValor.invoke(flujo));
        } catch (Throwable t) {
            flujo = null;
            getValor = null;
            return false;
        }
    }

    private static void tick() {
        boolean seguir = true;
        try {
            seguir = revisar();
        } catch (Throwable t) {
            Log.w(TAG, "tick fallo", t);
        }
        if (seguir && handler != null) {
            handler.postDelayed(new Runnable() {
                @Override public void run() { tick(); }
            }, PERIODO_MS);
        } else {
            synchronized (NavHide.class) { corriendo = false; }
        }
    }

    /** @return false cuando ya no hay nada que vigilar (reproductor cerrado y barra ya devuelta). */
    private static boolean revisar() {
        boolean abierto = reproductorAbierto();
        long ahora = SystemClock.uptimeMillis();
        Activity a = actual == null ? null : actual.get();
        if (a == null && abierto) { semilla(); a = actual == null ? null : actual.get(); }
        Activity esc = escondida == null ? null : escondida.get();

        // vigilante: el sistema nunca contesto la peticion de control
        if (pidiendo && ahora - pidiendoDesdeMs > 1500L) pidiendo = false;
        // el sistema termino o cancelo el control sin avisar
        if (ctl != null) {
            boolean muerto;
            try { muerto = ctl.isFinished() || ctl.isCancelled(); } catch (Throwable t) { muerto = true; }
            if (muerto) soltar();
        }

        if (abierto) {
            if (abiertoDesdeMs == 0L) abiertoDesdeMs = ahora;
            if (esc == null && !pidiendo && a != null && a.hasWindowFocus()
                    && ahora - abiertoDesdeMs >= ESPERA_ABRIR_MS && ahora >= sinControlHasta) {
                pedir(a);
            }
            return true;
        }

        // reproductor cerrado
        abiertoDesdeMs = 0L;
        sinControlHasta = 0L;
        if (pidiendo) return true; // se cancela solo al llegar onReady
        if (esc != null || ctl != null) {
            devolver(esc != null ? esc : a);
            return true;
        }
        return false;
    }

    private static void pedir(Activity a) {
        try {
            Window w = a.getWindow();
            WindowInsetsController c = w == null ? null : w.getInsetsController();
            if (c == null) return;
            c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            pidiendo = true;
            pidiendoDesdeMs = SystemClock.uptimeMillis();
            escondida = new WeakReference<Activity>(a);
            c.controlWindowInsetsAnimation(WindowInsets.Type.navigationBars(), -1L, null, new CancellationSignal(),
                    new Listener());
        } catch (Throwable t) {
            pidiendo = false;
            escondida = null;
            Log.w(TAG, "pedir fallo", t);
        }
    }

    private static void esconder(final WindowInsetsAnimationController c) {
        try {
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
            ValueAnimator va = ValueAnimator.ofFloat(1f, 0f);
            va.setDuration(OCULTAR_MS);
            va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override public void onAnimationUpdate(ValueAnimator v) {
                    try {
                        float x = ((Float) v.getAnimatedValue()).floatValue();
                        c.setInsetsAndAlpha(mostrado, x, x);
                    } catch (Throwable t) {
                        soltar();
                    }
                }
            });
            va.addListener(new AnimatorListenerAdapter() {
                private boolean cancelado;
                @Override public void onAnimationCancel(Animator an) { cancelado = true; }
                @Override public void onAnimationEnd(Animator an) {
                    if (cancelado) return;
                    anim = null;
                    // se esconde de verdad: la barra deja de ocupar espacio
                    try {
                        ctl = null;
                        c.finish(false);
                    } catch (Throwable t) {
                        Log.w(TAG, "finish(false) fallo", t);
                    }
                }
            });
            anim = va;
            va.start();
        } catch (Throwable t) {
            Log.w(TAG, "esconder fallo", t);
        }
    }

    /** Reproductor cerrado: la barra vuelve. */
    private static void devolver(Activity a) {
        try {
            WindowInsetsAnimationController c = ctl;
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); anim = null; }
            if (c != null) {
                ctl = null;
                try { c.finish(true); } catch (Throwable ignored) { }
            }
            if (a != null) {
                Window w = a.getWindow();
                WindowInsetsController wc = w == null ? null : w.getInsetsController();
                if (wc != null) wc.show(WindowInsets.Type.navigationBars());
            }
        } catch (Throwable t) {
            Log.w(TAG, "devolver fallo", t);
        }
        escondida = null;
    }

    private static void soltar() {
        try {
            if (anim != null) { anim.removeAllListeners(); anim.cancel(); }
        } catch (Throwable ignored) { }
        anim = null;
        ctl = null;
        pidiendo = false;
    }

    private static final class Listener implements WindowInsetsAnimationControlListener {
        @Override public void onReady(WindowInsetsAnimationController controller, int types) {
            try {
                pidiendo = false;
                mostrado = controller.getShownStateInsets();
                if (!reproductorAbierto()) { // se cerro mientras se pedia el control
                    try { controller.finish(true); } catch (Throwable ignored) { }
                    escondida = null;
                    return;
                }
                ctl = controller;
                controller.setInsetsAndAlpha(mostrado, 1f, 1f);
                esconder(controller);
            } catch (Throwable t) {
                Log.w(TAG, "onReady fallo", t);
                soltar();
                escondida = null;
            }
        }
        @Override public void onFinished(WindowInsetsAnimationController controller) { }
        @Override public void onCancelled(WindowInsetsAnimationController controller) {
            // el sistema no dio el control (ej. navegacion por gestos) o lo quito a medias (ej. bajaron las notificaciones)
            boolean teniaControl = ctl != null;
            soltar();
            escondida = null;
            sinControlHasta = teniaControl ? SystemClock.uptimeMillis() + 2000L : Long.MAX_VALUE;
        }
    }
}
