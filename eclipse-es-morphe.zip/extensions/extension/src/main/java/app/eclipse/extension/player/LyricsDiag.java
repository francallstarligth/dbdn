package app.eclipse.extension.player;

/**
 * v0.20.126: los mensajitos Toast de diagnostico de las letras (v0.20.123) ya no se muestran; toast() queda vacio para
 * no tocar a quienes lo llaman (LyricsPlusMochy, LyricsRetry).
 */
final class LyricsDiag {
    private LyricsDiag() {}

    static void toast(final String msg) {
    }
}
