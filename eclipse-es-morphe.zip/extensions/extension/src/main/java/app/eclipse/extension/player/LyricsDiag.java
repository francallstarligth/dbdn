package app.eclipse.extension.player;

/**
 * v0.20.123 (SIN COMPILAR / SIN PROBAR). Mensajitos Toast de diagnostico de las letras (hay que QUITARLOS cuando se sepa
 * por que falla la busqueda). Contexto por ActivityThread.currentApplication, como LyricsGlowShader.say.
 */
final class LyricsDiag {
    private LyricsDiag() {}

    static void toast(final String msg) {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            final android.content.Context ctx = (android.content.Context) at.getMethod("currentApplication").invoke(null);
            if (ctx == null) return;
            new android.os.Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                public void run() {
                    try {
                        android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show();
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
