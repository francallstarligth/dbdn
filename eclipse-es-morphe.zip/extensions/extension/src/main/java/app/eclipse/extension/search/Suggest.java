package app.eclipse.extension.search;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * v0.20.427 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias mientras escribes, sacadas de los resultados que la busqueda YA trae
 * (`Lz59;->q`, camino de addon de metadatos: Spotify o Apple). No hace ninguna peticion extra.
 * - note(): se llama al final de `Lz59;->q` con el `Lm49` (listas: canciones, albumes, artistas, playlists). Guarda hasta 2 artistas + 4 titulos de canciones.
 * - len()/list()/title(): ganchos en `Lmd8;->t` (pantalla de busqueda). La lista de "Recent searches" solo se pintaba con la caja vacia; mientras hay texto
 *   y hay sugerencias, se pinta con las sugerencias (y se llama "Sugerencias"). Con la caja vacia todo queda igual que antes.
 * Todo con try/catch: si algo falla, devuelve lo original.
 */
public final class Suggest {
    private static volatile List<String> sug = Collections.emptyList();
    private static volatile boolean typing = false;

    private Suggest() {}

    /** n = largo del texto escrito. Devuelve 0 (= "caja vacia") si hay que pintar la lista; si no, n. */
    public static int len(int n) {
        try {
            if (n == 0) {
                sug = Collections.emptyList();
                typing = false;
                return 0;
            }
            typing = !sug.isEmpty();
            return typing ? 0 : n;
        } catch (Throwable t) {
            typing = false;
            return n;
        }
    }

    public static List<String> list(List<String> orig) {
        try {
            return typing ? sug : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    public static String title(String orig) {
        try {
            return typing ? "Sugerencias" : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    /** m49 = `Lm49;` (cuatro listas). Se busca por reflexion: artistas (getName) y canciones (getTitle). */
    public static void note(Object m49) {
        try {
            if (m49 == null) return;
            List<String> artists = new ArrayList<>();
            List<String> tracks = new ArrayList<>();
            for (Field f : m49.getClass().getDeclaredFields()) {
                if (!List.class.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                Object v = f.get(m49);
                if (!(v instanceof List)) continue;
                for (Object it : (List<?>) v) {
                    if (it == null) continue;
                    String cn = it.getClass().getSimpleName();
                    if (cn.equals("CanonicalArtist")) {
                        add(artists, call(it, "getName"));
                    } else if (cn.equals("CanonicalTrack")) {
                        add(tracks, call(it, "getTitle"));
                    }
                }
            }
            List<String> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < artists.size() && i < 2; i++) put(out, seen, artists.get(i));
            for (int i = 0; i < tracks.size() && out.size() < 6; i++) put(out, seen, tracks.get(i));
            sug = out;
        } catch (Throwable t) {
            // se queda con lo anterior
        }
    }

    private static String call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        Object r = m.invoke(o);
        return r == null ? null : r.toString();
    }

    private static void add(List<String> l, String s) {
        if (s != null && !s.trim().isEmpty()) l.add(s.trim());
    }

    private static void put(List<String> out, Set<String> seen, String s) {
        if (seen.add(s.toLowerCase(Locale.ROOT))) out.add(s);
    }
}
