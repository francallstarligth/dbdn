package app.eclipse.extension.search;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import org.json.JSONObject;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * v0.20.435 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). tapped(): al tocar una sugerencia/reciente se esconden las sugerencias mientras la caja tenga ese texto. Antes: v0.20.434. Sin avisos de prueba (DEBUG=false); hideClear() y icon() quitan el boton Clear y el reloj en las sugerencias. Antes: v0.20.433. Sugerencias mientras escribes, sacadas de los resultados que la busqueda YA trae. Sin peticiones extra.
 * La pantalla REAL de busqueda es la del "modo nativo": `Ly12;->r` crea `Lju6` (el contenido del LazyColumn, `Lju6;->invoke(Lh15)`), con items: `Lig4` (barra), y con
 * texto vacio: header `Lpb` caso 25 ("Recently Searched") + filas `Llu6` (cada fila = un JSONObject con "title"/"subtitle", sale de `Lwt6.c`); con texto: resultados.
 * - note(): se llama en `Lz59;->b` con el `Lm49`. Guarda hasta 2 artistas + 4 titulos de canciones.
 * - add(): se llama en `Lju6;->invoke` justo despues del item `Lig4`. Si hay texto y sugerencias, agrega (por reflexion, para no pelear con registros de smali) un header
 *   `Lpb`(25) y las filas `Llu6` con las sugerencias convertidas a JSONObject, igual que hace la pantalla con los recientes. Tocar una fila busca ese texto.
 * - seen()/title(): ganchos en `Lpb;->x` para que el header de las sugerencias diga "Sugerencias" y el de recientes siga igual.
 * DIAGNOSTICO (DEBUG): cada aviso sale en un Toast Y se copia al portapapeles (junto con los ultimos avisos, con hora), para pegarlo en el chat.
 */
public final class Suggest {
    private static volatile List<String> sug = Collections.emptyList();

    // headers (Lpb) creados por add(); por identidad
    private static final Set<Object> HEADERS = Collections.newSetFromMap(new java.util.WeakHashMap<Object, Boolean>());
    private static volatile boolean curIsSug = false;

    // texto de la ultima sugerencia/reciente tocada (Lz59.t) y cuando
    private static volatile String tappedText = null;
    private static volatile long tappedAt = 0L;

    private static final boolean DEBUG = false;
    private static final int MAX_LOG = 30;
    private static final List<String> LOG = new ArrayList<>();
    private static String lastMsg = "";
    private static int repeats = 0;

    private static final int KEY_HEADER = 980637915;
    private static final int KEY_ITEMS = 802480019;

    private Suggest() {}

    /** q = texto escrito; scope = `Lh15` (LazyListScope); ju6 = `Lju6` (this). */
    public static void add(String q, Object scope, Object ju6) {
        try {
            boolean hayTexto = q != null && !q.trim().isEmpty();
            if (!hayTexto) {
                tappedText = null;
                sug = Collections.emptyList();
                dbg("add: caja vacia");
                return;
            }
            String tt = tappedText;
            if (tt != null) {
                boolean same = q.trim().toLowerCase(Locale.ROOT).equals(tt);
                // mismo texto = ya se eligio una sugerencia; ventana corta por si llega un cuadro con el texto viejo
                if (same || System.currentTimeMillis() - tappedAt < 1500L) return;
                tappedText = null;
            }
            final List<String> s = sug;
            if (s.isEmpty()) {
                dbg("add: texto=\"" + q + "\" pero aun no hay sugerencias");
                return;
            }
            Object xs6 = field(ju6, "q");
            Object wt6 = field(ju6, "r");
            Object qState = field(ju6, "s");
            Object z59 = field(ju6, "x");
            Object pz9 = field(ju6, "C");
            Object str = field(ju6, "D");
            Object ad3 = field(ju6, "E");
            Object hea = field(ju6, "F");

            List<JSONObject> rows = new ArrayList<>();
            for (String t : s) {
                JSONObject o = new JSONObject();
                o.put("title", t);
                o.put("subtitle", "");
                o.put("sug", true);
                rows.add(o);
            }

            // header = igual que el de recientes (Lpb caso 25), pero marcado
            Object pb = newInst("pb", xs6, wt6, z59, 25);
            HEADERS.add(pb);
            Object hdr = newInst("fq1", pb, Boolean.TRUE, KEY_HEADER);
            Method y0 = findMethod("h15", "y0", 4, true);
            y0.invoke(null, scope, null, hdr, 3);

            // filas = igual que las de recientes (Llu6 + Ltq6 + Lfq1) con items(count, null, Ltq6, content)
            Object lu6 = newInst("lu6", rows, z59, pz9, str, qState, wt6, ad3, xs6, hea);
            Object tq6 = newInst("tq6", rows, 9);
            Object content = newInst("fq1", lu6, Boolean.TRUE, KEY_ITEMS);
            Method z0 = findMethod("h15", "z0", 4, false);
            z0.invoke(scope, rows.size(), null, tq6, content);
            dbg("add OK: texto=\"" + q + "\" filas=" + rows.size());
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            StackTraceElement[] st = c.getStackTrace();
            dbg("add ERROR: " + c + (st.length > 0 ? " @ " + st[0] : ""));
        }
    }

    /** `Lpb;->x` (header "Recently Searched"): saber si esta instancia es la de las sugerencias. */
    public static void seen(Object pb) {
        try {
            curIsSug = pb != null && HEADERS.contains(pb);
        } catch (Throwable t) {
            curIsSug = false;
        }
    }

    /** `Lz59;->t(String)`: se toco una sugerencia o un reciente. */
    public static void tapped(String text) {
        try {
            if (text == null || text.trim().isEmpty()) return;
            tappedText = text.trim().toLowerCase(Locale.ROOT);
            tappedAt = System.currentTimeMillis();
        } catch (Throwable ignored) {}
    }

    /** `Lpb;->x`: true si el header actual es el de las sugerencias (entonces no se dibuja "Clear"). */
    public static boolean hideClear() {
        return curIsSug;
    }

    /** `Llu6;->k`: icono de la fila; null (sin icono) si la fila es una sugerencia. */
    public static Object icon(JSONObject row, Object orig) {
        try {
            return row != null && row.optBoolean("sug", false) ? null : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    public static String title(String orig) {
        try {
            dbg("title: sugerencias=" + curIsSug);
            return curIsSug ? "Sugerencias" : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    /** m49 = `Lm49;` (cuatro listas). Se busca por reflexion: artistas (getName) y canciones (getTitle). */
    public static void note(Object m49) {
        try {
            if (m49 == null) {
                dbg("note: m49 nulo");
                return;
            }
            List<String> artists = new ArrayList<>();
            List<String> tracks = new ArrayList<>();
            int listas = 0;
            for (Field f : m49.getClass().getDeclaredFields()) {
                if (!List.class.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                Object v = f.get(m49);
                if (!(v instanceof List)) continue;
                listas++;
                for (Object it : (List<?>) v) {
                    if (it == null) continue;
                    String cn = it.getClass().getSimpleName();
                    if (cn.equals("CanonicalArtist")) {
                        add(artists, call(it, "getName"));
                    } else if (cn.equals("CanonicalTrack")) {
                        add(tracks, call(it, "getTitle"));
                    }
                }
            }
            List<String> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < artists.size() && i < 2; i++) put(out, seen, artists.get(i));
            for (int i = 0; i < tracks.size() && out.size() < 6; i++) put(out, seen, tracks.get(i));
            sug = out;
            dbg("note: listas=" + listas + " art=" + artists.size() + " trk=" + tracks.size() + " out=" + out.size() + " " + out);
        } catch (Throwable t) {
            dbg("note ERROR: " + t);
        }
    }

    // ---------- reflexion ----------
    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    private static Object newInst(String cn, Object... a) throws Exception {
        Class<?> c = Class.forName(cn, true, Suggest.class.getClassLoader());
        Exception last = null;
        for (Constructor<?> k : c.getDeclaredConstructors()) {
            if (k.getParameterTypes().length != a.length) continue;
            try {
                k.setAccessible(true);
                return k.newInstance(a);
            } catch (Exception e) {
                last = e;
            }
        }
        throw last != null ? last : new NoSuchMethodException(cn + " ctor/" + a.length);
    }

    private static Method findMethod(String cn, String name, int nparams, boolean isStatic) throws Exception {
        Class<?> c = Class.forName(cn, true, Suggest.class.getClassLoader());
        for (Method m : c.getDeclaredMethods()) {
            if (m.getName().equals(name) && m.getParameterTypes().length == nparams
                    && Modifier.isStatic(m.getModifiers()) == isStatic) {
                m.setAccessible(true);
                return m;
            }
        }
        throw new NoSuchMethodException(cn + "." + name + "/" + nparams);
    }

    // ---------- diagnostico ----------
    private static synchronized void dbg(String msg) {
        if (!DEBUG) return;
        try {
            if (msg.equals(lastMsg)) {
                repeats++;
                return; // no repetir el mismo aviso seguido
            }
            if (repeats > 0 && !LOG.isEmpty()) {
                LOG.set(LOG.size() - 1, LOG.get(LOG.size() - 1) + " (x" + (repeats + 1) + ")");
            }
            repeats = 0;
            lastMsg = msg;
            String hora = new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date());
            LOG.add(hora + " " + msg);
            while (LOG.size() > MAX_LOG) LOG.remove(0);
            final String toast = "Sug " + msg;
            final StringBuilder all = new StringBuilder("Sugerencias v0.20.434\n");
            for (String l : LOG) all.append(l).append('\n');
            final String clip = all.toString();
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Sugerencias", clip));
                    } catch (Throwable ignored) {}
                    try { Toast.makeText(ctx, toast, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    private static String call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        Object r = m.invoke(o);
        return r == null ? null : r.toString();
    }

    private static void add(List<String> l, String s) {
        if (s != null && !s.trim().isEmpty()) l.add(s.trim());
    }

    private static void put(List<String> out, Set<String> seen, String s) {
        if (seen.add(s.toLowerCase(Locale.ROOT))) out.add(s);
    }
}
