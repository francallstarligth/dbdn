package app.eclipse.extension.search;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * v0.20.430 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias mientras escribes, sacadas de los resultados que la busqueda YA trae. Sin peticiones extra.
 * - note(): se llama en `Lz59;->b` con el `Lm49` (canciones, albumes, artistas, playlists). Guarda hasta 2 artistas + 4 titulos de canciones.
 * - show()/list()/title(): ganchos en la pantalla REAL de busqueda (`Ls6b;->d` -> `Lj7a;->invoke` (LazyColumn) -> `Lgw6;->q` -> `Ls6b;->c`). Con texto y sugerencias,
 *   se agrega un item "suggest" que reutiliza el de "recientes" pero con las sugerencias y el titulo "Sugerencias". Con la caja vacia todo queda igual.
 *   (Lmd8.t NO es la pantalla que se ve: por eso las 0.20.427-429 no mostraban nada.)
 * Todo con try/catch: si algo falla, devuelve lo original.
 */
public final class Suggest {
    private static volatile List<String> sug = Collections.emptyList();
    private static volatile boolean typing = false;
    /** DIAGNOSTICO v0.20.429: avisos (Toast) para ver donde se corta. Quitar cuando funcione. */
    private static final boolean DEBUG = true;
    private static String lastKey = "";

    private Suggest() {}

    /** q = texto escrito. true (= "agrega la lista de sugerencias") si hay texto y hay sugerencias; con la caja vacia limpia todo. */
    public static boolean show(String q) {
        try {
            if (q == null || q.trim().isEmpty()) {
                sug = Collections.emptyList();
                typing = false;
                return false;
            }
            typing = !sug.isEmpty();
            dbg("show", "Sug show: sug=" + sug.size() + " typing=" + typing);
            return typing;
        } catch (Throwable t) {
            typing = false;
            return false;
        }
    }

    public static List<String> list(List<String> orig) {
        try {
            return typing ? sug : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    public static String title(String orig) {
        try {
            return typing ? "Sugerencias" : orig;
        } catch (Throwable t) {
            return orig;
        }
    }

    /** m49 = `Lm49;` (cuatro listas). Se busca por reflexion: artistas (getName) y canciones (getTitle). */
    public static void note(Object m49) {
        try {
            if (m49 == null) return;
            List<String> artists = new ArrayList<>();
            List<String> tracks = new ArrayList<>();
            for (Field f : m49.getClass().getDeclaredFields()) {
                if (!List.class.isAssignableFrom(f.getType())) continue;
                f.setAccessible(true);
                Object v = f.get(m49);
                if (!(v instanceof List)) continue;
                for (Object it : (List<?>) v) {
                    if (it == null) continue;
                    String cn = it.getClass().getSimpleName();
                    if (cn.equals("CanonicalArtist")) {
                        add(artists, call(it, "getName"));
                    } else if (cn.equals("CanonicalTrack")) {
                        add(tracks, call(it, "getTitle"));
                    }
                }
            }
            List<String> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < artists.size() && i < 2; i++) put(out, seen, artists.get(i));
            for (int i = 0; i < tracks.size() && out.size() < 6; i++) put(out, seen, tracks.get(i));
            sug = out;
            dbg("note", "Sug note: art=" + artists.size() + " trk=" + tracks.size() + " out=" + out.size());
        } catch (Throwable t) {
            dbg("noteErr", "Sug note ERROR: " + t);
        }
    }

    private static void dbg(String k, final String msg) {
        if (!DEBUG) return;
        try {
            if (msg.equals(lastKey)) return;
            lastKey = msg;
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }

    private static String call(Object o, String name) throws Exception {
        Method m = o.getClass().getMethod(name);
        Object r = m.invoke(o);
        return r == null ? null : r.toString();
    }

    private static void add(List<String> l, String s) {
        if (s != null && !s.trim().isEmpty()) l.add(s.trim());
    }

    private static void put(List<String> out, Set<String> seen, String s) {
        if (seen.add(s.toLowerCase(Locale.ROOT))) out.add(s);
    }
}
