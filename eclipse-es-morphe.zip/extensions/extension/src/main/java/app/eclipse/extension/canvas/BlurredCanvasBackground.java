package app.eclipse.extension.canvas;

import android.util.Log;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Ayuda del parche "Custom: Canvas detras del fondo Blurred Cover".
 *
 * El fondo "Blurred Cover" del Custom lo dibuja di6.c(sv0, Z, Song, ki1, I) (rama BLURRED_ARTWORK): la portada
 * agrandada 1.2x con blur. Esa funcion no recibe la URL del Canvas (esta en ow0.w), asi que el video se dibuja
 * justo DESPUES de di6.c, en eg6.g, donde si se tiene ow0. Se llama por reflexion con los nombres de 0.6.47
 * (sin tocar registros de Eclipse). Si algo falla no dibuja nada y Eclipse sigue como siempre.
 *
 * Siempre abre y cierra un grupo de Compose propio (clave fija) para que la estructura sea la misma haya o no video.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class BlurredCanvasBackground {
    private static final String TAG = "BlurredCanvasBg";
    /** ASCII "CNVB". */
    private static final int GROUP_KEY = 0x434e5642;

    private static boolean tried;
    private static boolean ready;
    private static Object companion;   // jh5.q (Modifier.Companion)
    private static Method fillMax;     // g48.e(mh5, float)
    private static Method scale;       // yg2.H(mh5, float, float)
    private static Method blur;        // by9.k(mh5, float)
    private static Method video;       // xi6.h(String, boolean, mh5, ki1, int)
    private static Method startGroup;  // qi1.c0(int)
    private static Method endGroup;    // qi1.q(boolean)
    private static Field bgType;       // sv0.a (ni0)
    private static Field bgBlur;       // sv0.e (double)
    private static Field stUrl;        // ow0.w (String)
    private static Field stPlaying;    // ow0.b (boolean)

    private BlurredCanvasBackground() {}

    private static Method find(Class c, String name, Class[] params) throws Exception {
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals(name)) continue;
            Class[] p = m.getParameterTypes();
            if (p.length != params.length) continue;
            boolean same = true;
            for (int i = 0; i < p.length; i++) if (p[i] != params[i]) { same = false; break; }
            if (!same) continue;
            m.setAccessible(true);
            return m;
        }
        throw new NoSuchMethodException(c.getName() + "." + name);
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    private static synchronized boolean init() {
        if (tried) return ready;
        tried = true;
        try {
            Class mh5 = Class.forName("mh5");
            Class ki1 = Class.forName("ki1");
            Class qi1 = Class.forName("qi1");
            Class jh5 = Class.forName("jh5");
            Field q = jh5.getDeclaredField("q");
            q.setAccessible(true);
            companion = q.get(null);
            fillMax = find(Class.forName("g48"), "e", new Class[]{mh5, float.class});
            scale = find(Class.forName("yg2"), "H", new Class[]{mh5, float.class, float.class});
            blur = find(Class.forName("by9"), "k", new Class[]{mh5, float.class});
            video = find(Class.forName("xi6"), "h", new Class[]{String.class, boolean.class, mh5, ki1, int.class});
            startGroup = find(qi1, "c0", new Class[]{int.class});
            endGroup = find(qi1, "q", new Class[]{boolean.class});
            Class sv0 = Class.forName("sv0");
            bgType = field(sv0, "a");
            bgBlur = field(sv0, "e");
            Class ow0 = Class.forName("ow0");
            stUrl = field(ow0, "w");
            stPlaying = field(ow0, "b");
            ready = true;
        } catch (Throwable t) {
            Log.w(TAG, "init fallo: " + t);
            ready = false;
        }
        return ready;
    }

    /**
     * @param bg       sv0 (el fondo del layout Custom)
     * @param state    ow0 (estado del reproductor; puede ser null)
     * @param composer qi1 (el composer actual)
     */
    public static void draw(Object bg, Object state, Object composer) {
        if (composer == null || !init()) return;
        boolean opened = false;
        try {
            startGroup.invoke(composer, GROUP_KEY);
            opened = true;
            if (bg == null || state == null) return;
            Object type = bgType.get(bg);
            if (!(type instanceof Enum) || !"BLURRED_ARTWORK".equals(((Enum) type).name())) return;
            Object u = stUrl.get(state);
            if (!(u instanceof String) || ((String) u).isEmpty()) return;
            boolean playing = stPlaying.getBoolean(state);
            float radius = (float) (40.0 * bgBlur.getDouble(bg) + 20.0);

            // Igual que la portada borrosa de di6.c: llena el espacio, 1.2x, con el mismo blur.
            Object mod = fillMax.invoke(null, companion, 1.0f);
            mod = scale.invoke(null, mod, 1.2f, 1.2f);
            mod = blur.invoke(null, mod, radius);
            video.invoke(null, (String) u, playing, mod, composer, 0x180);
        } catch (Throwable t) {
            Log.w(TAG, "draw fallo: " + t);
        } finally {
            if (opened) {
                try { endGroup.invoke(composer, false); } catch (Throwable ignored) {}
            }
        }
    }
}
