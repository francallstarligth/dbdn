package app.eclipse.extension.canvas;

import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Ayuda del parche "Custom: Canvas detras del fondo Blurred Cover".
 *
 * El fondo "Blurred Cover" del Custom lo dibuja j87.c(i11, Z, Song, fp1, I) (rama BLURRED_ARTWORK): la portada
 * agrandada 1.2x con blur. Esa funcion no recibe la URL del Canvas (esta en e21.w), asi que el video se dibuja
 * justo DESPUES de j87.c, en n77.g, donde si se tiene e21. Se llama por reflexion con los nombres de 0.6.47
 * (sin tocar registros de Eclipse). Si algo falla no dibuja nada y Eclipse sigue como siempre.
 *
 * Si el layout es INMERSIVO (hay una capa de portada visible con edgeFade, como la plantilla del usuario), el video
 * no se dibuja a pantalla completa: se dibuja como REFLEJO (volteado en vertical) justo debajo de la portada nitida,
 * del mismo tamano que ella, para que el borde inferior de la portada se continue en espejo. En los demas layouts
 * queda como antes (pantalla completa, sin voltear).
 *
 * Siempre abre y cierra un grupo de Compose propio (clave fija) para que la estructura sea la misma haya o no video.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class BlurredCanvasBackground {
    private static final String TAG = "BlurredCanvasBg";
    /** ASCII "CNVB". */
    private static final int GROUP_KEY = 0x434e5642;
    /** Fraccion del alto de la portada que el reflejo sube por detras de ella (ajustable). */
    private static final double OVERLAP = 0.5;
    /** dp extra que la caja del reflejo se pasa por debajo de la pantalla. */
    private static final float EXTRA_BOTTOM_DP = 100f;
    /** v1.34.0: multiplicador del radio del blur del video (1.0 = igual que la portada borrosa). */
    private static final float BLUR_MULT = 1.4f;
    /** v1.34.0: opacidad del video; menos de 1 deja ver el fondo oscuro de abajo y oscurece. */
    private static final float VIDEO_ALPHA = 1.0f; // v0.20.1: opaco (antes 0.55) para que la portada borrosa de atras no se vea ni tina

    /** v0.20.10: oscurecimiento general fijo (0..1) entre el fondo/reflejo y los textos/botones. Ajustable. */
    private static volatile float dimAlpha = 0.25f; // v0.20.26: ajustable desde la opcion del parche (default 25%)

    /** v0.20.26: lo llama el gancho del parche con el porcentaje (0 a 100) de la opcion "Oscurecimiento". */
    public static void setDim(int percent) {
        dimAlpha = Math.max(0, Math.min(100, percent)) / 100f;
    }

    /** v0.20.55: lo enciende el parche "Reflejo liviano". Hace el reflejo de portada con una copia 1/LIGHT_K y lo estira. */
    private static volatile boolean lightRefl;
    private static final float LIGHT_K = 3f;
    public static void enableLightReflection() { lightRefl = true; }
    /** v0.20.56: lo enciende el parche "Reflejo liviano (Canvas)": lo mismo pero con el video del Canvas como reflejo. */
    private static volatile boolean lightCanvas;
    public static void enableLightCanvas() { lightCanvas = true; }
    /** v0.20.61: lo enciende el parche "Fondo liviano de Letras y Cola": la portada borrosa de Letra/Cola se borronea en una caja 1/LIGHT_PANE_K y se estira. */
    private static volatile boolean lightPane;
    private static final float LIGHT_PANE_K = 6f;
    public static void enableLightPane() { lightPane = true; }

    private static boolean tried;
    private static boolean ready;
    private static Object companion;   // ht5.q (Modifier.Companion)
    private static Method fillMax;     // hx8.e(kt5, float)
    private static Method scale;       // yp7.H(kt5, float, float)
    private static Method layer;    // jv6.F(kt5, sx, sy, alpha, rotZ, es8, fr0, mask)  (graphicsLayer); puede faltar
    private static Method blur;        // o24.i(kt5, float)
    private static Method video;       // d97.h(String, boolean, kt5, fp1, int)
    private static Method blurFx;      // v0.20.2: jv6.D(kt5, kd3)  (graphicsLayer { ... })
    private static Constructor pmCtor; // v0.20.2: vr0(float rx, float ry, int tileMode, boolean clip)
    private static boolean softReady;  // v0.20.2: hay desenfoque con borde suave
    private static Method startGroup;  // lp1.d0(int)
    private static Method endGroup;    // lp1.q(boolean)
    private static Field bgType;       // i11.a (ni0)
    private static Field bgBlur;       // i11.e (double)
    private static Field stUrl;        // e21.w (String)
    private static Field stPlaying;    // e21.b (boolean)
    private static Method then;        // kt5.c(kt5)  (Modifier.then)
    private static Method fillWidth;   // hx8.g(kt5, float)
    private static Method offset;      // km2.N(kt5, float, float)  (Modifier.offset(x, y))
    private static Constructor sizeEl; // gx8(float minW, float minH, float maxW, float maxH, boolean enforceIncoming)
    private static Field layLayers;    // w17.e (List<s11>)
    private static Field lyKind;       // s11.b (ob4)
    private static Field lyVisible;    // s11.k (boolean)
    private static Field lyArtwork;    // s11.A (r70)
    private static Field lyTransform;  // s11.d (lm4)
    private static Field awFade;       // r70.i (edgeFade)
    private static Field trX, trY, trW, trH; // lm4.a..d (double)
    // v1.49.0: reflejo de la portada normal (canciones sin Canvas)
    private static boolean coverReady;
    private static Field stSong;          // e21.a (Song)
    private static Constructor modelCtor; // p67(Song, int)  -> id3 que devuelve coverURL
    private static Constructor reqCtor;   // yw3(String, yt1, pg1, float, long, int)
    private static Method image;          // to7.a(id3, kt5, yd3, ax3, yw3, kd3, ae3, fp1, int, int, int)
    private static Object cachedSong;
    private static Object cachedModel;
    private static Object cachedReq;      // yw3 por defecto: es inmutable, se crea una sola vez
    private static Object cachedHoleReq;  // v0.20.145: yw3 propio del reflejo del HUECO del Canvas
    private static Object cachedReq2;     // v0.20.20: yw3 del relleno chiquito (otro objeto, otro sitio de PrevCover)
    private static boolean fillNext;      // v0.20.20: songForBlurFill quito el fondo original -> draw() rellena
    private static boolean fillFailed;
    /** v0.20.20: el relleno es 1/FILL_K del tamano de la pantalla, estirado (el blur se hace sobre pocos pixeles). */
    private static final float FILL_K = 8f;

    private BlurredCanvasBackground() {}

    private static Method find(Class c, String name, Class[] params) throws Exception {
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals(name)) continue;
            Class[] p = m.getParameterTypes();
            if (p.length != params.length) continue;
            boolean same = true;
            for (int i = 0; i < p.length; i++) if (p[i] != params[i]) { same = false; break; }
            if (!same) continue;
            m.setAccessible(true);
            return m;
        }
        throw new NoSuchMethodException(c.getName() + "." + name);
    }

    /** Escala (sx, sy) y opacidad VIDEO_ALPHA en una sola capa; si no hay graphicsLayer, solo escala. */
    private static Object scaleDim(Object mod, float sx, float sy) throws Exception {
        if (layer != null) {
            // mascara de valores por defecto: todo menos scaleX, scaleY y alpha (0x7fffc sin el bit 0x4 y sin 0x1/0x2)
            return layer.invoke(null, mod, sx, sy, VIDEO_ALPHA, 0f, null, null, 0x7fff8);
        }
        return scale.invoke(null, mod, sx, sy);
    }

    private static Class mhClass() throws Exception {
        return Class.forName("ou5");
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    private static synchronized boolean init() {
        if (tried) return ready;
        tried = true;
        try {
            Class kt5 = Class.forName("ou5");
            Class fp1 = Class.forName("cq1");
            Class lp1 = Class.forName("iq1");
            Class ht5 = Class.forName("lu5");
            Field q = ht5.getDeclaredField("q");
            q.setAccessible(true);
            companion = q.get(null);
            fillMax = find(Class.forName("kz8"), "e", new Class[]{kt5, float.class});
            scale = find(Class.forName("qs7"), "X", new Class[]{kt5, float.class, float.class});
            try {
                layer = find(Class.forName("br7"), "C", new Class[]{kt5, float.class, float.class, float.class, float.class,
                        Class.forName("ku8"), Class.forName("vr0"), int.class});
            } catch (Throwable t) {
                layer = null;
                Log.w(TAG, "sin graphicsLayer (sin oscurecer): " + t);
            }
            blur = find(Class.forName("ui4"), "h", new Class[]{kt5, float.class});
            video = find(Class.forName("ka7"), "h", new Class[]{String.class, boolean.class, kt5, fp1, int.class});
            startGroup = find(lp1, "d0", new Class[]{int.class});
            endGroup = find(lp1, "q", new Class[]{boolean.class});
            Class i11 = Class.forName("y11");
            bgType = field(i11, "a");
            bgBlur = field(i11, "e");
            Class e21 = Class.forName("u21");
            stUrl = field(e21, "w");
            stPlaying = field(e21, "b");
            then = kt5.getMethod("c", kt5);
            then.setAccessible(true);
            fillWidth = find(Class.forName("kz8"), "g", new Class[]{kt5, float.class});
            offset = find(Class.forName("n34"), "J", new Class[]{kt5, float.class, float.class});
            sizeEl = Class.forName("jz8").getDeclaredConstructor(float.class, float.class, float.class, float.class, boolean.class);
            sizeEl.setAccessible(true);
            layLayers = field(Class.forName("d37"), "e");
            Class s11 = Class.forName("i21");
            lyKind = field(s11, "b");
            lyVisible = field(s11, "k");
            lyArtwork = field(s11, "A");
            lyTransform = field(s11, "d");
            awFade = field(Class.forName("a80"), "i");
            Class lm4 = Class.forName("jn4");
            trX = field(lm4, "a");
            trY = field(lm4, "b");
            trW = field(lm4, "c");
            trH = field(lm4, "d");
            ready = true;
        } catch (Throwable t) {
            Log.w(TAG, "init fallo: " + t);
            ready = false;
            return false;
        }
        try {
            blurFx = find(Class.forName("br7"), "A", new Class[]{Class.forName("ou5"), Class.forName("je3")});
            pmCtor = Class.forName("ls0").getDeclaredConstructor(float.class, float.class, int.class, boolean.class);
            pmCtor.setAccessible(true);
            softReady = true;
        } catch (Throwable t) {
            Log.w(TAG, "sin desenfoque de borde suave: " + t);
            softReady = false;
        }
        try {
            stSong = field(Class.forName("u21"), "a");
            modelCtor = Class.forName("v77").getDeclaredConstructor(
                    Class.forName("com.eclipse.android.data.models.Song"), int.class);
            modelCtor.setAccessible(true);
            reqCtor = Class.forName("xx3").getDeclaredConstructor(String.class, Class.forName("tu1"),
                    Class.forName("kh1"), float.class, long.class, int.class);
            reqCtor.setAccessible(true);
            image = find(Class.forName("a2b"), "b", new Class[]{Class.forName("he3"), mhClass(), Class.forName("xe3"),
                    Class.forName("zx3"), Class.forName("xx3"), Class.forName("je3"), Class.forName("ze3"),
                    Class.forName("cq1"), int.class, int.class, int.class});
            coverReady = true;
        } catch (Throwable t) {
            Log.w(TAG, "sin reflejo de portada: " + t);
            coverReady = false;
        }
        return ready;
    }

    /**
     * Busca la capa de portada INMERSIVA del layout: visible, tipo ARTWORK y con edgeFade.
     * @return {abajo, alto, ancho} como fracciones de la pantalla (abajo = y + alto/2), o null si no hay.
     */
    private static double[] immersiveArtwork(Object layout) {
        try {
            if (layout == null) return null;
            Object l = layLayers.get(layout);
            if (!(l instanceof List)) return null;
            for (Object ly : (List) l) {
                if (ly == null) continue;
                Object kind = lyKind.get(ly);
                if (!(kind instanceof Enum) || !"ARTWORK".equals(((Enum) kind).name())) continue;
                if (!lyVisible.getBoolean(ly)) continue;
                Object aw = lyArtwork.get(ly);
                if (aw == null) continue; // v0.20.1: ya NO exige edge fade (el reflejo no depende de el)
                Object tr = lyTransform.get(ly);
                if (tr == null) continue;
                double y = trY.getDouble(tr), w = trW.getDouble(tr), h = trH.getDouble(tr);
                return new double[]{y + h / 2.0, h, w};
            }
        } catch (Throwable t) {
            Log.w(TAG, "immersive fallo: " + t);
        }
        return null;
    }

    /** v1.49.0: dibuja la portada normal (la misma que j87.c) dentro de mod; se usa cuando no hay Canvas. */
    private static void drawCover(Object state, Object mod, Object composer) throws Exception {
        drawCover(state, mod, composer, false);
    }

    /** v0.20.145: hole = true -> pedido propio del hueco del Canvas (PrevCover lo trata como BG3, con guardia opcional). */
    private static void drawCover(Object state, Object mod, Object composer, boolean hole) throws Exception {
        Object song = stSong.get(state);
        if (song == null) return;
        if (song != cachedSong || cachedModel == null) {
            cachedModel = modelCtor.newInstance(song, 0);
            cachedSong = song;
        }
        // 0x7f = todos los valores por defecto de yw3 (alineacion centro, sin filtro, alpha 1). Con 0x7b la alineacion
        // quedaba en null y to7.a fallaba por dentro (v1.49.0: no se veia el reflejo).
        if (cachedReq == null) {
            cachedReq = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
            // v0.20.19: que "mantener la imagen anterior" tambien valga para nuestro reflejo (antes lo hacia el fondo original).
            try { app.eclipse.extension.artwork.PrevCover.tagBg3(cachedReq); } catch (Throwable ignored) {}
        }
        Object req = cachedReq;
        if (hole) {
            if (cachedHoleReq == null) {
                cachedHoleReq = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
                try { app.eclipse.extension.artwork.PrevCover.tagHole(cachedHoleReq); } catch (Throwable ignored) {}
            }
            req = cachedHoleReq;
        }
        try {
            image.invoke(null, cachedModel, mod, null, null, req, null, null, composer, 0x30000, 0, 0x7dc);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Log.w(TAG, "to7.a fallo: " + e.getCause());
            throw e;
        }
    }

    /** v0.20.20: portada chiquita (1/8) borrosa y estirada a toda la pantalla, detras del reflejo. */
    private static void drawFill(Object state, Object composer, float maxHDp, float radius) throws Exception {
        android.util.DisplayMetrics dm = android.content.res.Resources.getSystem().getDisplayMetrics();
        if (dm == null || dm.density <= 0f || dm.widthPixels <= 0) return;
        Object song = stSong.get(state);
        if (song == null) return;
        float w0 = dm.widthPixels / dm.density / FILL_K;
        float h0 = maxHDp / FILL_K;
        // v0.20.24: cuadrado del lado mayor (alto de pantalla): la portada es cuadrada y asi cubre toda la pantalla, tambien arriba.
        float side = Math.max(w0, h0);
        float w = side;
        float h = side;
        Object mod = then.invoke(companion, sizeEl.newInstance(w, h, w, h, false));
        mod = scaleDim(mod, FILL_K * 1.05f, FILL_K * 1.05f);
        mod = blur.invoke(null, mod, Math.max(2f, radius / FILL_K));
        if (song != cachedSong || cachedModel == null) {
            cachedModel = modelCtor.newInstance(song, 0);
            cachedSong = song;
        }
        if (cachedReq2 == null) {
            cachedReq2 = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
            // v0.20.23: el relleno YA NO se marca (sin imagen anterior ni fundido propio): solo el reflejo hace el fundido.
        }
        try {
            image.invoke(null, cachedModel, mod, null, null, cachedReq2, null, null, composer, 0x30000, 0, 0x7dc);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Log.w(TAG, "relleno to7.a fallo: " + e.getCause());
            throw e;
        }
    }

    private static Object nbSong;
    private static Object nbModel;
    private static Object nbReq;      // yw3 de la vecina (sin marcar: PrevCover no la toca)
    private static Object nbReq2;     // yw3 de la portada nitida vecina
    private static boolean nbFailed;

    private static void drawNbImage(Object song, Object mod, Object composer, boolean sharp) throws Exception {
        if (song != nbSong || nbModel == null) {
            nbModel = modelCtor.newInstance(song, 0);
            nbSong = song;
        }
        Object req;
        if (sharp) {
            if (nbReq2 == null) nbReq2 = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
            req = nbReq2;
        } else {
            if (nbReq == null) nbReq = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
            req = nbReq;
        }
        image.invoke(null, nbModel, mod, null, null, req, null, null, composer, 0x30000, 0, 0x7dc);
    }

    /**
     * v0.20.45: mientras arrastras, dibuja al lado la cancion vecina (Siguiente si arrastras a la izquierda, Anterior si
     * a la derecha): su reflejo borroso y su portada nitida, pegados al reflejo y la portada de la actual. Siempre abre y
     * cierra un grupo propio para que la estructura sea la misma haya o no vecina. Si falla una vez, no reintenta.
     */
    private static void drawNeighbor(Object state, Object composer, float dragDp, float rY, float rH, float rW,
                                     boolean soft, float radius, double[] art, float maxHDp) {
        if (nbFailed) return;
        boolean opened = false;
        try {
            startGroup.invoke(composer, GROUP_KEY + 1);
            opened = true;
            if (dragDp == 0f || art == null || !coverReady) return;
            android.util.DisplayMetrics dm = android.content.res.Resources.getSystem().getDisplayMetrics();
            if (dm == null || dm.density <= 0f || dm.widthPixels <= 0) return;
            float wScr = dm.widthPixels / dm.density;
            int dir = dragDp < 0f ? 1 : -1;
            Object song = app.eclipse.extension.artwork.PrevCover.neighbor(dir);
            if (song == null) return;
            float x = dragDp + dir * wScr;
            // reflejo borroso de la vecina (misma caja que el de la actual, corrida un ancho de pantalla)
            Object m = offset.invoke(null, companion, x, rY);
            if (rW > 0f) {
                m = then.invoke(m, sizeEl.newInstance(rW, rH, rW, rH, false));
            } else {
                m = fillWidth.invoke(null, m, 1.0f);
                m = then.invoke(m, sizeEl.newInstance(Float.NaN, rH, Float.NaN, rH, false));
            }
            m = scaleDim(m, 1.0f, -1.0f);
            if (soft) m = blurFx.invoke(null, m, pmCtor.newInstance(radius, radius, 3, false));
            else m = blur.invoke(null, m, radius);
            drawNbImage(song, m, composer, false);
            // portada nitida de la vecina (mismo lugar que la portada de la actual, corrida un ancho de pantalla)
            float hSharp = (float) (art[1] * maxHDp);
            float top = (float) ((art[0] - art[1]) * maxHDp);
            Object m2 = offset.invoke(null, companion, x, top);
            m2 = then.invoke(m2, sizeEl.newInstance(wScr, hSharp, wScr, hSharp, false));
            drawNbImage(song, m2, composer, true);
        } catch (Throwable t) {
            nbFailed = true;
            Log.w(TAG, "vecina fallo: " + t);
        } finally {
            if (opened) {
                try { endGroup.invoke(composer, false); } catch (Throwable ignored) {}
            }
        }
    }

    private static boolean holeFailed;

    /**
     * v1.57.0: portada en el hueco de d97.h (Eclipse no dibuja nada hasta el primer cuadro del Canvas).
     * La llama CoverUnderlay.drawHole desde un gancho smali dentro de esa rama. Si falla una vez, no reintenta.
     */
    public static void drawHoleCover(Object state, Object mod, Object composer) {
        if (holeFailed || state == null || mod == null || composer == null) return;
        try {
            init();
            if (!coverReady) { holeFailed = true; return; }
            drawCover(state, mod, composer, true);
        } catch (Throwable t) {
            holeFailed = true;
            Log.w(TAG, "portada en el hueco fallo: " + t);
        }
    }

    /**
     * v0.20.17: lo llama n77.g justo antes de j87.c (parche "Bitchord: quitar fondo borroso original").
     * Si el layout tiene fondo Blurred Cover y portada inmersiva (la misma condicion con la que dibujamos el
     * reflejo), devuelve null: j87.c entonces no dibuja el borroso original. En cualquier otro caso devuelve la cancion.
     */
    public static Object songForBlurFill(Object song, Object layout) {
        Object r = songForBlur(song, layout);
        if (r == null && song != null) fillNext = true; // v0.20.20: draw() rellena el hueco
        return r;
    }

    public static Object songForBlur(Object song, Object layout) {
        try {
            if (song == null || layout == null || !init()) return song;
            Object bg = field(Class.forName("d37"), "d").get(layout);
            if (bg == null) return song;
            Object type = bgType.get(bg);
            if (!(type instanceof Enum) || !"BLURRED_ARTWORK".equals(((Enum) type).name())) return song;
            double[] im = immersiveArtwork(layout);
            if (im != null && im[2] >= 0.99 && im[1] > 0.05 && im[0] > 0.05 && im[0] < 0.95) return null;
        } catch (Throwable t) {
            Log.w(TAG, "songForBlur fallo: " + t);
        }
        return song;
    }

    /**
     * @param bg       i11 (el fondo del layout Custom)
     * @param state    e21 (estado del reproductor; puede ser null)
     * @param composer lp1 (el composer actual)
     * @param layout   w17 (el layout Custom: lista de capas)
     * @param maxHDp   alto disponible en dp (tt0.b())
     */
    // v0.20.32: estado de pestana del reproductor Custom (qw0). Lo entrega el parche "Bitchord: Letras estilo Apple Music".
    private static volatile Object paneHolder;
    private static Method paneMethod;

    /** Gancho de n77.g: guarda el objeto qw0 (estado de pestana: "artwork", "lyrics" o "queue"). */
    public static void setPane(Object holder) {
        if (holder != null) paneHolder = holder;
        app.eclipse.extension.player.LayerMorph.setTab(holder); // v0.20.39
    }

    /** v0.20.33: igual que setPane, pero ademas activa el reflejo de la portada en Letra y Cola (opcion del parche). */
    private static volatile boolean paneReflect;

    public static void setPaneReflect(Object holder) {
        paneReflect = true;
        setPane(holder);
    }

    /** true si la pestana actual NO es "artwork". Se lee dentro de la composicion, asi que se redibuja al cambiar. */
    private static boolean inPane() {
        try {
            Object h = paneHolder;
            if (h == null) return false;
            if (paneMethod == null) paneMethod = h.getClass().getMethod("a");
            Object v = paneMethod.invoke(h);
            return v instanceof String && !"artwork".equals(v);
        } catch (Throwable t) {
            return false;
        }
    }

    /** v0.20.146: true si la pestana actual es Letra o Cola (no Artwork). */
    public static boolean notArtwork() { return inPane(); }

    public static void draw(Object bg, Object state, Object composer, Object layout, float maxHDp) {
        try { app.eclipse.extension.artwork.PrevCover.setState(state); } catch (Throwable ignored) {} // v0.20.4
        try { app.eclipse.extension.artwork.CoverUnderlay.seen(state); } catch (Throwable ignored) {} // v0.20.160: currentUrl (hueco del Canvas) = portada de la cancion ACTUAL aunque Eclipse aun no haya leido e21.w
        if (composer == null || !init()) return;
        boolean opened = false;
        boolean dim = false;     // v0.20.10: hay fondo Blurred Cover -> oscurecer al final
        boolean failed = false;
        boolean fill = fillNext && coverReady && !fillFailed; // v0.20.20
        fillNext = false;
        try {
            startGroup.invoke(composer, GROUP_KEY);
            opened = true;
            if (bg == null || state == null) return;
            Object type = bgType.get(bg);
            if (!(type instanceof Enum) || !"BLURRED_ARTWORK".equals(((Enum) type).name())) return;
            dim = true;
            Object u = stUrl.get(state);
            // v0.20.32: en Letra y Cola (pestana distinta de "artwork") no se usa el Canvas. v0.20.33: con la opcion del parche se dibuja el reflejo de la portada (como en canciones sin Canvas); sin la opcion, portada fija borrosa a pantalla completa.
            boolean paneMode = inPane();
            boolean hasCanvas = !paneMode && u instanceof String && !((String) u).isEmpty();
            if (!hasCanvas && !coverReady) return;
            boolean playing = stPlaying.getBoolean(state);
            float radius = (float) (40.0 * bgBlur.getDouble(bg) + 20.0) * BLUR_MULT;

            Object mod;
            boolean soft = false;
            boolean reflect = false;
            int lightWpx = 0, lightHpx = 0;           // v0.20.56: tamano en px de la caja chica
            float lightK = 1f;                       // v0.20.55: 1 = reflejo normal; LIGHT_K = reflejo liviano
            float dragDp = 0f;                       // v0.20.45: arrastre con el dedo (dp)
            float rY = 0f, rH = 0f, rW = 0f;         // v0.20.45: caja del reflejo (para la vecina)
            double[] artBox = null;                  // v0.20.45: portada inmersiva {abajo, alto, ancho}
            // v0.20.33: con la opcion "Reflejo en Letra y Cola" tambien ahi se usa el reflejo (de la portada, sin Canvas); sin la opcion, portada fija borrosa.
            double[] im = (paneMode && !paneReflect) ? null : immersiveArtwork(layout);
            if (im != null && im[2] >= 0.99 && im[1] > 0.05 && im[0] > 0.05 && im[0] < 0.95
                    && maxHDp > 100f && maxHDp < 5000f) {
                // Reflejo: caja del mismo tamano que la portada, pegada debajo de ella, volteada en vertical.
                // v1.32.0: el reflejo sube OVERLAP*alto por detras de la portada, para que el fundido de la
                // portada (transparente abajo) deje ver el video borroso y no la portada borrosa de j87.c.
                float yDp = (float) ((im[0] - OVERLAP * im[1]) * maxHDp);
                float hDp = (float) (im[1] * maxHDp);
                // v1.33.0: la caja llega hasta pasado el fondo de la pantalla, para que su borde inferior (con el
                // blur es semitransparente y deja ver el fondo oscuro) quede fuera de la vista.
                float hFull = maxHDp - yDp + EXTRA_BOTTOM_DP;
                if (hFull > hDp) hDp = hFull;
                try { // v0.20.45: el reflejo sigue al dedo (leer el estado aqui hace que se redibuje con cada movimiento)
                    float px = app.eclipse.extension.artwork.PrevCover.dragPx();
                    android.util.DisplayMetrics dm0 = android.content.res.Resources.getSystem().getDisplayMetrics();
                    if (px != 0f && dm0 != null && dm0.density > 0f && !hasCanvas && !paneMode) dragDp = px / dm0.density;
                } catch (Throwable ignored) {}
                mod = offset.invoke(null, companion, dragDp, yDp);
                float wDp = 0f;
                if (softReady) {
                    // v0.20.2: borde suave (sin raya). La caja se hace mas ancha que la pantalla para que los lados
                    // (que tambien se difuminan) queden fuera de la vista; requiredSize la centra.
                    try {
                        android.util.DisplayMetrics dm = android.content.res.Resources.getSystem().getDisplayMetrics();
                        if (dm != null && dm.density > 0f && dm.widthPixels > 0) {
                            wDp = dm.widthPixels / dm.density + 2f * radius * 2.5f;
                        }
                    } catch (Throwable ignored) {}
                }
                if (wDp > 0f && !paneMode && (hasCanvas ? lightCanvas : lightRefl)) {
                    // v0.20.55: la misma caja pero a 1/LIGHT_K: se borronea chiquita (radio/K) y la capa se estira K veces
                    // (el blur queda DENTRO de la escala, igual que drawFill). Mismo centro que la caja grande.
                    // v0.20.56: con Canvas (parche aparte "Reflejo liviano (Canvas)") la vista del video se crea chica y
                    // CoverFade.lightK avisa del factor para que el centrado y la deteccion del reflejo usen el tamano real.
                    float k = LIGHT_K;
                    android.util.DisplayMetrics dmL = android.content.res.Resources.getSystem().getDisplayMetrics();
                    float swDp = dmL.widthPixels / dmL.density;
                    float w = wDp / k, h = hDp / k;
                    // la caja grande (mas ancha que la pantalla) se centra sola; la chica, si cabe en la pantalla, hay que centrarla a mano
                    float ox = dragDp + (w < swDp ? (swDp - w) / 2f : 0f);
                    float oy = yDp + hDp / 2f - h / 2f;
                    mod = offset.invoke(null, companion, ox, oy);
                    mod = then.invoke(mod, sizeEl.newInstance(w, h, w, h, false));
                    lightK = k;
                    lightWpx = Math.round(w * dmL.density);
                    lightHpx = Math.round(h * dmL.density);
                    soft = true;
                } else if (wDp > 0f) {
                    mod = then.invoke(mod, sizeEl.newInstance(wDp, hDp, wDp, hDp, false));
                    soft = true;
                } else {
                    mod = fillWidth.invoke(null, mod, 1.0f);
                    mod = then.invoke(mod, sizeEl.newInstance(Float.NaN, hDp, Float.NaN, hDp, false));
                }
                mod = scaleDim(mod, lightK, -lightK);
                reflect = true;
                rY = yDp; rH = hDp; rW = wDp; artBox = im;
            } else if (!hasCanvas && !paneMode) {
                // Sin Canvas y sin layout inmersivo: todo queda como esta (lo dibuja j87.c).
                try { app.eclipse.extension.artwork.PrevCover.setExpectRefl(false); } catch (Throwable ignored) {} // v0.20.44
                return;
            } else {
                // Igual que la portada borrosa de j87.c: llena el espacio y 1.2x.
                Object lightMod = null;
                if (lightPane && paneMode) {
                    // v0.20.61: misma cobertura (pantalla entera, 1.2x) pero con una caja 1/K centrada a mano (igual que el reflejo liviano):
                    // el blur (radio/K) se hace sobre pocos pixeles y la capa se estira K veces.
                    try {
                        android.util.DisplayMetrics dmP = android.content.res.Resources.getSystem().getDisplayMetrics();
                        if (dmP != null && dmP.density > 0f && dmP.widthPixels > 0 && dmP.heightPixels > 0) {
                            float kp = LIGHT_PANE_K;
                            float swDp = dmP.widthPixels / dmP.density;
                            float shDp = dmP.heightPixels / dmP.density;
                            float w = swDp / kp, h = shDp / kp;
                            Object m2 = offset.invoke(null, companion, (swDp - w) / 2f, (shDp - h) / 2f);
                            m2 = then.invoke(m2, sizeEl.newInstance(w, h, w, h, false));
                            m2 = scaleDim(m2, kp * 1.2f, kp * 1.2f);
                            lightMod = m2;
                            lightK = kp;
                        }
                    } catch (Throwable t) {
                        lightMod = null;
                        lightK = 1f;
                        lightPane = false; // no reintentar si falla
                        Log.w(TAG, "fondo liviano de Letras fallo", t);
                    }
                }
                if (lightMod != null) {
                    mod = lightMod;
                } else {
                    mod = fillMax.invoke(null, companion, 1.0f);
                    mod = scaleDim(mod, 1.2f, 1.2f);
                }
            }
            // v0.20.44: el deslizamiento espera portada Y reflejo solo si hay reflejo de imagen (sin Canvas).
            try { app.eclipse.extension.artwork.PrevCover.setExpectRefl(reflect && !hasCanvas); } catch (Throwable ignored) {}
            if (soft) {
                // v0.20.2: desenfoque SIN recortar (tile Decal=3, clip=false): el borde de la caja se desvanece.
                float rb = radius / lightK;
                mod = blurFx.invoke(null, mod, pmCtor.newInstance(rb, rb, 3, false));
            } else {
                mod = blur.invoke(null, mod, radius / lightK); // v0.20.61: lightK = 1 salvo el fondo liviano de Letras
            }
            if (fill && reflect) {
                try {
                    drawFill(state, composer, maxHDp, radius);
                } catch (Throwable t) {
                    fillFailed = true; // no reintentar; esta composicion cae en el catch de abajo
                    throw t;
                }
            }
            if (hasCanvas) {
                app.eclipse.extension.artwork.CoverFade.reflectionNext = reflect;
                if (lightK > 1f) {
                    app.eclipse.extension.artwork.CoverFade.lightWpx = lightWpx;
                    app.eclipse.extension.artwork.CoverFade.lightHpx = lightHpx;
                    app.eclipse.extension.artwork.CoverFade.lightK = lightK;
                }
                try {
                    video.invoke(null, (String) u, playing, mod, composer, 0x180);
                } finally {
                    app.eclipse.extension.artwork.CoverFade.reflectionNext = false;
                }
            } else {
                drawCover(state, mod, composer);
                if (reflect && !paneMode) drawNeighbor(state, composer, dragDp, rY, rH, rW, soft, radius, artBox, maxHDp); // v0.20.45
            }
        } catch (Throwable t) {
            failed = true;
            Log.w(TAG, "draw fallo: " + t);
        } finally {
            if (opened) {
                if (dim && !failed) {
                    try {
                        app.eclipse.extension.artwork.CoverUnderlay.drawDim(fillMax.invoke(null, companion, 1.0f), composer, dimAlpha);
                    } catch (Throwable ignored) {}
                }
                try { endGroup.invoke(composer, false); } catch (Throwable ignored) {}
            }
        }
    }
}
