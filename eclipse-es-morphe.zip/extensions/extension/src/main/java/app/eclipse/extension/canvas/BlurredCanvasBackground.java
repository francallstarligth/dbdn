package app.eclipse.extension.canvas;

import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;

/**
 * Ayuda del parche "Custom: Canvas detras del fondo Blurred Cover".
 *
 * El fondo "Blurred Cover" del Custom lo dibuja di6.c(sv0, Z, Song, ki1, I) (rama BLURRED_ARTWORK): la portada
 * agrandada 1.2x con blur. Esa funcion no recibe la URL del Canvas (esta en ow0.w), asi que el video se dibuja
 * justo DESPUES de di6.c, en eg6.g, donde si se tiene ow0. Se llama por reflexion con los nombres de 0.6.47
 * (sin tocar registros de Eclipse). Si algo falla no dibuja nada y Eclipse sigue como siempre.
 *
 * Si el layout es INMERSIVO (hay una capa de portada visible con edgeFade, como la plantilla del usuario), el video
 * no se dibuja a pantalla completa: se dibuja como REFLEJO (volteado en vertical) justo debajo de la portada nitida,
 * del mismo tamano que ella, para que el borde inferior de la portada se continue en espejo. En los demas layouts
 * queda como antes (pantalla completa, sin voltear).
 *
 * Siempre abre y cierra un grupo de Compose propio (clave fija) para que la estructura sea la misma haya o no video.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class BlurredCanvasBackground {
    private static final String TAG = "BlurredCanvasBg";
    /** ASCII "CNVB". */
    private static final int GROUP_KEY = 0x434e5642;
    /** Fraccion del alto de la portada que el reflejo sube por detras de ella (ajustable). */
    private static final double OVERLAP = 0.5;
    /** dp extra que la caja del reflejo se pasa por debajo de la pantalla. */
    private static final float EXTRA_BOTTOM_DP = 100f;
    /** v1.34.0: multiplicador del radio del blur del video (1.0 = igual que la portada borrosa). */
    private static final float BLUR_MULT = 1.4f;
    /** v1.34.0: opacidad del video; menos de 1 deja ver el fondo oscuro de abajo y oscurece. */
    private static final float VIDEO_ALPHA = 0.55f;

    private static boolean tried;
    private static boolean ready;
    private static Object companion;   // jh5.q (Modifier.Companion)
    private static Method fillMax;     // g48.e(mh5, float)
    private static Method scale;       // yg2.H(mh5, float, float)
    private static Method layer;    // vd9.F(mh5, sx, sy, alpha, rotZ, ny7, zl0, mask)  (graphicsLayer); puede faltar
    private static Method blur;        // by9.k(mh5, float)
    private static Method video;       // xi6.h(String, boolean, mh5, ki1, int)
    private static Method startGroup;  // qi1.c0(int)
    private static Method endGroup;    // qi1.q(boolean)
    private static Field bgType;       // sv0.a (ni0)
    private static Field bgBlur;       // sv0.e (double)
    private static Field stUrl;        // ow0.w (String)
    private static Field stPlaying;    // ow0.b (boolean)
    private static Method then;        // mh5.c(mh5)  (Modifier.then)
    private static Method fillWidth;   // g48.g(mh5, float)
    private static Method offset;      // et3.N(mh5, float, float)  (Modifier.offset(x, y))
    private static Constructor sizeEl; // f48(float minW, float minH, float maxW, float maxH, boolean enforceIncoming)
    private static Field layLayers;    // ib6.e (List<dw0>)
    private static Field lyKind;       // dw0.b (ob4)
    private static Field lyVisible;    // dw0.k (boolean)
    private static Field lyArtwork;    // dw0.A (x40)
    private static Field lyTransform;  // dw0.d (zb4)
    private static Field awFade;       // x40.i (edgeFade)
    private static Field trX, trY, trW, trH; // zb4.a..d (double)
    // v1.49.0: reflejo de la portada normal (canciones sin Canvas)
    private static boolean coverReady;
    private static Field stSong;          // ow0.a (Song)
    private static Constructor modelCtor; // kh6(Song, int)  -> d43 que devuelve coverURL
    private static Constructor reqCtor;   // sn3(String, bn1, ja1, float, long, int)
    private static Method image;          // by9.c(d43, mh5, t43, un3, sn3, f43, v43, ki1, int, int, int)
    private static Object cachedSong;
    private static Object cachedModel;
    private static Object cachedReq;      // sn3 por defecto: es inmutable, se crea una sola vez

    private BlurredCanvasBackground() {}

    private static Method find(Class c, String name, Class[] params) throws Exception {
        for (Method m : c.getDeclaredMethods()) {
            if (!m.getName().equals(name)) continue;
            Class[] p = m.getParameterTypes();
            if (p.length != params.length) continue;
            boolean same = true;
            for (int i = 0; i < p.length; i++) if (p[i] != params[i]) { same = false; break; }
            if (!same) continue;
            m.setAccessible(true);
            return m;
        }
        throw new NoSuchMethodException(c.getName() + "." + name);
    }

    /** Escala (sx, sy) y opacidad VIDEO_ALPHA en una sola capa; si no hay graphicsLayer, solo escala. */
    private static Object scaleDim(Object mod, float sx, float sy) throws Exception {
        if (layer != null) {
            // mascara de valores por defecto: todo menos scaleX, scaleY y alpha (0x7fffc sin el bit 0x4 y sin 0x1/0x2)
            return layer.invoke(null, mod, sx, sy, VIDEO_ALPHA, 0f, null, null, 0x7fff8);
        }
        return scale.invoke(null, mod, sx, sy);
    }

    private static Class mhClass() throws Exception {
        return Class.forName("mh5");
    }

    private static Field field(Class c, String name) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        return f;
    }

    private static synchronized boolean init() {
        if (tried) return ready;
        tried = true;
        try {
            Class mh5 = Class.forName("mh5");
            Class ki1 = Class.forName("ki1");
            Class qi1 = Class.forName("qi1");
            Class jh5 = Class.forName("jh5");
            Field q = jh5.getDeclaredField("q");
            q.setAccessible(true);
            companion = q.get(null);
            fillMax = find(Class.forName("g48"), "e", new Class[]{mh5, float.class});
            scale = find(Class.forName("yg2"), "H", new Class[]{mh5, float.class, float.class});
            try {
                layer = find(Class.forName("vd9"), "F", new Class[]{mh5, float.class, float.class, float.class, float.class,
                        Class.forName("ny7"), Class.forName("zl0"), int.class});
            } catch (Throwable t) {
                layer = null;
                Log.w(TAG, "sin graphicsLayer (sin oscurecer): " + t);
            }
            blur = find(Class.forName("by9"), "k", new Class[]{mh5, float.class});
            video = find(Class.forName("xi6"), "h", new Class[]{String.class, boolean.class, mh5, ki1, int.class});
            startGroup = find(qi1, "c0", new Class[]{int.class});
            endGroup = find(qi1, "q", new Class[]{boolean.class});
            Class sv0 = Class.forName("sv0");
            bgType = field(sv0, "a");
            bgBlur = field(sv0, "e");
            Class ow0 = Class.forName("ow0");
            stUrl = field(ow0, "w");
            stPlaying = field(ow0, "b");
            then = mh5.getMethod("c", mh5);
            then.setAccessible(true);
            fillWidth = find(Class.forName("g48"), "g", new Class[]{mh5, float.class});
            offset = find(Class.forName("et3"), "N", new Class[]{mh5, float.class, float.class});
            sizeEl = Class.forName("f48").getDeclaredConstructor(float.class, float.class, float.class, float.class, boolean.class);
            sizeEl.setAccessible(true);
            layLayers = field(Class.forName("ib6"), "e");
            Class dw0 = Class.forName("dw0");
            lyKind = field(dw0, "b");
            lyVisible = field(dw0, "k");
            lyArtwork = field(dw0, "A");
            lyTransform = field(dw0, "d");
            awFade = field(Class.forName("x40"), "i");
            Class zb4 = Class.forName("zb4");
            trX = field(zb4, "a");
            trY = field(zb4, "b");
            trW = field(zb4, "c");
            trH = field(zb4, "d");
            ready = true;
        } catch (Throwable t) {
            Log.w(TAG, "init fallo: " + t);
            ready = false;
            return false;
        }
        try {
            stSong = field(Class.forName("ow0"), "a");
            modelCtor = Class.forName("kh6").getDeclaredConstructor(
                    Class.forName("com.eclipse.android.data.models.Song"), int.class);
            modelCtor.setAccessible(true);
            reqCtor = Class.forName("sn3").getDeclaredConstructor(String.class, Class.forName("bn1"),
                    Class.forName("ja1"), float.class, long.class, int.class);
            reqCtor.setAccessible(true);
            image = find(Class.forName("by9"), "c", new Class[]{Class.forName("d43"), mhClass(), Class.forName("t43"),
                    Class.forName("un3"), Class.forName("sn3"), Class.forName("f43"), Class.forName("v43"),
                    Class.forName("ki1"), int.class, int.class, int.class});
            coverReady = true;
        } catch (Throwable t) {
            Log.w(TAG, "sin reflejo de portada: " + t);
            coverReady = false;
        }
        return ready;
    }

    /**
     * Busca la capa de portada INMERSIVA del layout: visible, tipo ARTWORK y con edgeFade.
     * @return {abajo, alto, ancho} como fracciones de la pantalla (abajo = y + alto/2), o null si no hay.
     */
    private static double[] immersiveArtwork(Object layout) {
        try {
            if (layout == null) return null;
            Object l = layLayers.get(layout);
            if (!(l instanceof List)) return null;
            for (Object ly : (List) l) {
                if (ly == null) continue;
                Object kind = lyKind.get(ly);
                if (!(kind instanceof Enum) || !"ARTWORK".equals(((Enum) kind).name())) continue;
                if (!lyVisible.getBoolean(ly)) continue;
                Object aw = lyArtwork.get(ly);
                if (aw == null || awFade.get(aw) == null) continue;
                Object tr = lyTransform.get(ly);
                if (tr == null) continue;
                double y = trY.getDouble(tr), w = trW.getDouble(tr), h = trH.getDouble(tr);
                return new double[]{y + h / 2.0, h, w};
            }
        } catch (Throwable t) {
            Log.w(TAG, "immersive fallo: " + t);
        }
        return null;
    }

    /** v1.49.0: dibuja la portada normal (la misma que di6.c) dentro de mod; se usa cuando no hay Canvas. */
    private static void drawCover(Object state, Object mod, Object composer) throws Exception {
        Object song = stSong.get(state);
        if (song == null) return;
        if (song != cachedSong || cachedModel == null) {
            cachedModel = modelCtor.newInstance(song, 0);
            cachedSong = song;
        }
        // 0x7f = todos los valores por defecto de sn3 (alineacion centro, sin filtro, alpha 1). Con 0x7b la alineacion
        // quedaba en null y by9.c fallaba por dentro (v1.49.0: no se veia el reflejo).
        if (cachedReq == null) cachedReq = reqCtor.newInstance(null, null, null, 1f, 0L, 0x7f);
        Object req = cachedReq;
        try {
            image.invoke(null, cachedModel, mod, null, null, req, null, null, composer, 0x30000, 0, 0x7dc);
        } catch (java.lang.reflect.InvocationTargetException e) {
            Log.w(TAG, "by9.c fallo: " + e.getCause());
            throw e;
        }
    }

    /**
     * @param bg       sv0 (el fondo del layout Custom)
     * @param state    ow0 (estado del reproductor; puede ser null)
     * @param composer qi1 (el composer actual)
     * @param layout   ib6 (el layout Custom: lista de capas)
     * @param maxHDp   alto disponible en dp (ko0.b())
     */
    public static void draw(Object bg, Object state, Object composer, Object layout, float maxHDp) {
        if (composer == null || !init()) return;
        boolean opened = false;
        try {
            startGroup.invoke(composer, GROUP_KEY);
            opened = true;
            if (bg == null || state == null) return;
            Object type = bgType.get(bg);
            if (!(type instanceof Enum) || !"BLURRED_ARTWORK".equals(((Enum) type).name())) return;
            Object u = stUrl.get(state);
            boolean hasCanvas = u instanceof String && !((String) u).isEmpty();
            if (!hasCanvas && !coverReady) return;
            boolean playing = stPlaying.getBoolean(state);
            float radius = (float) (40.0 * bgBlur.getDouble(bg) + 20.0) * BLUR_MULT;

            Object mod;
            double[] im = immersiveArtwork(layout);
            if (im != null && im[2] >= 0.99 && im[1] > 0.05 && im[0] > 0.05 && im[0] < 0.95
                    && maxHDp > 100f && maxHDp < 5000f) {
                // Reflejo: caja del mismo tamano que la portada, pegada debajo de ella, volteada en vertical.
                // v1.32.0: el reflejo sube OVERLAP*alto por detras de la portada, para que el fundido de la
                // portada (transparente abajo) deje ver el video borroso y no la portada borrosa de di6.c.
                float yDp = (float) ((im[0] - OVERLAP * im[1]) * maxHDp);
                float hDp = (float) (im[1] * maxHDp);
                // v1.33.0: la caja llega hasta pasado el fondo de la pantalla, para que su borde inferior (con el
                // blur es semitransparente y deja ver el fondo oscuro) quede fuera de la vista.
                float hFull = maxHDp - yDp + EXTRA_BOTTOM_DP;
                if (hFull > hDp) hDp = hFull;
                mod = offset.invoke(null, companion, 0f, yDp);
                mod = fillWidth.invoke(null, mod, 1.0f);
                mod = then.invoke(mod, sizeEl.newInstance(Float.NaN, hDp, Float.NaN, hDp, false));
                mod = scaleDim(mod, 1.0f, -1.0f);
            } else if (!hasCanvas) {
                // Sin Canvas y sin layout inmersivo: todo queda como esta (lo dibuja di6.c).
                return;
            } else {
                // Igual que la portada borrosa de di6.c: llena el espacio y 1.2x.
                mod = fillMax.invoke(null, companion, 1.0f);
                mod = scaleDim(mod, 1.2f, 1.2f);
            }
            mod = blur.invoke(null, mod, radius);
            if (hasCanvas) {
                video.invoke(null, (String) u, playing, mod, composer, 0x180);
            } else {
                drawCover(state, mod, composer);
            }
        } catch (Throwable t) {
            Log.w(TAG, "draw fallo: " + t);
        } finally {
            if (opened) {
                try { endGroup.invoke(composer, false); } catch (Throwable ignored) {}
            }
        }
    }
}
