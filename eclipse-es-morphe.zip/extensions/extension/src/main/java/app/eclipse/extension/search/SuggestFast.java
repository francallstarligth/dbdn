package app.eclipse.extension.search;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * v0.20.443 (SIN COMPILAR NI PROBAR; Eclipse 0.6.75). Sugerencias RAPIDAS: se piden aparte al autocompletar publico de Deezer
 * (`api.deezer.com/search/autocomplete`), sin esperar los resultados de la busqueda de Eclipse.
 * - onText(): gancho en `Lju6;->invoke` justo antes de `Suggest.add`; con cada texto nuevo espera 120 ms sin teclear y pide.
 * - pick(): `Suggest.add` usa estas sugerencias si hay (del mismo texto o de uno que empieza igual); si no, las de los resultados.
 * - touch(): `Suggest.add` lee un estado de Compose propio (`Lxf8;->w`, mutableStateOf) para que, al llegar la respuesta,
 *   la lista se vuelva a dibujar sola (sin esto solo saldria cuando lleguen los resultados). Si falla, no pasa nada grave.
 * Lo que se escribe se envia a Deezer (https). Si no responde en 2,5 s se queda con las sugerencias de siempre.
 */
public final class SuggestFast {
    private static final String BASE = "https://api.deezer.com/search/autocomplete?limit=6&q=";
    private static final long WAIT_MS = 120L;

    private static volatile String wanted = "";
    private static volatile String listQ = "";
    private static volatile List<String> list = Collections.emptyList();

    private static final Map<String, List<String>> CACHE = new LinkedHashMap<String, List<String>>(64, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, List<String>> e) { return size() > 60; }
    };

    private static Object tick;
    private static Method tickGet;
    private static Method tickSet;
    private static boolean tickTried = false;
    private static int tickN = 0;

    private SuggestFast() {}

    private static String norm(String q) {
        return q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
    }

    /** Se llama (en la pantalla) cada vez que se arma la lista con el texto de la caja. */
    public static void onText(String q) {
        try {
            final String n = norm(q);
            if (n.isEmpty()) {
                wanted = "";
                return;
            }
            if (n.equals(wanted)) return;
            wanted = n;
            List<String> hit;
            synchronized (CACHE) { hit = CACHE.get(n); }
            if (hit != null) {
                listQ = n;
                list = hit;
                return;
            }
            Thread t = new Thread(new Runnable() {
                @Override public void run() { work(n); }
            }, "SuggestFast");
            t.setDaemon(true);
            t.start();
        } catch (Throwable ignored) {}
    }

    private static void work(String n) {
        try {
            Thread.sleep(WAIT_MS);
            if (!n.equals(wanted)) return; // ya escribio otra cosa
            List<String> r = fetch(n);
            if (r == null || r.isEmpty()) return;
            synchronized (CACHE) { CACHE.put(n, r); }
            if (!n.equals(wanted)) return;
            listQ = n;
            list = r;
            bump();
        } catch (Throwable ignored) {}
    }

    /** Lo que muestra `Suggest.add`: las rapidas si corresponden al texto; si no, las de respaldo. */
    public static List<String> pick(String q, List<String> fallback) {
        try {
            String n = norm(q);
            List<String> l = list;
            String lq = listQ;
            if (!l.isEmpty() && !lq.isEmpty() && (n.equals(lq) || n.startsWith(lq) || lq.startsWith(n))) return l;
        } catch (Throwable ignored) {}
        return fallback;
    }

    /** Leer el estado propio dentro de la pantalla para que se redibuje cuando llegue la respuesta. */
    public static void touch() {
        try {
            ensureTick();
            if (tick != null && tickGet != null) tickGet.invoke(tick);
        } catch (Throwable ignored) {}
    }

    private static synchronized void ensureTick() {
        if (tickTried) return;
        tickTried = true;
        try {
            ClassLoader cl = SuggestFast.class.getClassLoader();
            Class<?> f8 = Class.forName("xf8", true, cl);
            Method w = null;
            for (Method m : f8.getDeclaredMethods()) {
                if (m.getName().equals("w") && m.getParameterTypes().length == 1
                        && java.lang.reflect.Modifier.isStatic(m.getModifiers())
                        && m.getReturnType().getName().equals("xe7")) { w = m; break; }
            }
            if (w == null) return;
            w.setAccessible(true);
            Object st = w.invoke(null, Integer.valueOf(0));
            Class<?> c = st.getClass();
            Method g = c.getDeclaredMethod("getValue");
            Method s = c.getDeclaredMethod("setValue", Object.class);
            g.setAccessible(true);
            s.setAccessible(true);
            tickGet = g;
            tickSet = s;
            tick = st;
        } catch (Throwable ignored) {}
    }

    private static synchronized void bump() {
        try {
            ensureTick();
            if (tick != null && tickSet != null) tickSet.invoke(tick, Integer.valueOf(++tickN));
        } catch (Throwable ignored) {}
    }

    // ---------- red ----------
    private static List<String> fetch(String n) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(BASE + URLEncoder.encode(n, "UTF-8")).openConnection();
            c.setConnectTimeout(2500);
            c.setReadTimeout(2500);
            c.setRequestProperty("Accept", "application/json");
            if (c.getResponseCode() != 200) return null;
            InputStream in = c.getInputStream();
            String body;
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[4096];
                int k;
                while ((k = in.read(buf)) > 0) {
                    out.write(buf, 0, k);
                    if (out.size() > 600000) break;
                }
                body = out.toString("UTF-8");
            } finally {
                in.close();
            }
            JSONObject root = new JSONObject(body);
            List<String> artists = names(root.optJSONObject("artists"), "name");
            List<String> tracks = names(root.optJSONObject("tracks"), "title");
            List<String> out = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < artists.size() && i < 2; i++) put(out, seen, artists.get(i), n);
            for (int i = 0; i < tracks.size() && out.size() < 6; i++) put(out, seen, tracks.get(i), n);
            return out;
        } catch (Throwable t) {
            return null;
        } finally {
            if (c != null) {
                try { c.disconnect(); } catch (Throwable ignored) {}
            }
        }
    }

    private static List<String> names(JSONObject sec, String key) {
        List<String> r = new ArrayList<>();
        if (sec == null) return r;
        JSONArray a = sec.optJSONArray("data");
        if (a == null) return r;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String s = o.optString(key, "").trim();
            if (!s.isEmpty()) r.add(s);
        }
        return r;
    }

    private static void put(List<String> out, Set<String> seen, String s, String typed) {
        String k = s.toLowerCase(Locale.ROOT);
        if (k.equals(typed)) return;
        if (seen.add(k)) out.add(s);
    }
}
