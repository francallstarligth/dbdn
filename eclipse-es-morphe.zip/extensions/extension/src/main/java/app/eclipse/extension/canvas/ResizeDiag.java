package app.eclipse.extension.canvas;

import android.app.Activity;
import android.app.Application;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import java.util.ArrayList;

/**
 * v0.20.334: DIAGNOSTICO TEMPORAL (QUITAR al resolver). Anota que alto recibe el reflejo y que hace la app al salir/volver o
 * cambiar de tamano la ventana. 1,5 s despues del ultimo evento copia el registro al portapapeles (sin avisos en pantalla;
 * Android 13+ puede mostrar su propio aviso de "copiado"). Tambien sale en logcat con la etiqueta ResizeDiag.
 */
public final class ResizeDiag {
    private static final String TAG = "ResizeDiag";
    private static final int MAX_LINES = 250;
    private static final long GAP_MS = 60000L;
    private static final long COPY_AFTER_MS = 1500L;

    private static final ArrayList<String> LINES = new ArrayList<String>();
    private static long blockStart;
    private static long lastAt;
    private static String lastKey = "";
    private static boolean started;
    private static Application app;
    private static Handler handler;
    private static final Runnable COPY = new Runnable() {
        @Override public void run() { copiar(); }
    };

    private ResizeDiag() { }

    /** Anota una linea. Si es igual a la anterior (misma clave) no se repite. */
    public static synchronized void log(String key, String text) {
        try {
            long now = SystemClock.uptimeMillis();
            if (now - lastAt > GAP_MS || LINES.isEmpty()) {
                LINES.clear();
                blockStart = now;
                lastKey = "";
            }
            lastAt = now;
            if (key != null && key.equals(lastKey)) return;
            lastKey = key == null ? "" : key;
            String line = (now - blockStart) + "ms [" + Thread.currentThread().getName() + "] " + text;
            LINES.add(line);
            while (LINES.size() > MAX_LINES) LINES.remove(0);
            Log.w(TAG, line);
            programar();
        } catch (Throwable ignored) {
        }
    }

    private static void programar() {
        try {
            if (handler == null) handler = new Handler(Looper.getMainLooper());
            handler.removeCallbacks(COPY);
            handler.postDelayed(COPY, COPY_AFTER_MS);
        } catch (Throwable ignored) {
        }
    }

    private static synchronized void copiar() {
        try {
            if (app == null || LINES.isEmpty()) return;
            StringBuilder sb = new StringBuilder("ResizeDiag v0.20.341\n");
            for (String s : LINES) sb.append(s).append('\n');
            ClipboardManager cm = (ClipboardManager) app.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("ResizeDiag", sb.toString()));
        } catch (Throwable t) {
            Log.w(TAG, "copiar fallo", t);
        }
    }

    private static String ventana(Activity a) {
        try {
            Configuration c = a.getResources().getConfiguration();
            int w = -1, h = -1;
            try {
                android.view.View d = a.getWindow().getDecorView();
                w = d.getWidth();
                h = d.getHeight();
            } catch (Throwable ignored) {
            }
            return "decor=" + w + "x" + h + " cfg=" + c.screenWidthDp + "x" + c.screenHeightDp + "dp";
        } catch (Throwable t) {
            return "?";
        }
    }

    /** Lo llama BlurredCanvasBackground.draw en cada dibujo: registra los avisos del sistema la primera vez. */
    public static void start() {
        try {
            synchronized (ResizeDiag.class) {
                if (started) return;
                started = true;
            }
            Object o = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(o instanceof Application)) return;
            app = (Application) o;
            app.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                @Override public void onActivityCreated(Activity a, Bundle b) { log(null, "Created"); }
                @Override public void onActivityStarted(Activity a) { log(null, "Started " + ventana(a)); }
                @Override public void onActivityResumed(Activity a) { log(null, "Resumed " + ventana(a)); }
                @Override public void onActivityPaused(Activity a) { log(null, "Paused " + ventana(a)); }
                @Override public void onActivityStopped(Activity a) { log(null, "Stopped " + ventana(a)); }
                @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                @Override public void onActivityDestroyed(Activity a) { log(null, "Destroyed"); }
            });
            app.registerComponentCallbacks(new ComponentCallbacks2() {
                @Override public void onTrimMemory(int level) { log(null, "onTrimMemory nivel=" + level); }
                @Override public void onConfigurationChanged(Configuration c) {
                    log(null, "onConfigurationChanged " + c.screenWidthDp + "x" + c.screenHeightDp + "dp");
                }
                @Override public void onLowMemory() { log(null, "onLowMemory"); }
            });
            log(null, "inicio del registro");
        } catch (Throwable t) {
            Log.w(TAG, "start fallo", t);
        }
    }
}
