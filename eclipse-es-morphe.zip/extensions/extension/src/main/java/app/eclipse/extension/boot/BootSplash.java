package app.eclipse.extension.boot;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;

/**
 * v0.20.138 (SIN COMPILAR / SIN PROBAR). Pantalla de carga propia: fondo negro, disco de vinilo que gira
 * (gira la etiqueta "ECLIPSE MUSIC"; el brillo del vinilo queda fijo) y el eclipse naranja detras (no gira).
 * El parche (BootSplashPatch) llama show(this) al final de MainActivity.onCreate. La capa es una VENTANA APARTE
 * (Dialog negro, sin foco ni animaciones, pantalla completa).
 *
 * v0.20.136: ya NO se lee la pantalla (PixelCopy). La senal de "cargo" es la que da Eclipse mismo: el parche
 * (BootSplashPatch) engancha HomeViewModel (clase ih3 de 0.6.47), funcion a(): cuando llegan los datos del Inicio, o
 * cuando la carga falla, llama homeLoaded(). Entonces el disco se quita ~150 ms despues (para que la pantalla alcance a
 * dibujarse), sin bajar de MIN_SHOW_MS en total. Tope MAX_MS = 3 s por si la senal nunca llega.
 * Si la senal ya llego antes en este proceso (activity recreada), se quita igual tras el minimo.
 * Todo con try/catch: si algo falla, no se muestra nada y la app abre normal.
 */
public final class BootSplash {
    private static final String TAG = "BootSplash";
    private static final long MAX_MS = 3000L;
    private static final long MIN_SHOW_MS = 450L;
    private static final long HOME_DELAY_MS = 150L;
    private static final long ENTER_MS = 150L;
    private static final float ENTER_SCALE = 0.94f;

    private static volatile boolean homeLoadedOnce;   // la senal ya llego alguna vez en este proceso
    private static Runner current;                    // solo hilo principal

    private BootSplash() {}

    /** Lo llama Eclipse (gancho en HomeViewModel) al llegar los datos del Inicio o al fallar la carga. Cualquier hilo. */
    public static void homeLoaded() {
        try {
            homeLoadedOnce = true;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    final Runner r = current;
                    if (r != null) r.onHome();
                }
            });
        } catch (Throwable ignored) { }
    }

    public static void show(Activity a) {
        try {
            final Dialog d = new Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            d.setCancelable(false);
            final Window w = d.getWindow();
            if (w == null) return;
            w.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            w.setWindowAnimations(0);
            w.clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            w.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
            w.setStatusBarColor(Color.BLACK);
            w.setNavigationBarColor(Color.BLACK);
            w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (Build.VERSION.SDK_INT >= 28) {
                final WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            final Stage stage = new Stage(a);
            stage.setAlpha(0f);
            stage.setScaleX(ENTER_SCALE);
            stage.setScaleY(ENTER_SCALE);
            d.setContentView(stage, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            d.show();
            stage.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(ENTER_MS)
                    .setInterpolator(new DecelerateInterpolator(1.5f)).withLayer().start();
            final Runner r = new Runner(a, d, stage.label);
            current = r;
            r.start();
            if (homeLoadedOnce) r.onHome();
        } catch (Throwable t) {
            Log.w(TAG, "no se pudo mostrar la pantalla de carga", t);
        }
    }

    private static final class Runner implements Choreographer.FrameCallback {
        private final Activity act;
        private final Dialog dialog;
        private final LabelView label;
        private final long t0 = SystemClock.uptimeMillis();
        private final Handler main = new Handler(Looper.getMainLooper());
        private boolean done, homeSignalled;   // solo hilo principal
        private long lastRot = -1000L;

        Runner(Activity a, Dialog d, LabelView l) { act = a; dialog = d; label = l; }

        void start() {
            Choreographer.getInstance().postFrameCallback(this);
            main.postDelayed(new Runnable() { @Override public void run() { finish(); } }, MAX_MS);   // tope
        }

        /** Llego la senal del Inicio: se quita en HOME_DELAY_MS, pero sin bajar de MIN_SHOW_MS en total. */
        void onHome() {
            if (done || homeSignalled) return;
            homeSignalled = true;
            final long el = SystemClock.uptimeMillis() - t0;
            final long wait = Math.max(HOME_DELAY_MS, MIN_SHOW_MS - el);
            main.postDelayed(new Runnable() { @Override public void run() { finish(); } }, wait);
        }

        @Override public void doFrame(long frameTimeNanos) {
            try {
                if (done) return;
                final long el = SystemClock.uptimeMillis() - t0;
                if (el - lastRot >= 30L) {   // giro de la etiqueta, ~30 cuadros por segundo
                    lastRot = el;
                    label.setRotation((el * 360f / 1800f) % 360f);
                }
                if (act.isFinishing() || act.isDestroyed()) { finish(); return; }
                Choreographer.getInstance().postFrameCallback(this);
            } catch (Throwable t) {
                Log.w(TAG, "fallo en la animacion", t);
                finish();
            }
        }

        /** Quita la ventana de carga (hilo principal). Sin desvanecido. */
        private void finish() {
            if (done) return;
            done = true;
            if (current == this) current = null;
            try { if (dialog.isShowing()) dialog.dismiss(); } catch (Throwable ignored) { }
            try { label.release(); } catch (Throwable ignored) { }
        }
    }

    /**
     * Contiene la parte fija (StaticView) y la etiqueta que gira (LabelView). Solo acomoda: la etiqueta queda centrada en el
     * centro del disco y gira alrededor de su propio centro.
     */
    private static final class Stage extends ViewGroup {
        final StaticView base;
        final LabelView label;

        Stage(Context c) {
            super(c);
            setWillNotDraw(true);
            base = new StaticView(c);
            label = new LabelView(c);
            addView(base);
            addView(label);
        }

        @Override protected void onMeasure(int wm, int hm) {
            setMeasuredDimension(getDefaultSize(0, wm), getDefaultSize(0, hm));
        }

        @Override protected void onLayout(boolean changed, int l, int t, int rr, int b) {
            final int w = rr - l, h = b - t;
            if (w <= 0 || h <= 0) return;
            base.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
            base.layout(0, 0, w, h);
            final float r = Math.min(w, h) * 0.205f;
            final float dx = w / 2f + r * 0.15f, dy = h / 2f;
            final int half = (int) Math.ceil(r * 0.385f + 3f);
            label.build(r, half);
            final int size = half * 2;
            final int lx = Math.round(dx - half), ly = Math.round(dy - half);
            label.measure(MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
            label.layout(lx, ly, lx + size, ly + size);
            label.setTranslationX(dx - half - lx);   // resto de pixel, para que el centro quede donde estaba
            label.setTranslationY(dy - half - ly);
            label.setPivotX(half);
            label.setPivotY(half);
        }
    }

    /**
     * Parte fija del logo: media luna naranja a la izquierda con su brillo y el disco de vinilo (surcos, borde y brillos).
     * Se dibuja una sola vez. Proporciones MEDIDAS en el icono original del APK (res/_M.png, 512x512, disco R = 171 px):
     * centro del disco a +0.15 R del centro del grupo, centro del eclipse a -0.20 R con radio 0.96 R; surcos en bandas
     * oscuras (#1E1E1E / #2A2A2A, periodo ~0.07 R) y borde mas claro (#404040); brillos suaves a ~-52 y ~128 grados.
     * Tamano en pantalla segun el video de referencia (R = 0.205 del lado menor).
     */
    private static final class StaticView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int lw = -1, lh = -1;
        private Shader sheen, glow, moon, base;

        StaticView(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
        }

        @Override protected void onDraw(Canvas cv) {
            final int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            final float gx = w / 2f, gy = h / 2f;
            final float r = Math.min(w, h) * 0.205f;           // R del disco
            final float dx = gx + r * 0.15f, dy = gy;            // centro del disco
            final float ex = gx - r * 0.20f, ey = gy;            // centro del eclipse
            final float er = r * 1.07f;

            if (lw != w || lh != h) {
                lw = w; lh = h;
                glow = new RadialGradient(ex, ey, er * 1.3f,
                        new int[]{0x00E8603A, 0x00E8603A, 0x66E8603A, 0x00E8603A},
                        new float[]{0f, 0.72f, 0.77f, 1f}, Shader.TileMode.CLAMP);
                moon = new LinearGradient(0, ey - er, 0, ey + er, 0xFFE0572F, 0xFFEA5A4C, Shader.TileMode.CLAMP);
                base = new RadialGradient(dx, dy, r * 1.03f,
                        new int[]{0xFF1E1E1E, 0xFF1E1E1E, 0x001E1E1E},
                        new float[]{0f, 0.94f, 1f}, Shader.TileMode.CLAMP);
                sheen = new SweepGradient(dx, dy,
                        new int[]{0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.30f, 0.356f, 0.41f, 0.80f, 0.856f, 0.91f, 1f});
            }

            // 1) Eclipse: brillo suave y circulo naranja (el disco lo tapa y deja la media luna).
            fill.setShader(glow);
            cv.drawCircle(ex, ey, er * 1.3f, fill);
            fill.setShader(moon);
            cv.drawCircle(ex, ey, er, fill);

            // 2) Disco con borde suave
            fill.setShader(base);
            cv.drawCircle(dx, dy, r * 1.03f, fill);
            fill.setShader(null);

            // bandas de surcos (claras sobre el fondo oscuro)
            line.setColor(0xFF2A2A2A);
            line.setStrokeWidth(r * 0.035f);
            for (float f = 0.405f; f < 0.92f; f += 0.07f) cv.drawCircle(dx, dy, r * (f + 0.0175f), line);
            // borde mas claro
            line.setColor(0xFF404040);
            line.setStrokeWidth(r * 0.065f);
            cv.drawCircle(dx, dy, r * 0.965f, line);

            // brillos suaves FIJOS (no giran)
            fill.setShader(sheen);
            cv.drawCircle(dx, dy, r, fill);
            fill.setShader(null);
        }
    }

    /**
     * Etiqueta que gira: circulo gris #474747 con "ECLIPSE MUSIC" dos veces en anillo (radio ~0.21 R, cada texto ~135 grados,
     * puntos blancos entre ellos) y el punto central rojo con halo (el punto es redondo y esta en el centro del giro, asi que
     * girarlo no cambia nada). Se dibuja UNA vez en un bitmap al doble de tamano y la vista solo cambia su angulo
     * (setRotation); asi el giro no obliga a redibujar el texto curvo.
     */
    private static final class LabelView extends View {
        private static final int K = 2;   // el bitmap se dibuja al doble y se muestra a la mitad (bordes del texto mas limpios)
        private final Paint show = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Rect dst = new Rect();
        private Bitmap bmp;
        private float builtR = -1f;
        private int builtHalf = -1;

        LabelView(Context c) { super(c); }

        /** Dibuja la etiqueta en el bitmap (solo si cambia el tamano). */
        void build(float r, int half) {
            if (bmp != null && builtR == r && builtHalf == half) return;
            builtR = r;
            builtHalf = half;
            final int n = half * 2 * K;
            final Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            final Canvas cv = new Canvas(b);
            cv.scale(K, K);
            final float cx = half, cy = half;
            final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
            text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            text.setTextScaleX(0.62f);
            text.setColor(0xFFFFFFFF);

            final float lr = r * 0.385f;
            fill.setColor(0xFF474747);
            cv.drawCircle(cx, cy, lr, fill);

            final float tr = r * 0.21f;
            text.setTextSize(r * 0.068f);
            text.setLetterSpacing(0.08f);
            final String s = "ECLIPSE MUSIC";
            final float tw = text.measureText(s);
            final float arcLen = (float) (Math.PI * tr * 135f / 180f);
            final float off = Math.max(0f, (arcLen - tw) / 2f);
            final RectF box = new RectF(cx - tr, cy - tr, cx + tr, cy + tr);
            final Path arc = new Path();
            arc.addArc(box, 163f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);
            arc.reset();
            arc.addArc(box, 338f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);

            // puntos blancos entre los dos textos
            fill.setColor(0xFFFFFFFF);
            for (float deg : new float[]{317f, 136f}) {
                final double rad = Math.toRadians(deg);
                cv.drawCircle(cx + (float) Math.cos(rad) * tr, cy + (float) Math.sin(rad) * tr, r * 0.017f, fill);
            }

            // punto central rojo con halo
            fill.setShader(new RadialGradient(cx, cy, r * 0.14f,
                    new int[]{0x66E8503A, 0x00E8503A}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            cv.drawCircle(cx, cy, r * 0.14f, fill);
            fill.setShader(null);
            fill.setColor(0xFFE8503A);
            cv.drawCircle(cx, cy, r * 0.05f, fill);

            bmp = b;
        }

        /** Suelta el bitmap (sin recycle: el sistema aun podria estar usandolo en el ultimo cuadro). */
        void release() { bmp = null; }

        @Override protected void onDraw(Canvas cv) {
            final Bitmap b = bmp;
            if (b == null) return;
            dst.set(0, 0, getWidth(), getHeight());
            cv.drawBitmap(b, null, dst, show);
        }
    }
}
