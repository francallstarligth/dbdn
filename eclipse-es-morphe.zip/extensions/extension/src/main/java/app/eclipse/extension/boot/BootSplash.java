package app.eclipse.extension.boot;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/**
 * v0.20.134 (SIN COMPILAR / SIN PROBAR). Pantalla de carga propia: fondo negro, disco de vinilo que gira
 * (gira la etiqueta "ECLIPSE MUSIC"; el brillo del vinilo queda fijo) y el eclipse naranja detras (no gira).
 * El parche (BootSplashPatch) llama show(this) al final de MainActivity.onCreate, justo despues de setContent,
 * asi la capa queda ENCIMA de la pantalla real.
 *
 * v0.20.134, optimizacion (mismo dibujo, menos trabajo):
 *  - La parte fija (eclipse, brillo, disco, surcos, borde, brillos del vinilo) se dibuja UNA vez (StaticView) y ya no se
 *    invalida: el sistema reutiliza ese dibujo guardado.
 *  - La etiqueta (con el texto curvo y el punto rojo central) se dibuja UNA vez en un bitmap al doble de tamano (LabelView)
 *    y solo se le cambia el angulo; antes se redibujaba todo el disco, texto curvo incluido, ~30 veces por segundo.
 *  - Entrada: disco y brillo aparecen juntos en 150 ms (antes 220 ms y 380 ms). Salida: sin desvanecido, la capa se quita
 *    de golpe (antes 220 ms de fundido).
 *
 * Cuando se quita: cuando se detecta que el Inicio ya se ve (probe, PixelCopy a una franja de 6 px que la capa negra deja
 * sin tapar), o por el respaldo por tiempo/cuadros fluidos si PixelCopy falla 10 veces. Tope MAX_MS.
 * Todo con try/catch: si algo falla, no se muestra nada y la app abre normal.
 */
public final class BootSplash {
    private static final String TAG = "BootSplash";
    private static final long MIN_MS = 700L;
    /** v0.20.130: en el primer arranque del proceso (arranque en frio) la app tarda ~2,5 s en mostrar el Inicio. Se deja el
     *  disco hasta entonces para que no se vea el icono chico del sistema. HIPOTESIS medida en un video, sin probar. */
    private static final long COLD_MIN_MS = 3000L;
    private static boolean firstShow = true;
    private static final long MAX_MS = 4500L;
    private static final long ENTER_MS = 150L;
    private static final int SMOOTH_FRAMES = 8;
    private static final long SMOOTH_NS = 24_000_000L;   // un cuadro de menos de 24 ms cuenta como fluido
    private static final float ENTER_SCALE = 0.94f;

    private BootSplash() {}

    public static void show(Activity a) {
        try {
            final boolean cold = firstShow;
            firstShow = false;
            final FrameLayout root = new FrameLayout(a);
            root.setClickable(true);   // que los toques no pasen a la pantalla de abajo mientras carga
            final BlackView black = new BlackView(a);
            root.addView(black, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            final Stage stage = new Stage(a);
            stage.setAlpha(0f);
            stage.setScaleX(ENTER_SCALE);
            stage.setScaleY(ENTER_SCALE);
            root.addView(stage, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            a.addContentView(root, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            stage.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(ENTER_MS)
                    .setInterpolator(new DecelerateInterpolator(1.5f)).withLayer().start();
            new Runner(a, root, black, stage.label, cold ? COLD_MIN_MS : MIN_MS).start();
        } catch (Throwable t) {
            Log.w(TAG, "no se pudo mostrar la pantalla de carga", t);
        }
    }

    private static final class Runner implements Choreographer.FrameCallback {
        private final Activity act;
        private final FrameLayout root;
        private final BlackView black;
        private final LabelView label;
        private final long t0 = SystemClock.uptimeMillis();
        private final long minMs;
        private long lastNs;
        private int smooth;
        private boolean fading;
        private long lastRot = -1000L;
        // v0.20.131: deteccion de que el Inicio ya se ve (ver probe()).
        private final Handler main = new Handler(Looper.getMainLooper());
        private boolean homeSeen, probing;
        private int probeFails;
        private long lastProbe;
        private Bitmap probeBmp;
        private final Rect src = new Rect();

        Runner(Activity a, FrameLayout r, BlackView b, LabelView l, long min) {
            act = a; root = r; black = b; label = l; minMs = min;
        }

        void start() { Choreographer.getInstance().postFrameCallback(this); }

        @Override public void doFrame(long frameTimeNanos) {
            try {
                if (fading) return;
                final long el = SystemClock.uptimeMillis() - t0;
                // Giro de la etiqueta: solo se cambia el angulo, como mucho cada ~30 ms (unos 30 cuadros por segundo).
                if (el - lastRot >= 30L) {
                    lastRot = el;
                    label.setRotation((el * 360f / 1800f) % 360f);
                }
                if (lastNs != 0L) {
                    if (frameTimeNanos - lastNs < SMOOTH_NS) smooth++; else smooth = 0;
                }
                lastNs = frameTimeNanos;
                if (act.isFinishing() || act.isDestroyed()) { fading = true; remove(); return; }
                if (el >= MIN_MS && !homeSeen && !fallback()) probe(el);
                if (el >= MAX_MS || (el >= MIN_MS && homeSeen)
                        || (el >= minMs && fallback() && smooth >= SMOOTH_FRAMES && contentReady())) {
                    fading = true;
                    remove();   // v0.20.134: sin desvanecido, se quita de golpe
                    return;
                }
                Choreographer.getInstance().postFrameCallback(this);
            } catch (Throwable t) {
                Log.w(TAG, "fallo en la animacion", t);
                fading = true;
                remove();
            }
        }

        /** Si PixelCopy falla muchas veces, se usa la regla vieja por tiempo (3 s en arranque en frio). */
        private boolean fallback() { return probeFails >= 10; }

        /**
         * v0.20.131. Mira un borde de la pantalla REAL por un huequito que la capa negra deja sin tapar
         * (franja de 6 px a la izquierda, a media altura). Mientras Eclipse carga esa franja es negra pura; cuando sale el
         * Inicio tiene color (en el video del usuario: de (41,36,31) a (88,81,74) vs (0,0,0)). Entonces se quita el disco.
         */
        private void probe(long el) {
            if (probing || el - lastProbe < 100L) return;
            try {
                final View dv = black;
                final int[] loc = new int[2];
                dv.getLocationInWindow(loc);
                final int top = (int) (dv.getHeight() * 0.25f), bot = (int) (dv.getHeight() * 0.75f);
                if (dv.getWidth() < 20 || bot - top < 20) return;
                src.set(loc[0], loc[1] + top, loc[0] + 6, loc[1] + bot);
                black.setHole(0, top, 6, bot);
                if (probeBmp == null) probeBmp = Bitmap.createBitmap(6, bot - top, Bitmap.Config.ARGB_8888);
                probing = true;
                lastProbe = el;
                PixelCopy.request(act.getWindow(), src, probeBmp, new PixelCopy.OnPixelCopyFinishedListener() {
                    @Override public void onPixelCopyFinished(int result) {
                        probing = false;
                        if (result != PixelCopy.SUCCESS) { probeFails++; return; }
                        try {
                            final int w = probeBmp.getWidth(), h = probeBmp.getHeight();
                            final int[] px = new int[w * h];
                            probeBmp.getPixels(px, 0, w, 0, 0, w, h);
                            int lit = 0;
                            for (int i = 0; i < px.length; i++) {
                                final int c = px[i];
                                if (((c >> 16) & 255) + ((c >> 8) & 255) + (c & 255) > 30) lit++;
                            }
                            if (lit * 5 > px.length) homeSeen = true;   // mas del 20 % de la franja con color
                        } catch (Throwable t) { probeFails++; }
                    }
                }, main);
            } catch (Throwable t) {
                probing = false;
                probeFails++;
            }
        }

        /** La pantalla real (el primer hijo de contenido que no es nuestra capa) ya tiene tamano. */
        private boolean contentReady() {
            final ViewGroup content = (ViewGroup) act.findViewById(android.R.id.content);
            if (content == null) return true;
            for (int i = 0; i < content.getChildCount(); i++) {
                final View c = content.getChildAt(i);
                if (c != root && c.getWidth() > 0 && c.getHeight() > 0) return true;
            }
            return false;
        }

        private void remove() {
            try {
                final ViewGroup p = (ViewGroup) root.getParent();
                if (p != null) p.removeView(root);
            } catch (Throwable ignored) { }
            try { label.release(); } catch (Throwable ignored) { }
        }
    }

    /** Fondo negro de pantalla completa; deja sin tapar el huequito que usa probe(). Solo se redibuja si cambia el huequito. */
    private static final class BlackView extends View {
        private final Rect hole = new Rect();

        BlackView(Context c) { super(c); }

        /** Huequito (en coordenadas de esta vista) que se deja sin tapar para mirar la pantalla real. */
        void setHole(int l, int t, int r, int b) {
            if (hole.left == l && hole.top == t && hole.right == r && hole.bottom == b) return;
            hole.set(l, t, r, b);
            invalidate();
        }

        @Override protected void onDraw(Canvas cv) {
            cv.save();
            if (!hole.isEmpty()) cv.clipOutRect(hole);
            cv.drawColor(Color.BLACK);
            cv.restore();
        }
    }

    /**
     * Contiene la parte fija (StaticView) y la etiqueta que gira (LabelView). Solo acomoda: la etiqueta queda centrada en el
     * centro del disco y gira alrededor de su propio centro.
     */
    private static final class Stage extends ViewGroup {
        final StaticView base;
        final LabelView label;

        Stage(Context c) {
            super(c);
            setWillNotDraw(true);
            base = new StaticView(c);
            label = new LabelView(c);
            addView(base);
            addView(label);
        }

        @Override protected void onMeasure(int wm, int hm) {
            setMeasuredDimension(getDefaultSize(0, wm), getDefaultSize(0, hm));
        }

        @Override protected void onLayout(boolean changed, int l, int t, int rr, int b) {
            final int w = rr - l, h = b - t;
            if (w <= 0 || h <= 0) return;
            base.measure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
            base.layout(0, 0, w, h);
            final float r = Math.min(w, h) * 0.205f;
            final float dx = w / 2f + r * 0.15f, dy = h / 2f;
            final int half = (int) Math.ceil(r * 0.385f + 3f);
            label.build(r, half);
            final int size = half * 2;
            final int lx = Math.round(dx - half), ly = Math.round(dy - half);
            label.measure(MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(size, MeasureSpec.EXACTLY));
            label.layout(lx, ly, lx + size, ly + size);
            label.setTranslationX(dx - half - lx);   // resto de pixel, para que el centro quede donde estaba
            label.setTranslationY(dy - half - ly);
            label.setPivotX(half);
            label.setPivotY(half);
        }
    }

    /**
     * Parte fija del logo: media luna naranja a la izquierda con su brillo y el disco de vinilo (surcos, borde y brillos).
     * Se dibuja una sola vez. Proporciones MEDIDAS en el icono original del APK (res/_M.png, 512x512, disco R = 171 px):
     * centro del disco a +0.15 R del centro del grupo, centro del eclipse a -0.20 R con radio 0.96 R; surcos en bandas
     * oscuras (#1E1E1E / #2A2A2A, periodo ~0.07 R) y borde mas claro (#404040); brillos suaves a ~-52 y ~128 grados.
     * Tamano en pantalla segun el video de referencia (R = 0.205 del lado menor).
     */
    private static final class StaticView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int lw = -1, lh = -1;
        private Shader sheen, glow, moon, base;

        StaticView(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
        }

        @Override protected void onDraw(Canvas cv) {
            final int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            final float gx = w / 2f, gy = h / 2f;
            final float r = Math.min(w, h) * 0.205f;           // R del disco
            final float dx = gx + r * 0.15f, dy = gy;            // centro del disco
            final float ex = gx - r * 0.20f, ey = gy;            // centro del eclipse
            final float er = r * 1.07f;

            if (lw != w || lh != h) {
                lw = w; lh = h;
                glow = new RadialGradient(ex, ey, er * 1.3f,
                        new int[]{0x00E8603A, 0x00E8603A, 0x66E8603A, 0x00E8603A},
                        new float[]{0f, 0.72f, 0.77f, 1f}, Shader.TileMode.CLAMP);
                moon = new LinearGradient(0, ey - er, 0, ey + er, 0xFFE0572F, 0xFFEA5A4C, Shader.TileMode.CLAMP);
                base = new RadialGradient(dx, dy, r * 1.03f,
                        new int[]{0xFF1E1E1E, 0xFF1E1E1E, 0x001E1E1E},
                        new float[]{0f, 0.94f, 1f}, Shader.TileMode.CLAMP);
                sheen = new SweepGradient(dx, dy,
                        new int[]{0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.30f, 0.356f, 0.41f, 0.80f, 0.856f, 0.91f, 1f});
            }

            // 1) Eclipse: brillo suave y circulo naranja (el disco lo tapa y deja la media luna).
            fill.setShader(glow);
            cv.drawCircle(ex, ey, er * 1.3f, fill);
            fill.setShader(moon);
            cv.drawCircle(ex, ey, er, fill);

            // 2) Disco con borde suave
            fill.setShader(base);
            cv.drawCircle(dx, dy, r * 1.03f, fill);
            fill.setShader(null);

            // bandas de surcos (claras sobre el fondo oscuro)
            line.setColor(0xFF2A2A2A);
            line.setStrokeWidth(r * 0.035f);
            for (float f = 0.405f; f < 0.92f; f += 0.07f) cv.drawCircle(dx, dy, r * (f + 0.0175f), line);
            // borde mas claro
            line.setColor(0xFF404040);
            line.setStrokeWidth(r * 0.065f);
            cv.drawCircle(dx, dy, r * 0.965f, line);

            // brillos suaves FIJOS (no giran)
            fill.setShader(sheen);
            cv.drawCircle(dx, dy, r, fill);
            fill.setShader(null);
        }
    }

    /**
     * Etiqueta que gira: circulo gris #474747 con "ECLIPSE MUSIC" dos veces en anillo (radio ~0.21 R, cada texto ~135 grados,
     * puntos blancos entre ellos) y el punto central rojo con halo (el punto es redondo y esta en el centro del giro, asi que
     * girarlo no cambia nada). Se dibuja UNA vez en un bitmap al doble de tamano y la vista solo cambia su angulo
     * (setRotation); asi el giro no obliga a redibujar el texto curvo.
     */
    private static final class LabelView extends View {
        private static final int K = 2;   // el bitmap se dibuja al doble y se muestra a la mitad (bordes del texto mas limpios)
        private final Paint show = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Rect dst = new Rect();
        private Bitmap bmp;
        private float builtR = -1f;
        private int builtHalf = -1;

        LabelView(Context c) { super(c); }

        /** Dibuja la etiqueta en el bitmap (solo si cambia el tamano). */
        void build(float r, int half) {
            if (bmp != null && builtR == r && builtHalf == half) return;
            builtR = r;
            builtHalf = half;
            final int n = half * 2 * K;
            final Bitmap b = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
            final Canvas cv = new Canvas(b);
            cv.scale(K, K);
            final float cx = half, cy = half;
            final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
            final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
            text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            text.setTextScaleX(0.62f);
            text.setColor(0xFFFFFFFF);

            final float lr = r * 0.385f;
            fill.setColor(0xFF474747);
            cv.drawCircle(cx, cy, lr, fill);

            final float tr = r * 0.21f;
            text.setTextSize(r * 0.068f);
            text.setLetterSpacing(0.08f);
            final String s = "ECLIPSE MUSIC";
            final float tw = text.measureText(s);
            final float arcLen = (float) (Math.PI * tr * 135f / 180f);
            final float off = Math.max(0f, (arcLen - tw) / 2f);
            final RectF box = new RectF(cx - tr, cy - tr, cx + tr, cy + tr);
            final Path arc = new Path();
            arc.addArc(box, 163f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);
            arc.reset();
            arc.addArc(box, 338f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);

            // puntos blancos entre los dos textos
            fill.setColor(0xFFFFFFFF);
            for (float deg : new float[]{317f, 136f}) {
                final double rad = Math.toRadians(deg);
                cv.drawCircle(cx + (float) Math.cos(rad) * tr, cy + (float) Math.sin(rad) * tr, r * 0.017f, fill);
            }

            // punto central rojo con halo
            fill.setShader(new RadialGradient(cx, cy, r * 0.14f,
                    new int[]{0x66E8503A, 0x00E8503A}, new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            cv.drawCircle(cx, cy, r * 0.14f, fill);
            fill.setShader(null);
            fill.setColor(0xFFE8503A);
            cv.drawCircle(cx, cy, r * 0.05f, fill);

            bmp = b;
        }

        /** Suelta el bitmap (sin recycle: el sistema aun podria estar usandolo en el ultimo cuadro). */
        void release() { bmp = null; }

        @Override protected void onDraw(Canvas cv) {
            final Bitmap b = bmp;
            if (b == null) return;
            dst.set(0, 0, getWidth(), getHeight());
            cv.drawBitmap(b, null, dst, show);
        }
    }
}
