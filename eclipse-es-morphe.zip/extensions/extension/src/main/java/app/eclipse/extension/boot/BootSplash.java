package app.eclipse.extension.boot;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.Log;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * v0.20.129 (SIN COMPILAR / SIN PROBAR). Pantalla de carga propia: fondo negro, disco de vinilo que gira
 * (gira la etiqueta "ECLIPSE MUSIC"; el brillo del vinilo queda fijo) y el eclipse naranja detras (no gira,
 * solo crece su brillo). El parche (BootSplashPatch) llama show(this) al final de MainActivity.onCreate, justo
 * despues de setContent, asi la capa queda ENCIMA de la pantalla real.
 *
 * Cuando se quita: pasados MIN_MS y cuando la app ya va fluida (SMOOTH_FRAMES cuadros seguidos rapidos, o sea
 * que termino de armar la pantalla de inicio). Tope MAX_MS por si nunca se calma. Se quita con un fundido corto.
 * HIPOTESIS (sin medir en el telefono): "cuadros rapidos seguidos" = "ya cargo".
 * Todo con try/catch: si algo falla, no se muestra nada y la app abre normal.
 */
public final class BootSplash {
    private static final String TAG = "BootSplash";
    private static final long MIN_MS = 700L;
    private static final long MAX_MS = 4500L;
    private static final long FADE_MS = 220L;
    private static final int SMOOTH_FRAMES = 8;
    private static final long SMOOTH_NS = 24_000_000L;   // un cuadro de menos de 24 ms cuenta como fluido

    private BootSplash() {}

    public static void show(Activity a) {
        try {
            final FrameLayout root = new FrameLayout(a);
            root.setBackgroundColor(Color.BLACK);
            root.setClickable(true);   // que los toques no pasen a la pantalla de abajo mientras carga
            final DiscView disc = new DiscView(a);
            root.addView(disc, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            a.addContentView(root, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            new Runner(a, root, disc).start();
        } catch (Throwable t) {
            Log.w(TAG, "no se pudo mostrar la pantalla de carga", t);
        }
    }

    private static final class Runner implements Choreographer.FrameCallback {
        private final Activity act;
        private final FrameLayout root;
        private final DiscView disc;
        private final long t0 = SystemClock.uptimeMillis();
        private long lastNs;
        private int smooth;
        private boolean fading;

        Runner(Activity a, FrameLayout r, DiscView d) { act = a; root = r; disc = d; }

        void start() { Choreographer.getInstance().postFrameCallback(this); }

        @Override public void doFrame(long frameTimeNanos) {
            try {
                if (fading) return;
                final long el = SystemClock.uptimeMillis() - t0;
                disc.setElapsed(el);
                if (lastNs != 0L) {
                    if (frameTimeNanos - lastNs < SMOOTH_NS) smooth++; else smooth = 0;
                }
                lastNs = frameTimeNanos;
                if (act.isFinishing() || act.isDestroyed()) { fading = true; remove(); return; }
                if (el >= MAX_MS || (el >= MIN_MS && smooth >= SMOOTH_FRAMES && contentReady())) {
                    fading = true;
                    root.animate().alpha(0f).setDuration(FADE_MS).withEndAction(new Runnable() {
                        @Override public void run() { remove(); }
                    }).start();
                    return;
                }
                Choreographer.getInstance().postFrameCallback(this);
            } catch (Throwable t) {
                Log.w(TAG, "fallo en la animacion", t);
                fading = true;
                remove();
            }
        }

        /** La pantalla real (el primer hijo de contenido que no es nuestra capa) ya tiene tamano. */
        private boolean contentReady() {
            final ViewGroup content = (ViewGroup) act.findViewById(android.R.id.content);
            if (content == null) return true;
            for (int i = 0; i < content.getChildCount(); i++) {
                final View c = content.getChildAt(i);
                if (c != root && c.getWidth() > 0 && c.getHeight() > 0) return true;
            }
            return false;
        }

        private void remove() {
            try {
                final ViewGroup p = (ViewGroup) root.getParent();
                if (p != null) p.removeView(root);
            } catch (Throwable ignored) { }
        }
    }

    /**
     * Dibuja el logo de Eclipse animado: media luna naranja a la izquierda y el disco de vinilo encima. Todo en codigo.
     * Proporciones MEDIDAS en el icono original del APK (res/_M.png, 512x512, disco R = 171 px): centro del disco a
     * +0.15 R del centro del grupo, centro del eclipse a -0.20 R con radio 0.96 R; etiqueta de radio 0.385 R en gris
     * #474747 con "ECLIPSE MUSIC" dos veces en anillo (radio ~0.21 R, cada texto ~135 grados, puntos blancos entre
     * ellos) y punto central rojo con halo; surcos en bandas oscuras (#1E1E1E / #2A2A2A, periodo ~0.07 R) y borde mas
     * claro (#404040); brillos suaves a ~-52 y ~128 grados. Tamano en pantalla segun el video de referencia
     * (R = 0.205 del lado menor). Fondo negro (el icono tiene fondo azul oscuro; el usuario pidio negro).
     */
    private static final class DiscView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path arc = new Path();
        private final RectF box = new RectF();
        private long elapsed;

        private int lw = -1, lh = -1;
        private Shader sheen, glow, moon, base, dotGlow;

        DiscView(Context c) {
            super(c);
            line.setStyle(Paint.Style.STROKE);
            text.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
            text.setTextScaleX(0.62f);
            text.setColor(0xFFFFFFFF);
        }

        void setElapsed(long ms) { elapsed = ms; invalidate(); }

        private static float ease(float x) {
            if (x <= 0f) return 0f;
            if (x >= 1f) return 1f;
            final float u = 1f - x;
            return 1f - u * u * u;
        }

        @Override protected void onDraw(Canvas cv) {
            final int w = getWidth(), h = getHeight();
            if (w <= 0 || h <= 0) return;
            final float gx = w / 2f, gy = h / 2f;
            final float r = Math.min(w, h) * 0.205f;           // R del disco
            final float dx = gx + r * 0.15f, dy = gy;            // centro del disco
            final float ex = gx - r * 0.20f, ey = gy;            // centro del eclipse
            final float er = r * 1.07f;
            final float appear = ease(elapsed / 220f);
            final float glowK = ease(elapsed / 380f);
            final float sc = 0.94f + 0.06f * appear;

            if (lw != w || lh != h) {
                lw = w; lh = h;
                glow = new RadialGradient(ex, ey, er * 1.3f,
                        new int[]{0x00E8603A, 0x00E8603A, 0x66E8603A, 0x00E8603A},
                        new float[]{0f, 0.72f, 0.77f, 1f}, Shader.TileMode.CLAMP);
                moon = new LinearGradient(0, ey - er, 0, ey + er, 0xFFE0572F, 0xFFEA5A4C, Shader.TileMode.CLAMP);
                base = new RadialGradient(dx, dy, r * 1.03f,
                        new int[]{0xFF1E1E1E, 0xFF1E1E1E, 0x001E1E1E},
                        new float[]{0f, 0.94f, 1f}, Shader.TileMode.CLAMP);
                sheen = new SweepGradient(dx, dy,
                        new int[]{0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.30f, 0.356f, 0.41f, 0.80f, 0.856f, 0.91f, 1f});
                dotGlow = new RadialGradient(dx, dy, r * 0.14f,
                        new int[]{0x66E8503A, 0x00E8503A}, new float[]{0f, 1f}, Shader.TileMode.CLAMP);
            }

            final int a = (int) (255 * appear);
            cv.save();
            cv.scale(sc, sc, gx, gy);

            // 1) Eclipse: brillo suave y circulo naranja (el disco lo tapa y deja la media luna).
            if (glowK > 0f) {
                final int ga = (int) (255 * glowK);
                fill.setShader(glow);
                fill.setAlpha(ga);
                cv.drawCircle(ex, ey, er * 1.3f, fill);
                fill.setShader(moon);
                fill.setAlpha(ga);
                cv.drawCircle(ex, ey, er, fill);
                fill.setShader(null);
            }

            // 2) Disco con borde suave
            fill.setShader(base);
            fill.setAlpha(a);
            cv.drawCircle(dx, dy, r * 1.03f, fill);
            fill.setShader(null);

            // bandas de surcos (claras sobre el fondo oscuro)
            line.setColor(0xFF2A2A2A);
            line.setAlpha(a);
            line.setStrokeWidth(r * 0.035f);
            for (float f = 0.405f; f < 0.92f; f += 0.07f) cv.drawCircle(dx, dy, r * (f + 0.0175f), line);
            // borde mas claro
            line.setColor(0xFF404040);
            line.setAlpha(a);
            line.setStrokeWidth(r * 0.065f);
            cv.drawCircle(dx, dy, r * 0.965f, line);

            // brillos suaves FIJOS (no giran)
            fill.setShader(sheen);
            fill.setAlpha(a);
            cv.drawCircle(dx, dy, r, fill);
            fill.setShader(null);

            // 3) Etiqueta: ESTA gira.
            final float lr = r * 0.385f;
            final float ang = (elapsed * 360f / 1800f) % 360f;
            cv.save();
            cv.rotate(ang, dx, dy);
            fill.setColor(0xFF474747);
            fill.setAlpha(a);
            cv.drawCircle(dx, dy, lr, fill);

            final float tr = r * 0.21f;
            text.setTextSize(r * 0.068f);
            text.setLetterSpacing(0.08f);
            text.setAlpha(a);
            final String s = "ECLIPSE MUSIC";
            final float tw = text.measureText(s);
            final float arcLen = (float) (Math.PI * tr * 135f / 180f);
            final float off = Math.max(0f, (arcLen - tw) / 2f);
            box.set(dx - tr, dy - tr, dx + tr, dy + tr);
            arc.reset();
            arc.addArc(box, 163f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);
            arc.reset();
            arc.addArc(box, 338f, 135f);
            cv.drawTextOnPath(s, arc, off, 0f, text);

            // puntos blancos entre los dos textos
            fill.setColor(0xFFFFFFFF);
            fill.setAlpha(a);
            for (float deg : new float[]{317f, 136f}) {
                final double rad = Math.toRadians(deg);
                cv.drawCircle(dx + (float) Math.cos(rad) * tr, dy + (float) Math.sin(rad) * tr, r * 0.017f, fill);
            }
            cv.restore();

            // punto central rojo con halo
            fill.setShader(dotGlow);
            fill.setAlpha(a);
            cv.drawCircle(dx, dy, r * 0.14f, fill);
            fill.setShader(null);
            fill.setColor(0xFFE8503A);
            fill.setAlpha(a);
            cv.drawCircle(dx, dy, r * 0.05f, fill);
            cv.restore();
            fill.setAlpha(255);
        }
    }
}
