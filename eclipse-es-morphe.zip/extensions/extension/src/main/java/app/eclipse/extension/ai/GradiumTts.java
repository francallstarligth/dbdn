package app.eclipse.extension.ai;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v0.20.239 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). Voz del DJ con la API de Gradium.
 *
 * 1. Pide la llave a nuestro Cloudflare Worker (GET /gradium -> {"provider":"gradium","key":"..."}); la guarda en memoria.
 * 2. POST https://api.gradium.ai/api/post/speech/tts con cabecera x-api-key y {text, voice_id, output_format:"wav", only_audio:true}.
 * 3. Devuelve el WAV, o null si algo falla (sin red, sin cupo, voz invalida...). Nunca lanza. Quien llama cae a Edge.
 * El plan gratis tiene ~45 mil caracteres/mes: se recorta el texto y, si Gradium dice que no hay cupo, se deja de intentar un rato.
 */
public final class GradiumTts {
    private static final String TAG = "GradiumTts";
    private static final String WORKER = "https://dj-puente.franc-all-starligth.workers.dev/gradium";
    private static final String API = "https://api.gradium.ai/api/post/speech/tts";
    private static final int MAX_CHARS = 800;
    private static final long KEY_TTL_MS = 12L * 60L * 60L * 1000L;
    private static final long PAUSE_QUOTA_MS = 30L * 60L * 1000L;
    private static final long PAUSE_ERR_MS = 60L * 1000L;
    private static final Pattern KEY_RE = Pattern.compile("\"key\"\\s*:\\s*\"([^\"]+)\"");

    // Solo para pruebas locales
    static String testWorker;
    static String testApi;

    private static volatile String key;
    private static volatile long keyTs;
    private static volatile long pausedUntil;

    private GradiumTts() {}

    /** @return WAV o null. Nunca lanza. */
    public static byte[] speak(String text, String voiceId) {
        try {
            if (text == null || voiceId == null) return null;
            voiceId = voiceId.trim();
            if (voiceId.isEmpty()) return null;
            if (System.currentTimeMillis() < pausedUntil) return null;
            text = EdgeTts.clean(text);
            if (text.isEmpty()) return null;
            if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS);

            for (int pass = 0; pass < 2; pass++) {
                String k = getKey(pass > 0);
                if (k == null) {
                    pause(PAUSE_ERR_MS);
                    return null;
                }
                int[] code = new int[1];
                byte[] a = post(k, text, voiceId, code);
                if (a != null) return a;
                if (code[0] == 401 || code[0] == 403) { // llave rotada o mala: pedir otra y reintentar una vez
                    key = null;
                    continue;
                }
                if (code[0] == 402 || code[0] == 429) pause(PAUSE_QUOTA_MS); // sin cupo
                else pause(PAUSE_ERR_MS);
                return null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
        }
        return null;
    }

    private static void pause(long ms) {
        pausedUntil = System.currentTimeMillis() + ms;
    }

    private static synchronized String getKey(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && key != null && now - keyTs < KEY_TTL_MS) return key;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(testWorker != null ? testWorker : WORKER).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "Worker respondio " + code);
                return null;
            }
            String body = new String(readAll(c.getInputStream()), StandardCharsets.UTF_8);
            Matcher m = KEY_RE.matcher(body);
            if (!m.find()) {
                Log.w(TAG, "Worker sin llave en la respuesta");
                return null;
            }
            key = m.group(1);
            keyTs = now;
            return key;
        } catch (Throwable t) {
            Log.w(TAG, "pedir llave fallo: " + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] post(String k, String text, String voiceId, int[] codeOut) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(testApi != null ? testApi : API).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(25000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("x-api-key", k);
            c.setRequestProperty("Content-Type", "application/json");
            String json = "{\"text\":" + q(text) + ",\"voice_id\":" + q(voiceId)
                + ",\"output_format\":\"wav\",\"only_audio\":true}";
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(body.length);
            OutputStream out = c.getOutputStream();
            out.write(body);
            out.flush();
            int code = c.getResponseCode();
            codeOut[0] = code;
            if (code != 200) {
                String err = "";
                try {
                    InputStream es = c.getErrorStream();
                    if (es != null) err = new String(readAll(es), StandardCharsets.UTF_8);
                } catch (Throwable ignore) {}
                Log.w(TAG, "Gradium " + code + ": " + (err.length() > 200 ? err.substring(0, 200) : err));
                return null;
            }
            byte[] a = readAll(c.getInputStream());
            // un WAV empieza con "RIFF"; si no, no es audio (p. ej. un JSON de error)
            if (a.length < 64 || a[0] != 'R' || a[1] != 'I' || a[2] != 'F' || a[3] != 'F') {
                String head = new String(a, 0, Math.min(a.length, 120), StandardCharsets.UTF_8);
                Log.w(TAG, "Respuesta que no es WAV (" + a.length + " bytes): " + head);
                codeOut[0] = 0;
                return null;
            }
            return a;
        } catch (Throwable t) {
            Log.w(TAG, "post fallo: " + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (ch < 32) b.append(String.format("\\u%04x", (int) ch));
                    else b.append(ch);
            }
        }
        return b.append('"').toString();
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }
}
