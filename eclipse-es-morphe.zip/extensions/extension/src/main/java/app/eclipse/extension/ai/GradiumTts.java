package app.eclipse.extension.ai;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * v0.20.240: normalizeWav() reconstruye el encabezado del WAV. v0.20.239 (SIN COMPILAR NI PROBAR en telefono; solo javac + servidor falso). Voz del DJ con la API de Gradium.
 *
 * 1. Pide la llave a nuestro Cloudflare Worker (GET /gradium -> {"provider":"gradium","key":"..."}); la guarda en memoria.
 * 2. POST https://api.gradium.ai/api/post/speech/tts con cabecera x-api-key y {text, voice_id, output_format:"wav", only_audio:true}.
 * 3. Devuelve el WAV, o null si algo falla (sin red, sin cupo, voz invalida...). Nunca lanza. Quien llama cae a Edge.
 * El plan gratis tiene ~45 mil caracteres/mes: se recorta el texto y, si Gradium dice que no hay cupo, se deja de intentar un rato.
 */
public final class GradiumTts {
    private static final String TAG = "GradiumTts";
    private static final String WORKER = "https://dj-puente.franc-all-starligth.workers.dev/gradium";
    private static final String API = "https://api.gradium.ai/api/post/speech/tts";
    private static final int MAX_CHARS = 800;
    private static final long KEY_TTL_MS = 12L * 60L * 60L * 1000L;
    private static final long PAUSE_QUOTA_MS = 30L * 60L * 1000L;
    private static final long PAUSE_ERR_MS = 60L * 1000L;
    private static final Pattern KEY_RE = Pattern.compile("\"key\"\\s*:\\s*\"([^\"]+)\"");

    // Solo para pruebas locales
    static String testWorker;
    static String testApi;

    private static volatile String key;
    private static volatile long keyTs;
    private static volatile long pausedUntil;

    private GradiumTts() {}

    /** @return WAV o null. Nunca lanza. */
    public static byte[] speak(String text, String voiceId) {
        try {
            if (text == null || voiceId == null) return null;
            voiceId = voiceId.trim();
            if (voiceId.isEmpty()) return null;
            if (System.currentTimeMillis() < pausedUntil) return null;
            text = EdgeTts.clean(text);
            if (text.isEmpty()) return null;
            if (text.length() > MAX_CHARS) text = text.substring(0, MAX_CHARS);

            for (int pass = 0; pass < 2; pass++) {
                String k = getKey(pass > 0);
                if (k == null) {
                    pause(PAUSE_ERR_MS);
                    return null;
                }
                int[] code = new int[1];
                byte[] a = post(k, text, voiceId, code);
                if (a != null) return a;
                if (code[0] == 401 || code[0] == 403) { // llave rotada o mala: pedir otra y reintentar una vez
                    key = null;
                    continue;
                }
                if (code[0] == 402 || code[0] == 429) pause(PAUSE_QUOTA_MS); // sin cupo
                else pause(PAUSE_ERR_MS);
                return null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "speak fallo: " + t);
        }
        return null;
    }

    private static void pause(long ms) {
        pausedUntil = System.currentTimeMillis() + ms;
    }

    private static synchronized String getKey(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && key != null && now - keyTs < KEY_TTL_MS) return key;
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(testWorker != null ? testWorker : WORKER).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(8000);
            c.setRequestMethod("GET");
            int code = c.getResponseCode();
            if (code != 200) {
                Log.w(TAG, "Worker respondio " + code);
                return null;
            }
            String body = new String(readAll(c.getInputStream()), StandardCharsets.UTF_8);
            Matcher m = KEY_RE.matcher(body);
            if (!m.find()) {
                Log.w(TAG, "Worker sin llave en la respuesta");
                return null;
            }
            key = m.group(1);
            keyTs = now;
            return key;
        } catch (Throwable t) {
            Log.w(TAG, "pedir llave fallo: " + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static byte[] post(String k, String text, String voiceId, int[] codeOut) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(testApi != null ? testApi : API).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(25000);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("x-api-key", k);
            c.setRequestProperty("Content-Type", "application/json");
            String json = "{\"text\":" + q(text) + ",\"voice_id\":" + q(voiceId)
                + ",\"output_format\":\"wav\",\"only_audio\":true}";
            byte[] body = json.getBytes(StandardCharsets.UTF_8);
            c.setFixedLengthStreamingMode(body.length);
            OutputStream out = c.getOutputStream();
            out.write(body);
            out.flush();
            int code = c.getResponseCode();
            codeOut[0] = code;
            if (code != 200) {
                String err = "";
                try {
                    InputStream es = c.getErrorStream();
                    if (es != null) err = new String(readAll(es), StandardCharsets.UTF_8);
                } catch (Throwable ignore) {}
                Log.w(TAG, "Gradium " + code + ": " + (err.length() > 200 ? err.substring(0, 200) : err));
                return null;
            }
            byte[] a = readAll(c.getInputStream());
            // un WAV empieza con "RIFF"; si no, no es audio (p. ej. un JSON de error)
            if (a.length < 64 || a[0] != 'R' || a[1] != 'I' || a[2] != 'F' || a[3] != 'F') {
                String head = new String(a, 0, Math.min(a.length, 120), StandardCharsets.UTF_8);
                Log.w(TAG, "Respuesta que no es WAV (" + a.length + " bytes): " + head);
                codeOut[0] = 0;
                return null;
            }
            byte[] n = normalizeWav(a);
            if (n == null) {
                codeOut[0] = 0;
                return null;
            }
            return n;
        } catch (Throwable t) {
            Log.w(TAG, "post fallo: " + t);
            return null;
        } finally {
            if (c != null) c.disconnect();
        }
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 255) | ((b[o + 1] & 255) << 8) | ((b[o + 2] & 255) << 16) | ((b[o + 3] & 255) << 24);
    }

    private static int le16(byte[] b, int o) {
        return (b[o] & 255) | ((b[o + 1] & 255) << 8);
    }

    private static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static void put16(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8);
    }

    /**
     * v0.20.240: reconstruye el WAV con un encabezado limpio de 44 bytes y los tamanos reales (la respuesta de Gradium
     * puede traer tamanos en 0 / 0xFFFFFFFF o chunks extra que MediaPlayer no tolera). Devuelve null si no hay audio
     * util (el llamador cae a Edge). Si no logra leer el encabezado, devuelve el WAV tal cual.
     */
    static byte[] normalizeWav(byte[] a) {
        try {
            int fmtAt = -1, fmtSize = 0, dataAt = -1;
            long dataSizeHdr = 0;
            int p = 12;
            while (p + 8 <= a.length) {
                int id0 = a[p], id1 = a[p + 1], id2 = a[p + 2], id3 = a[p + 3];
                long sz = le32(a, p + 4) & 0xFFFFFFFFL;
                if (id0 == 'f' && id1 == 'm' && id2 == 't' && id3 == ' ') {
                    fmtAt = p + 8;
                    fmtSize = (int) Math.min(sz, 64);
                } else if (id0 == 'd' && id1 == 'a' && id2 == 't' && id3 == 'a') {
                    dataAt = p + 8;
                    dataSizeHdr = sz;
                    break;
                }
                long next = p + 8L + sz + (sz & 1);
                if (sz == 0xFFFFFFFFL || next > a.length) break;
                p = (int) next;
            }
            if (fmtAt < 0 || fmtSize < 16 || fmtAt + 16 > a.length || dataAt < 0 || dataAt > a.length) {
                Log.w(TAG, "WAV: no pude leer el encabezado; se entrega tal cual (" + a.length + " bytes)");
                return a;
            }
            int tag = le16(a, fmtAt);
            if (tag == 0xFFFE && fmtSize >= 26 && fmtAt + 26 <= a.length) tag = le16(a, fmtAt + 24);
            int ch = le16(a, fmtAt + 2);
            int rate = le32(a, fmtAt + 4);
            int align = le16(a, fmtAt + 12);
            int bits = le16(a, fmtAt + 14);
            if (ch < 1 || rate < 1000 || bits < 8 || align < 1) {
                Log.w(TAG, "WAV: formato raro tag=" + tag + " ch=" + ch + " rate=" + rate + " bits=" + bits + "; se entrega tal cual");
                return a;
            }
            long avail = a.length - dataAt;
            long len = dataSizeHdr;
            if (len == 0 || len > avail) len = avail; // tamano en 0, 0xFFFFFFFF o mayor al archivo: usar lo que hay
            len -= len % align;
            Log.i(TAG, "WAV: tag=" + tag + " ch=" + ch + " rate=" + rate + " bits=" + bits + " hdrData=" + dataSizeHdr
                + " real=" + avail + " -> " + len);
            if (len < 1000) {
                Log.w(TAG, "WAV: casi sin audio (" + len + " bytes); se usa Edge");
                return null;
            }
            byte[] o = new byte[44 + (int) len];
            o[0] = 'R'; o[1] = 'I'; o[2] = 'F'; o[3] = 'F';
            put32(o, 4, 36 + (int) len);
            o[8] = 'W'; o[9] = 'A'; o[10] = 'V'; o[11] = 'E';
            o[12] = 'f'; o[13] = 'm'; o[14] = 't'; o[15] = ' ';
            put32(o, 16, 16);
            put16(o, 20, tag == 3 ? 3 : 1);
            put16(o, 22, ch);
            put32(o, 24, rate);
            put32(o, 28, rate * align);
            put16(o, 32, align);
            put16(o, 34, bits);
            o[36] = 'd'; o[37] = 'a'; o[38] = 't'; o[39] = 'a';
            put32(o, 40, (int) len);
            System.arraycopy(a, dataAt, o, 44, (int) len);
            return o;
        } catch (Throwable t) {
            Log.w(TAG, "normalizeWav fallo: " + t);
            return a;
        }
    }

    private static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            switch (ch) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (ch < 32) b.append(String.format("\\u%04x", (int) ch));
                    else b.append(ch);
            }
        }
        return b.append('"').toString();
    }

    private static byte[] readAll(InputStream in) throws Exception {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        in.close();
        return o.toByteArray();
    }
}
