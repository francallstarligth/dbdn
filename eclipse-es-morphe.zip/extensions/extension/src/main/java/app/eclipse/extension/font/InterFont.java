package app.eclipse.extension.font;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Build;

import java.lang.reflect.Field;
import java.util.Map;

/**
 * v0.20.120 (SIN COMPILAR / SIN PROBAR). Pone Inter (la fuente de Mochy: Regular 400, Medium 500, SemiBold 600, Bold 700)
 * como fuente por defecto de toda la app: se arma un Typeface con los 4 pesos (Android 10+) y se reemplazan
 * Typeface.DEFAULT / DEFAULT_BOLD / SANS_SERIF / sDefaults y la entrada "sans-serif" del mapa del sistema. Compose usa
 * Typeface.create(Typeface.DEFAULT, peso, cursiva) para su fuente por defecto, asi que toma Inter y elige el peso. Todo
 * en try/catch: si algo falla, la app sigue con la fuente del sistema. Los archivos van en assets/ (parche de recursos).
 */
public final class InterFont {
    private static final String[] FILES = {
            "eclipse_inter_regular.ttf", "eclipse_inter_medium.ttf", "eclipse_inter_semibold.ttf", "eclipse_inter_bold.ttf"};
    private static final int[] WEIGHTS = {400, 500, 600, 700};

    private static boolean done;

    private InterFont() {}

    /** Lo llama el parche al inicio de EclipseApplication.onCreate. */
    public static void install(Context ctx) {
        try {
            if (done || ctx == null) return;
            done = true;
            if (Build.VERSION.SDK_INT < 29) return;
            Typeface tf = Q.build(ctx.getAssets());
            if (tf == null) return;
            Typeface bold = Typeface.create(tf, 700, false);
            Typeface italic = Typeface.create(tf, 400, true);
            Typeface boldItalic = Typeface.create(tf, 700, true);
            setStatic("DEFAULT", tf);
            setStatic("DEFAULT_BOLD", bold);
            setStatic("SANS_SERIF", tf);
            setStatic("sDefaults", new Typeface[]{tf, bold, italic, boldItalic});
            try {
                Field f = Typeface.class.getDeclaredField("sSystemFontMap");
                f.setAccessible(true);
                @SuppressWarnings("unchecked")
                Map<String, Typeface> m = (Map<String, Typeface>) f.get(null);
                if (m != null) m.put("sans-serif", tf);
            } catch (Throwable ignored) {}
        } catch (Throwable ignored) {}
    }

    private static void setStatic(String name, Object value) {
        try {
            Field f = Typeface.class.getDeclaredField(name);
            f.setAccessible(true);
            f.set(null, value);
        } catch (Throwable ignored) {}
    }

    /** Aparte para que Android < 10 nunca cargue estas clases. */
    private static final class Q {
        static Typeface build(AssetManager am) throws Exception {
            android.graphics.fonts.FontFamily.Builder fb = null;
            for (int i = 0; i < FILES.length; i++) {
                android.graphics.fonts.Font font = new android.graphics.fonts.Font.Builder(am, FILES[i])
                        .setWeight(WEIGHTS[i])
                        .setSlant(android.graphics.fonts.FontStyle.FONT_SLANT_UPRIGHT)
                        .build();
                if (fb == null) fb = new android.graphics.fonts.FontFamily.Builder(font);
                else fb.addFont(font);
            }
            if (fb == null) return null;
            return new Typeface.CustomFallbackBuilder(fb.build())
                    .setSystemFallback("sans-serif")
                    .setStyle(new android.graphics.fonts.FontStyle(400, android.graphics.fonts.FontStyle.FONT_SLANT_UPRIGHT))
                    .build();
        }
    }
}
