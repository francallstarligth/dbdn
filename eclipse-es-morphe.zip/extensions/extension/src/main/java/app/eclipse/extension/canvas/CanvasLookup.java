package app.eclipse.extension.canvas;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Busca el Canvas (video en bucle) de una cancion en la lista publica de la comunidad
 * (CommunityCanvas, sin cuenta ni cookie). Uso personal.
 *
 * El hook de Eclipse la llama en el HILO PRINCIPAL (Android prohibe la red ahi), asi que la busqueda
 * real se hace en un hilo de fondo; el hilo principal espera como maximo MAIN_WAIT_MS y, si no llega,
 * sigue sin Canvas y la busqueda termina sola dejando el resultado en la cache.
 * Nunca lanza excepciones: si algo falla devuelve null y Eclipse sigue como siempre.
 */
@SuppressWarnings("unused")
public final class CanvasLookup {
    private static final String TAG = "CanvasLookup";

    /** Avisos (Toast) con el paso donde se queda. Lo fija el parche segun su opcion "debug"; apagado por defecto. */
    private static volatile boolean debug = false;

    public static void setDebug(boolean enabled) { debug = enabled; }

    /** Tras un fallo de red no se repite la misma cancion durante este tiempo. */
    private static final long FAIL_COOLDOWN_MS = 120_000L;
    private static final HashMap<String, Long> FAIL_UNTIL = new HashMap<String, Long>();

    /** Cache: clave -> URL, o "" si se confirmo que no hay canvas. */
    private static final HashMap<String, String> CACHE = new HashMap<String, String>();

    /** Espera maxima en el hilo principal. Mas alto = mas chance de verlo a la primera, pero mas riesgo de tirones/ANR. */
    private static final long MAIN_WAIT_MS = 2000L;

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(2, new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "CanvasLookup");
            t.setDaemon(true);
            return t;
        }
    });
    /** Busquedas en curso (para no repetirlas si Eclipse vuelve a llamar por la misma cancion). */
    private static final HashMap<String, Future<String>> RUNNING = new HashMap<String, Future<String>>();

    private CanvasLookup() {}

    /**
     * @param title       titulo de la cancion
     * @param artist      artista
     * @param durationSec duracion en segundos (0 si no se sabe; no se usa para emparejar)
     * @return URL mp4 del canvas, o null
     */
    public static String lookup(final String title, final String artist, final int durationSec) {
        try {
            if (!isMainThread()) return lookupBlocking(title, artist, durationSec);

            // Hilo principal: no se puede usar la red aqui. Se hace en segundo plano y se espera poco.
            final String key = keyOf(title, artist, durationSec);
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) return hit.isEmpty() ? null : hit;
            }
            Future<String> f;
            synchronized (RUNNING) {
                f = RUNNING.get(key);
                if (f == null) {
                    FutureTask<String> task = new FutureTask<String>(new Callable<String>() {
                        @Override public String call() {
                            try {
                                return lookupBlocking(title, artist, durationSec);
                            } finally {
                                synchronized (RUNNING) { RUNNING.remove(key); }
                            }
                        }
                    });
                    RUNNING.put(key, task);
                    EXEC.execute(task);
                    f = task;
                }
            }
            try {
                return f.get(MAIN_WAIT_MS, TimeUnit.MILLISECONDS);
            } catch (TimeoutException te) {
                toast("Canvas: tardando, sigo en segundo plano");
                return null;
            }
        } catch (Throwable t) {
            Log.w(TAG, "lookup (principal) fallo: " + t);
            return null;
        }
    }

    private static String keyOf(String title, String artist, int durationSec) {
        int dur = durationSec > 10000 ? durationSec / 1000 : durationSec;
        return title + "|" + artist + "|" + dur;
    }

    private static boolean isMainThread() {
        try { return Looper.myLooper() == Looper.getMainLooper(); } catch (Throwable t) { return false; }
    }

    private static String lookupBlocking(String title, String artist, int durationSec) {
        try {
            if (title == null || title.trim().isEmpty()) { toast("Canvas: cancion sin titulo"); return null; }

            String key = keyOf(title, artist, durationSec);
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) { toast("Canvas: (cache) " + (hit.isEmpty() ? "sin canvas" : "OK")); return hit.isEmpty() ? null : hit; }
            }
            long nowMs = System.currentTimeMillis();
            synchronized (FAIL_UNTIL) {
                Long until = FAIL_UNTIL.get(key);
                if (until != null && nowMs < until) return null;
            }

            toast("Canvas: buscando '" + title + "'...");
            // 1) Tidal por titulo+artista (no depende de los IDs de la cancion: sirve para canciones agregadas).
            boolean[] tidalOk = new boolean[1];
            String result = TidalCanvas.lookup(title, artist, null, tidalOk);
            if (result != null) toast("Canvas: OK (Tidal)");
            boolean loaded = false;
            if (result == null) {
                // 2) Lista de la comunidad.
                result = CommunityCanvas.lookup(title, artist);
                loaded = CommunityCanvas.manifestLoaded();
                if (result != null) toast("Canvas: OK (comunidad)");
                else toast(loaded ? "Canvas: Tidal y la comunidad no tienen esta cancion" : "Canvas: no pude cargar la lista de la comunidad");
            }

            // Solo se guarda "sin canvas" si alguna fuente respondio bien; un fallo de red no se guarda.
            if (result != null || loaded || tidalOk[0]) {
                synchronized (CACHE) {
                    if (CACHE.size() > 300) CACHE.clear();
                    CACHE.put(key, result == null ? "" : result);
                }
            } else {
                synchronized (FAIL_UNTIL) {
                    if (FAIL_UNTIL.size() > 300) FAIL_UNTIL.clear();
                    FAIL_UNTIL.put(key, System.currentTimeMillis() + FAIL_COOLDOWN_MS);
                }
            }
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            toast("Canvas: error " + t);
            return null;
        }
    }

    private static void toast(final String msg) {
        if (!debug) return;
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
