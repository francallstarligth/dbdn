package app.eclipse.extension.canvas;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Busca el Canvas (video en bucle) de una cancion en la lista publica de la comunidad
 * (CommunityCanvas, sin cuenta ni cookie). Uso personal.
 *
 * v1.90.0: el gancho ya NO espera. La busqueda se hace en un hilo de fondo; si no esta en cache se devuelve null
 * al instante (sale la portada) y, cuando llega el video, se pone en la variable de estado de la pantalla
 * del reproductor (bindState/deliver) y tambien queda en la cache.
 * Nunca lanza excepciones: si algo falla devuelve null y Eclipse sigue como siempre.
 */
@SuppressWarnings("unused")
public final class CanvasLookup {
    private static final String TAG = "CanvasLookup";

    /** Avisos (Toast) con el paso donde se queda. Lo fija el parche segun su opcion "debug"; apagado por defecto. */
    private static volatile boolean debug = false;

    public static void setDebug(boolean enabled) { debug = enabled; }

    /** Cookie sp_dc del usuario (opcion del parche). Vacia = fuente Spotify apagada. */
    public static void setCookie(String value) { SpotifyCanvas.setCookie(value); }

    /** Tras un fallo de red no se repite la misma cancion durante este tiempo. */
    private static final long FAIL_COOLDOWN_MS = 120_000L;
    private static final HashMap<String, Long> FAIL_UNTIL = new HashMap<String, Long>();

    /** Cache: clave -> URL, o "" si se confirmo que no hay canvas. */
    private static final HashMap<String, String> CACHE = new HashMap<String, String>();

    /** Espera maxima en el hilo principal. Mas alto = mas chance de verlo a la primera, pero mas riesgo de tirones/ANR. */
    private static final long MAIN_WAIT_MS = 2000L;
    /** v1.51.0: si la cancion trae datos de Tidal se espera un poco mas (Tidal tiene prioridad). */
    private static final long MAIN_WAIT_TIDAL_MS = 3500L;
    private static final long TIDAL_WAIT_MS = 8500L;

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(2, new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "CanvasLookup");
            t.setDaemon(true);
            return t;
        }
    });
    /** Busquedas en curso (para no repetirlas si Eclipse vuelve a llamar por la misma cancion). */
    private static final HashMap<String, Future<String>> RUNNING = new HashMap<String, Future<String>>();

    private CanvasLookup() {}

    /**
     * @param title       titulo de la cancion
     * @param artist      artista
     * @param durationSec duracion en segundos (0 si no se sabe; no se usa para emparejar)
     * @return URL mp4 del canvas, o null
     */
    public static String lookup(final String title, final String artist, final int durationSec) {
        return lookup(title, artist, durationSec, null);
    }

    /**
     * v1.90.0: NUNCA espera. Si el Canvas ya esta en cache lo devuelve; si no, devuelve null al instante (Eclipse muestra
     * la portada y deja abrir el reproductor), lanza la busqueda en segundo plano y, cuando llega el video, lo entrega
     * a la pantalla del reproductor con {@link #bindState} (poniendo la URL en su variable de estado).
     */
    public static String lookup(final String title, final String artist, final int durationSec, final Object song) {
        try {
            final String key = keyOf(title, artist, durationSec);
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) return hit.isEmpty() ? null : hit;
            }
            synchronized (RUNNING) {
                if (!RUNNING.containsKey(key)) {
                    toast("Canvas[1] busqueda lanzada: " + key);
                    FutureTask<String> task = new FutureTask<String>(new Callable<String>() {
                        @Override public String call() {
                            String r = null;
                            try {
                                r = lookupBlocking(title, artist, durationSec, song);
                            } finally {
                                synchronized (RUNNING) { RUNNING.remove(key); }
                            }
                            if (r != null && !r.isEmpty()) deliver(key, r);
                            return r;
                        }
                    });
                    RUNNING.put(key, task);
                    EXEC.execute(task);
                }
            }
            return null;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            return null;
        }
    }

    /** Pantallas (variables de estado de Eclipse) que esperan el Canvas de una cancion: clave -> estados. */
    private static final HashMap<String, ArrayList<WeakReference<Object>>> STATES =
        new HashMap<String, ArrayList<WeakReference<Object>>>();

    /**
     * v1.90.0: lo llama el gancho de rf0 justo antes de pedir el Canvas. Guarda la variable de estado de la pantalla del
     * reproductor para esta cancion. Un mismo estado solo espera una cancion a la vez (se quita de las demas).
     */
    private static WeakReference<Object> lastState, lastSong;

    public static void bindState(Object song, Object state) {
        try {
            if (song == null || state == null) { toast("Canvas[2] bindState: song/estado nulo"); return; }
            // v0.20.257: w32.Z se llama en cada recomposicion; si es el mismo estado y la misma cancion no se repite nada.
            if (lastState != null && lastState.get() == state && lastSong != null && lastSong.get() == song) return;
            lastState = new WeakReference<Object>(state);
            lastSong = new WeakReference<Object>(song);
            String key = keyOfSong(song);
            if (key == null) { toast("Canvas[2] bindState: no pude armar la clave"); return; }
            toast("Canvas[2] pantalla registrada: " + key);
            synchronized (STATES) {
                if (STATES.size() > 50) STATES.clear();
                for (ArrayList<WeakReference<Object>> l : STATES.values()) {
                    for (int i = l.size() - 1; i >= 0; i--) {
                        Object o = l.get(i).get();
                        if (o == null || o == state) l.remove(i);
                    }
                }
                ArrayList<WeakReference<Object>> mine = STATES.get(key);
                if (mine == null) { mine = new ArrayList<WeakReference<Object>>(); STATES.put(key, mine); }
                mine.add(new WeakReference<Object>(state));
            }
        } catch (Throwable t) {
            Log.w(TAG, "bindState fallo: " + t);
        }
    }

    /**
     * v0.20.255: lo llama el parche justo despues de que Eclipse escribe su resultado en el estado del reproductor.
     * Si el Canvas de esta cancion ya esta en cache (la busqueda en segundo plano llego antes), se vuelve a poner,
     * porque ese setValue de Eclipse puede haber borrado la entrega.
     */
    public static void reapply(Object song, Object state) {
        try {
            if (song == null || state == null) return;
            String key = keyOfSong(song);
            if (key == null) return;
            final String url;
            synchronized (CACHE) { url = CACHE.get(key); }
            if (url == null || url.isEmpty()) { toast("Canvas[4] reapply: aun sin Canvas en cache para " + key); return; }
            toast("Canvas[4] reapply: lo vuelvo a poner (" + key + ")");
            final Object st = state;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() { setStateValue(st, url); }
            });
        } catch (Throwable t) {
            Log.w(TAG, "reapply fallo: " + t);
        }
    }

    private static String keyOfSong(Object song) {
        try {
            Object t = song.getClass().getMethod("getTitle").invoke(song);
            Object a = song.getClass().getMethod("getArtist").invoke(song);
            Object d = song.getClass().getMethod("getDuration").invoke(song);
            return keyOf((String) t, (String) a, d instanceof Integer ? ((Integer) d).intValue() : 0);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Pone la URL en los estados que esperaban esta cancion (en el hilo principal). */
    private static void deliver(String key, final String url) {
        final ArrayList<WeakReference<Object>> list;
        synchronized (STATES) { list = STATES.remove(key); }
        if (list == null || list.isEmpty()) { toast("Canvas[3] llego el video pero NADIE lo esperaba: " + key); return; }
        toast("Canvas[3] llego el video, entrego a " + list.size() + " pantalla(s): " + key);
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() {
                for (WeakReference<Object> w : list) {
                    Object st = w.get();
                    if (st != null) setStateValue(st, url);
                }
            }
        });
    }

    private static void setStateValue(Object state, String url) {
        try {
            for (Method m : state.getClass().getMethods()) {
                if (!m.getName().equals("setValue")) continue;
                Class<?>[] pt = m.getParameterTypes();
                if (pt.length != 1 || !pt[0].isAssignableFrom(String.class)) continue;
                try { m.setAccessible(true); } catch (Throwable ignored) {}
                m.invoke(state, url);
                toast("Canvas: entregado al reproductor");
                return;
            }
            toast("Canvas: no encontre setValue en el estado");
        } catch (Throwable t) {
            Log.w(TAG, "setStateValue fallo: " + t);
        }
    }

    private static String keyOf(String title, String artist, int durationSec) {
        int dur = durationSec > 10000 ? durationSec / 1000 : durationSec;
        return title + "|" + artist + "|" + dur;
    }

    private static boolean isMainThread() {
        try { return Looper.myLooper() == Looper.getMainLooper(); } catch (Throwable t) { return false; }
    }

    private static String lookupBlocking(String title, String artist, int durationSec, Object song) {
        try {
            if (title == null || title.trim().isEmpty()) { toast("Canvas: cancion sin titulo"); return null; }

            String key = keyOf(title, artist, durationSec);
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) { toast("Canvas: (cache) " + (hit.isEmpty() ? "sin canvas" : "OK")); return hit.isEmpty() ? null : hit; }
            }
            long nowMs = System.currentTimeMillis();
            synchronized (FAIL_UNTIL) {
                Long until = FAIL_UNTIL.get(key);
                if (until != null && nowMs < until) return null;
            }

            // v0.20.205: la busqueda de Spotify arranca YA, en paralelo (hilo propio), mientras se espera a Tidal/Apple y se mira la
            // comunidad. Su resultado solo se usa si ninguno de ellos tiene Canvas (la prioridad no cambia).
            FutureTask<SpotifyCanvas.Result> spTask = null;
            if (SpotifyCanvas.enabled()) {
                final String fTitle = title, fArtist = artist;
                final int fDur = durationSec;
                spTask = new FutureTask<SpotifyCanvas.Result>(new Callable<SpotifyCanvas.Result>() {
                    @Override public SpotifyCanvas.Result call() { return SpotifyCanvas.lookup(fTitle, fArtist, fDur); }
                });
                Thread spThread = new Thread(spTask, "CanvasSpotify");
                spThread.setDaemon(true);
                spThread.start();
            }

            // v1.51.0: Tidal primero de verdad: si Eclipse todavia esta bajando el Canvas de Tidal de esta cancion, se espera.
            long tStart = System.currentTimeMillis();
            String tidal = TidalFirst.await(song, TIDAL_WAIT_MS);
            long tTidalMs = System.currentTimeMillis() - tStart;
            if (tidal != null) { toast("Canvas: OK (Tidal o Apple) [espera " + tTidalMs + " ms]"); return tidal; }

            toast("Canvas: buscando '" + title + "'...");
            // v1.50.0: Spotify es la ULTIMA opcion (despues de Tidal/Apple y de la comunidad); desde v0.20.205 su busqueda ya
            // corre en paralelo desde el principio (spTask) y aqui solo se recoge el resultado si hace falta.
            long tCom0 = System.currentTimeMillis();
            String result = CommunityCanvas.lookup(title, artist);
            long tComMs = System.currentTimeMillis() - tCom0;
            boolean loaded = CommunityCanvas.manifestLoaded();
            String tm = " [Tidal/Apple " + tTidalMs + " ms, comunidad " + tComMs + " ms]";
            if (result != null) toast("Canvas: OK (comunidad)" + tm);
            else toast((loaded ? "Canvas: la comunidad no tiene esta cancion" : "Canvas: no pude cargar la lista de la comunidad") + tm);

            // Fuente Spotify (solo si hay cookie): se usa cuando la comunidad no lo tiene.
            boolean spotifyOk = true; // true = no hay fallo pendiente de Spotify
            if (result == null && SpotifyCanvas.enabled()) {
                SpotifyCanvas.Result sr;
                try {
                    sr = spTask != null ? spTask.get(20, TimeUnit.SECONDS) : SpotifyCanvas.lookup(title, artist, durationSec);
                } catch (Throwable e) {
                    sr = new SpotifyCanvas.Result(null, false, "error " + e.getClass().getSimpleName());
                }
                result = sr.url;
                spotifyOk = sr.definitive;
                toast("Canvas Spotify: " + sr.note);
                if (sr.url != null) probeQuality(sr.url); // v0.20.21: calidad en segundo plano (no demora el Canvas)
            }

            // Solo se guarda "sin canvas" si las fuentes respondieron bien; un fallo de red/token no se guarda.
            if (result != null || (loaded && spotifyOk)) {
                synchronized (CACHE) {
                    if (CACHE.size() > 300) CACHE.clear();
                    CACHE.put(key, result == null ? "" : result);
                }
            } else {
                synchronized (FAIL_UNTIL) {
                    if (FAIL_UNTIL.size() > 300) FAIL_UNTIL.clear();
                    FAIL_UNTIL.put(key, System.currentTimeMillis() + FAIL_COOLDOWN_MS);
                }
            }
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            toast("Canvas: error " + t);
            return null;
        }
    }

    /**
     * v0.20.21: avisa (solo con los avisos de depuracion) el tipo de archivo, la resolucion y el bitrate del Canvas de
     * Spotify, y los campos que mando Spotify. Corre en segundo plano; si falla, no avisa nada mas.
     */
    private static void probeQuality(final String url) {
        if (!debug) return;
        final String fields = SpotifyCanvas.lastFields;
        EXEC.execute(new Runnable() {
            @Override public void run() {
                android.media.MediaMetadataRetriever mmr = null;
                try {
                    String path = url;
                    int q = path.indexOf('?');
                    if (q >= 0) path = path.substring(0, q);
                    String kind = path.toLowerCase(java.util.Locale.ROOT).endsWith(".m3u8") ? "lista de calidades (m3u8)"
                            : path.toLowerCase(java.util.Locale.ROOT).endsWith(".mp4") ? "mp4" : "archivo";
                    String res = "?";
                    String br = "";
                    try {
                        mmr = new android.media.MediaMetadataRetriever();
                        mmr.setDataSource(url, new java.util.HashMap<String, String>());
                        String w = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
                        String h = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
                        String b = mmr.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_BITRATE);
                        if (w != null && h != null) res = w + "x" + h;
                        if (b != null) {
                            try { br = ", " + String.format(java.util.Locale.US, "%.1f", Long.parseLong(b) / 1000000.0) + " Mbps"; } catch (Throwable ignored) {}
                        }
                    } catch (Throwable t) {
                        res = "no pude leerla (" + t.getClass().getSimpleName() + ")";
                    }
                    toast("Canvas Spotify calidad: " + kind + " " + res + br + " | campos: " + fields);
                } catch (Throwable ignored) {
                } finally {
                    try { if (mmr != null) mmr.release(); } catch (Throwable ignored) {}
                }
            }
        });
    }

    private static void toast(final String msg) {
        if (!debug) return;
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
