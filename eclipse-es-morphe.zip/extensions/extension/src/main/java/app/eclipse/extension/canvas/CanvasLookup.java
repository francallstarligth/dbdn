package app.eclipse.extension.canvas;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Busca el Canvas (video en bucle) de una cancion en la lista publica de la comunidad
 * (CommunityCanvas, sin cuenta ni cookie). Uso personal.
 *
 * v1.90.0: el gancho ya NO espera. La busqueda se hace en un hilo de fondo; si no esta en cache se devuelve null
 * al instante (sale la portada) y, cuando llega el video, se pone en la variable de estado de la pantalla
 * del reproductor (bindState/deliver) y tambien queda en la cache.
 * Nunca lanza excepciones: si algo falla devuelve null y Eclipse sigue como siempre.
 */
@SuppressWarnings("unused")
public final class CanvasLookup {
    private static final String TAG = "CanvasLookup";

    /** Avisos (Toast) con el paso donde se queda. Lo fija el parche segun su opcion "debug"; apagado por defecto. */
    private static volatile boolean debug = false;

    public static void setDebug(boolean enabled) { debug = enabled; }

    /** Cookie sp_dc del usuario (opcion del parche). Vacia = fuente Spotify apagada. */
    public static void setCookie(String value) { SpotifyCanvas.setCookie(value); }

    /** Tras un fallo de red no se repite la misma cancion durante este tiempo. */
    private static final long FAIL_COOLDOWN_MS = 120_000L;
    private static final HashMap<String, Long> FAIL_UNTIL = new HashMap<String, Long>();

    /** Cache: clave -> URL, o "" si se confirmo que no hay canvas. */
    private static final HashMap<String, String> CACHE = new HashMap<String, String>();

    /** v0.20.6: el Canvas que viene de Spotify se entrega unos segundos despues de pedirlo, para que se vea la portada y su fundido. */
    private static final long SPOTIFY_DELAY_MS = 3500L;
    private static final HashSet<String> SPOTIFY_KEYS = new HashSet<String>();
    private static final HashMap<String, Long> SPOTIFY_READY = new HashMap<String, Long>();

    private static boolean isSpotify(String key) {
        synchronized (SPOTIFY_KEYS) { return SPOTIFY_KEYS.contains(key); }
    }

    /** Entrega la URL cuando llegue la hora `readyAt` (uptimeMillis); si ya paso, al instante. */
    private static void deliverAt(final String key, final String url, long readyAt) {
        long delay = readyAt - SystemClock.uptimeMillis();
        if (delay <= 0) { deliver(key, url); return; }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override public void run() { deliver(key, url); }
        }, delay);
    }

    /** Espera maxima en el hilo principal. Mas alto = mas chance de verlo a la primera, pero mas riesgo de tirones/ANR. */
    private static final long MAIN_WAIT_MS = 2000L;
    /** v1.51.0: si la cancion trae datos de Tidal se espera un poco mas (Tidal tiene prioridad). */
    private static final long MAIN_WAIT_TIDAL_MS = 3500L;
    private static final long TIDAL_WAIT_MS = 2800L;

    private static final ExecutorService EXEC = Executors.newFixedThreadPool(2, new ThreadFactory() {
        @Override public Thread newThread(Runnable r) {
            Thread t = new Thread(r, "CanvasLookup");
            t.setDaemon(true);
            return t;
        }
    });
    /** Busquedas en curso (para no repetirlas si Eclipse vuelve a llamar por la misma cancion). */
    private static final HashMap<String, Future<String>> RUNNING = new HashMap<String, Future<String>>();

    private CanvasLookup() {}

    /**
     * @param title       titulo de la cancion
     * @param artist      artista
     * @param durationSec duracion en segundos (0 si no se sabe; no se usa para emparejar)
     * @return URL mp4 del canvas, o null
     */
    public static String lookup(final String title, final String artist, final int durationSec) {
        return lookup(title, artist, durationSec, null);
    }

    /**
     * v1.90.0: NUNCA espera. Si el Canvas ya esta en cache lo devuelve; si no, devuelve null al instante (Eclipse muestra
     * la portada y deja abrir el reproductor), lanza la busqueda en segundo plano y, cuando llega el video, lo entrega
     * a la pantalla del reproductor con {@link #bindState} (poniendo la URL en su variable de estado).
     */
    public static String lookup(final String title, final String artist, final int durationSec, final Object song) {
        try {
            final String key = keyOf(title, artist, durationSec);
            String hit;
            synchronized (CACHE) { hit = CACHE.get(key); }
            if (hit != null) {
                if (hit.isEmpty()) return null;
                if (!isSpotify(key)) return hit;
                // v0.20.6: Canvas de Spotify en cache: no se da al instante, se entrega 3,5 s despues de pedirlo.
                long now = SystemClock.uptimeMillis();
                Long ready;
                boolean first = false;
                synchronized (SPOTIFY_READY) {
                    ready = SPOTIFY_READY.get(key);
                    if (ready != null && now > ready + 20000L) ready = null; // otra vez la cancion: reinicia
                    if (ready == null) { ready = now + SPOTIFY_DELAY_MS; SPOTIFY_READY.put(key, ready); first = true; }
                }
                if (now >= ready) return hit;
                if (first) deliverAt(key, hit, ready);
                return null;
            }
            final long t0 = SystemClock.uptimeMillis();
            synchronized (RUNNING) {
                if (!RUNNING.containsKey(key)) {
                    FutureTask<String> task = new FutureTask<String>(new Callable<String>() {
                        @Override public String call() {
                            String r = null;
                            try {
                                r = lookupBlocking(title, artist, durationSec, song);
                            } finally {
                                synchronized (RUNNING) { RUNNING.remove(key); }
                            }
                            if (r != null && !r.isEmpty()) {
                                if (isSpotify(key)) {
                                    long ready = t0 + SPOTIFY_DELAY_MS;
                                    synchronized (SPOTIFY_READY) { SPOTIFY_READY.put(key, ready); }
                                    deliverAt(key, r, ready);
                                } else {
                                    deliver(key, r);
                                }
                            }
                            return r;
                        }
                    });
                    RUNNING.put(key, task);
                    EXEC.execute(task);
                }
            }
            return null;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            return null;
        }
    }

    /** Pantallas (variables de estado de Eclipse) que esperan el Canvas de una cancion: clave -> estados. */
    private static final HashMap<String, ArrayList<WeakReference<Object>>> STATES =
        new HashMap<String, ArrayList<WeakReference<Object>>>();

    /**
     * v1.90.0: lo llama el gancho de rf0 justo antes de pedir el Canvas. Guarda la variable de estado de la pantalla del
     * reproductor para esta cancion. Un mismo estado solo espera una cancion a la vez (se quita de las demas).
     */
    public static void bindState(Object song, Object state) {
        try {
            if (song == null || state == null) return;
            String key = keyOfSong(song);
            if (key == null) return;
            synchronized (STATES) {
                if (STATES.size() > 50) STATES.clear();
                for (ArrayList<WeakReference<Object>> l : STATES.values()) {
                    for (int i = l.size() - 1; i >= 0; i--) {
                        Object o = l.get(i).get();
                        if (o == null || o == state) l.remove(i);
                    }
                }
                ArrayList<WeakReference<Object>> mine = STATES.get(key);
                if (mine == null) { mine = new ArrayList<WeakReference<Object>>(); STATES.put(key, mine); }
                mine.add(new WeakReference<Object>(state));
            }
        } catch (Throwable t) {
            Log.w(TAG, "bindState fallo: " + t);
        }
    }

    private static String keyOfSong(Object song) {
        try {
            Object t = song.getClass().getMethod("getTitle").invoke(song);
            Object a = song.getClass().getMethod("getArtist").invoke(song);
            Object d = song.getClass().getMethod("getDuration").invoke(song);
            return keyOf((String) t, (String) a, d instanceof Integer ? ((Integer) d).intValue() : 0);
        } catch (Throwable t) {
            return null;
        }
    }

    /** Pone la URL en los estados que esperaban esta cancion (en el hilo principal). */
    private static void deliver(String key, final String url) {
        final ArrayList<WeakReference<Object>> list;
        synchronized (STATES) { list = STATES.remove(key); }
        if (list == null || list.isEmpty()) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override public void run() {
                for (WeakReference<Object> w : list) {
                    Object st = w.get();
                    if (st != null) setStateValue(st, url);
                }
            }
        });
    }

    private static void setStateValue(Object state, String url) {
        try {
            for (Method m : state.getClass().getMethods()) {
                if (!m.getName().equals("setValue")) continue;
                Class<?>[] pt = m.getParameterTypes();
                if (pt.length != 1 || !pt[0].isAssignableFrom(String.class)) continue;
                try { m.setAccessible(true); } catch (Throwable ignored) {}
                m.invoke(state, url);
                toast("Canvas: entregado al reproductor");
                return;
            }
            toast("Canvas: no encontre setValue en el estado");
        } catch (Throwable t) {
            Log.w(TAG, "setStateValue fallo: " + t);
        }
    }

    private static String keyOf(String title, String artist, int durationSec) {
        int dur = durationSec > 10000 ? durationSec / 1000 : durationSec;
        return title + "|" + artist + "|" + dur;
    }

    private static boolean isMainThread() {
        try { return Looper.myLooper() == Looper.getMainLooper(); } catch (Throwable t) { return false; }
    }

    private static String lookupBlocking(String title, String artist, int durationSec, Object song) {
        try {
            if (title == null || title.trim().isEmpty()) { toast("Canvas: cancion sin titulo"); return null; }

            String key = keyOf(title, artist, durationSec);
            synchronized (CACHE) {
                String hit = CACHE.get(key);
                if (hit != null) { toast("Canvas: (cache) " + (hit.isEmpty() ? "sin canvas" : "OK")); return hit.isEmpty() ? null : hit; }
            }
            long nowMs = System.currentTimeMillis();
            synchronized (FAIL_UNTIL) {
                Long until = FAIL_UNTIL.get(key);
                if (until != null && nowMs < until) return null;
            }

            // v1.51.0: Tidal primero de verdad: si Eclipse todavia esta bajando el Canvas de Tidal de esta cancion, se espera.
            String tidal = TidalFirst.await(song, TIDAL_WAIT_MS);
            if (tidal != null) { toast("Canvas: OK (Tidal)"); return tidal; }

            toast("Canvas: buscando '" + title + "'...");
            // v1.50.0: Spotify es la ULTIMA opcion (despues de Tidal/Apple, que resuelve Eclipse antes de llegar aqui, y de la
            // comunidad). Solo se le adelanta el token en segundo plano, mientras la comunidad busca; su resultado no se usa si ella lo tiene.
            if (SpotifyCanvas.enabled()) {
                EXEC.execute(new Runnable() { @Override public void run() { SpotifyCanvas.warmUp(); } });
            }
            String result = CommunityCanvas.lookup(title, artist);
            boolean loaded = CommunityCanvas.manifestLoaded();
            if (result != null) toast("Canvas: OK (comunidad)");
            else toast(loaded ? "Canvas: la comunidad no tiene esta cancion" : "Canvas: no pude cargar la lista de la comunidad");

            // Fuente Spotify (solo si hay cookie): se usa cuando la comunidad no lo tiene.
            boolean spotifyOk = true; // true = no hay fallo pendiente de Spotify
            if (result == null && SpotifyCanvas.enabled()) {
                SpotifyCanvas.Result sr = SpotifyCanvas.lookup(title, artist, durationSec);
                result = sr.url;
                if (result != null) { synchronized (SPOTIFY_KEYS) { SPOTIFY_KEYS.add(key); } }
                spotifyOk = sr.definitive;
                toast("Canvas Spotify: " + sr.note);
            }

            // Solo se guarda "sin canvas" si las fuentes respondieron bien; un fallo de red/token no se guarda.
            if (result != null || (loaded && spotifyOk)) {
                synchronized (CACHE) {
                    if (CACHE.size() > 300) CACHE.clear();
                    CACHE.put(key, result == null ? "" : result);
                }
            } else {
                synchronized (FAIL_UNTIL) {
                    if (FAIL_UNTIL.size() > 300) FAIL_UNTIL.clear();
                    FAIL_UNTIL.put(key, System.currentTimeMillis() + FAIL_COOLDOWN_MS);
                }
            }
            return result;
        } catch (Throwable t) {
            Log.w(TAG, "lookup fallo: " + t);
            toast("Canvas: error " + t);
            return null;
        }
    }

    private static void toast(final String msg) {
        if (!debug) return;
        try {
            Log.d(TAG, msg);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show(); } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable ignored) {}
    }
}
