package app.eclipse.extension.artwork;

/**
 * v1.100.10 PRUEBA (no es un arreglo): hace que el fondo "Portada desenfocada" (estilo 4 en di6.c) se dibuje con
 * la rama de "Dynamic" (estilo 6) para saber si la raya a la mitad viene de esa rama. Ademas anota en el
 * diagnostico (portapapeles) que estilo llego. Si algo falla devuelve el valor sin cambios.
 */
@SuppressWarnings("unused")
public final class StyleTest {
    private StyleTest() {}

    public static int map(int style) {
        try {
            String nombre = style == 4 ? " (Portada desenfocada)" : style == 6 ? " (Dynamic)" : "";
            PrevCover.diagStyle("estilo" + style,
                    "di6.c estilo=" + style + nombre + (style == 4 ? " -> PRUEBA: se dibuja como Dynamic" : ""));
        } catch (Throwable ignored) {
        }
        return style == 4 ? 6 : style;
    }
}
