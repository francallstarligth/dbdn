package app.eclipse.extension.artwork;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * v1.99.0: al cambiar de cancion, la imagen ANTERIOR se queda dibujada mientras carga la nueva (como Bitchord).
 *
 * Eclipse dibuja las portadas/fondos del reproductor con un componente compartido (by9.c -> by9.d -> Coil
 * SubcomposeAsyncImage; el contenido es la lambda w71.k, caso q=1). Mientras Coil carga (estado z81, o a91 vacio) esa
 * lambda dibuja un cuadro gris (qa2.b); al terminar (b91) dibuja el Drawable con bc2.g.
 *
 * Como el componente se usa en TODA la app (listas, albumes...), solo se toca el del reproductor: el parche marca con
 * {@link #tag0}..{@link #tag7} el objeto de parametros (sn3) que construye cada sitio del reproductor (di6.b, di6.c,
 * xi6.e). La lambda consulta {@link #saved} (devuelve el ultimo painter bueno de ESE sitio o null) y {@link #remember}
 * (lo guarda al terminar la carga). Cada sitio tiene su propio recuerdo: portada y fondo no se mezclan.
 *
 * No usa nada de Android: solo java.lang.ref. Si algo no esta marcado, saved() devuelve null y la app hace lo de siempre.
 */
@SuppressWarnings("unused")
public final class PrevCover {
    private static final int SITES = 8;
    private static final int MAX_TAGS = 256;

    private static final class Tag {
        final WeakReference<Object> ref;
        final int site;
        Tag(Object o, int site) { this.ref = new WeakReference<Object>(o); this.site = site; }
    }

    private static final ArrayList<Tag> TAGS = new ArrayList<Tag>();
    private static final Object[] LAST = new Object[SITES];

    public static void tag0(Object sn3) { tag(0, sn3); }
    public static void tag1(Object sn3) { tag(1, sn3); }
    public static void tag2(Object sn3) { tag(2, sn3); }
    public static void tag3(Object sn3) { tag(3, sn3); }
    public static void tag4(Object sn3) { tag(4, sn3); }
    public static void tag5(Object sn3) { tag(5, sn3); }
    public static void tag6(Object sn3) { tag(6, sn3); }
    public static void tag7(Object sn3) { tag(7, sn3); }

    private static synchronized void tag(int site, Object sn3) {
        try {
            if (sn3 == null) return;
            // Quita referencias muertas y, si hay demasiadas, las mas viejas.
            for (int i = TAGS.size() - 1; i >= 0; i--) {
                if (TAGS.get(i).ref.get() == null) TAGS.remove(i);
            }
            while (TAGS.size() >= MAX_TAGS) TAGS.remove(0);
            TAGS.add(new Tag(sn3, site));
        } catch (Throwable ignored) {
        }
    }

    private static int siteOf(Object sn3) {
        if (sn3 == null) return -1;
        // De atras hacia adelante: lo mas probable es el objeto recien creado.
        for (int i = TAGS.size() - 1; i >= 0; i--) {
            Tag t = TAGS.get(i);
            if (t.ref.get() == sn3) return t.site;
        }
        return -1;
    }

    /** Ultimo painter (i36) que termino de cargar en el sitio de este sn3, o null (sitio no marcado / nada guardado). */
    public static synchronized Object saved(Object sn3) {
        try {
            int s = siteOf(sn3);
            return s < 0 ? null : LAST[s];
        } catch (Throwable t) {
            return null;
        }
    }

    /** Guarda el painter recien cargado (rama exito) si el sn3 es de un sitio del reproductor. */
    public static synchronized void remember(Object sn3, Object painter) {
        try {
            if (painter == null) return;
            int s = siteOf(sn3);
            if (s >= 0) LAST[s] = painter;
        } catch (Throwable ignored) {
        }
    }
}
