package app.eclipse.extension.artwork;

import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * v1.99.1: al cambiar de cancion, el FONDO borroso del reproductor se queda con la imagen anterior y la PORTADA nitida
 * muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse dibuja portadas/fondos con un componente compartido (by9.c -> Coil SubcomposeAsyncImage; contenido = lambda
 * w71.k, caso q=1). Como se usa en TODA la app, solo se toca el del reproductor: el parche marca con {@link #tagBg} o
 * {@link #tagCover} el objeto de parametros (sn3) que construye cada sitio del reproductor. La lambda consulta
 * {@link #saved}: fondo -> ultimo painter bueno (o null); portada -> un Drawable con el cuadro y la nota; sitio no
 * marcado -> null (la app hace lo de siempre). {@link #remember} guarda el painter solo para fondos.
 */
@SuppressWarnings("unused")
public final class PrevCover {
    private static final int BG = 1;      // fondo borroso por defecto de Eclipse (di6.c)
    private static final int COVER = 2;
    private static final int BG2 = 3;     // copia borrosa / reflejo de la portada (xi6.e)
    private static final long FADE_MS = 600;
    private static final int MAX_TAGS = 256;

    private static final class Tag {
        final WeakReference<Object> ref;
        final int kind;
        Tag(Object o, int kind) { this.ref = new WeakReference<Object>(o); this.kind = kind; }
    }

    private static final ArrayList<Tag> TAGS = new ArrayList<Tag>();
    private static final Object[] lastBg = new Object[4];          // painter guardado por sitio (1 y 3)
    private static final Drawable[] lastSrc = new Drawable[4];     // ultimo Drawable cargado por sitio
    private static final Drawable[] lastWrapped = new Drawable[4]; // su envoltorio con fundido
    private static Drawable placeholder;

    public static void tagBg(Object sn3) { tag(BG, sn3); }

    public static void tagBg2(Object sn3) { tag(BG2, sn3); }

    public static void tagCover(Object sn3) { tag(COVER, sn3); }

    // v1.100.12: la portada del reproductor inmersivo (di6.b), la que lleva el edge fade encima.
    private static final ArrayList<WeakReference<Object>> IMM = new ArrayList<WeakReference<Object>>();

    public static synchronized void tagImm(Object sn3) {
        try {
            if (sn3 == null) return;
            for (int i = IMM.size() - 1; i >= 0; i--) {
                if (IMM.get(i).get() == null) IMM.remove(i);
            }
            while (IMM.size() >= 64) IMM.remove(0);
            IMM.add(new WeakReference<Object>(sn3));
        } catch (Throwable ignored) {
        }
    }

    private static boolean isImm(Object sn3) {
        for (int i = IMM.size() - 1; i >= 0; i--) {
            if (IMM.get(i).get() == sn3) return true;
        }
        return false;
    }

    private static synchronized void tag(int kind, Object sn3) {
        try {
            if (sn3 == null) return;
            for (int i = TAGS.size() - 1; i >= 0; i--) {
                if (TAGS.get(i).ref.get() == null) TAGS.remove(i);
            }
            while (TAGS.size() >= MAX_TAGS) TAGS.remove(0);
            TAGS.add(new Tag(sn3, kind));
        } catch (Throwable ignored) {
        }
    }

    private static int kindOf(Object sn3) {
        if (sn3 == null) return 0;
        for (int i = TAGS.size() - 1; i >= 0; i--) {
            Tag t = TAGS.get(i);
            if (t.ref.get() == sn3) return t.kind;
        }
        return 0;
    }

    /**
     * Fondo: ultimo painter (i36) que termino de cargar, o null. Portada: un Drawable (cuadro oscuro + nota). Sitio no
     * marcado o error: null.
     */
    public static synchronized Object saved(Object sn3) {
        try {
            int k = kindOf(sn3);
            if (k != 0) diagOnce(label(k, sn3) + "S", label(k, sn3) + " MIENTRAS CARGA muestra " + (k == COVER ? "cuadro+nota" : (lastBg[k] != null ? "imagen anterior" : "nada (sin anterior)")));
            if (k == BG || k == BG2) return lastBg[k];
            if (k == COVER) return placeholder();
            if (diagActive()) diagOnce("OS" + System.identityHashCode(sn3), "OTRA imagen (sin marcar) #" + (System.identityHashCode(sn3) % 1000) + " esta cargando/vacia");
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Guarda el painter recien cargado (rama exito) solo si el sn3 es un fondo del reproductor. */
    public static synchronized void remember(Object sn3, Object painter) {
        try {
            if (painter == null) return;
            int k = kindOf(sn3);
            if (k == BG || k == BG2) lastBg[k] = painter;
        } catch (Throwable ignored) {
        }
    }

    /**
     * v1.100.0: fundido al llegar la imagen nueva del fondo. Recibe el Drawable recien cargado y, si el sn3 es un fondo
     * del reproductor, devuelve un envoltorio que dibuja la imagen ANTERIOR del mismo sitio y la NUEVA apareciendo poco
     * a poco. Si no es fondo, no hay imagen anterior o algo falla, devuelve el mismo Drawable (sin fundido).
     * El envoltorio se guarda por Drawable para que la app (que lo recuerda por identidad) no reinicie el fundido.
     */
    public static synchronized Drawable fade(Object sn3, Drawable d) {
        try {
            if (d == null) return d;
            int k = kindOf(sn3);
            if (k == COVER) return fadeCover(sn3, d);
            if (k != BG && k != BG2) {
                if (k == 0 && diagActive()) diagOnce("O" + System.identityHashCode(d), "OTRA imagen (sin marcar) #" + (System.identityHashCode(sn3) % 1000) + " llega " + d.getClass().getSimpleName() + " " + d.getIntrinsicWidth() + "x" + d.getIntrinsicHeight());
                return d;
            }
            if (lastSrc[k] == d) return lastWrapped[k] != null ? lastWrapped[k] : d;
            diag(label(k, sn3) + " LLEGA imagen " + d.getClass().getSimpleName() + " " + d.getIntrinsicWidth() + "x" + d.getIntrinsicHeight() + (lastSrc[k] == null ? " (primera)" : " (hay anterior)"));
            Drawable prev = lastSrc[k];
            lastSrc[k] = d;
            lastWrapped[k] = new FadeDrawable(prev, d, label(k, sn3), false); // prev null: aparece desde transparente
            return lastWrapped[k];
        } catch (Throwable t) {
            return d;
        }
    }

    // v1.100.1: la PORTADA tambien se funde. Lo que se ve mientras carga es el cuadro con la nota, asi que el fundido va
    // del cuadro a la portada nueva (a la vez que el del fondo). 
    // Hay dos sitios de portada (di6.b / xi6.p), por eso el envoltorio se guarda por Drawable en una lista corta.
    private static final int COVER_CACHE = 4;
    private static final Drawable[] coverSrc = new Drawable[COVER_CACHE];
    private static final Drawable[] coverWrapped = new Drawable[COVER_CACHE];
    private static int coverNext = 0;

    private static Drawable fadeCover(Object sn3, Drawable d) {
        for (int i = 0; i < COVER_CACHE; i++) {
            if (coverSrc[i] == d) return coverWrapped[i] != null ? coverWrapped[i] : d;
        }
        diag(label(COVER, sn3) + " LLEGA imagen " + d.getClass().getSimpleName() + " " + d.getIntrinsicWidth() + "x" + d.getIntrinsicHeight());
        // v1.100.13: en la portada del reproductor inmersivo el fundido se hornea en los pixeles (sin capas ni caja encima).
        Drawable target = isImm(sn3) ? new BakedFade(d) : d;
        Drawable w = new FadeDrawable(placeholder(), target, label(COVER, sn3), false);
        coverSrc[coverNext] = d;
        coverWrapped[coverNext] = w;
        coverNext = (coverNext + 1) % COVER_CACHE;
        return w;
    }

    // ---- v1.100.7 DIAGNOSTICO: anota que hace cada capa y lo copia al portapapeles 3 s despues del ultimo evento ----
    private static final StringBuilder DIAG = new StringBuilder();
    private static final java.util.HashSet<String> DIAG_SEEN = new java.util.HashSet<String>();
    private static long diagT0 = 0;
    private static final android.os.Handler DIAG_H = new android.os.Handler(android.os.Looper.getMainLooper());
    private static final Runnable DIAG_FLUSH = new Runnable() {
        @Override public void run() { diagFlush(); }
    };

    private static String label(int kind, Object sn3) {
        String n = kind == BG ? "FONDO" : kind == BG2 ? "REFLEJO" : kind == COVER ? "PORTADA" : "?";
        return n + "#" + (System.identityHashCode(sn3) % 1000);
    }

    static void diag(String msg) {
        try {
            synchronized (DIAG) {
                long now = android.os.SystemClock.uptimeMillis();
                if (diagT0 == 0) diagT0 = now;
                if (DIAG.length() < 12000) DIAG.append('+').append(now - diagT0).append("ms ").append(msg).append('\n');
            }
            DIAG_H.removeCallbacks(DIAG_FLUSH);
            DIAG_H.postDelayed(DIAG_FLUSH, 3000L);
        } catch (Throwable ignored) {
        }
    }

    private static boolean diagActive() {
        synchronized (DIAG) {
            return diagT0 != 0 && android.os.SystemClock.uptimeMillis() - diagT0 < 2500L;
        }
    }

    /** v1.100.11: true si hay una ventana de diagnostico abierta (imagenes llegando). */
    public static boolean diagOn() {
        return diagActive();
    }

    /** v1.100.10: anota una vez por ventana, y solo si el diagnostico ya esta activo (no abre ventanas nuevas). */
    public static void diagStyle(String key, String msg) {
        if (diagActive()) diagOnce(key, msg);
    }

    static void diagOnce(String key, String msg) {
        synchronized (DIAG) {
            if (!DIAG_SEEN.add(key)) return;
        }
        diag(msg);
    }

    private static void diagFlush() {
        try {
            String text;
            synchronized (DIAG) {
                text = DIAG.toString();
                DIAG.setLength(0);
                DIAG_SEEN.clear();
                diagT0 = 0;
            }
            if (text.length() == 0) return;
            android.content.Context ctx = (android.content.Context) Class.forName("android.app.ActivityThread")
                    .getMethod("currentApplication").invoke(null);
            android.content.ClipboardManager cm = (android.content.ClipboardManager)
                    ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("diag", "PrevCover v1.100.13\n" + text));
            android.widget.Toast.makeText(ctx, "Diagnostico copiado", android.widget.Toast.LENGTH_SHORT).show();
        } catch (Throwable ignored) {
        }
    }


    /**
     * v1.100.13: portada con el fundido de borde HORNEADO en una copia de la imagen (Bitmap con alfa, hecho por software).
     * Se hornea de forma perezosa en el primer dibujo (para entonces OwnFade ya recibio la configuracion) y se rehornea si
     * la configuracion cambia. Sin saveLayer ni caja encima. Si el fundido no esta activo, dibuja la imagen tal cual.
     */
    private static final class BakedFade extends Drawable {
        private final Drawable src;
        private Bitmap bmp;
        private int ver = -1;
        private int alpha = 255;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);

        BakedFade(Drawable src) { this.src = src; }

        @Override public int getIntrinsicWidth() { return src.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return src.getIntrinsicHeight(); }

        private void bake() {
            bmp = null;
            ver = OwnFade.version();
            if (!OwnFade.isActive()) return;
            try {
                int w = src.getIntrinsicWidth(), h = src.getIntrinsicHeight();
                if (w <= 0 || h <= 0) return;
                float s = Math.min(1f, 1600f / Math.max(w, h));
                int bw = Math.max(1, Math.round(w * s)), bh = Math.max(1, Math.round(h * s));
                Bitmap out = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                Canvas c = new Canvas(out);
                src.setBounds(0, 0, bw, bh);
                src.draw(c);
                OwnFade.apply(c, 0f, 0f, (float) bw, (float) bh, new OwnFade.Cache());
                bmp = out;
            } catch (Throwable t) {
                bmp = null;
            }
        }

        @Override
        public void draw(Canvas canvas) {
            try {
                if (ver != OwnFade.version()) bake();
                Rect b = getBounds();
                if (bmp != null) {
                    paint.setAlpha(alpha);
                    canvas.drawBitmap(bmp, null, b, paint);
                } else {
                    src.setBounds(b);
                    src.setAlpha(alpha);
                    src.draw(canvas);
                }
            } catch (Throwable ignored) {
            }
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static final class FadeDrawable extends Drawable {
        private Drawable from;
        private final Drawable to;
        private long start = -1;
        private boolean done = false;
        private final String label;
        private boolean logged = false;
        private boolean swLogged = false;

        private final boolean imm;
        private final OwnFade.Cache fadeCache = new OwnFade.Cache();

        FadeDrawable(Drawable from, Drawable to, String label, boolean imm) { this.from = from; this.to = to; this.label = label; this.imm = imm; }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            // v1.100.12: portada del reproductor inmersivo con el fundido de borde horneado (sin la caja aparte de Eclipse).
            if (imm && OwnFade.isActive() && canvas.isHardwareAccelerated()) {
                int sc = -1;
                try {
                    Rect b = getBounds();
                    sc = canvas.saveLayer((float) b.left, (float) b.top, (float) b.right, (float) b.bottom, null);
                    drawContent(canvas);
                    OwnFade.apply(canvas, b.left, b.top, b.right, b.bottom, fadeCache);
                } catch (Throwable ignored) {
                } finally {
                    if (sc >= 0) canvas.restoreToCount(sc);
                }
                return;
            }
            drawContent(canvas);
        }

        private void drawContent(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                if (!logged) {
                    logged = true;
                    diag(label + " DIBUJA bounds=" + b.flattenToString() + " clip=" + canvas.getClipBounds()
                            + " lienzo=" + canvas.getWidth() + "x" + canvas.getHeight() + " hw=" + canvas.isHardwareAccelerated()
                            + " de=" + (from == null ? "nada" : from.getClass().getSimpleName())
                            + " a=" + to.getClass().getSimpleName() + " " + to.getIntrinsicWidth() + "x" + to.getIntrinsicHeight());
                }
                if (!canvas.isHardwareAccelerated() && !swLogged) {
                    swLogged = true;
                    diag(label + " SOFTWARE (sin fundido) lienzo=" + canvas.getWidth() + "x" + canvas.getHeight());
                }
                // La app tambien dibuja el Drawable en un Bitmap (canvas por software) para otras cosas: ahi no hay
                // fundido ni se arranca el reloj. El dibujo real de Compose usa canvas con aceleracion por hardware.
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                long now = android.os.SystemClock.uptimeMillis();
                if (start < 0) { start = now; diag(label + " INICIA fundido"); }
                float t = (now - start) / (float) FADE_MS;
                if (t >= 1f) { diag(label + " FIN fundido"); done = true; from = null; to.draw(canvas); return; }
                if (from != null) { from.setBounds(b); from.draw(canvas); }
                to.setAlpha((int) (255 * t));
                to.draw(canvas);
                to.setAlpha(255);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * Cuadro negro ~55% con esquinas suaves y una nota doble blanca ~63% al centro (referencia: Bitchord).
     * Es un Drawable propio que se dibuja segun el tamano REAL del area: la app lo estira a todo el area de la portada
     * (que no es cuadrada), asi que la nota se dibuja siempre con proporcion cuadrada y centrada, sin deformarse.
     */
    private static Drawable placeholder() {
        if (placeholder == null) placeholder = new NoteBox();
        return placeholder;
    }

    private static final class NoteBox extends Drawable {
        private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint notePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF boxRect = new RectF();
        private final RectF dst = new RectF();
        private Bitmap note;
        private int alpha = 255;
        private float shaderH = -1f;

        NoteBox() {
            boxPaint.setStyle(Paint.Style.FILL);
            boxPaint.setColor(0xFF000000);
            notePaint.setAlpha(160);       // blanco ~63%
        }

        @Override public int getIntrinsicWidth() { return 800; }
        @Override public int getIntrinsicHeight() { return 800; }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                float w = b.width(), h = b.height();
                if (w <= 0 || h <= 0) return;
                float m = Math.min(w, h);
                boxPaint.setAlpha(alpha);
                notePaint.setAlpha((int) (160 * (alpha / 255f)));
                // Negro ~55% que se difumina hacia abajo (desde ~55% del alto hasta 0 en el borde).
                if (shaderH != h) {
                    boxPaint.setShader(new LinearGradient(0f, 0f, 0f, h,
                            new int[] {0x8C000000, 0x8C000000, 0x00000000},
                            new float[] {0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
                    shaderH = h;
                }
                boxPaint.setAlpha(alpha);
                canvas.save();
                canvas.translate(b.left, b.top);
                canvas.drawRect(0f, 0f, w, h, boxPaint);
                canvas.restore();
                if (note == null) note = makeNote();
                float side = m * 0.17f; // la nota ocupa ~17% del lado corto
                float cx = b.left + w / 2f, cy = b.top + h / 2f;
                dst.set(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f);
                canvas.drawBitmap(note, null, dst, notePaint);
            } catch (Throwable ignored) {
            }
        }

        @Override public void setAlpha(int a) { alpha = a; }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Nota doble en blanco OPACO sobre un lienzo cuadrado (se pega luego con transparencia: sin zonas mas claras). */
    private static Bitmap makeNote() {
        final int n = 256;
        Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas nc = new Canvas(bmp);
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setStyle(Paint.Style.FILL);
        q.setColor(0xFFFFFFFF);
        float w = n * 0.90f;                    // ancho total de la nota dentro del lienzo
        float x0 = (n - w) / 2f, y0 = (n - w * 0.97f) / 2f;
        float rx = w * 0.17f, ry = w * 0.13f;   // cabezas
        float lx = x0 + rx, ly = y0 + w * 0.84f;
        float rcx = x0 + w - rx * 0.86f, rcy = y0 + w * 0.72f;
        float sw = w * 0.085f;                  // grosor de los palitos
        float lTop = y0 + w * 0.12f, rTop = y0;
        float bt = w * 0.17f;                   // grosor de la barra
        // Los palitos nacen DENTRO de las cabezas (borde derecho algo hacia adentro) y suben solo hasta la mitad de la
        // barra: asi no sobresalen escalones ni esquinas planas.
        float lSr = lx + rx * 0.86f, rSr = rcx + rx * 0.86f;
        nc.save();
        nc.rotate(-20f, lx, ly);
        nc.drawOval(new RectF(lx - rx, ly - ry, lx + rx, ly + ry), q);
        nc.restore();
        nc.save();
        nc.rotate(-20f, rcx, rcy);
        nc.drawOval(new RectF(rcx - rx, rcy - ry, rcx + rx, rcy + ry), q);
        nc.restore();
        nc.drawRect(new RectF(lSr - sw, lTop + bt * 0.5f, lSr, ly - ry * 0.1f), q);
        nc.drawRect(new RectF(rSr - sw, rTop + bt * 0.5f, rSr, rcy - ry * 0.1f), q);
        Path beam = new Path();
        beam.moveTo(lSr - sw, lTop);
        beam.lineTo(rSr, rTop);
        beam.lineTo(rSr, rTop + bt);
        beam.lineTo(lSr - sw, lTop + bt);
        beam.close();
        nc.drawPath(beam, q);
        return bmp;
    }
}
