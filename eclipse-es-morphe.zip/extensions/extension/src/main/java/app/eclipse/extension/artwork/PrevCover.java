package app.eclipse.extension.artwork;

import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * v0.20.44 (SIN COMPILAR / SIN PROBAR): ya NO "mantiene la imagen anterior" con fundido ni nota. Lo unico que queda es lo
 * necesario para el DESLIZAMIENTO al cambiar de cancion: la portada nitida y su reflejo se mueven JUNTOS como un bloque
 * (un solo reloj, un solo momento de arranque): la imagen vieja sale hacia un lado y la nueva entra pegada.
 *
 * Eclipse dibuja portadas/fondos con un componente compartido (by9.c -> Coil SubcomposeAsyncImage; contenido = lambda
 * w71.k, caso q=1). Como se usa en TODA la app, solo se toca el del reproductor: el parche marca con {@link #tagBg} /
 * {@link #tagCover} el objeto de parametros (sn3) que construye cada sitio del reproductor. La lambda consulta
 * {@link #saved} (que dibujar mientras carga la imagen nueva), {@link #fade} (envoltorio de la imagen nueva) y
 * {@link #remember}.
 *
 * Sitios: BG = fondo borroso original de Eclipse y BG4 = relleno chiquito (sin cambios: los maneja Eclipse tal cual);
 * COVER = portada nitida; BG2 = reflejo de Eclipse; BG3 = reflejo propio (BlurredCanvasBackground.drawCover).
 */
@SuppressWarnings("unused")
public final class PrevCover {
    private static final int BG = 1;
    private static final int COVER = 2;
    private static final int BG2 = 3;     // reflejo de Eclipse (xi6.e)
    private static final int BG3 = 4;     // reflejo PROPIO (BlurredCanvasBackground.drawCover)
    private static final int BG4 = 5;     // relleno chiquito PROPIO (BlurredCanvasBackground.drawFillCover)
    private static final int MAX_TAGS = 256;

    private static final class Tag {
        final WeakReference<Object> ref;
        final int kind;
        Tag(Object o, int kind) { this.ref = new WeakReference<Object>(o); this.kind = kind; }
    }

    private static final ArrayList<Tag> TAGS = new ArrayList<Tag>();
    private static final Object[] lastBg = new Object[6];          // painter guardado (solo reflejos BG2 / BG3)
    private static final Drawable[] lastSrc = new Drawable[6];     // ultimo Drawable cargado por sitio
    private static final Drawable[] lastWrapped = new Drawable[6]; // su envoltorio con deslizamiento
    // v0.20.47: de que cancion es lo guardado arriba (lastBg / lastSrc). Si no es la anterior ni la actual, esta viejo
    // (por ejemplo de dos canciones atras) y NO se usa como "reflejo que sale": se veia el reflejo ajeno al deslizar.
    private static final Object[] bgSong = new Object[6];
    private static final Object[] srcSong = new Object[6];
    private static volatile Object prevSong;   // v0.20.47: la cancion que sonaba justo antes de curSong

    private static boolean sameSong(Object a, Object b) {
        return a != null && b != null && (a == b || a.equals(b));
    }

    /** v0.20.47: lo guardado de la cancion `owner` sirve de reflejo viejo solo si es de la anterior o de la actual. */
    private static boolean freshFor(Object owner) {
        return sameSong(owner, prevSong) || sameSong(owner, curSong);
    }

    public static void tagBg(Object sn3) { tag(BG, sn3); }

    public static void tagBg2(Object sn3) { tag(BG2, sn3); }

    private static volatile Object ownReq;

    /** El sn3 que usa nuestro reflejo (un solo objeto, se guarda aparte para que la lista de marcas no lo borre). */
    public static void tagBg3(Object sn3) { ownReq = sn3; }

    private static volatile Object ownReq2;

    /** El sn3 del relleno chiquito del fondo. */
    public static void tagBg4(Object sn3) { ownReq2 = sn3; }

    private static volatile Object holeReq;

    /** v0.20.145: el sn3 del reflejo del HUECO del Canvas (BlurredCanvasBackground.drawHoleCover). Cuenta como BG3. */
    public static void tagHole(Object sn3) { holeReq = sn3; }

    public static void tagCover(Object sn3) { tag(COVER, sn3); }

    private static synchronized void tag(int kind, Object sn3) {
        try {
            if (sn3 == null) return;
            for (int i = TAGS.size() - 1; i >= 0; i--) {
                if (TAGS.get(i).ref.get() == null) TAGS.remove(i);
            }
            while (TAGS.size() >= MAX_TAGS) TAGS.remove(0);
            TAGS.add(new Tag(sn3, kind));
        } catch (Throwable ignored) {
        }
    }

    private static int kindOf(Object sn3) {
        if (sn3 == null) return 0;
        if (sn3 == ownReq || (sn3 == holeReq && holeReq != null)) return BG3;
        if (sn3 == ownReq2) return BG4;
        for (int i = TAGS.size() - 1; i >= 0; i--) {
            Tag t = TAGS.get(i);
            if (t.ref.get() == sn3) return t.kind;
        }
        return 0;
    }

    // ---- v0.20.145: guardia contra la portada ANTERIOR al volver de Letra (casilla del parche; sin casilla no hace nada) ----
    private static volatile boolean guardOn;
    private static volatile int offEvt = -1;   // v0.20.146: numero de cambio de cancion que ocurrio con la pestana NO en "artwork"

    /** Gancho (smali) del parche "Reflejo: no usar la portada anterior al volver de Letra". */
    public static void enableStaleGuard() { guardOn = true; }

    /**
     * v0.20.146: true si el cambio de cancion actual ocurrio con la pestana en Letra o Cola (no en Artwork). Una sola senal
     * (la pestana al momento del cambio) apaga TODOS los caminos que dibujan la portada anterior: reflejo, hueco y CoverDrawable.
     */
    private static boolean stale() {
        return guardOn && songEvt != 0 && offEvt == songEvt;
    }

    public static boolean isStale() {
        try { return stale(); } catch (Throwable t) { return false; }
    }

    /** La portada ya cargada (Coil) de LA CANCION ACTUAL, o null si aun no es de esta cancion. */
    public static Drawable currentCover() {
        Drawable kc = keptCover;
        return (kc != null && sameSong(keptSong, curSong)) ? kc : null;
    }

    /**
     * Que dibujar mientras carga la imagen nueva. Portada: la portada anterior (queda quieta hasta que llega la nueva y
     * entonces sale deslizando) o un cuadro vacio la primera vez. Reflejos: su ultimo painter. Todo lo demas (fondo
     * borroso, relleno) o error: null = Eclipse hace lo de siempre.
     */
    public static synchronized Object saved(Object sn3) {
        try {
            int k = kindOf(sn3);
            // v0.20.153: REFLEJOS (BG2 de Eclipse, BG3 propio y hueco del Canvas, BG4 relleno): NUNCA lo de la cancion
            // anterior, ni su painter ni su portada. Solo lo ya cargado de LA CANCION ACTUAL; si no hay, el hueco del Canvas
            // usa la portada ya bajada de la actual, y si tampoco, nada (Eclipse no dibuja nada hasta que llegue la nueva).
            if (k == BG2 || k == BG3 || k == BG4) {
                Object p = sameSong(bgSong[k], curSong) ? lastBg[k] : null;
                if (p != null) return p;
                if (sn3 != null && sn3 == holeReq) {
                    Drawable cur = currentCover();
                    if (cur != null) return cur;
                    Drawable cb = CoverUnderlay.currentBitmapDrawable();
                    if (cb != null) return cb;
                }
                return null;
            }
            if (k == BG) {
                Object p = (stale() ? sameSong(bgSong[k], curSong) : freshFor(bgSong[k])) ? lastBg[k] : null; // v0.20.47/48 (146: fuera de Artwork solo la misma cancion)
                if (p != null) return p;
                // v0.20.50: mientras carga la imagen nueva y no hay desenfoque viejo guardado, dibujar la portada vieja como desenfoque.
                if (slideWanted()) {
                    Drawable pk = sameSong(keptSong, curSong) ? prevKept : keptCover;
                    if (pk != null) return pk;
                }
                return null;
            }
            if (k == COVER) {
                Drawable kc = keptCover;
                return kc != null ? kc : blank();
            }
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Guarda el painter recien cargado (rama exito) solo para los reflejos. */
    public static synchronized void remember(Object sn3, Object painter) {
        try {
            if (painter == null) return;
            int k = kindOf(sn3);
            if (k == BG2 || k == BG3 || k == BG || k == BG4) { lastBg[k] = painter; bgSong[k] = curSong; } // v0.20.47/48
        } catch (Throwable ignored) {
        }
    }

    /**
     * Recibe el Drawable recien cargado. Portada -> fadeCover. Reflejo -> si hay un cambio de cancion reciente, un
     * SlideDrawable (la imagen anterior sale, la nueva entra); si no, el mismo Drawable. Otros sitios: el mismo Drawable.
     */
    public static synchronized Drawable fade(Object sn3, Drawable d) {
        try {
            if (d == null) return d;
            int k = kindOf(sn3);
            if (k == COVER) return fadeCover(d);
            if (sn3 != null && sn3 == holeReq && stale()) { // v0.20.145: sin fundido desde la portada anterior
                lastSrc[BG3] = d;
                srcSong[BG3] = curSong;
                lastWrapped[BG3] = null;
                return d;
            }
            if (k == BG2 || k == BG3 || k == BG4) { // v0.20.153: sin imagen anterior; no se dibuja hasta que arranca el cambio de la portada
                if (lastSrc[k] == d) return lastWrapped[k] != null ? lastWrapped[k] : d;
                lastSrc[k] = d;
                srcSong[k] = curSong;
                if (slideWanted()) {
                    arrive(songEvt, k == BG4 ? 0 : BIT_REFL);
                    lastWrapped[k] = new RevealDrawable(d, songEvt);
                    return lastWrapped[k];
                }
                lastWrapped[k] = null;
                return d;
            }
            boolean still = (k == BG || k == BG4); // v0.20.48: fondo de toda la pantalla: no se mueve, cambia a la vez que el deslizamiento
            if (k != BG2 && k != BG3 && !still) return d;
            if (lastSrc[k] == d) return lastWrapped[k] != null ? lastWrapped[k] : d;
            Drawable prev = lastSrc[k];
            if (prev != null && !freshFor(srcSong[k])) prev = null; // v0.20.47: reflejo de una cancion vieja: no se desliza
            // v0.20.49: si la cancion anterior tenia Canvas (nunca guardo su propio desenfoque), el "desenfoque que sale"
            // es su portada (la que vuelve cuando se va el video). Asi cada una sale/entra con su propio desenfoque.
            if (prev == null && slideWanted()) {
                Drawable pk = sameSong(keptSong, curSong) ? prevKept : keptCover;
                if (pk != null && pk != d) prev = pk;
            }
            lastSrc[k] = d;
            srcSong[k] = curSong;
            if (prev != null && slideWanted() && slideUsed[k] != songEvt) {
                slideUsed[k] = songEvt;
                arrive(songEvt, still ? 0 : BIT_REFL);
                lastWrapped[k] = still ? new HoldFadeDrawable(prev, d, songEvt) : new SlideDrawable(prev, d, songDir, songEvt, 0.12f);
                return lastWrapped[k];
            }
            lastWrapped[k] = null;
            return d;
        } catch (Throwable t) {
            return d;
        }
    }

    // ---- estado de la cancion ----
    private static volatile Object curSong;
    private static volatile Object lastCoverSong;
    private static volatile Drawable keptCover;  // la imagen MAS GRANDE de la cancion actual
    private static volatile int keptW;
    private static volatile Object keptSong;
    private static volatile Drawable prevKept;   // portada de la cancion anterior (para deslizar)
    private static volatile Object slideSong;
    private static volatile long slideFirstAt;

    // ---- deslizamiento ----
    private static final long SLIDE_MS = 380;    // duracion del deslizamiento (se ajusta aqui)
    /** v0.20.52: el cambio de cancion se hace con FUNDIDO (sin movimiento). false = vuelve al deslizamiento. */
    public static final boolean FADE_MODE = true;
    private static final long GATE_MS = 600;     // espera maxima a que lleguen portada y reflejo antes de arrancar
    private static final int BIT_COVER = 1;
    private static final int BIT_REFL = 2;
    private static volatile int expectMask = 1;  // que piezas se esperan (1 = portada; 3 = portada + reflejo)
    private static volatile int skipDir = 0;     // +1 siguiente (la vieja sale a la izquierda), -1 anterior
    private static volatile long skipAt = 0;
    private static volatile int songEvt = 0;     // contador de cambios de cancion
    private static volatile long songEvtAt = 0;
    private static volatile int songDir = 1;
    private static final int[] slideUsed = new int[6];
    private static int gateEvt = -1;
    private static int gateMask = 0;
    private static long gateFirstAt = 0;
    private static long gateStart = 0;
    private static java.lang.reflect.Field layerKindField;
    private static boolean layerKindTried;

    /** Hay un cambio de cancion reciente que debe deslizar. */
    private static boolean slideWanted() {
        if (stale()) return false; // v0.20.146: cambio hecho fuera de Artwork: nada de la anterior
        return songEvt != 0 && android.os.SystemClock.uptimeMillis() - songEvtAt < 6000;
    }

    /** Lo llama BlurredCanvasBackground.draw: true si en esta pantalla hay reflejo de imagen (sin Canvas). */
    public static void setExpectRefl(boolean r) { expectMask = r ? 3 : 1; }

    private static synchronized void arrive(int evt, int bit) {
        if (gateEvt != evt) {
            gateEvt = evt;
            gateMask = 0;
            gateFirstAt = android.os.SystemClock.uptimeMillis();
            gateStart = 0;
        }
        gateMask |= bit;
    }

    /** Hora de arranque del deslizamiento de este cambio (0 = todavia no arranca). Portada y reflejo comparten este reloj. */
    private static synchronized long startOf(int evt) {
        if (gateEvt != evt) return 1L; // evento viejo o desconocido: ya termino
        if (gateStart != 0) return gateStart;
        long now = android.os.SystemClock.uptimeMillis();
        if ((gateMask & expectMask) == expectMask || now - gateFirstAt > GATE_MS) gateStart = now;
        return gateStart;
    }

    /**
     * Gancho al inicio de kj6.s(lb4, dw0) (ejecuta la accion de un boton/gesto). Solo guarda la DIRECCION (NEXT=+1,
     * PREVIOUS=-1); el deslizamiento arranca cuando cambia la cancion (setState).
     */
    public static void onSkip(Object action, Object layer) {
        try {
            if (!(action instanceof Enum)) return;
            String n = ((Enum<?>) action).name();
            int dir = "NEXT".equals(n) ? 1 : ("PREVIOUS".equals(n) ? -1 : 0);
            if (dir == 0) return;
            skipDir = dir;
            skipAt = android.os.SystemClock.uptimeMillis();
        } catch (Throwable ignored) {
        }
    }

    // ---- arrastre con el dedo (v0.20.45) ----
    private static volatile Object dragState;   // y46 (MutableFloatState con los pixeles arrastrados)
    private static java.lang.reflect.Method dragGet;
    private static boolean dragTried;
    private static volatile float lastDragPx;
    private static volatile long lastDragAt;
    private static volatile float songFrac;     // fraccion de pantalla ya recorrida al soltar (para seguir desde ahi)

    /** Gancho al inicio de di6.q: guarda el estado del arrastre. */
    public static void setDrag(Object st) { dragState = st; }

    /**
     * Pixeles arrastrados ahora (negativo = hacia la izquierda = Siguiente; positivo = Anterior). Leerlo dentro de la
     * composicion hace que se vuelva a dibujar con cada movimiento del dedo. 0 si no se sabe.
     */
    public static float dragPx() {
        try {
            Object st = dragState;
            if (st == null) return 0f;
            if (!dragTried) {
                dragTried = true;
                java.lang.reflect.Method m = st.getClass().getDeclaredMethod("g");
                m.setAccessible(true);
                dragGet = m;
            }
            if (dragGet == null) return 0f;
            Object r = dragGet.invoke(st);
            float v = (r instanceof Float) ? ((Float) r).floatValue() : 0f;
            if (v != 0f) {
                lastDragPx = v;
                lastDragAt = android.os.SystemClock.uptimeMillis();
            }
            return v;
        } catch (Throwable t) {
            return 0f;
        }
    }

    private static float fracAfterDrag(long now, int dir) {
        try {
            float p = lastDragPx;
            if (now - lastDragAt > 1200L || p == 0f) return 0f;
            if (!((p < 0f && dir > 0) || (p > 0f && dir < 0))) return 0f;
            int sw = android.content.res.Resources.getSystem().getDisplayMetrics().widthPixels;
            if (sw <= 0) return 0f;
            float f = Math.abs(p) / sw;
            return f > 0.2f ? Math.min(f, 0.95f) : 0f;
        } catch (Throwable t) {
            return 0f;
        }
    }

    // ---- cancion vecina (v0.20.45): la misma que usaria Eclipse con Siguiente / Anterior ----
    private static java.lang.reflect.Field qInstField;
    private static java.lang.reflect.Method qNext, qPrev;
    private static java.lang.reflect.Field qListField;
    private static boolean qTried;

    private static Object callNoArg(Object o, String name) throws Exception {
        Class<?> c = o.getClass();
        while (c != null) {
            try {
                java.lang.reflect.Method m = c.getDeclaredMethod(name);
                m.setAccessible(true);
                return m.invoke(o);
            } catch (NoSuchMethodException e) {
                c = c.getSuperclass();
            }
        }
        return null;
    }

    /** dir > 0: la cancion que sigue; dir < 0: la anterior. null si no se sabe o es la misma que suena. */
    public static Object neighbor(int dir) {
        try {
            if (!qTried) {
                qTried = true;
                Class<?> c = Class.forName("yz6");
                qInstField = c.getDeclaredField("y");
                qInstField.setAccessible(true);
                qNext = c.getDeclaredMethod("x");
                qNext.setAccessible(true);
                qPrev = c.getDeclaredMethod("n");
                qPrev.setAccessible(true);
                qListField = c.getDeclaredField("b");
                qListField.setAccessible(true);
            }
            if (qInstField == null) return null;
            Object q = qInstField.get(null);
            if (q == null) return null;
            Object song;
            if (dir > 0) {
                song = qNext.invoke(q);
            } else {
                Object idx = qPrev.invoke(q);
                if (!(idx instanceof Integer)) return null;
                Object flow = qListField.get(q);
                if (flow == null) return null;
                Object list = callNoArg(flow, "getValue");
                if (!(list instanceof java.util.List)) return null;
                java.util.List<?> l = (java.util.List<?>) list;
                int i = ((Integer) idx).intValue();
                song = (i >= 0 && i < l.size()) ? l.get(i) : null;
            }
            Object cur = curSong;
            if (song == null || (cur != null && cur.equals(song))) return null;
            return song;
        } catch (Throwable t) {
            qInstField = null; // no reintentar si algo no coincide
            return null;
        }
    }

    // ---- API para la portada que espera al Canvas (v0.20.46) ----
    /** Numero del cambio de cancion actual (0 = ninguno). */
    public static int curEvt() { return songEvt; }

    /** Hay un cambio de cancion reciente que debe deslizar. */
    public static boolean wantsSlide() { return slideWanted(); }

    public static int slideDir() { return songDir; }

    /**
     * Progreso (0..1) del deslizamiento del cambio evt, con el MISMO reloj que la portada normal. -1 = no hay (dibujar
     * solo la nueva): evento viejo, ya termino o algo falla. newReady avisa que la portada nueva ya esta lista.
     */
    public static synchronized float slideProgress(int evt, boolean newReady) {
        try {
            if (evt == 0 || songEvt != evt || !slideWanted()) return -1f;
            arrive(evt, newReady ? BIT_COVER : 0);
            long st = startOf(evt);
            float e0 = songFrac;
            if (st == 0) return e0;
            long now = android.os.SystemClock.uptimeMillis();
            float t = (now - st) / (float) SLIDE_MS;
            if (t >= 1f) return -1f;
            float inv = 1f - t;
            return e0 + (1f - e0) * (1f - inv * inv * inv);
        } catch (Throwable t) {
            return -1f;
        }
    }

    private static java.lang.reflect.Field songField;
    private static boolean songFieldTried;

    public static void setState(Object st) {
        try {
            if (st == null) return;
            if (!songFieldTried) {
                songFieldTried = true;
                try {
                    songField = st.getClass().getDeclaredField("a");
                    songField.setAccessible(true);
                } catch (Throwable t) {
                    songField = null;
                }
            }
            if (songField != null) {
                Object ns = songField.get(st);
                Object os = curSong;
                curSong = ns;
                // Cambio de cancion (no la primera) -> evento de deslizamiento. Direccion: la del ultimo Siguiente/Anterior
                // si fue hace poco; si no (cambia sola, arrastre sin boton), siguiente.
                if (os != null && ns != null && !os.equals(ns)) {
                    prevSong = os; // v0.20.47
                    long now = android.os.SystemClock.uptimeMillis();
                    songDir = (skipDir != 0 && now - skipAt < 2500) ? skipDir : 1;
                    songEvt = songEvt + 1;
                    songEvtAt = now;
                    try { // v0.20.146: ¿la pestana era Artwork al cambiar?
                        offEvt = app.eclipse.extension.canvas.BlurredCanvasBackground.notArtwork() ? songEvt : -1;
                    } catch (Throwable t) { offEvt = -1; }
                    songFrac = fracAfterDrag(now, songDir); // v0.20.45
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean songChanged() {
        Object c = curSong, l = lastCoverSong;
        if (c == null || l == null) return true;
        return !c.equals(l);
    }

    private static final int COVER_CACHE = 4;
    private static final Drawable[] coverSrc = new Drawable[COVER_CACHE];
    private static final Drawable[] coverWrapped = new Drawable[COVER_CACHE];
    private static int coverNext = 0;

    // v0.20.54: cuenta cada vez que llega una portada (imagen lista) al sitio de la portada nitida; PlayerEnter la usa
    // para esperar la portada antes de subir el reproductor.
    private static volatile long coverTick;
    private static volatile long coverTickAt;
    public static long coverTick() { return coverTick; }
    public static long coverTickAt() { return coverTickAt; }

    private static Drawable fadeCover(Drawable d) {
        coverTick++;
        coverTickAt = android.os.SystemClock.uptimeMillis();
        for (int i = 0; i < COVER_CACHE; i++) {
            if (coverSrc[i] == d) return coverWrapped[i] != null ? coverWrapped[i] : d;
        }
        long now = android.os.SystemClock.uptimeMillis();
        boolean newSong = songChanged();
        Object cs = curSong;
        int wd = d.getIntrinsicWidth();
        Drawable oldCover = null;
        if (newSong) {
            prevKept = (cs != null) ? keptCover : null;
            keptCover = d;
            keptW = wd;
            keptSong = cs;
            if (cs != null && prevKept != null && slideWanted()) {
                slideSong = cs;
                slideFirstAt = now;
                oldCover = prevKept;
            }
        } else {
            if (keptCover == null || wd >= keptW) { keptCover = d; keptW = wd; keptSong = cs; }
            if (cs != null && slideSong != null && slideSong.equals(cs) && prevKept != null && slideWanted()
                    && now - slideFirstAt < 1500) {
                oldCover = prevKept;
            }
        }
        lastCoverSong = curSong;
        // BestOf (calidad): si la caja es mas grande que esta imagen, dibuja la mas grande de la cancion.
        Drawable under = new BestOf(d, cs);
        Drawable w;
        if (oldCover != null && oldCover != d) {
            arrive(songEvt, BIT_COVER);
            w = new SlideDrawable(oldCover, under, songDir, songEvt, 0f); // la vieja sale, la nueva entra
        } else {
            w = under;
        }
        coverSrc[coverNext] = d;
        coverWrapped[coverNext] = w;
        coverNext = (coverNext + 1) % COVER_CACHE;
        return w;
    }

    /**
     * La imagen vieja sale hacia un lado y la nueva entra pegada (sin hueco). Se mueve por una "costura" que va de un
     * borde de la pantalla al otro: a un lado de la costura se dibuja la vieja y al otro la nueva, ambas desplazadas la
     * misma distancia (el ancho de la pantalla). Asi la portada (caja = pantalla) y el reflejo (caja mas ancha que la
     * pantalla) avanzan igual, y el reflejo no deja huecos fuera de la pantalla (el desenfoque no ve bordes vacios).
     * El reloj es compartido por cambio de cancion y arranca cuando llegaron portada y reflejo (o a los 600 ms).
     * Mientras espera dibuja la vieja quieta. Si algo falla, dibuja la nueva sin mas.
     */
    private static final class SlideDrawable extends Drawable {
        private final Drawable from;
        private final Drawable to;
        private final int dir;
        private final int evt;
        private final float e0;   // v0.20.45: fraccion ya recorrida con el dedo al soltar (0 = parte del centro)
        private boolean done = false;

        private final float mfrac; // v0.20.51: margen de la costura (fraccion del ancho de pantalla); 0 = portada nitida

        SlideDrawable(Drawable from, Drawable to, int dir, int evt, float mfrac) {
            this.from = from; this.to = to; this.dir = dir; this.evt = evt; this.mfrac = mfrac;
            this.e0 = FADE_MODE ? 0f : songFrac;
        }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                from.setBounds(b);
                long st = startOf(evt);
                float e;
                if (st == 0) { // todavia no arranca
                    if (e0 <= 0f) { // la vieja queda quieta
                        from.draw(canvas);
                        invalidateSelf();
                        return;
                    }
                    e = e0;     // v0.20.45: queda donde la dejo el dedo
                } else {
                    long now = android.os.SystemClock.uptimeMillis();
                    float t = (now - st) / (float) SLIDE_MS;
                    if (t >= 1f) { done = true; to.draw(canvas); return; }
                    float inv = 1f - t;
                    e = e0 + (1f - e0) * (1f - inv * inv * inv); // sale rapido y frena al final
                }
                if (FADE_MODE) { // v0.20.52: fundido: la vieja queda y la nueva entra encima
                    float tf = (android.os.SystemClock.uptimeMillis() - st) / (float) SLIDE_MS;
                    float inv2 = 1f - Math.min(1f, Math.max(0f, tf));
                    float ef = 1f - inv2 * inv2 * inv2;
                    from.draw(canvas);
                    int svf = canvas.saveLayerAlpha(b.left - 4f * b.width(), b.top, b.right + 4f * b.width(), b.bottom, (int) (255f * ef));
                    to.draw(canvas);
                    canvas.restoreToCount(svf);
                    invalidateSelf();
                    return;
                }
                int sw = 0;
                try {
                    sw = android.content.res.Resources.getSystem().getDisplayMetrics().widthPixels;
                } catch (Throwable ignored) { }
                float dist = (sw > 0) ? (float) sw : (float) b.width();
                float cx = (b.left + b.right) / 2f;
                // v0.20.51: en el reflejo (con blur) la costura empieza un margen FUERA de la pantalla y termina un margen fuera del otro
                // lado, para que el desenfoque de la imagen que sale no se vea como una franja en el borde (la mezcla del blur
                // queda fuera de la pantalla). Las imagenes se mueven igual que la portada; solo cambia donde se corta.
                float seam = cx + dir * (dist / 2f - e * dist + mfrac * dist * (1f - 2f * e));
                float lo = b.left - 4f * dist, hi = b.right + 4f * dist;
                int sv = canvas.save();
                if (dir > 0) canvas.clipRect(lo, b.top, seam, b.bottom); else canvas.clipRect(seam, b.top, hi, b.bottom);
                canvas.translate(-dir * e * dist, 0f);
                from.draw(canvas);
                canvas.restoreToCount(sv);
                sv = canvas.save();
                if (dir > 0) canvas.clipRect(seam, b.top, hi, b.bottom); else canvas.clipRect(lo, b.top, seam, b.bottom);
                canvas.translate(dir * (1f - e) * dist, 0f);
                to.draw(canvas);
                canvas.restoreToCount(sv);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * v0.20.153: reflejo de la cancion NUEVA sin imagen anterior. No dibuja nada hasta que arranca el cambio de este evento
     * (mismo reloj que la portada: startOf) y entonces aparece con fundido de la misma duracion. Despues dibuja la imagen sin mas.
     * Si algo falla o no hay aceleracion por hardware, dibuja la nueva sin mas.
     */
    private static final class RevealDrawable extends Drawable {
        private final Drawable to;
        private final int evt;
        private boolean done = false;

        RevealDrawable(Drawable to, int evt) { this.to = to; this.evt = evt; }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                long st = startOf(evt);
                if (st == 0) { // todavia no arranca: no se ve nada del reflejo
                    invalidateSelf();
                    return;
                }
                float t = (android.os.SystemClock.uptimeMillis() - st) / (float) SLIDE_MS;
                if (t >= 1f) { done = true; to.draw(canvas); return; }
                float inv = 1f - Math.max(0f, t);
                float e = 1f - inv * inv * inv;
                int sv = canvas.saveLayerAlpha(b.left, b.top, b.right, b.bottom, (int) (255f * e));
                to.draw(canvas);
                canvas.restoreToCount(sv);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * v0.20.48: para el desenfoque de TODA la pantalla (no se mueve): se queda con la imagen vieja hasta que arranca el
     * deslizamiento (mismo reloj que portada y reflejo) y entonces pasa a la nueva con un fundido de la misma duracion.
     * Si algo falla, dibuja la nueva sin mas.
     */
    private static final class HoldFadeDrawable extends Drawable {
        private final Drawable from;
        private final Drawable to;
        private final int evt;
        private boolean done = false;

        HoldFadeDrawable(Drawable from, Drawable to, int evt) { this.from = from; this.to = to; this.evt = evt; }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                from.setBounds(b);
                long st = startOf(evt);
                if (st == 0) { // todavia no arranca: la vieja queda quieta
                    from.draw(canvas);
                    invalidateSelf();
                    return;
                }
                float t = (android.os.SystemClock.uptimeMillis() - st) / (float) SLIDE_MS;
                if (t >= 1f) { done = true; to.draw(canvas); return; }
                float inv = 1f - t;
                float e = 1f - inv * inv * inv;
                from.draw(canvas);
                int sv = canvas.saveLayerAlpha(b.left, b.top, b.right, b.bottom, (int) (255f * e));
                to.draw(canvas);
                canvas.restoreToCount(sv);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static Drawable blankDrawable;

    private static Drawable blank() {
        if (blankDrawable == null) blankDrawable = new Blank();
        return blankDrawable;
    }

    /** Portada vacia (transparente) para la primera carga: sin nota ni cuadro. */
    private static final class Blank extends Drawable {
        @Override public int getIntrinsicWidth() { return 800; }
        @Override public int getIntrinsicHeight() { return 800; }
        @Override public void draw(Canvas canvas) { }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSPARENT; }
    }

    /**
     * Calidad: mientras la portada grande vuelve a su tamano (Letra -> Artwork) Eclipse pide imagenes de tamanos
     * intermedios y se podia ver una chiquita estirada. Al dibujar, si la caja es bastante mas grande que esta imagen y hay
     * una mas grande de la MISMA cancion, se dibuja esa.
     */
    private static final class BestOf extends Drawable {
        private final Drawable d;
        private final Object song;
        private int alpha = 255;

        BestOf(Drawable d, Object song) { this.d = d; this.song = song; }

        @Override public int getIntrinsicWidth() { return d.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return d.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                Drawable use = d;
                Drawable k = keptCover;
                if (k != null && k != d) {
                    Object ks = keptSong;
                    boolean sameSong = (song == null && ks == null) || (song != null && song.equals(ks));
                    int dw = d.getIntrinsicWidth(), kw = k.getIntrinsicWidth();
                    if (sameSong && dw > 0 && kw > dw && b.width() > dw * 1.15f) use = k;
                }
                use.setBounds(b);
                use.setAlpha(alpha);
                use.draw(canvas);
            } catch (Throwable ignored) {
                try { d.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }
}
