package app.eclipse.extension.artwork;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * v1.99.1: al cambiar de cancion, el FONDO borroso del reproductor se queda con la imagen anterior y la PORTADA nitida
 * muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse dibuja portadas/fondos con un componente compartido (by9.c -> Coil SubcomposeAsyncImage; contenido = lambda
 * w71.k, caso q=1). Como se usa en TODA la app, solo se toca el del reproductor: el parche marca con {@link #tagBg} o
 * {@link #tagCover} el objeto de parametros (sn3) que construye cada sitio del reproductor. La lambda consulta
 * {@link #saved}: fondo -> ultimo painter bueno (o null); portada -> un Drawable con el cuadro y la nota; sitio no
 * marcado -> null (la app hace lo de siempre). {@link #remember} guarda el painter solo para fondos.
 */
@SuppressWarnings("unused")
public final class PrevCover {
    private static final int BG = 1;
    private static final int COVER = 2;
    private static final int MAX_TAGS = 256;

    private static final class Tag {
        final WeakReference<Object> ref;
        final int kind;
        Tag(Object o, int kind) { this.ref = new WeakReference<Object>(o); this.kind = kind; }
    }

    private static final ArrayList<Tag> TAGS = new ArrayList<Tag>();
    private static Object lastBg;
    private static Drawable placeholder;

    public static void tagBg(Object sn3) { tag(BG, sn3); }

    public static void tagCover(Object sn3) { tag(COVER, sn3); }

    private static synchronized void tag(int kind, Object sn3) {
        try {
            if (sn3 == null) return;
            for (int i = TAGS.size() - 1; i >= 0; i--) {
                if (TAGS.get(i).ref.get() == null) TAGS.remove(i);
            }
            while (TAGS.size() >= MAX_TAGS) TAGS.remove(0);
            TAGS.add(new Tag(sn3, kind));
        } catch (Throwable ignored) {
        }
    }

    private static int kindOf(Object sn3) {
        if (sn3 == null) return 0;
        for (int i = TAGS.size() - 1; i >= 0; i--) {
            Tag t = TAGS.get(i);
            if (t.ref.get() == sn3) return t.kind;
        }
        return 0;
    }

    /**
     * Fondo: ultimo painter (i36) que termino de cargar, o null. Portada: un Drawable (cuadro oscuro + nota). Sitio no
     * marcado o error: null.
     */
    public static synchronized Object saved(Object sn3) {
        try {
            int k = kindOf(sn3);
            if (k == BG) return lastBg;
            if (k == COVER) return placeholder();
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Guarda el painter recien cargado (rama exito) solo si el sn3 es un fondo del reproductor. */
    public static synchronized void remember(Object sn3, Object painter) {
        try {
            if (painter == null) return;
            if (kindOf(sn3) == BG) lastBg = painter;
        } catch (Throwable ignored) {
        }
    }

    /** Cuadro negro ~55% con esquinas suaves y una nota musical doble blanca ~55% al centro (referencia: Bitchord). */
    private static Drawable placeholder() {
        if (placeholder != null) return placeholder;
        final int n = 800;
        Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x8C000000); // negro ~55%
        float r = n * 0.03f;
        c.drawRoundRect(new RectF(0, 0, n, n), r, r, p);

        p.setColor(0x8CFFFFFF); // blanco ~55%
        float w = n * 0.15f;           // ancho de la nota
        float cx = n / 2f, cy = n / 2f;
        float rx = w * 0.21f, ry = w * 0.15f;
        float lx = cx - w * 0.30f, ly = cy + w * 0.34f;   // cabeza izquierda
        float rxc = cx + w * 0.34f, ryc = cy + w * 0.20f; // cabeza derecha
        float stemW = w * 0.09f;
        float top = cy - w * 0.42f;
        // cabezas (ovalos inclinados)
        c.save();
        c.rotate(-20f, lx, ly);
        c.drawOval(new RectF(lx - rx, ly - ry, lx + rx, ly + ry), p);
        c.restore();
        c.save();
        c.rotate(-20f, rxc, ryc);
        c.drawOval(new RectF(rxc - rx, ryc - ry, rxc + rx, ryc + ry), p);
        c.restore();
        // plicas
        c.drawRect(new RectF(lx + rx - stemW, top + w * 0.06f, lx + rx, ly), p);
        c.drawRect(new RectF(rxc + rx - stemW, top - w * 0.02f, rxc + rx, ryc), p);
        // barra
        Path beam = new Path();
        float bt = w * 0.17f;
        beam.moveTo(lx + rx - stemW, top + w * 0.06f);
        beam.lineTo(rxc + rx, top - w * 0.02f);
        beam.lineTo(rxc + rx, top - w * 0.02f + bt);
        beam.lineTo(lx + rx - stemW, top + w * 0.06f + bt);
        beam.close();
        c.drawPath(beam, p);

        placeholder = new BitmapDrawable(bmp);
        return placeholder;
    }
}
