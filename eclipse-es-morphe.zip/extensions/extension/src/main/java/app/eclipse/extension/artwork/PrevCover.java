package app.eclipse.extension.artwork;

import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * v1.99.1: al cambiar de cancion, el FONDO borroso del reproductor se queda con la imagen anterior y la PORTADA nitida
 * muestra un cuadro oscuro translucido con una nota musical mientras carga (como Bitchord).
 *
 * Eclipse dibuja portadas/fondos con un componente compartido (by9.c -> Coil SubcomposeAsyncImage; contenido = lambda
 * w71.k, caso q=1). Como se usa en TODA la app, solo se toca el del reproductor: el parche marca con {@link #tagBg} o
 * {@link #tagCover} el objeto de parametros (sn3) que construye cada sitio del reproductor. La lambda consulta
 * {@link #saved}: fondo -> ultimo painter bueno (o null); portada -> un Drawable con el cuadro y la nota; sitio no
 * marcado -> null (la app hace lo de siempre). {@link #remember} guarda el painter solo para fondos.
 */
@SuppressWarnings("unused")
public final class PrevCover {
    private static final int BG = 1;      // fondo borroso por defecto de Eclipse (di6.c)
    private static final int COVER = 2;
    private static final int BG2 = 3;     // copia borrosa / reflejo de la portada (xi6.e)
    private static final int BG3 = 4;     // v0.20.19: reflejo PROPIO (BlurredCanvasBackground.drawCover)
    private static final int BG4 = 5;     // v0.20.20: relleno chiquito PROPIO (BlurredCanvasBackground.drawFillCover)
    private static final long FADE_MS = 220; // v0.20.27: antes 300
    private static final int MAX_TAGS = 256;

    private static final class Tag {
        final WeakReference<Object> ref;
        final int kind;
        Tag(Object o, int kind) { this.ref = new WeakReference<Object>(o); this.kind = kind; }
    }

    private static final ArrayList<Tag> TAGS = new ArrayList<Tag>();
    private static final Object[] lastBg = new Object[6];          // painter guardado por sitio (1, 3 y 4)
    private static final Drawable[] lastSrc = new Drawable[6];     // ultimo Drawable cargado por sitio
    private static final Drawable[] lastWrapped = new Drawable[6]; // su envoltorio con fundido
    private static Drawable placeholder;

    public static void tagBg(Object sn3) { tag(BG, sn3); }

    public static void tagBg2(Object sn3) { tag(BG2, sn3); }

    private static volatile Object ownReq;

    /** v0.20.19: el sn3 que usa nuestro reflejo (un solo objeto, se guarda aparte para que la lista de marcas no lo borre). */
    public static void tagBg3(Object sn3) { ownReq = sn3; }

    private static volatile Object ownReq2;

    /** v0.20.20: el sn3 del relleno chiquito del fondo (otro objeto, con su propia imagen anterior). */
    public static void tagBg4(Object sn3) { ownReq2 = sn3; }

    public static void tagCover(Object sn3) { tag(COVER, sn3); }

    private static synchronized void tag(int kind, Object sn3) {
        try {
            if (sn3 == null) return;
            for (int i = TAGS.size() - 1; i >= 0; i--) {
                if (TAGS.get(i).ref.get() == null) TAGS.remove(i);
            }
            while (TAGS.size() >= MAX_TAGS) TAGS.remove(0);
            TAGS.add(new Tag(sn3, kind));
        } catch (Throwable ignored) {
        }
    }

    private static int kindOf(Object sn3) {
        if (sn3 == null) return 0;
        if (sn3 == ownReq) return BG3;
        if (sn3 == ownReq2) return BG4;
        for (int i = TAGS.size() - 1; i >= 0; i--) {
            Tag t = TAGS.get(i);
            if (t.ref.get() == sn3) return t.kind;
        }
        return 0;
    }

    /**
     * Fondo: ultimo painter (i36) que termino de cargar, o null. Portada: un Drawable (cuadro oscuro + nota). Sitio no
     * marcado o error: null.
     */
    public static synchronized Object saved(Object sn3) {
        try {
            int k = kindOf(sn3);
            if (k == BG || k == BG2 || k == BG3 || k == BG4) return lastBg[k];
            if (k == COVER) {
                // v0.20.38: misma cancion (solo cambia el tamano de la portada) -> se queda la portada anterior, sin nota.
                // v0.20.43: sin nota ni cuadro. Mientras carga la portada nueva se queda la anterior (que sale deslizando cuando llega).
                Drawable kc = keptCover;
                if (kc != null) return kc;
                return blank();
            }
            return null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Guarda el painter recien cargado (rama exito) solo si el sn3 es un fondo del reproductor. */
    public static synchronized void remember(Object sn3, Object painter) {
        try {
            if (painter == null) return;
            int k = kindOf(sn3);
            if (k == BG || k == BG2 || k == BG3 || k == BG4) lastBg[k] = painter;
        } catch (Throwable ignored) {
        }
    }

    /**
     * v1.100.0: fundido al llegar la imagen nueva del fondo. Recibe el Drawable recien cargado y, si el sn3 es un fondo
     * del reproductor, devuelve un envoltorio que dibuja la imagen ANTERIOR del mismo sitio y la NUEVA apareciendo poco
     * a poco. Si no es fondo, no hay imagen anterior o algo falla, devuelve el mismo Drawable (sin fundido).
     * El envoltorio se guarda por Drawable para que la app (que lo recuerda por identidad) no reinicie el fundido.
     */
    public static synchronized Drawable fade(Object sn3, Drawable d) {
        try {
            if (d == null) return d;
            int k = kindOf(sn3);
            if (k == COVER) return fadeCover(d);
            if (k != BG && k != BG2 && k != BG3 && k != BG4) return d;
            if (lastSrc[k] == d) return lastWrapped[k] != null ? lastWrapped[k] : d;
            Drawable prev = lastSrc[k];
            lastSrc[k] = d;
            // v0.20.43: el reflejo (nuestro o el de Eclipse) se desliza junto con la portada nitida en CADA cambio de cancion. Una sola vez por cambio.
            if ((k == BG2 || k == BG3) && prev != null && slideWanted() && slideUsed[k] != songEvt) {
                slideUsed[k] = songEvt;
                lastWrapped[k] = new SlideDrawable(prev, d, songDir, songEvt);
                return lastWrapped[k];
            }
            lastWrapped[k] = new FadeDrawable(prev, d); // prev null: aparece desde transparente
            return lastWrapped[k];
        } catch (Throwable t) {
            return d;
        }
    }

    // v1.100.1: la PORTADA tambien se funde. Lo que se ve mientras carga es el cuadro con la nota, asi que el fundido va
    // del cuadro a la portada nueva (a la vez que el del fondo). 
    // Hay dos sitios de portada (di6.b / xi6.p), por eso el envoltorio se guarda por Drawable en una lista corta.
    private static long coverSince = 0;            // v0.20.3: desde cuando se muestra la nota (0 = no)
    private static long coverDecidedAt = 0;        // v0.20.3: cuando llego la imagen y se decidio si fundir
    // v0.20.4: la nota solo sale si la cancion actual es distinta de la de la ultima portada mostrada (cambio de
    // cancion); al salir y volver al reproductor la cancion es la misma y no sale. La cancion actual la entrega
    // BlurredCanvasBackground.draw con el estado ow0 (campo `a`, Song). Sin dato (null) se muestra la nota como antes.
    private static volatile Object curSong;
    private static volatile Object lastCoverSong;
    private static volatile Drawable keptCover; // v0.20.38 (v0.20.42: solo la mas grande de la cancion actual)
    private static volatile int keptW;           // v0.20.42: ancho de keptCover
    private static volatile Object keptSong;     // v0.20.43: cancion de keptCover
    private static volatile Drawable prevKept;   // v0.20.42: portada de la cancion anterior (para deslizar)
    private static volatile Object slideSong;    // v0.20.42: cancion para la que se esta deslizando
    private static volatile long slideFirstAt;

    // ---- v0.20.42: deslizamiento al presionar siguiente/anterior (SIN COMPILAR / SIN PROBAR) ----
    private static final long SLIDE_MS = 380;   // duracion del deslizamiento (se ajusta aqui)
    private static volatile int skipDir = 0;    // +1 siguiente (la vieja sale a la izquierda), -1 anterior
    private static volatile long skipAt = 0;
    private static volatile long swipeAt = 0;   // v0.20.43: ultimo arrastre con el dedo sobre la portada (Eclipse ya desliza solo)
    private static volatile int songEvt = 0;    // v0.20.43: contador de cambios de cancion
    private static volatile long songEvtAt = 0;
    private static volatile int songDir = 1;
    private static final int[] slideUsed = new int[6];
    private static volatile long slideStart = 0;
    private static volatile int slideStartEvt = -1;
    private static java.lang.reflect.Field layerKindField;
    private static boolean layerKindTried;

    /** v0.20.43: hay un cambio de cancion reciente que debe deslizar. */
    private static boolean slideWanted() {
        return songEvt != 0 && android.os.SystemClock.uptimeMillis() - songEvtAt < 6000;
    }

    /**
     * Gancho al inicio de kj6.s(lb4, dw0) (ejecuta la accion de un boton/gesto). Solo cuenta NEXT y PREVIOUS que vienen
     * de un BOTON (la capa no es la portada: el arrastre con el dedo ya tiene su propio deslizamiento en Eclipse).
     */
    public static void onSkip(Object action, Object layer) {
        try {
            if (!(action instanceof Enum)) return;
            String n = ((Enum<?>) action).name();
            int dir = "NEXT".equals(n) ? 1 : ("PREVIOUS".equals(n) ? -1 : 0);
            if (dir == 0) return;
            if (layer != null) {
                if (!layerKindTried) {
                    layerKindTried = true;
                    try {
                        layerKindField = layer.getClass().getDeclaredField("b");
                        layerKindField.setAccessible(true);
                    } catch (Throwable t) {
                        layerKindField = null;
                    }
                }
                if (layerKindField != null) {
                    Object kd = layerKindField.get(layer);
                    if (kd instanceof Enum && "ARTWORK".equalsIgnoreCase(((Enum<?>) kd).name())) {
                        swipeAt = android.os.SystemClock.uptimeMillis(); // v0.20.43: arrastre con el dedo: Eclipse ya desliza solo
                        return;
                    }
                }
            }
            skipDir = dir;
            skipAt = android.os.SystemClock.uptimeMillis();
        } catch (Throwable ignored) {
        }
    }
    private static java.lang.reflect.Field songField;
    private static boolean songFieldTried;

    public static void setState(Object st) {
        try {
            if (st == null) return;
            if (!songFieldTried) {
                songFieldTried = true;
                try {
                    songField = st.getClass().getDeclaredField("a");
                    songField.setAccessible(true);
                } catch (Throwable t) {
                    songField = null;
                }
            }
            if (songField != null) {
                Object ns = songField.get(st);
                Object os = curSong;
                curSong = ns;
                // v0.20.43: cambio de cancion (no la primera) -> evento de deslizamiento, salvo arrastre con el dedo.
                if (os != null && ns != null && !os.equals(ns)) {
                    long now = android.os.SystemClock.uptimeMillis();
                    if (now - swipeAt > 4000) {
                        songDir = (skipDir != 0 && now - skipAt < 2500) ? skipDir : 1;
                        songEvt = songEvt + 1;
                        songEvtAt = now;
                    }
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static boolean songChanged() {
        Object c = curSong, l = lastCoverSong;
        if (c == null || l == null) return true;
        return !c.equals(l);
    }

    private static final int COVER_CACHE = 4;
    private static final Drawable[] coverSrc = new Drawable[COVER_CACHE];
    private static final Drawable[] coverWrapped = new Drawable[COVER_CACHE];
    private static int coverNext = 0;

    private static Drawable fadeCover(Drawable d) {
        for (int i = 0; i < COVER_CACHE; i++) {
            if (coverSrc[i] == d) return coverWrapped[i] != null ? coverWrapped[i] : d;
        }
        // v0.20.3: solo se funde desde la nota si la nota se estuvo viendo (carga real = cambio de cancion).
        // Al salir y volver al reproductor la imagen llega casi al instante (cache): ahi NO hay fundido ni nota.
        long now = android.os.SystemClock.uptimeMillis();
        boolean noteWasShown = coverSince != 0
                && !(coverDecidedAt > 0 && now - coverDecidedAt > 500); // v0.20.5: sin umbral de tiempo
        if (coverDecidedAt == 0) coverDecidedAt = now;
        // v0.20.42: calidad. Antes keptCover era "la ultima cargada" (a veces la chiquita de la cabecera, 64 dp) y al volver a Artwork
        // se mostraba esa estirada. Ahora solo se guarda la MAS GRANDE de la cancion actual. Ademas se recuerda la portada de la
        // cancion anterior (prevKept) para el deslizamiento.
        boolean newSong = songChanged();
        Object cs = curSong;
        int wd = d.getIntrinsicWidth();
        Drawable oldCover = null;
        if (newSong) {
            prevKept = (cs != null) ? keptCover : null;
            keptCover = d;
            keptW = wd;
            keptSong = cs;
            if (cs != null && prevKept != null && slideWanted()) {
                slideSong = cs;
                slideFirstAt = now;
                oldCover = prevKept;
            }
        } else {
            if (keptCover == null || wd >= keptW) { keptCover = d; keptW = wd; keptSong = cs; }
            if (cs != null && slideSong != null && slideSong.equals(cs) && prevKept != null && slideWanted()
                    && now - slideFirstAt < 1500) {
                oldCover = prevKept;
            }
        }
        lastCoverSong = curSong; // v0.20.4: la cancion de la portada que acaba de llegar
        // v0.20.43: sin nota ni fundido. BestOf: si la caja es mas grande que esta imagen, dibuja la mas grande de la cancion (calidad).
        Drawable under = new BestOf(d, cs);
        Drawable w;
        if (oldCover != null && oldCover != d) {
            w = new SlideDrawable(oldCover, under, songDir, songEvt); // entra deslizando, la vieja sale
        } else {
            w = under;
        }
        coverSrc[coverNext] = d;
        coverWrapped[coverNext] = w;
        coverNext = (coverNext + 1) % COVER_CACHE;
        return w;
    }

    /**
     * v0.20.42: la imagen vieja sale hacia un lado y la nueva entra pegada (sin hueco). Se recorta al ancho de la pantalla
     * (centrado en la caja) para que el reflejo, que es mas ancho que la pantalla, avance igual que la portada nitida.
     * El reloj es compartido por evento (portada y reflejo arrancan a la vez). Si algo falla, dibuja la nueva sin mas.
     */
    private static final class SlideDrawable extends Drawable {
        private final Drawable from;
        private final Drawable to;
        private final int dir;
        private final int evt;
        private boolean done = false;

        SlideDrawable(Drawable from, Drawable to, int dir, int evt) {
            this.from = from; this.to = to; this.dir = dir; this.evt = evt;
        }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                long now = android.os.SystemClock.uptimeMillis();
                if (slideStartEvt != evt) { slideStartEvt = evt; slideStart = now; }
                float t = (now - slideStart) / (float) SLIDE_MS;
                if (t >= 1f) { done = true; to.draw(canvas); return; }
                float inv = 1f - t;
                float e = 1f - inv * inv * inv; // sale rapido y frena al final
                int sw = 0;
                try {
                    sw = android.content.res.Resources.getSystem().getDisplayMetrics().widthPixels;
                } catch (Throwable ignored) { }
                float dist = (sw > 0) ? Math.min((float) sw, (float) b.width()) : (float) b.width();
                float cx = (b.left + b.right) / 2f;
                int saved = canvas.save();
                canvas.clipRect(cx - dist / 2f, b.top, cx + dist / 2f, b.bottom);
                canvas.save();
                canvas.translate(-dir * e * dist, 0f);
                from.setBounds(b);
                from.draw(canvas);
                canvas.restore();
                canvas.save();
                canvas.translate(dir * (1f - e) * dist, 0f);
                to.draw(canvas);
                canvas.restore();
                canvas.restoreToCount(saved);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static final class FadeDrawable extends Drawable {
        private Drawable from;
        private final Drawable to;
        private long start = -1;
        private boolean done = false;

        FadeDrawable(Drawable from, Drawable to) { this.from = from; this.to = to; }

        @Override public int getIntrinsicWidth() { return to.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return to.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                to.setBounds(b);
                // La app tambien dibuja el Drawable en un Bitmap (canvas por software) para otras cosas: ahi no hay
                // fundido ni se arranca el reloj. El dibujo real de Compose usa canvas con aceleracion por hardware.
                if (done || !canvas.isHardwareAccelerated()) { to.draw(canvas); return; }
                long now = android.os.SystemClock.uptimeMillis();
                if (start < 0) start = now;
                float t = (now - start) / (float) FADE_MS;
                if (t >= 1f) { done = true; from = null; to.draw(canvas); return; }
                if (from != null) { from.setBounds(b); from.draw(canvas); }
                to.setAlpha((int) (255 * t));
                to.draw(canvas);
                to.setAlpha(255);
                invalidateSelf();
            } catch (Throwable ignored) {
                try { to.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /**
     * Cuadro negro ~55% con esquinas suaves y una nota doble blanca ~63% al centro (referencia: Bitchord).
     * Es un Drawable propio que se dibuja segun el tamano REAL del area: la app lo estira a todo el area de la portada
     * (que no es cuadrada), asi que la nota se dibuja siempre con proporcion cuadrada y centrada, sin deformarse.
     */
    private static Drawable placeholder() {
        if (placeholder == null) placeholder = new NoteBox(false);
        return placeholder;
    }

    private static Drawable fadePlaceholder() {
        if (fadeNote == null) fadeNote = new NoteBox(true);
        return fadeNote;
    }

    private static Drawable fadeNote;

    /** v0.20.6: dibuja la nota y encima la portada. Si la portada es opaca la tapa; si tiene bordes transparentes, se ve debajo. */
    private static final class UnderNote extends Drawable {
        private final Drawable cover;
        private int alpha = 255;

        UnderNote(Drawable cover) { this.cover = cover; }

        @Override public int getIntrinsicWidth() { return cover.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return cover.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                cover.setBounds(b);
                if (canvas.isHardwareAccelerated()) { // en bitmaps por software no se pinta la nota
                    Drawable n = fadePlaceholder();
                    n.setBounds(b);
                    n.draw(canvas);
                }
                cover.setAlpha(alpha);
                cover.draw(canvas);
            } catch (Throwable ignored) {
                try { cover.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static Drawable blankDrawable;

    private static Drawable blank() {
        if (blankDrawable == null) blankDrawable = new Blank();
        return blankDrawable;
    }

    /** v0.20.43: portada vacia (transparente) para la primera carga: sin nota ni cuadro. */
    private static final class Blank extends Drawable {
        @Override public int getIntrinsicWidth() { return 800; }
        @Override public int getIntrinsicHeight() { return 800; }
        @Override public void draw(Canvas canvas) { }
        @Override public void setAlpha(int a) { }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSPARENT; }
    }

    /**
     * v0.20.43 (calidad): mientras la portada grande vuelve a su tamano (Letra -> Artwork) Eclipse pide imagenes de tamanos
     * intermedios y se podia ver una chiquita estirada. Al dibujar, si la caja es bastante mas grande que esta imagen y hay
     * una mas grande de la MISMA cancion, se dibuja esa.
     */
    private static final class BestOf extends Drawable {
        private final Drawable d;
        private final Object song;
        private int alpha = 255;

        BestOf(Drawable d, Object song) { this.d = d; this.song = song; }

        @Override public int getIntrinsicWidth() { return d.getIntrinsicWidth(); }
        @Override public int getIntrinsicHeight() { return d.getIntrinsicHeight(); }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                Drawable use = d;
                Drawable k = keptCover;
                if (k != null && k != d) {
                    Object ks = keptSong;
                    boolean sameSong = (song == null && ks == null) || (song != null && song.equals(ks));
                    int dw = d.getIntrinsicWidth(), kw = k.getIntrinsicWidth();
                    if (sameSong && dw > 0 && kw > dw && b.width() > dw * 1.15f) use = k;
                }
                use.setBounds(b);
                use.setAlpha(alpha);
                use.draw(canvas);
            } catch (Throwable ignored) {
                try { d.draw(canvas); } catch (Throwable ignored2) { }
            }
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    private static final class NoteBox extends Drawable {
        private final Paint boxPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint notePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF boxRect = new RectF();
        private final RectF dst = new RectF();
        private Bitmap note;
        private int alpha = 255;
        private float shaderH = -1f;

        private final boolean always;

        NoteBox(boolean always) {
            this.always = always;
            notePaint.setAlpha(160);       // blanco ~63%
        }

        @Override public int getIntrinsicWidth() { return 800; }
        @Override public int getIntrinsicHeight() { return 800; }

        @Override
        public void draw(Canvas canvas) {
            try {
                Rect b = getBounds();
                float w = b.width(), h = b.height();
                if (w <= 0 || h <= 0) return;
                float m = Math.min(w, h);
                // v0.20.4: sin cuadro negro. Solo se dibuja si cambio la cancion (o en el fundido de salida).
                // v0.20.6: la nota se dibuja siempre; solo se apunta (para el fundido) si cambio la cancion.
                if (!always && songChanged()) {
                    long now = android.os.SystemClock.uptimeMillis();
                    if (coverSince == 0 || (coverDecidedAt > 0 && now - coverDecidedAt > 500)) {
                        coverSince = now;
                        coverDecidedAt = 0;
                    }
                }
                notePaint.setAlpha((int) (160 * (alpha / 255f)));
                if (note == null) note = makeNote();
                float side = m * 0.11f; // v0.20.4: la nota ocupa ~14% del lado corto (antes 17%)
                float cx = b.left + w / 2f, cy = b.top + h / 2f;
                dst.set(cx - side / 2f, cy - side / 2f, cx + side / 2f, cy + side / 2f);
                canvas.drawBitmap(note, null, dst, notePaint);
            } catch (Throwable ignored) {
            }
        }

        @Override public void setAlpha(int a) { alpha = a; }
        @Override public void setColorFilter(ColorFilter cf) { }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
    }

    /** Nota doble en blanco OPACO sobre un lienzo cuadrado (se pega luego con transparencia: sin zonas mas claras). */
    private static Bitmap makeNote() {
        final int n = 256;
        Bitmap bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888);
        Canvas nc = new Canvas(bmp);
        Paint q = new Paint(Paint.ANTI_ALIAS_FLAG);
        q.setStyle(Paint.Style.FILL);
        q.setColor(0xFFFFFFFF);
        float w = n * 0.90f;                    // ancho total de la nota dentro del lienzo
        float x0 = (n - w) / 2f, y0 = (n - w * 0.97f) / 2f;
        float rx = w * 0.17f, ry = w * 0.13f;   // cabezas
        float lx = x0 + rx, ly = y0 + w * 0.84f;
        float rcx = x0 + w - rx * 0.86f, rcy = y0 + w * 0.72f;
        float sw = w * 0.085f;                  // grosor de los palitos
        float lTop = y0 + w * 0.12f, rTop = y0;
        float bt = w * 0.17f;                   // grosor de la barra
        // Los palitos nacen DENTRO de las cabezas (borde derecho algo hacia adentro) y suben solo hasta la mitad de la
        // barra: asi no sobresalen escalones ni esquinas planas.
        float lSr = lx + rx * 0.86f, rSr = rcx + rx * 0.86f;
        nc.save();
        nc.rotate(-20f, lx, ly);
        nc.drawOval(new RectF(lx - rx, ly - ry, lx + rx, ly + ry), q);
        nc.restore();
        nc.save();
        nc.rotate(-20f, rcx, rcy);
        nc.drawOval(new RectF(rcx - rx, rcy - ry, rcx + rx, rcy + ry), q);
        nc.restore();
        nc.drawRect(new RectF(lSr - sw, lTop + bt * 0.5f, lSr, ly - ry * 0.1f), q);
        nc.drawRect(new RectF(rSr - sw, rTop + bt * 0.5f, rSr, rcy - ry * 0.1f), q);
        Path beam = new Path();
        beam.moveTo(lSr - sw, lTop);
        beam.lineTo(rSr, rTop);
        beam.lineTo(rSr, rTop + bt);
        beam.lineTo(lSr - sw, lTop + bt);
        beam.close();
        nc.drawPath(beam, q);
        return bmp;
    }
}
