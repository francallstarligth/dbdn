package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * v0.20.373. Mini reproductor "pildora" de la skin Native: al tocar SIGUIENTE con el BOTON hace el mismo deslizamiento que al soltar el dedo.
 * `registerWs` (Lws6.<init>, el gesto del mini, nace al dibujar el mini) guarda el gesto; `nextClick` (Ln40.a, caso 17 = siguiente del mini)
 * lanza `Lvs6(Lqt, F offset, Lll8, F ancho, Z, I direccion, Lle8, Ljh0, Luh6, Lte7, Luh6, Luh6, tz1)` por `Lkxb.I(Lo12, null, null, job, 3)`
 * con direccion +1, leyendo los datos de Lws6 por reflexion. Todo en try/catch: si algo no cuadra devuelve false y el boton hace lo de siempre.
 */
public final class MiniSlide {
    private static final String TAG = "MiniSlide";
    private static final int NEXT_CASE = 17;
    private static volatile WeakReference<Object> ws6;
    private static volatile long last;
    private static Constructor<?> ctor;
    private static Method launch;

    private MiniSlide() {}

    public static void registerWs(Object o) {
        ws6 = new WeakReference<>(o);
    }

    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    /** @return true si se lanzo el deslizamiento (el boton no debe hacer nada mas). */
    public static boolean nextClick(int mode, Object click) {
        try {
            if (mode != NEXT_CASE) return false;
            WeakReference<Object> r = ws6;
            Object ws = r == null ? null : r.get();
            if (ws == null) return false;
            long now = SystemClock.uptimeMillis();
            if (now - last < 350) return false; // toques muy seguidos: hace lo de siempre (salta directo)

            Object scope = field(ws, "u");
            Object qt = field(ws, "v");
            Object le8 = field(ws, "x");
            Object jh0 = field(ws, "y");
            Object a = field(ws, "s");
            Object te7b = field(ws, "z");
            Object b = field(ws, "A");
            Object c = field(ws, "B");
            if (scope == null || qt == null || le8 == null || jh0 == null || a == null || te7b == null || b == null || c == null) return false;
            Field fq = ws.getClass().getDeclaredField("t");
            fq.setAccessible(true);
            float density = fq.getFloat(ws);
            Field fw = ws.getClass().getDeclaredField("w");
            fw.setAccessible(true);
            boolean w = fw.getBoolean(ws);

            // posicion real del mini (Lqt.d()): si ya se esta moviendo, hace lo de siempre
            Method dm = qt.getClass().getMethod("d");
            dm.setAccessible(true);
            float cur = ((Number) dm.invoke(qt)).floatValue();
            if (Math.abs(cur) > 1f) return false;

            // Lll8 = soporte de un float (campo q). Con q = 0 Lvs6 siempre confirma el cambio (no lo cancela)
            Class<?> kll = Class.forName("ll8");
            Object ll8;
            try {
                Constructor<?> lc = kll.getDeclaredConstructor();
                lc.setAccessible(true);
                ll8 = lc.newInstance();
            } catch (Throwable t0) {
                Class<?> ku = Class.forName("sun.misc.Unsafe");
                Field uf = ku.getDeclaredField("theUnsafe");
                uf.setAccessible(true);
                ll8 = ku.getMethod("allocateInstance", Class.class).invoke(uf.get(null), kll);
            }
            Field fl = kll.getDeclaredField("q");
            fl.setAccessible(true);
            fl.setFloat(ll8, 0f);

            if (ctor == null) {
                Class<?> k = Class.forName("vs6");
                for (Constructor<?> cc : k.getDeclaredConstructors()) {
                    Class<?>[] p = cc.getParameterTypes();
                    if (p.length == 13 && p[0].getName().equals("qt") && p[1] == float.class && p[5] == int.class) {
                        cc.setAccessible(true);
                        ctor = cc;
                        break;
                    }
                }
            }
            if (launch == null) {
                Class<?> kx = Class.forName("kxb");
                for (Method mm : kx.getDeclaredMethods()) {
                    Class<?>[] p = mm.getParameterTypes();
                    if (mm.getName().equals("I") && Modifier.isStatic(mm.getModifiers()) && p.length == 5
                            && p[4] == int.class && p[3].getName().equals("tk3") && p[0].getName().equals("o12")) {
                        mm.setAccessible(true);
                        launch = mm;
                        break;
                    }
                }
            }
            if (ctor == null || launch == null) return false;
            // direccion +1 = siguiente (Lvs6: direccion > 0 -> Ljh0.K(false)); desliza hacia la izquierda
            Object job = ctor.newInstance(qt, 0f, ll8, density, w, 1, le8, jh0, a, te7b, b, c, null);
            launch.invoke(null, scope, null, null, job, 3);
            last = now;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "nextClick", t);
            return false;
        }
    }
}
