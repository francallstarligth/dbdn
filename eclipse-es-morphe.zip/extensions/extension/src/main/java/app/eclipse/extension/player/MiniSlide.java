package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * v0.20.368 (SIN COMPILAR NI PROBAR). Mini reproductor "pildora" de la skin Native: al tocar SIGUIENTE con el BOTON hace el mismo
 * deslizamiento que al soltar el dedo tras arrastrar.
 * Al soltar el dedo, Eclipse llama `Lts6.a()`, que lanza `Lvs6(Lqt, F offset, Lll8, F densidad, Z, I direccion, Lle8, Ljh0, Luh6, Lte7, Luh6, Luh6, tz1)`
 * por `Lkxb.I(Lo12, null, null, job, 3)`. `Lvs6` anima el desplazamiento (200 ms), llama siguiente (direccion &gt; 0) o anterior, y vuelve a 0.
 * `register` (Lts6.<init>) guarda ese Lts6; `nextClick` (Ln40.a, caso 17 = siguiente del mini) lanza el mismo trabajo con direccion +1,
 * leyendo los datos del Lts6 por reflexion. Todo en try/catch: si algo no cuadra devuelve false y el boton hace lo de siempre.
 */
public final class MiniSlide {
    private static final String TAG = "MiniSlide";
    private static final int NEXT_CASE = 17;
    private static volatile WeakReference<Object> ts6;
    private static volatile long last;
    private static Constructor<?> ctor;
    private static Method launch;

    private MiniSlide() {}

    public static void register(Object o) {
        ts6 = new WeakReference<>(o);
    }

    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    /** @return true si se lanzo el deslizamiento (el boton no debe hacer nada mas). */
    public static boolean nextClick(int mode, Object click) {
        try {
            if (mode != NEXT_CASE) return false;
            WeakReference<Object> r = ts6;
            Object ts = r == null ? null : r.get();
            if (ts == null) return false;
            long now = SystemClock.uptimeMillis();
            if (now - last < 350) return false; // toques muy seguidos: hace lo de siempre (salta directo)

            Object scope = field(ts, "s");
            Object offsetState = field(ts, "t");
            Object qt = field(ts, "u");
            Object ll8 = field(ts, "v");
            Object le8 = field(ts, "x");
            Object jh0 = field(ts, "y");
            Object a = field(ts, "z");
            Object te7b = field(ts, "A");
            Object b = field(ts, "B");
            Object c = field(ts, "C");
            if (scope == null || offsetState == null || qt == null || ll8 == null || le8 == null
                    || jh0 == null || a == null || te7b == null || b == null || c == null) return false;
            Field fq = ts.getClass().getDeclaredField("q");
            fq.setAccessible(true);
            float density = fq.getFloat(ts);
            Field fw = ts.getClass().getDeclaredField("w");
            fw.setAccessible(true);
            boolean w = fw.getBoolean(ts);

            Method h = offsetState.getClass().getDeclaredMethod("h");
            h.setAccessible(true);
            float offset = ((Number) h.invoke(offsetState)).floatValue();
            if (Math.abs(offset) > 1f) return false; // ya hay un deslizamiento en curso

            // Lvs6 compara |ll8.q| con |offset|: con ll8.q = 0 siempre confirma el cambio (no lo cancela)
            Field fl = ll8.getClass().getDeclaredField("q");
            fl.setAccessible(true);
            fl.setFloat(ll8, 0f);

            if (ctor == null) {
                Class<?> k = Class.forName("vs6");
                for (Constructor<?> cc : k.getDeclaredConstructors()) {
                    Class<?>[] p = cc.getParameterTypes();
                    if (p.length == 13 && p[0].getName().equals("qt") && p[1] == float.class && p[5] == int.class) {
                        cc.setAccessible(true);
                        ctor = cc;
                        break;
                    }
                }
            }
            if (launch == null) {
                Class<?> kx = Class.forName("kxb");
                for (Method mm : kx.getDeclaredMethods()) {
                    Class<?>[] p = mm.getParameterTypes();
                    if (mm.getName().equals("I") && Modifier.isStatic(mm.getModifiers()) && p.length == 5
                            && p[4] == int.class && p[3].getName().equals("tk3") && p[0].getName().equals("o12")) {
                        mm.setAccessible(true);
                        launch = mm;
                        break;
                    }
                }
            }
            if (ctor == null || launch == null) return false;
            // direccion +1 = siguiente (Lvs6: direccion > 0 -> Ljh0.K(false)); desliza hacia la izquierda
            Object job = ctor.newInstance(qt, offset, ll8, density, w, 1, le8, jh0, a, te7b, b, c, null);
            launch.invoke(null, scope, null, null, job, 3);
            last = now;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "nextClick", t);
            return false;
        }
    }
}
