package app.eclipse.extension.player;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.widget.Toast;
import android.util.Log;

import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * v0.20.369 DIAGNOSTICO: ademas del deslizamiento, guarda un log y lo copia al portapapeles cuando alguien llama `Ljh0.K(false)` (siguiente):
 * cuenta cuantas veces se registro `Lts6`, que caso de `Ln40` se toco, por que `nextClick` devolvio false y QUIEN llamo a siguiente (pila).
 * v0.20.368 (SIN COMPILAR NI PROBAR). Mini reproductor "pildora" de la skin Native: al tocar SIGUIENTE con el BOTON hace el mismo
 * deslizamiento que al soltar el dedo tras arrastrar.
 * Al soltar el dedo, Eclipse llama `Lts6.a()`, que lanza `Lvs6(Lqt, F offset, Lll8, F densidad, Z, I direccion, Lle8, Ljh0, Luh6, Lte7, Luh6, Luh6, tz1)`
 * por `Lkxb.I(Lo12, null, null, job, 3)`. `Lvs6` anima el desplazamiento (200 ms), llama siguiente (direccion &gt; 0) o anterior, y vuelve a 0.
 * `register` (Lts6.<init>) guarda ese Lts6; `nextClick` (Ln40.a, caso 17 = siguiente del mini) lanza el mismo trabajo con direccion +1,
 * leyendo los datos del Lts6 por reflexion. Todo en try/catch: si algo no cuadra devuelve false y el boton hace lo de siempre.
 */
public final class MiniSlide {
    private static final String TAG = "MiniSlide";
    private static final int NEXT_CASE = 17;
    private static volatile WeakReference<Object> ts6;
    private static volatile long last;
    private static Constructor<?> ctor;
    private static Method launch;

    private MiniSlide() {}

    private static final StringBuilder LOG = new StringBuilder();
    private static int regs;

    private static void log(String line) {
        synchronized (LOG) {
            LOG.append(SystemClock.uptimeMillis() % 1000000).append(' ').append(line).append('\n');
            if (LOG.length() > 6000) LOG.delete(0, LOG.length() - 5000);
        }
    }

    private static boolean no(String why) {
        log("nextClick=false: " + why);
        return false;
    }

    /** Gancho al inicio de Ljh0.K(Z) (siguiente): anota quien llamo (pila) y copia el log al portapapeles. */
    public static void dbgK(final Object jh0) {
        try {
            StackTraceElement[] st = new Throwable().getStackTrace();
            StringBuilder sb = new StringBuilder("K() llamado desde:");
            for (int i = 1; i < st.length && i < 14; i++) {
                sb.append("\n   ").append(st[i].getClassName()).append('.').append(st[i].getMethodName())
                        .append(':').append(st[i].getLineNumber());
            }
            log(sb.toString());
            Field f = jh0.getClass().getDeclaredField("a");
            f.setAccessible(true);
            final Context ctx = ((Context) f.get(jh0)).getApplicationContext();
            final String text;
            synchronized (LOG) {
                text = "MiniSlide 369 | registros Lts6=" + regs + "\n" + LOG;
            }
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("MiniSlide", text));
                        Toast.makeText(ctx, "Log copiado", Toast.LENGTH_SHORT).show();
                    } catch (Throwable t) {
                        Log.w(TAG, "copiar", t);
                    }
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "dbgK", t);
        }
    }

    public static void register(Object o) {
        ts6 = new WeakReference<>(o);
        regs++;
        log("registrado Lts6 #" + regs);
    }

    private static Object field(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name);
        f.setAccessible(true);
        return f.get(o);
    }

    /** @return true si se lanzo el deslizamiento (el boton no debe hacer nada mas). */
    public static boolean nextClick(int mode, Object click) {
        try {
            if (mode == 9 || mode == 10 || mode == 13 || mode == 14 || mode == 17 || mode == 19 || mode == 22 || mode == 27) log("Ln40 caso " + mode);
            if (mode != NEXT_CASE) return false;
            WeakReference<Object> r = ts6;
            Object ts = r == null ? null : r.get();
            if (ts == null) return no("Lts6 no registrado");
            long now = SystemClock.uptimeMillis();
            if (now - last < 350) return no("toque muy seguido"); // toques muy seguidos: hace lo de siempre (salta directo)

            Object scope = field(ts, "s");
            Object offsetState = field(ts, "t");
            Object qt = field(ts, "u");
            Object ll8 = field(ts, "v");
            Object le8 = field(ts, "x");
            Object jh0 = field(ts, "y");
            Object a = field(ts, "z");
            Object te7b = field(ts, "A");
            Object b = field(ts, "B");
            Object c = field(ts, "C");
            if (scope == null || offsetState == null || qt == null || ll8 == null || le8 == null
                    || jh0 == null || a == null || te7b == null || b == null || c == null) return no("campo nulo en Lts6");
            Field fq = ts.getClass().getDeclaredField("q");
            fq.setAccessible(true);
            float density = fq.getFloat(ts);
            Field fw = ts.getClass().getDeclaredField("w");
            fw.setAccessible(true);
            boolean w = fw.getBoolean(ts);

            Method h = offsetState.getClass().getDeclaredMethod("h");
            h.setAccessible(true);
            float offset = ((Number) h.invoke(offsetState)).floatValue();
            if (Math.abs(offset) > 1f) return no("offset=" + offset); // ya hay un deslizamiento en curso

            // Lvs6 compara |ll8.q| con |offset|: con ll8.q = 0 siempre confirma el cambio (no lo cancela)
            Field fl = ll8.getClass().getDeclaredField("q");
            fl.setAccessible(true);
            fl.setFloat(ll8, 0f);

            if (ctor == null) {
                Class<?> k = Class.forName("vs6");
                for (Constructor<?> cc : k.getDeclaredConstructors()) {
                    Class<?>[] p = cc.getParameterTypes();
                    if (p.length == 13 && p[0].getName().equals("qt") && p[1] == float.class && p[5] == int.class) {
                        cc.setAccessible(true);
                        ctor = cc;
                        break;
                    }
                }
            }
            if (launch == null) {
                Class<?> kx = Class.forName("kxb");
                for (Method mm : kx.getDeclaredMethods()) {
                    Class<?>[] p = mm.getParameterTypes();
                    if (mm.getName().equals("I") && Modifier.isStatic(mm.getModifiers()) && p.length == 5
                            && p[4] == int.class && p[3].getName().equals("tk3") && p[0].getName().equals("o12")) {
                        mm.setAccessible(true);
                        launch = mm;
                        break;
                    }
                }
            }
            if (ctor == null || launch == null) return no("no halle ctor Lvs6=" + (ctor != null) + " launch kxb.I=" + (launch != null));
            // direccion +1 = siguiente (Lvs6: direccion > 0 -> Ljh0.K(false)); desliza hacia la izquierda
            Object job = ctor.newInstance(qt, offset, ll8, density, w, 1, le8, jh0, a, te7b, b, c, null);
            launch.invoke(null, scope, null, null, job, 3);
            last = now;
            log("nextClick=true: deslizamiento lanzado, offset=" + offset + " ancho=" + density);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "nextClick", t);
            return no("excepcion " + t);
        }
    }
}
