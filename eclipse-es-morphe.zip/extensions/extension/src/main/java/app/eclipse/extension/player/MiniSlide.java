package app.eclipse.extension.player;

import android.os.SystemClock;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * v0.20.367 (SIN COMPILAR NI PROBAR). Mini reproductor de la skin Native ("Apple Music"): al tocar SIGUIENTE o ANTERIOR con el BOTON
 * hace el mismo deslizamiento que al soltar el dedo tras arrastrar.
 * Al soltar el dedo, Eclipse lanza `Lrj3(F offset, F distancia, Lqt, Lsf4, Ljh0, Luh6, tz1)`: anima el desplazamiento del contenido a +-distancia
 * (200 ms), llama a siguiente (offset &lt; 0) o anterior (offset &gt;= 0) y vuelve el desplazamiento a 0. Aqui se lanza ese mismo trabajo desde el boton.
 * `register` (Lsj3.<init>) guarda el Animatable (Lqt) y la distancia; `go` (Lij3.a, modos 0 = anterior y 2 = siguiente) lo lanza.
 * Todo por reflexion y en try/catch: si algo no cuadra devuelve false y el boton hace lo de siempre.
 */
public final class MiniSlide {
    private static final String TAG = "MiniSlide";
    private static volatile Object qt;
    private static volatile float dist;
    private static volatile long last;
    private static Constructor<?> ctor;
    private static Method launch;
    private static Method offsetGetter;

    private MiniSlide() {}

    public static void register(Object q, float d) {
        qt = q;
        dist = d;
    }

    /** @return true si se lanzo el deslizamiento (el boton no debe hacer nada mas). */
    public static boolean go(int mode, Object scope, Object sf4, Object jh0, Object uh6) {
        try {
            if (mode != 0 && mode != 2) return false;
            Object q = qt;
            float d = dist;
            if (q == null || scope == null || sf4 == null || jh0 == null || uh6 == null || !(d > 0f)) return false;
            long now = SystemClock.uptimeMillis();
            if (now - last < 350) return false; // toques muy seguidos: hace lo de siempre (salta directo)
            if (offsetGetter == null) {
                for (Method m : q.getClass().getDeclaredMethods()) {
                    if (m.getName().equals("d") && m.getParameterTypes().length == 0 && m.getReturnType() == Object.class) {
                        m.setAccessible(true);
                        offsetGetter = m;
                        break;
                    }
                }
            }
            if (offsetGetter != null) {
                Object v = offsetGetter.invoke(q);
                if (v instanceof Number && Math.abs(((Number) v).floatValue()) > 1f) return false; // ya hay un deslizamiento en curso
            }
            if (ctor == null) {
                Class<?> k = Class.forName("rj3");
                for (Constructor<?> c : k.getDeclaredConstructors()) {
                    Class<?>[] p = c.getParameterTypes();
                    if (p.length == 7 && p[0] == float.class && p[1] == float.class && p[2].getName().equals("qt")) {
                        c.setAccessible(true);
                        ctor = c;
                        break;
                    }
                }
            }
            if (launch == null) {
                Class<?> kx = Class.forName("kxb");
                for (Method mm : kx.getDeclaredMethods()) {
                    Class<?>[] p = mm.getParameterTypes();
                    if (mm.getName().equals("I") && Modifier.isStatic(mm.getModifiers()) && p.length == 5
                            && p[4] == int.class && p[3].getName().equals("tk3") && p[0].getName().equals("o12")) {
                        mm.setAccessible(true);
                        launch = mm;
                        break;
                    }
                }
            }
            if (ctor == null || launch == null) return false;
            // 1er valor: signo del deslizamiento (negativo = siguiente, hacia la izquierda; positivo = anterior).
            Object job = ctor.newInstance(mode == 2 ? -1f : 1f, d, q, sf4, jh0, uh6, null);
            launch.invoke(null, scope, null, null, job, 3);
            last = now;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "go", t);
            return false;
        }
    }
}
