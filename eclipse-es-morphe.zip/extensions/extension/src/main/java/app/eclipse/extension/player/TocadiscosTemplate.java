package app.eclipse.extension.player;

import org.json.JSONObject;

/**
 * v0.20.412 (SIN COMPILAR EN GITHUB NI PROBAR EN EL CEL): tarjeta "Tocadiscos" de los Reproductores integrados.
 * El diseno (JSON de ~1,2 MB con las imagenes del disco y el brazo) NO va como constante Java (limite de 64 KB):
 * va como recurso raw "tocadiscos_design" que agrega el parche de recursos. Se apoya en BitchordTemplate para el resto.
 */
public final class TocadiscosTemplate {
    private TocadiscosTemplate() {}

    /** Nombre del diseno interno de la tarjeta (se oculta de "Your Custom Players"). Si cambia el diseno, el sello lo renueva solo. */
    static final String CARD_NAME = "Tocadiscos 1 (integrado)";
    private static final String RES_NAME = "tocadiscos_design";

    /** Bytes del recurso raw. */
    private static byte[] bytes() throws Exception {
        Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
        if (!(app instanceof android.content.Context)) throw new IllegalStateException("Tocadiscos: sin contexto");
        android.content.Context ctx = (android.content.Context) app;
        int id = ctx.getResources().getIdentifier(RES_NAME, "raw", ctx.getPackageName());
        if (id == 0) throw new IllegalStateException("Tocadiscos: falta el recurso " + RES_NAME);
        java.io.InputStream in = ctx.getResources().openRawResource(id);
        try {
            java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(1 << 21);
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        } finally {
            in.close();
        }
    }

    public static JSONObject json() {
        try {
            return new JSONObject(new String(bytes(), "UTF-8"));
        } catch (Exception e) {
            throw new RuntimeException("Tocadiscos: JSON invalido", e);
        }
    }

    public static JSONObject jsonCard() {
        JSONObject o = json();
        try {
            o.put("name", CARD_NAME);
        } catch (Exception ignored) {
        }
        return o;
    }

    /** Sello barato del diseno (hash de los bytes del recurso): si no cambia, no se vuelve a escribir. */
    static String stamp() throws Exception {
        byte[] b = bytes();
        return Integer.toHexString(java.util.Arrays.hashCode(b)) + "-" + b.length;
    }

    /** Id del diseno interno de la tarjeta Tocadiscos entre los disenos del usuario, o null. */
    public static String existingId(Object designs) {
        try {
            if (!(designs instanceof Iterable)) return null;
            for (Object d : (Iterable<?>) designs) {
                if (d == null) continue;
                if (CARD_NAME.equals(BitchordTemplate.field(d, "b"))) {
                    Object id = BitchordTemplate.field(d, "a");
                    if (id instanceof String) return (String) id;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}
