package app.eclipse.extension.diag;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Diagnostico temporal: cada vez que Eclipse dibuja una imagen (by9.c o bc2.f) se mira quien la llamo
 * (la pila de llamadas). Las pilas distintas se juntan y se copian al portapapeles, para pegarlas en el chat.
 * Sirve para ubicar la funcion que dibuja la portada del reproductor. Nunca lanza excepciones.
 */
@SuppressWarnings("unused")
public final class CoverDiag {
    private static final String TAG = "CoverDiag";
    private static final int MAX_ENTRIES = 40;
    private static final Set<String> seen = new LinkedHashSet<String>();

    private CoverDiag() {}

    public static void hitC() { record("by9.c"); }

    public static void hitF() { record("bc2.f"); }

    private static void record(String origin) {
        try {
            StackTraceElement[] st = new Throwable().getStackTrace();
            StringBuilder sb = new StringBuilder(origin).append(" <- ");
            int n = 0;
            for (StackTraceElement e : st) {
                String c = e.getClassName();
                if (c.startsWith("app.eclipse.extension") || c.startsWith("java.") || c.startsWith("android.")
                        || c.startsWith("androidx.") || c.startsWith("kotlin.") || c.startsWith("dalvik.")
                        || c.startsWith("com.android.")) continue;
                if (c.equals("by9") || c.equals("bc2")) continue;
                if (n > 0) sb.append(" < ");
                sb.append(c).append('.').append(e.getMethodName()).append(':').append(e.getLineNumber());
                if (++n >= 6) break;
            }
            final String entry = sb.toString();
            final String all;
            synchronized (seen) {
                if (seen.size() >= MAX_ENTRIES || !seen.add(entry)) return;
                StringBuilder out = new StringBuilder();
                int i = 1;
                for (String s : seen) out.append(i++).append(") ").append(s).append('\n');
                all = out.toString();
            }
            Log.d(TAG, entry);
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (!(app instanceof Context)) return;
            final Context ctx = (Context) app;
            final int count;
            synchronized (seen) { count = seen.size(); }
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("CoverDiag", all));
                        Toast.makeText(ctx, "Diag portada: " + count + " (copiado)", Toast.LENGTH_SHORT).show();
                    } catch (Throwable ignored) {}
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "record fallo: " + t);
        }
    }
}
