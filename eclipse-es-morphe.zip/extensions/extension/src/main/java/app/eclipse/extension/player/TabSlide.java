package app.eclipse.extension.player;

import android.app.Activity;
import android.app.Application;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.Map;

/**
 * v0.20.461 (SIN COMPILAR NI PROBAR). Skin Native: al tocar una pestana, la pantalla vieja (captura con PixelCopy) se
 * desliza y se borra rapido encima, y la nueva entra desde el lado de la pestana tocada con fundido. La nueva se mueve con
 * un graphicsLayer sobre el contenedor de la pagina ({@link #page}). Reloj propio (Choreographer): dura siempre lo mismo,
 * sin importar la escala de animacion del telefono. La franja de abajo (mini reproductor y barra) no se mueve.
 * Todo es mejor esfuerzo: si algo falla, no hace nada y la app sigue normal.
 */
public final class TabSlide {
    private static final long DURATION_MS = 300L;       // real, no depende de la escala de animacion
    private static final float SLIDE_FRACTION = 0.10f;  // pantalla vieja: se va un 10 % del ancho
    private static final float IN_FRACTION = 0.05f;     // pantalla nueva: entra desde un 5 % del ancho
    private static final float OUT_FADE_END = 0.45f;    // la vieja ya no se ve al 45 % del tiempo
    private static final float IN_FADE_END = 0.60f;     // la nueva esta completa al 60 % del tiempo
    private static final float IN_ALPHA_START = 0.40f;  // no empieza en 0 para que no se vea oscuro
    private static final float BOTTOM_DP = 150f;       // franja de abajo que NO se mueve (mini player + barra)
    private static final long MIN_GAP_MS = 320L;       // ignora toques seguidos

    private static boolean broken = false;
    private static boolean lifecycleTried = false;
    private static long last = 0L;
    private static WeakReference<Activity> actual;

    // Pantalla nueva. Se usa solo en el hilo principal.
    private static boolean pageBroken = false;
    private static Object state;      // estado de Compose (Lxe7) con el avance 0..1; 1 = quieto
    private static Object layer;      // bloque de graphicsLayer (Lfk3)
    private static Method layerMethod, getValue, setValue, setTx, setAlpha;
    private static float inOffsetPx = 0f;
    private static Runnable running;  // termina la animacion en curso

    private TabSlide() { }

    /** Inicio de `Lxs6;->l(Lcy6;)V` (se toco una pestana). `nav` = Lxs6, `tab` = Lcy6 nueva. */
    public static void before(Object nav, Object tab) {
        try {
            if (broken || nav == null || tab == null) return;
            if (Looper.myLooper() != Looper.getMainLooper()) return;
            long now = System.currentTimeMillis();
            if (now - last < MIN_GAP_MS) return;

            Method e = nav.getClass().getMethod("e");
            Object old = e.invoke(nav);
            if (old == null || old == tab) return;
            int dir = position(tab) > position(old) ? -1 : 1; // hacia la derecha: la vieja sale a la izquierda
            last = now;

            trackActivity();
            final Activity a = findActivity();
            if (a == null || a.isFinishing()) return;
            final View decor = a.getWindow().getDecorView();
            final int w = decor.getWidth();
            final int h = decor.getHeight();
            if (w <= 0 || h <= 0 || !(decor instanceof ViewGroup)) return;

            final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            final int d = dir;
            PixelCopy.request(a.getWindow(), bmp, new PixelCopy.OnPixelCopyFinishedListener() {
                @Override public void onPixelCopyFinished(int result) {
                    if (result != PixelCopy.SUCCESS) { bmp.recycle(); return; }
                    try {
                        overlay(a, bmp, d);
                    } catch (Throwable t) {
                        broken = true;
                    }
                }
            }, new Handler(Looper.getMainLooper()));
        } catch (Throwable t) {
            broken = true;
        }
    }

    private static void overlay(Activity a, Bitmap bmp, int dir) {
        final ViewGroup decor = (ViewGroup) a.getWindow().getDecorView();
        final int w = bmp.getWidth();
        int bottom = Math.round(BOTTOM_DP * a.getResources().getDisplayMetrics().density);
        int hCut = Math.max(1, bmp.getHeight() - bottom);

        final FrameLayout box = new FrameLayout(a);
        box.setClipChildren(true);
        box.setClickable(false);
        box.setFocusable(false);
        final ImageView iv = new ImageView(a);
        iv.setImageBitmap(bmp);
        iv.setScaleType(ImageView.ScaleType.FIT_START);
        iv.setClickable(false);
        box.addView(iv, new FrameLayout.LayoutParams(w, bmp.getHeight()));
        if (running != null) running.run();
        decor.addView(box, new FrameLayout.LayoutParams(w, hCut));
        animate(decor, box, iv, w, dir);
    }

    private static void animate(final ViewGroup decor, final View box, final View old, final int w, final int dir) {
        inOffsetPx = -dir * w * IN_FRACTION;
        progress(0f);
        final Handler handler = new Handler(Looper.getMainLooper());
        final boolean[] done = {false};
        final Runnable finish = new Runnable() {
            @Override public void run() {
                if (done[0]) return;
                done[0] = true;
                running = null;
                handler.removeCallbacks(this);
                progress(1f);
                try { decor.removeView(box); } catch (Throwable ignored) { }
            }
        };
        running = finish;
        handler.postDelayed(finish, DURATION_MS + 1000L); // seguro por si no llegan cuadros
        Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback() {
            private long start = -1L;
            @Override public void doFrame(long nanos) {
                if (done[0]) return;
                try {
                    if (start < 0L) start = nanos;
                    float p = Math.min(1f, (nanos - start) / (DURATION_MS * 1000000f));
                    old.setTranslationX(dir * w * SLIDE_FRACTION * ease(p));
                    old.setAlpha(Math.max(0f, 1f - p / OUT_FADE_END));
                    progress(p);
                    if (p >= 1f) finish.run();
                    else Choreographer.getInstance().postFrameCallback(this);
                } catch (Throwable t) {
                    broken = true;
                    finish.run();
                }
            }
        });
    }

    /** Frenado suave al final. */
    private static float ease(float p) {
        float r = 1f - p;
        return 1f - r * r * r;
    }

    /** Orden en la barra de Native: Inicio, Novedades, Radio, Biblioteca, Buscar (no es el orden del enum). */
    private static int position(Object tab) {
        String n = ((Enum<?>) tab).name();
        if ("HOME".equals(n)) return 0;
        if ("NEW".equals(n)) return 1;
        if ("RADIO".equals(n)) return 2;
        if ("LIBRARY".equals(n)) return 3;
        return 4;
    }

    /**
     * Se llama en `Lfm6;->r` con el Modifier (Lrb6) del contenedor de la pagina; devuelve el mismo Modifier con un
     * graphicsLayer (`Lvb8;->B`) que lee el avance. Si algo falla devuelve el original.
     */
    public static Object page(Object modifier) {
        if (pageBroken || modifier == null) return modifier;
        try {
            if (layer == null) setUpLayer();
            return layerMethod.invoke(null, modifier, layer);
        } catch (Throwable t) {
            pageBroken = true;
            return modifier;
        }
    }

    private static void setUpLayer() throws Exception {
        ClassLoader cl = TabSlide.class.getClassLoader();
        Class<?> modifierClass = Class.forName("rb6", false, cl);
        Class<?> function = Class.forName("fk3", false, cl);   // Function1
        Class<?> scope = Class.forName("oq3", false, cl);      // GraphicsLayerScope
        setTx = scope.getMethod("r", float.class);             // translationX
        setAlpha = scope.getMethod("m", float.class);          // alpha
        layerMethod = Class.forName("vb8", false, cl).getMethod("B", modifierClass, function);
        state = Class.forName("xf8", true, cl).getMethod("w", Object.class).invoke(null, Float.valueOf(1f));
        getValue = state.getClass().getMethod("getValue");
        setValue = state.getClass().getMethod("setValue", Object.class);
        Object unit = null;
        try {
            Field f = Class.forName("scb", true, cl).getField("a");
            unit = f.get(null);
        } catch (Throwable ignored) { }
        final Object result = unit;
        layer = Proxy.newProxyInstance(cl, new Class<?>[]{function}, new InvocationHandler() {
            @Override public Object invoke(Object self, Method m, Object[] args) {
                String name = m.getName();
                if ("equals".equals(name)) return args != null && self == args[0];
                if ("hashCode".equals(name)) return System.identityHashCode(self);
                if ("toString".equals(name)) return "TabSlideLayer";
                try {
                    float p = (Float) getValue.invoke(state); // leerlo aqui hace que se redibuje al cambiar
                    float x = 0f;
                    float alpha = 1f;
                    if (p < 1f) {
                        x = inOffsetPx * (1f - ease(p));
                        alpha = IN_ALPHA_START + (1f - IN_ALPHA_START) * Math.min(1f, p / IN_FADE_END);
                    }
                    setTx.invoke(args[0], x);
                    setAlpha.invoke(args[0], alpha);
                } catch (Throwable t) {
                    pageBroken = true;
                }
                return result;
            }
        });
    }

    private static void progress(float p) {
        if (state == null) return;
        try {
            setValue.invoke(state, Float.valueOf(p));
        } catch (Throwable t) {
            pageBroken = true;
        }
    }

    /** Sigue cual es la actividad visible. Mejor esfuerzo (mismo metodo que ArmSeek). */
    private static void trackActivity() {
        if (lifecycleTried) return;
        lifecycleTried = true;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Application) {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
            }
        } catch (Throwable t) {
            // sin seguimiento: se usa la busqueda directa
        }
    }

    @SuppressWarnings("unchecked")
    private static Activity findActivity() {
        Activity a = actual == null ? null : actual.get();
        if (a != null) return a;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return (Activity) act;
                }
            }
        } catch (Throwable t) {
            // sin actividad
        }
        return null;
    }
}
