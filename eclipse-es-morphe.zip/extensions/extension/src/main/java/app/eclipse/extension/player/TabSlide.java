package app.eclipse.extension.player;

import android.app.Activity;
import android.app.Application;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.PixelCopy;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Map;

/**
 * v0.20.460 (SIN COMPILAR NI PROBAR). Skin Native: al tocar una pestana, la pantalla vieja (captura con PixelCopy) se queda
 * encima, se desvanece y se desplaza un poco hacia el lado (segun el orden de las pestanas) y deja ver la nueva debajo.
 * Se recorta la franja de abajo (mini reproductor y barra de pestanas) para que esa parte no se mueva.
 * Todo es mejor esfuerzo: si algo falla, no hace nada y la app sigue normal.
 */
public final class TabSlide {
    private static final long DURATION_MS = 220L;
    private static final float SLIDE_FRACTION = 0.10f; // desplazamiento = 10 % del ancho
    private static final float BOTTOM_DP = 150f;       // franja de abajo que NO se mueve (mini player + barra)
    private static final long MIN_GAP_MS = 250L;       // ignora toques seguidos

    private static boolean broken = false;
    private static boolean lifecycleTried = false;
    private static long last = 0L;
    private static WeakReference<Activity> actual;

    private TabSlide() { }

    /** Inicio de `Lxs6;->l(Lcy6;)V` (se toco una pestana). `nav` = Lxs6, `tab` = Lcy6 nueva. */
    public static void before(Object nav, Object tab) {
        try {
            if (broken || nav == null || tab == null) return;
            if (Looper.myLooper() != Looper.getMainLooper()) return;
            long now = System.currentTimeMillis();
            if (now - last < MIN_GAP_MS) return;

            Method e = nav.getClass().getMethod("e");
            Object old = e.invoke(nav);
            if (old == null || old == tab) return;
            int dir = ((Enum<?>) tab).ordinal() > ((Enum<?>) old).ordinal() ? -1 : 1; // sube: la vieja sale a la izquierda
            last = now;

            trackActivity();
            final Activity a = findActivity();
            if (a == null || a.isFinishing()) return;
            final View decor = a.getWindow().getDecorView();
            final int w = decor.getWidth();
            final int h = decor.getHeight();
            if (w <= 0 || h <= 0 || !(decor instanceof ViewGroup)) return;

            final Bitmap bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            final int d = dir;
            PixelCopy.request(a.getWindow(), bmp, new PixelCopy.OnPixelCopyFinishedListener() {
                @Override public void onPixelCopyFinished(int result) {
                    if (result != PixelCopy.SUCCESS) { bmp.recycle(); return; }
                    try {
                        overlay(a, bmp, d);
                    } catch (Throwable t) {
                        broken = true;
                    }
                }
            }, new Handler(Looper.getMainLooper()));
        } catch (Throwable t) {
            broken = true;
        }
    }

    private static void overlay(Activity a, Bitmap bmp, int dir) {
        final ViewGroup decor = (ViewGroup) a.getWindow().getDecorView();
        final int w = bmp.getWidth();
        int bottom = Math.round(BOTTOM_DP * a.getResources().getDisplayMetrics().density);
        int hCut = Math.max(1, bmp.getHeight() - bottom);

        final FrameLayout box = new FrameLayout(a);
        box.setClipChildren(true);
        box.setClickable(false);
        box.setFocusable(false);
        final ImageView iv = new ImageView(a);
        iv.setImageBitmap(bmp);
        iv.setScaleType(ImageView.ScaleType.FIT_START);
        iv.setClickable(false);
        box.addView(iv, new FrameLayout.LayoutParams(w, bmp.getHeight()));
        decor.addView(box, new FrameLayout.LayoutParams(w, hCut));

        iv.animate()
                .alpha(0f)
                .translationX(dir * w * SLIDE_FRACTION)
                .setDuration(DURATION_MS)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        try { decor.removeView(box); } catch (Throwable ignored) { }
                    }
                })
                .start();
    }

    /** Sigue cual es la actividad visible. Mejor esfuerzo (mismo metodo que ArmSeek). */
    private static void trackActivity() {
        if (lifecycleTried) return;
        lifecycleTried = true;
        try {
            Object app = Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null);
            if (app instanceof Application) {
                ((Application) app).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override public void onActivityResumed(Activity a) { actual = new WeakReference<Activity>(a); }
                    @Override public void onActivityPaused(Activity a) {
                        Activity c = actual == null ? null : actual.get();
                        if (c == a) actual = null;
                    }
                    @Override public void onActivityCreated(Activity a, Bundle b) { }
                    @Override public void onActivityStarted(Activity a) { }
                    @Override public void onActivityStopped(Activity a) { }
                    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
                    @Override public void onActivityDestroyed(Activity a) { }
                });
            }
        } catch (Throwable t) {
            // sin seguimiento: se usa la busqueda directa
        }
    }

    @SuppressWarnings("unchecked")
    private static Activity findActivity() {
        Activity a = actual == null ? null : actual.get();
        if (a != null) return a;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            Field fa = at.getDeclaredField("mActivities");
            fa.setAccessible(true);
            Map<Object, Object> mapa = (Map<Object, Object>) fa.get(thread);
            for (Object rec : mapa.values()) {
                Field fp = rec.getClass().getDeclaredField("paused");
                fp.setAccessible(true);
                if (fp.getBoolean(rec)) continue;
                Field fact = rec.getClass().getDeclaredField("activity");
                fact.setAccessible(true);
                Object act = fact.get(rec);
                if (act instanceof Activity) {
                    actual = new WeakReference<Activity>((Activity) act);
                    return (Activity) act;
                }
            }
        } catch (Throwable t) {
            // sin actividad
        }
        return null;
    }
}
