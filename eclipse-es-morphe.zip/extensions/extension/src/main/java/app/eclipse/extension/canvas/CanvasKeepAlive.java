package app.eclipse.extension.canvas;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.WeakHashMap;

/**
 * Ayuda del parche "Canvas: mantener el video vivo (pausar al salir)". v0.20.197 (SIN COMPILAR NI PROBAR).
 *
 * Eclipse 0.6.57: la pantalla del video animado (n34.h, Canvas y portadas animadas de Tidal / Apple) crea su ExoPlayer con
 * n34.v(Context, url, cap, flag) dentro de un `remember`, y al salir de la pantalla (cerrar el reproductor, ir a Letra o
 * Cola) un efecto de limpieza (Gn caso 5) le quita el oyente y lo LIBERA (gz2.p3). Al volver se crea otro desde cero.
 *
 * Aqui, en vez de liberarlo, se PAUSA y se guarda unos minutos; si la pantalla vuelve a pedir el mismo video (misma
 * direccion y mismos parametros) se le devuelve el que estaba guardado, ya cargado y en la misma posicion.
 *
 * Nombres de 0.6.57 (por reflexion, porque el dex esta ofuscado): gz2.e0(Z) = setPlayWhenReady, gz2.m() = estado de
 * reproduccion (3 = listo), gz2.p3() = release. El oyente de n34.h es i80; su metodo u(int) = onPlaybackStateChanged:
 * con 3 enciende el estado "listo" que hace aparecer el video.
 *
 * Todo corre en el hilo principal (composicion de Compose). Si algo falla se hace lo que hacia Eclipse (liberar).
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasKeepAlive {
    private static final String TAG = "CanvasKeepAlive";

    /** Cuantos videos pausados se guardan como maximo (portada + fondo = 2). */
    private static final int MAX_PARKED = 2;
    /** Tiempo maximo guardado sin que nadie lo pida (ms). Pasado esto se libera. */
    private static final long TTL_MS = 120_000L;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static final class Key {
        final String url;
        final int cap;
        final boolean flag;

        Key(String url, int cap, boolean flag) {
            this.url = url;
            this.cap = cap;
            this.flag = flag;
        }

        boolean matches(String u, int c, boolean f) {
            return cap == c && flag == f && url != null && url.equals(u);
        }
    }

    private static final class Parked {
        final Object player;
        final Key key;
        Runnable expire;

        Parked(Object player, Key key) {
            this.player = player;
            this.key = key;
        }
    }

    /** Videos creados por n34.v desde n34.h y aun vivos (guardados o en pantalla). Clave = el ExoPlayer. */
    private static final WeakHashMap<Object, Key> LIVE = new WeakHashMap<Object, Key>();
    /** Videos que se acaban de devolver desde la caja y aun no han registrado su oyente nuevo. */
    private static final WeakHashMap<Object, Boolean> REUSED = new WeakHashMap<Object, Boolean>();
    private static final ArrayList<Parked> PARKED = new ArrayList<Parked>();

    private CanvasKeepAlive() {}

    // ------------------------------------------------------------------ ganchos

    /**
     * Llamado en n34.h justo antes de n34.v. Devuelve un video guardado que coincida (ya pausado y cargado) o null para que
     * Eclipse cree uno nuevo como siempre.
     */
    public static Object take(String url, int cap, boolean flag) {
        try {
            synchronized (PARKED) {
                for (int i = 0; i < PARKED.size(); i++) {
                    Parked p = PARKED.get(i);
                    if (!p.key.matches(url, cap, flag)) continue;
                    PARKED.remove(i);
                    if (p.expire != null) MAIN.removeCallbacks(p.expire);
                    int st = state(p.player);
                    // 1 = IDLE (error o ya liberado), 4 = ENDED: no sirve, se libera y se crea uno nuevo.
                    if (st == 2 || st == 3) {
                        REUSED.put(p.player, Boolean.TRUE);
                        Log.d(TAG, "reutilizado (estado " + st + "): " + url);
                        return p.player;
                    }
                    realRelease(p.player);
                    return null;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "take: " + t);
        }
        return null;
    }

    /** Llamado en n34.h justo despues de crear un video nuevo con n34.v (puede llegar null). */
    public static void register(Object player, String url, int cap, boolean flag) {
        try {
            if (player == null) return;
            synchronized (PARKED) {
                LIVE.put(player, new Key(url, cap, flag));
            }
        } catch (Throwable t) {
            Log.w(TAG, "register: " + t);
        }
    }

    /**
     * Reemplaza a gz2.p3() (release) en el efecto de limpieza de n34.h. Pausa el video y lo guarda; si no se puede,
     * lo libera como hacia Eclipse.
     */
    public static void release(Object player, Object listener) {
        if (player == null) return;
        try {
            Key key;
            synchronized (PARKED) {
                key = LIVE.get(player);
            }
            if (key != null) {
                int st = state(player);
                if ((st == 2 || st == 3) && setPlayWhenReady(player, false)) {
                    park(player, key);
                    return;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "release (se libera): " + t);
        }
        realRelease(player);
    }

    /**
     * Llamado en f80 justo despues de registrar el oyente i80 en el video. Si el video viene de la caja y ya esta listo,
     * el aviso "listo" (estado 3) no se repetiria solo y el video quedaria escondido: se lo damos a mano.
     */
    public static void onAttached(Object player, Object listener) {
        try {
            if (player == null || listener == null) return;
            boolean reused;
            synchronized (PARKED) {
                reused = REUSED.remove(player) != null;
            }
            if (!reused) return;
            if (state(player) == 3) {
                Method u = listener.getClass().getDeclaredMethod("u", int.class);
                u.setAccessible(true);
                u.invoke(listener, 3);
                Log.d(TAG, "aviso de listo dado a mano");
            }
        } catch (Throwable t) {
            Log.w(TAG, "onAttached: " + t);
        }
    }

    // ------------------------------------------------------------------ guardado

    private static void park(final Object player, Key key) {
        final Parked p = new Parked(player, key);
        p.expire = new Runnable() {
            @Override public void run() {
                boolean removed;
                synchronized (PARKED) {
                    removed = PARKED.remove(p);
                }
                if (removed) {
                    Log.d(TAG, "vencido, se libera: " + p.key.url);
                    realRelease(p.player);
                }
            }
        };
        ArrayList<Object> toRelease = new ArrayList<Object>();
        synchronized (PARKED) {
            PARKED.add(p);
            while (PARKED.size() > MAX_PARKED) {
                Parked old = PARKED.remove(0);
                if (old.expire != null) MAIN.removeCallbacks(old.expire);
                toRelease.add(old.player);
            }
        }
        MAIN.postDelayed(p.expire, TTL_MS);
        for (Object o : toRelease) realRelease(o);
        Log.d(TAG, "pausado y guardado: " + key.url);
    }

    // ------------------------------------------------------------------ reflexion sobre el ExoPlayer (gz2)

    private static int state(Object player) {
        try {
            Method m = player.getClass().getMethod("m");
            m.setAccessible(true);
            Object r = m.invoke(player);
            return r instanceof Integer ? ((Integer) r).intValue() : 1;
        } catch (Throwable t) {
            return 1;
        }
    }

    private static boolean setPlayWhenReady(Object player, boolean play) {
        try {
            Method m = player.getClass().getMethod("e0", boolean.class);
            m.setAccessible(true);
            m.invoke(player, play);
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "no se pudo pausar: " + t);
            return false;
        }
    }

    private static void realRelease(Object player) {
        try {
            synchronized (PARKED) {
                LIVE.remove(player);
                REUSED.remove(player);
            }
            Method m = player.getClass().getMethod("p3");
            m.setAccessible(true);
            m.invoke(player);
        } catch (Throwable t) {
            Log.w(TAG, "release: " + t);
        }
    }
}
