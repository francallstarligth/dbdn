package app.eclipse.extension.canvas;

import android.content.Context;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Ayuda del parche "Canvas: cache compartida".
 *
 * Eclipse 0.6.57: n34.v crea el ExoPlayer de cada Canvas (oy2 con 3 parametros), cuya fabrica de fuentes
 * (vb0.get caso 1 -> u82(l24(ctx, 12), g72)) lee directo de la red, sin cache. Eclipse SI trae una cache de media3
 * (fw8.v.d(Context) -> ey8) y una fabrica de fuente con cache (az0) que usa para las canciones
 * (xe0.l). Aqui se envuelve la fuente de red de los ExoPlayer de los Canvas con esa misma cache, asi el segundo
 * reproductor (y los Canvas ya vistos) leen lo ya bajado.
 *
 * v0.20.201: solo para Canvas de Spotify y de la comunidad (ver allowed). Solo se envuelve mientras n34.v esta construyendo SU ExoPlayer (begin/end alrededor de oy2.a(), mismo hilo),
 * porque oy2 lo usan otros sitios de Eclipse que no se tocan. Si algo falla, wrap devuelve la fuente original.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasCache {
    private static final String TAG = "CanvasCache";
    /** Igual que xe0.l: FLAG_IGNORE_CACHE_ON_ERROR (az0.q = 2). */
    private static final int FLAGS = 2;
    /** Igual que xe0.l: u92(9) = fuente de lectura de la cache (az0.s). */
    private static final int READ_SOURCE_KIND = 9;

    private static volatile Thread active;

    private CanvasCache() {}

    /** v0.20.201: URL del Canvas que n34.v esta construyendo (la pone un gancho al inicio de n34.v, mismo hilo). */
    private static final ThreadLocal<String> CURRENT_URL = new ThreadLocal<String>();

    /** Llamado al inicio de n34.v(Context, String url, int, boolean). */
    public static void setUrl(String url) {
        try { CURRENT_URL.set(url); } catch (Throwable ignored) {}
    }

    /**
     * v0.20.201: la cache compartida es SOLO para Canvas de Spotify (canvaz.scdn.co) y de la lista de la comunidad.
     * Los de Tidal (archivo local o HLS) y Apple Music se dejan como los maneja Eclipse. Ante la duda (sin URL) no se envuelve.
     */
    static boolean allowed(String url) {
        try {
            if (url == null) return false;
            String low = url.toLowerCase(java.util.Locale.ROOT);
            if (!(low.startsWith("https://") || low.startsWith("http://"))) return false; // file:// y otros: no
            int s = low.indexOf("://") + 3;
            int e = low.indexOf('/', s);
            String host = e < 0 ? low.substring(s) : low.substring(s, e);
            int c = host.indexOf(':');
            if (c >= 0) host = host.substring(0, c);
            if (host.equals("scdn.co") || host.endsWith(".scdn.co")) return true;
            return CommunityCanvas.hasUrl(url);
        } catch (Throwable t) {
            return false;
        }
    }

    /** Llamado justo antes de oy2.a() dentro de n34.v. */
    public static void begin() {
        active = allowed(CURRENT_URL.get()) ? Thread.currentThread() : null;
    }

    /** Llamado justo despues de oy2.a() dentro de n34.v. */
    public static void end() {
        active = null;
    }

    /**
     * Llamado en u82.<init>(Context, g72) con la fuente de red por defecto (l24). Devuelve una az0 (fuente con cache) que
     * usa esa misma fuente de red como respaldo, o la original si no estamos construyendo un Canvas o algo falla.
     */
    public static Object wrap(Context ctx, Object upstream) {
        try {
            if (upstream == null || ctx == null || active != Thread.currentThread()) return upstream;
            Object ky0 = build(ctx, upstream);
            return ky0 != null ? ky0 : upstream;
        } catch (Throwable t) {
            Log.w(TAG, "sin cache para el Canvas (se usa la red directa): " + t);
            return upstream;
        }
    }

    /**
     * Arma una az0 (fabrica de fuente con cache) cuyo respaldo es `upstream`. Devuelve null si no hay cache.
     * Lo usa tambien CanvasPreload (que no pasa por begin/end).
     */
    static Object build(Context ctx, Object upstream) throws Exception {
        Class<?> ky0c = Class.forName("az0");
        Object ky0 = allocate(ky0c);

        Constructor<?> k = Class.forName("u92").getDeclaredConstructor(int.class);
        k.setAccessible(true);
        Object readSource = k.newInstance(READ_SOURCE_KIND);

        Class<?> au8c = Class.forName("fw8");
        Field u = au8c.getDeclaredField("v");
        u.setAccessible(true);
        Method b = au8c.getDeclaredMethod("d", Context.class);
        b.setAccessible(true);
        Object cache = b.invoke(u.get(null), ctx);
        if (cache == null) return null;

        put(ky0c, "s", ky0, readSource);
        put(ky0c, "r", ky0, cache);
        put(ky0c, "t", ky0, upstream);
        Field q = ky0c.getDeclaredField("q");
        q.setAccessible(true);
        q.setInt(ky0, FLAGS);
        return ky0;
    }

    private static void put(Class<?> c, String name, Object target, Object value) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        f.set(target, value);
    }

    /** Crea la instancia sin correr ningun constructor (igual que xe0.l, que llama a Object.<init> directo). */
    private static Object allocate(Class<?> c) throws Exception {
        Field f = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        f.setAccessible(true);
        Object unsafe = f.get(null);
        Method m = unsafe.getClass().getMethod("allocateInstance", Class.class);
        return m.invoke(unsafe, c);
    }
}
