package app.eclipse.extension.canvas;

import android.content.Context;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Ayuda del parche "Canvas: cache compartida".
 *
 * Eclipse 0.6.55: kw0.H crea el ExoPlayer de cada Canvas (ox2 con 3 parametros), cuya fabrica de fuentes
 * (nb0.get caso 1 -> v72(m14(ctx, 12), h62)) lee directo de la red, sin cache. Eclipse SI trae una cache de media3
 * (au8.v.d(Context) -> aw8) y una fabrica de fuente con cache (ky0) que usa para las canciones
 * (ie0.k). Aqui se envuelve la fuente de red de los ExoPlayer de los Canvas con esa misma cache, asi el segundo
 * reproductor (y los Canvas ya vistos) leen lo ya bajado.
 *
 * Solo se envuelve mientras kw0.H esta construyendo SU ExoPlayer (begin/end alrededor de ox2.a(), mismo hilo),
 * porque ox2 lo usan otros sitios de Eclipse que no se tocan. Si algo falla, wrap devuelve la fuente original.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasCache {
    private static final String TAG = "CanvasCache";
    /** Igual que ie0.k: FLAG_IGNORE_CACHE_ON_ERROR (ky0.q = 2). */
    private static final int FLAGS = 2;
    /** Igual que ie0.k: pb2(9) = fuente de lectura de la cache (ky0.s). */
    private static final int READ_SOURCE_KIND = 9;

    private static volatile Thread active;

    private CanvasCache() {}

    /** Llamado justo antes de ox2.a() dentro de kw0.H. */
    public static void begin() {
        active = Thread.currentThread();
    }

    /** Llamado justo despues de ox2.a() dentro de kw0.H. */
    public static void end() {
        active = null;
    }

    /**
     * Llamado en v72.<init>(Context, h62) con la fuente de red por defecto (m14). Devuelve una ky0 (fuente con cache) que
     * usa esa misma fuente de red como respaldo, o la original si no estamos construyendo un Canvas o algo falla.
     */
    public static Object wrap(Context ctx, Object upstream) {
        try {
            if (upstream == null || ctx == null || active != Thread.currentThread()) return upstream;
            Object ky0 = build(ctx, upstream);
            return ky0 != null ? ky0 : upstream;
        } catch (Throwable t) {
            Log.w(TAG, "sin cache para el Canvas (se usa la red directa): " + t);
            return upstream;
        }
    }

    /**
     * Arma una ky0 (fabrica de fuente con cache) cuyo respaldo es `upstream`. Devuelve null si no hay cache.
     * Lo usa tambien CanvasPreload (que no pasa por begin/end).
     */
    static Object build(Context ctx, Object upstream) throws Exception {
        Class<?> ky0c = Class.forName("ky0");
        Object ky0 = allocate(ky0c);

        Constructor<?> k = Class.forName("pb2").getDeclaredConstructor(int.class);
        k.setAccessible(true);
        Object readSource = k.newInstance(READ_SOURCE_KIND);

        Class<?> au8c = Class.forName("au8");
        Field u = au8c.getDeclaredField("v");
        u.setAccessible(true);
        Method b = au8c.getDeclaredMethod("d", Context.class);
        b.setAccessible(true);
        Object cache = b.invoke(u.get(null), ctx);
        if (cache == null) return null;

        put(ky0c, "s", ky0, readSource);
        put(ky0c, "r", ky0, cache);
        put(ky0c, "t", ky0, upstream);
        Field q = ky0c.getDeclaredField("q");
        q.setAccessible(true);
        q.setInt(ky0, FLAGS);
        return ky0;
    }

    private static void put(Class<?> c, String name, Object target, Object value) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        f.set(target, value);
    }

    /** Crea la instancia sin correr ningun constructor (igual que ie0.k, que llama a Object.<init> directo). */
    private static Object allocate(Class<?> c) throws Exception {
        Field f = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        f.setAccessible(true);
        Object unsafe = f.get(null);
        Method m = unsafe.getClass().getMethod("allocateInstance", Class.class);
        return m.invoke(unsafe, c);
    }
}
