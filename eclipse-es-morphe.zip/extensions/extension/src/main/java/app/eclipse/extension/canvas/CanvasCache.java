package app.eclipse.extension.canvas;

import android.content.Context;
import android.util.Log;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Ayuda del parche "Canvas: cache compartida".
 *
 * Eclipse 0.6.47: cada llamada a xi6.h crea su propio ExoPlayer con ro2 por defecto, cuya fabrica de fuentes
 * (g80 caso 2 -> lz1(aa5(ctx, 11), xx1)) lee directo de la red, sin cache. Eclipse SI trae una cache de media3
 * ("StreamCache", z38.b(Context) -> y28) y una fabrica de fuente con cache (ws0) que usa para las canciones
 * (x90.i). Aqui se envuelve la fuente de red de los ExoPlayer de los Canvas con esa misma cache, asi el segundo
 * reproductor (y los Canvas ya vistos) leen lo ya bajado.
 *
 * Solo se envuelve mientras xi6.h esta construyendo SU ExoPlayer (begin/end alrededor de ro2.a(), mismo hilo),
 * porque ro2 lo usan otros 7 sitios de Eclipse que no se tocan. Si algo falla, wrap devuelve la fuente original.
 */
@SuppressWarnings({"unused", "rawtypes", "unchecked"})
public final class CanvasCache {
    private static final String TAG = "CanvasCache";
    /** Igual que x90.i: FLAG_IGNORE_CACHE_ON_ERROR. */
    private static final int FLAGS = 2;
    /** Igual que x90.i: d32(9) = fuente de lectura de la cache. */
    private static final int READ_SOURCE_KIND = 9;

    private static volatile Thread active;

    private CanvasCache() {}

    /** Llamado justo antes de ro2.a() dentro de xi6.h. */
    public static void begin() {
        active = Thread.currentThread();
    }

    /** Llamado justo despues de ro2.a() dentro de xi6.h. */
    public static void end() {
        active = null;
    }

    /**
     * Llamado en g80.get (caso 2) con la fuente de red por defecto (aa5). Devuelve una ws0 (fuente con cache) que
     * usa esa misma fuente de red como respaldo, o la original si no estamos construyendo un Canvas o algo falla.
     */
    public static Object wrap(Context ctx, Object upstream) {
        try {
            if (upstream == null || ctx == null || active != Thread.currentThread()) return upstream;
            Object ws0 = build(ctx, upstream);
            return ws0 != null ? ws0 : upstream;
        } catch (Throwable t) {
            Log.w(TAG, "sin cache para el Canvas (se usa la red directa): " + t);
            return upstream;
        }
    }

    /**
     * Arma una ws0 (fabrica de fuente con cache) cuyo respaldo es `upstream`. Devuelve null si no hay cache.
     * Lo usa tambien CanvasPreload (que no pasa por begin/end).
     */
    static Object build(Context ctx, Object upstream) throws Exception {
        Class<?> ws0c = Class.forName("ws0");
        Object ws0 = allocate(ws0c);

        Constructor<?> k = Class.forName("d32").getDeclaredConstructor(int.class);
        k.setAccessible(true);
        Object readSource = k.newInstance(READ_SOURCE_KIND);

        Class<?> z38c = Class.forName("z38");
        Field u = z38c.getDeclaredField("u");
        u.setAccessible(true);
        Method b = z38c.getDeclaredMethod("b", Context.class);
        b.setAccessible(true);
        Object cache = b.invoke(u.get(null), ctx);
        if (cache == null) return null;

        put(ws0c, "s", ws0, readSource);
        put(ws0c, "r", ws0, cache);
        put(ws0c, "t", ws0, upstream);
        Field q = ws0c.getDeclaredField("q");
        q.setAccessible(true);
        q.setInt(ws0, FLAGS);
        return ws0;
    }

    private static void put(Class<?> c, String name, Object target, Object value) throws Exception {
        Field f = c.getDeclaredField(name);
        f.setAccessible(true);
        f.set(target, value);
    }

    /** Crea la instancia sin correr ningun constructor (igual que x90.i, que llama a Object.<init> directo). */
    private static Object allocate(Class<?> c) throws Exception {
        Field f = Class.forName("sun.misc.Unsafe").getDeclaredField("theUnsafe");
        f.setAccessible(true);
        Object unsafe = f.get(null);
        Method m = unsafe.getClass().getMethod("allocateInstance", Class.class);
        return m.invoke(unsafe, c);
    }
}
