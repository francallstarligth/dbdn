# Eclipse ES (parche Morphe)

Traduce la UI de Eclipse (`com.eclipse.android`, 0.6.47) al español en tiempo de ejecución.
Si el teléfono/app no está en español, el texto queda en inglés.

- `patches/`: parche "Spanish translation" (Kotlin). `SiteAnalyzer.kt` decide por sitio si es seguro traducir.
- `extensions/extension/`: `Translator.java` + `Dictionary.java` (generado).
- `patches/src/main/resources/eclipse/`: `dictionary_en_es.tsv` (1.181 entradas) y `risky.txt` (22 literales que no se tocan).
- `tools/gen_dictionary.py`: regenera `Dictionary.java` desde el TSV.

Usar junto con el parche **Spoof signature** de Morphe (no se cambia el paquete).

## Parches
- **Spanish translation** (activo por defecto).
- **Canvas (comunidad)** (opcional, `default = false`): cuando Eclipse no tiene portada animada, busca un video en bucle en una lista publica de la comunidad (sin cuenta ni cookie). El gancho esta en `qf2.a(...)` de Eclipse 0.6.47 y llama a `app.eclipse.extension.canvas.CanvasLookup.lookup(...)`. Se quito la fuente de Spotify.
- Opcion `debug` del parche Canvas (apagada por defecto): muestra avisos Toast con el paso donde se queda la busqueda.

- **Diagnostico de portadas (temporal)** (opcional, `default = false`): muestra un aviso con los datos de la cancion (ID de album de Apple y Tidal, ISRC, album) al buscar su portada animada. Gancho al inicio de `qf2.a(...)`. Desactivar despues de usar.

- **Apple Music: portadas en biblioteca** (opcional, `default = false`): `AppleLibraryArtworkPatch.kt`. En `qf2.c(Song, ew, Continuation)` salta el filtro que descartaba las canciones sin ID de pista de Apple (las de la biblioteca, id `addon:...`); asi tambien buscan la portada de Apple por artista+album. Verificado solo contra el smali; no probado en el telefono.
- **Pausar cancion anterior al cambiar** (opcional, `default = false`): pausa la cancion que sonaba en cuanto se elige otra (gancho en `x90.B`).
