# Eclipse ES (parche Morphe)

Traduce la interfaz de Eclipse (`com.eclipse.android`, 0.6.47) al español en tiempo de ejecución.
Solo traduce si el idioma del teléfono es español; si no, el texto queda en inglés.
No cambia el paquete ni necesita el parche "Spoof signature".

## Estructura
- `patches/`: parche "Spanish translation" (Kotlin). `SiteAnalyzer.kt` decide por sitio si es seguro traducir (descarta textos usados como claves, en comparaciones, JSON, etc.).
- `extensions/extension/`: `Translator.java` y `Dictionary.java` (generado).
- `patches/src/main/resources/eclipse/dictionary_en_es.tsv`: diccionario (1184 entradas, formato `inglés<TAB>español`).
- `patches/src/main/resources/eclipse/risky.txt`: literales que nunca se traducen (palabras sueltas que la app puede usar como claves). Sus traducciones guardadas están en `tools/risky_translations.tsv` (no se compilan).
- `tools/gen_dictionary.py`: regenera `Dictionary.java` desde el TSV. Ejecutarlo después de editar el TSV: `python3 tools/gen_dictionary.py`.

## Compilar
Sube `eclipse-es-morphe.zip` a la raíz del repo (o usa "Run workflow" en Actions). El workflow genera el `.mpp`, lo publica como release y actualiza `patches-bundle.json` para añadir la fuente en Morphe Manager por enlace.

Si recompilas con la misma versión (`gradle.properties`), Morphe Manager podría no detectar el cambio: sube el número.
