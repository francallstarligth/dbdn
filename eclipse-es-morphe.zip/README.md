# Eclipse ES (parche Morphe)

Traduce la UI de Eclipse (`com.eclipse.android`, 0.6.47) al español en tiempo de ejecución.
Si el teléfono/app no está en español, el texto queda en inglés.

- `patches/`: parche "Spanish translation" (Kotlin). `SiteAnalyzer.kt` decide por sitio si es seguro traducir.
- `extensions/extension/`: `Translator.java` + `Dictionary.java` (generado).
- `patches/src/main/resources/eclipse/`: `dictionary_en_es.tsv` (1.181 entradas) y `risky.txt` (22 literales que no se tocan).
- `tools/gen_dictionary.py`: regenera `Dictionary.java` desde el TSV.

Usar junto con el parche **Spoof signature** de Morphe (no se cambia el paquete).

## Parches
- **Spanish translation** (activo por defecto).
- **Spotify Canvas** (opcional, `default = false`): pide la cookie `sp_dc` al parchear; el gancho esta en `qf2.a(...)` de Eclipse 0.6.47 y llama a `app.eclipse.extension.spotify.SpotifyCanvas.lookup(...)`. Uso personal; Spotify podria restringir la cuenta.
