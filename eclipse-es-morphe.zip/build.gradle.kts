// Root build configuration for eclipse-es-morphe
