group = "app.eclipse"

patches {
    about {
        name = "Eclipse ES Patches"
        description = "Traduccion al espanol de Eclipse (com.eclipse.android)"
        source = "git@github.com:francallstarligth/eclipse-es-morphe.git"
        author = "francallstarligth"
        contact = "na"
        website = "na"
        license = "GPLv3"
    }
}
