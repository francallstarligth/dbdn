#!/usr/bin/env python3
"""Genera Dictionary.java desde patches/src/main/resources/eclipse/dictionary_en_es.tsv.
Uso (desde la raiz del proyecto): python3 tools/gen_dictionary.py
Trozos de 150 entradas por metodo (limite de 64 KB de bytecode por metodo)."""
import os
root=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
src=os.path.join(root,'patches/src/main/resources/eclipse/dictionary_en_es.tsv')
dst=os.path.join(root,'extensions/extension/src/main/java/app/eclipse/extension/es/Dictionary.java')
def lit(s):
    o=['"']
    for c in s:
        if c=='"': o.append('\\"')
        elif c=='\\': o.append('\\\\')
        elif c=='\n': o.append('\\n')
        elif ord(c)<32 or ord(c)>126: o.append('\\u%04x'%ord(c))
        else: o.append(c)
    o.append('"'); return ''.join(o)
rows=[l.rstrip('\n').split('\t',1) for l in open(src,encoding='utf-8') if '\t' in l]
chunks=[rows[i:i+150] for i in range(0,len(rows),150)]
out=['package app.eclipse.extension.es;','','import java.util.HashMap;','',
'/** GENERADO por tools/gen_dictionary.py. No editar a mano. */',
'final class Dictionary {','    private Dictionary() {}','',
'    static HashMap<String, String> build() {',
'        HashMap<String, String> m = new HashMap<>(%d);'%(len(rows)*2)]
out+=['        d%d(m);'%k for k in range(len(chunks))]
out+=['        return m;','    }','']
for k,ch in enumerate(chunks):
    out.append('    private static void d%d(HashMap<String, String> m) {'%k)
    out+=['        m.put(%s, %s);'%(lit(a),lit(b)) for a,b in ch]
    out+=['    }','']
out.append('}')
open(dst,'w',encoding='utf-8').write('\n'.join(out)+'\n')
print(len(rows),'entradas,',len(chunks),'metodos')
