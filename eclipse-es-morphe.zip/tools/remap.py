#!/usr/bin/env python3
"""
remap.py - mapa de nombres ofuscados entre dos versiones de Eclipse (clases Y metodos) para portar los parches.

Uso:
  python3 tools/remap.py firmas  <carpeta_con_classes.dex> <salida.json>          # saca la "firma" de cada clase/metodo de un APK
  python3 tools/remap.py mapa    <firmas_viejas.json> <firmas_nuevas.json> <mapa.json> [carpeta_patches]
  python3 tools/remap.py todo    <viejo.apk|carpeta_dex> <nuevo.apk|url|carpeta_dex> [carpeta_patches]   # TODO EN UNO: firmas + mapa + reporte corto
  python3 tools/remap.py aplicar <mapa.json> <carpeta_patches>                    # reescribe los nombres de clase en los .kt (solo los seguros)

Requisitos: pip install androguard --break-system-packages
Cada firma de clase = textos (const-string) + descriptores de metodos con los tipos ofuscados normalizados a "L?;".
Un metodo se identifica por (descriptor normalizado, textos que usa, numero de instrucciones).
"""
import sys, os, re, json
from collections import Counter

PAT = re.compile(r'L[a-z][a-z0-9]{0,5};')          # tipos ofuscados: Lq97; Ln34; ...
SAFE = {'igual', 'renombrada', 'cambio pequeno'}

def norm_desc(d):
    return PAT.sub('L?;', d[d.index('('):])

def cmd_firmas(dexdir, out):
    from loguru import logger; logger.remove()
    from androguard.core.dex import DEX
    res = {}
    for f in sorted(os.listdir(dexdir)):
        if not f.endswith('.dex'): continue
        dx = DEX(open(os.path.join(dexdir, f), 'rb').read())
        for c in dx.get_classes():
            strs = set(); meths = []
            for m in c.get_methods():
                code = m.get_code(); ms = []; n = 0
                if code:
                    for i in code.get_bc().get_instructions():
                        n += 1
                        if i.get_name().startswith('const-string'):
                            o = i.get_output(); q = o.find('"')
                            if q >= 0: ms.append(o[q:][:80])
                strs.update(ms)
                meths.append([m.get_name(), m.get_descriptor(), sorted(set(ms)), n])
            res[c.get_name()] = {'s': sorted(strs), 'm': meths, 'sup': c.get_superclassname()}
    json.dump(res, open(out, 'w'))
    print(dexdir, len(res), 'clases ->', out)

def jac(a, b):
    ia = sum((a & b).values()); ua = sum((a | b).values())
    return ia / ua if ua else 1.0

def cnorm(v):
    return Counter(v['s']), Counter(norm_desc(m[1]) for m in v['m'])

def score(x, y):
    s = jac(x[0], y[0]); m = jac(x[1], y[1])
    return (0.5 * s + 0.5 * m) if (sum(x[0].values()) + sum(y[0].values())) else m

def map_methods(old, new):
    """metodo viejo -> nuevo dentro de una pareja de clases."""
    out = {}
    nm = {}
    for name, desc, strs, n in new['m']:
        nm.setdefault((norm_desc(desc), tuple(strs), n), []).append((name, desc))
    nm2 = {}
    for name, desc, strs, n in new['m']:
        nm2.setdefault((norm_desc(desc), tuple(strs)), []).append((name, desc, n))
    for name, desc, strs, n in old['m']:
        key = name + desc
        c = nm.get((norm_desc(desc), tuple(strs), n), [])
        if len(c) == 1:
            out[key] = {'nuevo': c[0][0] + c[0][1], 'seguro': True}; continue
        c2 = nm2.get((norm_desc(desc), tuple(strs)), [])
        if len(c2) == 1:
            out[key] = {'nuevo': c2[0][0] + c2[0][1], 'seguro': n == c2[0][2]}; continue
        if len(c) > 1 or len(c2) > 1:
            out[key] = {'nuevo': None, 'seguro': False, 'nota': 'ambiguo'}
        else:
            out[key] = {'nuevo': None, 'seguro': False, 'nota': 'sin pareja'}
    return out

def tokens_de_patches(carpeta):
    toks = set()
    for root, _, fs in os.walk(carpeta):
        for f in fs:
            if f.endswith('.kt'):
                t = open(os.path.join(root, f), encoding='utf-8').read()
                toks.update(re.findall(r'(?<![A-Za-z0-9/$_])(L[a-z][a-z0-9]{0,5};)', t))
    return toks

def cmd_mapa(oldf, newf, out, patches=None):
    old = json.load(open(oldf)); new = json.load(open(newf))
    clases = sorted(c for c in (tokens_de_patches(patches) if patches else old) if c in old)
    nn = {k: cnorm(v) for k, v in new.items()}
    por_n = {}
    for k, y in nn.items(): por_n.setdefault(sum(y[1].values()), []).append(k)
    res = {}
    for cn in clases:
        x = cnorm(old[cn]); nmet = sum(x[1].values())
        same = score(x, nn[cn]) if cn in nn else -1
        best = (None, 0.0)
        for d in range(-3, 4):
            for k in por_n.get(nmet + d, []):
                sc = score(x, nn[k])
                if sc > best[1]: best = (k, sc)
        nme, sc = best
        if cn in nn and same >= 0.97 and nme == cn: est = 'igual'
        elif sc >= 0.85 and nme == cn: est = 'cambio pequeno'
        elif sc >= 0.85: est = 'renombrada'
        elif sc >= 0.65: est = 'dudosa'
        else: est = 'no encontrada'
        ent = {'estado': est, 'nuevo': nme if est != 'no encontrada' else None, 'parecido': round(sc, 2)}
        if ent['nuevo']: ent['metodos'] = map_methods(old[cn], new[ent['nuevo']])
        res[cn] = ent
    json.dump(res, open(out, 'w'), indent=1, ensure_ascii=False)
    cnt = Counter(v['estado'] for v in res.values())
    print(len(res), 'clases:', dict(cnt), '->', out)
    for k, v in res.items():
        if v['estado'] in ('dudosa', 'no encontrada'):
            print('  REVISAR', k, v['estado'], v['nuevo'], v['parecido'])

def cmd_aplicar(mapaf, carpeta):
    mapa = json.load(open(mapaf))
    ren = {k: v['nuevo'] for k, v in mapa.items() if v['estado'] in SAFE and v['nuevo'] and v['nuevo'] != k}
    pat = re.compile(r'(?<![A-Za-z0-9/$_])(' + '|'.join(re.escape(k) for k in ren) + r')')
    tot = 0
    for root, _, fs in os.walk(carpeta):
        for f in fs:
            if not f.endswith('.kt'): continue
            p = os.path.join(root, f)
            t = open(p, encoding='utf-8').read()
            n, c = pat.subn(lambda m: ren[m.group(1)], t)
            if c:
                open(p, 'w', encoding='utf-8').write(n); tot += c; print(f, c, 'cambios')
    print('total', tot, '(solo clases seguras; los METODOS y los casos dudosos se revisan a mano)')

def _dexdir(src, work, tag):
    import zipfile, subprocess
    if os.path.isdir(src): return src
    if src.startswith('http'):
        apk = os.path.join(work, tag + '.apk')
        subprocess.check_call(['curl', '-sL', '-o', apk, src]); src = apk
    d = os.path.join(work, tag + '_dex'); os.makedirs(d, exist_ok=True)
    with zipfile.ZipFile(src) as z:
        for n in z.namelist():
            if re.fullmatch(r'classes\d*\.dex', n): z.extract(n, d)
    return d

def cmd_todo(viejo, nuevo, patches=None):
    import tempfile
    patches = patches or 'patches/src/main/kotlin'
    work = tempfile.mkdtemp(prefix='remap_')
    dv, dn = _dexdir(viejo, work, 'viejo'), _dexdir(nuevo, work, 'nuevo')
    fv, fn = os.path.join(work, 'fv.json'), os.path.join(work, 'fn.json')
    cmd_firmas(dv, fv); cmd_firmas(dn, fn)
    mp = 'mapa_nuevo.json'
    cmd_mapa(fv, fn, mp, patches)
    mapa = json.load(open(mp))
    por = {}
    for f in sorted(os.listdir_r(patches) if False else [os.path.join(r, x) for r, _, fs in os.walk(patches) for x in fs if x.endswith('.kt')]):
        t = open(f, encoding='utf-8').read()
        cl = sorted(set(re.findall(r'(?<![A-Za-z0-9/$_])(L[a-z][a-z0-9]{0,5};)', t)) & set(mapa))
        if cl: por[os.path.basename(f)] = cl
    lines = ['REPORTE (por parche): OK = todas sus clases tienen pareja segura; REVISAR = hay clases sin pareja/dudosas']
    for f, cl in por.items():
        mal = [c for c in cl if mapa[c]['estado'] not in SAFE]
        lines.append(('REVISAR ' if mal else 'OK      ') + f + (' -> ' + ', '.join(mal) if mal else ''))
    open('reporte.txt', 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('\n'.join(lines)); print('\nGuardado: mapa_nuevo.json y reporte.txt. Siguiente: aplicar mapa_nuevo.json <patches> (solo clases) y revisar metodos a mano.')

if __name__ == '__main__':
    a = sys.argv[1:]
    if not a: print(__doc__); sys.exit(1)
    if a[0] == 'firmas': cmd_firmas(a[1], a[2])
    elif a[0] == 'mapa': cmd_mapa(a[1], a[2], a[3], a[4] if len(a) > 4 else None)
    elif a[0] == 'todo': cmd_todo(a[1], a[2], a[3] if len(a) > 3 else None)
    elif a[0] == 'aplicar': cmd_aplicar(a[1], a[2])
    else: print(__doc__)
