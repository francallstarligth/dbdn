# Compara un metodo 70 con su pareja 73 (instrucciones normalizadas). Uso: python3 -I cmp.py 'Lfz1;' I0 ['(desc70)']
import sys, subprocess, re
sys.path.insert(0, '/home/claude/repo/tools/port73'); import mm
c, n = sys.argv[1:3]; d = sys.argv[3] if len(sys.argv) > 3 else None
c2, o = mm.meth(c, n, d)
for a, B, cf in (o if isinstance(o, list) else []):
    for b in B:
        print('##', c, a[0], a[1], '->', c2, b[0], b[1], cf)
        def run(v, cc, m, dd): return subprocess.run(['python3', '-I', '/home/claude/repo/tools/port73/disasm.py', v, cc, m, dd.replace(' ', '')], capture_output=True, text=True).stdout.split('\n')[1:]
        x = run('70', c, a[0], a[1]); y = run('73', c2, b[0], b[1])
        nz = lambda L: [re.sub(r'L[a-z0-9]{1,4};(->[A-Za-z0-9_$]+)?', 'L?;', re.sub(r'^\d+ ', '', l)) for l in L]
        import difflib
        dl = [l for l in difflib.unified_diff(nz(x), nz(y), lineterm='', n=0) if not l.startswith(('---', '+++', '@@'))]
        print('instr 70/73:', len(x), len(y), 'diferencias:', len(dl)); print('\n'.join(dl[:40]))
