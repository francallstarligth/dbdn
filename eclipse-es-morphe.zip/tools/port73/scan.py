# Lee un parche .kt y muestra el equivalente 73 de cada clase/metodo/campo que cita. Uso: python3 -I scan.py parche.kt
import sys, re
sys.path.insert(0, '/home/claude/repo/tools/port73')
import mm
txt = open(sys.argv[1]).read()
code = re.sub(r'/\*.*?\*/', '', txt, flags=re.S)
code = re.sub(r'^\s*//.*$', '', code, flags=re.M)
ignore = ('Lapp/', 'Ljava/', 'Landroid/', 'Lkotlin/', 'Lcom/android', 'Lcom/google', 'Lorg/', 'Lj$/', 'Lcom/')
cl = sorted({c for c in re.findall(r'L[a-z0-9]{1,4};', code)})
print('== CLASES'); 
for c in cl: print(c, '->', mm.P.get(c) or 'SIN PAREJA')
print('== METODOS')
seen = set()
for m in re.finditer(r'(L[a-z0-9]{1,4};)->([A-Za-z0-9_<>$]+)(\([^)\s]*\)\S*?)(?=[\s,"\\]|$)', code):
    k = m.group(0)
    if k in seen: continue
    seen.add(k); c, n, d = m.group(1), m.group(2), m.group(3)
    if c not in mm.M70: continue
    c2, o = mm.meth(c, n, d[:d.index(')')+1] and None)
    if c2 is None: print(k, '=>', o); continue
    for a, B, conf in (o if isinstance(o, list) else []):
        if a[1].split(')')[0] != d.split(')')[0]: continue
        print(k, '=>', c2 + '->', [(b[0], b[1]) for b in B], conf)
print('== CAMPOS')
for m in re.finditer(r'(L[a-z0-9]{1,4};)->([A-Za-z0-9_$]+):(\S+?)(?=[\s,"\\]|$)', code):
    k = m.group(0)
    if k in seen: continue
    seen.add(k); c2, o = mm.field(m.group(1), m.group(2)) if m.group(1) in mm.M70 else (None, 'no es 70')
    print(k, '=>', c2, [(b[0], b[1], cf) for a, B, cf in o for b in B] if isinstance(o, list) else o)
print('== NOMBRES ENTRE COMILLAS (revisar a mano)')
for m in re.finditer(r'name == "([A-Za-z0-9_$]{1,4})"', code): print(m.group(0))
