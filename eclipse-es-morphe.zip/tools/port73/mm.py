# Biblioteca/CLI: busca en 73 un metodo/campo de 70. Uso: python3 -I mm.py <dir json> 'Lfz1;' I0 ['(Lfv4;)V']   |  campo: --f 'Lxm;' a
import sys, json, glob, re
D = '/tmp/claude-0/-home-claude/21b7852c-ba75-5d73-8d9f-2485727d003e/scratchpad'
def ld(p):
    r = {}
    for f in sorted(glob.glob(D + '/' + p)): r.update(json.load(open(f)))
    return r
P = json.load(open('/home/claude/repo/tools/port73/pairs_70_to_73.json'))
import os
_o = '/home/claude/repo/tools/port73/overrides.json'
if os.path.exists(_o): P.update(json.load(open(_o)))
M70 = ld('mem70_*.json'); M73 = ld('mem73_*.json')
DESC = re.compile(r'\[*L[^;]+;')
def mapt(t): return P.get(t, t)
def mapd(d): return DESC.sub(lambda m: mapt(m.group(0).lstrip('[')) if '[' not in m.group(0) else '['*m.group(0).count('[')+mapt(m.group(0).lstrip('[')), d)
def cls(c): return P.get(c)
def meth(c, name, desc=None):
    c2 = cls(c)
    if not c2: return None, 'sin pareja de clase'
    A = [m for m in M70[c]['m'] if m[0] == name and (desc is None or m[1].replace(' ', '') == desc)]
    if not A: return None, 'no existe en 70'
    out = []
    for a in A:
        tgt = mapd(a[1])
        B = [m for m in M73[c2]['m'] if m[1] == tgt]          # misma firma mapeada
        if not B: B = [m for m in M73[c2]['m'] if m[2] == a[2]]   # misma firma normalizada
        if len(B) > 1:
            h = [m for m in B if m[4] == a[4]]
            if len(h) == 1: B = h; conf = 'hash'
            else:
                B2 = sorted(B, key=lambda m: abs(m[3] - a[3]))
                conf = 'AMBIGUO(%d)' % len(B)
                B = B2[:1] if (len(B2) == 1 or abs(B2[0][3]-a[3]) < abs(B2[1][3]-a[3])) else B2[:3]
        else: conf = 'firma' if B else 'NO'
        if B and len(B) == 1 and conf == 'firma' and B[0][4] != a[4]: conf = 'firma(cuerpo distinto %d->%d ins)' % (a[3], B[0][3])
        out.append((a, B, conf))
    return c2, out
def field(c, name):
    c2 = cls(c)
    if not c2: return None, 'sin pareja'
    A = [f for f in M70[c]['f'] if f[0] == name]
    res = []
    for a in A:
        B = [f for f in M73[c2]['f'] if f[1] == mapd(a[1])] or [f for f in M73[c2]['f'] if f[2] == a[2]]
        if len(B) > 1:
            ia = [f for f in M70[c]['f'] if f[2] == a[2]].index(a)
            same = [f for f in M73[c2]['f'] if f[2] == a[2]]; B = [same[ia]] if ia < len(same) else B
            res.append((a, B, 'por orden'))
        else: res.append((a, B, 'firma'))
    return c2, res
if __name__ == '__main__':
    a = sys.argv[1:]
    if a[0] == '--f': print(field(a[1], a[2]))
    else:
        c2, o = meth(a[0], a[1], a[2] if len(a) > 2 else None); print(c2)
        for x in (o if isinstance(o, list) else [o]): print(x)

def findsig(c, name, desc=None):
    """Para clases sin pareja: busca en TODO 73 metodos con la firma mapeada del metodo 70."""
    res = []
    for a in M70[c]['m']:
        if a[0] != name or (desc and a[1] != desc): continue
        t = mapd(a[1])
        for k, v in M73.items():
            for m in v['m']:
                if m[1] == t: res.append((a, k, m))
    return res
