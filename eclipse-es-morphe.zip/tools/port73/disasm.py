# Desensambla un metodo. Uso: python3 -I dis.py <70|73> 'Lfz1;' I0 ['(desc)'] [desde hasta]
import sys, zipfile
from loguru import logger; logger.remove()
from androguard.core.dex import DEX
v, c, n = sys.argv[1:4]; rest = sys.argv[4:]
desc = rest[0] if rest and rest[0].startswith('(') else None
rng = [int(x) for x in (rest[1:] if desc else rest)]
apk = {'70': '/home/claude/apk70/eclipse0.6.70.apk', '73': '/home/claude/apk73/eclipse0.6.73.apk'}[v]
z = zipfile.ZipFile(apk)
for dn in ('classes.dex', 'classes2.dex'):
    dex = DEX(z.read(dn)); cd = [x for x in dex.get_classes() if x.get_name() == c]
    if cd: break
else: sys.exit('clase no hallada')
for m in cd[0].get_methods():
    if m.get_name() == n and (desc is None or m.get_descriptor().replace(' ', '') == desc.replace(' ', '')):
        print('##', m.get_name(), m.get_descriptor(), 'regs', m.get_code().get_registers_size() if m.get_code() else '-')
        if not m.get_code(): continue
        for i, ins in enumerate(m.get_code().get_bc().get_instructions()):
            if not rng or rng[0] <= i <= rng[1]: print(i, ins.get_name(), ins.get_output())
