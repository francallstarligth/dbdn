# Empareja clases 70->73. Uso: python3 -I match.py <dir con fp70_*.json y fp73_*.json> <salida pairs.json>
import sys, json, glob, hashlib, collections
d, out = sys.argv[1:3]
def load(p):
    r = {}
    for f in sorted(glob.glob(d + '/' + p)): r.update(json.load(open(f)))
    return r
A = load('fp70_*.json'); B = load('fp73_*.json')
def h(x): return hashlib.md5(repr(x).encode()).hexdigest()
def base(c): return h((c['acc'], c['sup'], c['itf'], c['fields'], c['methods'], c['strs']))
bA = {k: base(v) for k, v in A.items()}; bB = {k: base(v) for k, v in B.items()}
pairs = {}; inv = {}
def add(a, b):
    pairs[a] = b; inv[b] = a
for it in range(12):
    ga = collections.defaultdict(list); gb = collections.defaultdict(list)
    for k, v in A.items():
        if k in pairs: continue
        refs = tuple(sorted(pairs.get(r, '?') for r in v['refs']))
        ga[(bA[k], refs if it else ())].append(k)
    for k, v in B.items():
        if k in inv: continue
        refs = tuple(sorted(pairs.get(inv.get(r), '?') if r in inv else '?' for r in v['refs']))
        gb[(bB[k], refs if it else ())].append(k)
    n = 0
    for key, la in ga.items():
        lb = gb.get(key)
        if lb and len(la) == 1 and len(lb) == 1 and lb[0] not in inv:
            add(la[0], lb[0]); n += 1
    print('iter', it, 'nuevos', n, 'total', len(pairs))
    if n == 0 and it > 0: break
def feats(c, pm, inv_):
    s = {('m',) + tuple(m[:4]) for m in c['methods']}; s |= {('s', x) for x in c['strs']}; s |= {('f',) + tuple(f[:2]) for f in c['fields']}
    s |= {('d', m[0], m[1], m[2] // 4) for m in c['methods']}
    s |= {('t', c['sup'], c['acc'], len(c['methods']), len(c['fields']))}
    for r in c['refs']:
        s.add(('r', pm(r)))
    return s
def mutual(src, dst, thr):
    idx = collections.defaultdict(set)
    for k, s in dst.items():
        for f in s: idx[f].add(k)
    res = {}
    for k, s in src.items():
        if not s: continue
        cnt = collections.Counter()
        for f in s:
            for o in idx.get(f, ()): cnt[o] += 1
        sc = sorted(((c / len(s | dst[o]), o) for o, c in cnt.most_common(8)), reverse=True)
        if sc and sc[0][0] >= thr and (len(sc) < 2 or sc[1][0] < sc[0][0] - 0.05): res[k] = sc[0][1]
    return res
m2 = 0
for thr in (0.8, 0.7, 0.7, 0.6, 0.6):
    ra = [k for k in A if k not in pairs]; rb = [k for k in B if k not in inv]
    fa = {k: feats(A[k], lambda r: pairs.get(r, '?'), None) for k in ra}
    fb = {k: feats(B[k], lambda r: pairs.get(inv.get(r), '?') if r in inv else '?', None) for k in rb}
    ab = mutual(fa, fb, thr); ba = mutual(fb, fa, thr)
    n = 0
    for a, b in ab.items():
        if ba.get(b) == a and a not in pairs and b not in inv: add(a, b); n += 1
    m2 += n; print('parcial thr', thr, 'nuevos', n, 'total', len(pairs))
print('parcial', m2, 'total', len(pairs), 'de', len(A))
json.dump(pairs, open(out, 'w'), indent=0)
