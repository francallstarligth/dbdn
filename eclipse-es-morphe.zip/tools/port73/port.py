# Reescribe un parche 70 -> 73 en UNA pasada (clases, metodos y campos citados). Uso: python3 -I port.py entrada.kt salida.kt
import sys, re
sys.path.insert(0, '/home/claude/repo/tools/port73')
import mm
src, dst = sys.argv[1:3]
t = open(src).read(); warn = []
ns = lambda x: x.replace(' ', '')
RET = r'(?:\[*(?:[VZBSCIJFD]|L[^;\s"]+;))'
PAT = re.compile(r'(L[a-z0-9]{1,4};)(?:->([A-Za-z0-9_$<>]+)(?:(\([^)\s"]*\))(' + RET + r'?)|:(' + RET + r')))?')
def f(m):
    c, n, args, ret, fty = m.groups()
    if c not in mm.P and c not in mm.M70: return m.group(0)
    if n is None:
        if c in mm.P: return mm.P[c]
        warn.append('CLASE sin pareja %s' % c); return c
    c2 = mm.P.get(c)
    if c2 is None: warn.append('SIN CLASE %s' % m.group(0)); return m.group(0)
    if args is not None:
        if n in ('<init>', '<clinit>'):
            return c2 + '->' + n + mm.mapd(args) + (mm.mapd(ret) if ret else '')
        _, o = mm.meth(c, n)
        cand = [x for x in (o if isinstance(o, list) else []) if ns(x[0][1]).split(')')[0] + ')' == args]
        if len(cand) != 1 or len(cand[0][1]) != 1: warn.append('METODO dudoso %s' % m.group(0)); return m.group(0)
        a, B, cf = cand[0]
        if cf.startswith('AMBIGUO'): warn.append('METODO %s %s' % (m.group(0), cf))
        elif 'cuerpo distinto' in cf: warn.append('metodo con cuerpo distinto (revisar) %s' % m.group(0))
        b = ns(B[0][1]); return c2 + '->' + B[0][0] + b[:b.index(')') + 1] + (b[b.index(')') + 1:] if ret else '')
    _, o = mm.field(c, n)
    if not isinstance(o, list) or len(o) != 1 or len(o[0][1]) != 1: warn.append('CAMPO dudoso %s' % m.group(0)); return m.group(0)
    if o[0][2] != 'firma': warn.append('CAMPO por orden %s -> %s' % (m.group(0), o[0][1][0][0]))
    return c2 + '->' + o[0][1][0][0] + ':' + mm.mapd(fty)

def pre(m):
    c, mid, nm = m.group(1), m.group(2), m.group(3)
    c2 = mm.P.get(c)
    if c2 is None or c not in mm.M70: return m.group(0)
    ctx = t[max(0, m.start() - 220):m.end()]
    isf = bool(re.search(r'SGET|IGET|SPUT|IPUT', ctx))
    if isf:
        _, o = mm.field(c, nm)
        new = {x[1][0][0] for x in o if x[1]} if isinstance(o, list) else set()
    else:
        _, o = mm.meth(c, nm)
        new = {b[0] for a, B, cf in o for b in B} if isinstance(o, list) else set()
    if len(new) != 1: warn.append('NOMBRE %s.%s no se pudo mapear (%s)' % (c, nm, new)); return m.group(0)
    n2 = new.pop()
    if n2 != nm: warn.append('nombre %s.%s -> %s' % (c, nm, n2))
    return m.group(0)[:m.start(3) - m.start()] + n2 + m.group(0)[m.end(3) - m.start():]
t = re.sub(r'"(L[a-z0-9]{1,4};)"(\s*(?:&&|\|\|)\s*\w+\.name\s*(?:==|!=)\s*")([A-Za-z0-9_$<>]+)(?=")', pre, t)
t = PAT.sub(f, t)
open(dst, 'w').write(t)
for w in sorted(set(warn)): print('AVISO', w)
for i, l in enumerate(t.split('\n'), 1):
    if re.search(r'name == "[A-Za-z0-9_$]{1,4}"|name\s*==|\.name\b', l): print('REVISAR NOMBRE linea', i, l.strip()[:150])
