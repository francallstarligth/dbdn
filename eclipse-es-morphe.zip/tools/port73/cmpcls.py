# Compara TODOS los metodos de una clase 70 con su pareja 73. Uso: python3 -I cmpcls.py 'Ldq;' ['Lotra;' ...]
import sys, re, zipfile, difflib
sys.path.insert(0, '/home/claude/repo/tools/port73'); import mm
from loguru import logger; logger.remove()
from androguard.core.dex import DEX
cls70 = sys.argv[1:]
def load(apk, names):
    z = zipfile.ZipFile(apk); out = {}
    for dn in ('classes.dex', 'classes2.dex'):
        dex = DEX(z.read(dn))
        for c in dex.get_classes():
            if c.get_name() in names:
                for m in c.get_methods():
                    code = m.get_code()
                    ins = [re.sub(r'L[a-z0-9]{1,4};(->[A-Za-z0-9_$]+)?', 'L?;', ' '.join([i.get_name(), i.get_output()])) for i in code.get_bc().get_instructions()] if code else []
                    out[(c.get_name(), m.get_name(), m.get_descriptor().replace(' ', ''))] = ins
        del dex
    return out
c73 = {mm.P[c] for c in cls70 if c in mm.P}
a = load('/home/claude/apk70/eclipse0.6.70.apk', set(cls70)); b = load('/home/claude/apk73/eclipse0.6.73.apk', c73)
for c in cls70:
    c2 = mm.P.get(c); print('##', c, '->', c2); tot = bad = 0
    for (cc, n, d), ins in sorted(a.items()):
        if cc != c: continue
        tot += 1
        cands = [v for (c3, n3, d3), v in b.items() if c3 == c2 and len(v) == len(ins)]
        best = min((sum(1 for _ in difflib.unified_diff(ins, v, n=0)) for v in cands), default=None)
        if best is None or best > 0 and len(ins) > 0 and best > 3:
            bad += 1; print('  DIFERENTE', n, d[:50], len(ins), 'mejor=', best)
    print('  metodos', tot, 'diferentes', bad)
