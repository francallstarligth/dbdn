# Volcado de miembros (nombre real) de todas las clases. Uso: python3 -I mem.py <apk> <dex> <salida.json>
import sys, re, json, zipfile, hashlib
from loguru import logger; logger.remove()
from androguard.core.dex import DEX
apk, dexname, out = sys.argv[1:4]
OBF = re.compile(r'^\[*L(?:[a-z0-9]{1,3}/)*[a-zA-Z0-9]{1,4};$')
DESC = re.compile(r'\[*L[^;]+;')
nd = lambda d: DESC.sub(lambda m: 'L?;' if OBF.match(m.group(0)) else m.group(0), d)
dex = DEX(zipfile.ZipFile(apk).read(dexname)); res = {}
for c in dex.get_classes():
    ms = []
    for m in c.get_methods():
        code = m.get_code(); ops = []
        if code:
            for ins in code.get_bc().get_instructions():
                n = ins.get_name()
                if n.startswith('const-string'): ops.append(n + ':' + ins.get_output().split(', ', 1)[-1][:40])
                elif n.startswith(('invoke', 'iget', 'iput', 'sget', 'sput')):
                    o = ins.get_output().split(', ')[-1]; cl, _, t = o.partition('->')
                    ops.append(n.split('/')[0] + ':' + ('L?;' if OBF.match(cl) else cl) + '->' + (t if '(' not in t else nd(t)))
                else: ops.append(n)
        ms.append([m.get_name(), m.get_descriptor(), nd(m.get_descriptor()), len(ops), hashlib.md5('|'.join(ops).encode()).hexdigest()[:8], m.get_access_flags()])
    res[c.get_name()] = dict(m=ms, f=[[f.get_name(), f.get_descriptor(), nd(f.get_descriptor()), f.get_access_flags()] for f in c.get_fields()])
json.dump(res, open(out, 'w')); print(len(res))
