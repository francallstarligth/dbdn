# Huella estructural de las clases de un dex. Uso: python3 -I fp.py <apk> <dex> <salida.json>
import sys, re, json, zipfile, hashlib
from loguru import logger; logger.remove()
from androguard.core.dex import DEX
apk, dexname, out = sys.argv[1:4]
OBF = re.compile(r'^\[*L(?:[a-z0-9]{1,3}/)*[a-zA-Z0-9]{1,4};$')
def nt(t):
    return 'L?;' if OBF.match(t) and not t.startswith('[') else (('[' * (len(t)-len(t.lstrip('[')))) + 'L?;' if OBF.match(t) else t)
DESC = re.compile(r'\[*L[^;]+;')
def nd(d): return DESC.sub(lambda m: nt(m.group(0)), d)
def h(s): return hashlib.md5(s.encode()).hexdigest()[:10]
z = zipfile.ZipFile(apk)
dex = DEX(z.read(dexname))
res = {}
for c in dex.get_classes():
    name = c.get_name()
    ms = []; strs = set(); calls = set(); refs = set()
    for m in list(c.get_methods()):
        code = m.get_code()
        ops = []
        if code:
            for ins in code.get_bc().get_instructions():
                n = ins.get_name()
                if n.startswith('const-string'):
                    s = ins.get_output().split(', ',1)[-1]; strs.add(s[:80]); ops.append(n+':'+s[:40])
                elif n.startswith('invoke') or n.startswith(('iget','iput','sget','sput')):
                    o = ins.get_output().split(', ')[-1]
                    cl = o.split('->')[0]
                    if OBF.match(cl): refs.add(cl); cl = 'L?;'
                    tail = o.split('->',1)[-1]
                    ops.append(n.split('/')[0]+':'+cl+'->'+nd(tail))
                    if cl != 'L?;': calls.add(cl+'->'+nd(tail))
                else:
                    ops.append(n)
        nm = m.get_name()
        ms.append([nm if len(nm) > 3 else '_', nd(m.get_descriptor()), len(ops), h('|'.join(ops)), m.get_access_flags()])
    fs = []
    for f in c.get_fields():
        fs.append([f.get_name() if len(f.get_name()) > 3 else '_', nt(f.get_descriptor()), f.get_access_flags()])
    sup = c.get_superclassname(); itf = c.get_interfaces() or []
    for t in [sup] + list(itf) + [f.get_descriptor() for f in c.get_fields()]:
        t = t.lstrip('[')
        if OBF.match(t): refs.add(t)
    for m in ms: pass
    res[name] = dict(acc=c.get_access_flags(), sup=sup if not OBF.match(sup) else 'L?;', rsup=sup,
                     itf=sorted(nt(i) for i in itf), ritf=list(itf), fields=sorted(fs), methods=sorted(ms),
                     strs=sorted(strs)[:60], refs=sorted(refs))
json.dump(res, open(out, 'w'))
print(len(res), 'clases')
