# Compara un metodo 73 con su pareja 75. Uso: python3 -I cmp75.py 'Lviejo;' 'Lnuevo;' nombre73 [nombre75] [desc73]
import sys, re, subprocess, difflib
cv, cn, n73 = sys.argv[1:4]; n75 = sys.argv[4] if len(sys.argv) > 4 and sys.argv[4] != '-' else n73
d = sys.argv[5] if len(sys.argv) > 5 else None
def run(v, c, n):
    out = subprocess.run(['python3','-I','/home/claude/repo/tools/port73/disasm75.py',v,c,n]+([d.replace(' ','')] if d else []),capture_output=True,text=True).stdout
    return out
x = run('73', cv, n73); y = run('75', cn, n75)
nz = lambda s: [re.sub(r'L[a-z0-9]{1,4};(->[A-Za-z0-9_$]+)?','L?;',re.sub(r'^\d+ ','',l)) for l in s.split('\n') if l and not l.startswith('##')]
a, b = nz(x), nz(y)
dl = [l for l in difflib.unified_diff(a, b, lineterm='', n=0) if not l.startswith(('---','+++','@@'))]
print('instr 73/75:', len(a), len(b), 'diferencias:', len(dl)); print('\n'.join(dl[:40]))
