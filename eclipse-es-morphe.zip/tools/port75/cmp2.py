# Uso: python3 -I cmp2.py Lc75; metodo   -> compara con la clase 73 pareja (inversa) por opcodes normalizados
import sys,re,subprocess,difflib; sys.path.insert(0,'/home/claude/repo/tools/port73')
import mm75 as mm
inv={v:k for k,v in mm.P.items()}
c75,n=sys.argv[1:3]; c73=inv.get(c75)
if not c73: print(c75,n,'SIN pareja 73'); sys.exit()
def run(v,c,n):
    return subprocess.run(['python3','-I','/home/claude/repo/tools/port73/disasm75.py',v,c,n],capture_output=True,text=True).stdout
nz=lambda s:[re.sub(r'L[a-z0-9]{1,4};(->[A-Za-z0-9_$]+)?','L?;',re.sub(r'^\d+ ','',l)) for l in s.split('\n') if l and not l.startswith('##')]
a=nz(run('73',c73,n)); b=nz(run('75',c75,n))
dl=[l for l in difflib.unified_diff(a,b,lineterm='',n=0) if not l.startswith(('---','+++','@@'))]
print(c75,n,'<-',c73,'| ins',len(a),len(b),'| dif',len(dl)); print('\n'.join(dl[:6]))
