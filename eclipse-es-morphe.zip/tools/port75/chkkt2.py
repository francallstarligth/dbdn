# Para cada "Lx;" citado en un .kt, mira los name == "n" que le siguen (160 car.) y comprueba que existan en 75.
import sys,re; sys.path.insert(0,'/home/claude/repo/tools/port73')
import mm75 as mm
for f in sys.argv[1:]:
    t=open(f).read(); print('##',f.split('/')[-1]); seen=set()
    for m in re.finditer(r'"(L[a-z0-9]{1,4};)"',t):
        c=m.group(1); seg=t[m.end():m.end()+170]
        # cortar en el siguiente "L..;" para no mezclar
        n2=re.search(r'"L[a-z0-9]{1,4};"',seg); seg=seg[:n2.start()] if n2 else seg
        names=re.findall(r'name\s*(?:==|!=)\s*"([A-Za-z0-9_$<>]+)"',seg)
        for n in names:
            if (c,n) in seen: continue
            seen.add((c,n))
            if c not in mm.M73: print(' ',c,n,'*** clase no existe en 75'); continue
            ms=[x for x in mm.M73[c]['m'] if x[0]==n]; fs=[x for x in mm.M73[c]['f'] if x[0]==n]
            print(' ',c,n,'met%d camp%d'%(len(ms),len(fs)), '' if (ms or fs) else '*** NO EXISTE en 75')
