# Uso: python3 -I q75.py 'Lc73;' [metodo|campo ...]   -> pareja 75 y miembros mapeados (m:nombre, f:nombre)
import sys; sys.path.insert(0,'/home/claude/repo/tools/port73')
import mm75 as mm
c=sys.argv[1]; print(c,'->',mm.P.get(c))
for x in sys.argv[2:]:
    k,n=x.split(':',1)
    if k=='f':
        c2,o=mm.field(c,n)
        for a,B,cf in (o if isinstance(o,list) else []): print('  campo',a[0],a[1],'->',[(b[0],b[1]) for b in B],cf)
    else:
        c2,o=mm.meth(c,n)
        for a,B,cf in (o if isinstance(o,list) else []): print('  met',a[0],a[1],a[3],'ins ->',[(b[0],b[1],b[3]) for b in B],cf)
