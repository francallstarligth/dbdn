# Verifica que cada referencia Lx;->m(...) de un .kt exista en el dex 75 y que su pareja 73 tenga el mismo cuerpo (hash).
import sys,re; sys.path.insert(0,'/home/claude/repo/tools/port73')
import mm75 as mm
inv={v:k for k,v in mm.P.items()}
ns=lambda s:s.replace(' ','')
for f in sys.argv[1:]:
    t=open(f).read(); print('##',f.split('/')[-1]); seen=set()
    for m in re.finditer(r'(L[a-z0-9]{1,4};)->([A-Za-z0-9_$<>]+)(?:(\([^)\s"]*\))([^\s"\\,]*)|:([^\s"\\,]+))?',t):
        c,n,args,ret,fty=m.groups()
        if (c,n,args)in seen or c not in mm.M73: continue
        seen.add((c,n,args))
        if args is None:
            ok=[x for x in mm.M73[c]['f'] if x[0]==n]
            print(' campo',c,n,'OK' if ok else '*** NO EXISTE en 75'); continue
        cand=[x for x in mm.M73[c]['m'] if x[0]==n and ns(x[1]).split(')')[0]+')'==args]
        if not cand: print(' met',c,n,args,'*** NO EXISTE en 75'); continue
        c73=inv.get(c); st='sin pareja 73'
        if c73 and c73 in mm.M70:
            h=[x for x in mm.M70[c73]['m'] if x[4]==cand[0][4] and x[3]==cand[0][3]]
            st='cuerpo igual en 73 (%s.%s)'%(c73,h[0][0]) if h else '*** cuerpo distinto/no hallado en 73 (%s)'%c73
        print(' met',c,n,args,'OK',st)
